Imports UtilityClassLibrary
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports System.Configuration

' Batch Send To Department �ӧҹ�ͺ��� 1
' Batch �ͺ�����觢����š�Ѻ㹷ء˹�ҧҹ ��� P&P ���ҧ���� ���੾�� Cheque & Draft ��ҹ��

Public Class FrmExportDep
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim currentFullDate As String
    Dim currentHaftDate As String

    Private Sub FrmExportDep_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim strDate As String

            My.Application.ChangeCulture("en-GB")

            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                    'Return exit code to batch
                    Environment.ExitCode = 2

                    Exit Sub
                End If
            End If

            currentFullDate = Now.ToString("yyyyMMdd")
            currentHaftDate = Now.ToString("yyMMdd")

            strDate = fnGetLastWorkDay(currentFullDate, 1)

            If (CheckFileSendDep(strDate)) Then
                'MsgBox("�������ö  Export to Department �� ���ͧ�ҡ File ��Ѻ�����ú��ǹ")
            Else
                Debug.Print(System.DateTime.Now)

                fnGenTextFile(1)

                Debug.Print(System.DateTime.Now)
                'MsgBox("  Export to Department Completed")
            End If

            'MsgBox("Batch Export Data To Department Completed")

            'Me.Close()
        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            Me.Close()
        End Try

    End Sub
    Private Function CheckFileSendDep(ByVal strExportDate As String) As Boolean
        Dim dt_CheckFile As DataTable

        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)
        ' ��Ǩ�ͺ�������Ѻ�Ҥú���� ����Ҥú���� �е�ͧ�������¡�â����ŷ���ѧ��� 
        sb.Append(" select GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append("           left join GPS_TRANSREF_REL ")
        sb.Append("             on GPS_PAYMENT.Gp_Createdate = GPS_TRANSREF_REL.Tref_Createdate ")
        sb.Append("            and GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TRANSREF_REL.Tref_Core_System ")
        sb.Append("            and GPS_PAYMENT.Gp_Transref = GPS_TRANSREF_REL.Tref_Transref ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        '--sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP') ")
        sb.Append("   and ( GPS_PAYMENT.GP_CORE_SYSTEM = 'PP' ")
        sb.Append("     or (GPS_PAYMENT.GP_CORE_SYSTEM = 'ACC' and GPS_TRANSREF_REL.TREF_DTSOURCE = 'AGT') ")
        sb.Append("       ) ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_DATE <= '" & strExportDate & "' ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH in ('C' , 'D') ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N' ")

        dt_CheckFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_CheckFile) AndAlso dt_CheckFile.Rows.Count > 0 Then
            Return True

        Else
            Return False
        End If


    End Function
    'Private Function CheckFileMediaSendDep(ByVal strDueDate As String) As Boolean
    '    Dim dt_CheckFile As DataTable

    '    Dim sb As New StringBuilder

    '    sb.Remove(0, sb.Length)
    '    ' ��Ǩ�ͺ�������Ѻ�Ҥú���� ����Ҥú���� �е�ͧ�������¡�â����ŷ���ѧ��� 
    '    sb.Append(" select GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
    '    sb.Append(" from GPS_PAYMENT   ")
    '    sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
    '    sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
    '    sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
    '    sb.Append(" and GPS_PAYMENT.GP_PAIDDATE <= '" & strDueDate & "' ")
    '    sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' ")
    '    sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT is null ")

    '    dt_CheckFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

    '    If Not IsNothing(dt_CheckFile) AndAlso dt_CheckFile.Rows.Count > 0 Then
    '        Return True

    '    Else
    '        Return False
    '    End If


    'End Function


    Private Sub fnGenTextFile(ByVal BatchNo As Integer)
        Dim dt_Filename As DataTable
        Dim dt2 As DataTable
        Dim sb As New StringBuilder
        Dim sb2 As New StringBuilder
        Dim vlineNo As Double
        Dim filename As String
        Dim filenameRunning As Double
        Dim GenTextFilePath As String
        'Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        Dim AMOUNT() As String
        Dim AMOUNT1 As String
        Dim AMOUNT2 As String

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        '--Begin Adjust By Songpol 16/02/2015  
        '--Add Variable Path File Other System
        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENOTHSYS_PATH")

        GenTextFilePath = descpath
        '--End Adjust By Songpol 16/02/2015


        sb.Remove(0, sb.Length)

        'sb.Append(" select GPS_PAYMENT.GP_DATASOURCE_NME as DATASOURCE_NME ")
        'sb.Append(" , count(GPS_PAYMENT.GP_AMOUNT) as CountTrans   ")
        'sb.Append(" , TO_CHAR(sum(GPS_PAYMENT.GP_AMOUNT),'999999999999999.99') as AmountTrans   ")
        'sb.Append(" , MAX(to_char(sysdate,'YYYYMMDD')) as DateTrans   ")
        'sb.Append(" from GPS_PAYMENT   ")
        'sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        'sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        'sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP'  ) ")
        'sb.Append(" and GPS_PAYMENT.GP_PAYMTH in ('C' , 'D') ")
        'sb.Append(" group by GPS_PAYMENT.GP_DATASOURCE_NME ")
        'sb.Append(" order by GPS_PAYMENT.GP_DATASOURCE_NME ")

        sb.Append(" SELECT GP.DATASOURCE_NME, ")
        sb.Append("  GP.CountTrans+NVL(GP_REJ.NO_Record,0) As CountTrans, ")
        sb.Append("  TO_CHAR(GP.AmountTrans+NVL(GP_REJ.GPRJ_AMOUNT,0), '999999999999999.99') as AmountTrans, ")
        sb.Append(" GP.DateTrans ")
        sb.Append(" FROM (select GPS_PAYMENT.GP_DATASOURCE_NME as DATASOURCE_NME ")
        sb.Append(" , count(GPS_PAYMENT.GP_AMOUNT) as CountTrans   ")
        sb.Append(" , sum(GPS_PAYMENT.GP_AMOUNT) as AmountTrans   ")
        sb.Append(" , MAX(to_char(sysdate,'YYYYMMDD')) as DateTrans   ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append("               left join GPS_TRANSREF_REL ")
        sb.Append("                 on GPS_PAYMENT.Gp_Createdate = GPS_TRANSREF_REL.Tref_Createdate ")
        sb.Append("                and GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TRANSREF_REL.Tref_Core_System ")
        sb.Append("                and GPS_PAYMENT.Gp_Transref = GPS_TRANSREF_REL.Tref_Transref ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        '--sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP'  ) ")
        sb.Append(" and ( GPS_PAYMENT.GP_CORE_SYSTEM = 'PP' ")
        sb.Append("  or ( GPS_PAYMENT.GP_CORE_SYSTEM = 'ACC' and GPS_TRANSREF_REL.TREF_DTSOURCE = 'AGT' ) ")
        sb.Append("     ) ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH in ('C' , 'D') ")
        sb.Append(" group by GPS_PAYMENT.GP_DATASOURCE_NME ")
        sb.Append(" order by GPS_PAYMENT.GP_DATASOURCE_NME) GP ")
        sb.Append(" LEFT JOIN (SELECT RJ.GPRJ_DATASOURCE_NME,  ")
        sb.Append("                  COUNT(RJ.GPRJ_CORE_SYSTEM) AS NO_Record,  ")
        sb.Append("                  SUM(RJ.GPRJ_AMOUNT) AS GPRJ_AMOUNT  ")
        sb.Append("          FROM GPS_PAYMENT_REJ RJ  ")
        sb.Append("                    left join GPS_TRANSREF_REL ")
        sb.Append("                      on RJ.GPRJ_CREATEDATE = GPS_TRANSREF_REL.Tref_Createdate ")
        sb.Append("                     and RJ.GPRJ_CORE_SYSTEM = GPS_TRANSREF_REL.Tref_Core_System ")
        sb.Append("                     and RJ.GPRJ_Transref = GPS_TRANSREF_REL.Tref_Transref ")
        '--sb.Append("          WHERE RJ.GPRJ_CORE_SYSTEM = 'PP'  ")
        sb.Append("          WHERE ( RJ.GPRJ_CORE_SYSTEM = 'PP' ")
        sb.Append("             OR ( RJ.GPRJ_CORE_SYSTEM = 'ACC' AND GPS_TRANSREF_REL.TREF_DTSOURCE = 'AGT' ) ")
        sb.Append("                ) ")
        sb.Append("          AND RJ.GPRJ_REJECT_FUNC <> 'BANK'  ")
        sb.Append("          GROUP BY RJ.GPRJ_DATASOURCE_NME) GP_REJ  ")
        sb.Append(" ON GP.DATASOURCE_NME = GP_REJ.GPRJ_DATASOURCE_NME  ")
        sb.Append(" ORDER BY GP.DATASOURCE_NME ")


        filenameRunning = 1

        dt_Filename = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_Filename) AndAlso dt_Filename.Rows.Count > 0 Then

            'oleTrans = clsUtility.gConnGP.BeginTransaction

            Dim oShell : oShell = CreateObject("WScript.Shell")
            Dim oEnv : oEnv = oShell.Environment("PROCESS")
            oEnv.Item("NLS_LANG") = "THAI_THAILAND.TH8TISASCII"

            For Each dr_Filename As DataRow In dt_Filename.Rows



                filename = GenTextFilePath & dr_Filename("DATASOURCE_NME").ToString & currentFullDate & CStr(filenameRunning).ToString.PadLeft(3, "0") & ".txt"

                If System.IO.File.Exists(filename) Then
                    My.Computer.FileSystem.DeleteFile(filename)
                End If

                dt2 = GetData(dr_Filename("DATASOURCE_NME").ToString)
                vlineNo = 0
                Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)

                ' Detail
                For Each dr As DataRow In dt2.Rows
                    vlineNo = vlineNo + 1

                    'sw.WriteLine(vlineNo & "," & dr("EXPDATA").ToString)
                    sw.WriteLine(dr("EXPDATA").ToString)



                Next


                ' Total 
                sw.Write("TOTAL:")
                sw.Write(dr_Filename("CountTrans").ToString.PadLeft(10, "0"))

                AMOUNT = Split(Trim(dr_Filename("AmountTrans").ToString), ".")
                AMOUNT1 = AMOUNT(0).PadLeft(18, "0")
                AMOUNT2 = AMOUNT(1).PadLeft(2, "0")
                sw.Write(AMOUNT1 & AMOUNT2)
                sw.Close()

                '---- Update �ͺ Batch �š�Ѻ�ҡ Bank
                UPD_GP_EXPTOOTHSYS_NO(Trim(BatchNo), Trim(dr_Filename("DATASOURCE_NME").ToString))


            Next 'dr_Filename

            ' ---- Update datasource for Accounting only

            UPD_GP_EXPTOOTHSYS_NO_ACC(Trim(BatchNo), "")

            'MsgBox("Gen Text Completed")

        Else
            'MsgBox("No Text File ")
            UPD_GP_EXPTOOTHSYS_NO_ACC(Trim(BatchNo), "")
        End If


    End Sub
    Public Function UPD_GP_EXPTOOTHSYS_NO(BatchNo As Integer, ByVal DatasourceName As String) As Integer
        Dim sb2 As New StringBuilder
        Dim Rec As Integer
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction

        sb2.Remove(0, sb2.Length)
        sb2.Append("  UPDATE GPS_PAYMENT  ")
        sb2.Append("  SET GPS_PAYMENT.GP_EXPTOOTHSYS_NO = " & Trim(BatchNo) & " ")
        sb2.Append(" , GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'Y' ")
        sb2.Append(" , GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = to_char(sysdate,'YYYYMMDD') ")
        sb2.Append("  WHERE  GPS_PAYMENT.GP_DATASOURCE_NME =  '" & DatasourceName & "'  ")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

        If Rec > 0 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()

        End If

    End Function
    Public Function UPD_GP_EXPTOOTHSYS_NO_ACC(BatchNo As Integer, ByVal DatasourceName As String) As Integer
        Dim sb2 As New StringBuilder
        Dim Rec As Integer
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction

        sb2.Remove(0, sb2.Length)
        sb2.Append("  UPDATE GPS_PAYMENT  ")
        sb2.Append("  SET GPS_PAYMENT.GP_EXPTOOTHSYS_NO = " & Trim(BatchNo) & "  ")
        sb2.Append(" , GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'Y' ")
        sb2.Append(" , GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = to_char(sysdate,'YYYYMMDD') ")
        sb2.Append("  where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
        sb2.Append("  and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb2.Append("  and GPS_PAYMENT.GP_CORE_SYSTEM  in ( 'ACC' )  ")
        sb2.Append("  and TRIM(GPS_PAYMENT.Gp_Transref) NOT IN (SELECT TRIM(T.TREF_TRANSREF) FROM GPS_TRANSREF_REL T WHERE T.TREF_CORE_SYSTEM = 'ACC' AND T.TREF_DTSOURCE = 'AGT')  ")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

        If Rec > 0 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()

        End If

    End Function
    Public Function GetData(ByVal DatasourceName As String) As DataTable
        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)
        sb.Append(" SELECT  RPAD(ROWNUM,7,' ')||EXPDATA as EXPDATA ")
        sb.Append(" from ( ")

        sb.Append(" SELECT * from (  ")

        sb.Append(" SELECT ")
        sb.Append(" RPAD(NVL(GPS_PAYMENT.GP_CHQNO,' '),20,' ') ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYDESC,' '),150,' ') ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ') ")
        sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT.GP_AMOUNT,'0'),'999999999999999999.99')),19,' ') ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BILLNO,' '),15,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_POLNO,' '),20,' ')  ")
        sb.Append(" ||RPAD('0',10,'0') ")
        sb.Append(" ||RPAD('0',10,'0') ")
        sb.Append(" ||case  ")
        sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M'  then RPAD('C',50,' ') ")
        sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'C'  then RPAD('C',50,' ') ")
        sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'D'  then RPAD('C',50,' ') ")
        sb.Append(" else RPAD(' ',50,' ') ")
        sb.Append(" end ")
        sb.Append(" ||RPAD(' ',50,' ') ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNO,' '),50,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNME,' '),50,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BNKCODE,' '),5,' ')  ")
        sb.Append(" ||RPAD(' ',150,' ') ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_ADDRESS1,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DISTRICT,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PROVINCE,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_INSURENAME,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DATASOURCE_NME,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE6,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_MERCHN_NO,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_CDCARD_DATE,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE9,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE10,' '),100,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_REF,' '),5,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_GR,' '),5,' ') ")
        sb.Append(" as EXPDATA , GPS_PAYMENT.GP_GPTREF_SEQNO as GPTREF_SEQNO ")
        sb.Append(" from GPS_PAYMENT ")
        sb.Append(" where GPS_PAYMENT.GP_DATASOURCE_NME = '" & DatasourceName & "' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")

        sb.Append(" union all  ")

        sb.Append(" SELECT   ")
        sb.Append(" RPAD(' ',20,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DESC,' '),150,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
        sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT_REJ.GPRJ_AMOUNT,'0'),'999999999999999999.99')),19,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BILLNO,' '),15,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_POLNO,' '),20,' ')    ")

        'sb.Append(" ||RPAD(' ',10,' ')   ")
        'sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYMTH,' '),10,' ')    ")
        sb.Append(" ||RPAD('0',10,'0')   ")
        sb.Append(" ||RPAD('0',10,'0')   ")

        sb.Append(" ||RPAD('R',50,' ')    ")
        sb.Append(" ||RPAD(' ',50,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNO,' '),50,' ')  ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNME,' '),50,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BNKCODE,' '),5,' ')   ")
        sb.Append(" ||RPAD(' ',150,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_ADDRESS1,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DISTRICT,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PROVINCE,' '),100,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_INSURENAME,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE6,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_MERCHN_NO,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_CDCARD_DATE,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE9,' '),100,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE10,' '),100,' ')   ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_REF,' '),5,' ')    ")
        sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_GR,' '),5,' ')  ")
        sb.Append(" as EXPDATA , GPS_PAYMENT_REJ.GPRJ_GPTREF_SEQNO as GPTREF_SEQNO  ")
        sb.Append(" from GPS_PAYMENT_REJ   ")
        sb.Append(" where GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME = '" & DatasourceName & "'   ")
        sb.Append(" and GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE <> 'BANK_REJ'   ")
        sb.Append(" and GPS_PAYMENT_REJ.GPRJ_BATCHTYPE <> 'BANK'   ")

        sb.Append(" ) MasterData  ")
        sb.Append(" order by MasterData.GPTREF_SEQNO  ")


        sb.Append(" ) ExportData ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetWorkDay(ByVal CurrentDate As DateTime) As Boolean

        Select Case CurrentDate.DayOfWeek
            Case DayOfWeek.Saturday
                Return False
            Case DayOfWeek.Sunday
                Return False
            Case Else
                'handles sunday through thursday
                Return True
        End Select

    End Function
    Function LookUpHoliday(ByVal d_start As String, ByVal d_end As String) As Integer

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE BETWEEN '" & d_start & "'  AND '" & d_end & "'  AND HLDS_COMPANY_CODE='SCBLIFE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return 0
        End If

    End Function
    Public Function fnGetLastWorkDay(ByVal begin_date As String, ByVal total_day As Integer) As String
        Dim RetDate As Date
        Dim countworkdate As Integer
        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim format As String = "yyyyMMdd"

        RetDate = Date.ParseExact(begin_date, format, New Globalization.CultureInfo("en-US"))

        Do While countworkdate <> total_day

            RetDate = DateAdd(DateInterval.Day, -1, RetDate)

            chkHoliday = LookUpHoliday(RetDate.ToString("yyyyMMdd"), RetDate.ToString("yyyyMMdd"))

            If chkHoliday > 0 Then
                total_day = total_day + 1
            End If

            chkWorkDay = GetWorkDay(RetDate)
            If chkWorkDay Then
                countworkdate += 1
            End If


        Loop

        Return RetDate.ToString("yyyyMMdd")

    End Function

    Function GetDataSource(ByVal datefrom As String, ByVal dateto As String, ByVal sourcename As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""

        sb.Append("SELECT GP_DATASOURCE_NME FROM GPS_PAYMENT ")
        sb.Append("WHERE GP_PAIDDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        sb.Append("AND GP_FLAG_GET_RESULT = 'Y' ")
        sb.Append("AND GP_FLAG_EXPTOOTHSYS = 'Y' ")
        sb.Append("GROUP BY GP_DATASOURCE_NME ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function
    Private Sub GenInterfaceReport(ByVal status As String, ByVal datefrom As String, ByVal dateto As String, ByVal datasourcename As String, ByVal datasourcefilename As String)
        'Dim dt_source As New DataTable
        'dt_source = GetDataSource(datefrom, dateto, datasourcename)
        'If Not IsNothing(dt_source) AndAlso dt_source.Rows.Count > 0 Then

        '    For Each dr As DataRow In dt_source.Rows

        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_DATASOURCE_NME,P.GP_CREATEDATE,R.TREF_BATCH_NO,P.GP_CHQNO,P.GP_PAYDESC,T.PAYT_PAYTYPE,P.GP_PAYEE_NAME, ")
        sb.Append("P.GP_PAIDDATE,P.GP_AMOUNT,P.GP_POLNO,R.TREF_VCH_NO_C ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        ' sb.Append("WHERE P.GP_PAIDDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ' sb.Append("AND P.GP_DATASOURCE_NME='" & dr("GP_DATASOURCE_NME").ToString & "' ")
        sb.Append("WHERE P.GP_DATASOURCE_NME ='" & datasourcename & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Dim reportname As String
        ' reportname = dr("GP_DATASOURCE_NME").ToString & Now.ToString("yyMMdd") & "001" & ".pdf"
        reportname = datasourcename & Now.ToString("yyMMdd") & "001" & ".pdf"

        Dim clsExportPDF As New clsCrystalToPDFConverter

        clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptInterfaceToOther.rpt") 'sReportPath ��� path �ͧ crystal report
        clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & reportname) 'ValidationReportPath ��� path �����ҧ report  

        Dim transfrom, transto As String
        Dim lstname As New ArrayList
        Dim lstvalue As New ArrayList

        transfrom = datefrom.Substring(6, 2) & "/" & datefrom.Substring(4, 2) & "/" & datefrom.Substring(0, 4)
        transto = dateto.Substring(6, 2) & "/" & dateto.Substring(4, 2) & "/" & dateto.Substring(0, 4)

        lstname.Add("pTransdate")
        lstname.Add("pFileName")

        lstvalue.Add(transfrom & " - " & transto)
        'lstvalue.Add(Now.ToString("yyMMdd") & "001")
        lstvalue.Add(datasourcefilename)

        clsExportPDF.ExportReport(dt, lstname, lstvalue)

        '    Next


        'End If


    End Sub

End Class