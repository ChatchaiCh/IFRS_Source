Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmAutoBatch_TLM
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim MsgLoader As String
    Dim dtJournalHold As DataTable
    Dim retJnHold As String
    Private Sub FrmAutoBatch_TLM_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                'Return exit code to batch
                Environment.ExitCode = 2

                Exit Sub
            End If
        End If
    End Sub
    Function TLM_GetInFileName(ByVal filepath As String, ByVal filetype As String) As ArrayList

        Dim lst As New ArrayList
        Dim filename As String = ""

        Dim di As New DirectoryInfo(filepath)
        Dim diar As FileInfo() = di.GetFiles(filetype & "*", SearchOption.AllDirectories)
        Dim dra As FileInfo
        For Each dra In diar
            '.Add(dra)
            '.Add(dra.FullName)
            'lst.Add(dra.ToString.Substring(dra.ToString.Length - 8, 4))
            lst.Add(dra)
        Next

        Return lst

    End Function
    Public Function TLM_ReadTextFile(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Try

            CurrentRow = TextFileReader.ReadFields()

            If Not CurrentRow Is Nothing Then
                If dtD Is Nothing Then
                    dtD = New DataTable("dtGP")

                    dtD.Columns.Add("H_DATE")
                    dtD.Columns.Add("H_TOT_AMT")


                End If

                Row = dtD.NewRow
                Row.Item(0) = CurrentRow(0).ToString.Trim
                Row.Item(1) = CurrentRow(1).ToString.Trim

                dtD.Rows.Add(Row)


            End If
        Catch ex As _
        Microsoft.VisualBasic.FileIO.MalformedLineException
            MsgBox("Line " & ex.Message & _
            "is not valid and will be skipped.")

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try

        TextFileReader.Dispose()

        Return dtD

    End Function
    Private Sub TLM_GenControlGP(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_PAYMENT_CREATION ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GPCR_CREATEDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GPCR_CORE_SYSTEM " & "constant ""TLM"",")
            '��� Running ����� sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(MAX, 1) ,")

            sw.WriteLine("GPCR_TRANSREF,")
            sw.WriteLine("GPCR_GPTREF_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("GPCR_POLNO,")
            sw.WriteLine("GPCR_BILLNO,")
            sw.WriteLine("GPCR_PAIDDATE ""SUBSTR(:GPCR_PAIDDATE,7,4)||SUBSTR(:GPCR_PAIDDATE,4,2)||SUBSTR(:GPCR_PAIDDATE,1,2)"",")
            sw.WriteLine("GPCR_AMOUNT,")
            sw.WriteLine("GPCR_DESC,")
            sw.WriteLine("GPCR_PAYMTH,")
            sw.WriteLine("GPCR_PAYEE_NAME,")
            sw.WriteLine("GPCR_BNKCODE_NO,")
            sw.WriteLine("GPCR_BNKBRN,")
            sw.WriteLine("GPCR_BNKNAME,")
            sw.WriteLine("GPCR_PAYEE_BNKACCNO,")
            sw.WriteLine("GPCR_PAYEE_BNKACCNME,")
            sw.WriteLine("GPCR_COMMENT,")
            sw.WriteLine("GPCR_ADDRESS1,")
            sw.WriteLine("GPCR_DISTRICT,")
            sw.WriteLine("GPCR_PROVINCE,")
            sw.WriteLine("GPCR_INSURENAME,")
            sw.WriteLine("GPCR_DATASOURCE_NME,")
            sw.WriteLine("GPCR_RESERVE6,")
            sw.WriteLine("GPCR_MERCHN_NO,")
            sw.WriteLine("GPCR_CDCARD_DATE,")
            sw.WriteLine("GPCR_RESERVE9,")
            sw.WriteLine("GPCR_RESERVE10,")
            sw.WriteLine("GPCR_SYS_REF,")
            sw.WriteLine("GPCR_SYS_GR,")
            'sw.WriteLine("GPCR_DTSOURCE ""SUBSTR(:GPCR_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub
    Private Sub TLM_GenControlGL(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_GL_CREATION ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GLCR_CREATEDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GLCR_CORE_SYSTEM " & "constant ""TLM"",")
            sw.WriteLine("GLCR_JN_TYPE,")
            sw.WriteLine("GLCR_JN_SOURCE,")
            sw.WriteLine("GLCR_B_UNIT,")
            sw.WriteLine("GLCR_GL_PERIOD,")
            sw.WriteLine("GLCR_TRANSREF,")
            sw.WriteLine("GLCR_LINENO,")
            sw.WriteLine("GLCR_TRANSDATE ""SUBSTR(:GLCR_TRANSDATE,7,4)||SUBSTR(:GLCR_TRANSDATE,4,2)||SUBSTR(:GLCR_TRANSDATE,1,2)"",")
            sw.WriteLine("GLCR_DUEDATE ""SUBSTR(:GLCR_DUEDATE,7,4)||SUBSTR(:GLCR_DUEDATE,4,2)||SUBSTR(:GLCR_DUEDATE,1,2)"",")
            sw.WriteLine("GLCR_DESC,")
            sw.WriteLine("GLCR_O_ACCOUNT,")
            sw.WriteLine("GLCR_AMOUNT,")
            sw.WriteLine("GLCR_DRCR,")
            sw.WriteLine("GLCR_O_DEP_BRN,")
            sw.WriteLine("GLCR_O_PL_PT,")
            sw.WriteLine("GLCR_O_MKT_EMP,")
            sw.WriteLine("GLCR_O_PROJECT,")
            sw.WriteLine("GLCR_PAYMTH,")
            sw.WriteLine("GLCR_PAYEE,")
            sw.WriteLine("GLCR_S_ACCOUNT,")
            sw.WriteLine("GLCR_S_ACCNAME,")
            sw.WriteLine("GLCR_S_DEP_BRN,")
            sw.WriteLine("GLCR_S_PL_PT,")
            sw.WriteLine("GLCR_S_MKT_EMP,")
            sw.WriteLine("GLCR_S_TT_TR,")
            sw.WriteLine("GLCR_S_PROJECT,")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub
    Function SqlLoader(ByVal control As String) As Boolean
        'Dim pw As String
        'pw = SPI_BATCH.Decrypt(strDatabasePassword)

        'Call Web Service
        Dim pw As String
        pw = "generatepayment"
        'Dim objService As New wsClsUtility.clsUtility
        'pw = objService.Decrypt(strDatabasePassword, "WhiteKnight").returnValue

        Dim proc As System.Diagnostics.Process = New System.Diagnostics.Process
        Dim myCommand As String = "sqlldr.EXE"
        proc.StartInfo = New ProcessStartInfo(myCommand)
        'Set up arguments for CMD.EXE
        'proc.StartInfo.Arguments = "pbill@ORASNAP/pbill CONTROL=D:\Support\Special_pay_in\inbound\control1.ctl"
        proc.StartInfo.Arguments = strUser & "@" & strDatabase & "/" & pw & " CONTROL='" & control & "'"
        proc.StartInfo.RedirectStandardInput = False
        proc.StartInfo.RedirectStandardOutput = False
        proc.StartInfo.RedirectStandardError = True
        proc.StartInfo.UseShellExecute = False
        proc.StartInfo.WorkingDirectory = ControlPath

        'Dim currentProcess As String = Process.GetCurrentProcess().ProcessName '="SPI_BATCH.vshost"
        'CheckIfRunning("odbcadm.exe")
        Try
            proc.Start()
            proc.WaitForExit(2000)
            If (proc.ExitCode = 0) Then
                'MsgBox("Successful Inserted")
                'Dim myStreamReader As IO.StreamReader = proc.StandardOutput()
                'MsgLoader = myStreamReader.ReadToEnd()
                MsgLoader = "Successful Inserted"
                Return True
            Else
                'MsgBox(proc.StandardError.ReadToEnd)
                Dim myStreamReader As IO.StreamReader = proc.StandardError()
                MsgLoader = myStreamReader.ReadToEnd()
                'MsgLoader = "Error in log file"
                If MsgLoader.Trim = "" Then
                    MsgLoader = "error in log file " & ControlPath & ".log"
                End If
                Return False
            End If
        Catch ex As Exception
            MsgLoader = ex.Message.ToString
            If MsgLoader.Trim = "" Then
                MsgLoader = "Exception Error"
            End If
            Return False
            'MsgBox(ex.Message)

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Function
    Private Sub TLM_BackupFile(ByVal org As String, ByVal dest As String)
        Try
            'Copy file to backup
            If System.IO.File.Exists(dest) Then
                My.Computer.FileSystem.DeleteFile(dest)
            End If
            My.Computer.FileSystem.CopyFile(org, dest, overwrite:=False)

            'Delete Original file 
            My.Computer.FileSystem.DeleteFile(org)
        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            'Delete Original file 
            'If controlName <> "" Then My.Computer.FileSystem.DeleteFile(controlName)
        End Try



    End Sub
    Private Sub TLM_DeleteOldData(ByVal systemdate As String)
        Dim oleTrans As OleDbTransaction
        Dim sbGP As New StringBuilder
        Dim sbGL As New StringBuilder
        Dim recGP, recGL As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        'Delete GPS_PAYMENT_CREATION
        sbGP.Append("DELETE FROM GPS_PAYMENT_CREATION   ")
        sbGP.Append("WHERE GPCR_CREATEDATE='" & systemdate & "' ")
        sbGP.Append("AND GPCR_CORE_SYSTEM='TLM'")

        recGP = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sbGP, oleTrans)

        'Delete GPS_GL_CREATION
        sbGL.Append("DELETE FROM GPS_GL_CREATION   ")
        sbGL.Append("WHERE GLCR_CREATEDATE='" & systemdate & "' ")
        sbGL.Append("AND GLCR_CORE_SYSTEM='TLM'")

        recGL = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sbGL, oleTrans)



        If recGP >= 0 And recGL >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Private Sub TLM_LoadGPFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = TLM_GetInFileName(GLInfilePath, "GENPAY")

        If arr.Count < 1 Then
            MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            controlfile = ControlPath & "GPCONTROL_TLM.ctl"
            infile = GLInfilePath & filename
            bkfile = GPBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = TLM_ReadTextFile(infile, "|")

            TLM_GenControlGP(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)
            chkLoader = SqlLoader(controlfile)

            ''�ó� Loader �ӧҹ�����
            If chkLoader Then
                'Backup file
                TLM_BackupFile(infile, bkfile)
            Else
                MsgBox(MsgLoader)
            End If

        Next

        'Update Bank code
        TLM_GP_UpdateBankCode(systemdate)

        'Update SubPayType
        TLM_GP_UpdateSubPayType(systemdate)

        'Update Flag_Track_Bill
        TLM_GP_UpdateFlagFlwBill(systemdate)

    End Sub
    Private Sub TLM_LoadGLFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = TLM_GetInFileName(GLInfilePath, "SUNACC")

        If arr.Count < 1 Then
            MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()

            controlfile = ControlPath & "GLCONTROL_TLM.ctl"
            infile = GLInfilePath & filename
            bkfile = GLBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = TLM_ReadTextFile(infile, "|")

            TLM_GenControlGL(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)
            chkLoader = SqlLoader(controlfile)

            ''�ó� Loader �ӧҹ�����
            If chkLoader Then
                TLM_BackupFile(infile, bkfile)
            Else
                MsgBox(MsgLoader)
            End If

        Next

        'Update Config Data
        TLM_GL_UpdateConfigData(systemdate)

        'Update Journal Hold
        TLM_GL_UpdateJournalHold(systemdate)

    End Sub
    Private Sub TLM_GP_UpdateBankCode(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION a  ")
        sb.Append("SET (GPCR_BNKCODE) = ( ")
        sb.Append("SELECT BKMST_BNKCODE ")
        sb.Append("FROM GPS_TL_BANKMASTER b  ")
        sb.Append("WHERE a.GPCR_BNKCODE_NO = b.BKMST_BNKCODE_NO AND b.BKMST_STATUS='ACTIVE') ")
        sb.Append("WHERE a.GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND a.GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdateSubPayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_SUB_PAYMTH= ")
        sb.Append("CASE WHEN (GPCR_PAYMTH='C') THEN 'C'  ")
        sb.Append("WHEN (GPCR_PAYMTH='D') THEN 'D' ")
        sb.Append("WHEN (GPCR_PAYMTH='M' AND UPPER(GPCR_RESERVE6) LIKE '%CREDIT CARD%') THEN 'C' ")
        sb.Append("WHEN (GPCR_PAYMTH='M') THEN 'M' ")
        sb.Append("ELSE '' END ")
        sb.Append("WHERE GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdateFlagFlwBill(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_FLWBILL=")
        sb.Append("CASE WHEN (UPPER(GPCR_DESC) LIKE '%PAYMENT OF MEDICAL INVOICE%') THEN 'Y' ELSE 'N' END ")
        sb.Append("WHERE GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GL_UpdateConfigData(ByVal LoadDate As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_GL_HEAD_SETUP ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim sb1 As New StringBuilder
            Dim rec As Integer

            oleTrans = clsUtility.gConnGP.BeginTransaction()
            sb1.Append("UPDATE GPS_GL_CREATION SET ")
            sb1.Append(" GLCR_GLSTS = '" & dt.Rows(0)("GLHS_GLSTS").ToString & "', ")
            sb1.Append(" GLCR_BOOKID = '" & dt.Rows(0)("GLHS_BOOKID").ToString & "' ,")
            sb1.Append(" GLCR_SOURCE_NME = '" & dt.Rows(0)("GLHS_SOURCE_NME").ToString & "', ")
            sb1.Append(" GLCR_CATEGORY_NME = '" & dt.Rows(0)("GLHS_CATEGORY_NME").ToString & "' ,")
            sb1.Append(" GLCR_CURRENCY_CDE = '" & dt.Rows(0)("GLHS_CURRENCY_CDE").ToString & "', ")
            sb1.Append(" GLCR_ACTUAL_FLAG = '" & dt.Rows(0)("GLHS_ACTUAL_FLAG").ToString & "' ,")
            sb1.Append(" GLCR_COMPANY_CDE = '" & dt.Rows(0)("GLHS_COMPANY_CDE").ToString & "', ")
            sb1.Append(" GLCR_RCCODE = '" & dt.Rows(0)("GLHS_RCCODE").ToString & "' ")
            sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
            sb1.Append("AND GLCR_CORE_SYSTEM='TLM'")


            rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)

            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                MsgBox(clsBusiness.gLastErrMessage)
            End If

        Else
            MsgBox("Can not load data GPS_GL_HEAD_SETUP")
        End If
    End Sub
    Private Sub TLM_GL_UpdateJournalHold(ByVal LoadDate As String)
        Dim dt As DataTable
        dt = TLM_JournalHoldToTemp(LoadDate)

        If dt.Rows.Count > 0 Then

            Dim rec As Integer
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim sb1 As New StringBuilder

                sb1.Append("UPDATE GPS_GL_CREATION SET ")
                sb1.Append("GLCR_JN_HOLD = '" & dr("JournalHold") & "' ")
                sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
                sb1.Append("AND GLCR_TRANSREF = '" & dr("Transref") & "' ")
                sb1.Append("AND GLCR_CORE_SYSTEM='TLM'")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)
            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                MsgBox(clsBusiness.gLastErrMessage)
            End If

        End If

    End Sub
    Private Sub TLM_UPDATE_INTERFACE_CONTROL_STATUS(ByVal status As String)

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO", status, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If
    End Sub
    Private Sub TLM_UPDATE_INTERFACE_CONTROL_NO()

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_NO(clsUtility.gConnGP, "JN_HO", oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Function TLM_GetJournalHold() As String
        Cursor = Cursors.WaitCursor
        retJnHold = ""
        Dim chk As Boolean
        Dim no As String
        chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO")

        If chk Then


            TLM_UPDATE_INTERFACE_CONTROL_STATUS("START")

            no = clsBusiness.GET_NO_INTERFACE_CONTROL(clsUtility.gConnGP, "JN_HO")

            TLM_UPDATE_INTERFACE_CONTROL_NO()

            TLM_UPDATE_INTERFACE_CONTROL_STATUS("STOP")

            Cursor = Cursors.Default
        Else
            no = ""
        End If

        'If no = "" Then
        '    GetJournalHold
        'End If

        Return no

    End Function
    Function TLM_JournalHoldToTemp(ByVal LoadDate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GLCR_TRANSREF FROM GPS_GL_CREATION   ")
        sb.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' AND GLCR_CORE_SYSTEM='TLM' ")
        sb.Append("GROUP BY GLCR_TRANSREF ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            If dtJournalHold Is Nothing Then
                dtJournalHold = New DataTable("TempJN")

                dtJournalHold.Columns.Add("Transref")
                dtJournalHold.Columns.Add("JournalHold")
            End If

            Dim Row As DataRow

            For Each dr As DataRow In dt.Rows
                'Dim jn_ho As String
                'jn_ho = GetJournalHold()

                retJnHold = ""
                Do While retJnHold = ""
                    retJnHold = TLM_GetJournalHold()
                Loop


                Row = dtJournalHold.NewRow

                Row.Item(0) = dr("GLCR_TRANSREF").ToString
                Row.Item(1) = retJnHold 'jn_ho

                dtJournalHold.Rows.Add(Row)

            Next

        End If

        Return dtJournalHold
    End Function
    Private Sub TLM_INS_GPS_TRANSREF_REL(ByVal systemdate As String)
        Dim dt As DataTable
        dt = TLM_PrepareData(systemdate)

        If dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim rec As Integer
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb As New StringBuilder

                sb.Append("INSERT INTO GPS_TRANSREF_REL ( ")
                sb.Append("TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_TRANSREF,")
                sb.Append("TREF_JN_TYPE,TREF_GL_PERIOD,TREF_PAYCRETYP_ID,")
                sb.Append("TREF_PAIDDATE,TREF_PAYMTH,TREF_SUB_PAYMTH,")
                sb.Append("TREF_DTSOURCE,TREF_DEP_KEYIN,TREF_DEP_REPAY,")
                sb.Append("TREF_JN_HOLD,CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE)")
                sb.Append("VALUES (")
                sb.Append("'" & systemdate & "',")
                sb.Append("'TLM',")
                sb.Append("'" & dr.Item("GPCR_TRANSREF").ToString & "',")
                sb.Append("'" & dr.Item("GLCR_JN_TYPE").ToString & "',")
                sb.Append("'" & dr.Item("GLCR_GL_PERIOD").ToString & "',")
                sb.Append("'005',")
                sb.Append("'" & dr.Item("GPCR_PAIDDATE").ToString & "',")
                sb.Append("'" & dr.Item("GPCR_PAYMTH").ToString & "',")
                sb.Append("'" & dr.Item("GPCR_SUB_PAYMTH").ToString & "',")
                sb.Append("'TLM',")
                sb.Append("'TLM',")
                sb.Append("'TLM',")
                sb.Append("'" & dr.Item("GLCR_JN_HOLD").ToString & "',")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                MsgBox(clsBusiness.gLastErrMessage)
            End If


        End If
    End Sub
    Function TLM_PrepareData(ByVal systemdate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GP.GPCR_TRANSREF, GP.GPCR_PAIDDATE, GP.GPCR_PAYMTH, GP.GPCR_SUB_PAYMTH, ")
        sb.Append("GL.GLCR_JN_TYPE,GL.GLCR_GL_PERIOD, GL.GLCR_JN_HOLD   ")
        sb.Append("FROM GPS_PAYMENT_CREATION GP LEFT JOIN GPS_GL_CREATION GL  ")
        sb.Append("ON GP.GPCR_CREATEDATE= GL.GLCR_CREATEDATE  ")
        sb.Append("AND GP.GPCR_CORE_SYSTEM=GL.GLCR_CORE_SYSTEM  ")
        sb.Append("AND GP.GPCR_TRANSREF=GL.GLCR_TRANSREF   ")
        sb.Append("WHERE GP.GPCR_CREATEDATE='" & systemdate & "' AND GP.GPCR_CORE_SYSTEM='TLM'  ")
        sb.Append("GROUP BY GP.GPCR_TRANSREF, GP.GPCR_PAIDDATE, GP.GPCR_PAYMTH,GP.GPCR_SUB_PAYMTH,  ")
        sb.Append("GL.GLCR_JN_TYPE, GL.GLCR_GL_PERIOD, GL.GLCR_JN_HOLD  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Private Sub btnLoader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoader.Click
        Dim systemdate As String = Date.Now.ToString("yyyyMMdd")

        TLM_DeleteOldData(systemdate)

        TLM_LoadGPFile(systemdate)

        TLM_LoadGLFile(systemdate)

        TLM_INS_GPS_TRANSREF_REL(systemdate)

    End Sub
End Class
