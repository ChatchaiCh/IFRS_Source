Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration

Module ModDefine

    Public strUser As String = ConfigurationManager.AppSettings("UserID_Loader").ToString
    Public strDatabasePassword As String = ConfigurationManager.AppSettings("Password_Loader").ToString
    Public strDatabase As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToString
    'Public sReportPath As String = Application.StartupPath.Substring(0, Application.StartupPath.Length - 9) & ConfigurationManager.AppSettings("REPORT_PATH").ToString
    'Public sReportPath As String = System.AppDomain.CurrentDomain.BaseDirectory().Replace("\bin\Debug\", ConfigurationManager.AppSettings("REPORT_PATH").ToString)
    Public sReportPath As String = System.AppDomain.CurrentDomain.BaseDirectory() & ConfigurationManager.AppSettings("REPORT_PATH").ToString
    Public ValidationReportPath As String = ConfigurationManager.AppSettings("VALIDATION_REPORT_PATH").ToString
    Public gServerReport As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToString
    Public gSystemMode As String = ConfigurationManager.AppSettings("SYSTEMMODE").ToString
    'Public ControlPath As String = Application.StartupPath.Substring(0, Application.StartupPath.Length - 9) & ConfigurationManager.AppSettings("LOADER_PATH").ToString
    'Public ControlPath As String = System.AppDomain.CurrentDomain.BaseDirectory().Replace("\bin\Debug\", ConfigurationManager.AppSettings("LOADER_PATH").ToString)
    Public ControlPath As String = System.AppDomain.CurrentDomain.BaseDirectory() & ConfigurationManager.AppSettings("LOADER_PATH").ToString

    Public GPInfilePath As String = ConfigurationManager.AppSettings("GP_INFILE_PATH").ToString
    Public GLInfilePath As String = ConfigurationManager.AppSettings("GL_INFILE_PATH").ToString
    Public GPBackupPath As String = ConfigurationManager.AppSettings("GP_BACKUP_PATH").ToString
    Public GLBackupPath As String = ConfigurationManager.AppSettings("GL_BACKUP_PATH").ToString
    Public gUserFullName As String = Environment.UserName.ToString
End Module
