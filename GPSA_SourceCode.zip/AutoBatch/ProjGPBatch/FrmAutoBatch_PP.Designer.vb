<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAutoBatch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLoader = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnLoader
        '
        Me.btnLoader.Location = New System.Drawing.Point(195, 39)
        Me.btnLoader.Name = "btnLoader"
        Me.btnLoader.Size = New System.Drawing.Size(122, 23)
        Me.btnLoader.TabIndex = 0
        Me.btnLoader.Text = "SQL Loader"
        Me.btnLoader.UseVisualStyleBackColor = True
        '
        'FrmAutoBatch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 114)
        Me.Controls.Add(Me.btnLoader)
        Me.Name = "FrmAutoBatch"
        Me.Text = "Auto Batch & Validate(Pick Pack)"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnLoader As System.Windows.Forms.Button

End Class
