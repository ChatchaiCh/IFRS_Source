Imports System.IO
Imports System.Text
Imports System.Net.Mail
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary

Public Class FrmBatch
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsValidate
    Dim MsgLoader As String
    Dim dtJournalHold As DataTable
    Dim retJnHold As String
    Private Sub FrmBatch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        strDatabasePassword = clsUtility.gP
        'Console.WriteLine(strDatabasePassword)
        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(), 8)

        'GenValidationReport(systemdate)

        Dim s_systemtime As String
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)

        '-- ONE GL --
        Dim sDateYYYMMDD As String() = Environment.GetCommandLineArgs()
        If sDateYYYMMDD.Length > 1 Then
            systemdate = sDateYYYMMDD(1)
        End If
        '-- ONE GL --

        Try

            If CheckRunBatch(systemdate) Then

                DeleteDirectory(ControlPath)
                RunBatch(systemdate)

            End If

            Me.Close()

        Catch ex As Exception
            'MsgBox(ex.ToString)
            Console.WriteLine("LOAD: " & ex.ToString.Substring(0, 255))
            clsBusiness.gLastErrMessage = ex.ToString.Substring(0, 255)
            InsertTransLog("AUTO BATCH", Now.ToString("yyyyMMdd"), "", s_systemtime, "INCOMPLETE", 0)
            ' Me.Close()

            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            'Me.Close()
        End Try


        '--------------Test----------------

    End Sub
    Public Function GetWorkDay(ByVal CurrentDate As DateTime) As Boolean

        Select Case CurrentDate.DayOfWeek
            Case DayOfWeek.Saturday
                Return False
            Case DayOfWeek.Sunday
                Return False
            Case Else
                'handles sunday through thursday
                Return True
        End Select

    End Function
    Function CheckRunBatch(ByVal systemdate As String) As Boolean
        Dim ret As Boolean = False
        Dim workday As Boolean
        Dim sdate As DateTime
        Dim format As String = "yyyyMMdd"

        sdate = Date.ParseExact(systemdate, Format, New Globalization.CultureInfo("en-US"))

        workday = GetWorkDay(sdate)

        If workday Then
            Dim chk_holiday As Boolean
            chk_holiday = cls.LookUpHoliday_SCBLIFE(clsUtility.gConnGP, systemdate)

            If chk_holiday Then
                ret = False
            Else
                ret = True
            End If

        Else
            ret = False
        End If

        Return ret

    End Function
    Function SqlLoader(ByVal control As String, ByVal systemdate As String, ByVal filename As String) As Boolean
        Dim batchname As String
        batchname = control.Replace(".txt.ctl", ".bat")

        Dim logname As String

        logname = control.Replace(".txt.ctl", ".log")
        Dim txt As String
        txt = "SQLLDR USERID=""" & strUser & "/" & strDatabasePassword & "@" & strDatabase & """ CONTROL='" & control & "' LOG='" & logname & "'"

        GenBatch(batchname, txt)

        Dim proc As System.Diagnostics.Process = New System.Diagnostics.Process()
        proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        proc.EnableRaisingEvents = False
        proc.StartInfo.FileName = batchname
        proc.Start()
        proc.WaitForExit()
        proc.Close()


    End Function
    Function SqlLoader_Old(ByVal control As String, ByVal systemdate As String, ByVal filename As String) As Boolean
        'Dim pw As String
        'pw = SPI_BATCH.Decrypt(strDatabasePassword)

        'Call Web Service
        'Dim pw As String
        'pw = "generatepayment"
        'Dim objService As New wsClsUtility.clsUtility
        'pw = objService.Decrypt(strDatabasePassword, "WhiteKnight").returnValue

        Dim s_systemtime As String
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
        Dim logname As String

        logname = control.Replace(".txt.ctl", ".log")

        Dim proc As System.Diagnostics.Process = New System.Diagnostics.Process
        Dim myCommand As String = "sqlldr.EXE"
        proc.StartInfo = New ProcessStartInfo(myCommand)
        'Set up arguments for CMD.EXE
        'proc.StartInfo.Arguments = "pbill@ORASNAP/pbill CONTROL=D:\Support\Special_pay_in\inbound\control1.ctl"
        'proc.StartInfo.Arguments = strUser & "@" & strDatabase & "/" & strDatabasePassword & " CONTROL='" & control & "'"
        proc.StartInfo.Arguments = strUser & "@" & strDatabase & "/" & strDatabasePassword & " CONTROL='" & control & "' LOG='" & logname & "'"
        proc.StartInfo.RedirectStandardInput = False
        proc.StartInfo.RedirectStandardOutput = False
        proc.StartInfo.RedirectStandardError = True
        proc.StartInfo.UseShellExecute = False
        proc.StartInfo.WorkingDirectory = ControlPath

        'Dim currentProcess As String = Process.GetCurrentProcess().ProcessName '="SPI_BATCH.vshost"
        'CheckIfRunning("odbcadm.exe")
        Try

            proc.Start()
            proc.WaitForExit()
            If (proc.ExitCode = 0) Then
                'MsgBox("Successful Inserted")
                'Dim myStreamReader As IO.StreamReader = proc.StandardOutput()
                'MsgLoader = myStreamReader.ReadToEnd()
                MsgLoader = "Complete"
                Return True
            Else
                'MsgBox(proc.StandardError.ReadToEnd)
                Dim myStreamReader As IO.StreamReader = proc.StandardError()
                clsBusiness.gLastErrMessage = myStreamReader.ReadToEnd()
                MsgLoader = "InComplete"

                'If MsgLoader.Trim = "" Then
                '    MsgLoader = "error in log file " & ControlPath & ".log"
                'End If

                InsertTransLog("SQL LOADER", systemdate, "", s_systemtime, "INCOMPLETE", 0)
                Return False
            End If
        Catch ex As Exception
            MsgLoader = ex.Message.ToString
            If MsgLoader.Trim = "" Then
                MsgLoader = "Exception Error"
            End If
            clsBusiness.gLastErrMessage = "Exception Error " & filename
            InsertTransLog("SQL LOADER", systemdate, "", s_systemtime, "INCOMPLETE", 0)
            Return False
            'MsgBox(ex.Message)

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
        proc.Close()
    End Function
    Private Sub BackupFile(ByVal org As String, ByVal dest As String, ByVal systemdate As String)
        Dim s_systemtime As String
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)

        Try
            'Copy file to backup
            If System.IO.File.Exists(dest) Then
                My.Computer.FileSystem.DeleteFile(dest)
                Console.WriteLine("DeleteFile(dest): " & dest & " completed")
            End If
            System.IO.File.Move(org, dest)
            Console.WriteLine("Move(org, dest): " & org & " to " & dest & " completed")

            'My.Computer.FileSystem.CopyFile(org, dest, overwrite:=True)

            ''Delete Original file 
            'My.Computer.FileSystem.DeleteFile(org)
        Catch ex As Exception
            Console.WriteLine("error: " & ex.ToString)
            clsBusiness.gLastErrMessage = org & ":" & ex.ToString
            InsertTransLog("BACKUP FILE", systemdate, "", s_systemtime, "INCOMPLETE", 0)

            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            'Delete Original file 
            'If controlName <> "" Then My.Computer.FileSystem.DeleteFile(controlName)
        End Try

    End Sub
    Private Sub DeleteDirectory(ByVal path As String)

        If Directory.Exists(path) Then

            'Delete all files from the Directory

            For Each filepath As String In Directory.GetFiles(path)

                File.Delete(filepath)

            Next

            'Delete all child Directories

            For Each dir As String In Directory.GetDirectories(path)

                DeleteDirectory(dir)

            Next

            ''Delete a Directory

            'Directory.Delete(path)

        End If

    End Sub
    Function GetInFileName(ByVal filepath As String, ByVal filetype As String) As ArrayList

        Dim lst As New ArrayList
        Dim filename As String = ""

        Dim di As New DirectoryInfo(filepath)
        Dim diar As FileInfo() = di.GetFiles(filetype & "*", SearchOption.AllDirectories)
        Dim dra As FileInfo
        Console.WriteLine("GetInFileName: ")
        For Each dra In diar
            '.Add(dra)
            '.Add(dra.FullName)
            'lst.Add(dra.ToString.Substring(dra.ToString.Length - 8, 4))
            lst.Add(dra)
            Console.WriteLine(" -" & dra.FullName & " " & dra.Name)
        Next

        Return lst

    End Function
    Function fnDelete(ByVal oleTrans As OleDbTransaction, ByVal str As String) As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        sb.Append(str)

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Function DeleteOldData(ByVal systemdate As String) As Boolean
        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15 As Boolean

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        d1 = fnDelete(oleTrans, "delete from gps_payment_load where gpld_batchdate='" & systemdate & "' ")

        d2 = fnDelete(oleTrans, "delete from gps_wht_load where taxld_batchdate='" & systemdate & "' ")

        d3 = fnDelete(oleTrans, "delete from gps_gl_load where glld_batchdate='" & systemdate & "' ")

        d4 = fnDelete(oleTrans, "delete from gps_payment_creation where gpcr_createdate='" & systemdate & "' and (gpcr_core_system='TLM' or gpcr_core_system='PP' or gpcr_core_system='ACC') ")

        d5 = fnDelete(oleTrans, "delete from gps_gl_creation where glcr_createdate='" & systemdate & "' and (glcr_core_system='TLM' or glcr_core_system='PP' or glcr_core_system='ACC') ")

        d15 = fnDelete(oleTrans, "delete from gps_wht_creation where taxcr_createdate='" & systemdate & "' and (taxcr_core_system='TLM' or taxcr_core_system='PP' or taxcr_core_system='ACC') ")

        d6 = fnDelete(oleTrans, "delete from gps_transref_rel where tref_createdate='" & systemdate & "' and (tref_core_system='TLM' or tref_core_system='PP' or tref_core_system='ACC') ")

        d7 = fnDelete(oleTrans, "delete from gps_tmp_payment ")

        d8 = fnDelete(oleTrans, "delete from gps_tmp_wht ")

        d9 = fnDelete(oleTrans, "delete from gps_payment_complete where gpcm_batchdate='" & systemdate & "' and gpcm_batchtype='A' ")

        d10 = fnDelete(oleTrans, "delete from gps_wht_complete where taxcm_batchdate='" & systemdate & "' and taxcm_batchtype='A' ")

        d11 = fnDelete(oleTrans, "delete from gps_payment_rej where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A' and (gprj_reject_type is null OR gprj_reject_type<>'BANK') ")

        d12 = fnDelete(oleTrans, "delete from gps_wht_rej where taxrj_batchdate='" & systemdate & "' and taxrj_batchtype='A' and (taxrj_reject_type is null OR taxrj_reject_type<>'BANK') ")

        d13 = fnDelete(oleTrans, "delete from glm_gl_daily where gl_posting_date='" & systemdate & "' and gl_system_name='GPSA' ")

        d14 = fnDelete(oleTrans, "delete from gps_aml where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A'  ")

        If (d1 And d2 And d3 And d4 And d5 And d6 And d7 And d8 And d9 And d10 And d11 And d12 And d13 And d14 And d15) Then
            oleTrans.Commit()
            Return True
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
            Return False
        End If

    End Function
    Function InsertToTempPayment_PP(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer
        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("INSERT INTO GPS_TMP_PAYMENT( ")
        sb.Append("GP_BATCHDATE,")
        sb.Append("GP_BATCH_NO,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_DESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_FLAG_VALIDATE,")
        sb.Append("GP_REJECT_TYPE,")
        sb.Append("GP_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT '" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("GPLD_BATCHDATE, ")
        sb.Append("GPLD_CORE_SYSTEM, ")
        sb.Append("GPLD_TRANSREF, ")
        sb.Append("GPLD_GPTREF_SEQNO, ")
        sb.Append("GPLD_POLNO, ")
        sb.Append("GPLD_BILLNO, ")
        sb.Append("GPLD_PAIDDATE, ")
        sb.Append("GPLD_AMOUNT, ")
        sb.Append("GPLD_DESC, ")
        sb.Append("GPLD_PAYMTH, ")
        sb.Append("GPLD_PAYEE_NAME, ")
        sb.Append("(SELECT BKMST_BNKCODE FROM GPS_TL_BANKMASTER WHERE BKMST_BNKCODE_NO=GPLD_BNKCODE_NO AND BKMST_STATUS='ACTIVE'), ")
        sb.Append("GPLD_BNKCODE_NO, ")
        sb.Append("GPLD_BNKBRN, ")
        sb.Append("GPLD_BNKNAME, ")
        sb.Append("GPLD_PAYEE_BNKACCNO, ")
        sb.Append("GPLD_PAYEE_BNKACCNME, ")
        sb.Append("GPLD_COMMENT, ")
        sb.Append("GPLD_ADDRESS1, ")
        sb.Append("GPLD_DISTRICT, ")
        sb.Append("GPLD_PROVINCE, ")
        sb.Append("GPLD_INSURENAME, ")
        sb.Append("GPLD_DATASOURCE_NME, ")
        sb.Append("GPLD_Reserve6, ")
        sb.Append("GPLD_MERCHN_NO, ")
        sb.Append("GPLD_CDCARD_DATE, ")
        sb.Append("GPLD_Reserve9, ")
        sb.Append("GPLD_Reserve10, ")
        sb.Append("GPLD_SYS_REF, ")
        sb.Append("GPLD_SYS_GR, ")
        sb.Append("GPLD_SUB_PAYMTH, ")
        sb.Append("GPLD_FLAG_FLWBILL, ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'', ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("from gps_payment_load where gpld_batchdate='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            'oleTrans.Commit()
            'MsgBox("Update already")
            Return True
        Else
            'oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
            Return False
        End If

    End Function
    Function InsertToTempPayment_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_PAYMENT ( ")
        sb.Append("GP_BATCHDATE,")
        sb.Append("GP_BATCH_NO,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_DESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_FLAG_VALIDATE,")
        sb.Append("GP_REJECT_TYPE,")
        sb.Append("GP_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE, ")
        sb.Append("GP_FLAG_CC,")
        sb.Append("GP_CC_APPROVEDBY) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("GPCR_CREATEDATE, ")
        sb.Append("GPCR_CORE_SYSTEM, ")
        sb.Append("GPCR_TRANSREF, ")
        sb.Append("GPCR_GPTREF_SEQNO, ")
        sb.Append("GPCR_POLNO, ")
        sb.Append("GPCR_BILLNO, ")
        sb.Append("GPCR_PAIDDATE, ")
        sb.Append("GPCR_AMOUNT, ")
        sb.Append("GPCR_DESC, ")
        sb.Append("GPCR_PAYMTH, ")
        sb.Append("GPCR_PAYEE_NAME, ")
        sb.Append("GPCR_BNKCODE, ")
        sb.Append("GPCR_BNKCODE_NO, ")
        sb.Append("GPCR_BNKBRN, ")
        sb.Append("GPCR_BNKNAME, ")
        sb.Append("GPCR_PAYEE_BNKACCNO, ")
        sb.Append("GPCR_PAYEE_BNKACCNME, ")
        sb.Append("GPCR_COMMENT, ")
        sb.Append("GPCR_ADDRESS1, ")
        sb.Append("GPCR_DISTRICT, ")
        sb.Append("GPCR_PROVINCE, ")
        sb.Append("GPCR_INSURENAME, ")
        sb.Append("GPCR_DATASOURCE_NME, ")
        sb.Append("GPCR_Reserve6, ")
        sb.Append("GPCR_MERCHN_NO, ")
        sb.Append("GPCR_CDCARD_DATE, ")
        sb.Append("GPCR_Reserve9, ")
        sb.Append("GPCR_Reserve10, ")
        sb.Append("GPCR_SYS_REF, ")
        sb.Append("GPCR_SYS_GR, ")
        sb.Append("GPCR_SUB_PAYMTH, ")
        sb.Append("GPCR_FLAG_FLWBILL, ")
        sb.Append("GPCR_OSEA_LIST, ")
        sb.Append("GPCR_PHONE, ")
        sb.Append("GPCR_FAX, ")
        sb.Append("GPCR_SWIFT_CODE, ")
        sb.Append("GPCR_BNKBRN_NAME, ")
        sb.Append("GPCR_BNKADDR, ")
        sb.Append("GPCR_COUNTRY, ")
        sb.Append("GPCR_CURRENCY, ")
        sb.Append("GPCR_EXCHN_RATE, ")
        sb.Append("GPCR_BNKCHARGES, ")

        '-- sb.Append("'COMPLETE', ")
        sb.Append("GPCR_FLAG_VALIDATE, ")
        '-- sb.Append("'', ")
        sb.Append("GPCR_REJECT_TYPE, ")

        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'), ")
        sb.Append("GPCR_fLAG_CC, ")
        sb.Append("GPCR_CC_APPROVEDBY ")
        sb.Append("FROM GPS_PAYMENT_CREATION  ")
        '-- sb.Append("       INNER JOIN GPS_TRANSREF_REL  ")
        '-- sb.Append("         ON GPS_PAYMENT_CREATION.GPCR_CREATEDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        '-- sb.Append("        AND GPS_PAYMENT_CREATION.GPCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        '-- sb.Append("        AND GPS_PAYMENT_CREATION.GPCR_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" WHERE GPCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("   AND GPCR_FLAG_BATCH='N' AND GPCR_APPROVEDDATE < '" & systemdate & "' ")
        '-- sb.Append("   AND GPS_TRANSREF_REL.TREF_PAYCRETYP_ID NOT IN ( '003', '006' ) ")
        sb.Append("   AND GPCR_FLAG_VALIDATE = 'COMPLETE' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertToTempWHT_PP(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXLD_BATCHDATE, ")
        sb.Append("TAXLD_CORE_SYSTEM, ")
        sb.Append("TAXLD_TRANSREF, ")
        sb.Append("TAXLD_GPTREF_SEQNO, ")
        sb.Append("TAXLD_LINENO, ")
        sb.Append("TAXLD_TAXID, ")
        sb.Append("TAXLD_IDCARD, ")
        sb.Append("TAXLD_AP_TTL, ")
        sb.Append("TAXLD_AP_FNAME, ")
        sb.Append("TAXLD_AP_LNAME, ")
        sb.Append("TAXLD_ADDRESS, ")
        sb.Append("TAXLD_AMPENM, ")
        sb.Append("TAXLD_PROVNM, ")
        sb.Append("TAXLD_AGZIP, ")
        sb.Append("TAXLD_TAXTYPE, ")
        sb.Append("TAXLD_TAXITEM, ")
        sb.Append("TAXLD_TAXDATE, ")
        sb.Append("TAXLD_BASE_AMT, ")
        sb.Append("TAXLD_TAX_AMT, ")
        sb.Append("TAXLD_PAYEE, ")
        sb.Append("TAXLD_TAX_RATE, ")
        sb.Append("TAXLD_DESC, ")
        sb.Append("TAXLD_GL_ACCOUNT, ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_WHT_LOAD WHERE TAXLD_BATCHDATE='" & systemdate & "'")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertToTempWHT_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXCR_CREATEDATE, ")
        sb.Append("TAXCR_CORE_SYSTEM, ")
        sb.Append("TAXCR_TRANSREF, ")
        sb.Append("TAXCR_GPTREF_SEQNO, ")
        sb.Append("TAXCR_LINENO, ")
        sb.Append("TAXCR_TAXID, ")
        sb.Append("TAXCR_IDCARD, ")
        sb.Append("TAXCR_AP_TTL, ")
        sb.Append("TAXCR_AP_FNAME, ")
        sb.Append("TAXCR_AP_LNAME, ")
        sb.Append("TAXCR_ADDRESS, ")
        sb.Append("TAXCR_AMPENM, ")
        sb.Append("TAXCR_PROVNM, ")
        sb.Append("TAXCR_AGZIP, ")
        sb.Append("TAXCR_TAXTYPE, ")
        sb.Append("TAXCR_TAXITEM, ")
        sb.Append("TAXCR_TAXDATE, ")
        sb.Append("TAXCR_BASE_AMT, ")
        sb.Append("TAXCR_TAX_AMT, ")
        sb.Append("TAXCR_PAYEE, ")
        sb.Append("TAXCR_TAX_RATE, ")
        sb.Append("TAXCR_DESC, ")
        sb.Append("TAXCR_GL_ACCOUNT, ")

        '-- sb.Append("'COMPLETE', ")
        sb.Append("TAXCR_FLAG_VALIDATE, ")

        sb.Append("TAXCR_REJECT_TYPE, ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append(" FROM GPS_WHT_CREATION ")
        '-- sb.Append("       INNER JOIN GPS_TRANSREF_REL  ")
        '-- sb.Append("         ON GPS_WHT_CREATION.TAXCR_CREATEDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        '-- sb.Append("        AND GPS_WHT_CREATION.TAXCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        '-- sb.Append("        AND GPS_WHT_CREATION.TAXCR_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" WHERE TAXCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("   AND TAXCR_FLAG_BATCH='N' AND TAXCR_APPROVEDDATE < '" & systemdate & "' ")
        '-- sb.Append("   AND GPS_TRANSREF_REL.TREF_PAYCRETYP_ID NOT IN ( '003', '006' ) ")
        sb.Append("   AND TAXCR_FLAG_VALIDATE = 'COMPLETE' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertPaymentComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_COMPLETE( ")
        sb.Append("GPCM_BATCHDATE,")
        sb.Append("GPCM_BATCH_NO,")
        sb.Append("GPCM_CREATEDATE,")
        sb.Append("GPCM_CORE_SYSTEM,")
        sb.Append("GPCM_TRANSREF,")
        sb.Append("GPCM_GPTREF_SEQNO,")
        sb.Append("GPCM_POLNO,")
        sb.Append("GPCM_BILLNO,")
        sb.Append("GPCM_PAIDDATE,")
        sb.Append("GPCM_AMOUNT,")
        sb.Append("GPCM_DESC,")
        sb.Append("GPCM_PAYMTH,")
        sb.Append("GPCM_PAYEE_NAME,")
        sb.Append("GPCM_BNKCODE,")
        sb.Append("GPCM_BNKCODE_NO,")
        sb.Append("GPCM_BNKBRN,")
        sb.Append("GPCM_BNKNAME,")
        sb.Append("GPCM_PAYEE_BNKACCNO,")
        sb.Append("GPCM_PAYEE_BNKACCNME,")
        sb.Append("GPCM_COMMENT,")
        sb.Append("GPCM_ADDRESS1,")
        sb.Append("GPCM_DISTRICT,")
        sb.Append("GPCM_PROVINCE,")
        sb.Append("GPCM_INSURENAME,")
        sb.Append("GPCM_DATASOURCE_NME,")
        sb.Append("GPCM_RESERVE6,")
        sb.Append("GPCM_MERCHN_NO,")
        sb.Append("GPCM_CDCARD_DATE,")
        sb.Append("GPCM_RESERVE9,")
        sb.Append("GPCM_RESERVE10,")
        sb.Append("GPCM_SYS_REF,")
        sb.Append("GPCM_SYS_GR,")
        sb.Append("GPCM_SUB_PAYMTH,")
        sb.Append("GPCM_FLAG_FLWBILL,")
        sb.Append("GPCM_OSEA_LIST,")
        sb.Append("GPCM_PHONE,")
        sb.Append("GPCM_FAX,")
        sb.Append("GPCM_SWIFT_CODE,")
        sb.Append("GPCM_BNKBRN_NAME,")
        sb.Append("GPCM_BNKADDR,")
        sb.Append("GPCM_COUNTRY,")
        sb.Append("GPCM_CURRENCY,")
        sb.Append("GPCM_EXCHN_RATE,")
        sb.Append("GPCM_BNKCHARGES,")
        sb.Append("GPCM_BATCHTYPE,")
        sb.Append("GPCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_COMPLETE( ")
        sb.Append("TAXCM_BATCHDATE,")
        sb.Append("TAXCM_BATCH_NO,")
        sb.Append("TAXCM_CREATEDATE,")
        sb.Append("TAXCM_CORE_SYSTEM,")
        sb.Append("TAXCM_TRANSREF,")
        sb.Append("TAXCM_GPTREF_SEQNO,")
        sb.Append("TAXCM_LINENO,")
        sb.Append("TAXCM_TAXID,")
        sb.Append("TAXCM_IDCARD,")
        sb.Append("TAXCM_AP_TTL,")
        sb.Append("TAXCM_AP_FNAME,")
        sb.Append("TAXCM_AP_LNAME,")
        sb.Append("TAXCM_ADDRESS,")
        sb.Append("TAXCM_AMPENM,")
        sb.Append("TAXCM_PROVNM,")
        sb.Append("TAXCM_AGZIP,")
        sb.Append("TAXCM_TAXTYPE,")
        sb.Append("TAXCM_TAXITEM,")
        sb.Append("TAXCM_TAXDATE,")
        sb.Append("TAXCM_BASE_AMT,")
        sb.Append("TAXCM_TAX_AMT,")
        sb.Append("TAXCM_PAYEE,")
        sb.Append("TAXCM_TAX_RATE,")
        sb.Append("TAXCM_DESC,")
        sb.Append("TAXCM_GL_ACCOUNT,")
        sb.Append("TAXCM_BATCHTYPE,")
        sb.Append("TAXCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='COMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertPaymentReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_REJ( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE, ")
        sb.Append("GP_WLSTT_SUBTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_REJ ( ")
        sb.Append("TAXRJ_BATCHDATE,")
        sb.Append("TAXRJ_BATCH_NO,")
        sb.Append("TAXRJ_CREATEDATE,")
        sb.Append("TAXRJ_CORE_SYSTEM,")
        sb.Append("TAXRJ_TRANSREF,")
        sb.Append("TAXRJ_GPTREF_SEQNO,")
        sb.Append("TAXRJ_LINENO,")
        sb.Append("TAXRJ_TAXID,")
        sb.Append("TAXRJ_IDCARD,")
        sb.Append("TAXRJ_AP_TTL,")
        sb.Append("TAXRJ_AP_FNAME,")
        sb.Append("TAXRJ_AP_LNAME,")
        sb.Append("TAXRJ_ADDRESS,")
        sb.Append("TAXRJ_AMPENM,")
        sb.Append("TAXRJ_PROVNM,")
        sb.Append("TAXRJ_AGZIP,")
        sb.Append("TAXRJ_TAXTYPE,")
        sb.Append("TAXRJ_TAXITEM,")
        sb.Append("TAXRJ_TAXDATE,")
        sb.Append("TAXRJ_BASE_AMT,")
        sb.Append("TAXRJ_TAX_AMT,")
        sb.Append("TAXRJ_PAYEE,")
        sb.Append("TAXRJ_TAX_RATE,")
        sb.Append("TAXRJ_DESC,")
        sb.Append("TAXRJ_GL_ACCOUNT,")
        sb.Append("TAXRJ_REJECT_TYPE,")
        sb.Append("TAXRJ_REJECT_FUNC,")
        sb.Append("TAXRJ_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='INCOMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertAML(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_AML( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE ,")
        sb.Append("GP_WLSTT_SUBTYPE ,")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_WLSTT_TYPE='AML' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            oleTrans.Commit()
        Else
            Return False
            oleTrans.Rollback()
        End If

    End Function
    Private Sub RunTLM(ByVal systemdate As String)

        TLM_LoadGPFile(systemdate)
        TLM_LoadGLFile(systemdate)

        TLM_INS_GPS_TRANSREF_REL(systemdate)
    End Sub
    Private Sub RunPP(ByVal systemdate As String)

        Console.WriteLine("--PP_LoadGPFile--")
        PP_LoadGPFile(systemdate)
        Console.WriteLine("--PP_LoadGLFile--")
        PP_LoadGLFile(systemdate)
        Console.WriteLine("--PP_LoadWHTFile--")
        PP_LoadWHTFile(systemdate)

        PP_INS_GPS_TRANSREF_REL(systemdate)

        '-- ���ͧ�ҡ���� RunTF ��ͧ������ѹ�͡ sub 
        '-- CallGL(systemdate, "SYSTEM")
    End Sub
    Private Sub RunTF(ByVal systemdate As String)

        TF_LoadGPFile(systemdate)
        TF_LoadGLFile(systemdate)
        TF_LoadWHTFile(systemdate)

        TF_INS_GPS_TRANSREF_REL(systemdate)
        '-- CallGL(systemdate, "SYSTEM")
    End Sub
    Function InsertDataToTemp(ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim insPaymentTLM, insWHTTLM, insPaymentPP, insWHTPP As Boolean

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()
        Console.WriteLine("2.1")
        insPaymentTLM = InsertToTempPayment_TLM(oleTrans, systemdate, batchno)
        Console.WriteLine("2.2")
        insWHTTLM = InsertToTempWHT_TLM(oleTrans, systemdate, batchno)
        Console.WriteLine("2.3")
        insPaymentPP = InsertToTempPayment_PP(oleTrans, systemdate, batchno) '--> include TF
        Console.WriteLine("2.4")
        insWHTPP = InsertToTempWHT_PP(oleTrans, systemdate, batchno) '-- include TF
        Console.WriteLine("2.5")

        If insPaymentTLM = False Then
            Console.WriteLine("2.6")
            clsBusiness.gLastErrMessage = "err insert TLM to gps_tmp_payment"
            Console.WriteLine("2.7")
            Console.WriteLine("TO TEMP")
            Console.WriteLine(Now.ToString("yyyyMMdd"))
            Console.WriteLine(Now.ToString("HH:mm:ss"))
            InsertTransLog("TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        End If
        If insWHTTLM = False Then
            Console.WriteLine("2.8")
            clsBusiness.gLastErrMessage = "err insert TLM to gps_wht_payment"
            Console.WriteLine("2.9")
            InsertTransLog("TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        End If
        If insPaymentPP = False Then
            Console.WriteLine("2.10")
            clsBusiness.gLastErrMessage = "err insert PP to gps_tmp_payment"
            Console.WriteLine("2.11")
            InsertTransLog("TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        End If
        If insWHTPP = False Then
            Console.WriteLine("2.12")
            clsBusiness.gLastErrMessage = "err insert PP to gps_wht_payment"
            Console.WriteLine("2.13")
            InsertTransLog("TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        End If

        If insPaymentTLM And insWHTTLM And insPaymentPP And insWHTPP Then
            oleTrans.Commit()
            Return True
        Else
            oleTrans.Rollback()
            Return False
        End If
    End Function
    Function InsertTableComplete(ByVal oleTrans As OleDbTransaction) As Boolean


        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentComplete(oleTrans)
        chkWHT = InsertWHTComplete(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

    End Function
    Function InsertTableReject(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentReject(oleTrans)
        chkWHT = InsertWHTReject(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function
    Function InsertTableAML(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chk As Boolean

        chk = InsertAML(oleTrans)
        
        If chk Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function
    Function chkDataComplete(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='COMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If


    End Function
    Function chkDataReject(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder
        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If

    End Function
    Private Sub GenValidationReport(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then

            Dim clsExportPDF As New clsCrystalToPDFConverter

            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
            clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & ".pdf")

            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")

            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)
        End If
    End Sub
    Private Sub RunBatch(ByVal systemdate As String)
        Dim s_systemtime As String
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)

        If DeleteOldData(systemdate) Then

            Dim batchno As String
            batchno = clsBusiness.fnCallBatchNo(clsUtility.gConnGP, systemdate)

            '--RunTLM(systemdate)

            Console.WriteLine("=== RunPP ===")
            RunPP(systemdate)

            Console.WriteLine("=== RunTF ===")
            RunTF(systemdate)
            Console.WriteLine("1")
            CallGL(systemdate, "SYSTEM")
            Console.WriteLine("2")
            Dim chk_totemp, chk_complete, chk_rej, chk_aml As Boolean

            chk_complete = True
            chk_rej = True
            chk_aml = True

            chk_totemp = InsertDataToTemp(systemdate, batchno)
            Console.WriteLine("3")
            If chk_totemp Then

                'Validate Data
                If ValidateData(systemdate) Then
                    Console.WriteLine("4")
                    '��Ǩ�ͺ��Ҿ������� COMPLETE
                    Dim dataCM As Integer
                    dataCM = chkDataComplete(systemdate)
                    '��Ǩ�ͺ��Ҿ������� INCOMPLETE
                    Dim dataRJ As Integer
                    dataRJ = chkDataReject(systemdate)

                    Dim oleTrans As OleDbTransaction
                    oleTrans = clsUtility.gConnGP.BeginTransaction()


                    'Insert to AML
                    chk_aml = InsertTableAML(oleTrans)

                    '��Ǩ�ͺ��Ҿ������� COMPLETE ��� insert data ŧ table Complete
                    If dataCM > 0 Then
                        chk_complete = InsertTableComplete(oleTrans)
                    End If
                    '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� insert data ŧ table Reject
                    If dataRJ > 0 Then
                        chk_rej = InsertTableReject(oleTrans)
                    End If

                    If chk_complete And chk_rej And chk_aml Then
                        oleTrans.Commit()

                        Dim chk_updateflag As Boolean
                        chk_updateflag = UpdateFlag(systemdate)

                        Dim chk_updateflag_GL As Boolean
                        chk_updateflag_GL = UpdateFlag_GL(systemdate)

                        Dim chk_updateflag_TAX As Boolean
                        chk_updateflag_TAX = UpdateFlag_TAX(systemdate)

                        If chk_updateflag And chk_updateflag_GL And chk_updateflag_TAX Then
                            '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� update reject type � table creation
                            If dataRJ > 0 Then
                                UpdatePaymentReject_CR()
                                UpdateWHTReject_CR()
                                UpdatePaymentReject_LD()
                                UpdateWHTReject_LD()
                            End If

                            clsBusiness.gLastErrMessage = "update flag"
                            InsertTransLog("AUTO BATCH", systemdate, batchno, s_systemtime, "COMPLETE", dataCM + dataRJ)
                        Else
                            clsBusiness.gLastErrMessage = "update flag"
                            InsertTransLog("AUTO BATCH", systemdate, batchno, s_systemtime, "COMPLETE", dataCM + dataRJ)
                        End If

                        clsBusiness.gLastErrMessage = "move data to complete,reject,aml"
                        InsertTransLog("AUTO BATCH", systemdate, batchno, s_systemtime, "COMPLETE", dataCM + dataRJ)
                    Else
                        oleTrans.Rollback()
                        clsBusiness.gLastErrMessage = "move data to complete,reject,aml"
                        InsertTransLog("AUTO BATCH", systemdate, batchno, s_systemtime, "INCOMPLETE", 0)
                    End If

                    '�������� Incomplete ��� generate report and send email
                    If dataRJ > 0 Then

                        CallGL_REJ_PARTIAL(systemdate, batchno, "SYSTEM")
                        CallGL_REJ_ALL(systemdate, batchno, "SYSTEM")

                        GenValidationReport(systemdate)

                        '------------SendEmail("ERR_AUTOBATCH")-----------
                        SendEmailSCBLife("ERR_BY_VALIDATE")

                        clsBusiness.gLastErrMessage = "Call GL"
                        InsertTransLog("AUTO BATCH", systemdate, batchno, s_systemtime, "COMPLETE", dataCM + dataRJ)

                    End If

                Else 'Valid Error
                    Console.WriteLine("5")
                    clsBusiness.gLastErrMessage = "Validate not comlplete 17 function"
                    InsertTransLog("VALIDATE", systemdate, batchno, s_systemtime, "INCOMPLETE", 0)
                End If

            Else 'Insert to temp
                clsBusiness.gLastErrMessage = "can not insert data to tmp"
                InsertTransLog("TO TEMP", systemdate, batchno, s_systemtime, "INCOMPLETE", 0)
            End If
       
        End If
    End Sub
    Private Sub btnRunBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRunBatch.Click
        Dim systemdate As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(), 8)

        RunBatch(systemdate)


    End Sub
    Function UpdatePaymentReject_CR() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPCR_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPCR_CREATEDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPCR_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPCR_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPCR_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdatePaymentReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPLD_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPLD_BATCHDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPLD_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPLD_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPLD_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_CR() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_CREATION SET TAXCR_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXCR_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXCR_CREATEDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXCR_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXCR_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXCR_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_LOAD SET TAXLD_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXLD_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXLD_BATCHDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXLD_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXLD_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXLD_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateFlag(ByVal systemdate As String) As Boolean

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chkTranref, chkPayment, chkTranref_nonpay As Boolean

        chkPayment = UpdateFlagPayment_CR(oleTrans, systemdate)
        chkTranref = UpdateFlagTransRef(oleTrans, systemdate)
        chkTranref_nonpay = UpdateFlagTransRef_NONPAY(oleTrans, systemdate)

        'chkWHT = UpdateFlagWHT_CR(oleTrans, systemdate)
        'chk_gl = UpdateFlagGL_CR(oleTrans, systemdate)

        If chkTranref And chkPayment And chkTranref_nonpay Then
            oleTrans.Commit()
            Return True
        Else
            oleTrans.Rollback()
            Return False
        End If

    End Function
    Function UpdateFlag_GL(ByVal systemdate As String) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk_gl As Boolean

        chk_gl = UpdateFlagGL_CR(systemdate)

        If chk_gl Then
            Return True
        Else
            Return False
        End If

    End Function
    Function UpdateFlag_TAX(ByVal systemdate As String) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk, chknonpay As Boolean

        chk = UpdateFlagTAX_CR(systemdate)

        chknonpay = UpdateFlagTAX_CR_NONPAY(systemdate)

        If chk And chknonpay Then
            Return True
        Else
            Return False
        End If

    End Function
    Function UpdateFlagTransRef(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.TREF_BATCH_NO=T.GP_BATCH_NO, ")
        sb.Append("A.TREF_BATCHTYPE='A',   ")
        sb.Append("A.TREF_FLAG_BATCH='Y',   ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagTransRef_NONPAY(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A    ")
        sb.Append("USING     ")
        sb.Append("(    ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R  ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE  ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM  ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF  ")
        sb.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append(") T ON (   ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE   ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM   ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF   ")
        sb.Append(")     ")
        sb.Append("WHEN MATCHED THEN UPDATE     ")
        sb.Append("SET A.TREF_BATCH_NO=T.TAX_BATCH_NO,  ")
        sb.Append("A.TREF_BATCHTYPE='A',    ")
        sb.Append("A.TREF_FLAG_BATCH='Y',    ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagPayment_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT_CREATION A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.GPCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.GPCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.GPCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.GPCR_FLAG_BATCH='Y', ")
        sb.Append("A.GPCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagWHT_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_WHT_CREATION A ")
        sb.Append("USING ")
        sb.Append("( ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF ")
        'sb.Append("WHERE R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TAXCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TAXCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TAXCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.TAXCR_FLAG_BATCH='Y', ")
        sb.Append("A.TAXCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Private Sub InsertTransLog(ByVal fn As String, ByVal systemdate As String, ByVal batchno As String, ByVal s_systemtime As String, ByVal status As String, ByVal total_rec As Integer)
        Dim oleTrans As OleDbTransaction

        Dim e_systemtime As String

        Console.WriteLine("2.7.1")
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(), 8)
        Console.WriteLine("2.7.2")
        e_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
        Console.WriteLine("2.7.3")

        'Dim total_rec, total_creation, total_load As Integer
        'total_creation = GetPaymentCreationRecord(systemdate)
        'total_load = GetPaymentLoadRecord(systemdate)

        'total_rec = total_creation + total_load

        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        Console.WriteLine("2.7.4")

        sb.Append("INSERT INTO GPS_TRANSLOG( ")
        sb.Append("TRAN_DATE,")
        sb.Append("TRAN_FUNCTION,")
        sb.Append("TRAN_BATCH_ID,")
        sb.Append("TRAN_S_TIME,")
        sb.Append("TRAN_E_TIME,")
        sb.Append("TRAN_RECORD,")
        sb.Append("TRAN_BATCH_TYPE,")
        sb.Append("TRAN_STATUS,")
        sb.Append("TRAN_REMARK,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & fn & "',")
        sb.Append("'" & batchno & "',")
        sb.Append("'" & s_systemtime & "',")
        sb.Append("'" & e_systemtime & "',")
        sb.Append("'" & total_rec & "',")
        sb.Append("'A',")
        sb.Append("'" & status & "',")
        sb.Append("'" & clsBusiness.gLastErrMessage.Replace("'", "''") & "',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")
        Console.WriteLine(sb.ToString)
        Console.WriteLine("2.14")
        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'Console.WriteLine("2.7.4.commit")
        Else
            oleTrans.Rollback()
            'Console.WriteLine("2.7.4.rollback")
        End If

    End Sub
    Public Function UPD_GLCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_GL_CREATION  ")
        sb.Append("SET GLCR_FLAG_BATCH='Y', GLCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE GLCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND GLCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND GLCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Function UpdateFlagGL_CR(ByVal systemdate As String) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_GLCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function
    Public Function UPD_TAXCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_WHT_CREATION  ")
        sb.Append("SET TAXCR_FLAG_BATCH='Y', TAXCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE TAXCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND TAXCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND TAXCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Function UpdateFlagTAX_CR(ByVal systemdate As String) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function
    Function UpdateFlagTAX_CR_NONPAY(ByVal systemdate As String) As Boolean

        Dim r_chk As Integer
        Dim sbChk As New StringBuilder()

        'sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        'sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        'sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        'sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        'sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        'sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        sbChk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO    ")
        sbChk.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R    ")
        sbChk.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE    ")
        sbChk.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM    ")
        sbChk.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF AND T.TAX_BATCHDATE='" & systemdate & "'    ")
        sbChk.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sbChk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function
    Private Sub btnTLM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTLM.Click
        Dim systemdate As String = Date.Now.ToString("yyyyMMdd")
        'RunTLM(systemdate)
      
    End Sub
    Private Sub btnPP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPP.Click
        Dim systemdate As String = Date.Now.ToString("yyyyMMdd")
        'RunPP(systemdate)
    End Sub
    Public Function CheckDate(ByVal dateString As String, ByVal systemdate As String) As Boolean

        Dim formats As String = "yyyyMMdd"
        Dim dateValue As DateTime

        Select Case Convert.ToInt16(dateString.Substring(0, 4))
            Case Convert.ToInt16(systemdate.Substring(0, 4))
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Convert.ToInt16(systemdate.Substring(0, 4)) + 1
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Else
                Return False
        End Select

    End Function
    Public Function TLM_ReadTextFile(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Try

            CurrentRow = TextFileReader.ReadFields()

            If Not CurrentRow Is Nothing Then
                If dtD Is Nothing Then
                    dtD = New DataTable("dtPP")

                    dtD.Columns.Add("H_DATE")
                    dtD.Columns.Add("H_TOT_AMT")


                End If

                Row = dtD.NewRow
                Row.Item(0) = CurrentRow(0).ToString.Trim
                Row.Item(1) = CurrentRow(1).ToString.Trim

                dtD.Rows.Add(Row)


            End If
        Catch ex As _
        Microsoft.VisualBasic.FileIO.MalformedLineException
            'MsgBox("Line " & ex.Message & _
            '"is not valid and will be skipped.")
        End Try

        TextFileReader.Dispose()

        Return dtD

    End Function
    Private Sub TLM_GenControlGP(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_PAYMENT_CREATION ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GPCR_CREATEDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GPCR_CORE_SYSTEM " & "constant ""TLM"",")
            '��� Running ����� sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(MAX, 1) ,")

            sw.WriteLine("GPCR_TRANSREF,")
            sw.WriteLine("GPCR_GPTREF_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("GPCR_POLNO,")
            sw.WriteLine("GPCR_BILLNO,")
            sw.WriteLine("GPCR_PAIDDATE ""SUBSTR(:GPCR_PAIDDATE,7,4)||SUBSTR(:GPCR_PAIDDATE,4,2)||SUBSTR(:GPCR_PAIDDATE,1,2)"",")
            sw.WriteLine("GPCR_AMOUNT,")
            sw.WriteLine("GPCR_DESC,")
            sw.WriteLine("GPCR_PAYMTH,")
            sw.WriteLine("GPCR_PAYEE_NAME,")
            sw.WriteLine("GPCR_BNKCODE_NO,")
            sw.WriteLine("GPCR_BNKBRN,")
            sw.WriteLine("GPCR_BNKNAME,")
            sw.WriteLine("GPCR_PAYEE_BNKACCNO,")
            sw.WriteLine("GPCR_PAYEE_BNKACCNME,")
            sw.WriteLine("GPCR_COMMENT,")
            sw.WriteLine("GPCR_ADDRESS1,")
            sw.WriteLine("GPCR_DISTRICT,")
            sw.WriteLine("GPCR_PROVINCE,")
            sw.WriteLine("GPCR_INSURENAME,")
            sw.WriteLine("GPCR_DATASOURCE_NME,")
            sw.WriteLine("GPCR_RESERVE6,")
            sw.WriteLine("GPCR_MERCHN_NO,")
            sw.WriteLine("GPCR_CDCARD_DATE,")
            sw.WriteLine("GPCR_RESERVE9,")
            sw.WriteLine("GPCR_RESERVE10,")
            sw.WriteLine("GPCR_SYS_REF,")
            sw.WriteLine("GPCR_SYS_GR,")
            'sw.WriteLine("GPCR_DTSOURCE ""SUBSTR(:GPCR_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub TLM_GenControlGL(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 1 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_GL_CREATION ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GLCR_CREATEDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GLCR_CORE_SYSTEM " & "constant ""TLM"",")
            sw.WriteLine("GLCR_JN_TYPE,")
            sw.WriteLine("GLCR_JN_SOURCE,")
            sw.WriteLine("GLCR_B_UNIT,")
            'sw.WriteLine("GLCR_GL_PERIOD,")
            sw.WriteLine("GLCR_GL_PERIOD ""SUBSTR(:GLCR_GL_PERIOD,4,4)||SUBSTR(:GLCR_GL_PERIOD,1,3)"",")
            sw.WriteLine("GLCR_TRANSREF,")
            sw.WriteLine("GLCR_LINENO,")
            'sw.WriteLine("GLCR_TRANSDATE ""SUBSTR(:GLCR_TRANSDATE,7,4)||SUBSTR(:GLCR_TRANSDATE,4,2)||SUBSTR(:GLCR_TRANSDATE,1,2)"",")
            'sw.WriteLine("GLCR_DUEDATE ""SUBSTR(:GLCR_DUEDATE,7,4)||SUBSTR(:GLCR_DUEDATE,4,2)||SUBSTR(:GLCR_DUEDATE,1,2)"",")
            sw.WriteLine("GLCR_TRANSDATE ""SUBSTR(:GLCR_TRANSDATE,5,4)||SUBSTR(:GLCR_TRANSDATE,3,2)||SUBSTR(:GLCR_TRANSDATE,1,2)"",")
            sw.WriteLine("GLCR_DUEDATE ""SUBSTR(:GLCR_DUEDATE,5,4)||SUBSTR(:GLCR_DUEDATE,3,2)||SUBSTR(:GLCR_DUEDATE,1,2)"",")
            sw.WriteLine("GLCR_DESC,")
            'sw.WriteLine("GLCR_O_ACCOUNT,")
            sw.WriteLine("GLCR_AMOUNT,")
            sw.WriteLine("GLCR_DRCR,")
            'sw.WriteLine("GLCR_O_DEP_BRN,")
            'sw.WriteLine("GLCR_O_PL_PT,")
            'sw.WriteLine("GLCR_O_MKT_EMP,")
            sw.WriteLine("GLCR_O_PROJECT " & "constant ""00000"",")
            sw.WriteLine("GLCR_PAYMTH,")
            sw.WriteLine("GLCR_PAYEE,")
            sw.WriteLine("GLCR_S_ACCOUNT,")
            sw.WriteLine("GLCR_S_ACCNAME,")
            sw.WriteLine("GLCR_S_DEP_BRN,")
            sw.WriteLine("GLCR_S_PL_PT,")
            sw.WriteLine("GLCR_S_MKT_EMP,")
            sw.WriteLine("GLCR_S_TT_TR,")
            sw.WriteLine("GLCR_S_PROJECT,")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub TLM_LoadGPFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GPInfilePath, "GENPAY")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            'controlfile = ControlPath & "GPCONTROL_TLM.ctl"
            controlfile = ControlPath & filename & ".ctl"
            infile = GPInfilePath & filename
            bkfile = GPBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = TLM_ReadTextFile(infile, "|")

            TLM_GenControlGP(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

            chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

            BackupFile(infile, bkfile, systemdate)

        Next

        If arr.Count >= 1 Then
            'Update Bank code
            TLM_GP_UpdateBankCode(systemdate)

            'Update SubPayType
            TLM_GP_UpdatePayType(systemdate)

            'Update SubPayType
            TLM_GP_UpdateSubPayType(systemdate)

            'Update BankBranch
            TLM_GP_UpdateBnkBrn(systemdate)

            'Update Flag_Track_Bill
            TLM_GP_UpdateFlagFlwBill(systemdate)

        End If

    End Sub
    Private Sub TLM_LoadGLFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GLInfilePath, "SUNACC")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()

            'controlfile = ControlPath & "GLCONTROL_TLM.ctl"
            controlfile = ControlPath & filename & ".ctl"
            infile = GLInfilePath & filename
            bkfile = GLBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = TLM_ReadTextFile(infile, "|")

            TLM_GenControlGL(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

            chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)


            BackupFile(infile, bkfile, systemdate)

        Next

        If arr.Count >= 1 Then

            'Update Type Paymth = R
            TLM_GL_UpdatePayMth_R(systemdate)

            'Update Config Data
            TLM_GL_UpdateConfigData(systemdate)

            'Update Journal Hold
            TLM_GL_UpdateJournalHold(systemdate)

        End If

    End Sub
    Private Sub TLM_GP_UpdateBankCode(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION a  ")
        sb.Append("SET (GPCR_BNKCODE) = ( ")
        sb.Append("SELECT BKMST_BNKCODE ")
        sb.Append("FROM GPS_TL_BANKMASTER b  ")
        sb.Append("WHERE a.GPCR_BNKCODE_NO = b.BKMST_BNKCODE_NO AND b.BKMST_STATUS='ACTIVE') ")
        sb.Append("WHERE a.GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND a.GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdatePayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_PAYMTH= 'M' ")
        sb.Append("WHERE GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM='TLM'")
        sb.Append("AND GPCR_PAYMTH='R'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdateSubPayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_SUB_PAYMTH= ")
        sb.Append("CASE WHEN (GPCR_PAYMTH='C') THEN 'C'  ")
        sb.Append("WHEN (GPCR_PAYMTH='D') THEN 'D' ")
        sb.Append("WHEN (GPCR_PAYMTH='M' AND (UPPER(GPCR_RESERVE6) LIKE '%CREDIT CARD%' OR GPCR_RESERVE6 LIKE '%�ѵ��ôԵ%')) THEN 'C' ")
        sb.Append("WHEN (GPCR_PAYMTH='M') THEN 'M' ")
        sb.Append("ELSE '' END ")
        sb.Append("WHERE GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdateBnkBrn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION P SET P.GPCR_BNKBRN= ")
        sb.Append("CASE WHEN GPCR_PAYMTH='C' OR GPCR_PAYMTH='D' THEN   ")
        sb.Append("(SELECT B.BNKS_BNKSBRN_CD FROM GPS_TL_PAYTYPE A INNER JOIN GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP ")
        sb.Append("WHERE A.PAYT_PAYMTH=P.GPCR_PAYMTH AND A.PAYT_SUB_PAYMTH=P.GPCR_SUB_PAYMTH) ")
        sb.Append("ELSE P.GPCR_BNKBRN END ")
        sb.Append("WHERE P.GPCR_CREATEDATE='" & LoadDate & "' AND P.GPCR_CORE_SYSTEM='TLM' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GP_UpdateFlagFlwBill(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_FLWBILL=")
        sb.Append("CASE WHEN (UPPER(GPCR_DESC) LIKE '%PAYMENT OF MEDICAL INVOICE%') THEN 'Y' ELSE 'N' END ")
        sb.Append("WHERE GPCR_CREATEDATE='" & LoadDate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM='TLM'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TLM_GL_UpdateConfigData(ByVal LoadDate As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_GL_HEAD_SETUP ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim sb1 As New StringBuilder
            Dim rec As Integer

            oleTrans = clsUtility.gConnGP.BeginTransaction()
            sb1.Append("UPDATE GPS_GL_CREATION SET ")
            sb1.Append(" GLCR_GLSTS = '" & dt.Rows(0)("GLHS_GLSTS").ToString & "', ")
            sb1.Append(" GLCR_BOOKID = '" & dt.Rows(0)("GLHS_BOOKID").ToString & "' ,")
            sb1.Append(" GLCR_SOURCE_NME = '" & dt.Rows(0)("GLHS_SOURCE_NME").ToString & "', ")
            sb1.Append(" GLCR_CATEGORY_NME = '" & dt.Rows(0)("GLHS_CATEGORY_NME").ToString & "' ,")
            sb1.Append(" GLCR_CURRENCY_CDE = '" & dt.Rows(0)("GLHS_CURRENCY_CDE").ToString & "', ")
            sb1.Append(" GLCR_ACTUAL_FLAG = '" & dt.Rows(0)("GLHS_ACTUAL_FLAG").ToString & "' ,")
            sb1.Append(" GLCR_COMPANY_CDE = '" & dt.Rows(0)("GLHS_COMPANY_CDE").ToString & "', ")
            sb1.Append(" GLCR_RCCODE = '" & dt.Rows(0)("GLHS_RCCODE").ToString & "' ")
            sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
            sb1.Append("AND GLCR_CORE_SYSTEM='TLM'")


            rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)

            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                'MsgBox(clsBusiness.gLastErrMessage)
            End If

        Else
            'MsgBox("Can not load data GPS_GL_HEAD_SETUP")
        End If
    End Sub
    Private Sub TLM_GL_UpdateJournalHold(ByVal LoadDate As String)
        Dim dt As DataTable
        dt = TLM_JournalHoldToTemp(LoadDate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim rec As Integer
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim sb1 As New StringBuilder

                sb1.Append("UPDATE GPS_GL_CREATION SET ")
                sb1.Append("GLCR_JN_HOLD = '" & dr("JournalHold") & "' ")
                sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
                sb1.Append("AND GLCR_TRANSREF = '" & dr("Transref") & "' ")
                sb1.Append("AND GLCR_CORE_SYSTEM='TLM'")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)
            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")

            Else
                oleTrans.Rollback()
                'MsgBox(clsBusiness.gLastErrMessage)
            End If

        End If




    End Sub
    Private Sub TLM_GL_UpdatePayMth_R(ByVal LoadDate As String)
      
        Dim rec As Integer
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()


        Dim sb1 As New StringBuilder

        sb1.Append("UPDATE GPS_GL_CREATION SET ")
        sb1.Append("GLCR_PAYMTH = 'M' ")
        sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
        sb1.Append("AND GLCR_CORE_SYSTEM='TLM'")
        sb1.Append("AND GLCR_PAYMTH='R'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)


        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")

        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Function CallGL(ByVal batchdate As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
       

        dbComm.CommandText = "GPS_SP_GET_JournalNO"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Function CallWL(ByVal batchdate As String, ByVal errtype As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate
        dbComm.Parameters.Add("p_errtype", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_errtype").Value = errtype
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_VALIDATE_WL"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

       
    End Function
    Function Call_GPS_SP_VALIDATE_AUTO(ByVal batchdate As String) As Integer
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate
        dbComm.Parameters.Add("v_error", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_VALIDATE_AUTO"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("v_error").Value


    End Function
    Function CallAML(ByVal batchdate As String, ByVal errtype As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate
        dbComm.Parameters.Add("p_errtype", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_errtype").Value = errtype
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_VALIDATE_AML"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value


    End Function
    Function CallGL_REJ_PARTIAL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectpartial"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        '--Dim X As String = dbComm.Parameters("result_msg").Value

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Function CallGL_REJ_ALL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectall"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        '--Dim X As String = dbComm.Parameters("result_msg").Value.ToString.Trim

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Private Sub TLM_UPDATE_INTERFACE_CONTROL_STATUS(ByVal status As String)

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO", status, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If
    End Sub
    Private Sub TLM_UPDATE_INTERFACE_CONTROL_NO()

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_NO(clsUtility.gConnGP, "JN_HO", oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Function TLM_GetJournalHold() As String
        Cursor = Cursors.WaitCursor
        retJnHold = ""
        Dim chk As Boolean
        Dim no As String
        chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO")

        If chk Then


            TLM_UPDATE_INTERFACE_CONTROL_STATUS("START")

            no = clsBusiness.GET_NO_INTERFACE_CONTROL(clsUtility.gConnGP, "JN_HO")

            TLM_UPDATE_INTERFACE_CONTROL_NO()

            TLM_UPDATE_INTERFACE_CONTROL_STATUS("STOP")

            Cursor = Cursors.Default
        Else
            no = ""
        End If

        Return no

    End Function
    Function TLM_JournalHoldToTemp(ByVal LoadDate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GLCR_TRANSREF FROM GPS_GL_CREATION   ")
        sb.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' AND GLCR_CORE_SYSTEM='TLM' ")
        sb.Append("GROUP BY GLCR_TRANSREF ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            If dtJournalHold Is Nothing Then
                dtJournalHold = New DataTable("TempJN")

                dtJournalHold.Columns.Add("Transref")
                dtJournalHold.Columns.Add("JournalHold")
            End If

            Dim Row As DataRow

            For Each dr As DataRow In dt.Rows
                'Dim jn_ho As String
                'jn_ho = GetJournalHold()

                retJnHold = ""
                Do While retJnHold = ""
                    retJnHold = TLM_GetJournalHold()
                Loop


                Row = dtJournalHold.NewRow

                Row.Item(0) = dr("GLCR_TRANSREF").ToString
                Row.Item(1) = retJnHold 'jn_ho

                dtJournalHold.Rows.Add(Row)

            Next

        End If

        Return dtJournalHold
    End Function
    Private Sub TLM_INS_GPS_TRANSREF_REL(ByVal systemdate As String)
        Dim dt As DataTable
        dt = TLM_PrepareData(systemdate)

        If Not dt Is Nothing AndAlso dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim rec As Integer
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb As New StringBuilder

                sb.Append("INSERT INTO GPS_TRANSREF_REL ( ")
                sb.Append("TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_TRANSREF,")
                sb.Append("TREF_JN_TYPE,TREF_GL_PERIOD,TREF_PAYCRETYP_ID,")
                sb.Append("TREF_PAIDDATE,TREF_PAYMTH,TREF_SUB_PAYMTH,")
                sb.Append("TREF_DTSOURCE,TREF_DEP_KEYIN,TREF_DEP_REPAY,")
                sb.Append("TREF_JN_HOLD,TREF_BATCHTYPE,CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE)")
                sb.Append("VALUES (")
                sb.Append("'" & systemdate & "',")
                sb.Append("'TLM',")
                sb.Append("'" & dr.Item("GPCR_TRANSREF").ToString & "',")
                sb.Append("'" & dr.Item("GLCR_JN_TYPE").ToString & "',")
                sb.Append("'" & dr.Item("GLCR_GL_PERIOD").ToString & "',")
                sb.Append("'005',")
                sb.Append("'" & dr.Item("GPCR_PAIDDATE").ToString & "',")
                sb.Append("'" & dr.Item("GPCR_PAYMTH").ToString & "',")
                sb.Append("'" & dr.Item("GPCR_SUB_PAYMTH").ToString & "',")
                sb.Append("'TLM',")
                sb.Append("'TLM',")
                sb.Append("'TLM',")
                sb.Append("'" & dr.Item("GLCR_JN_HOLD").ToString & "',")
                sb.Append("'',")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                'MsgBox(clsBusiness.gLastErrMessage)
            End If


        End If
    End Sub
    Private Sub PP_INS_GPS_TRANSREF_REL(ByVal systemdate As String)
        Dim dt As DataTable
        dt = PP_PrepareData(systemdate)


        If Not dt Is Nothing AndAlso dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim rec As Integer
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb As New StringBuilder

                sb.Append("insert into gps_transref_rel ( ")
                sb.Append("TREF_CREATEDATE, ")
                sb.Append("TREF_CORE_SYSTEM, ")
                sb.Append("TREF_TRANSREF, ")
                sb.Append("TREF_JN_TYPE, ")
                sb.Append("TREF_GL_PERIOD, ")
                sb.Append("TREF_PAIDDATE, ")
                sb.Append("TREF_PAYMTH, ")
                sb.Append("TREF_SUB_PAYMTH, ")
                sb.Append("TREF_DTSOURCE, ")
                sb.Append("TREF_DEP_KEYIN, ")
                sb.Append("TREF_DEP_REPAY, ")
                sb.Append("TREF_FLAG_BATCH, ")
                sb.Append("TREF_BATCHTYPE, ")
                sb.Append("CREATEDBY, ")
                sb.Append("CREATEDDATE, ")
                sb.Append("UPDATEDBY, ")
                sb.Append("UPDATEDDATE) ")
                sb.Append("values ( ")
                sb.Append("'" & dr.Item("GPLD_BATCHDATE").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_CORE_SYSTEM").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_TRANSREF").ToString & "', ")
                sb.Append("'" & dr.Item("GLLD_JN_TYPE").ToString & "', ")
                sb.Append("'" & dr.Item("GLLD_GL_PERIOD").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_PAIDDATE").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_PAYMTH").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_SUB_PAYMTH").ToString & "', ")
                sb.Append("'" & Microsoft.VisualBasic.Left(dr.Item("GPLD_TRANSREF").ToString, 3) & "', ")
                sb.Append("'" & dr.Item("DTS_DEP_KEYIN").ToString & "', ")
                sb.Append("'" & dr.Item("DTS_DEP_REPAY").ToString & "', ")
                sb.Append("'N' ,")
                sb.Append("'A' ,")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")


                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                'MsgBox(clsBusiness.gLastErrMessage)
            End If


        End If
    End Sub
    Private Sub TF_INS_GPS_TRANSREF_REL(ByVal systemdate As String)
        Dim dt As DataTable
        dt = TF_PrepareData(systemdate)


        If Not dt Is Nothing AndAlso dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            Dim rec As Integer
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb As New StringBuilder

                sb.Append("insert into gps_transref_rel ( ")
                sb.Append("TREF_CREATEDATE, ")
                sb.Append("TREF_CORE_SYSTEM, ")
                sb.Append("TREF_TRANSREF, ")
                sb.Append("TREF_JN_TYPE, ")
                sb.Append("TREF_GL_PERIOD, ")
                sb.Append("TREF_PAIDDATE, ")
                sb.Append("TREF_PAYMTH, ")
                sb.Append("TREF_SUB_PAYMTH, ")
                sb.Append("TREF_DTSOURCE, ")
                sb.Append("TREF_DEP_KEYIN, ")
                sb.Append("TREF_DEP_REPAY, ")
                sb.Append("TREF_FLAG_BATCH, ")
                sb.Append("TREF_BATCHTYPE, ")
                sb.Append("CREATEDBY, ")
                sb.Append("CREATEDDATE, ")
                sb.Append("UPDATEDBY, ")
                sb.Append("UPDATEDDATE) ")
                sb.Append("values ( ")
                sb.Append("'" & dr.Item("GPLD_BATCHDATE").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_CORE_SYSTEM").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_TRANSREF").ToString & "', ")
                sb.Append("'" & dr.Item("GLLD_JN_TYPE").ToString & "', ")
                sb.Append("'" & dr.Item("GLLD_GL_PERIOD").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_PAIDDATE").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_PAYMTH").ToString & "', ")
                sb.Append("'" & dr.Item("GPLD_SUB_PAYMTH").ToString & "', ")
                sb.Append("'" & Microsoft.VisualBasic.Left(dr.Item("GPLD_TRANSREF").ToString, 3) & "', ")
                sb.Append("'" & dr.Item("DTS_DEP_KEYIN").ToString & "', ")
                sb.Append("'" & dr.Item("DTS_DEP_REPAY").ToString & "', ")
                sb.Append("'N' ,")
                sb.Append("'A' ,")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("'SYSTEM' ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")


                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
            Next


            If rec >= 0 Then
                oleTrans.Commit()
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()
                'MsgBox(clsBusiness.gLastErrMessage)
            End If


        End If
    End Sub
    Function TLM_PrepareData(ByVal systemdate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GP.GPCR_TRANSREF, GP.GPCR_PAIDDATE, GP.GPCR_PAYMTH, GP.GPCR_SUB_PAYMTH, ")
        sb.Append("GL.GLCR_JN_TYPE,GL.GLCR_GL_PERIOD, GL.GLCR_JN_HOLD   ")
        sb.Append("FROM GPS_PAYMENT_CREATION GP LEFT JOIN GPS_GL_CREATION GL  ")
        sb.Append("ON GP.GPCR_CREATEDATE= GL.GLCR_CREATEDATE  ")
        sb.Append("AND GP.GPCR_CORE_SYSTEM=GL.GLCR_CORE_SYSTEM  ")
        sb.Append("AND GP.GPCR_TRANSREF=GL.GLCR_TRANSREF   ")
        sb.Append("WHERE GP.GPCR_CREATEDATE='" & systemdate & "' AND GP.GPCR_CORE_SYSTEM='TLM'  ")
        sb.Append("GROUP BY GP.GPCR_TRANSREF, GP.GPCR_PAIDDATE, GP.GPCR_PAYMTH,GP.GPCR_SUB_PAYMTH,  ")
        sb.Append("GL.GLCR_JN_TYPE, GL.GLCR_GL_PERIOD, GL.GLCR_JN_HOLD  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Function PP_PrepareData(ByVal systemdate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GP.GPLD_BATCHDATE, GP.GPLD_CORE_SYSTEM, GP.GPLD_TRANSREF, GP.GPLD_PAIDDATE, ")
        sb.Append("GP.GPLD_PAYMTH, GP.GPLD_SUB_PAYMTH, GL.GLLD_JN_TYPE,GL.GLLD_GL_PERIOD,S.DTS_DEP_KEYIN, S.DTS_DEP_REPAY ")
        sb.Append("FROM GPS_PAYMENT_LOAD GP LEFT JOIN GPS_GL_LOAD GL ON GP.GPLD_BATCHDATE= GL.GLLD_BATCHDATE AND  ")
        sb.Append("GP.GPLD_CORE_SYSTEM=GL.GLLD_CORE_SYSTEM And  ")
        sb.Append("GP.GPLD_TRANSREF=GL.GLLD_TRANSREF ")
        sb.Append("LEFT JOIN GPS_TL_DATASOURCE S ON GP.GPLD_CORE_SYSTEM=S.DTS_CORE_SYSTEM ")
        sb.Append("AND LPAD(GP.GPLD_TRANSREF,3)=S.DTS_DTSOURCE ")
        sb.Append("WHERE GP.GPLD_BATCHDATE='" & systemdate & "' and GP.GPLD_CORE_SYSTEM='PP'  ")
        sb.Append("GROUP BY GP.GPLD_BATCHDATE, GP.GPLD_CORE_SYSTEM, GP.GPLD_TRANSREF, GP.GPLD_PAIDDATE, ")
        sb.Append(" GP.GPLD_PAYMTH,GP.GPLD_SUB_PAYMTH, GL.GLLD_JN_TYPE, GL.GLLD_GL_PERIOD,S.DTS_DEP_KEYIN, S.DTS_DEP_REPAY ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Function TF_PrepareData(ByVal systemdate As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT GP.GPLD_BATCHDATE, GP.GPLD_CORE_SYSTEM, GP.GPLD_TRANSREF, GP.GPLD_PAIDDATE, ")
        sb.Append("GP.GPLD_PAYMTH, GP.GPLD_SUB_PAYMTH, GL.GLLD_JN_TYPE,GL.GLLD_GL_PERIOD,S.DTS_DEP_KEYIN, S.DTS_DEP_REPAY ")
        sb.Append("FROM GPS_PAYMENT_LOAD GP LEFT JOIN GPS_GL_LOAD GL ON GP.GPLD_BATCHDATE= GL.GLLD_BATCHDATE AND  ")
        sb.Append("GP.GPLD_CORE_SYSTEM=GL.GLLD_CORE_SYSTEM And  ")
        sb.Append("GP.GPLD_TRANSREF=GL.GLLD_TRANSREF ")
        sb.Append("LEFT JOIN GPS_TL_DATASOURCE S ON GP.GPLD_CORE_SYSTEM=S.DTS_CORE_SYSTEM ")
        sb.Append("AND LPAD(GP.GPLD_TRANSREF,3)=S.DTS_DTSOURCE ")
        sb.Append("WHERE GP.GPLD_BATCHDATE='" & systemdate & "' and GP.GPLD_CORE_SYSTEM='ACC'  ")
        sb.Append("GROUP BY GP.GPLD_BATCHDATE, GP.GPLD_CORE_SYSTEM, GP.GPLD_TRANSREF, GP.GPLD_PAIDDATE, ")
        sb.Append(" GP.GPLD_PAYMTH,GP.GPLD_SUB_PAYMTH, GL.GLLD_JN_TYPE, GL.GLLD_GL_PERIOD,S.DTS_DEP_KEYIN, S.DTS_DEP_REPAY ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function PP_ReadTextFile(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Try

            CurrentRow = TextFileReader.ReadFields()

            If Not CurrentRow Is Nothing Then
                If dtD Is Nothing Then
                    dtD = New DataTable("dtPP")

                    dtD.Columns.Add("H_DATE")
                    dtD.Columns.Add("H_TOT_AMT")


                End If

                Row = dtD.NewRow
                Row.Item(0) = CurrentRow(0).ToString.Trim
                Row.Item(1) = CurrentRow(1).ToString.Trim

                dtD.Rows.Add(Row)


            End If
        Catch ex As  _
        Microsoft.VisualBasic.FileIO.MalformedLineException
            'MsgBox("Line " & ex.Message & _
            '"is not valid and will be skipped.")
        End Try

        TextFileReader.Dispose()

        Return dtD

    End Function
    Public Function TF_ReadTextFile(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Try

            CurrentRow = TextFileReader.ReadFields()

            If Not CurrentRow Is Nothing Then
                If dtD Is Nothing Then
                    dtD = New DataTable("dtTF")

                    dtD.Columns.Add("H_DATE")
                    dtD.Columns.Add("H_TOT_AMT")


                End If

                Row = dtD.NewRow
                Row.Item(0) = CurrentRow(0).ToString.Trim
                Row.Item(1) = CurrentRow(1).ToString.Trim

                dtD.Rows.Add(Row)


            End If
        Catch ex As  _
        Microsoft.VisualBasic.FileIO.MalformedLineException
            'MsgBox("Line " & ex.Message & _
            '"is not valid and will be skipped.")
        End Try

        TextFileReader.Dispose()

        Return dtD

    End Function
    Private Sub PP_GenControlGP(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_PAYMENT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GPLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GPLD_CORE_SYSTEM " & "constant ""PP"",")
            '��� Running ����� sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(MAX, 1) ,")
            sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("GPLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GPLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GPLD_FILENAME " & "constant """ & filename & """,")
            sw.WriteLine("GPLD_TRANSREF,")
            sw.WriteLine("GPLD_POLNO,")
            sw.WriteLine("GPLD_BILLNO,")
            sw.WriteLine("GPLD_PAIDDATE_TXT,")
            sw.WriteLine("GPLD_AMOUNT,")
            sw.WriteLine("GPLD_DESC,")
            sw.WriteLine("GPLD_PAYMTH,")
            sw.WriteLine("GPLD_PAYEE_NAME,")
            sw.WriteLine("GPLD_BNKCODE_NO,")
            sw.WriteLine("GPLD_BNKBRN,")
            sw.WriteLine("GPLD_BNKNAME,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNO,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNME,")
            sw.WriteLine("GPLD_COMMENT,")
            sw.WriteLine("GPLD_ADDRESS1,")
            sw.WriteLine("GPLD_DISTRICT,")
            sw.WriteLine("GPLD_PROVINCE,")
            sw.WriteLine("GPLD_INSURENAME,")
            sw.WriteLine("GPLD_DATASOURCE_NME,")
            sw.WriteLine("GPLD_RESERVE6,")
            sw.WriteLine("GPLD_MERCHN_NO,")
            sw.WriteLine("GPLD_CDCARD_DATE,")
            sw.WriteLine("GPLD_RESERVE9,")
            sw.WriteLine("GPLD_RESERVE10,")
            sw.WriteLine("GPLD_SYS_REF,")
            sw.WriteLine("GPLD_SYS_GR,")
            sw.WriteLine("GPLD_DTSOURCE ""SUBSTR(:GPLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub TF_GenControlGP(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_PAYMENT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GPLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GPLD_CORE_SYSTEM " & "constant ""ACC"",")  '--> change PP >> TF
            '��� Running ����� sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(MAX, 1) ,")
            sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("GPLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GPLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GPLD_FILENAME " & "constant """ & filename & """,")
            sw.WriteLine("GPLD_TRANSREF,")
            sw.WriteLine("GPLD_POLNO,")
            sw.WriteLine("GPLD_BILLNO,")
            sw.WriteLine("GPLD_PAIDDATE_TXT,")
            sw.WriteLine("GPLD_AMOUNT,")
            sw.WriteLine("GPLD_DESC,")
            sw.WriteLine("GPLD_PAYMTH,")
            sw.WriteLine("GPLD_PAYEE_NAME,")
            sw.WriteLine("GPLD_BNKCODE_NO,")
            sw.WriteLine("GPLD_BNKBRN,")
            sw.WriteLine("GPLD_BNKNAME,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNO,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNME,")
            sw.WriteLine("GPLD_COMMENT,")
            sw.WriteLine("GPLD_ADDRESS1,")
            sw.WriteLine("GPLD_DISTRICT,")
            sw.WriteLine("GPLD_PROVINCE,")
            sw.WriteLine("GPLD_INSURENAME,")
            sw.WriteLine("GPLD_DATASOURCE_NME,")
            sw.WriteLine("GPLD_RESERVE6,")
            sw.WriteLine("GPLD_MERCHN_NO,")
            sw.WriteLine("GPLD_CDCARD_DATE,")
            sw.WriteLine("GPLD_RESERVE9,")
            sw.WriteLine("GPLD_RESERVE10,")
            sw.WriteLine("GPLD_SYS_REF,")
            sw.WriteLine("GPLD_SYS_GR,")
            sw.WriteLine("GPLD_DTSOURCE ""SUBSTR(:GPLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub PP_GenControlGL(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_GL_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GLLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GLLD_CORE_SYSTEM " & "constant ""PP"",")
            sw.WriteLine("GLLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GLLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GLLD_JN_TYPE,")
            sw.WriteLine("GLLD_JN_SOURCE,")
            sw.WriteLine("GLLD_B_UNIT,")
            sw.WriteLine("GLLD_GL_PERIOD,")
            sw.WriteLine("GLLD_TRANSREF,")
            sw.WriteLine("GLLD_LINENO,")
            sw.WriteLine("GLLD_TRANSDATE_TXT,")
            sw.WriteLine("GLLD_DUEDATE_TXT,")
            sw.WriteLine("GLLD_DESC,")
            sw.WriteLine("GLLD_O_ACCOUNT,")
            sw.WriteLine("GLLD_AMOUNT,")
            sw.WriteLine("GLLD_DRCR,")
            sw.WriteLine("GLLD_O_DEP_BRN,")
            sw.WriteLine("GLLD_O_PL_PT,")
            sw.WriteLine("GLLD_O_MKT_EMP,")
            sw.WriteLine("GLLD_O_PROJECT,")
            sw.WriteLine("GLLD_PAYMTH,")
            sw.WriteLine("GLLD_PAYEE,")
            sw.WriteLine("GLLD_S_ACCOUNT,")
            sw.WriteLine("GLLD_S_ACCNAME,")
            sw.WriteLine("GLLD_S_DEP_BRN,")
            sw.WriteLine("GLLD_S_PL_PT,")
            sw.WriteLine("GLLD_S_MKT_EMP,")
            sw.WriteLine("GLLD_S_TT_TR,")
            sw.WriteLine("GLLD_S_PROJECT,")
            sw.WriteLine("GLLD_DTSOURCE ""SUBSTR(:GLLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub TF_GenControlGL(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_GL_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GLLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GLLD_CORE_SYSTEM " & "constant ""ACC"",")
            sw.WriteLine("GLLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GLLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GLLD_JN_TYPE,")
            sw.WriteLine("GLLD_JN_SOURCE,")
            sw.WriteLine("GLLD_B_UNIT,")
            sw.WriteLine("GLLD_GL_PERIOD,")
            sw.WriteLine("GLLD_TRANSREF,")
            sw.WriteLine("GLLD_LINENO,")
            sw.WriteLine("GLLD_TRANSDATE_TXT,")
            sw.WriteLine("GLLD_DUEDATE_TXT,")
            sw.WriteLine("GLLD_DESC,")
            sw.WriteLine("GLLD_O_ACCOUNT,")
            sw.WriteLine("GLLD_AMOUNT,")
            sw.WriteLine("GLLD_DRCR,")
            sw.WriteLine("GLLD_O_DEP_BRN,")
            sw.WriteLine("GLLD_O_PL_PT,")
            sw.WriteLine("GLLD_O_MKT_EMP,")
            sw.WriteLine("GLLD_O_PROJECT,")
            sw.WriteLine("GLLD_PAYMTH,")
            sw.WriteLine("GLLD_PAYEE,")
            sw.WriteLine("GLLD_S_ACCOUNT,")
            sw.WriteLine("GLLD_S_ACCNAME,")
            sw.WriteLine("GLLD_S_DEP_BRN,")
            sw.WriteLine("GLLD_S_PL_PT,")
            sw.WriteLine("GLLD_S_MKT_EMP,")
            sw.WriteLine("GLLD_S_TT_TR,")
            sw.WriteLine("GLLD_S_PROJECT,")
            sw.WriteLine("GLLD_DTSOURCE ""SUBSTR(:GLLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub PP_GenControlWHT(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                           ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (LOAD=" & lineCount & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_WHT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("TAXLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("TAXLD_CORE_SYSTEM " & "constant ""PP"",")
            'sw.WriteLine("TAXLD_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("TAXLD_LINENO,")
            sw.WriteLine("TAXLD_TAXID,")
            sw.WriteLine("TAXLD_IDCARD,")
            sw.WriteLine("TAXLD_AP_TTL,")
            sw.WriteLine("TAXLD_AP_FNAME,")
            sw.WriteLine("TAXLD_AP_LNAME,")
            sw.WriteLine("TAXLD_ADDRESS,")
            sw.WriteLine("TAXLD_AMPENM,")
            sw.WriteLine("TAXLD_PROVNM,")
            sw.WriteLine("TAXLD_AGZIP,")
            sw.WriteLine("TAXLD_TAXTYPE,")
            sw.WriteLine("TAXLD_TAXITEM,")
            sw.WriteLine("TAXLD_TAXDATE,")
            sw.WriteLine("TAXLD_BASE_AMT,")
            sw.WriteLine("TAXLD_TAX_AMT,")
            sw.WriteLine("TAXLD_PAYEE,")
            sw.WriteLine("TAXLD_TAX_RATE,")
            sw.WriteLine("TAXLD_DESC,")
            sw.WriteLine("TAXLD_GL_ACCOUNT,")
            sw.WriteLine("TAXLD_TRANSREF,")
            sw.WriteLine("TAXLD_RESERVE1,")
            sw.WriteLine("TAXLD_DTSOURCE ""SUBSTR(:TAXLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub TF_GenControlWHT(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                           ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (LOAD=" & lineCount & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_WHT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("TAXLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("TAXLD_CORE_SYSTEM " & "constant ""ACC"",")
            'sw.WriteLine("TAXLD_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("TAXLD_LINENO,")
            sw.WriteLine("TAXLD_TAXID,")
            sw.WriteLine("TAXLD_IDCARD,")
            sw.WriteLine("TAXLD_AP_TTL,")
            sw.WriteLine("TAXLD_AP_FNAME,")
            sw.WriteLine("TAXLD_AP_LNAME,")
            sw.WriteLine("TAXLD_ADDRESS,")
            sw.WriteLine("TAXLD_AMPENM,")
            sw.WriteLine("TAXLD_PROVNM,")
            sw.WriteLine("TAXLD_AGZIP,")
            sw.WriteLine("TAXLD_TAXTYPE,")
            sw.WriteLine("TAXLD_TAXITEM,")
            sw.WriteLine("TAXLD_TAXDATE,")
            sw.WriteLine("TAXLD_BASE_AMT,")
            sw.WriteLine("TAXLD_TAX_AMT,")
            sw.WriteLine("TAXLD_PAYEE,")
            sw.WriteLine("TAXLD_TAX_RATE,")
            sw.WriteLine("TAXLD_DESC,")
            sw.WriteLine("TAXLD_GL_ACCOUNT,")
            sw.WriteLine("TAXLD_TRANSREF,")
            sw.WriteLine("TAXLD_RESERVE1,")
            sw.WriteLine("TAXLD_DTSOURCE ""SUBSTR(:TAXLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub PP_LoadGPFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GPInfilePath, "GP")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        Console.WriteLine("  Total File: " & arr.Count - 1)
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            'controlfile = ControlPath & "GPCONTROL.ctl"
            controlfile = ControlPath & filename & ".ctl"
            infile = GPInfilePath & filename
            bkfile = GPBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = PP_ReadTextFile(infile, "|")

            PP_GenControlGP(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

            Console.WriteLine("  SqlLoader: " & i.ToString & ". " & filename.ToLower)
            chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)
            Console.WriteLine("  SqlLoader: " & i.ToString & ". " & filename.ToLower & " completed")

            Console.WriteLine("  BackupFile: " & i.ToString & ". " & infile)
            BackupFile(infile, bkfile, systemdate)
            Console.WriteLine("  BackupFile: " & i.ToString & ". " & infile & " completed")

        Next

        Console.WriteLine("  Update Value: ")
        If arr.Count >= 1 Then
            'Update Date Format
            PP_GP_UpdateFormatDate(systemdate)
            Console.WriteLine("    PP_GP_UpdateFormatDate: " & systemdate & " completed")
            'Update SubPayType
            PP_GP_UpdateSubPayType(systemdate)
            Console.WriteLine("    PP_GP_UpdateSubPayType: " & systemdate & " completed")
            'Update BankBranch
            PP_GP_UpdateBnkBrn(systemdate)
            Console.WriteLine("    PP_GP_UpdateBnkBrn: " & systemdate & " completed")
            'Update Flag_Track_Bill
            PP_GP_UpdateFlagFlwBill(systemdate)
            Console.WriteLine("    PP_GP_UpdateFlagFlwBill: " & systemdate & " completed")
            'Update Dep_KeyIn
            PP_GP_UpdateDeptKeyIn(systemdate)
            Console.WriteLine("PP_GP_UpdateDeptKeyIn: " & systemdate & " completed")
        End If


    End Sub
    Private Sub TF_LoadGPFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GPInfilePath, "TFGP")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            'controlfile = ControlPath & "GPCONTROL.ctl"
            controlfile = ControlPath & filename & ".ctl"
            infile = GPInfilePath & filename
            bkfile = GPBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = TF_ReadTextFile(infile, "|")

            TF_GenControlGP(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

            chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

            BackupFile(infile, bkfile, systemdate)

        Next

        If arr.Count >= 1 Then
            'Update Date Format
            TF_GP_UpdateFormatDate(systemdate)
            'Update SubPayType
            TF_GP_UpdateSubPayType(systemdate)
            'Update BankBranch
            TF_GP_UpdateBnkBrn(systemdate)
            'Update Flag_Track_Bill
            TF_GP_UpdateFlagFlwBill(systemdate)
            'Update Dep_KeyIn
            TF_GP_UpdateDeptKeyIn(systemdate)
        End If


    End Sub
    Private Sub PP_LoadGLFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GLInfilePath, "GL")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) <> "_TAX.TXT" Then

                'controlfile = ControlPath & "GLCONTROL.ctl"
                controlfile = ControlPath & filename & ".ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = PP_ReadTextFile(infile, "|")

                PP_GenControlGL(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

                chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

                BackupFile(infile, bkfile, systemdate)

            End If

        Next
        If arr.Count >= 1 Then
            'update ONE GL
            PP_GL_Update1GL(systemdate)
            'Update Journal Type
            PP_GL_UpdateJournalType(systemdate)
            'Update Format Date
            PP_GL_UpdateFormatDate(systemdate)
            'Update Dep KeyIn
            PP_GL_UpdateDeptKeyIn(systemdate)
        End If

    End Sub
    Private Sub TF_LoadGLFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GLInfilePath, "TFGL")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) <> "_TAX.TXT" Then

                'controlfile = ControlPath & "GLCONTROL.ctl"
                controlfile = ControlPath & filename & ".ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = TF_ReadTextFile(infile, "|")

                TF_GenControlGL(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

                chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

                BackupFile(infile, bkfile, systemdate)

            End If

        Next
        If arr.Count >= 1 Then
            'update ONE GL
            TF_GL_Update1GL(systemdate)
            'Update Journal Type
            TF_GL_UpdateJournalType(systemdate)
            'Update Format Date
            TF_GL_UpdateFormatDate(systemdate)
            'Update Dep KeyIn
            TF_GL_UpdateDeptKeyIn(systemdate)
        End If

    End Sub
    Private Sub PP_LoadWHTFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GLInfilePath, "GL")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) = "_TAX.TXT" Then


                'controlfile = ControlPath & "WHTCONTROL.ctl"
                controlfile = ControlPath & filename & ".ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = PP_ReadTextFile(infile, "|")

                PP_GenControlWHT(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

                chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

                BackupFile(infile, bkfile, systemdate)

            End If

        Next
        If arr.Count >= 1 Then
            'Update  GPTREF_SEQNO
            PP_WHT_UpdateGPTREF_SEQNO(systemdate)
            'Update Dept KeyIn
            PP_WHT_UpdateDeptKeyIn(systemdate)
            'Update 1GL
            PP_WHT_Update_1GL(systemdate)

        End If


    End Sub
    Private Sub TF_LoadWHTFile(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = GetInFileName(GLInfilePath, "TFGL")

        If arr.Count < 1 Then
            'MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) = "_TAX.TXT" Then


                'controlfile = ControlPath & "WHTCONTROL.ctl"
                controlfile = ControlPath & filename & ".ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = TF_ReadTextFile(infile, "|")

                TF_GenControlWHT(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)

                chkLoader = SqlLoader(controlfile.ToLower, systemdate, filename.ToLower)

                BackupFile(infile, bkfile, systemdate)

            End If

        Next
        If arr.Count >= 1 Then
            'Update  GPTREF_SEQNO
            TF_WHT_UpdateGPTREF_SEQNO(systemdate)
            'Update Dept KeyIn
            TF_WHT_UpdateDeptKeyIn(systemdate)
            'Update 1GL
            TF_WHT_Update_1GL(systemdate)

        End If


    End Sub
    Private Sub GenBatch(ByVal filename As String, ByVal desc As String)
        System.IO.File.Create(filename).Dispose()

        Dim sw As IO.StreamWriter = New IO.StreamWriter(filename, True)

        Try

            sw.WriteLine("SET NLS_LANG=THAI_THAILAND.TH8TISASCII ")
            sw.WriteLine(desc)
            'sw.WriteLine("Exit")

            sw.Close()

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub PP_GP_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET ")
        sb.Append("GPLD_PAIDDATE=TO_CHAR(TO_DATE(GPLD_PAIDDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD'),")
        sb.Append("GPLD_CDCARD_DATE=TO_CHAR(TO_DATE(GPLD_CDCARD_DATE,'DD/MM/YYYY'),'YYYYMMDD')")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
        Console.WriteLine("PP_GP_UpdateFormatDate: " & clsBusiness.gLastErrMessage)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
            Console.WriteLine("PP_GP_UpdateFormatDate: " & LoadDate & " commit")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
            Console.WriteLine("PP_GP_UpdateFormatDate: " & LoadDate & " rollback")
        End If


    End Sub
    Private Sub TF_GP_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET ")
        sb.Append("GPLD_PAIDDATE=TO_CHAR(TO_DATE(GPLD_PAIDDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD'),")
        sb.Append("GPLD_CDCARD_DATE=TO_CHAR(TO_DATE(GPLD_CDCARD_DATE,'DD/MM/YYYY'),'YYYYMMDD')")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateSubPayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_SUB_PAYMTH= ")
        sb.Append("CASE WHEN (GPLD_PAYMTH='C') THEN 'C'  ")
        sb.Append("WHEN (GPLD_PAYMTH='D') THEN 'D' ")
        sb.Append("WHEN (GPLD_PAYMTH='M' AND (UPPER(GPLD_RESERVE6) LIKE '%CREDIT CARD%' OR GPLD_RESERVE6 LIKE '%�ѵ��ôԵ%' )) THEN 'C' ")
        sb.Append("WHEN (GPLD_PAYMTH='M') THEN 'M' ")
        sb.Append("ELSE '' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_GP_UpdateSubPayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_SUB_PAYMTH= ")
        sb.Append("CASE WHEN (GPLD_PAYMTH='C') THEN 'C'  ")
        sb.Append("WHEN (GPLD_PAYMTH='D') THEN 'D' ")
        sb.Append("WHEN (GPLD_PAYMTH='M' AND (UPPER(GPLD_RESERVE6) LIKE '%CREDIT CARD%' OR GPLD_RESERVE6 LIKE '%�ѵ��ôԵ%' )) THEN 'C' ")
        sb.Append("WHEN (GPLD_PAYMTH='M') THEN 'M' ")
        sb.Append("ELSE '' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateBnkBrn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD P SET P.GPLD_BNKBRN= ")
        sb.Append("CASE WHEN GPLD_PAYMTH='C' OR GPLD_PAYMTH='D' THEN   ")
        sb.Append("(SELECT B.BNKS_BNKSBRN_CD FROM GPS_TL_PAYTYPE A INNER JOIN GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP ")
        sb.Append("WHERE A.PAYT_PAYMTH=P.GPLD_PAYMTH AND A.PAYT_SUB_PAYMTH=P.GPLD_SUB_PAYMTH) ")
        sb.Append("ELSE P.GPLD_BNKBRN END ")
        sb.Append("WHERE P.GPLD_BATCHDATE='" & LoadDate & "' AND P.GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_GP_UpdateBnkBrn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD P SET P.GPLD_BNKBRN= ")
        sb.Append("CASE WHEN GPLD_PAYMTH='C' OR GPLD_PAYMTH='D' THEN   ")
        sb.Append("(SELECT B.BNKS_BNKSBRN_CD FROM GPS_TL_PAYTYPE A INNER JOIN GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP ")
        sb.Append("WHERE A.PAYT_PAYMTH=P.GPLD_PAYMTH AND A.PAYT_SUB_PAYMTH=P.GPLD_SUB_PAYMTH) ")
        sb.Append("ELSE P.GPLD_BNKBRN END ")
        sb.Append("WHERE P.GPLD_BATCHDATE='" & LoadDate & "' AND P.GPLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateFlagFlwBill(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_FLWBILL =")
        sb.Append("CASE WHEN (GPLD_DESC LIKE '%�Թ���¤���Թ������ѭ%') THEN 'Y' ELSE 'N' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_GP_UpdateFlagFlwBill(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_FLWBILL =")
        sb.Append("CASE WHEN (GPLD_DESC LIKE '%�Թ���¤���Թ������ѭ%') THEN 'Y' ELSE 'N' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_PAYMENT_LOAD a ")
        sb.Append("SET (GPLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GPLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Private Sub TF_GP_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_PAYMENT_LOAD a ")
        sb.Append("SET (GPLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GPLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='ACC')")
        sb.Append("WHERE a.GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GPLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Private Sub PP_GL_UpdateJournalType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_LOAD SET ")
        sb.Append("GLLD_JN_TYPE='CP' ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub

    Private Sub PP_GL_Update1GL(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("update generatepayment.gps_gl_load t ")
        sb.Append("   set t.glld_ref_6 = t.glld_s_mkt_emp ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        sb.Clear()
        sb.Append("update generatepayment.gps_gl_load t ")
        sb.Append("   set t.glld_s_account = substr(t.glld_s_account, 1, 7) ")
        sb.Append("     , t.glld_conversion_date = substr(t.glld_transdate_txt, 7, 4) || '-' || substr(t.glld_transdate_txt, 4, 2) || '-' || substr(t.glld_transdate_txt, 1, 2)")
        sb.Append("     , t.glld_sub_acct = substr(t.glld_s_account, 8, 7) ")
        sb.Append("     , t.glld_s_dep_brn = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'DEPB' and a.anl_s_code = t.glld_s_dep_brn ) ")
        sb.Append("     , t.glld_s_pl_pt = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'PLPT' and a.anl_s_code = t.glld_s_pl_pt ) ")
        sb.Append("     , t.glld_s_mkt_emp = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'MKTG' and a.anl_s_code = t.glld_s_mkt_emp ) ")
        sb.Append("     , t.glld_s_project = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'PROJ' and a.anl_s_code = t.glld_s_project ) ")
        sb.Append("     , t.glld_to_ledger = 'GCOMN' ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub


    Private Sub TF_GL_Update1GL(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("update generatepayment.gps_gl_load t ")
        sb.Append("   set t.glld_ref_6 = t.glld_s_mkt_emp ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        sb.Clear()
        sb.Append("update generatepayment.gps_gl_load t ")
        sb.Append("   set t.glld_s_account = substr(t.glld_s_account, 1, 7) ")
        sb.Append("     , t.glld_sub_acct = substr(t.glld_s_account, 8, 7) ")
        sb.Append("     , t.glld_conversion_date = substr(t.glld_transdate_txt, 7, 4) || '-' || substr(t.glld_transdate_txt, 4, 2) || '-' || substr(t.glld_transdate_txt, 1, 2)")
        sb.Append("     , t.glld_s_dep_brn = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'DEPB' and a.anl_s_code = t.glld_s_dep_brn ) ")
        sb.Append("     , t.glld_s_pl_pt = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'PLPT' and a.anl_s_code = t.glld_s_pl_pt ) ")
        sb.Append("     , t.glld_s_mkt_emp = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'MKTG' and a.anl_s_code = t.glld_s_mkt_emp ) ")
        sb.Append("     , t.glld_s_project = (select a.anl_1gl_code from generatepayment.glm_anlcode_setup a where a.anl_type = 'PROJ' and a.anl_s_code = t.glld_s_project ) ")
        sb.Append("     , t.glld_to_ledger = 'GCOMN' ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub

    Private Sub TF_GL_UpdateJournalType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_LOAD SET ")
        sb.Append("GLLD_JN_TYPE='CD' ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GL_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_LOAD SET ")
        sb.Append("GLLD_TRANSDATE=TO_CHAR(TO_DATE(GLLD_TRANSDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD'),")
        sb.Append("GLLD_DUEDATE=TO_CHAR(TO_DATE(GLLD_DUEDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD') ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_GL_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_LOAD SET ")
        sb.Append("GLLD_TRANSDATE=TO_CHAR(TO_DATE(GLLD_TRANSDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD'),")
        sb.Append("GLLD_DUEDATE=TO_CHAR(TO_DATE(GLLD_DUEDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD') ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GL_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_GL_LOAD a ")
        sb.Append("SET (GLLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GLLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_GL_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_GL_LOAD a ")
        sb.Append("SET (GLLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GLLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='ACC')")
        sb.Append("WHERE a.GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GLLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_WHT_UpdateGPTREF_SEQNO(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_GPTREF_SEQNO) = ( ")
        sb.Append("SELECT GPLD_GPTREF_SEQNO ")
        sb.Append("FROM GPS_PAYMENT_LOAD b ")
        sb.Append("WHERE a.TAXLD_BATCHDATE = b.GPLD_BATCHDATE ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM=b.GPLD_CORE_SYSTEM ")
        sb.Append("AND a.TAXLD_TRANSREF=b.GPLD_TRANSREF ")
        sb.Append("AND a.TAXLD_RESERVE1=b.GPLD_RESERVE9) ")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_WHT_UpdateGPTREF_SEQNO(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_GPTREF_SEQNO) = ( ")
        sb.Append("SELECT GPLD_GPTREF_SEQNO ")
        sb.Append("FROM GPS_PAYMENT_LOAD b ")
        sb.Append("WHERE a.TAXLD_BATCHDATE = b.GPLD_BATCHDATE ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM=b.GPLD_CORE_SYSTEM ")
        sb.Append("AND a.TAXLD_TRANSREF=b.GPLD_TRANSREF ")
        sb.Append("AND a.TAXLD_RESERVE1=b.GPLD_RESERVE9) ")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_WHT_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.TAXLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='PP' ")
        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub TF_WHT_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.TAXLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='ACC')")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='ACC' ")
        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub

    Private Sub PP_WHT_Update_1GL(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("   set a.taxld_sub_acct = substr(a.taxld_gl_account, 8, 7) ")
        sb.Append("     , a.taxld_gl_account = substr(a.taxld_gl_account, 1, 7) ")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub

    Private Sub TF_WHT_Update_1GL(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("        a.taxld_sub_acct = substr(a.taxld_gl_account, 8, 7) ")
        sb.Append("  , a.taxld_gl_account = substr(a.taxld_gl_account, 1, 7) ")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='ACC' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Function SendEmailSCBLife(ByVal mailfuction As String) As String
        Dim Email As New MailMessage()
        Try
            Dim SMTPServer As New SmtpClient

            'For Each Attachment As String In Attachments
            '    Email.Attachments.Add(New Attachment(Attachment))
            'Next
            'Email.From = New MailAddress("AutomaticValidateReject@scblife.com")
            'For Each Recipient As String In Recipients
            '    Email.To.Add(Recipient)
            'Next

            'For Each CC As String In CCs
            '    If Trim(CC) <> "" Then
            '        Email.CC.Add(CC)
            '    End If
            'Next

            Email.From = New MailAddress("AutomaticValidateReject@scblife.com")

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    Email.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

            End If
            Email.Subject = "Reject Payment Transaction by Validation  [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
            Email.Body = "����������¡�è������١��ͧ (Error by Validation) ú�ǹ��Ǩ�ͺ��� path : " & ValidationReportPath
            SMTPServer.Host = "mailsmtp.scnyl.local"
            SMTPServer.Port = 25
            ''SMTPServer.Credentials = New System.Net.NetworkCredential(UserName, Password)
            ''SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()
            Return "Complete"
        Catch ex As SmtpException
            Email.Dispose()
            Return "Sending Email Failed. Smtp Error."
        Catch ex As ArgumentOutOfRangeException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        Catch Ex As InvalidOperationException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        End Try
    End Function
    Function SendEmailScbl(ByVal FromAddress As String, _
                      ByVal Recipients As List(Of String), _
                      ByVal CCs As List(Of String), _
                      ByVal Subject As String, _
                      ByVal Body As String, _
                      Optional ByVal Server As String = "mailsmtp.scnyl.local", _
                      Optional ByVal Port As Integer = 25, _
                      Optional ByVal Attachments As List(Of String) = Nothing) As String
        Dim Email As New MailMessage()
        Try
            Dim SMTPServer As New SmtpClient
            For Each Attachment As String In Attachments
                Email.Attachments.Add(New Attachment(Attachment))
            Next
            Email.From = New MailAddress(FromAddress)
            For Each Recipient As String In Recipients
                Email.To.Add(Recipient)
            Next
            For Each CC As String In CCs
                If Trim(CC) <> "" Then
                    Email.CC.Add(CC)
                End If
            Next
            Email.Subject = Subject
            Email.Body = Body
            SMTPServer.Host = Server
            SMTPServer.Port = Port
            ''SMTPServer.Credentials = New System.Net.NetworkCredential(UserName, Password)
            ''SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()
            Return "Complete"
        Catch ex As SmtpException
            Email.Dispose()
            Return "Sending Email Failed. Smtp Error."
        Catch ex As ArgumentOutOfRangeException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        Catch Ex As InvalidOperationException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        End Try
    End Function
    Function GetEmail(ByVal mailfuction As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""
        sb.Append("SELECT EMAIL_ADDRESS FROM GPS_EMAIL_SETUP WHERE EMAIL_FUNC='" & mailfuction & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function
    Private Sub SendEmail(ByVal mailfuction As String)
        Try

            Dim Smtp_Server As New Net.Mail.SmtpClient
            Dim e_mail As New Net.Mail.MailMessage()
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential("AutomaticValidateReject@scblife.com", "")
            Smtp_Server.Port = 25
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "MAILSMTP.SCNYL.LOCAL"

            Dim txtFrom As String
            Dim txtMessage As String

            txtFrom = "AutomaticMediaReject@scblife.com"
            txtMessage = "����������¡�è������١��ͧ (Error by Validation) ú�ǹ��Ǩ�ͺ��� path : " & sReportPath

            e_mail = New Net.Mail.MailMessage()
            e_mail.From = New Net.Mail.MailAddress(txtFrom)

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    e_mail.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

                'e_mail.CC.Add("AutomaticValidateReject@scblife.com")
                e_mail.Subject = "Reject Payment Transaction by Validation  [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
                e_mail.IsBodyHtml = False
                e_mail.Body = txtMessage

                Smtp_Server.Send(e_mail)
                'MsgBox("Mail Sent")

            End If

        Catch error_t As Exception
            'MsgBox(error_t.ToString)
        End Try
    End Sub
    Function ValidateData(ByVal systemdate) As Boolean
        Dim ret As Integer

        ret = Call_GPS_SP_VALIDATE_AUTO(systemdate)

        If ret >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function ValidateData_OLD(ByVal systemdate) As Boolean

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Function
            End If
        End If

        Dim TOTAL_REC As Integer
        Dim PAMT_NOMAT As Integer
        Dim PDTE_NOMAT As Integer
        Dim DUPT_ERR As Integer
        Dim TAMT_NOMAT As Integer
        Dim TREF_ERR As Integer
        Dim WLST_ERR As Integer
        Dim CHAR_ERR As Integer
        Dim PDTE_ERR As Integer
        Dim PAMT_ERR As Integer
        Dim BKCD_ERR As Integer
        Dim BKAC_ERR As Integer
        Dim ACNM_ERR As Integer
        Dim PAYEE_ERR As Integer
        Dim LENGT_ERR As Integer
        Dim ADDR_ERR As Integer
        Dim MCHN_ERR As Integer
        Dim NB_CANCEL As Integer
        Dim status As String
        Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

        '--------------fValidateNetAmountNotMatch--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAMT_NOMAT = Validate_1(clsUtility.gConnGP_2, oleTrans, systemdate, "PAMT_NOMAT")
        TOTAL_REC = PAMT_NOMAT
        If PAMT_NOMAT = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatePaidDateNotMatch--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PDTE_NOMAT = Validate_2(clsUtility.gConnGP_2, oleTrans, systemdate, "PDTE_NOMAT")
        TOTAL_REC = TOTAL_REC + PDTE_NOMAT
        If PDTE_NOMAT = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateDuplicateTransRef--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        DUPT_ERR = Validate_3(clsUtility.gConnGP_2, oleTrans, systemdate, "DUPT_ERR")
        TOTAL_REC = TOTAL_REC + DUPT_ERR
        If DUPT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)
        ''--------------fValidateWHTAmountNotMatch--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        TAMT_NOMAT = Validate_4(clsUtility.gConnGP_2, oleTrans, systemdate, "TAMT_NOMAT")
        TOTAL_REC = TOTAL_REC + TAMT_NOMAT
        If TAMT_NOMAT = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateTransrefError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        TREF_ERR = Validate_5(clsUtility.gConnGP_2, oleTrans, systemdate, "TREF_ERR")
        TOTAL_REC = TOTAL_REC + TREF_ERR
        If TREF_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidatWatchLists--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        WLST_ERR = Validate_6(clsUtility.gConnGP_2, oleTrans, systemdate, "WLST_ERR")
        TOTAL_REC = TOTAL_REC + WLST_ERR
        If WLST_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatSpecialCharacterError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        CHAR_ERR = Validate_7(clsUtility.gConnGP_2, oleTrans, systemdate, "CHAR_ERR")
        TOTAL_REC = TOTAL_REC + CHAR_ERR
        If CHAR_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatePaidDateError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PDTE_ERR = Validate_8(clsUtility.gConnGP_2, oleTrans, systemdate, "PDTE_ERR")
        TOTAL_REC = TOTAL_REC + PDTE_ERR
        If PDTE_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatePaidAmountError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAMT_ERR = Validate_9(clsUtility.gConnGP_2, oleTrans, systemdate, "PAMT_ERR")
        TOTAL_REC = TOTAL_REC + PAMT_ERR
        If PAMT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateBankCodeError--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'BKCD_ERR = Validate_10(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        'TOTAL_REC = TOTAL_REC + BKCD_ERR
        'If BKCD_ERR = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()
        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()
        'End If

        'clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        'InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        '------------Pattamalin 2015/02/02 ��� Validate BKAC_ERR ��͹ BKCD_ERR���������������

        '--------------fValidateBankAccountError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        BKAC_ERR = Validate_11(clsUtility.gConnGP_2, oleTrans, systemdate, "BKAC_ERR")
        TOTAL_REC = TOTAL_REC + BKAC_ERR
        If BKAC_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        '--------------fValidateBankCodeError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        BKCD_ERR = Validate_10_1(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        TOTAL_REC = TOTAL_REC + BKCD_ERR
        If BKCD_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        '--------------fValidateBankCodeError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        BKCD_ERR = Validate_10_2(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        TOTAL_REC = TOTAL_REC + BKCD_ERR
        If BKCD_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)




        '--------------fValidateBankAccountNameError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        ACNM_ERR = Validate_12(clsUtility.gConnGP_2, oleTrans, systemdate, "ACNM_ERR")
        TOTAL_REC = TOTAL_REC + ACNM_ERR
        If ACNM_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        '--------------fValidatePayeeNameError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAYEE_ERR = Validate_13(clsUtility.gConnGP_2, oleTrans, systemdate, "PAYEE_ERR")
        TOTAL_REC = TOTAL_REC + PAYEE_ERR
        If PAYEE_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)
        '--------------fValidatePayeeLengthFieldError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        LENGT_ERR = Validate_14(clsUtility.gConnGP_2, oleTrans, systemdate, "LENGT_ERR")
        TOTAL_REC = TOTAL_REC + LENGT_ERR
        If LENGT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)
        '--------------fValidateAddressError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        ADDR_ERR = Validate_15(clsUtility.gConnGP_2, oleTrans, systemdate, "ADDR_ERR")
        TOTAL_REC = TOTAL_REC + ADDR_ERR
        If ADDR_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)
        '--------------fValidateMerchantError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        MCHN_ERR = Validate_16(clsUtility.gConnGP_2, oleTrans, systemdate, "MCHN_ERR")
        TOTAL_REC = TOTAL_REC + MCHN_ERR
        If MCHN_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)
        ''--------------fValidateNBCancel--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        NB_CANCEL = Validate_17(clsUtility.gConnGP_2, oleTrans, systemdate, "NB_CANCEL")
        TOTAL_REC = TOTAL_REC + NB_CANCEL
        If NB_CANCEL = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()
        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()
        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)


        If TOTAL_REC = 18 Then
            'oleTrans.Commit()
            Return True
        Else
            'oleTrans.Rollback()
            Return False
        End If

    End Function
    Function Validate_1(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateNetAmountNotMatch(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows

                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_2(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidDateNotMatch(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_3(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim dt2 As New DataTable
        Dim r_payment As Integer
        Dim i_chk As Integer
        Dim r_wht As Integer
        dt = cls.fValidateDuplicateTransRef_1(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                dt2 = cls.fValidateDuplicateTransRef_2(clsUtility.gConnGP, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                If Not IsNothing(dt2) AndAlso dt2.Rows.Count > 0 Then

                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
                    i_chk = i_chk + 1

                Else
                    Return 1
                End If

            Next

            If (r_payment = i_chk) And (r_wht = i_chk) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_4(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateWHTAmountNotMatch(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_5(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateTransrefError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_6(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim cwl, caml As Boolean

        cwl = CallAML(batchdate, errtype)
        caml = CallAML(batchdate, errtype)

        If cwl And caml Then
            Return 1
        Else
            Return 0
        End If


    End Function
    Function Validate_6_OLD(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_rej As Integer
        Dim r_aml As Integer
        Dim i_rej As Integer
        Dim i_aml As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer

        dt = cls.fValidatWatchLists(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            For Each dr As DataRow In dt.Rows

                'Data Reject 
                Dim dt_wl As New DataTable
                dt_wl = cls.CHECK_WATCHLIST_FOR_REJ(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString.Replace(" ", ""))


                'Data AML
                Dim dt_aml As New DataTable
                dt_aml = cls.CHECK_WATCHLIST_FOR_AML(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString.Replace(" ", ""))


                If Not IsNothing(dt_wl) AndAlso dt_wl.Rows.Count > 0 Then


                    Dim chk_effdate As Boolean
                    chk_effdate = cls.CHECK_WATCHLIST_EFFDATE(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString, batchdate)


                    If chk_effdate = False Then


                        r_rej = r_rej + cls.UPD_WATCHLIST_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"), dt_wl.Rows(0)("WLSTT_TYPE"), dt_wl.Rows(0)("WLST_SUBTYPE_CODE"))
                        i_rej = i_rej + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1

                    End If

                End If


                If Not IsNothing(dt_aml) AndAlso dt_aml.Rows.Count > 0 Then

                    r_aml = r_aml + cls.UPD_WATCHLIST_AML(oConn, oleTrans, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"), dt_aml.Rows(0)("WLSTT_TYPE"), dt_aml.Rows(0)("WLST_SUBTYPE_CODE"))
                    i_aml = i_aml + 1

                End If

            Next

            If (r_rej = i_rej) And (r_aml = i_aml) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

        Return 1
    End Function
    Function Validate_7(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim dt_char As New DataTable
        Dim r_err As Integer
        dt = cls.fValidatSpecialCharacterError(clsUtility.gConnGP)
        dt_char = cls.GetSpecialCharacter(clsUtility.gConnGP)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim txt_payeename As String
                Dim txt_address As String
                Dim txt_district As String
                Dim txt_province As String
                Dim txt_payee_bnkname As String

                txt_payeename = dr("GP_PAYEE_NAME").ToString.Trim
                txt_address = dr("GP_ADDRESS1").ToString.Trim
                txt_district = dr("GP_DISTRICT").ToString.Trim
                txt_province = dr("GP_PROVINCE").ToString.Trim
                txt_payee_bnkname = dr("GP_PAYEE_BNKACCNME").ToString.Trim

                For Each dr_char As DataRow In dt_char.Rows
                    If InStr(txt_payeename, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_payeename = txt_payeename.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PAYEE_NAME", txt_payeename, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_address, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_address = txt_address.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_ADDRESS1", txt_address, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_district, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_district = txt_district.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_DISTRICT", txt_district, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_province, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_province = txt_province.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PROVINCE", txt_province, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_payee_bnkname, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_payee_bnkname = txt_payee_bnkname.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PAYEE_BNKACCNME", txt_payee_bnkname, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                Next
            Next

            If (r_err >= 0) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_8(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim i_payment As Integer
        Dim i_wht As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidDateError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                If CheckDate(dr("GP_PAIDDATE"), batchdate) Then


                    Dim format As String = "yyyyMMdd"
                    Dim DueDate As Date
                    DueDate = Date.ParseExact(dr("GP_PAIDDATE"), format, New Globalization.CultureInfo("en-US"))

                    If GetWorkDay(DueDate) Then
                        Select Case dr("PAYT_PAY_GROUP")
                            Case "SCB_NET"
                                If Convert.ToInt32(dr("GP_PAIDDATE")) > Convert.ToInt32(batchdate) Then
                                    Dim chk_holiday As Boolean
                                    chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                    If chk_holiday Then
                                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_payment += 1

                                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_wht = i_wht + 1

                                    End If
                                Else
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1
                                End If
                            Case "SCBLIFE_CHQ"
                                If Convert.ToInt32(dr("GP_PAIDDATE")) < Convert.ToInt32(batchdate) Then
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1
                                End If

                            Case "OVERSEA"
                                If Convert.ToInt32(dr("GP_PAIDDATE")) >= Convert.ToInt32(batchdate) Then
                                    Dim chk_holiday As Boolean
                                    chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                    If chk_holiday Then
                                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_payment += 1

                                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_wht = i_wht + 1

                                    End If
                                Else
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1
                                End If
                            Case "ATS", "CREDIT_CARD"
                                If Convert.ToInt32(dr("GP_PAIDDATE")) > Convert.ToInt32(batchdate) Then
                                    Dim chk_holiday As Boolean
                                    chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                    If chk_holiday Then
                                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_payment += 1

                                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                        i_wht = i_wht + 1

                                    End If
                                Else
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1
                                End If

                        End Select
                    Else 'Saturday Sunday
                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_payment += 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1
                    End If
                Else 'format <> "CCYYYMMDD" 
                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_payment += 1

                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_wht = i_wht + 1
                End If

            Next

            If (r_payment = i_payment) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_9(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidAmountError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))

            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_10_1(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim v1, v2 As Integer

        v1 = cls.UPD_VALIDATE10_1(oConn, oleTrans, errtype)
        v2 = cls.UPD_VALIDATE10_2(oConn, oleTrans, errtype)

        If (v1 = 1 And v2 = 1) Then
            ' oleTrans.Commit()
            Return 1
        Else
            'oleTrans.Rollback()
            clsBusiness.gLastErrMessage = errtype
            Return 0
        End If


    End Function
    Function Validate_10_2(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim v3, v4 As Integer

        v3 = cls.UPD_VALIDATE10_3(oConn, oleTrans, errtype)
        v4 = cls.UPD_VALIDATE10_4(oConn, oleTrans, errtype)

        If (v3 = 1 And v4 = 1) Then
            ' oleTrans.Commit()
            Return 1
        Else
            'oleTrans.Rollback()
            clsBusiness.gLastErrMessage = errtype
            Return 0
        End If


    End Function
    Function Validate_10_OLD(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankCodeError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim chk As Boolean
                chk = cls.CHK_BKMST_BNKCODE(clsUtility.gConnGP, dr("GP_BNKCODE_NO").ToString)
                If chk Then

                    If dr("GP_PAYMTH") = "C" Or dr("GP_PAYMTH") = "D" Then
                        Dim chk2 As Boolean
                        chk2 = cls.CHK_BNKS_BNKSCODE_NO(clsUtility.gConnGP, dr("PAYT_PAY_GROUP"), dr("GP_BNKCODE_NO"))

                        If chk2 = False Then

                            'MsgBox("CHK_BNKS_BNKSCODE_NO" & "/" & dr("PAYT_PAY_GROUP") & "/" & dr("GP_BNKCODE_NO"))

                            r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            c_err += 1

                            r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            i_wht = i_wht + 1

                            'Dim s_systemtime As String
                            's_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
                            'clsBusiness.gLastErrMessage = "CHK_BNKS_BNKSCODE_NO" & "/" & dr("PAYT_PAY_GROUP") & "/" & dr("GP_BNKCODE_NO")
                            'InsertTransLog("AUTO BATCH", Now.ToString("yyyyMMdd"), "", s_systemtime, "INCOMPLETE", 0)
                        End If
                    End If

                Else
                    'MsgBox("CHK_BKMST_BNKCODE" & "/" & dr("GP_BNKCODE_NO").ToString)

                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    c_err += 1

                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_wht = i_wht + 1


                    'Dim s_systemtime As String
                    's_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
                    'clsBusiness.gLastErrMessage = "CHK_BKMST_BNKCODE" & "/" & dr("GP_BNKCODE_NO").ToString
                    'InsertTransLog("AUTO BATCH", Now.ToString("yyyyMMdd"), "", s_systemtime, "INCOMPLETE", 0)

                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_11(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankAccountError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_12(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankAccountNameError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                If dr("GP_PAYMTH") = "M" Then
                    If dr("GP_PAYEE_BNKACCNME").ToString.Trim = "" Or IsDBNull(dr("GP_PAYEE_BNKACCNME")) Then
                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        c_err = c_err + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1

                    End If
                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_13(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidatePayeeNameError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                If dr("GP_PAYMTH") = "C" Or dr("GP_PAYMTH") = "D" Then
                    If dr("GP_PAYEE_NAME").ToString.Trim = "" Or IsDBNull(dr("GP_PAYEE_NAME")) Then
                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        c_err = c_err + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1
                    End If
                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_14(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidatePayeeLengthFieldError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_15(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateAddressError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim pay_subpay As String
                pay_subpay = dr("GP_PAYMTH") & ":" & dr("GP_SUB_PAYMTH")
                Select Case pay_subpay
                    Case "D:D"
                        If dr("ADDRESS").ToString.Trim = "" Or IsDBNull(dr("ADDRESS")) Then
                            r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            c_err += 1

                            r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            i_wht = i_wht + 1
                        End If
                End Select

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_16(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateMerchantError(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_17(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateNBCancel(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
End Class