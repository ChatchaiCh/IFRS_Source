<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmBatch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnTLM = New System.Windows.Forms.Button()
        Me.btnPP = New System.Windows.Forms.Button()
        Me.btnRunBatch = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnTLM
        '
        Me.btnTLM.Location = New System.Drawing.Point(27, 70)
        Me.btnTLM.Name = "btnTLM"
        Me.btnTLM.Size = New System.Drawing.Size(122, 23)
        Me.btnTLM.TabIndex = 2
        Me.btnTLM.Text = "Call TLM"
        Me.btnTLM.UseVisualStyleBackColor = True
        Me.btnTLM.Visible = False
        '
        'btnPP
        '
        Me.btnPP.Location = New System.Drawing.Point(212, 70)
        Me.btnPP.Name = "btnPP"
        Me.btnPP.Size = New System.Drawing.Size(122, 23)
        Me.btnPP.TabIndex = 3
        Me.btnPP.Text = "Call PP"
        Me.btnPP.UseVisualStyleBackColor = True
        Me.btnPP.Visible = False
        '
        'btnRunBatch
        '
        Me.btnRunBatch.Location = New System.Drawing.Point(27, 29)
        Me.btnRunBatch.Name = "btnRunBatch"
        Me.btnRunBatch.Size = New System.Drawing.Size(307, 23)
        Me.btnRunBatch.TabIndex = 4
        Me.btnRunBatch.Text = "Run Batch"
        Me.btnRunBatch.UseVisualStyleBackColor = True
        Me.btnRunBatch.Visible = False
        '
        'FrmBatch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(367, 101)
        Me.Controls.Add(Me.btnRunBatch)
        Me.Controls.Add(Me.btnPP)
        Me.Controls.Add(Me.btnTLM)
        Me.Name = "FrmBatch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GP Stand Alone AutoBatch"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnTLM As System.Windows.Forms.Button
    Friend WithEvents btnPP As System.Windows.Forms.Button
    Friend WithEvents btnRunBatch As System.Windows.Forms.Button
End Class
