Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmAutoBatch
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim MsgLoader As String
    Private Sub FrmAutoBatch_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                'Return exit code to batch
                Environment.ExitCode = 2

                Exit Sub
            End If
        End If
    End Sub
    Function PP_GetInFileName(ByVal filepath As String, ByVal filetype As String) As ArrayList

        Dim lst As New ArrayList
        Dim filename As String = ""

        Dim di As New DirectoryInfo(filepath)
        Dim diar As FileInfo() = di.GetFiles(filetype & "*", SearchOption.AllDirectories)
        Dim dra As FileInfo
        For Each dra In diar
            '.Add(dra)
            '.Add(dra.FullName)
            'lst.Add(dra.ToString.Substring(dra.ToString.Length - 8, 4))
            lst.Add(dra)
        Next

        Return lst

    End Function
    Public Function PP_ReadTextFile(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Try

            CurrentRow = TextFileReader.ReadFields()

            If Not CurrentRow Is Nothing Then
                If dtD Is Nothing Then
                    dtD = New DataTable("dt")

                    dtD.Columns.Add("H_DATE")
                    dtD.Columns.Add("H_TOT_AMT")


                End If

                Row = dtD.NewRow
                Row.Item(0) = CurrentRow(0).ToString.Trim
                Row.Item(1) = CurrentRow(1).ToString.Trim

                dtD.Rows.Add(Row)


            End If
        Catch ex As _
        Microsoft.VisualBasic.FileIO.MalformedLineException
            MsgBox("Line " & ex.Message & _
            "is not valid and will be skipped.")

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try

        TextFileReader.Dispose()

        Return dtD

    End Function
    Private Sub PP_GenControlGP(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_PAYMENT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GPLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GPLD_CORE_SYSTEM " & "constant ""PP"",")
            '��� Running ����� sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(MAX, 1) ,")
            sw.WriteLine("GPLD_GPTREF_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("GPLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GPLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GPLD_FILENAME " & "constant """ & filename & """,")
            sw.WriteLine("GPLD_TRANSREF,")
            sw.WriteLine("GPLD_POLNO,")
            sw.WriteLine("GPLD_BILLNO,")
            sw.WriteLine("GPLD_PAIDDATE_TXT,")
            sw.WriteLine("GPLD_AMOUNT,")
            sw.WriteLine("GPLD_DESC,")
            sw.WriteLine("GPLD_PAYMTH,")
            sw.WriteLine("GPLD_PAYEE_NAME,")
            sw.WriteLine("GPLD_BNKCODE_NO,")
            sw.WriteLine("GPLD_BNKBRN,")
            sw.WriteLine("GPLD_BNKNAME,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNO,")
            sw.WriteLine("GPLD_PAYEE_BNKACCNME,")
            sw.WriteLine("GPLD_COMMENT,")
            sw.WriteLine("GPLD_ADDRESS1,")
            sw.WriteLine("GPLD_DISTRICT,")
            sw.WriteLine("GPLD_PROVINCE,")
            sw.WriteLine("GPLD_INSURENAME,")
            sw.WriteLine("GPLD_DATASOURCE_NME,")
            sw.WriteLine("GPLD_RESERVE6,")
            sw.WriteLine("GPLD_MERCHN_NO,")
            sw.WriteLine("GPLD_CDCARD_DATE,")
            sw.WriteLine("GPLD_RESERVE9,")
            sw.WriteLine("GPLD_RESERVE10,")
            sw.WriteLine("GPLD_SYS_REF,")
            sw.WriteLine("GPLD_SYS_GR,")
            sw.WriteLine("GPLD_DTSOURCE ""SUBSTR(:GPLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub
    Private Sub PP_GenControlGL(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                             ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (SKIP=1,LOAD=" & lineCount - 2 & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_GL_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("GLLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("GLLD_CORE_SYSTEM " & "constant ""PP"",")
            sw.WriteLine("GLLD_H_DATE " & "constant """ & H_DATE & """,")
            sw.WriteLine("GLLD_H_TOT_AMT " & "constant """ & H_AMT & """,")
            sw.WriteLine("GLLD_JN_TYPE,")
            sw.WriteLine("GLLD_JN_SOURCE,")
            sw.WriteLine("GLLD_B_UNIT,")
            sw.WriteLine("GLLD_GL_PERIOD,")
            sw.WriteLine("GLLD_TRANSREF,")
            sw.WriteLine("GLLD_LINENO,")
            sw.WriteLine("GLLD_TRANSDATE_TXT,")
            sw.WriteLine("GLLD_DUEDATE_TXT,")
            sw.WriteLine("GLLD_DESC,")
            sw.WriteLine("GLLD_O_ACCOUNT,")
            sw.WriteLine("GLLD_AMOUNT,")
            sw.WriteLine("GLLD_DRCR,")
            sw.WriteLine("GLLD_O_DEP_BRN,")
            sw.WriteLine("GLLD_O_PL_PT,")
            sw.WriteLine("GLLD_O_MKT_EMP,")
            sw.WriteLine("GLLD_O_PROJECT,")
            sw.WriteLine("GLLD_PAYMTH,")
            sw.WriteLine("GLLD_PAYEE,")
            sw.WriteLine("GLLD_S_ACCOUNT,")
            sw.WriteLine("GLLD_S_ACCNAME,")
            sw.WriteLine("GLLD_S_DEP_BRN,")
            sw.WriteLine("GLLD_S_PL_PT,")
            sw.WriteLine("GLLD_S_MKT_EMP,")
            sw.WriteLine("GLLD_S_TT_TR,")
            sw.WriteLine("GLLD_S_PROJECT,")
            sw.WriteLine("GLLD_DTSOURCE ""SUBSTR(:GLLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub
    Private Sub PP_GenControlWHT(ByVal SystemDate As String, ByVal control As String, ByVal infile As String, ByVal filename As String, _
                           ByVal delimited As String, ByVal H_DATE As String, ByVal H_AMT As String, ByVal lineCount As Integer)
        Dim sw As IO.StreamWriter = New IO.StreamWriter(control)
        Try

            sw.WriteLine("OPTIONS (LOAD=" & lineCount & ")")
            sw.WriteLine("LOAD DATA")
            sw.WriteLine("INFILE '" & infile & "'")
            sw.WriteLine("APPEND") 'APPEND,TRUNCATE
            sw.WriteLine("INTO TABLE GPS_WHT_LOAD ")
            'sw.WriteLine("WHEN (GPLD_TRANSREF != 'T')  ")
            sw.WriteLine("FIELDS TERMINATED BY '" & delimited & "' OPTIONALLY ENCLOSED BY '""' ")
            sw.WriteLine("TRAILING NULLCOLS")

            sw.WriteLine("(")
            sw.WriteLine("TAXLD_BATCHDATE " & "constant """ & SystemDate & """,")
            sw.WriteLine("TAXLD_CORE_SYSTEM " & "constant ""PP"",")
            'sw.WriteLine("TAXLD_SEQNO SEQUENCE(1, 1) ,")
            sw.WriteLine("TAXLD_LINENO,")
            sw.WriteLine("TAXLD_TAXID,")
            sw.WriteLine("TAXLD_IDCARD,")
            sw.WriteLine("TAXLD_AP_TTL,")
            sw.WriteLine("TAXLD_AP_FNAME,")
            sw.WriteLine("TAXLD_AP_LNAME,")
            sw.WriteLine("TAXLD_ADDRESS,")
            sw.WriteLine("TAXLD_AMPENM,")
            sw.WriteLine("TAXLD_PROVNM,")
            sw.WriteLine("TAXLD_AGZIP,")
            sw.WriteLine("TAXLD_TAXTYPE,")
            sw.WriteLine("TAXLD_TAXITEM,")
            sw.WriteLine("TAXLD_TAXDATE,")
            sw.WriteLine("TAXLD_BASE_AMT,")
            sw.WriteLine("TAXLD_TAX_AMT,")
            sw.WriteLine("TAXLD_PAYEE,")
            sw.WriteLine("TAXLD_TAX_RATE,")
            sw.WriteLine("TAXLD_DESC,")
            sw.WriteLine("TAXLD_GL_ACCOUNT,")
            sw.WriteLine("TAXLD_TRANSREF,")
            sw.WriteLine("TAXLD_RESERVE1,")
            sw.WriteLine("TAXLD_DTSOURCE ""SUBSTR(:TAXLD_TRANSREF,1,3)"",")
            sw.WriteLine("CREATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("CREATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""" + ",")
            sw.WriteLine("UPDATEDBY  " & "constant ""SYSTEM""" + ",")
            sw.WriteLine("UPDATEDDATE EXPRESSION " & """TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')""")
            sw.WriteLine(")")

            sw.Close()

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub
    Function SqlLoader(ByVal control As String) As Boolean
        'Dim pw As String
        'pw = SPI_BATCH.Decrypt(strDatabasePassword)

        'Call Web Service
        Dim pw As String
        pw = "generatepayment"
        'Dim objService As New wsClsUtility.clsUtility
        'pw = objService.Decrypt(strDatabasePassword, "WhiteKnight").returnValue

        Dim proc As System.Diagnostics.Process = New System.Diagnostics.Process
        Dim myCommand As String = "sqlldr.EXE"
        proc.StartInfo = New ProcessStartInfo(myCommand)
        'Set up arguments for CMD.EXE
        'proc.StartInfo.Arguments = "pbill@ORASNAP/pbill CONTROL=D:\Support\Special_pay_in\inbound\control1.ctl"
        proc.StartInfo.Arguments = strUser & "@" & strDatabase & "/" & pw & " CONTROL='" & control & "'"
        proc.StartInfo.RedirectStandardInput = False
        proc.StartInfo.RedirectStandardOutput = False
        proc.StartInfo.RedirectStandardError = True
        proc.StartInfo.UseShellExecute = False
        proc.StartInfo.WorkingDirectory = ControlPath

        'Dim currentProcess As String = Process.GetCurrentProcess().ProcessName '="SPI_BATCH.vshost"
        'CheckIfRunning("odbcadm.exe")
        Try
            proc.Start()
            proc.WaitForExit(2000)
            If (proc.ExitCode = 0) Then
                'MsgBox("Successful Inserted")
                'Dim myStreamReader As IO.StreamReader = proc.StandardOutput()
                'MsgLoader = myStreamReader.ReadToEnd()
                MsgLoader = "Successful Inserted"
                Return True
            Else
                'MsgBox(proc.StandardError.ReadToEnd)
                Dim myStreamReader As IO.StreamReader = proc.StandardError()
                MsgLoader = myStreamReader.ReadToEnd()
                ' MsgLoader = "Error in log file"
                If MsgLoader.Trim = "" Then
                    MsgLoader = "error in log file " & ControlPath & ".log"
                End If
                Return False
            End If
        Catch ex As Exception
            MsgLoader = ex.Message.ToString
            If MsgLoader.Trim = "" Then
                MsgLoader = "Exception Error"
            End If
            Return False
            'MsgBox(ex.Message)

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Function
    Private Sub PP_BackupFile(ByVal org As String, ByVal dest As String)
        Try
            'Copy file to backup
            If System.IO.File.Exists(dest) Then
                My.Computer.FileSystem.DeleteFile(dest)
            End If
            My.Computer.FileSystem.CopyFile(org, dest, overwrite:=False)

            'Delete Original file 
            My.Computer.FileSystem.DeleteFile(org)
        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            'Delete Original file 
            'If controlName <> "" Then My.Computer.FileSystem.DeleteFile(controlName)
        End Try



    End Sub
    Private Sub PP_RunGP(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = PP_GetInFileName(GPInfilePath, "GP")

        If arr.Count < 1 Then
            MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            controlfile = ControlPath & "GPCONTROL.ctl"
            infile = GPInfilePath & filename
            bkfile = GPBackupPath & filename

            Dim lineCount = File.ReadAllLines(infile).Length
            Dim dt As New DataTable
            dt = PP_ReadTextFile(infile, "|")

            PP_GenControlGP(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)
            chkLoader = SqlLoader(controlfile)

            ''�ó� Loader �ӧҹ�����
            If chkLoader Then

                'Backup file
                PP_BackupFile(infile, bkfile)
                'Update Date Format
                PP_GP_UpdateFormatDate(systemdate)
                'Update SubPayType
                PP_GP_UpdateSubPayType(systemdate)
                'Update Flag_Track_Bill
                PP_GP_UpdateFlagFlwBill(systemdate)
                'Update Dep_KeyIn
                PP_GP_UpdateDeptKeyIn(systemdate)

            Else
                MsgBox(MsgLoader)
            End If


        Next
    End Sub
    Private Sub PP_RunGL(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = PP_GetInFileName(GLInfilePath, "GL")

        If arr.Count < 1 Then
            MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) <> "_TAX.TXT" Then

                controlfile = ControlPath & "GLCONTROL.ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = PP_ReadTextFile(infile, "|")

                PP_GenControlGL(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)
                chkLoader = SqlLoader(controlfile)

                ''�ó� Loader �ӧҹ�����
                If chkLoader Then
                    PP_BackupFile(infile, bkfile)
                    'Update Format Date
                    PP_GL_UpdateFormatDate(systemdate)
                    'Update Dep KeyIn
                    PP_GL_UpdateDeptKeyIn(systemdate)
                Else
                    MsgBox(MsgLoader)
                End If
            End If

        Next
    End Sub
    Private Sub PP_RunWHT(ByVal systemdate As String)
        Dim controlfile As String
        Dim infile As String
        Dim bkfile As String
        Dim filename As String
        Dim arr As ArrayList
        Dim chkLoader As Boolean
        'Dim systemdate As String = Now.ToString("yyyyMMdd")

        arr = PP_GetInFileName(GLInfilePath, "GL")

        If arr.Count < 1 Then
            MsgBox("File not found")
            Exit Sub
        End If
        For i As Integer = 0 To arr.Count - 1

            filename = arr(i).ToString()
            If Microsoft.VisualBasic.Right(filename.ToUpper, 8) = "_TAX.TXT" Then

                controlfile = ControlPath & "WHTCONTROL.ctl"
                infile = GLInfilePath & filename
                bkfile = GLBackupPath & filename

                Dim lineCount = File.ReadAllLines(infile).Length
                Dim dt As New DataTable
                dt = PP_ReadTextFile(infile, "|")

                PP_GenControlWHT(systemdate, controlfile, infile, filename, "|", dt.Rows(0)(0), dt.Rows(0)(1), lineCount)
                chkLoader = SqlLoader(controlfile)

                ''�ó� Loader �ӧҹ�����
                If chkLoader Then
                    PP_BackupFile(infile, bkfile)

                    'Update  GPTREF_SEQNO
                    PP_WHT_UpdateGPTREF_SEQNO(systemdate)
                    'Update Dept KeyIn
                    PP_WHT_UpdateDeptKeyIn(systemdate)
                Else
                    MsgBox(MsgLoader)
                End If
            End If

        Next
    End Sub
    Private Sub PP_GP_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET ")
        sb.Append("GPLD_PAIDDATE=TO_CHAR(TO_DATE(GPLD_PAIDDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD')")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateSubPayType(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_SUB_PAYMTH= ")
        sb.Append("CASE WHEN (GPLD_PAYMTH='C') THEN 'C'  ")
        sb.Append("WHEN (GPLD_PAYMTH='D') THEN 'D' ")
        sb.Append("WHEN (GPLD_PAYMTH='M' AND UPPER(GPLD_RESERVE6) LIKE '%CREDIT CARD%') THEN 'C' ")
        sb.Append("WHEN (GPLD_PAYMTH='M') THEN 'M' ")
        sb.Append("ELSE '' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateFlagFlwBill(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_FLWBILL =")
        sb.Append("CASE WHEN (GPLD_DESC LIKE '%�Թ���¤���Թ������ѭ%') THEN 'Y' ELSE 'N' END ")
        sb.Append("WHERE GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GP_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_PAYMENT_LOAD a ")
        sb.Append("SET (GPLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GPLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.GPLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GPLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GL_UpdateFormatDate(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_LOAD SET ")
        sb.Append("GLLD_TRANSDATE=TO_CHAR(TO_DATE(GLLD_TRANSDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD'),")
        sb.Append("GLLD_DUEDATE=TO_CHAR(TO_DATE(GLLD_DUEDATE_TXT,'DD/MM/YYYY'),'YYYYMMDD') ")
        sb.Append("WHERE GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_GL_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_GL_LOAD a ")
        sb.Append("SET (GLLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.GLLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.GLLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.GLLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_WHT_UpdateGPTREF_SEQNO(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_GPTREF_SEQNO) = ( ")
        sb.Append("SELECT GPLD_GPTREF_SEQNO ")
        sb.Append("FROM GPS_PAYMENT_LOAD b ")
        sb.Append("WHERE a.TAXLD_BATCHDATE = b.GPLD_BATCHDATE ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM=b.GPLD_CORE_SYSTEM ")
        sb.Append("AND a.TAXLD_TRANSREF=b.GPLD_TRANSREF ")
        sb.Append("AND a.TAXLD_RESERVE1=b.GPLD_RESERVE9) ")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='PP' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub PP_WHT_UpdateDeptKeyIn(ByVal LoadDate As String)

        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()
        sb.Append("UPDATE GPS_WHT_LOAD a ")
        sb.Append("SET (TAXLD_DEP_KEYIN) = ( ")
        sb.Append("SELECT DTS_DEP_KEYIN  ")
        sb.Append("FROM GPS_TL_DATASOURCE b ")
        sb.Append("WHERE a.TAXLD_DTSOURCE = b.DTS_DTSOURCE ")
        sb.Append("AND b.DTS_CORE_SYSTEM='PP')")
        sb.Append("WHERE a.TAXLD_BATCHDATE='" & LoadDate & "' ")
        sb.Append("AND a.TAXLD_CORE_SYSTEM='PP' ")
        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If


    End Sub
    Private Sub btnLoader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoader.Click
        Dim systemdate As String = Now.ToString("yyyyMMdd")
        PP_RunGP(systemdate)
        PP_RunGL(systemdate)
        PP_RunWHT(systemdate)

        'GP_UpdateSubPayType("20140818")
        'GP_UpdateFlagTrackBill("20140818")
        'HT_UpdateGPTREF_SEQNO("20140818")
        'GL_UpdateFormatDate("20140818")
    End Sub
End Class
