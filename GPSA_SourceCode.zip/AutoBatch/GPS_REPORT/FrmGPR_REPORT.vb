Imports UtilityClassLibrary
Imports System.IO
Imports System.Text
Imports System.Data.OleDb

' Batch Send To Department �ӧҹ�ͺ��� 2
' Batch �ͺ�����觢����š�Ѻ㹷ء˹�ҧҹ ��� P&P ��� TLM

Public Class FrmGPR_REPORT
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsOutstandingRepayment
    Dim currentFullDate As String
    Dim currentHaftDate As String
    Dim currentFullDateReport As String

    Private Sub FrmExportDep_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim strDate As String

            My.Application.ChangeCulture("en-GB")

            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Open connection fail: " & clsUtility.ErrConnectDBMessage)
                    'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                    'Return exit code to batch
                    Environment.ExitCode = 2

                    Exit Sub
                End If
            End If

            currentFullDate = Now.ToString("yyyyMMdd")
            currentHaftDate = Now.ToString("yyMMdd")

            strDate = fnGetLastWorkDay(currentFullDate, 1)

            Debug.Print(System.DateTime.Now)

            If REPORT_START_DATE.ToString = "" Or REPORT_END_DATE.ToString = "" Then
                Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & " Generate Outstanding Repayment Report as of paid date " & currentFullDate)
                Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Started.")
                Run_Report(currentFullDate, currentFullDate)
            Else
                Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & " Generate Outstanding Repayment Report as of paid date " & REPORT_START_DATE & " - " & REPORT_END_DATE)
                Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Started.")
                Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & currentFullDate)
                Run_Report(REPORT_START_DATE, REPORT_END_DATE)
            End If

            Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Export to pdf completed.")


        Catch ex As Exception
            'Return exit code to batch
            Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Fail: " & ex.ToString)
            Environment.ExitCode = 2
        Finally
            Me.Close()
        End Try

    End Sub
    Private Function CheckFileCD_TLMSendDep(ByVal strExportDate As String) As Boolean
        Dim dt_CheckFile As DataTable

        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)
        ' ��Ǩ�ͺ�������Ѻ�Ҥú���� ����Ҥú���� �е�ͧ�������¡�â����ŷ���ѧ��� 
        sb.Append(" select GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('TLM') ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_DATE <= '" & strExportDate & "' ")
        sb.Append(" and ((GPS_PAYMENT.GP_PAYMTH ='C' and GPS_PAYMENT.GP_SUB_PAYMTH='C') Or (GPS_PAYMENT.GP_PAYMTH ='D' and GPS_PAYMENT.GP_SUB_PAYMTH='D')) ")
        sb.Append(" and ( GPS_PAYMENT.GP_FLAG_GET_RESULT='N') ")

        dt_CheckFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_CheckFile) AndAlso dt_CheckFile.Rows.Count > 0 Then
            Return True

        Else
            Return False
        End If


    End Function
    Private Function CheckFileMediaSendDep(ByVal strDueDate As String) As Boolean
        Dim dt_CheckFile As DataTable

        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)
        ' ��Ǩ�ͺ�������Ѻ�Ҥú���� ����Ҥú���� �е�ͧ�������¡�â����ŷ���ѧ��� 
        sb.Append(" select GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
        sb.Append(" and GPS_PAYMENT.GP_PAIDDATE <= '" & strDueDate & "' ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' and GPS_PAYMENT.GP_SUB_PAYMTH='M' ")
        sb.Append(" and ( GPS_PAYMENT.GP_FLAG_GET_RESULT='N') ")

        dt_CheckFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_CheckFile) AndAlso dt_CheckFile.Rows.Count > 0 Then
            Return True

        Else
            Return False
        End If


    End Function


    Private Function CheckFileMediaACC(ByVal strDueDate As String) As Boolean
        Dim dt_CheckFile As DataTable

        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)
        ' ��Ǩ�ͺ�������Ѻ�Ҥú���� ����Ҥú���� �е�ͧ�������¡�â����ŷ���ѧ��� 
        sb.Append(" select GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('ACC') ")
        sb.Append(" and GPS_PAYMENT.GP_PAIDDATE <= '" & strDueDate & "' ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' and GPS_PAYMENT.GP_SUB_PAYMTH='M' ")
        sb.Append(" and ( GPS_PAYMENT.GP_FLAG_GET_RESULT='N') ")

        dt_CheckFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_CheckFile) AndAlso dt_CheckFile.Rows.Count > 0 Then
            Return True

        Else
            Return False
        End If


    End Function

    Private Sub fnGenTextFile(ByVal BatchNo As Integer, ByVal strBusinessDate As String, ByVal strCurrDate As String)
        Dim dt_Filename As DataTable
        Dim dt2 As DataTable
        Dim sb As New StringBuilder
        Dim sb2 As New StringBuilder
        Dim vlineNo As Double
        Dim filename As String
        Dim filenameRunning As Double
        Dim GenTextFilePath As String
        'Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        Dim AMOUNT() As String
        Dim AMOUNT1 As String
        Dim AMOUNT2 As String

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        '--Begin Adjust By Songpol 16/02/2015  
        '--Add Variable Path File Other System
        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENOTHSYS_PATH")

        GenTextFilePath = descpath
        '--End Adjust By Songpol 16/02/2015


        sb.Remove(0, sb.Length)

        'sb.Append(" select GPS_PAYMENT.GP_DATASOURCE_NME as DATASOURCE_NME ")
        'sb.Append(" , count(GPS_PAYMENT.GP_AMOUNT) as CountTrans   ")
        'sb.Append(" , TO_CHAR(sum(GPS_PAYMENT.GP_AMOUNT),'999999999999999.99') as AmountTrans   ")
        'sb.Append(" , MAX(to_char(sysdate,'YYYYMMDD')) as DateTrans   ")
        'sb.Append(" , max(GPS_PAYMENT.GP_TRANSREF) as TRANSREF   ")
        'sb.Append(" from GPS_PAYMENT   ")
        'sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        'sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        'sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        'sb.Append(" and ( (GPS_PAYMENT.GP_CORE_SYSTEM in ('TLM') ")
        'sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_DATE <= '" & strBusinessDate & "' ")
        'sb.Append(" and ((GPS_PAYMENT.GP_PAYMTH ='C' and GPS_PAYMENT.GP_SUB_PAYMTH='C') Or (GPS_PAYMENT.GP_PAYMTH ='D' and GPS_PAYMENT.GP_SUB_PAYMTH='D'))) ")
        'sb.Append("     Or ")
        'sb.Append(" (GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
        'sb.Append(" and GPS_PAYMENT.GP_PAIDDATE <= '" & strCurrDate & "' ")
        'sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' and GPS_PAYMENT.GP_SUB_PAYMTH='M') ) ")
        'sb.Append(" group by GPS_PAYMENT.GP_DATASOURCE_NME ")
        'sb.Append(" order by GPS_PAYMENT.GP_DATASOURCE_NME ")

        sb.Append(" SELECT GP.DATASOURCE_NME, ")
        sb.Append(" GP.CountTrans+NVL(GP_REJ.NO_Record,0) As CountTrans, ")
        sb.Append(" TO_CHAR(GP.AmountTrans+NVL(GP_REJ.GPRJ_AMOUNT,0), '999999999999999.99') as AmountTrans, ")
        sb.Append(" GP.DateTrans, ")
        sb.Append(" GP.TRANSREF ")
        sb.Append(" FROM (select GPS_PAYMENT.GP_DATASOURCE_NME as DATASOURCE_NME ")
        sb.Append(" , count(GPS_PAYMENT.GP_AMOUNT) as CountTrans   ")
        sb.Append(" , sum(GPS_PAYMENT.GP_AMOUNT) as AmountTrans   ")
        sb.Append(" , MAX(to_char(sysdate,'YYYYMMDD')) as DateTrans   ")
        sb.Append(" , max(GPS_PAYMENT.GP_TRANSREF) as TRANSREF   ")
        sb.Append(" from GPS_PAYMENT   ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and ( (GPS_PAYMENT.GP_CORE_SYSTEM in ('TLM') ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_DATE <= '" & strBusinessDate & "' ")
        sb.Append(" and ((GPS_PAYMENT.GP_PAYMTH ='C' and GPS_PAYMENT.GP_SUB_PAYMTH='C') Or (GPS_PAYMENT.GP_PAYMTH ='D' and GPS_PAYMENT.GP_SUB_PAYMTH='D'))) ")
        sb.Append("     Or ")
        sb.Append(" (GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
        sb.Append(" and GPS_PAYMENT.GP_PAIDDATE <= '" & strCurrDate & "' ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' and GPS_PAYMENT.GP_SUB_PAYMTH='M') ) ")
        sb.Append(" group by GPS_PAYMENT.GP_DATASOURCE_NME ")
        sb.Append(" order by GPS_PAYMENT.GP_DATASOURCE_NME) GP ")
        sb.Append("LEFT JOIN (SELECT RJ.GPRJ_DATASOURCE_NME, ")
        sb.Append("                 COUNT(RJ.GPRJ_CORE_SYSTEM) AS NO_Record, ")
        sb.Append("                 SUM(RJ.GPRJ_AMOUNT) AS GPRJ_AMOUNT ")
        sb.Append("         FROM GPS_PAYMENT_REJ RJ ")
        sb.Append("         WHERE RJ.GPRJ_CORE_SYSTEM = 'PP' ")
        sb.Append("         AND RJ.GPRJ_REJECT_FUNC <> 'BANK' ")
        sb.Append("         GROUP BY RJ.GPRJ_DATASOURCE_NME) GP_REJ ")
        sb.Append("ON GP.DATASOURCE_NME = GP_REJ.GPRJ_DATASOURCE_NME ")
        sb.Append("ORDER BY GP.DATASOURCE_NME ")

        filenameRunning = 1

        dt_Filename = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_Filename) AndAlso dt_Filename.Rows.Count > 0 Then

            'oleTrans = clsUtility.gConnGP.BeginTransaction

            Dim oShell : oShell = CreateObject("WScript.Shell")
            Dim oEnv : oEnv = oShell.Environment("PROCESS")
            oEnv.Item("NLS_LANG") = "THAI_THAILAND.TH8TISASCII"

            For Each dr_Filename As DataRow In dt_Filename.Rows

                filename = GenTextFilePath & dr_Filename("DATASOURCE_NME").ToString & currentFullDate & CStr(filenameRunning).ToString.PadLeft(3, "0") & ".txt"

                If System.IO.File.Exists(filename) Then
                    My.Computer.FileSystem.DeleteFile(filename)
                End If

                dt2 = GetData(dr_Filename("DATASOURCE_NME").ToString)
                vlineNo = 0
                Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)



                ' Detail
                For Each dr As DataRow In dt2.Rows
                    vlineNo = vlineNo + 1


                    sw.WriteLine(dr("EXPDATA").ToString)



                Next


                ' Total 
                sw.Write("TOTAL:")
                sw.Write(dr_Filename("CountTrans").ToString.PadLeft(10, "0"))

                AMOUNT = Split(Trim(dr_Filename("AmountTrans").ToString), ".")
                AMOUNT1 = AMOUNT(0).PadLeft(18, "0")
                AMOUNT2 = AMOUNT(1).PadLeft(2, "0")
                sw.Write(AMOUNT1 & AMOUNT2)
                sw.Close()

                '---- Update �ͺ Batch �š�Ѻ�ҡ Bank

                UPD_GP_EXPTOOTHSYS_NO(Trim(BatchNo), Trim(dr_Filename("DATASOURCE_NME").ToString))

            Next 'dr_Filename
            UPD_GP_EXPTOOTHSYS_NO_ACC(Trim(BatchNo), "")
            'MsgBox("Gen Text Completed")

        Else

            UPD_GP_EXPTOOTHSYS_NO_ACC(Trim(BatchNo), "")
            'MsgBox("No Text File, Gen Media ACC Completed ")

        End If


    End Sub

    Public Function UPD_GP_EXPTOOTHSYS_NO(BatchNo As Integer, ByVal DatasourceName As String) As Integer
        Dim sb2 As New StringBuilder
        Dim Rec As Integer
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction

        If (DatasourceName = "TALIS") Then

            sb2.Remove(0, sb2.Length)
            sb2.Append("  UPDATE GPS_PAYMENT  ")
            sb2.Append("  SET GPS_PAYMENT.GP_EXPTOOTHSYS_NO = " & Trim(BatchNo) & " ")
            sb2.Append(" , GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'Y' ")
            sb2.Append(" , GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = to_char(sysdate,'YYYYMMDD') ")
            sb2.Append("  WHERE  GPS_PAYMENT.GP_DATASOURCE_NME =  '" & DatasourceName & "'  ")
            sb2.Append("  and  GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N'  ")
            sb2.Append("  and  GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
            'sb2.Append("  and  GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")

        Else
            sb2.Remove(0, sb2.Length)
            sb2.Append("  UPDATE GPS_PAYMENT  ")
            sb2.Append("  SET GPS_PAYMENT.GP_EXPTOOTHSYS_NO = " & Trim(BatchNo) & " ")
            sb2.Append(" , GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'Y' ")
            sb2.Append(" , GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = to_char(sysdate,'YYYYMMDD') ")
            sb2.Append("  WHERE  GPS_PAYMENT.GP_DATASOURCE_NME =  '" & DatasourceName & "'  ")

        End If

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

        If Rec > 0 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()

        End If

    End Function
    Public Function UPD_GP_EXPTOOTHSYS_NO_ACC(BatchNo As Integer, ByVal DatasourceName As String) As Integer
        Dim sb2 As New StringBuilder
        Dim Rec As Integer
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction

        sb2.Remove(0, sb2.Length)
        sb2.Append("  UPDATE GPS_PAYMENT  ")
        sb2.Append("  SET GPS_PAYMENT.GP_EXPTOOTHSYS_NO = " & Trim(BatchNo) & "  ")
        sb2.Append(" , GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'Y' ")
        sb2.Append(" , GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = to_char(sysdate,'YYYYMMDD') ")
        sb2.Append("  where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
        sb2.Append("  and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sb2.Append("  and GPS_PAYMENT.GP_PAYMTH = 'M' and GPS_PAYMENT.GP_SUB_PAYMTH='M' ")
        sb2.Append("  and GPS_PAYMENT.GP_CORE_SYSTEM  in ( 'ACC' ) ")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

        If Rec > 0 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()

        End If

    End Function
    Public Function GetTransRefTLM(ByVal DatasourceName As String) As String
        Dim sbTLM As New StringBuilder
        Dim dt_TLM As DataTable
        Dim str_TLM As String

        str_TLM = ""
        sbTLM.Remove(0, sbTLM.Length)

        sbTLM.Append(" select GPS_PAYMENT.GP_DATASOURCE_NME as DATASOURCE_NME ")
        sbTLM.Append(" , count(GPS_PAYMENT.GP_AMOUNT) as CountTrans   ")
        sbTLM.Append(" , TO_CHAR(sum(GPS_PAYMENT.GP_AMOUNT),'999999999999999.99') as AmountTrans   ")
        sbTLM.Append(" , MAX(to_char(sysdate,'YYYYMMDD')) as DateTrans   ")
        sbTLM.Append(" , max(GPS_PAYMENT.GP_TRANSREF) as TRANSREF   ")
        sbTLM.Append(" from GPS_PAYMENT   ")
        sbTLM.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        sbTLM.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")
        sbTLM.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ( 'TLM' ) ")
        sbTLM.Append(" and GPS_PAYMENT.GP_DATASOURCE_NME = '" & DatasourceName & "' ")
        sbTLM.Append(" group by GPS_PAYMENT.GP_DATASOURCE_NME , GPS_PAYMENT.GP_TRANSREF ")
        sbTLM.Append(" order by GPS_PAYMENT.GP_DATASOURCE_NME , GPS_PAYMENT.GP_TRANSREF ")

        dt_TLM = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbTLM)



        If Not IsNothing(dt_TLM) AndAlso dt_TLM.Rows.Count > 0 Then
            str_TLM = ""

            For Each dr_TLM As DataRow In dt_TLM.Rows
                If (str_TLM <> "") Then
                    str_TLM = str_TLM & " , "
                End If
                str_TLM = str_TLM & " '" & dr_TLM("TRANSREF").ToString & "' "
            Next


        Else

            str_TLM = ""
        End If

        Return str_TLM

    End Function


    Public Function GetData(ByVal DatasourceName As String) As DataTable
        Dim sb As New StringBuilder
        Dim TransRefTLM As String


        If (DatasourceName = "TALIS") Then

            TransRefTLM = GetTransRefTLM(DatasourceName)


            sb.Remove(0, sb.Length)
            sb.Append(" SELECT  RPAD(ROWNUM,7,' ')||EXPDATA as EXPDATA ")
            sb.Append(" from ( ")

            sb.Append(" SELECT * from (  ")

            sb.Append(" SELECT ")
            sb.Append(" RPAD(NVL(GPS_PAYMENT.GP_CHQNO,' '),20,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYDESC,' '),150,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ') ")
            sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT.GP_AMOUNT,'0'),'999999999999999999.99')),19,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BILLNO,' '),15,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_POLNO,' '),20,' ')  ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||case  ")
            'sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M'  then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M' And GPS_PAYMENT.GP_LASTUPD_STS='S' then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M' And GPS_PAYMENT.GP_LASTUPD_STS='F' then RPAD('R',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'C'  then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'D'  then RPAD('C',50,' ') ")
            sb.Append(" else RPAD(' ',50,' ') ")
            sb.Append(" end ")
            'sb.Append(" ||RPAD(' ',50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_REJBANK_REASON,' '),50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNO,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNME,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BNKCODE,' '),5,' ')  ")
            sb.Append(" ||RPAD(' ',150,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_ADDRESS1,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DISTRICT,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PROVINCE,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_INSURENAME,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DATASOURCE_NME,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE6,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_MERCHN_NO,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_CDCARD_DATE,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE9,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE10,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_REF,' '),5,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_GR,' '),5,' ') ")
            sb.Append(" as EXPDATA , GPS_PAYMENT.GP_GPTREF_SEQNO as GPTREF_SEQNO  ")
            sb.Append(" from GPS_PAYMENT ")
            sb.Append(" where GPS_PAYMENT.GP_DATASOURCE_NME = '" & DatasourceName & "' ")
            sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
            sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")

            sb.Append(" union all  ")

            sb.Append(" SELECT   ")
            sb.Append(" RPAD(' ',20,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DESC,' '),150,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
            sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT_REJ.GPRJ_AMOUNT,'0'),'999999999999999999.99')),19,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BILLNO,' '),15,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_POLNO,' '),20,' ')    ")
            sb.Append(" ||RPAD(' ',10,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYMTH,' '),10,' ')    ")
            sb.Append(" ||RPAD('R',50,' ')   ")
            'sb.Append(" ||RPAD(' ',50,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE,' '),50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNO,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNME,' '),50,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BNKCODE,' '),5,' ')   ")
            sb.Append(" ||RPAD(' ',150,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_ADDRESS1,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DISTRICT,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PROVINCE,' '),100,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_INSURENAME,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE6,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_MERCHN_NO,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_CDCARD_DATE,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE9,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE10,' '),100,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_REF,' '),5,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_GR,' '),5,' ')  ")
            sb.Append(" as EXPDATA , GPS_PAYMENT_REJ.GPRJ_GPTREF_SEQNO as GPTREF_SEQNO  ")
            sb.Append(" from GPS_PAYMENT_REJ   ")
            sb.Append(" where GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME = '" & DatasourceName & "'   ")

            If (TransRefTLM <> "") Then
                sb.Append(" and GPS_PAYMENT_REJ.GPRJ_TRANSREF in ( " & TransRefTLM & " ) ")
            End If

            sb.Append(" and GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE <> 'BANK_REJ'   ")
            sb.Append(" and GPS_PAYMENT_REJ.GPRJ_BATCHTYPE <> 'BANK'   ")
            sb.Append(" and GPS_PAYMENT_REJ.GPRJ_PAYMTH = 'M'   ")
            sb.Append(" ) MasterData  ")
            sb.Append(" order by MasterData.GPTREF_SEQNO  ")


            sb.Append(" ) ExportData ")

        Else

            sb.Remove(0, sb.Length)
            sb.Append(" SELECT  RPAD(ROWNUM,7,' ')||EXPDATA as EXPDATA ")
            sb.Append(" from ( ")

            sb.Append(" SELECT * from (  ")

            sb.Append(" SELECT ")
            sb.Append(" RPAD(NVL(GPS_PAYMENT.GP_CHQNO,' '),20,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYDESC,' '),150,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ') ")
            sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT.GP_AMOUNT,'0'),'999999999999999999.99')),19,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BILLNO,' '),15,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAIDDATE,' '),10,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_POLNO,' '),20,' ')  ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||case  ")
            'sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M' then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M' And GPS_PAYMENT.GP_LASTUPD_STS='S' then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'M' And GPS_PAYMENT.GP_LASTUPD_STS='F' then RPAD('R',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'C'  then RPAD('C',50,' ') ")
            sb.Append(" when GPS_PAYMENT.GP_PAYMTH = 'D'  then RPAD('C',50,' ') ")
            sb.Append(" else RPAD(' ',50,' ') ")
            sb.Append(" end ")
            'sb.Append(" ||RPAD(' ',50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_REJBANK_REASON,' '),50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNO,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PAYEE_BNKACCNME,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_BNKCODE,' '),5,' ')  ")
            sb.Append(" ||RPAD(' ',150,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_ADDRESS1,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DISTRICT,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_PROVINCE,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_INSURENAME,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_DATASOURCE_NME,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE6,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_MERCHN_NO,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_CDCARD_DATE,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE9,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_RESERVE10,' '),100,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_REF,' '),5,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT.GP_SYS_GR,' '),5,' ') ")
            sb.Append(" as EXPDATA , GPS_PAYMENT.GP_GPTREF_SEQNO as GPTREF_SEQNO  ")
            sb.Append(" from GPS_PAYMENT ")
            sb.Append(" where GPS_PAYMENT.GP_DATASOURCE_NME = '" & DatasourceName & "' ")
            sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y'  ")
            sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOOTHSYS = 'N' ")

            sb.Append(" union all  ")

            sb.Append(" SELECT   ")
            sb.Append(" RPAD(' ',20,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DESC,' '),150,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
            sb.Append(" ||LPAD(TRIM(TO_CHAR(NVL(GPS_PAYMENT_REJ.GPRJ_AMOUNT,'0'),'999999999999999999.99')),19,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BILLNO,' '),15,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAIDDATE,' '),10,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_POLNO,' '),20,' ')    ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||RPAD('0',10,'0') ")
            sb.Append(" ||RPAD('R',50,' ') ")
            'sb.Append(" ||RPAD(' ',50,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE,' '),50,' ') ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNO,' '),50,' ')  ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNME,' '),50,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_BNKCODE,' '),5,' ')   ")
            sb.Append(" ||RPAD(' ',150,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_ADDRESS1,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DISTRICT,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_PROVINCE,' '),100,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_INSURENAME,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE6,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_MERCHN_NO,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_CDCARD_DATE,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE9,' '),100,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_RESERVE10,' '),100,' ')   ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_REF,' '),5,' ')    ")
            sb.Append(" ||RPAD(NVL(GPS_PAYMENT_REJ.GPRJ_SYS_GR,' '),5,' ')  ")
            sb.Append(" as EXPDATA , GPS_PAYMENT_REJ.GPRJ_GPTREF_SEQNO as GPTREF_SEQNO  ")
            sb.Append(" from GPS_PAYMENT_REJ   ")
            sb.Append(" where GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME = '" & DatasourceName & "'   ")
            sb.Append(" and GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE <> 'BANK_REJ'   ")
            sb.Append(" and GPS_PAYMENT_REJ.GPRJ_BATCHTYPE <> 'BANK'   ")

            sb.Append(" ) MasterData  ")
            sb.Append(" order by MasterData.GPTREF_SEQNO  ")


            sb.Append(" ) ExportData ")

        End If



        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetWorkDay(ByVal CurrentDate As DateTime) As Boolean

        Select Case CurrentDate.DayOfWeek
            Case DayOfWeek.Saturday
                Return False
            Case DayOfWeek.Sunday
                Return False
            Case Else
                'handles sunday through thursday
                Return True
        End Select

    End Function
    Function LookUpHoliday(ByVal d_start As String, ByVal d_end As String) As Integer

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE BETWEEN '" & d_start & "'  AND '" & d_end & "'  AND HLDS_COMPANY_CODE='SCBLIFE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return 0
        End If

    End Function
    Public Function fnGetLastWorkDay(ByVal begin_date As String, ByVal total_day As Integer) As String
        Dim RetDate As Date
        Dim countworkdate As Integer
        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim format As String = "yyyyMMdd"

        RetDate = Date.ParseExact(begin_date, format, New Globalization.CultureInfo("en-US"))

        Do While countworkdate <> total_day

            RetDate = DateAdd(DateInterval.Day, -1, RetDate)

            chkHoliday = LookUpHoliday(RetDate.ToString("yyyyMMdd"), RetDate.ToString("yyyyMMdd"))

            If chkHoliday > 0 Then
                total_day = total_day + 1
            End If

            chkWorkDay = GetWorkDay(RetDate)
            If chkWorkDay Then
                countworkdate += 1
            End If


        Loop

        Return RetDate.ToString("yyyyMMdd")

    End Function

    Function GetDataSource(ByVal datefrom As String, ByVal dateto As String, ByVal sourcename As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""

        sb.Append("SELECT GP_DATASOURCE_NME FROM GPS_PAYMENT ")
        sb.Append("WHERE GP_PAIDDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        sb.Append("AND GP_FLAG_GET_RESULT = 'Y' ")
        sb.Append("AND GP_FLAG_EXPTOOTHSYS = 'Y' ")
        sb.Append("GROUP BY GP_DATASOURCE_NME ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function
    Private Sub GenInterfaceReport(ByVal status As String, ByVal datefrom As String, ByVal dateto As String, ByVal datasourcename As String, ByVal datasourcefilename As String)


        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_DATASOURCE_NME,P.GP_CREATEDATE,R.TREF_BATCH_NO,P.GP_CHQNO,P.GP_PAYDESC,T.PAYT_PAYTYPE,P.GP_PAYEE_NAME, ")
        sb.Append("P.GP_PAIDDATE,P.GP_AMOUNT,P.GP_POLNO,R.TREF_VCH_NO_C ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        ' sb.Append("WHERE P.GP_PAIDDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ' sb.Append("AND P.GP_DATASOURCE_NME='" & dr("GP_DATASOURCE_NME").ToString & "' ")
        sb.Append("WHERE P.GP_DATASOURCE_NME ='" & datasourcename & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Dim reportname As String

        reportname = datasourcename & Now.ToString("yyyyMMdd") & "001" & ".pdf"

        Dim clsExportPDF As New clsCrystalToPDFConverter

        clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptInterfaceToOther.rpt") 'sReportPath ��� path �ͧ crystal report
        clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & reportname) 'ValidationReportPath ��� path �����ҧ report  

        Dim transfrom, transto As String
        Dim lstname As New ArrayList
        Dim lstvalue As New ArrayList

        transfrom = datefrom.Substring(6, 2) & "/" & datefrom.Substring(4, 2) & "/" & datefrom.Substring(0, 4)
        transto = dateto.Substring(6, 2) & "/" & dateto.Substring(4, 2) & "/" & dateto.Substring(0, 4)

        lstname.Add("pTransdate")
        lstname.Add("pFileName")

        lstvalue.Add(transfrom & " - " & transto)
        lstvalue.Add(datasourcefilename)

        clsExportPDF.ExportReport(dt, lstname, lstvalue)



    End Sub

    Private Sub Run_Report(ByVal strDateFrom As String, ByVal strDateTo As String)

        Dim dt As New DataTable
        Me.Cursor = Cursors.WaitCursor

        dt = cls.GetDataForReport(clsUtility.gConnGP, strDateFrom, strDateTo)

        If IsNothing(dt) Then
            Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Data not found!")
        Else
            Console.WriteLine(Now.ToString("yyyy-MM-dd hh:mm:ss") & "   Data : " & dt.Rows.Count.ToString & " record(s).")
        End If

        PrintReportOutStandingRepayment(dt, strDateFrom, strDateTo)

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub PrintReportOutStandingRepayment(ByVal dt As DataTable, ByVal strDateFrom As String, ByVal strDateTo As String)


        Dim clsExportPDF As New clsCrystalToPDFConverter
        Dim reportname As String

        reportname = "RPTOutstandingRepayment_" & Now.ToString("yyyyMMddhhmmss") & ".pdf"
        clsExportPDF.SetCrystalReportFilePath(sReportPath & "RPTOutstandingRepayment.rpt") 'sReportPath ��� path �ͧ crystal report
        clsExportPDF.SetPdfDestinationFilePath(sReportPath & reportname) 'ValidationReportPath ��� path �����ҧ report  

        Dim transfrom, transto As String
        Dim lstname As New ArrayList
        Dim lstvalue As New ArrayList

        transfrom = strDateFrom.Substring(6, 2) & "/" & strDateFrom.Substring(4, 2) & "/" & strDateFrom.Substring(0, 4)
        transto = strDateTo.Substring(6, 2) & "/" & strDateTo.Substring(4, 2) & "/" & strDateTo.Substring(0, 4)

        lstname.Add("pTransdate")
        lstname.Add("pTransdateTo")
        lstname.Add("pUser")

        lstvalue.Add(transfrom)
        lstvalue.Add(transto)
        lstvalue.Add("System")

        clsExportPDF.ExportReport(dt, lstname, lstvalue)


        '-----

    End Sub

End Class