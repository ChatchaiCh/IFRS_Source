'Imports System.Data
'Imports System.Data.OleDb
'Imports System.Configuration
'Imports SCNYL_Connection2005.SCNYL_Connection
'Module ModDBUtil
'    Public gLastErrMessage As String
'    Public Function ExecuteReader(ByRef oConn As OleDbConnection, ByRef oDs As DataSet, ByVal sSql As String, Optional ByVal sTableName As String = "") As Boolean
'        Dim oleDa As New OleDbDataAdapter(sSql, oConn)
'        Try
'            If sTableName = "" Then
'                oleDa.Fill(oDs)
'            Else
'                oleDa.Fill(oDs, sTableName)
'            End If
'            ExecuteReader = True
'        Catch ex As Exception
'            gLastErrMessage = ex.Message
'            ExecuteReader = False
'        End Try
'    End Function
'    Public Function ExecuteData(ByRef oConn As OleDbConnection, ByVal sSql As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
'        Dim oleComm As New OleDbCommand(sSql)
'        Try
'            oleComm.Connection = oConn
'            If oTrans Is Nothing Then
'            Else
'                oleComm.Transaction = oTrans
'            End If
'            oleComm.CommandText = sSql
'            ExecuteData = oleComm.ExecuteNonQuery
'        Catch ex As Exception
'            gLastErrMessage = ex.Message
'            ExecuteData = -1
'        End Try
'    End Function

'End Module
