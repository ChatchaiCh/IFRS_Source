' Program Name: clsDataAccess.vb
' Description: 
'==============================
' Change History
'==============================
' Range     Date        Time    By          Description
' 01      21/6/2011    11.50  Phaitoon s.  Create Module
'==============================
Imports System
Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration
Imports SCNYL_Connection2005.SCNYL_Connection

Namespace DataClass

    Public Class clsDataAccess
        Const ErrMessageNotfound As String = "Not found.."
        Private Shared cn_ADUPS As OleDb.OleDbConnection

        Public Shared Function GetDataRow(ByVal strSQL As String, ByVal strCn As String) As DataRow
            Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
            Dim sServer As String = ConfigurationManager.AppSettings("SERVER1").ToUpper
            Dim sServer2 As String = ConfigurationManager.AppSettings("SERVER2").ToUpper
            Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper

            Using cn As New OleDb.OleDbConnection
                ClsScnylConn.OpenConnection(cn, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)

                Using cmd As New OleDb.OleDbCommand(strSQL, cn)
                    Using dt As New DataTable
                        Try
                            cn.Open()
                            Dim dr As OleDb.OleDbDataReader = cmd.ExecuteReader
                            dt.Load(dr)
                            If dt.Rows.Count = 0 Then
                                Throw New ApplicationException(ErrMessageNotfound)
                            End If
                            GetDataRow = dt.Rows(0)
                            dr.Close()
                        Catch ex As Exception
                            GetDataRow = Nothing
                            Throw ex
                        End Try
                    End Using
                End Using
            End Using
        End Function

        Public Shared Function GetDataTable(ByVal strSQL As String, ByVal strCn As String) As DataTable
            Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
            Dim sServer As String = ConfigurationManager.AppSettings("SERVER1").ToUpper
            Dim sServer2 As String = ConfigurationManager.AppSettings("SERVER2").ToUpper
            Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper

            Using cn As New OleDb.OleDbConnection

              ClsScnylConn.OpenConnection(cn, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)
              Using cmd As New OleDb.OleDbCommand(strSQL, cn)
                    Using dt As New DataTable
                        Try
                            cn.Open()
                            Dim dr As OleDb.OleDbDataReader = cmd.ExecuteReader
                            dt.Load(dr)
                            If dt.Rows.Count = 0 Then
                                Throw New ApplicationException(ErrMessageNotfound)
                            End If
                            GetDataTable = dt
                            dr.Close()
                        Catch ex As Exception
                            GetDataTable = Nothing
                            Throw ex
                        End Try
                    End Using
                End Using
            End Using
        End Function

        Public Shared Function GetDataSet(ByVal strSQL As String, ByVal strCn As String) As DataSet
            Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
            Dim sServer As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
            Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper
            Dim sServer2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
            'Using cn As New OleDb.OleDbConnection
            Dim cn As New OleDb.OleDbConnection

            ClsScnylConn.OpenConnection(cn, _
                              EnumAccessLocationType.ALT_ORACLE, _
                              sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, _
                              sServer, EnumLocationType.LT_ORACLE, 2, sServer2)

                Using cmd As New OleDb.OleDbCommand(strSQL, cn)
                    Using ds As New DataSet
                        Using da As New OleDb.OleDbDataAdapter(cmd)
                            Try
                                'cn.Open()
                                da.Fill(ds)
                                GetDataSet = ds
                            Catch ex As Exception
                                GetDataSet = Nothing
                                Throw ex
                            End Try
                        End Using
                    End Using
                End Using
            'End Using
        End Function

        Public Shared Function GetDefaultRow(ByVal strTable As String, ByVal strCn As String) As DataRow
            ' define SQL
            Dim strSql As String = String.Format( _
                " SELECT * FROM {0} WHERE 1=0 ", strTable)
            Using cn As New OleDb.OleDbConnection(strCn)
                Using cmd As New OleDb.OleDbCommand(strSql, cn)
                    Using dt As New DataTable
                        Try
                            cn.Open()
                            Dim dr As OleDb.OleDbDataReader = cmd.ExecuteReader
                            dt.Load(dr)
                            GetDefaultRow = dt.NewRow
                            dr.Close()
                        Catch ex As Exception
                            GetDefaultRow = Nothing
                            Throw ex
                        End Try
                    End Using
                End Using
            End Using
        End Function

        'Check null value
        Public Shared Function GetDBString(ByVal dbfld As Object) As String
            If IsDBNull(dbfld) Then
                Return String.Empty
            Else
                Return CType(dbfld, String)
            End If
        End Function

        'program to read xmlfile2 format 
        Public Shared Function GetConfigXML(ByVal strID As String) As DataRow
            Dim ds As New DataSet
            'Set reference in .NET option to system.configuration
            ds.ReadXml(ConfigurationManager.AppSettings("XMLPath").ToString)
            Dim dc As DataColumn = ds.Tables(0).Columns(0)
            ds.Tables(0).Constraints.Add("key1", dc, True)
            Dim dr As DataRow = ds.Tables(0).Rows.Find(strID)
            Return dr
        End Function
        Public Shared Function BuildDropTable(ByVal tb As String, ByVal strCn As String) As Boolean
            Dim sSQL As String
            Try
                sSQL = "Drop TABLE " & tb
                BuildDropTable = ExecuteCommandSQL(sSQL, strCn)
            Catch ex As Exception
                BuildDropTable = False
                Throw ex
            End Try
        End Function
        Public Shared Function ExecuteCommandSQL(ByVal strSQL As String, ByVal strCn As String) As Boolean
            Try
                Using cn As New OleDb.OleDbConnection(strCn)
                    cn.Open()
                    Dim cmd As New OleDb.OleDbCommand(strSQL, cn)
                    cmd.ExecuteScalar()
                    ExecuteCommandSQL = True
                End Using
            Catch ex As Exception
                ExecuteCommandSQL = False
                Throw ex
            End Try
        End Function

    End Class
End Namespace
