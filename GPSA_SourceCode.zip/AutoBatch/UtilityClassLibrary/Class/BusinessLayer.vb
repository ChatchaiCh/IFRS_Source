Imports System.Data.OleDb
Imports System.Configuration
Imports System.Globalization
Imports System.Threading
Imports System.Text
Imports System.IO

Public Class BusinessLayer
    'Public ret_RejectCode As String
    Public gLastErrMessage As String

    Public Function GetSystemDate() As String
        'Dim sb As New StringBuilder()
        'sb.Append("select TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi:ss') as systemdate from dual")

        'Try

        '    Dim dt As DataTable
        '    dt = ExecuteReaderCommand(oleConn, sb)
        '    If dt.Rows.Count > 0 Then
        '        Return dt.Rows(0)("systemdate").ToString()
        '    Else
        '        Return ""
        '    End If
        'Catch ex As Exception

        '    Dim en As New System.Globalization.CultureInfo("en-GB")
        '    Return DateTime.Now.ToString("yyyyMMdd HH:mm:ss", en)
        '    'Throw New Exception(ex.Message & " [source:" & sb.ToString() & "]")
        'End Try

        Dim en As New System.Globalization.CultureInfo("en-GB")
        Return DateTime.Now.ToString("yyyyMMdd HH:mm:ss", en)

    End Function
    Public Function DtEmptyRpt(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select 1 from dual ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function ExecuteCommand(ByRef oleConn As OleDbConnection, ByVal sb As StringBuilder, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try

            ExecuteCommand = ExecuteData(oleConn, sb.ToString, oTrans)

        Catch ex As Exception
            gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function ExecuteReaderCommand(ByRef oleConn As OleDbConnection, ByVal sb As StringBuilder) As DataTable
        Try

            Dim Ds As New DataSet
            ExecuteReader(oleConn, Ds, sb.ToString)
            ExecuteReaderCommand = Ds.Tables(0)
        Catch ex As Exception
            ExecuteReaderCommand = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ExecuteReader(ByRef oConn As OleDbConnection, ByRef oDs As DataSet, ByVal sSql As String, Optional ByVal sTableName As String = "") As Boolean
        Dim oleDa As New OleDbDataAdapter(sSql, oConn)
        Try
            If sTableName = "" Then
                oleDa.Fill(oDs)
            Else
                oleDa.Fill(oDs, sTableName)
            End If
            ExecuteReader = True
        Catch ex As Exception
            gLastErrMessage = ex.Message
            ExecuteReader = False
        End Try
    End Function
    Public Function ExecuteData(ByRef oConn As OleDbConnection, ByVal sSql As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Dim oleComm As New OleDbCommand(sSql)
        Try
            oleComm.Connection = oConn
            If oTrans Is Nothing Then
            Else
                oleComm.Transaction = oTrans
            End If
            oleComm.CommandText = sSql
            Console.WriteLine("2.7.4.executedata")
            ExecuteData = oleComm.ExecuteNonQuery
            Console.WriteLine("2.7.4.executedata completed")
        Catch ex As Exception
            gLastErrMessage = ex.Message
            Console.WriteLine("2.7.4 ex = " & gLastErrMessage )
            ExecuteData = -1
        End Try
    End Function
    Public Function GetBankForPrtCheque(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT BKMST_BNKCODE,BKMST_BNKNAME FROM GPS_TL_BANKMASTER WHERE BKMST_FLAG_PRN_OTHBNK='Y'  ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GetBankForPrtCheque = Ds.Tables(0)
        Catch ex As Exception
            GetBankForPrtCheque = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetBankCode(ByRef oleConn As OleDbConnection, Optional ByVal bankcode As String = "") As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT BANK_CODE,PAY_CHANNEL ||'-'|| TH_DESC BANK_NAME  FROM SPI_M_PAY_CHANNEL   ")
            If bankcode <> "" Then
                sb.Append("WHERE BANK_CODE LIKE '%" & bankcode & "%' ")
            End If
            sb.Append("ORDER BY BANK_NAME ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GetBankCode = Ds.Tables(0)
        Catch ex As Exception
            GetBankCode = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function CHECK_INTERFACE_CONTROL_STATUS(ByRef oleConn As OleDbConnection, ByVal fn As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT * FROM GLM_INTERFACE_CONTROL   ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")
            sb.Append("AND INT_STATUS='STOP' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows.Count > 0 Then
                CHECK_INTERFACE_CONTROL_STATUS = True
            Else
                CHECK_INTERFACE_CONTROL_STATUS = False
            End If

        Catch ex As Exception
            CHECK_INTERFACE_CONTROL_STATUS = False
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_NO_INTERFACE_CONTROL(ByRef oleConn As OleDbConnection, ByVal fn As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT NVL(INT_GL_NO,0)+1 AS NEXTNO FROM GLM_INTERFACE_CONTROL   ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GET_NO_INTERFACE_CONTROL = Ds.Tables(0).Rows(0)("NEXTNO") ' Ds.Tables(0).Rows("NEXTNO").ToString
        Catch ex As Exception
            GET_NO_INTERFACE_CONTROL = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function UPDATE_INTERFACE_CONTROL_STATUS(ByRef oleConn As OleDbConnection, ByVal fn As String, ByVal status As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("UPDATE GLM_INTERFACE_CONTROL SET INT_STATUS='" & status & "'  ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            UPDATE_INTERFACE_CONTROL_STATUS = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            UPDATE_INTERFACE_CONTROL_STATUS = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function UPDATE_INTERFACE_CONTROL_NO(ByRef oleConn As OleDbConnection, ByVal fn As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("UPDATE GLM_INTERFACE_CONTROL SET INT_GL_NO=INT_GL_NO+1  ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            UPDATE_INTERFACE_CONTROL_NO = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            UPDATE_INTERFACE_CONTROL_NO = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPhorNgorDor(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim dtGL As DataTable = Nothing
            If dtGL Is Nothing Then
                dtGL = New DataTable

                dtGL.Columns.Add("IDCARD")
                dtGL.Columns.Add("TAXID")
                dtGL.Columns.Add("APNAME")
                dtGL.Columns.Add("ADDRESS")

            End If

            Dim rowNew As DataRow
            rowNew = dtGL.NewRow

            rowNew.Item("IDCARD") = "1239876542314"
            rowNew.Item("TAXID") = "1896654310990"
            rowNew.Item("APNAME") = "�ѷ���Թ ��͹��"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "�ҭ��� �ͧ˹ع"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "���� �Ҫ�Թ"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "���Թ�� ���ا���"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "��ʹ� �ح�ѧ"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "����� �á��"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "�പ �ء�����"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()


            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()


            GetPhorNgorDor = dtGL
        Catch ex As Exception
            GetPhorNgorDor = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookupBankCode(ByRef oleConn As OleDbConnection, ByVal bankcode As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT BANK_CODE,PAY_CHANNEL ||'-'|| TH_DESC BANK_NAME  FROM SPI_M_PAY_CHANNEL ")
            sb.Append("WHERE BANK_CODE='" & bankcode & "' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            LookupBankCode = Ds.Tables(0).Rows(0)("BANK_NAME")
        Catch ex As Exception
            LookupBankCode = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function SetDefaultGL() As DataTable
        Try
            Dim dtGL As DataTable = Nothing
            If dtGL Is Nothing Then
                dtGL = New DataTable

                dtGL.Columns.Add("STATUS")
                dtGL.Columns.Add("SET_OF_BOOKS_ID")
                dtGL.Columns.Add("USER_JE_SOURCE_NAME")
                dtGL.Columns.Add("USER_JE_CATEGORY_NAME")
                dtGL.Columns.Add("ACCOUNTING_DATE")
                dtGL.Columns.Add("CURRENCY_CODE")
                dtGL.Columns.Add("DATE_CREATED")
                dtGL.Columns.Add("CREATED_BY")
                dtGL.Columns.Add("ACTUAL_FLAG")
                dtGL.Columns.Add("CURRENCY_CONVERSION_DATE")
                dtGL.Columns.Add("CURRENCY_CONVERSION_TYPE")
                dtGL.Columns.Add("CURRENCY_CONVERSION_RATE")
                dtGL.Columns.Add("COMPANY_CODE")
                dtGL.Columns.Add("RC_CODE")
                dtGL.Columns.Add("OWNER_CODE")
                dtGL.Columns.Add("PRODUCT_CODE")
                dtGL.Columns.Add("CHANNEL_CODE")
                dtGL.Columns.Add("ACCOUNT_CODE")
                dtGL.Columns.Add("PROJECT_CODE")
                dtGL.Columns.Add("TAX_CODE")
                dtGL.Columns.Add("SEGMENT_RESERVE1")
                dtGL.Columns.Add("SEGMENT_RESERVE2")
                dtGL.Columns.Add("ENTERED_DR")
                dtGL.Columns.Add("ENTERED_CR")
                dtGL.Columns.Add("ACCOUNTED_DR")
                dtGL.Columns.Add("ACCOUNTED_CR")
                dtGL.Columns.Add("REFERENCE1")
                dtGL.Columns.Add("REFERENCE4")
                dtGL.Columns.Add("RESERSAL_FLAG")
                dtGL.Columns.Add("RESERSAL_PERIOD")
                dtGL.Columns.Add("RESERSAL_METHOD")
                dtGL.Columns.Add("REFERENCE10")
                dtGL.Columns.Add("GROUP_ID")
                dtGL.Columns.Add("PERIOD_NAME")
                dtGL.Columns.Add("STAT_AMOUNT")
                dtGL.Columns.Add("ATTRIBUTE1")
                dtGL.Columns.Add("ATTRIBUTE2")
                dtGL.Columns.Add("ATTRIBUTE3")

            End If

            Dim rowNew As DataRow
            rowNew = dtGL.NewRow

            rowNew.Item("STATUS") = "NEW"
            rowNew.Item("SET_OF_BOOKS_ID") = "255"
            rowNew.Item("USER_JE_SOURCE_NAME") = "SUNGL"
            rowNew.Item("USER_JE_CATEGORY_NAME") = "Normal"
            rowNew.Item("CREATED_BY") = "1072"
            rowNew.Item("ACTUAL_FLAG") = "A"
            rowNew.Item("COMPANY_CODE") = "01"
            rowNew.Item("RC_CODE") = "0001"
            rowNew.Item("SEGMENT_RESERVE1") = "0000"
            rowNew.Item("SEGMENT_RESERVE2") = "0000"

            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            SetDefaultGL = dtGL
        Catch ex As Exception
            SetDefaultGL = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ReadTextGL_Old(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGL")

                            dtD.Columns.Add("LineNo")
                            dtD.Columns.Add("TransDate")
                            dtD.Columns.Add("Dept")
                            dtD.Columns.Add("PLPT")
                            dtD.Columns.Add("Mktg")
                            dtD.Columns.Add("AccCode")
                            dtD.Columns.Add("AccName")
                            dtD.Columns.Add("Desc")
                            dtD.Columns.Add("Project")
                            dtD.Columns.Add("TTTR")
                            dtD.Columns.Add("DC")
                            'dtD.Columns.Add("DrAmt")
                            'dtD.Columns.Add("CrAmt")
                            dtD.Columns.Add("OracleAccCode")
                            dtD.Columns.Add("OracleDept")
                            dtD.Columns.Add("OraclePLPT")
                            dtD.Columns.Add("OracleMktg")

                        End If

                        Row = dtD.NewRow
                        Row.Item(0) = CurrentRow(5).ToString.Trim
                        Row.Item(1) = CurrentRow(6).ToString.Trim
                        Row.Item(2) = CurrentRow(20).ToString.Trim
                        Row.Item(3) = CurrentRow(21).ToString.Trim
                        Row.Item(4) = CurrentRow(22).ToString.Trim
                        Row.Item(5) = CurrentRow(18).ToString.Trim
                        Row.Item(6) = CurrentRow(19).ToString.Trim
                        Row.Item(7) = CurrentRow(8).ToString.Trim
                        Row.Item(8) = CurrentRow(15).ToString.Trim
                        Row.Item(9) = CurrentRow(23).ToString.Trim
                        Row.Item(10) = CurrentRow(10).ToString.Trim & "-" & CurrentRow(11).ToString.Trim

                        'If CurrentRow(11).ToString.Trim = "C" Then
                        '    Row.Item(10) = "0"
                        '    Row.Item(11) = CurrentRow(10).ToString.Trim
                        'Else
                        '    Row.Item(10) = CurrentRow(10).ToString.Trim
                        '    Row.Item(11) = "0"
                        'End If

                        Row.Item(11) = CurrentRow(9).ToString.Trim
                        Row.Item(12) = CurrentRow(12).ToString.Trim
                        Row.Item(13) = CurrentRow(13).ToString.Trim
                        Row.Item(14) = CurrentRow(14).ToString.Trim

                        dtD.Rows.Add(Row)
                    Else 'if last row

                    End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    Public Function ReadTextGL(ByVal filename As String, ByVal delimited As String, ByVal jntype As String, ByVal datasource As String, ByVal duedate As String, ByVal lineno As Integer) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        'Dim lineno As Integer = 1
        Dim RowFooter As Integer '��ҹ�ҡ Text File
        Dim countRow As Integer 'Loop Sum �ҡ Text File
        Dim AmtHead As Decimal  '��ҹ�ҡ Text File
        Dim AmtCredit As Decimal 'Loop Sum �ҡ Text File
        Dim AmtDebit As Decimal 'Loop Sum �ҡ Text File
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()
        AmtHead = Convert.ToDecimal(CurrentRow(1).ToString)

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGL")

                            dtD.Columns.Add("JournalType")
                            dtD.Columns.Add("JournalSource")
                            dtD.Columns.Add("BusinessUnit")
                            dtD.Columns.Add("AccPeriod")
                            dtD.Columns.Add("TransRef")
                            dtD.Columns.Add("LineNo", GetType(Integer))
                            dtD.Columns.Add("TransDate")
                            dtD.Columns.Add("DueDate")
                            dtD.Columns.Add("Description")
                            dtD.Columns.Add("OracleAccCode")
                            dtD.Columns.Add("Amount")
                            dtD.Columns.Add("DC")
                            dtD.Columns.Add("OracleDept")
                            dtD.Columns.Add("OraclePLPT")
                            dtD.Columns.Add("OracleMktg")
                            dtD.Columns.Add("OracleProjectCode")
                            dtD.Columns.Add("PaymentType")
                            dtD.Columns.Add("PayeeName")
                            dtD.Columns.Add("SunAccCode")
                            dtD.Columns.Add("SunAccName")
                            dtD.Columns.Add("SunDept")
                            dtD.Columns.Add("SunPLPT")
                            dtD.Columns.Add("SunMktg")
                            dtD.Columns.Add("SunTTTR")
                            dtD.Columns.Add("SunProjectCode")

                        End If

                        If CurrentRow(0).ToString.Trim <> jntype Then
                            MsgBox("Journal Type not match")
                            dtD = Nothing
                            Return dtD
                            Exit Function
                        End If

                        If Left(CurrentRow(4).ToString.Trim, 3).ToUpper <> datasource.ToUpper Then
                            MsgBox("Datasource not match")
                            dtD = Nothing
                            Return dtD
                            Exit Function
                        End If
                        Dim txt_duedate As String
                        txt_duedate = CurrentRow(7).Substring(6, 4) & CurrentRow(7).Substring(3, 2) & CurrentRow(7).Substring(0, 2)
                        If txt_duedate <> duedate Then
                            MsgBox("DueDate not match")
                            dtD = Nothing
                            Return dtD
                            Exit Function
                        End If

                        Row = dtD.NewRow
                        lineno = lineno + 1

                        Row.Item(0) = CurrentRow(0).ToString.Trim
                        Row.Item(1) = CurrentRow(1).ToString.Trim
                        Row.Item(2) = CurrentRow(2).ToString.Trim
                        Row.Item(3) = CurrentRow(3).ToString.Trim
                        Row.Item(4) = CurrentRow(4).ToString.Trim
                        Row.Item(5) = lineno  'CurrentRow(5).ToString.Trim
                        Row.Item(6) = CurrentRow(6).ToString.Trim
                        Row.Item(7) = CurrentRow(7).ToString.Trim
                        Row.Item(8) = CurrentRow(8).ToString.Trim
                        Row.Item(9) = CurrentRow(9).ToString.Trim
                        Row.Item(10) = CurrentRow(10).ToString.Trim
                        Row.Item(11) = CurrentRow(11).ToString.Trim
                        Row.Item(12) = CurrentRow(12).ToString.Trim
                        Row.Item(13) = CurrentRow(13).ToString.Trim
                        Row.Item(14) = CurrentRow(14).ToString.Trim
                        Row.Item(15) = CurrentRow(15).ToString.Trim
                        Row.Item(16) = CurrentRow(16).ToString.Trim
                        Row.Item(17) = CurrentRow(17).ToString.Trim
                        Row.Item(18) = CurrentRow(18).ToString.Trim
                        Row.Item(19) = CurrentRow(19).ToString.Trim
                        Row.Item(20) = CurrentRow(20).ToString.Trim
                        Row.Item(21) = CurrentRow(21).ToString.Trim
                        Row.Item(22) = CurrentRow(22).ToString.Trim
                        Row.Item(23) = CurrentRow(23).ToString.Trim
                        Row.Item(24) = CurrentRow(24).ToString.Trim

                        If CurrentRow(11).ToString.Trim = "C" Then
                            AmtCredit = AmtCredit + Convert.ToDecimal(CurrentRow(10).ToString)
                        ElseIf CurrentRow(11).ToString.Trim = "D" Then
                            AmtDebit = AmtDebit + Convert.ToDecimal(CurrentRow(10).ToString)
                        End If

                        countRow = countRow + 1

                        dtD.Rows.Add(Row)
                    Else 'if last row
                        RowFooter = Convert.ToDouble(CurrentRow(0).ToString)
                    End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            'lineno = lineno + 1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        If AmtHead <> AmtCredit Then
            MsgBox("Total amount is not valid")
            dtD = Nothing
        End If

        If RowFooter <> countRow Then
            MsgBox("Line number is not valid")
            dtD = Nothing
        End If

        If AmtCredit <> AmtDebit Then
            MsgBox("Amount Credit <> Amount Debit")
            dtD = Nothing
        End If


        Return dtD

    End Function
    Public Function ReadTextGP(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGP")

                            dtD.Columns.Add("TransRef")
                            dtD.Columns.Add("PolNo")
                            dtD.Columns.Add("BillNo")
                            dtD.Columns.Add("DueDate")
                            dtD.Columns.Add("Amount")
                            dtD.Columns.Add("PaymentDesc")
                            dtD.Columns.Add("PaymentType")
                            dtD.Columns.Add("PayeeName")
                            dtD.Columns.Add("BankCode")
                            dtD.Columns.Add("BankBranch")
                            dtD.Columns.Add("BankName")
                            dtD.Columns.Add("PayeeBankAccNo")
                            dtD.Columns.Add("PayeeBankAccName")
                            dtD.Columns.Add("Comment")
                            dtD.Columns.Add("Address1")
                            dtD.Columns.Add("District")
                            dtD.Columns.Add("Province")
                            dtD.Columns.Add("InsureName")
                            dtD.Columns.Add("DataSource")
                            dtD.Columns.Add("Reserve6")
                            dtD.Columns.Add("Reserve7")
                            dtD.Columns.Add("Reserve8")
                            dtD.Columns.Add("Reserve9")
                            dtD.Columns.Add("Reserve10")
                            dtD.Columns.Add("Sys_Ref")
                            dtD.Columns.Add("Sys_Gr")

                        End If

                        Row = dtD.NewRow

                        Row.Item(0) = CurrentRow(0).ToString.Trim
                        Row.Item(1) = CurrentRow(1).ToString.Trim
                        Row.Item(2) = CurrentRow(2).ToString.Trim
                        Row.Item(3) = CurrentRow(3).ToString.Trim
                        Row.Item(4) = Convert.ToDecimal(CurrentRow(4).ToString.Trim)
                        Row.Item(5) = CurrentRow(5).ToString.Trim
                        Row.Item(6) = CurrentRow(6).ToString.Trim
                        Row.Item(7) = CurrentRow(7).ToString.Trim
                        Row.Item(8) = CurrentRow(8).ToString.Trim
                        Row.Item(9) = CurrentRow(9).ToString.Trim
                        Row.Item(10) = CurrentRow(10).ToString.Trim
                        Row.Item(11) = CurrentRow(11).ToString.Trim
                        Row.Item(12) = CurrentRow(12).ToString.Trim
                        Row.Item(13) = CurrentRow(13).ToString.Trim
                        Row.Item(14) = CurrentRow(14).ToString.Trim
                        Row.Item(15) = CurrentRow(15).ToString.Trim
                        Row.Item(16) = CurrentRow(16).ToString.Trim
                        Row.Item(17) = CurrentRow(17).ToString.Trim
                        Row.Item(18) = CurrentRow(18).ToString.Trim
                        Row.Item(19) = CurrentRow(19).ToString.Trim
                        Row.Item(20) = CurrentRow(20).ToString.Trim
                        Row.Item(21) = CurrentRow(21).ToString.Trim
                        Row.Item(22) = CurrentRow(22).ToString.Trim
                        Row.Item(23) = CurrentRow(23).ToString.Trim
                        Row.Item(24) = CurrentRow(24).ToString.Trim
                        Row.Item(25) = CurrentRow(25).ToString.Trim


                        dtD.Rows.Add(Row)
                    Else 'if last row

                    End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    Public Function ReadTextGP_Fix(ByVal filename As String, ByVal delimited As String) As DataTable
        Dim dt As DataTable = Nothing
        Dim row As DataRow
        Using Reader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)

            Reader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.FixedWidth
            Reader.SetFieldWidths(5, 5, 8, 30, 3, 11, 8, 9, -1)
            Dim currentRow As String()
            While Not Reader.EndOfData
                Try
                    currentRow = Reader.ReadFields()
                    'Dim currentField As String
                    If Not currentRow Is Nothing Then
                        If dt Is Nothing Then
                            dt = New DataTable("dtGP")

                            dt.Columns.Add("Sys_Ref")
                            dt.Columns.Add("Sys_Gr")
                            dt.Columns.Add("GenerateDate")
                            dt.Columns.Add("PaymentDesc")
                            dt.Columns.Add("BankCode")
                            dt.Columns.Add("PayeeBankAccNo")
                            dt.Columns.Add("DueDate")
                            dt.Columns.Add("Amount")
                            dt.Columns.Add("PayeeName")
                            dt.Columns.Add("BankNo")
                            dt.Columns.Add("BankName")
                        End If

                        row = dt.NewRow
                        row.Item(0) = currentRow(0).ToString.Trim
                        row.Item(1) = currentRow(1).ToString.Trim
                        row.Item(2) = currentRow(2).ToString.Trim
                        row.Item(3) = currentRow(3).ToString.Trim
                        row.Item(4) = currentRow(4).ToString.Trim
                        row.Item(5) = currentRow(5).ToString.Trim

                        Dim txt_duedate As String '17062014
                        txt_duedate = currentRow(6).Substring(0, 2) & "/" & currentRow(6).Substring(2, 2) & "/" & currentRow(6).Substring(4, 4)

                        row.Item(6) = txt_duedate 'currentRow(6).ToString.Trim
                        row.Item(7) = currentRow(7).ToString.Trim
                        row.Item(8) = currentRow(8).ToString.Trim


                        dt.Rows.Add(row)

                    End If
                    'For Each currentField In currentRow
                    '    MsgBox(currentField)
                    'Next
                Catch ex As Microsoft.VisualBasic.FileIO.MalformedLineException
                    dt = Nothing
                    MsgBox("Line " & ex.Message & "is not valid and will be skipped.")
                End Try
            End While
        End Using

        Return dt

    End Function
    Public Function ReadTextTAX(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        'CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    'If CurrentRow.Length <> 1 Then
                    If dtD Is Nothing Then
                        dtD = New DataTable("dtTAX")

                        dtD.Columns.Add("LineNo")
                        dtD.Columns.Add("TaxID")
                        dtD.Columns.Add("IDCard")
                        dtD.Columns.Add("APTitle")
                        dtD.Columns.Add("APName")
                        dtD.Columns.Add("APLastName")
                        dtD.Columns.Add("Address")
                        dtD.Columns.Add("AMPENM")
                        dtD.Columns.Add("PROVNM")
                        dtD.Columns.Add("AGZIP")
                        dtD.Columns.Add("TaxType")
                        dtD.Columns.Add("TaxItem")
                        dtD.Columns.Add("TaxDate")
                        dtD.Columns.Add("BaseAmount")
                        dtD.Columns.Add("WHTAmount")
                        dtD.Columns.Add("Payee")
                        dtD.Columns.Add("TaxRate")
                        dtD.Columns.Add("Description")
                        dtD.Columns.Add("AccountCode")
                        dtD.Columns.Add("TransRef")

                    End If

                    Row = dtD.NewRow
                    Row.Item(0) = CurrentRow(0).ToString.Trim
                    Row.Item(1) = CurrentRow(1).ToString.Trim
                    Row.Item(2) = CurrentRow(2).ToString.Trim
                    Row.Item(3) = CurrentRow(3).ToString.Trim
                    Row.Item(4) = CurrentRow(4).ToString.Trim
                    Row.Item(5) = CurrentRow(5).ToString.Trim
                    Row.Item(6) = CurrentRow(6).ToString.Trim
                    Row.Item(7) = CurrentRow(7).ToString.Trim
                    Row.Item(8) = CurrentRow(8).ToString.Trim
                    Row.Item(9) = CurrentRow(9).ToString.Trim
                    Row.Item(10) = CurrentRow(10).ToString.Trim
                    Row.Item(11) = CurrentRow(11).ToString.Trim
                    Row.Item(12) = CurrentRow(12).ToString.Trim
                    Row.Item(13) = CurrentRow(13).ToString.Trim
                    Row.Item(14) = CurrentRow(14).ToString.Trim
                    Row.Item(15) = CurrentRow(15).ToString.Trim
                    Row.Item(16) = CurrentRow(16).ToString.Trim
                    Row.Item(17) = CurrentRow(17).ToString.Trim
                    Row.Item(18) = CurrentRow(18).ToString.Trim
                    Row.Item(19) = CurrentRow(19).ToString.Trim

                    dtD.Rows.Add(Row)
                    'Else 'if last row

                    'End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    'Public Function GET_SUM_GP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select sum(gpcr_amount) as sum_gp ")
    '        sb.Append("from gps_payment_creation ")
    '        sb.Append("where gpcr_createdate='" & create_date & "' ")
    '        sb.Append("and gpcr_core_system='" & core_system & "' ")
    '        sb.Append("and gpcr_transref='" & transref & "' ")


    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GET_SUM_GP = Ds.Tables(0).Rows(0)("sum_gp")
    '    Catch ex As Exception
    '        GET_SUM_GP = 0
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GET_SUM_GL_AMOUNT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select sum(glcr_amount) sum_gl_amount ")
    '        sb.Append("from gps_gl_creation ")
    '        sb.Append("where glcr_createdate='" & create_date & "' ")
    '        sb.Append("and glcr_core_system='" & core_system & "' ")
    '        sb.Append("and glcr_transref='" & transref & "' ")
    '        sb.Append("and glcr_s_account like '2%' ")
    '        sb.Append("and glcr_drcr='C' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GET_SUM_GL_AMOUNT = Ds.Tables(0).Rows(0)("sum_gl_amount")
    '    Catch ex As Exception
    '        GET_SUM_GL_AMOUNT = 0
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GET_SUM_GL_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select sum(glcr_amount) sum_gl_wht ")
    '        sb.Append("from gps_gl_creation ")
    '        sb.Append("where glcr_createdate='" & create_date & "' ")
    '        sb.Append("and glcr_core_system='" & core_system & "' ")
    '        sb.Append("and glcr_transref='" & transref & "' ")
    '        sb.Append("and glcr_drcr='C' ")
    '        sb.Append("and glcr_s_tt_tr='00000000' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GET_SUM_GL_WHT = Ds.Tables(0).Rows(0)("sum_gl_wht")
    '    Catch ex As Exception
    '        GET_SUM_GL_WHT = 0
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GET_SUM_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select sum(taxcr_tax_amt) ")
    '        sb.Append("from gps_wht_creation ")
    '        sb.Append("where taxcr_createdate='" & create_date & "' ")
    '        sb.Append("and taxcr_core_system='" & core_system & "' ")
    '        sb.Append("and taxcr_transref='" & transref & "' ")


    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GET_SUM_WHT = Ds.Tables(0).Rows(0)("sum_wht")
    '    Catch ex As Exception
    '        GET_SUM_WHT = 0
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GetPaidDate_GLGP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select glcr_duedate ")
    '        sb.Append("from gps_gl_creation ")
    '        sb.Append("where glcr_createdate='" & create_date & "' ")
    '        sb.Append("and glcr_core_system='" & core_system & "' ")
    '        sb.Append("and glcr_transref='" & transref & "' ")
    '        sb.Append("and glcr_s_account like '2%' and glcr_drcr ='C' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GetPaidDate_GLGP = Ds.Tables(0).Rows(0)("glcr_duedate")
    '    Catch ex As Exception
    '        GetPaidDate_GLGP = ""
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function ChkNetAmountError(ByRef oleConn As OleDbConnection, ByVal user As String) As DataTable
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select gpcr_amount ")
    '        sb.Append("from gps_tmp_payment_creation ")
    '        sb.Append("where createdby='" & user & "' and gpcr_amount <=0 ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        ChkNetAmountError = Ds.Tables(0)
    '    Catch ex As Exception
    '        ChkNetAmountError = Nothing
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GetPaidDate_GLWHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select glcr_duedate ")
    '        sb.Append("from gps_gl_creation ")
    '        sb.Append("where glcr_createdate='" & create_date & "' ")
    '        sb.Append("and glcr_core_system='" & core_system & "' ")
    '        sb.Append("and glcr_transref='" & transref & "' ")
    '        sb.Append("and glcr_drcr ='C' and glcr_s_tt_tr <> '00000000' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GetPaidDate_GLWHT = Ds.Tables(0).Rows(0)("glcr_duedate")
    '    Catch ex As Exception
    '        GetPaidDate_GLWHT = ""
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GetPaidDate_GP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select gpcr_paiddate ")
    '        sb.Append("from gps_payment_creation ")
    '        sb.Append("where gpcr_createdate='" & create_date & "' ")
    '        sb.Append("and gpcr_core_system='" & core_system & "' ")
    '        sb.Append("and gpcr_transref='" & transref & "' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GetPaidDate_GP = Ds.Tables(0).Rows(0)("gpcr_paiddate")
    '    Catch ex As Exception
    '        GetPaidDate_GP = ""
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
    'Public Function GetPaidDate_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
    '    Try
    '        Dim sb As New StringBuilder()
    '        Dim Ds As New DataSet

    '        sb.Append("select taxcr_taxdate ")
    '        sb.Append("from gps_wht_creation ")
    '        sb.Append("where taxcr_createdate='" & create_date & "' ")
    '        sb.Append("and taxcr_core_system='" & core_system & "' ")
    '        sb.Append("and taxcr_transref='" & transref & "' ")

    '        ExecuteReader(oleConn, Ds, sb.ToString)
    '        GetPaidDate_WHT = Ds.Tables(0).Rows(0)("taxcr_taxdate")
    '    Catch ex As Exception
    '        GetPaidDate_WHT = ""
    '        gLastErrMessage = ex.ToString
    '    End Try
    'End Function
  
    'Public Function fnNetAmountError(ByRef oleConn As OleDbConnection, ByVal user As String) As Boolean
    '    Dim ret As Boolean
    '    Dim dt As New DataTable

    '    dt = ChkNetAmountError(oleConn, user)

    '    If dt.Rows.Count > 0 Then
    '        ret_RejectCode = "PAMT_ERR"
    '        ret = False
    '    Else
    '        ret = False
    '        ret_RejectCode = ""
    '    End If
    '    Return ret

    'End Function
    'Public Function fnPaidDateNotMatch(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
    '    Dim ret As Boolean
    '    Dim strPaidDate_GLWHT, strPaidDate_GP, strPaidDate_WHT, strPaidDate_GLGP As String

    '    strPaidDate_GLGP = GetPaidDate_GLGP(oleConn, create_date, core_system, transref)
    '    strPaidDate_GLWHT = GetPaidDate_GLWHT(oleConn, create_date, core_system, transref)
    '    strPaidDate_GP = GetPaidDate_GP(oleConn, create_date, core_system, transref)
    '    strPaidDate_WHT = GetPaidDate_WHT(oleConn, create_date, core_system, transref)

    '    If (strPaidDate_GLGP <> strPaidDate_GP) Or (strPaidDate_GLWHT <> strPaidDate_WHT) Then
    '        ret = False
    '        ret_RejectCode = "PDTE_NOMAT"
    '    Else
    '        ret_RejectCode = ""
    '        ret = False
    '    End If
    '    Return ret

    'End Function
    'Public Function fnNetAmountNotMatch(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
    '    Dim ret As Boolean
    '    Dim sum_gp, sum_gl_amount, sum_gl_wht, sum_wht As Double

    '    sum_gp = GET_SUM_GP(oleConn, create_date, core_system, transref)
    '    sum_gl_amount = GET_SUM_GL_AMOUNT(oleConn, create_date, core_system, transref)
    '    sum_gl_wht = GET_SUM_GL_WHT(oleConn, create_date, core_system, transref)
    '    sum_wht = GET_SUM_WHT(oleConn, create_date, core_system, transref)

    '    If (sum_gp <> sum_gl_amount) Or (sum_gl_wht <> sum_wht) Then
    '        ret = False
    '        ret_RejectCode = "PAMT_NOMAT"
    '    Else
    '        ret_RejectCode = ""
    '        ret = False
    '    End If

    '    Return ret

    'End Function
    Public Function fnCallBatchNo(ByRef oleConn As OleDbConnection, ByVal systemdate As String) As String
        Dim batchno As String
        Dim sb As New StringBuilder


        sb.Append("select nvl(max(gpcm_batch_no),0) batch_no from gps_payment_complete where gpcm_batchdate='" & systemdate & "' ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim no As Integer
            no = Convert.ToInt16(Right(dt.Rows(0)("batch_no"), 2)) + 1
            batchno = "GP" & systemdate & no.ToString.PadLeft(2, "0")
        Else
            batchno = "GP" & systemdate & "01"
        End If
        Return batchno
    End Function
    Public Function INS_GPS_PRNCHQ_OTHBNK(ByRef oleConn As OleDbConnection, ByRef oTrans As OleDbTransaction, ByVal dr As DataRow) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("INSERT INTO GPS_PRNCHQ_OTHBNK( ")
            sb.Append("PCHQ_BNKCODE, ")
            sb.Append("PCHQ_CHQNO, ")
            sb.Append("PCHQ_PAYEE_NAME, ")
            sb.Append("PCHQ_AMOUNT, ")
            sb.Append("PCHQ_PAIDDATE, ")
            sb.Append("CREATEDBY, ")
            sb.Append("CREATEDDATE, ")
            sb.Append("UPDATEDBY, ")
            sb.Append("UPDATEDDATE) ")
            sb.Append("VALUES ( ")
            sb.Append("'" & dr("PCHQ_BNKCODE") & "',")
            sb.Append("'" & dr("PCHQ_CHQNO") & "',")
            sb.Append("'" & dr("PCHQ_PAYEE_NAME") & "',")
            sb.Append("'" & dr("PCHQ_AMOUNT") & "',")
            sb.Append("'" & dr("PCHQ_PAIDDATE") & "',")
            sb.Append("'" & dr("CREATEDBY") & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
            sb.Append("'" & dr("UPDATEDBY") & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

            INS_GPS_PRNCHQ_OTHBNK = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            INS_GPS_PRNCHQ_OTHBNK = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetRptPrtCheque(ByRef oleConn As OleDbConnection, ByVal bnkcode As String, ByVal chqno As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_PRNCHQ_OTHBNK WHERE PCHQ_BNKCODE='" & bnkcode & "' AND  PCHQ_CHQNO='" & chqno & "' ")
        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetMaxLetterNo(ByRef oleConn As OleDbConnection) As String
        Dim sb As New StringBuilder

        sb.Append("SELECT TO_CHAR(SYSDATE,'YYYY') AS YYYY,NVL(MAX(SUBSTR(LETT_NO,-6)),0) AS LETT_NO FROM GPS_LETTERNO_SETUP WHERE LETT_YEAR=TO_CHAR(SYSDATE,'YYYY')")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)("LETT_NO") = 0 Then
                Return "Treasury-" & dt.Rows(0)("YYYY") & "/000001"
            Else
                Dim no As String
                no = Convert.ToDecimal(dt.Rows(0)("LETT_NO")) + 1
                Return "Treasury-" & dt.Rows(0)("YYYY") & "/" & no.PadLeft(6, "0")
            End If
        Else
            Return Nothing
        End If
    End Function
    Public Function INS_GPS_LETTERNO_SETUP(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("INSERT INTO GPS_LETTERNO_SETUP ( ")
        sb.Append("LETT_YEAR, ")
        sb.Append("LETT_NO, ")
        sb.Append("CREATEDBY, ")
        sb.Append("CREATEDDATE, ")
        sb.Append("UPDATEDBY, ")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES( ")
        sb.Append("'" & dr("LETT_YEAR") & "',")
        sb.Append("'" & dr("LETT_NO") & "',")
        sb.Append("'" & dr("CREATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & dr("UPDATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')")
        sb.Append(") ")


        rec = ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GPS_LETTERNO_SETUP(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_LETTERNO_SETUP SET ")
        sb.Append("LETT_NO='" & dr("LETT_NO") & "',")
        sb.Append("UPDATEDBY='" & dr("UPDATEDBY") & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE LETT_YEAR='" & dr("LETT_YEAR") & "' ")


        rec = ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function GetReportContract(ByRef oleConn As OleDbConnection, ByVal rpt_id As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT * FROM GPS_TL_CONTRACT_RPT WHERE CONT_REPORT_ID='" & rpt_id & "' ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataRptWHT(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,W.TAX_WHTNO,W.TAX_TAXDATE,W.TAX_AP_TTL||W.TAX_AP_FNAME||W.TAX_AP_LNAME AS PAYEENAME,W.TAX_TAXID,W.TAX_BASE_AMT,  ")
        sb.Append("W.TAX_TAX_AMT,(W.TAX_BASE_AMT-W.TAX_TAX_AMT) AS AMOUNT,W.TAX_TRANSREF,  ")
        sb.Append("W.TAX_PHORNGORDOR,S.STS_DESC  AS TAX_PRINTWHT_STS,W.TAX_PRINTWHT_STSDATE  ")
        sb.Append("FROM (GPS_WHT W INNER JOIN GPS_TRANSREF_REL L    ")
        sb.Append("ON W.TAX_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND W.TAX_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND W.TAX_TRANSREF=L.TREF_TRANSREF ) ")
        sb.Append("LEFT JOIN ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='PRN_WHT')S ")
        sb.Append("ON W.TAX_PRINTWHT_STS=S.STS_STATUS ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO ")


        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function fnGet_pathconfig(ByRef oleConn As OleDbConnection, ByVal fn As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CPATH_PATH FROM GPS_TL_CONFIG_PATH  WHERE CPATH_FUNC = '" & fn & "' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            fnGet_pathconfig = Ds.Tables(0).Rows(0)("CPATH_PATH")

        Catch ex As Exception
            fnGet_pathconfig = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function


End Class
