Imports System.Collections.Generic
Imports System.Windows.Forms

Public NotInheritable Class ClsMenuItem
    Private Sub New()
    End Sub
#Region "Methods"

    ''' <summary>
    ''' Gets a list of all ToolStripMenuItems
    ''' </summary>
    ''' <param name="menuStrip">The menu strip control</param>
    ''' <returns>List of all ToolStripMenuItems</returns>
    Public Shared Function GetItems(ByRef menuStrip As MenuStrip) As List(Of ToolStripMenuItem)
        Dim myItems As New List(Of ToolStripMenuItem)()
        For Each i As ToolStripMenuItem In menuStrip.Items
            GetMenuItems(i, myItems)
        Next
        Return myItems
    End Function

    ''' <summary>
    ''' Gets the menu items.
    ''' </summary>
    ''' <param name="item">The item.</param>
    ''' <param name="items">The items.</param>
    Private Shared Sub GetMenuItems(ByVal item As ToolStripMenuItem, ByVal items As List(Of ToolStripMenuItem))
        items.Add(item)
        For Each i As ToolStripItem In item.DropDownItems
            If TypeOf i Is ToolStripMenuItem Then
                GetMenuItems(DirectCast(i, ToolStripMenuItem), items)
            End If
        Next
    End Sub


    Public Shared Function SetItems(ByRef menuStrip As MenuStrip) As List(Of ToolStripMenuItem)
        Dim myItems As New List(Of ToolStripMenuItem)()
        For Each i As ToolStripMenuItem In menuStrip.Items
            GetMenuItems(i, myItems)
        Next
        Return myItems
    End Function

    Private Shared Sub SetMenuItems(ByVal item As ToolStripMenuItem, ByVal items As List(Of ToolStripMenuItem))
        items.Add(item)
        For Each i As ToolStripItem In item.DropDownItems
            If TypeOf i Is ToolStripMenuItem Then
                GetMenuItems(DirectCast(i, ToolStripMenuItem), items)
            End If
        Next
    End Sub

#End Region
End Class



