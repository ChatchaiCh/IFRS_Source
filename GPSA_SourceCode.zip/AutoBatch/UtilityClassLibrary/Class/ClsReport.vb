Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function DtJournalListingRpt(ByRef oleConn As OleDbConnection, ByVal postdate As String, ByVal fn As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT D.GL_JN_TYPE,D.GL_PERIOD,D.GL_JN_NO,D.GL_LINENO,D.GL_DESC,D.GL_TRANSDATE,D.GL_DUEDATE,D.GL_S_ACCOUNT AS ACC,D.GL_DESC AS ACCNAME, ")
        sb.Append("D.GL_VCH_NO  AS SEQNO,D.GL_S_DEP_BRN AS DEPT_BR,D.GL_S_PL_PT AS PL_PT,D.GL_S_MKT_EMP AS MKT_EMP, ")
        sb.Append("D.GL_S_PROJECT AS PROJECT,D.GL_S_TT_TR AS TT_TR,D.GL_DRCR AS DR_CR,D.GL_AMOUNT AS AMOUNT ")
        sb.Append("FROM GLM_GL_DAILY D  WHERE D.GL_POSTING_DATE='" & postdate & "'   ")

        If fn <> "0" Then
            Select Case fn
                Case "1"
                    sb.Append("AND D.GL_FUNCTION = 'GP01' ")
                Case "2"
                    sb.Append("AND D.GL_FUNCTION = 'GP02' ")
                Case "3"
                    sb.Append("AND D.GL_FUNCTION = 'GP03' ")
                Case "4"
                    sb.Append("AND D.GL_FUNCTION = 'GP04' ")
                Case "5"
                    sb.Append("AND D.GL_FUNCTION = 'GP05' ")
                Case "6"
                    sb.Append("AND D.GL_FUNCTION = 'GP06' ")
            End Select

        End If

        sb.Append("ORDER BY D.GL_JN_NO,D.GL_VCH_NO ,D.GL_LINENO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function DtRptAgingOutStandingPayment(ByRef oleConn As OleDbConnection, ByVal business_date As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select diff,case when diff >=1 and diff <=7 then 'G1'  ")
        sb.Append("when diff >=8 and diff <=14 then 'G2'  ")
        sb.Append("when diff >=15 and diff <=21 then 'G3'     ")
        sb.Append("when diff >=22 and diff <=28 then 'G4' ")
        sb.Append("when diff >=29 and diff <=35 then 'G5' ")
        sb.Append("when diff >=36 then 'G6'  end diffgroup, ")
        sb.Append("jn_vch,tref_paiddate,tref_transref,gl_amt,gp_amt,tax_amt ")
        sb.Append("from ")
        sb.Append("(select  ")
        sb.Append("to_date(t.tref_paiddate,'YYYYMMDD')-to_date('" & business_date & "','YYYYMMDD') as diff,t.tref_transref,t.tref_paiddate, ")
        sb.Append("case when t.tref_approveddate is null then t.tref_jn_hold else t.tref_vch_no_c end as jn_vch, ")
        sb.Append("sum(gl.glcr_amount) as gl_amt,sum(gp.gpcr_amount) as gp_amt,sum(w.taxcr_tax_amt) as tax_amt ")
        sb.Append("from (((gps_transref_rel t inner join gps_gl_creation gl ")
        sb.Append("on t.tref_createdate=gl.glcr_createdate ")
        sb.Append("and t.tref_core_system=gl.glcr_core_system ")
        sb.Append("and t.tref_transref=gl.glcr_transref)  ")
        sb.Append("inner join  ")
        sb.Append("gps_payment_creation gp ")
        sb.Append("on t.tref_createdate=gp.gpcr_createdate ")
        sb.Append("and t.tref_core_system=gp.gpcr_core_system ")
        sb.Append("and t.tref_transref=gp.gpcr_transref) ")
        sb.Append("left join ")
        sb.Append("gps_wht_creation w ")
        sb.Append("on t.tref_createdate=w.taxcr_createdate ")
        sb.Append("and t.tref_core_system=w.taxcr_core_system ")
        sb.Append("and t.tref_transref=w.taxcr_transref) ")
        sb.Append("where t.tref_paiddate > '" & business_date & "' ")
        sb.Append("and gl.glcr_drcr='C' ")
        sb.Append("and t.tref_paycretyp_id='001' ")
        sb.Append("and t.tref_createdate <= '" & business_date & "' ")
        sb.Append("and (t.tref_approvedby is null or t.tref_approveddate < '" & business_date & "' ) ")
        sb.Append("and t.tref_core_system='ACC' ")
        sb.Append("group by  t.tref_paiddate,case when t.tref_approveddate is null then t.tref_jn_hold else t.tref_vch_no_c end,t.tref_transref)  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function DtRptPendingReceipt(ByRef oleConn As OleDbConnection, ByVal datefrom As String, ByVal dateto As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select g.payg_pay_groupname,r.tref_batch_no,r.tref_vch_no_c,p.gp_paiddate, ")
        sb.Append("case when p.gp_paymth='C' or p.gp_paymth='D' then p.gp_chqno else p.gp_bnksacc_no end chqno, ")
        sb.Append("case when p.gp_paymth='C' or p.gp_paymth='D' then p.gp_payee_name else p.gp_payee_bnkaccnme end payeename,   ")
        sb.Append("p.gp_amount,NVL(w.tax_amt,0) as tax_amt ")
        sb.Append("from ((((gps_payment p inner join gps_transref_rel r ")
        sb.Append("on p.gp_createdate=r.tref_createdate ")
        sb.Append("and p.gp_core_system=r.tref_core_system ")
        sb.Append("and p.gp_transref=r.tref_transref) ")
        sb.Append("left join  ")
        sb.Append("(select w.tax_createdate,w.tax_core_system,w.tax_transref,sum(w.tax_tax_amt) as tax_amt ")
        sb.Append("from gps_wht w ")
        sb.Append("group by w.tax_createdate,w.tax_core_system,w.tax_transref ")
        sb.Append(")w ")
        sb.Append("on p.gp_createdate=w.tax_createdate ")
        sb.Append("and p.gp_core_system=w.tax_core_system ")
        sb.Append("and p.gp_transref=w.tax_transref) ")
        sb.Append("inner join gps_tl_paytype t ")
        sb.Append("on p.gp_paymth=t.payt_paymth and p.gp_sub_paymth=t.payt_sub_paymth) ")
        sb.Append("inner join gps_tl_paygroup g on t.payt_pay_group=g.payg_pay_group) ")
        sb.Append("where p.gp_flag_flwbill='Y' ")
        sb.Append("and p.gp_lastupd_sts<>'W' and not(p.gp_paymth='M' and p.gp_lastupd_sts='R') ")
        sb.Append("and p.gp_lastupd_stsdate between '" & datefrom & "' and '" & dateto & "' ")
        sb.Append("order by g.payg_pay_groupname,p.gp_paiddate,r.tref_batch_no ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function DtRptRejectHis(ByRef oleConn As OleDbConnection, ByVal datefrom As String, ByVal dateto As String, ByVal rejtype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' and r.gprj_sub_paymth='M' then r.gprj_payee_bnkaccno else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_batchdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate between '" & datefrom & "' and '" & dateto & "'  ")

        If rejtype <> "0" Then
            Select Case rejtype
                Case "1"
                    sb.Append("and r.gprj_reject_func='VALIDATE' ")
                Case "2"
                    sb.Append("and r.gprj_reject_func='HASH' ")
                Case "3"
                    sb.Append("and r.gprj_reject_func='BANK' ")
            End Select
        End If



        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
End Class
