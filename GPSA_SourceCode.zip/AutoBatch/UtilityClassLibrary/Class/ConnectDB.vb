Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration
Imports SCNYL_Connection2005.SCNYL_Connection
Public Class ConnectDB
    Public gConnGP As New OleDbConnection
    Public gConnGP_2 As New OleDbConnection
    Public ErrConnectDBMessage As String
    Public gP As String

    Public Function OpenConnGP() As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim sServer As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper
        Dim sServer2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        '-- remark start by ppk
        'Try
        '    ClsScnylConn.OpenConnection(gConnGP, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)
        '    OpenConnGP = True
        'Catch ex As Exception
        '    ErrConnectDBMessage = ex.ToString
        '    OpenConnGP = False
        'End Try
        '-- remark end by ppk

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        '-- CR#174 App2App --

        Try
            'System.Console.Write(sACCESSLOCATION1)
            'System.Console.Write(sSERVICENAME1)
            'System.Console.Write(sSYSTEMCODE1)
            'System.Console.Write(sLOCATIONTYPE1)
            'System.Console.Write(sSEQID1)
            'System.Console.Write(gP)
            gP = SCNYL_Connection2005.SCNYL_Connection.GetAuthorize(sACCESSLOCATION1 _
                                                                      , sSERVICENAME1 _
                                                                      , sSYSTEMCODE1 _
                                                                      , sLOCATIONTYPE1 _
                                                                      , sSEQID1)
            'System.Console.Write(gP)
            gP = gP.Replace("%", "%%")
            ClsScnylConn.OpenConnection(gConnGP, EnumAccessLocationType.ALT_ORACLE, sSYSTEMCODE1, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sSERVICENAME1, EnumLocationType.LT_ORACLE, sSEQID1, sSERVICENAME2)
            OpenConnGP = True
        Catch ex As Exception
            ErrConnectDBMessage = ex.ToString
            OpenConnGP = False
        End Try

    End Function
    Public Function OpenConnGP_2() As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim sServer As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper
        Dim sServer2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        '-- remark start by ppk
        'Try
        '    ClsScnylConn.OpenConnection(gConnGP_2, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)
        '    OpenConnGP_2 = True
        'Catch ex As Exception
        '    ErrConnectDBMessage = ex.ToString
        '    OpenConnGP_2 = False
        'End Try
        '-- remark end by ppk

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        '-- CR#174 App2App --

        Try
            gP = SCNYL_Connection2005.SCNYL_Connection.GetAuthorize(sACCESSLOCATION1 _
                                                                      , sSERVICENAME1 _
                                                                      , sSYSTEMCODE1 _
                                                                      , sLOCATIONTYPE1 _
                                                                      , sSEQID1)
            gP = gP.Replace("%", "%%")
            ClsScnylConn.OpenConnection(gConnGP_2, EnumAccessLocationType.ALT_ORACLE, sSYSTEMCODE1, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sSERVICENAME1, EnumLocationType.LT_ORACLE, sSEQID1, sSERVICENAME2)
            OpenConnGP_2 = True
        Catch ex As Exception
            ErrConnectDBMessage = ex.ToString
            OpenConnGP_2 = False
        End Try

    End Function
End Class
