Imports System.Data
Imports System.Data.OleDb

Namespace DataClass
    Public Class clsData_WORK

#Region "Public Methods"

        Public Function BuildInsertSQL(ByVal dr As DataRow) As String
            Dim sb As New System.Text.StringBuilder
            sb.Append("INSERT WORK VALUES(")
            sb.AppendFormat(" '{0}',", dr("WORKCODE"))
            sb.AppendFormat(" '{0}',", dr("WORKPARENTCODE"))
            sb.AppendFormat(" '{0}',", dr("WORKNAME"))
            sb.AppendFormat(" '{0}',", dr("WORKURL"))
            sb.AppendFormat(" '{0}',", dr("WORKTYPE"))
            sb.AppendFormat(" '{0}',", dr("INSERTUSER"))
            sb.AppendFormat(" '{0}',", dr("INSERTPROGRAM"))
            sb.AppendFormat(" '{0}',", dr("INSERTDATE"))
            sb.AppendFormat(" '{0}',", dr("INSERTTIME"))
            sb.AppendFormat(" '{0}',", dr("UPDATEUSER"))
            sb.AppendFormat(" '{0}',", dr("UPDATEPROGRAM"))
            sb.AppendFormat(" '{0}',", dr("UPDATEDATE"))
            sb.AppendFormat(" '{0}',", dr("UPDATETIME"))
            sb.AppendFormat(" '{0}' ", dr("RECORDSTATUS"))

            sb.Append(");")
            sb.Append(" SELECT CAST(scope_identity() as int);")
            Return sb.ToString
        End Function

        Public Function BuildUpdateSQL(ByVal dr As DataRow) As String
            Dim sb As New System.Text.StringBuilder
            sb.Append("UPDATE work SET ")
            sb.AppendFormat("PROJECTCODE='{0}',", dr("PROJECTCODE"))
            sb.AppendFormat("WORKCODE='{0}',", dr("WORKCODE"))
            sb.AppendFormat("WORKPARENTCODE='{0}',", dr("WORKPARENTCODE"))
            sb.AppendFormat("WORKNAME='{0}',", dr("WORKNAME"))
            sb.AppendFormat("WORKURL='{0}',", dr("WORKURL"))
            sb.AppendFormat("WORKTYPE='{0}',", dr("WORKTYPE"))
            sb.AppendFormat("INSERTUSER='{0}',", dr("INSERTUSER"))
            sb.AppendFormat("INSERTPROGRAM='{0}',", dr("INSERTPROGRAM"))
            sb.AppendFormat("INSERTDATE='{0}',", dr("INSERTDATE"))
            sb.AppendFormat("INSERTTIME='{0}',", dr("INSERTTIME"))
            sb.AppendFormat("UPDATEUSER='{0}',", dr("UPDATEUSER"))
            sb.AppendFormat("UPDATEPROGRAM='{0}',", dr("UPDATEPROGRAM"))
            sb.AppendFormat("UPDATEDATE='{0}',", dr("UPDATEDATE"))
            sb.AppendFormat("UPDATETIME='{0}',", dr("UPDATETIME"))
            sb.AppendFormat("RECORDSTATUS='{0}' ", dr("RECORDSTATUS"))

            sb.AppendFormat(" WHERE PROJECTCODE='{0}'", dr("PROJECTCODE"))
            Return sb.ToString
        End Function

        Public Function BuildDeleteSQL(ByVal dr As DataRow) As String
            Dim sb As New System.Text.StringBuilder
            sb.Append("DELETE FROM work ")
            sb.AppendFormat(" WHERE PROJECTCODE='{0}'", dr("PROJECTCODE").ToString)
            Return sb.ToString
        End Function
#Region "Get Record"
        Public Function GetRecord(ByVal strKey As String, ByVal strCn As String) As DataRow
            '
            Dim strSQL As String = String.Format( _
            " SELECT *  " & _
            " FROM work" & _
            " WHERE PROJECTCODE" & _
            " = '{0}' ", strKey)
            Try
                GetRecord = Dataclass.clsDataAccess.GetDataRow(strSQL, strCn)
            Catch ex As Exception
                GetRecord = Nothing
                Throw ex
            End Try
        End Function

        Public Function GetDataRow_GetIniNode(ByVal strCn As String, ByVal sprojectcode As String) As DataRow()
            Try
                Dim strsql As String
                Dim DS As New DataSet
                Dim objDr() As DataRow
                strsql = " Select * FROM  work WHERE  workparentcode ='0' and projectcode='" & sprojectcode & "' order by workname"

                DS = DataClass.clsDataAccess.GetDataSet(strsql, strCn)
                objDr = DS.Tables(0).Select
                Return objDr
            Catch ex As Exception
                Err.Raise(Err.Number, Err.Source, Err.Description)
                Return Nothing
            End Try
        End Function

        Public Function GetDataRow_GetChild(ByVal strCn As String, ByVal strFungrpcode As String, ByVal strProjectcode As String) As DataRow()
            Try
                Dim strsql As String
                Dim DS As New DataSet
                Dim objDr() As DataRow
                strsql = " Select * FROM work where FunPRTCODE ='" & strFungrpcode & " and projectcode ='" & strProjectcode & "' order by Fungrpname"
                DS = DataClass.clsDataAccess.GetDataSet(strsql, strCn)
                objDr = DS.Tables(0).Select
                Return objDr
            Catch ex As Exception
                Err.Raise(Err.Number, Err.Source, Err.Description)
                Return Nothing
            End Try
        End Function
        Public Function GetDataSetGroupWork(ByVal strCn As String, ByVal strProjectcode As String) As DataSet

            Dim strsql As String

            Try
                strsql = "SELECT * FROM  groupwork  where projectcode='" & strProjectcode & "'"
                Return Dataclass.clsDataAccess.GetDataSet(strsql, strCn)
            Catch ex As Exception
                GetDataSetGroupWork = Nothing
                Throw ex
            End Try
        End Function
        Public Function GetDataSet(ByVal strCn As String, ByVal strProjectcode As String) As DataSet

            Dim strsql As String

            Try
                strsql = "SELECT * FROM  Work  where projectcode='" & strProjectcode & "'"

                Return Dataclass.clsDataAccess.GetDataSet(strsql, strCn)
            Catch ex As Exception
                GetDataSet = Nothing
                Throw ex
            End Try
        End Function
        Public Function GetData_GroupID(ByVal strCn As String, ByVal struserscode As String) As DataRow()

            Dim strsql As String
            Dim DS As New DataSet
            Dim objDr() As DataRow

            Try

                strsql = "SELECT groupcode FROM  groupusers  where userscode='" & struserscode & "'"

                DS = Dataclass.clsDataAccess.GetDataSet(strsql, strCn)
                objDr = DS.Tables(0).Select

                Return objDr
            Catch ex As Exception
                GetData_GroupID = Nothing
                Throw ex
            End Try

        End Function

        Public Function Find_Funcid_FIX(ByVal strKeyGRPID As String, ByVal strKeyFNCID As String, ByVal DS As DataSet) As Boolean
            Dim objdview As DataView
            Dim objrowview As DataRowView
            Dim strsql As String
            Try
                If strKeyGRPID = "" Then
                    strsql = " 1=2"
                Else
                    strsql = "  groupcode in " & Trim(strKeyGRPID) & "  and workcode ='" & Trim(strKeyFNCID) & "'"
                End If
                objdview = DS.Tables(0).DefaultView
                objdview.RowFilter = strsql
                For Each objrowview In objdview
                    Return True
                Next

            Catch ex As Exception
                Err.Raise(Err.Number, Err.Source, Err.Description)
                Return False
            End Try
        End Function

        Public Function GetAllRows(ByVal strCn As String) As DataTable
            Dim strSQL As String = "SELECT * FROM work"
            Try
                GetAllRows = Dataclass.clsDataAccess.GetDataTable(strSQL, strCn)
            Catch ex As Exception
                GetAllRows = Nothing
                Throw ex
            End Try
        End Function
#End Region

#Region "Insert"

        Public Function InsertRecord( _
        ByVal dr As DataRow, ByVal strCn As String) As Integer
            Dim strSQL As String = BuildInsertSQL(dr)
            Using cn As New OleDb.OleDbConnection(strCn)
                Try
                    cn.Open()
                    Dim cmd As New OleDb.OleDbCommand(strSQL, cn)
                    cmd.ExecuteScalar()
                    InsertRecord = 1
                Catch ex As Exception
                    InsertRecord = 0
                    Throw ex
                End Try
            End Using
        End Function

        Public Function InsertRecord( _
        ByVal dr As DataRow, _
        ByVal cn As OleDb.OleDbConnection, _
        ByVal tran As OleDb.OleDbTransaction) As Integer
            Dim strSQL As String = BuildInsertSQL(dr)
            Try
                Dim cmd As New OleDb.OleDbCommand(strSQL, cn, tran)
                cmd.ExecuteScalar()
                InsertRecord = 1
            Catch ex As Exception
                InsertRecord = 0
                Throw ex
            End Try
        End Function

#End Region

#Region "Update"

        Public Function UpdateRecord( _
        ByVal dr As DataRow, ByVal strCn As String) As Long
            Dim strSQL As String = BuildUpdateSQL(dr)
            Using cn As New OleDb.OleDbConnection(strCn)
                Try
                    cn.Open()
                    Dim cmd As New OleDb.OleDbCommand(strSQL, cn)
                    UpdateRecord = CType(cmd.ExecuteScalar(), Long)
                Catch ex As Exception
                    UpdateRecord = 0
                    Throw ex
                End Try

            End Using
        End Function

        Public Function UpdateRecord( _
        ByVal dr As DataRow, _
        ByVal cn As OleDb.OleDbConnection, _
        ByVal tran As OleDb.OleDbTransaction) As Long
            '
            Dim strSQL As String = BuildUpdateSQL(dr)
            Try
                Dim cmd As New OleDb.OleDbCommand(strSQL, cn, tran)
                UpdateRecord = CType(cmd.ExecuteScalar(), Long)
            Catch ex As Exception
                UpdateRecord = 0
                Throw ex
            End Try

        End Function

#End Region

#Region "Delete"

        Public Function DeleteRecord( _
        ByVal dr As DataRow, ByVal strCn As String) As Long
            Dim strSQL As String = BuildDeleteSQL(dr)
            Using cn As New OleDb.OleDbConnection(strCn)
                Try
                    cn.Open()
                    Dim cmd As New OleDb.OleDbCommand(strSQL, cn)
                    DeleteRecord = CType(cmd.ExecuteScalar(), Long)
                Catch ex As Exception
                    DeleteRecord = 0
                    Throw ex
                End Try
            End Using

        End Function

        Public Function DeleteRecord( _
        ByVal dr As DataRow, _
        ByVal cn As OleDb.OleDbConnection, _
        ByVal tran As OleDb.OleDbTransaction) As Long
            '
            Dim strSQL As String = BuildDeleteSQL(dr)
            Try
                Dim cmd As New OleDb.OleDbCommand(strSQL, cn, tran)
                DeleteRecord = CType(cmd.ExecuteScalar(), Long)
            Catch ex As Exception
                DeleteRecord = 0
                Throw ex
            End Try

        End Function

#End Region

#End Region

    End Class
End Namespace

