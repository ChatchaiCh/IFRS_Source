Imports UtilityClassLibrary
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
' Batch �ͺ���д֧������੾�� Cheque ��� Draft  ��ҹ�� 
Public Class FrmImpResultBank
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Private Sub FrmImpResultBank_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dt_ImportFile As DataTable
            Dim dt_DetailImportFile As DataTable
            Dim dt_UpdateStatusFile As DataTable
            Dim strmsgbox As String
            Dim sb As New StringBuilder
            Dim oleTrans As OleDbTransaction
            Dim Rec As Integer
            Dim HaveRejectBank As Boolean
            Dim strcurrentDate As String

            My.Application.ChangeCulture("en-GB")

            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                    'Return exit code to batch
                    Environment.ExitCode = 2

                    Exit Sub
                End If
            End If

            'oleTrans = clsUtility.gConnGP.BeginTransaction
            dt_ImportFile = CheckDataImportCD()

            strmsgbox = ""

            HaveRejectBank = False
            strcurrentDate = Now.ToString("yyyyMMdd")

            If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then


                For Each dr_ImportFile As DataRow In dt_ImportFile.Rows

                    ' -- ��Ǩ�ͺ����� File �š�Ѻ���������
                    If Not String.IsNullOrEmpty(dr_ImportFile("IMPBANK_FILENME").ToString) Then
                        'oleTrans = clsUtility.gConnGP.BeginTransaction

                        '-- ��Ǩ�ͺ������� File ��� Import ����� �ըӹǹ��¡�� ����ʹ�Թ�١��ͧ�������
                        If (dr_ImportFile("IMPBANK_CountTrans").ToString <> dr_ImportFile("IMPBANK_TOTCountTrans").ToString) Or (dr_ImportFile("IMPBANK_AmountTrans").ToString <> dr_ImportFile("IMPBANK_TOTAmountTrans").ToString) Then

                            '---- ��Ǩ�ͺ File ��� Import ���١��ͧ  Update D - Delete
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL  ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = ''D''  ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = ''' " & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "'''  ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                            ' -- ��Ǩ�ͺ��� File ��� Import ����� ��� Export 仹�� �ըӹǹ��¡�� ����ʹ�Թ�١��ͧ�������
                        ElseIf (dr_ImportFile("IMPBANK_CountTrans").ToString <> dr_ImportFile("EXPTOBANK_CountTrans").ToString) Or (dr_ImportFile("IMPBANK_AmountTrans").ToString <> dr_ImportFile("EXPTOBANK_AmountTrans").ToString) Then

                            '---- ��Ǩ�ͺ File ��� Import ���١��ͧ  Update D - Delete
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL  ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = 'D'  ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = '" & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "'  ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                        Else
                            ' -- �ӡ�� Update ʶҹТͧ Chq , Draft ���� Media

                            dt_DetailImportFile = GetDataImport(dr_ImportFile("EXPTOBANK_FILENME").ToString, dr_ImportFile("IMPBANK_FILENME").ToString)

                            For Each dr_DetailImportFile As DataRow In dt_DetailImportFile.Rows

                                ' -- �����ʶҹ� �š�Ѻ�ҡ Bank �� F - Fail (����ҹ)
                                If (Trim(dr_DetailImportFile("IMPBANK_PROCESS_STS").ToString) <> "R") Then

                                    sb.Remove(0, sb.Length)
                                    sb.Append("  UPDATE GPS_PAYMENT ")
                                    sb.Append("  SET GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
                                    sb.Append("  , GPS_PAYMENT.GP_GET_RESULT_DATE = to_char(sysdate,'YYYYMMDD') ")

                                    ' -- ����ǡѺ�Ţ��� ������ �ҡ�� Media ��� Update �Ţ�������� ��� �ҡ�� C , D ��ͧ ��ʶҹ��� O ��ҹ��

                                    If (Trim(dr_DetailImportFile("EXPTOBANK_PAYMTH").ToString) <> "M") Then
                                        sb.Append("  , GPS_PAYMENT.GP_CHQNO = '" & Trim(dr_DetailImportFile("IMPBANK_CHQ_NO").ToString) & "' ")
                                    End If

                                    ' -- ����ǡѺ�Ţ��� ʶҹе����� �ҡ�� Media Update ���ʶҹз���Ѻ�� ��� �ҡ�� C , D ��ͧ Update �� O ��ҹ��
                                    ' -- AP-2016-008 update �š�Ѻ�ͧ cheque ����� E-Expire
                                    If (Trim(dr_DetailImportFile("EXPTOBANK_PAYMTH").ToString) <> "M") Then
                                        '-- AP-2016-008 'sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  'O' ")
                                        sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  '" & Trim(dr_DetailImportFile("IMPBANK_LAST_STS").ToString) & "' ")
                                        'sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  '")
                                    Else
                                        sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  '" & Trim(dr_DetailImportFile("IMPBANK_PROCESS_STS").ToString) & "' ")
                                    End If

                                    sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STSDATE = to_char(sysdate,'YYYYMMDD') ")
                                    sb.Append("  WHERE  GPS_PAYMENT.GP_CUSTREFNO = '" & Trim(dr_DetailImportFile("EXPTOBANK_CUSTREFNO").ToString) & "' ")
                                    sb.Append("   ")

                                    Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                                Else ' -- ��ʶҹ� �š�Ѻ�ҡ Bank �� F - Fail (����ҹ)

                                    HaveRejectBank = True
                                    ' -- Insert ��ҷ�� Payment Reject 
                                    sb.Remove(0, sb.Length)

                                    sb.Append("  insert into GPS_PAYMENT_REJ (  ")
                                    sb.Append("  GPS_PAYMENT_REJ.GPRJ_BATCHDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BATCH_NO  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_CREATEDATE  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_CORE_SYSTEM  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_TRANSREF  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_GPTREF_SEQNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_POLNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BILLNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAIDDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_AMOUNT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DESC  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCODE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCODE_NO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKBRN  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKNAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_COMMENT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_ADDRESS1  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DISTRICT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PROVINCE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_INSURENAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE6  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_MERCHN_NO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_CDCARD_DATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE9  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE10  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SYS_REF  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SYS_GR  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SUB_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_FLAG_FLWBILL  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_OSEA_LIST  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PHONE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_FAX  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SWIFT_CODE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKBRN_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKADDR  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_COUNTRY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_CURRENCY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_EXCHN_RATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCHARGES  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_REJECT_FUNC  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BATCHTYPE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.CREATEDBY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.CREATEDDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.UPDATEDBY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.UPDATEDDATE )  ")
                                    sb.Append(" select   ")
                                    sb.Append("  to_char(sysdate,'YYYYMMDD')  as BATCHDATE  ")
                                    sb.Append("  , to_char(sysdate,'YYYYMMDD') as  BATCH_NO  ")
                                    sb.Append(" , to_char(sysdate,'YYYYMMDD')  as CREATEDATE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_CORE_SYSTEM  ")
                                    sb.Append("  , GPS_PAYMENT.GP_TRANSREF  ")
                                    sb.Append("  , GPS_PAYMENT.GP_GPTREF_SEQNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_POLNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BILLNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAIDDATE  ")
                                    sb.Append(" , GPS_PAYMENT.GP_AMOUNT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYDESC  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYMTH  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_NAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKCODE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKCODE_NO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKBRN  ")
                                    sb.Append(" , GPS_PAYMENT.GP_BNKNAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_BNKACCNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_BNKACCNME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_COMMENT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_ADDRESS1  ")
                                    sb.Append("  , GPS_PAYMENT.GP_DISTRICT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PROVINCE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_INSURENAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_DATASOURCE_NME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_RESERVE6  ")
                                    sb.Append("  , GPS_PAYMENT.GP_MERCHN_NO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_CDCARD_DATE  ")
                                    sb.Append(" , GPS_PAYMENT.GP_RESERVE9  ")
                                    sb.Append("  , GPS_PAYMENT.GP_RESERVE10  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SYS_REF  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SYS_GR  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SUB_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_FLAG_FLWBILL  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_OSEA_LIST  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_PHONE  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_FAX  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SWIFT_CODE  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_BNKBRN_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_BNKADDR  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_COUNTRY  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_CURRENCY  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_EXCHN_RATE  ")
                                    sb.Append(" ,GPS_PAYMENT.GP_BNKCHARGES  ")
                                    sb.Append("  , 'BANK_REJ' as REJECT_TYPE  ")
                                    sb.Append("  , 'BANK' as REJECT_FUNC  ")
                                    sb.Append("  , 'A' as BATCHTYPE  ")
                                    sb.Append("  , 'SOA' as CREATEDBY  ")
                                    sb.Append("  , to_char(sysdate,'YYYYMMDD')  as CREATEDDATE  ")
                                    sb.Append("  , 'SOA' as  UPDATEDBY  ")
                                    sb.Append("  , to_char(sysdate,'YYYYMMDD')  as UPDATEDDATE  ")
                                    sb.Append("  from GPS_PAYMENT  ")
                                    sb.Append("  where trim(GPS_PAYMENT.GP_CUSTREFNO) = '" & Trim(dr_DetailImportFile("EXPTOBANK_CUSTREFNO").ToString) & "'  ")

                                    Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                                    ' -- Delete ��¡�ôѧ������͡�ҡ Payment

                                End If


                            Next

                            '---- ��Ǩ�ͺ File ��� Import ��� Export �١��ͧ Update Y  
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = 'Y' ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = '" & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "' ")
                            sb.Append("   ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                        End If ' -- ��Ǩ�ͺ������� File ��� Import

                    End If ' -- ��Ǩ�ͺ����� File �š�Ѻ���������

                Next

                dt_UpdateStatusFile = SelectLastUpdateStatusCD(strcurrentDate)
                If Not IsNothing(dt_UpdateStatusFile) AndAlso dt_UpdateStatusFile.Rows.Count > 0 Then
                    For Each dr_UpdateStatusFile As DataRow In dt_UpdateStatusFile.Rows
                        sb.Remove(0, sb.Length)
                        sb.Append("  update GPS_PAYMENT t ")
                        sb.Append("  set t.gp_lastupd_sts='" & Trim(dr_UpdateStatusFile("payge_last_sts").ToString) & "',  ")
                        sb.Append("      t.gp_lastupd_stsdate='" & Trim(dr_UpdateStatusFile("payge_last_sts_date").ToString) & "' ")
                        sb.Append("  where t.gp_custrefno = '" & Trim(dr_UpdateStatusFile("payge_51_cust_ref").ToString) & "' ")
                        sb.Append("   ")

                        Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
                    Next
                End If

                If Rec >= 0 Then
                    'MsgBox(" Update Records successfully")
                Else
                    oleTrans.Rollback()

                    'MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
                End If


                '---- �ա��ʶҹ� Reject  
                If (HaveRejectBank) Then

                    '---- Gen GL Reject  
                    Call_GPS_SP_GET_RejectBank(strcurrentDate, "BatchBank")

                    '---- Gen Report Media Reject   
                    GenMediaRejectReport(strcurrentDate, strcurrentDate, "BatchBank", "", "", "")

                    '---- Send Mail Reject
                    SendEmail("REJ_BY_BANK")

                End If


            Else
                ' MsgBox("Not File Wait Result From Bank")
                dt_UpdateStatusFile = SelectLastUpdateStatusCD(strcurrentDate)
                If Not IsNothing(dt_UpdateStatusFile) AndAlso dt_UpdateStatusFile.Rows.Count > 0 Then
                    For Each dr_UpdateStatusFile As DataRow In dt_UpdateStatusFile.Rows
                        sb.Remove(0, sb.Length)
                        sb.Append("  update GPS_PAYMENT t ")
                        sb.Append("  set t.gp_lastupd_sts='" & Trim(dr_UpdateStatusFile("payge_last_sts").ToString) & "',  ")
                        sb.Append("      t.gp_lastupd_stsdate='" & Trim(dr_UpdateStatusFile("payge_last_sts_date").ToString) & "' ")
                        sb.Append("  where t.gp_custrefno = '" & Trim(dr_UpdateStatusFile("payge_51_cust_ref").ToString) & "' ")
                        sb.Append("   ")

                        Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
                    Next
                End If
            End If


            'MsgBox("Batch Import Payment Result From Bank Completed")

            'Me.Close()
        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            Me.Close()
        End Try

    End Sub

    Function Call_GPS_SP_GET_RejectBank(ByVal postdate As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_Batch_Date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_Date").Value = postdate ' "20140926"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "GPS_SP_GET_RejectBank"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        If (dbComm.Parameters("result_return").Value = "TRUE") Then

            Return True
        Else
            Return False
        End If

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Private Function SelectLastUpdateStatusCD(ByVal strcurrentDate As String) As DataTable
        Dim dt_UpdateStatusCD As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append("  select    ")
        sb.Append("         t.payge_last_sts,   ")
        sb.Append("         t.payge_last_sts_date,   ")
        sb.Append("         trim(t.payge_51_cust_ref) as payge_51_cust_ref   ")
        sb.Append("    from PAYOUT_GEN_RESULT_NONIL t   ")
        sb.Append("   inner join GPS_PAYMENT b   ")
        sb.Append("      ON trim(t.payge_51_cust_ref) = b.gp_custrefno   ")

        '-- remark AP-2016-008 --
        '-- remark AP-2016-008 --sb.Append("   where t.payge_gen_date = '" & strcurrentDate & "'   ")
        '-- remark AP-2016-008 --'-- sb.Append("     and t.payge_paym_typ in ('DDP', 'MCP')   ")  '-- CR2997 ����¹ M-Cheque �� Corporate Cheque
        '-- remark AP-2016-008 --sb.Append("     and t.payge_paym_typ in ('DDP', 'MCP', 'CCP')   ")  '-- CR2997 ����¹ M-Cheque �� Corporate Cheque
        '-- remark AP-2016-008 --sb.Append("     and t.payge_rec_type = '510'   ")
        '-- remark AP-2016-008 --sb.Append("     and not (t.payge_last_sts in ('O', 'E'))   ")

        '-- remark AP-2016-008 : start --
        sb.Append("   where ( t.payge_gen_date = '" & strcurrentDate & "'   ") '-- AP-2016-008
        '-- sb.Append("     and t.payge_paym_typ in ('DDP', 'MCP')   ")  '-- CR2997 ����¹ M-Cheque �� Corporate Cheque
        sb.Append("     and t.payge_paym_typ in ('MCP', 'CCP')   ")  '-- CR2997 ����¹ M-Cheque �� Corporate Cheque
        sb.Append("     and t.payge_rec_type = '510' ) ")
        sb.Append("   or ( t.payge_gen_date = '" & strcurrentDate & "'   ")
        sb.Append("     and t.payge_paym_typ = 'DDP' ")
        sb.Append("     and t.payge_rec_type = '510' ")
        sb.Append("     and not (t.payge_last_sts in ('O', 'E')) ) ")
        '-- remark AP-2016-008 : end --

        sb.Append("   ")

        dt_UpdateStatusCD = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_UpdateStatusCD) AndAlso dt_UpdateStatusCD.Rows.Count > 0 Then
            Return dt_UpdateStatusCD
        Else
            Return Nothing
        End If


    End Function

    Private Function CheckDataImportCD() As DataTable
        Dim dt_ImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GP_Out.EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , GP_Out.PAIDDATE  as EXPTOBANK_PAIDDATE  ")
        sb.Append(" , GP_Out.CountTrans as EXPTOBANK_CountTrans  ")
        sb.Append(" , GP_Out.AmountTrans as EXPTOBANK_AmountTrans  ")
        sb.Append(" , GP_In.EXPTOBANK_FILENME as IMPBANK_FILENME  ")
        sb.Append(" , GP_In.CountTrans as IMPBANK_CountTrans  ")
        sb.Append(" , GP_In.AmountTrans as IMPBANK_AmountTrans  ")
        sb.Append(" , GP_In.TOTCountTrans as IMPBANK_TOTCountTrans  ")
        sb.Append(" , GP_In.TOTAmountTrans as IMPBANK_TOTAmountTrans  ")
        sb.Append(" from (  ")
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_EXPTOBANK_FILENME  as EXPTOBANK_FILENME   ")
        sb.Append(" , MAX(GPS_PAYMENT.GP_PAIDDATE) as PAIDDATE  ")
        sb.Append(" ,  count(GPS_PAYMENT.GP_AMOUNT) as CountTrans  ")
        sb.Append(" ,  sum(GPS_PAYMENT.GP_AMOUNT) as AmountTrans  ")
        sb.Append(" from(GPS_PAYMENT)  ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N'  ")
        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH in ( 'C' , 'D' )  ")
        sb.Append(" group by GPS_PAYMENT.GP_EXPTOBANK_FILENME  ")
        sb.Append(" order by GPS_PAYMENT.GP_EXPTOBANK_FILENME   ")
        sb.Append(" ) GP_Out   ")
        sb.Append(" left join    ")
        sb.Append(" (  ")
        sb.Append(" select    ")
        sb.Append(" PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S  as EXPTOBANK_FILENME  ")
        sb.Append(" , '' as PAIDDATE  ")
        sb.Append(" , PAYGE_FILE_NAME_S_Detail.DetailCount as  CountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_Detail.DetailSum as  AmountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_TOT.TOTCount  as  TOTCountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_TOT.TOTSum as  TOTAmountTrans  ")
        sb.Append(" from  ")
        sb.Append(" ( select PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as PAYGE_FILE_NAME_S  ")
        sb.Append(" , count(PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE) as DetailCount  ")
        sb.Append(" , sum(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM) as DetailSum  ")
        sb.Append(" from(PAYOUT_GEN_RESULT_NONIL)  ")
        sb.Append(" where  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%'  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '510'  ")
        sb.Append(" group by PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME , PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE  ")
        sb.Append(" ) PAYGE_FILE_NAME_S_Detail ,   ")
        sb.Append(" (   ")
        sb.Append(" select PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as PAYGE_FILE_NAME_S  ")
        sb.Append(" , sum(to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_REC))  as  TOTCount  ")
        sb.Append(" , sum((to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_PAYAMT))/10000 ) as  TOTSum  ")
        sb.Append(" from(PAYOUT_GEN_RESULT_NONIL)  ")
        sb.Append(" where  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%'   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '599'  ")

        sb.Append(" group by PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME ")

        sb.Append(" ) PAYGE_FILE_NAME_S_TOT  ")
        sb.Append(" where(PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S = PAYGE_FILE_NAME_S_TOT.PAYGE_FILE_NAME_S)  ")
        sb.Append(" ) GP_In  ")
        sb.Append(" on   'RE'||GP_Out.EXPTOBANK_FILENME = GP_In.EXPTOBANK_FILENME   ")
        sb.Append(" order by EXPTOBANK_FILENME  ")
        sb.Append("  ")

        dt_ImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then
            Return dt_ImportFile
        Else
            Return Nothing
        End If


    End Function

    Private Function GetDataImport(ByVal p_EXPTOBANK_FILENME As String, ByVal p_IMPBANK_FILENME As String) As DataTable
        Dim dt_DataImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_PAYMTH as EXPTOBANK_PAYMTH  ")
        sb.Append(" , GPS_PAYMENT.GP_EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as IMPBANK_FILENME  ")
        sb.Append(" , substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME,3,12) as IMPBANK_FILENME_SHOW  ")
        sb.Append(" ,  GPS_PAYMENT.GP_CUSTREFNO as EXPTOBANK_CUSTREFNO  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF as IMPBANK_CUSTREFNO  ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as EXPTOBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM as IMPBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_STS as  IMPBANK_PROCESS_STS ")
        'sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10) as IMPBANK_CHQ_NO  ")
        sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7) as IMPBANK_CHQ_NO  ")

        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_LAST_STS IMPBANK_LAST_STS") '-- AP-2016-008, action: add new line

        sb.Append(" from GPS_PAYMENT , PAYOUT_GEN_RESULT_NONIL   ")
        sb.Append(" where GPS_PAYMENT.GP_EXPTOBANK_FILENME  =  substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME,3,12)   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF is not null  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_FILENME = '" & Trim(p_EXPTOBANK_FILENME) & "' ")
        sb.Append(" and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = '" & Trim(p_IMPBANK_FILENME) & "'  ")
        sb.Append(" and trim(GPS_PAYMENT.GP_CUSTREFNO) = trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF) ")

        '--        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N' ") '-- AP-2016-008, action: remark line
        '--        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ") '-- AP-2016-008, action: remark line

        sb.Append(" order by EXPTOBANK_CUSTREFNO  ")
        sb.Append("  ")



        dt_DataImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_DataImportFile) AndAlso dt_DataImportFile.Rows.Count > 0 Then
            Return dt_DataImportFile
        Else
            Return Nothing
        End If




    End Function

    Private Sub GenMediaRejectReport(ByVal datefrom As String, ByVal dateto As String, ByVal user As String, ByVal str1 As String, ByVal str2 As String, ByVal str3 As String)

        Dim sb As New StringBuilder

        sb.Append("SELECT C.CSYS_CORE_SYSTEMNAME AS CORE_SYSTEM,D.DEP_DEPNAME AS DEPARTMENT,S.DTS_BUSINESS AS BUSINESS,  ")
        sb.Append("R.GPRJ_PAIDDATE,PAYT_PAYTYPE,R.GPRJ_DESC,  ")
        sb.Append("R.GPRJ_POLNO,R.GPRJ_BNKCODE,R.GPRJ_PAYEE_BNKACCNO,  ")
        sb.Append("CASE WHEN R.GPRJ_PAYMTH='M' AND R.GPRJ_SUB_PAYMTH='M' THEN R.GPRJ_PAYEE_BNKACCNO ELSE R.GPRJ_PAYEE_NAME END AS PAYEENAME,  ")
        sb.Append("R.GPRJ_AMOUNT,R.GPRJ_REJECT_TYPE AS ERRGROUP,RT.REJT_REJ_GROUP,RT.REJT_REJ_MASSAGE  ")
        sb.Append("FROM GPS_PAYMENT_REJ R INNER JOIN GPS_TRANSREF_REL T  ")
        'sb.Append("ON R.GPRJ_BATCHDATE=T.TREF_CREATEDATE  ")
        'sb.Append("AND R.GPRJ_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append(" ON R.GPRJ_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND R.GPRJ_TRANSREF=T.TREF_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE P  ")
        sb.Append("ON R.GPRJ_PAYMTH=P.PAYT_PAYMTH AND R.GPRJ_SUB_PAYMTH=P.PAYT_SUB_PAYMTH ")
        sb.Append("INNER JOIN GPS_TL_CORE_SYSTEM C ON R.GPRJ_CORE_SYSTEM=C.CSYS_CORE_SYSTEM ")
        sb.Append("INNER JOIN GPS_TL_DATASOURCE S ON R.GPRJ_CORE_SYSTEM=S.DTS_CORE_SYSTEM  ")
        sb.Append("AND T.TREF_DTSOURCE=S.DTS_DTSOURCE   ")
        sb.Append("AND T.TREF_DEP_REPAY=S.DTS_DEP_REPAY  ")
        sb.Append("INNER JOIN GPS_TL_REJECT_TYPE RT   ")
        sb.Append("ON R.GPRJ_REJECT_TYPE=RT.REJT_REJ_TYPE  ")
        sb.Append("INNER JOIN GPS_TL_DEPARTMENT D ON T.TREF_DEP_REPAY=D.DEP_DEPCODE  ")
        sb.Append("WHERE R.GPRJ_PAYMTH='M' ")
        sb.Append("AND R.GPRJ_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' AND R.GPRJ_REJECT_FUNC='BANK' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        Dim reportname As String
        reportname = "RptMediaRejectByBank_" & Now.ToString("yyMMddHHmm") & ".pdf"

        Dim clsExportPDF As New clsCrystalToPDFConverter

        clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptMediaRejectByBank.rpt") 'sReportPath ��� path �ͧ crystal report
        clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & reportname) 'ValidationReportPath ��� path �����ҧ report  

        Dim lstname As New ArrayList
        Dim lstvalue As New ArrayList

        lstname.Add("pTransdate")
        lstname.Add("pUser")

        lstvalue.Add(datefrom)
        lstvalue.Add(user)

        clsExportPDF.ExportReport(dt, lstname, lstvalue)

    End Sub

    Function GetEmail(ByVal mailfuction As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""
        sb.Append("SELECT EMAIL_ADDRESS FROM GPS_EMAIL_SETUP WHERE EMAIL_FUNC='" & mailfuction & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function
    Private Sub SendEmail(ByVal mailfuction As String)
        Try

            Dim Smtp_Server As New Net.Mail.SmtpClient
            Dim e_mail As New Net.Mail.MailMessage()
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential("AutomaticMediaReject@scblife.com", "yourpassword")
            Smtp_Server.Port = 25
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "10.100.1.88"

            Dim txtFrom As String
            Dim txtMessage As String

            txtFrom = "AutomaticMediaReject@scblife.com"
            txtMessage = "Media Reject By Bank"

            e_mail = New Net.Mail.MailMessage()
            e_mail.From = New Net.Mail.MailAddress(txtFrom)

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    e_mail.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

                e_mail.CC.Add("AutomaticMediaReject@scblife.com")
                e_mail.Subject = "Media Reject By Bank Automatic"
                e_mail.IsBodyHtml = False
                e_mail.Body = txtMessage

                Smtp_Server.Send(e_mail)
                'MsgBox("Mail Sent")

            End If

        Catch error_t As Exception
            'MsgBox(error_t.ToString)

            'Return exit code to batch
            Environment.ExitCode = 2
        End Try
    End Sub

End Class