Imports UtilityClassLibrary
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports System.Net.Mail
' Batch �ͺ���д֧������੾�� Media ��ҹ��
Public Class FrmImpResultBank
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Private Sub FrmImpResultBank_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dt_ImportFile As DataTable
            Dim dt_DetailImportFile As DataTable
            Dim strmsgbox As String
            Dim sb As New StringBuilder
            Dim oleTrans As OleDbTransaction
            Dim Rec As Integer
            Dim HaveRejectBank As Boolean
            Dim strcurrentDate As String

            My.Application.ChangeCulture("en-GB")

            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)

                    'Return exit code to batch
                    Environment.ExitCode = 2

                    Exit Sub
                End If
            End If

            strcurrentDate = Now.ToString("yyyyMMdd")

            Debug.Print(System.DateTime.Now)

            dt_ImportFile = CheckDataImport(strcurrentDate)
            strmsgbox = ""

            HaveRejectBank = False

            If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then


                'oleTrans = clsUtility.gConnGP.BeginTransaction

                For Each dr_ImportFile As DataRow In dt_ImportFile.Rows

                    ' -- ��Ǩ�ͺ����� File �š�Ѻ���������
                    If Not String.IsNullOrEmpty(dr_ImportFile("IMPBANK_FILENME").ToString) Then

                        '-- ��Ǩ�ͺ������� File ��� Import ����� �ըӹǹ��¡�� ����ʹ�Թ�١��ͧ�������
                        If (dr_ImportFile("IMPBANK_CountTrans").ToString <> dr_ImportFile("IMPBANK_TOTCountTrans").ToString) Or (dr_ImportFile("IMPBANK_AmountTrans").ToString <> dr_ImportFile("IMPBANK_TOTAmountTrans").ToString) Then

                            '---- ��Ǩ�ͺ File ��� Import ���١��ͧ  Update D - Delete
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL  ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = ''D''  ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = ''' " & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "'''  ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                            ' -- ��Ǩ�ͺ��� File ��� Import ����� ��� Export 仹�� �ըӹǹ��¡�� ����ʹ�Թ�١��ͧ�������
                        ElseIf (dr_ImportFile("IMPBANK_CountTrans").ToString <> dr_ImportFile("EXPTOBANK_CountTrans").ToString) Or (dr_ImportFile("IMPBANK_AmountTrans").ToString <> dr_ImportFile("EXPTOBANK_AmountTrans").ToString) Then

                            '---- ��Ǩ�ͺ File ��� Import ���١��ͧ  Update D - Delete
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL  ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = 'D'  ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME)  = '" & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "'  ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                        Else
                            ' -- �ӡ�� Update ʶҹТͧ Chq , Draft ���� Media

                            dt_DetailImportFile = GetDataImport(dr_ImportFile("EXPTOBANK_FILENME").ToString, dr_ImportFile("IMPBANK_FILENME").ToString, strcurrentDate)

                            For Each dr_DetailImportFile As DataRow In dt_DetailImportFile.Rows

                                ' -- �����ʶҹ� �š�Ѻ�ҡ Bank �� F - Fail (����ҹ)

                                sb.Remove(0, sb.Length)
                                sb.Append("  UPDATE GPS_PAYMENT ")
                                sb.Append("  SET GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
                                sb.Append("  , GPS_PAYMENT.GP_GET_RESULT_DATE = to_char(sysdate,'YYYYMMDD') ")

                                ' -- ����ǡѺ�Ţ��� ������ �ҡ�� Media ��� Update �Ţ�������� ��� �ҡ�� C , D ��ͧ ��ʶҹ��� O ��ҹ��

                                If (Trim(dr_DetailImportFile("EXPTOBANK_PAYMTH").ToString) <> "M") And (Trim(dr_DetailImportFile("IMPBANK_PROCESS_STS").ToString) = "O") Then
                                    sb.Append("  , GPS_PAYMENT.GP_CHQNO = '" & Trim(dr_DetailImportFile("IMPBANK_CHQ_NO").ToString) & "' ")
                                End If

                                ' -- ����ǡѺ�Ţ��� ʶҹе����� �ҡ�� Media Update ���ʶҹз���Ѻ�� ��� �ҡ�� C , D ��ͧ Update �� O ��ҹ��
                                If (Trim(dr_DetailImportFile("EXPTOBANK_PAYMTH").ToString) <> "M") Then
                                    sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  'O' ")
                                Else
                                    sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STS =  '" & Trim(dr_DetailImportFile("IMPBANK_PROCESS_STS").ToString) & "' ")
                                    sb.Append("  , GPS_PAYMENT.GP_REJBANK_REASON =  '" & Trim(dr_DetailImportFile("IMPBANK_PROCESS_REJREASON").ToString) & "' ")
                                End If

                                sb.Append("  , GPS_PAYMENT.GP_LASTUPD_STSDATE = to_char(sysdate,'YYYYMMDD') ")
                                sb.Append("  WHERE  GPS_PAYMENT.GP_CUSTREFNO = '" & Trim(dr_DetailImportFile("EXPTOBANK_CUSTREFNO").ToString) & "' ")
                                sb.Append("   ")

                                Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                                If (Trim(dr_DetailImportFile("IMPBANK_PROCESS_STS").ToString) = "F") Then ' -- ��ʶҹ� �š�Ѻ�ҡ Bank �� F - Fail (����ҹ)
                                    'Else 

                                    HaveRejectBank = True
                                    ' -- Insert ��ҷ�� Payment Reject 
                                    sb.Remove(0, sb.Length)

                                    sb.Append("  insert into GPS_PAYMENT_REJ (  ")
                                    sb.Append("  GPS_PAYMENT_REJ.GPRJ_BATCHDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BATCH_NO  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_CREATEDATE  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_CORE_SYSTEM  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_TRANSREF  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_GPTREF_SEQNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_POLNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BILLNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAIDDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_AMOUNT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DESC  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCODE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCODE_NO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKBRN  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKNAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PAYEE_BNKACCNME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_COMMENT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_ADDRESS1  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DISTRICT  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PROVINCE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_INSURENAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_DATASOURCE_NME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE6  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_MERCHN_NO  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_CDCARD_DATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE9  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_RESERVE10  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SYS_REF  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SYS_GR  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SUB_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_FLAG_FLWBILL  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_OSEA_LIST  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_PHONE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_FAX  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_SWIFT_CODE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKBRN_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKADDR  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_COUNTRY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_CURRENCY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_EXCHN_RATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BNKCHARGES  ")
                                    sb.Append(" ,GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_REJECT_FUNC  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.GPRJ_BATCHTYPE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.CREATEDBY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.CREATEDDATE  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.UPDATEDBY  ")
                                    sb.Append("  ,GPS_PAYMENT_REJ.UPDATEDDATE )  ")
                                    sb.Append(" select   ")
                                    sb.Append("  to_char(sysdate,'YYYYMMDD')  as BATCHDATE  ")
                                    sb.Append("  , ' ' as  BATCH_NO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_CREATEDATE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_CORE_SYSTEM  ")
                                    sb.Append("  , GPS_PAYMENT.GP_TRANSREF  ")
                                    sb.Append("  , GPS_PAYMENT.GP_GPTREF_SEQNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_POLNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BILLNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAIDDATE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_AMOUNT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYDESC  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYMTH  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_NAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKCODE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKCODE_NO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_BNKBRN  ")
                                    sb.Append(" , GPS_PAYMENT.GP_BNKNAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_BNKACCNO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PAYEE_BNKACCNME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_COMMENT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_ADDRESS1  ")
                                    sb.Append("  , GPS_PAYMENT.GP_DISTRICT  ")
                                    sb.Append("  , GPS_PAYMENT.GP_PROVINCE  ")
                                    sb.Append("  , GPS_PAYMENT.GP_INSURENAME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_DATASOURCE_NME  ")
                                    sb.Append("  , GPS_PAYMENT.GP_RESERVE6  ")
                                    sb.Append("  , GPS_PAYMENT.GP_MERCHN_NO  ")
                                    sb.Append("  , GPS_PAYMENT.GP_CDCARD_DATE  ")
                                    sb.Append(" , GPS_PAYMENT.GP_RESERVE9  ")
                                    sb.Append("  , GPS_PAYMENT.GP_RESERVE10  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SYS_REF  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SYS_GR  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SUB_PAYMTH  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_FLAG_FLWBILL  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_OSEA_LIST  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_PHONE  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_FAX  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_SWIFT_CODE  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_BNKBRN_NAME  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_BNKADDR  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_COUNTRY  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_CURRENCY  ")
                                    sb.Append("  ,GPS_PAYMENT.GP_EXCHN_RATE  ")
                                    sb.Append(" ,GPS_PAYMENT.GP_BNKCHARGES  ")
                                    sb.Append("  , 'BANK_REJ' as REJECT_TYPE  ")
                                    sb.Append("  , 'BANK' as REJECT_FUNC  ")
                                    sb.Append("  , 'A' as BATCHTYPE  ")
                                    sb.Append("  , 'BatchBank' as CREATEDBY  ")
                                    sb.Append("  , to_char(sysdate,'YYYYMMDD')  as CREATEDDATE  ")
                                    sb.Append("  , 'BatchBank' as  UPDATEDBY  ")
                                    sb.Append("  , to_char(sysdate,'YYYYMMDD')  as UPDATEDDATE  ")
                                    sb.Append("  from GPS_PAYMENT  ")
                                    sb.Append("  where trim(GPS_PAYMENT.GP_CUSTREFNO) = '" & Trim(dr_DetailImportFile("EXPTOBANK_CUSTREFNO").ToString) & "'  ")

                                    Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


                                End If


                            Next

                            '---- ��Ǩ�ͺ File ��� Import ��� Export �١��ͧ Update Y  
                            sb.Remove(0, sb.Length)
                            sb.Append("  UPDATE PAYOUT_GEN_RESULT_NONIL ")
                            sb.Append("  SET PAYOUT_GEN_RESULT_NONIL.PAYI_FLG_TRANSFORM = 'Y' ")
                            sb.Append("  WHERE  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = '" & Trim(dr_ImportFile("IMPBANK_FILENME").ToString) & "' ")
                            sb.Append("   ")

                            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                        End If ' -- ��Ǩ�ͺ������� File ��� Import

                    End If ' -- ��Ǩ�ͺ����� File �š�Ѻ���������

                Next


                If Rec >= 0 Then
                    '-- oleTrans.Commit()
                    'MsgBox(" Update Records successfully")
                Else
                    '-- oleTrans.Rollback()
                    'MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
                End If

                '---- �ա��ʶҹ� Reject  
                If (HaveRejectBank) Then

                    '---- Gen GL Reject  
                    Call_GPS_SP_GET_RejectBank(strcurrentDate, "BatchBank")

                    '---- Gen Report Media Reject   
                    GenMediaRejectReport(strcurrentDate, strcurrentDate, "BatchBank", "", "", "")

                    '---- Send Mail Reject
                    SendEmail("REJ_BY_BANK")

                End If

            Else
                'MsgBox("Not File Wait Result From Bank")
            End If

            'MsgBox("Batch Import Payment Result From Bank Completed")

        Catch ex As Exception
            'Return exit code to batch
            Environment.ExitCode = 2
        Finally
            Debug.Print(System.DateTime.Now)
            Me.Close()
        End Try
        Debug.Print(System.DateTime.Now)

    End Sub

    Function Call_GPS_SP_GET_RejectBank(ByVal postdate As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_Batch_Date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_Date").Value = postdate ' "20140926"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "GPS_SP_GET_RejectBank"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        If (dbComm.Parameters("result_return").Value = "TRUE") Then

            Return True
        Else
            Return False
        End If

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Private Function CheckDataImport_OLD(ByVal LStr_Impdate As String) As DataTable
        Dim dt_ImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GP_Out.EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , GP_Out.PAIDDATE  as EXPTOBANK_PAIDDATE  ")
        sb.Append(" , GP_Out.CountTrans as EXPTOBANK_CountTrans  ")
        sb.Append(" , GP_Out.AmountTrans as EXPTOBANK_AmountTrans  ")
        sb.Append(" , GP_In.EXPTOBANK_FILENME as IMPBANK_FILENME  ")
        sb.Append(" , GP_In.CountTrans as IMPBANK_CountTrans  ")
        sb.Append(" , GP_In.AmountTrans as IMPBANK_AmountTrans  ")
        sb.Append(" , GP_In.TOTCountTrans as IMPBANK_TOTCountTrans  ")
        sb.Append(" , GP_In.TOTAmountTrans as IMPBANK_TOTAmountTrans  ")
        sb.Append(" from (  ")
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_EXPTOBANK_FILENME  as EXPTOBANK_FILENME   ")
        sb.Append(" , MAX(GPS_PAYMENT.GP_PAIDDATE) as PAIDDATE  ")
        sb.Append(" ,  count(GPS_PAYMENT.GP_AMOUNT) as CountTrans  ")
        sb.Append(" ,  sum(GPS_PAYMENT.GP_AMOUNT) as AmountTrans  ")
        sb.Append(" from(GPS_PAYMENT)  ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N'  ")
        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")
        sb.Append(" and GPS_PAYMENT.GP_PAYMTH = 'M' ")
        sb.Append(" group by GPS_PAYMENT.GP_EXPTOBANK_FILENME  ")
        sb.Append(" order by GPS_PAYMENT.GP_EXPTOBANK_FILENME   ")
        sb.Append(" ) GP_Out   ")
        sb.Append(" left join    ")
        sb.Append(" (  ")
        sb.Append(" select    ")
        sb.Append(" PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S  as EXPTOBANK_FILENME  ")
        sb.Append(" , '' as PAIDDATE  ")
        sb.Append(" , PAYGE_FILE_NAME_S_Detail.DetailCount as  CountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_Detail.DetailSum as  AmountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_TOT.TOTCount  as  TOTCountTrans  ")
        sb.Append(" , PAYGE_FILE_NAME_S_TOT.TOTSum as  TOTAmountTrans  ")
        sb.Append(" from  ")
        sb.Append(" ( select PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as PAYGE_FILE_NAME_S  ")
        sb.Append(" , count(PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE) as DetailCount  ")
        sb.Append(" , sum(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM) as DetailSum  ")
        sb.Append(" from(PAYOUT_GEN_RESULT_NONIL)  ")
        sb.Append(" where  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%'  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '510'  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "'  ")
        sb.Append(" group by PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME , PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE  ")
        sb.Append(" ) PAYGE_FILE_NAME_S_Detail ,   ")
        sb.Append(" (   ")
        sb.Append(" select PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as PAYGE_FILE_NAME_S  ")
        sb.Append(" , to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_REC)  as  TOTCount  ")
        sb.Append(" , (to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_PAYAMT))/10000  as  TOTSum  ")
        sb.Append(" from(PAYOUT_GEN_RESULT_NONIL)  ")
        sb.Append(" where  trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%'   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '599'  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "'  ")
        sb.Append(" ) PAYGE_FILE_NAME_S_TOT  ")
        sb.Append(" where(PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S = PAYGE_FILE_NAME_S_TOT.PAYGE_FILE_NAME_S)  ")
        sb.Append(" ) GP_In  ")
        sb.Append(" on   'RE'||GP_Out.EXPTOBANK_FILENME = GP_In.EXPTOBANK_FILENME   ")
        sb.Append(" order by EXPTOBANK_FILENME  ")
        sb.Append("  ")

        dt_ImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then
            Return dt_ImportFile
        Else
            Return Nothing
        End If

    End Function
    Private Function CheckDataImport(ByVal LStr_Impdate As String) As DataTable
        Dim dt_ImportFile As DataTable

        Dim sb As New StringBuilder

        sb.Append("select GP_Out.EXPTOBANK_FILENME as EXPTOBANK_FILENME, ")
        sb.Append("       GP_Out.PAIDDATE          as EXPTOBANK_PAIDDATE, ")
        sb.Append("       GP_Out.CountTrans        as EXPTOBANK_CountTrans, ")
        sb.Append("       GP_Out.AmountTrans       as EXPTOBANK_AmountTrans, ")
        sb.Append("       GP_In.EXPTOBANK_FILENME  as IMPBANK_FILENME, ")
        sb.Append("       GP_In.CountTrans         as IMPBANK_CountTrans, ")
        sb.Append("       GP_In.AmountTrans        as IMPBANK_AmountTrans, ")
        sb.Append("       GP_In.TOTCountTrans      as IMPBANK_TOTCountTrans, ")
        sb.Append("       GP_In.TOTAmountTrans     as IMPBANK_TOTAmountTrans ")
        sb.Append("  from (select GPS_PAYMENT.GP_EXPTOBANK_FILENME as EXPTOBANK_FILENME, ")
        sb.Append("               MAX(GPS_PAYMENT.GP_PAIDDATE) as PAIDDATE, ")
        sb.Append("               count(GPS_PAYMENT.GP_AMOUNT) as CountTrans, ")
        sb.Append("               sum(GPS_PAYMENT.GP_AMOUNT) as AmountTrans ")
        sb.Append("        from(GPS_PAYMENT) ")
        sb.Append("         where GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append("           and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N' ")
        sb.Append("           and GPS_PAYMENT.GP_GET_RESULT_DATE is null ")
        sb.Append("           and GPS_PAYMENT.GP_PAYMTH = 'M' ")
        sb.Append("         group by GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append("         order by GPS_PAYMENT.GP_EXPTOBANK_FILENME) GP_Out ")
        sb.Append("  left join (select PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S as EXPTOBANK_FILENME, ")
        sb.Append("                    '' as PAIDDATE, ")
        sb.Append("                    PAYGE_FILE_NAME_S_Detail.DetailCount as CountTrans, ")
        sb.Append("                    PAYGE_FILE_NAME_S_Detail.DetailSum as AmountTrans, ")
        sb.Append("                    PAYGE_FILE_NAME_S_TOT.TOTCount as TOTCountTrans, ")
        sb.Append("                    PAYGE_FILE_NAME_S_TOT.TOTSum as TOTAmountTrans ")
        sb.Append("               from ( ")
        sb.Append("                     select PAYOUT_GEN_RESULT_NONIL_500.O_FILE_S as PAYGE_FILE_NAME_S, ")
        sb.Append("                            count(PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE) as DetailCount, ")
        sb.Append("                            sum(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM) as DetailSum ")

        '--IC#6889-- sb.Append("                       from (select * from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '510' and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%' and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "') PAYOUT_GEN_RESULT_NONIL ")
        sb.Append("                       from (select payge_gen_date, payge_file_name, payge_file_name_s, payge_cd_file_type, payge_paym_typ, payge_seqno, payge_last_sts, payge_rec_type, payge_50_createdate, payge_50_createtime, payge_50_file_ref, payge_50_company_id, payge_50_paym_typ, payge_50_channel_id, payge_50_batch_ref, payge_50_value_date, payge_51_paym_curr, payge_51_paym_amt, payge_51_paym_amt_num, payge_51_bene_acc, payge_51_bene_nme, payge_51_bene_taxid, payge_51_bnknme, payge_51_bnkcde, payge_51_brnnme, payge_51_brncde, max(payge_51_bnkref) payge_51_bnkref, payge_51_process_sts, payge_51_process_re, payge_51_net_amt, payge_51_chq_no7, payge_51_cust_ref, payge_51_wht_no, payge_51_chq_no10, payge_59_tot_rec, payge_59_tot_payamt, payge_flg_print, source, system_id, createdby, updatedby, createddate, updateddate, payi_flg_transform, payge_last_sts_date from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '510' and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%' and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "' group by payge_gen_date, payge_file_name, payge_file_name_s, payge_cd_file_type, payge_paym_typ, payge_seqno, payge_last_sts, payge_rec_type, payge_50_createdate, payge_50_createtime, payge_50_file_ref, payge_50_company_id, payge_50_paym_typ, payge_50_channel_id, payge_50_batch_ref, payge_50_value_date, payge_51_paym_curr, payge_51_paym_amt, payge_51_paym_amt_num, payge_51_bene_acc, payge_51_bene_nme, payge_51_bene_taxid, payge_51_bnknme, payge_51_bnkcde, payge_51_brnnme, payge_51_brncde, payge_51_process_sts, payge_51_process_re, payge_51_net_amt, payge_51_chq_no7, payge_51_cust_ref, payge_51_wht_no, payge_51_chq_no10, payge_59_tot_rec, payge_59_tot_payamt, payge_flg_print, source, system_id, createdby, updatedby, createddate, updateddate, payi_flg_transform, payge_last_sts_date ) PAYOUT_GEN_RESULT_NONIL ")

        sb.Append("                               left join (select PAYGE_FILE_NAME_S PAYGE_FILE_NAME_S_500, 'RE' || substr(Payge_50_File_Ref, 21, 16) O_FILE_S from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '500' and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "') PAYOUT_GEN_RESULT_NONIL_500 ")
        sb.Append("                                 on PAYOUT_GEN_RESULT_NONIL.Payge_File_Name_s = PAYOUT_GEN_RESULT_NONIL_500.Payge_File_Name_s_500 ")
        sb.Append("                      group by PAYOUT_GEN_RESULT_NONIL_500.O_FILE_S, ")
        sb.Append("                               PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE ")
        sb.Append("                               ) PAYGE_FILE_NAME_S_Detail, ")
        sb.Append("                    ( ")
        sb.Append("                     select PAYOUT_GEN_RESULT_NONIL_500.O_FILE_S as PAYGE_FILE_NAME_S, ")
        sb.Append("                            to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_REC) as TOTCount, ")
        sb.Append("                            (to_number(PAYOUT_GEN_RESULT_NONIL.PAYGE_59_TOT_PAYAMT)) / ")
        sb.Append("                            10000 as TOTSum ")
        sb.Append("                       from (select * from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '599' and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) like 'RES%' and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "') PAYOUT_GEN_RESULT_NONIL ")
        sb.Append("                               left join (select PAYGE_FILE_NAME_S PAYGE_FILE_NAME_S_500, 'RE' || substr(Payge_50_File_Ref, 21, 16) O_FILE_S from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '500' and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE = '" & LStr_Impdate & "') PAYOUT_GEN_RESULT_NONIL_500 ")
        sb.Append("                                 on PAYOUT_GEN_RESULT_NONIL.Payge_File_Name_s = PAYOUT_GEN_RESULT_NONIL_500.Payge_File_Name_s_500 ")
        sb.Append("                            ) PAYGE_FILE_NAME_S_TOT ")
        sb.Append("              where (PAYGE_FILE_NAME_S_Detail.PAYGE_FILE_NAME_S = ")
        sb.Append("                    PAYGE_FILE_NAME_S_TOT.PAYGE_FILE_NAME_S)) GP_In ")
        sb.Append("    on 'RE' || GP_Out.EXPTOBANK_FILENME = GP_In.EXPTOBANK_FILENME ")
        sb.Append(" order by EXPTOBANK_FILENME ")

        dt_ImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then
            Return dt_ImportFile
        Else
            Return Nothing
        End If

    End Function
    Private Function CheckDataImport2(ByVal p_EXPTOBANK_FILENME As String, ByVal p_IMPBANK_FILENME As String) As DataTable
        Dim dt_ImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_PAYMTH as EXPTOBANK_PAYMTH  ")
        sb.Append(" , GPS_PAYMENT.GP_EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as IMPBANK_FILENME  ")
        sb.Append(" , substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME,3,12) as IMPBANK_FILENME_SHOW  ")
        sb.Append(" ,  GPS_PAYMENT.GP_CUSTREFNO as EXPTOBANK_CUSTREFNO  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF as IMPBANK_CUSTREFNO  ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as EXPTOBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM as IMPBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_STS as  IMPBANK_PROCESS_STS ")
        'sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10) as IMPBANK_CHQ_NO  ")
        sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7) as IMPBANK_CHQ_NO  ")
        sb.Append(" from GPS_PAYMENT , PAYOUT_GEN_RESULT_NONIL   ")
        sb.Append(" where GPS_PAYMENT.GP_EXPTOBANK_FILENME  =  substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME_S,3,12)   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF is not null  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_FILENME = '" & Trim(p_EXPTOBANK_FILENME) & "' ")
        sb.Append(" and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME_S) = '" & Trim(p_IMPBANK_FILENME) & "'  ")
        sb.Append(" and trim(GPS_PAYMENT.GP_CUSTREFNO) = trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF) ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N'  ")
        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")
        sb.Append(" order by EXPTOBANK_CUSTREFNO  ")
        sb.Append("  ")



        dt_ImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_ImportFile) AndAlso dt_ImportFile.Rows.Count > 0 Then
            Return dt_ImportFile
        Else
            Return Nothing
        End If




    End Function

    Private Function GetDataImport_OLD(ByVal p_EXPTOBANK_FILENME As String, ByVal p_IMPBANK_FILENME As String, ByVal LStr_ImpDate As String) As DataTable
        Dim dt_DataImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_PAYMTH as EXPTOBANK_PAYMTH  ")
        sb.Append(" , GPS_PAYMENT.GP_EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as IMPBANK_FILENME  ")
        sb.Append(" , substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME,3,12) as IMPBANK_FILENME_SHOW  ")
        sb.Append(" ,  GPS_PAYMENT.GP_CUSTREFNO as EXPTOBANK_CUSTREFNO  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF as IMPBANK_CUSTREFNO  ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as EXPTOBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM as IMPBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_STS as  IMPBANK_PROCESS_STS ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_RE as  IMPBANK_PROCESS_REJREASON ")
        sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7) as IMPBANK_CHQ_NO  ")
        sb.Append(" from GPS_PAYMENT , PAYOUT_GEN_RESULT_NONIL   ")
        sb.Append(" where GPS_PAYMENT.GP_EXPTOBANK_FILENME  =  substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME_S,3,12)   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF is not null  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_FILENME = '" & Trim(p_EXPTOBANK_FILENME) & "' ")
        sb.Append(" and trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME) = '" & Trim(p_IMPBANK_FILENME) & "'  ")
        sb.Append(" and trim(GPS_PAYMENT.GP_CUSTREFNO) = trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF) ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N'  ")
        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE ='" & LStr_ImpDate & "' ")
        sb.Append(" order by EXPTOBANK_CUSTREFNO  ")
        sb.Append("  ")



        dt_DataImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_DataImportFile) AndAlso dt_DataImportFile.Rows.Count > 0 Then
            Return dt_DataImportFile
        Else
            Return Nothing
        End If




    End Function

    Private Function GetDataImport(ByVal p_EXPTOBANK_FILENME As String, ByVal p_IMPBANK_FILENME As String, ByVal LStr_ImpDate As String) As DataTable
        Dim dt_DataImportFile As DataTable

        Dim sb As New StringBuilder


        sb.Remove(0, sb.Length)
        sb.Append(" select   ")
        sb.Append(" GPS_PAYMENT.GP_PAYMTH as EXPTOBANK_PAYMTH  ")
        sb.Append(" , GPS_PAYMENT.GP_EXPTOBANK_FILENME as EXPTOBANK_FILENME  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME as IMPBANK_FILENME  ")
        sb.Append(" , substr(PAYOUT_GEN_RESULT_NONIL.PAYGE_FILE_NAME,3,12) as IMPBANK_FILENME_SHOW  ")
        sb.Append(" ,  GPS_PAYMENT.GP_CUSTREFNO as EXPTOBANK_CUSTREFNO  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF as IMPBANK_CUSTREFNO  ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as EXPTOBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PAYM_AMT_NUM as IMPBANK_AMOUNT  ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_STS as  IMPBANK_PROCESS_STS ")
        sb.Append(" , PAYOUT_GEN_RESULT_NONIL.PAYGE_51_PROCESS_RE as  IMPBANK_PROCESS_REJREASON ")
        sb.Append(" , NVL(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO10,PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CHQ_NO7) as IMPBANK_CHQ_NO  ")
        '--IC#6889-- sb.Append(" from GPS_PAYMENT , (select * from PAYOUT_GEN_RESULT_NONIL where PAYGE_REC_TYPE = '510') PAYOUT_GEN_RESULT_NONIL   ")
        sb.Append(" from GPS_PAYMENT , (select payge_gen_date, payge_file_name, payge_file_name_s, payge_cd_file_type, payge_paym_typ, payge_seqno, payge_last_sts, payge_rec_type, payge_50_createdate, payge_50_createtime, payge_50_file_ref, payge_50_company_id, payge_50_paym_typ, payge_50_channel_id, payge_50_batch_ref, payge_50_value_date, payge_51_paym_curr, payge_51_paym_amt, payge_51_paym_amt_num, payge_51_bene_acc, payge_51_bene_nme, payge_51_bene_taxid, payge_51_bnknme, payge_51_bnkcde, payge_51_brnnme, payge_51_brncde, max(payge_51_bnkref) payge_51_bnkref, payge_51_process_sts, payge_51_process_re, payge_51_net_amt, payge_51_chq_no7, payge_51_cust_ref, payge_51_wht_no, payge_51_chq_no10, payge_59_tot_rec, payge_59_tot_payamt, payge_flg_print, source, system_id, createdby, updatedby, createddate, updateddate, payi_flg_transform, payge_last_sts_date from PAYOUT_GEN_RESULT_NONIL where PAYGE_REC_TYPE = '510' group by payge_gen_date, payge_file_name, payge_file_name_s, payge_cd_file_type, payge_paym_typ, payge_seqno, payge_last_sts, payge_rec_type, payge_50_createdate, payge_50_createtime, payge_50_file_ref, payge_50_company_id, payge_50_paym_typ, payge_50_channel_id, payge_50_batch_ref, payge_50_value_date, payge_51_paym_curr, payge_51_paym_amt, payge_51_paym_amt_num, payge_51_bene_acc, payge_51_bene_nme, payge_51_bene_taxid, payge_51_bnknme, payge_51_bnkcde, payge_51_brnnme, payge_51_brncde, payge_51_process_sts, payge_51_process_re, payge_51_net_amt, payge_51_chq_no7, payge_51_cust_ref, payge_51_wht_no, payge_51_chq_no10, payge_59_tot_rec, payge_59_tot_payamt, payge_flg_print, source, system_id, createdby, updatedby, createddate, updateddate, payi_flg_transform, payge_last_sts_date ) PAYOUT_GEN_RESULT_NONIL   ")
        sb.Append("           left join (select PAYGE_FILE_NAME_S PAYGE_FILE_NAME_S_500, 'RE' || substr(Payge_50_File_Ref, 21, 16) O_FILE_S from GENERATEPAYMENT.PAYOUT_GEN_RESULT_NONIL where PAYOUT_GEN_RESULT_NONIL.PAYGE_REC_TYPE = '500') PAYOUT_GEN_RESULT_NONIL_500 ")
        sb.Append("             on PAYOUT_GEN_RESULT_NONIL.Payge_File_Name_s = PAYOUT_GEN_RESULT_NONIL_500.Payge_File_Name_s_500 ")
        sb.Append(" where GPS_PAYMENT.GP_EXPTOBANK_FILENME  =  substr(PAYOUT_GEN_RESULT_NONIL_500.O_FILE_S,3,12)   ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF is not null  ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y'  ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOBANK_FILENME = '" & Trim(p_EXPTOBANK_FILENME) & "' ")
        sb.Append(" and trim(PAYOUT_GEN_RESULT_NONIL_500.O_FILE_S) = '" & Trim(p_IMPBANK_FILENME) & "'  ")
        sb.Append(" and trim(GPS_PAYMENT.GP_CUSTREFNO) = trim(PAYOUT_GEN_RESULT_NONIL.PAYGE_51_CUST_REF) ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT = 'N'  ")
        sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE is null  ")
        sb.Append(" and PAYOUT_GEN_RESULT_NONIL.PAYGE_GEN_DATE ='" & LStr_ImpDate & "' ")
        sb.Append(" order by EXPTOBANK_CUSTREFNO  ")
        sb.Append("  ")



        dt_DataImportFile = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt_DataImportFile) AndAlso dt_DataImportFile.Rows.Count > 0 Then
            Return dt_DataImportFile
        Else
            Return Nothing
        End If




    End Function

    Private Sub GenMediaRejectReport(ByVal datefrom As String, ByVal dateto As String, ByVal user As String, ByVal str1 As String, ByVal str2 As String, ByVal str3 As String)

        Dim sb As New StringBuilder

        sb.Append(" SELECT C.CSYS_CORE_SYSTEMNAME AS CORE_SYSTEM,D.DEP_DEPNAME AS DEPARTMENT,S.DTS_BUSINESS AS BUSINESS,  ")
        sb.Append(" R.GPRJ_PAIDDATE,PAYT_PAYTYPE,R.GPRJ_DESC,  ")
        sb.Append(" R.GPRJ_POLNO,R.GPRJ_BNKCODE, R.GPRJ_PAYEE_BNKACCNO as GPRJ_PAYEE_BNKACCNO,  ")
        sb.Append(" CASE WHEN R.GPRJ_PAYMTH='M' AND R.GPRJ_SUB_PAYMTH='M' THEN R.GPRJ_PAYEE_BNKACCNME ELSE R.GPRJ_PAYEE_NAME END AS PAYEENAME,  ")
        sb.Append(" R.GPRJ_AMOUNT,R.GPRJ_REJECT_TYPE AS ERRGROUP,'Reject by Bank' AS REJT_REJ_GROUP,RT.gp_rejbank_reason AS REJT_REJ_MASSAGE  ")
        sb.Append(" FROM GPS_PAYMENT_REJ R INNER JOIN GPS_TRANSREF_REL T  ")
        sb.Append(" ON R.GPRJ_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append(" AND R.GPRJ_TRANSREF=T.TREF_TRANSREF ")
        sb.Append(" INNER JOIN GPS_TL_PAYTYPE P  ")
        sb.Append(" ON R.GPRJ_PAYMTH=P.PAYT_PAYMTH AND R.GPRJ_SUB_PAYMTH=P.PAYT_SUB_PAYMTH ")
        sb.Append(" INNER JOIN GPS_TL_CORE_SYSTEM C ON R.GPRJ_CORE_SYSTEM=C.CSYS_CORE_SYSTEM ")
        sb.Append(" INNER JOIN GPS_TL_DATASOURCE S ON R.GPRJ_CORE_SYSTEM=S.DTS_CORE_SYSTEM  ")
        sb.Append(" AND T.TREF_DTSOURCE=S.DTS_DTSOURCE   ")
        sb.Append(" AND T.TREF_DEP_REPAY=S.DTS_DEP_REPAY  ")

        'sb.Append(" INNER JOIN GPS_TL_REJECT_TYPE RT   ")
        'sb.Append(" ON R.GPRJ_REJECT_TYPE=RT.REJT_REJ_TYPE  ")
        sb.Append(" INNER JOIN GPS_PAYMENT RT   ")
        sb.Append(" ON R.gprj_createdate=RT.gp_createdate ")
        sb.Append(" AND R.gprj_core_system=RT.gp_core_system ")
        sb.Append(" AND R.gprj_transref=RT.gp_transref ")
        sb.Append(" AND R.gprj_gptref_seqno=RT.gp_gptref_seqno ")

        sb.Append(" INNER JOIN GPS_TL_DEPARTMENT D ON T.TREF_DEP_REPAY=D.DEP_DEPCODE  ")
        sb.Append(" WHERE R.GPRJ_PAYMTH='M' ")
        sb.Append(" AND R.GPRJ_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' AND R.GPRJ_REJECT_FUNC='BANK' ")




        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        Dim reportname As String
        reportname = "RptMediaRejectByBank_" & Now.ToString("yyMMddHHmm") & ".pdf"

        Dim clsExportPDF As New clsCrystalToPDFConverter

        clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptMediaRejectByBank.rpt") 'sReportPath ��� path �ͧ crystal report 
        clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & reportname) 'ValidationReportPath ��� path �����ҧ report 
        Dim lstname As New ArrayList
        Dim lstvalue As New ArrayList

        lstname.Add("pTransdate")
        lstname.Add("pUser")

        lstvalue.Add(datefrom)
        lstvalue.Add(user)

        clsExportPDF.ExportReport(dt, lstname, lstvalue)

    End Sub

    Function GetEmail(ByVal mailfuction As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""
        sb.Append("SELECT EMAIL_ADDRESS FROM GPS_EMAIL_SETUP WHERE EMAIL_FUNC='" & mailfuction & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function
    Private Sub SendEmail(ByVal mailfuction As String)
        Dim Email As New MailMessage()
        Try

            Dim SMTPServer As New SmtpClient
            Email.From = New MailAddress("AutomaticMediaReject@scblife.com")

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    Email.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

            End If

            Email.Subject = "Media Reject By Bank [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
            Email.Body = "����������¡�è��� Media Reject By Bank"
            SMTPServer.Host = "mailsmtp.scnyl.local"
            SMTPServer.Port = 25

            SMTPServer.Send(Email)
            Email.Dispose()

        Catch error_t As Exception
            MsgBox(error_t.ToString)

            'Return exit code to batch
            'Console.WriteLine(error_t.ToString)

            Environment.ExitCode = 2
        End Try
    End Sub

End Class