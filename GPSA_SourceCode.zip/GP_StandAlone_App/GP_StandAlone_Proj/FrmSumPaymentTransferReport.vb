Imports System.Text
Imports System.IO
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmSumPaymentTransferReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim clsHashLo As New ClsHashTotalErrorLOCancel
    Dim timework As Integer = 1
    Dim clsGPS_PayoutGroupSetup As New ClsGPS_PayOutGroup_Setup
#Region "BackgroundWorker"
    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        My.Application.ChangeCulture("en-GB")
        'Run_Process()
        Run_Report()
        Dim i As Integer
        For i = 0 To timework Step +1

            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                BackgroundWorker1.ReportProgress(i)
                System.Threading.Thread.Sleep(timework)
            End If
        Next



    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ''���� 1 progress      
        'ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        'MsgBox("Complete")
        'btnConfirm.Enabled = False
        'Me.Dispose()
        'Cursor = Cursors.Default


        'Run_Report()
        Me.Close()

    End Sub

#End Region
    Private Sub FrmRptEDO_Reprint_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ComboReportType.Items.Add("GPS")
        ComboReportType.Items.Add("IL")
        ComboReportType.SelectedIndex = 0

        dtpEntryDate.Value = Now.ToString("dd/MM/yyyy")
    End Sub
    Private Sub PrintReport(ByVal batchno As String, ByVal condition As String, ByVal group As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSumPaymentTransfer.rpt")

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataPaymentSummaryReport(clsUtility.gConnGP, batchno, condition)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)
        Else
            dt = cls.GetDummyForReport(clsUtility.gConnGP)
            frm1.FillDataTableToReport(dt)
        End If

        Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param1 As New CrystalDecisions.Shared.ParameterField()
        Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param2 As New CrystalDecisions.Shared.ParameterField()
        Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        param1.ParameterFieldName = "pGroup"
        discrete1.Value = group
        param1.CurrentValues.Add(discrete1)
        paramFields.Add(param1)

        param2.ParameterFieldName = "pTransdate"
        discrete2.Value = dtpEntryDate.Value.ToString("dd/MM/yyyy")
        param2.CurrentValues.Add(discrete2)
        paramFields.Add(param2)

        paramUser.ParameterFieldName = "pUser"
        discreteUser.Value = gUserFullName
        paramUser.CurrentValues.Add(discreteUser)
        paramFields.Add(paramUser)

        frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

    End Sub
    Private Sub GenerateReport(ByVal dt As DataTable, ByVal dtPayoutGroupSetup As DataTable)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows
                PrintReport(dr("TREF_BATCH_NO"), "", "ALL")
                'PrintReport(dr("TREF_BATCH_NO"), " HAVING SUM(P.GP_AMOUNT) > 10000000 ", "Group A")
                'PrintReport(dr("TREF_BATCH_NO"), " HAVING SUM(P.GP_AMOUNT) > 2000000 AND SUM(P.GP_AMOUNT) <= 10000000 ", "Group B")
                'PrintReport(dr("TREF_BATCH_NO"), " HAVING SUM(P.GP_AMOUNT) >=0 AND SUM(P.GP_AMOUNT) <= 2000000  ", "Group C")

                For Each drPayoutGroupSetup As DataRow In dtPayoutGroupSetup.Rows

                    If drPayoutGroupSetup("APPROVEGROUP") = "A" Then
                        PrintReport(dr("TREF_BATCH_NO"), " HAVING SUM(P.GP_AMOUNT) >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup), "Group " + drPayoutGroupSetup("APPROVEGROUP"))
                    Else
                        PrintReport(dr("TREF_BATCH_NO"), " HAVING SUM(P.GP_AMOUNT) >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup) + " AND SUM(P.GP_AMOUNT) <= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "maxamount", dtPayoutGroupSetup), "Group " + drPayoutGroupSetup("APPROVEGROUP"))
                    End If

                Next

            Next
            Dim frm As New FrmSumPaymentTransferReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub GenerateTextFile(ByVal dt As DataTable)


        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows

                Dim dt_filename As New DataTable
                dt_filename = cls.GetTextFileForGen(clsUtility.gConnGP, dr("TREF_BATCH_NO"))
                fnGenTextFile(dt_filename)

                Dim dt_filename_M As New DataTable
                dt_filename_M = cls.GetTextFileForGen_M(clsUtility.gConnGP, dr("TREF_BATCH_NO"))
                fnGenTextFile(dt_filename_M)
            Next

        End If



    End Sub
    Private Sub fnGenTextFile(ByVal dt_filename As DataTable)
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then

            For Each dr As DataRow In dt_filename.Rows
                Dim dt As DataTable

                Dim filename As String
                Dim path As String
                path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")

                filename = path & dr("GP_EXPTOBANK_FILENME") & ".txt"

                If dr("TREF_PAYMTH") = "M" Then
                    dt = cls.GetDataForGenTextFile_M(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    GenTextFile_M(dt, filename)
                Else
                    dt = cls.GetDataForGenTextFile(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    GenTextFile(dt, filename)
                End If

            Next

        End If
    End Sub
    Public Sub GenTextFile(ByVal dt As DataTable, ByVal filename As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If

        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)


        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        For Each dr As DataRow In dt.Rows

            GenDetail(sw, filename, dr, (dt.Rows.IndexOf(dr) + 1), dr("GP_AMOUNT"))

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()
    End Sub
    Public Sub GenTextFile_M(ByVal dt As DataTable, ByVal filename As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If

        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)



        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadRight(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        Dim line As Integer = 1
        Dim amt As Double
        Dim amt_split As Double = 2000000

        For Each dr As DataRow In dt.Rows

            amt = Convert.ToDecimal(dr("GP_AMOUNT"))
            If amt > amt_split Then
                Dim c As Integer = 1
                Dim i As Integer
                i = Math.Ceiling(amt / amt_split)

                Do While c < i

                    GenDetail(sw, filename, dr, line, amt_split)

                    line = line + 1
                    c = c + 1
                Loop

                amt = amt - (amt_split * (c - 1))
                GenDetail(sw, filename, dr, line, amt)

                line = line + 1
            Else

                GenDetail(sw, filename, dr, line, amt)
                line = line + 1

            End If

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()
    End Sub
    Private Sub GenDetail(ByVal sw As StreamWriter, ByVal filename As String, ByVal dr As DataRow, ByVal line As Integer, ByVal amt As String)

        If InStr(amt.ToString, ".") Then
            amt = amt.Replace(".", "")
        Else
            amt = amt & "000"
        End If

        Dim l_RecordType3 = "003"
        sw.Write(l_RecordType3)
        Dim l_SeqOfCr = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr)

        Dim l_CrAccount
        If dr("GP_PAYMTH") = "M" Then
            l_CrAccount = dr("GP_PAYEE_BNKACCNO_NEW").ToString.PadRight(25, " ")
        Else
            l_CrAccount = "".PadRight(25, " ")
        End If
        sw.Write(l_CrAccount)
        Dim l_CrAmount = amt.ToString.PadLeft(16, "0")
        sw.Write(l_CrAmount)
        Dim l_CrCurrency = "THB"
        sw.Write(l_CrCurrency)
        Dim l_CrIntenalRef = "00000001"
        sw.Write(l_CrIntenalRef)
        Dim l_WHTPresent = "N"
        sw.Write(l_WHTPresent)
        Dim l_InvoicePresent = "N"
        sw.Write(l_InvoicePresent)
        Dim l_CrAdviceRequest = "N"
        sw.Write(l_CrAdviceRequest)
        Dim l_DeliveryMode = "P"
        sw.Write(l_DeliveryMode)
        Dim l_PicupLocation = "C002"
        sw.Write(l_PicupLocation)
        Dim l_WHTType = "00"
        sw.Write(l_WHTType)
        Dim l_WHTNo = "".PadRight(14, " ")
        sw.Write(l_WHTNo)
        Dim l_WHTAttNo = "000000"
        sw.Write(l_WHTAttNo)
        Dim l_WHTNoDetail = "00"
        sw.Write(l_WHTNoDetail)
        Dim l_WHTTotalAmt = "0000000000000000"
        sw.Write(l_WHTTotalAmt)
        Dim l_WHTNoInvoiceDetail = "000000"
        sw.Write(l_WHTNoInvoiceDetail)
        Dim l_WHTInvoiceAmt = "0000000000000000"
        sw.Write(l_WHTInvoiceAmt)
        Dim l_WHTPayType = "0"
        sw.Write(l_WHTPayType)
        Dim l_WHTRemark = "".PadRight(40, " ")
        sw.Write(l_WHTRemark)
        Dim l_WHTDeductDate = "".PadRight(8, " ")
        sw.Write(l_WHTDeductDate)
        Dim l_ReceiveBnkCode = dr("GP_BNKCODE_NO").ToString.PadRight(3, " ")
        sw.Write(l_ReceiveBnkCode)

        Dim l_ReceiveBnkName
        If dr("GP_BNKSCODE") = "SCB" Then
            l_ReceiveBnkName = dr("BKMST_BNKNAME_ENG").ToString.PadRight(35, " ")
        Else
            l_ReceiveBnkName = dr("BKMST_BNKNAME").ToString.PadRight(35, " ")
        End If
        sw.Write(l_ReceiveBnkName)

        Dim l_ReceiveBranchCode = dr("GP_BNKBRN_NEW").ToString.PadRight(4, " ")
        sw.Write(l_ReceiveBranchCode)

        Dim l_ReceiveBranchName
        If dr("GP_BNKSCODE") = "SCB" Then
            l_ReceiveBranchName = "CHIDLOM BRANCH".PadRight(35, " ")
        Else
            l_ReceiveBranchName = "".PadRight(35, " ")
        End If
        sw.Write(l_ReceiveBranchName)

        Dim l_WHTSignatory = "".PadRight(1, " ")
        sw.Write(l_WHTSignatory)
        Dim l_ChqIssuance = "N"
        sw.Write(l_ChqIssuance)
        Dim l_ChqRefNo = dr("GP_CUSTREFNO").ToString.PadRight(20, " ")
        sw.Write(l_ChqRefNo)
        Dim l_ChqRefType = "3"
        sw.Write(l_ChqRefType)
        Dim l_PayTypeCode = "".PadRight(3, " ")
        sw.Write(l_PayTypeCode)

        Dim l_ServiceType
        If dr("GP_PAYMTH") = "M" Then
            l_ServiceType = "04"
        Else
            l_ServiceType = "".PadRight(2, " ")
        End If
        sw.Write(l_ServiceType)

        Dim l_002Remark = "".PadRight(68, " ")
        sw.Write(l_002Remark)
        Dim l_Bene_Flag = "".PadRight(2, " ")
        sw.Write(l_Bene_Flag)
        sw.WriteLine()


        'Generate 004
        Dim l_RecordType4 = "004"
        sw.Write(l_RecordType4)
        Dim l_CrIntenalRef4 = "00000001"
        sw.Write(l_CrIntenalRef4)
        Dim l_SeqOfCr4 = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr4)
        Dim l_PayeeIDCard = "".PadRight(15, " ")
        sw.Write(l_PayeeIDCard)

        Dim l_PayeeName
        If dr("GP_PAYMTH") = "M" Then
            l_PayeeName = dr("GP_PAYEE_BNKACCNME").ToString.PadRight(100, " ")
        Else
            l_PayeeName = dr("GP_PAYEE_NAME").ToString.PadRight(100, " ")
        End If
        sw.Write(l_PayeeName.ToString.Substring(0, 100))

        Dim l_Address1
        If dr("GP_PAYMTH") = "D" Then
            l_Address1 = dr("GP_ADDRESS1").ToString.PadRight(70, " ")
        Else
            l_Address1 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address1.ToString.Substring(0, 70))

        Dim l_Address2
        If dr("GP_PAYMTH") = "D" Then
            l_Address2 = dr("GP_DISTRICT").ToString.PadRight(70, " ")
        Else
            l_Address2 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address2)

        Dim l_Address3
        If dr("GP_PAYMTH") = "D" Then
            l_Address3 = dr("GP_PROVINCE").ToString.PadRight(70, " ")
        Else
            l_Address3 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address3)

        Dim l_PayeeTaxId = "".PadRight(10, " ")
        sw.Write(l_PayeeTaxId)
        Dim l_PayeeNameEng = "".PadRight(70, " ")
        sw.Write(l_PayeeNameEng.ToString.Substring(0, 70))
        Dim l_PayeeFax = "".PadRight(10, " ")
        sw.Write(l_PayeeFax)
        Dim l_PayeeMobile = "".PadRight(10, " ")
        sw.Write(l_PayeeMobile)
        Dim l_PayeeEmail = "".PadRight(64, " ")
        sw.Write(l_PayeeEmail.ToString.Substring(0, 64))
        Dim l_PayeeNameThai = "".PadRight(100, " ")
        sw.Write(l_PayeeNameThai.ToString.Substring(0, 100))
        Dim l_Payee2Address1 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address1.ToString.Substring(0, 70))
        Dim l_Payee2Address2 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address2.ToString.Substring(0, 70))
        Dim l_Payee2Address3 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address3.ToString.Substring(0, 70))

        sw.WriteLine()
    End Sub
    Private Sub Run_Process()
        Dim dt As New DataTable
        dt = cls.GetBatchNoByExpDate(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"))

        GenerateTextFile(dt)
    End Sub
    Private Sub Run_Report()

        Dim dtPayoutGroupSetup As DataTable
        dtPayoutGroupSetup = clsGPS_PayoutGroupSetup.GetGps_Payoutgroup_Setup()

        If Not IsNothing(dtPayoutGroupSetup) AndAlso dtPayoutGroupSetup.Rows.Count > 0 Then



            If ComboReportType.SelectedItem.Equals("GPS") Then
                Dim dt As New DataTable
                dt = cls.GetBatchNoByExpDate(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"))
                GenerateReport(dt, dtPayoutGroupSetup)
            ElseIf ComboReportType.SelectedItem.Equals("IL") Then
                Dim dtSUM, dtMNG As New DataTable
                dtMNG = clsHashLo.getDataForMNGReport(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"), True, dtPayoutGroupSetup)
                PrintReportLO(dtMNG, "MNG")
                dtSUM = clsHashLo.getDataForSUMReport(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"), True)
                PrintReportLO(dtSUM, "SUM")
                Me.Close()
            Else
                MsgBox("��������͡ Report type.")
            End If

        Else
            MsgBox("Gps_Payoutgroup_Setup is missing.", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click

        'Dim dt As New DataTable
        'dt = cls.GetBatchNoByExpDate(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"))
        'If IsNothing(dt) Then
        '    MsgBox("Not found data for Re-Print")
        '    Exit Sub
        'End If

        'Run_Report()
        'Try
        '    timework = timework * 100
        '    Dim progress As New frmProgress(Me.BackgroundWorker1)
        '    progress.ShowDialog()

        'Catch ex As Exception
        '    MsgBox("Process Error!")
        'End Try
        Run_Report()

    End Sub

    Private Sub PrintReportLO(ByVal dt As DataTable, ByVal fn As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        If fn = "MNG" Then
            frm1.CrDoc.Load(sReportPath & "report_mng.rpt")
        ElseIf fn = "SUM" Then
            frm1.CrDoc.Load(sReportPath & "report_sum.rpt")
        End If

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    
End Class