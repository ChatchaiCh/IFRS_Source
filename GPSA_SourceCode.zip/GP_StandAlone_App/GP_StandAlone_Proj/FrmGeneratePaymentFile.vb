Imports System.Text
Imports System.IO
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmGeneratePaymentFile
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim timework As Integer = 1
    Dim clsGPS_PayoutGroupSetup As New ClsGPS_PayOutGroup_Setup
    Dim dtPayoutGroupSetup As DataTable
#Region "BackgroundWorker"
    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        My.Application.ChangeCulture("en-GB")
        Run_Process()

        Dim i As Integer
        For i = 0 To timework Step +1

            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                BackgroundWorker1.ReportProgress(i)
                System.Threading.Thread.Sleep(timework)
            End If
        Next



    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ''���� 1 progress      
        'ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        'MsgBox("Complete")
        'btnConfirm.Enabled = False
        'Me.Dispose()
        'Cursor = Cursors.Default
        Run_Report()
        'BindBatchNo()
        Me.Close()

    End Sub

#End Region
    Private Sub FrmGeneratePaymentTextFile_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        btnPrint.BackColor = Color.FromArgb(255, 235, 220)
        btnPrint.Height = 25
        btnPrint.Enabled = False

        BindBatchNo()
        lblDate.Text = Now.ToString("dd/MM/yyyy")


    End Sub
    Private Sub BindBatchNo()
        
        Dim dt As DataTable
        dt = cls.BindBatchNo(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            txtBatchNo.Text = dt.Rows(0)("TREF_BATCH_NO")
            btnPrint.Enabled = True
        Else
            txtBatchNo.Text = ""
            btnPrint.Enabled = False
        End If
    End Sub
    Private Sub Run_Process()
        Dim dt_data As New DataTable
        dt_data = cls.BindData(clsUtility.gConnGP, txtBatchNo.Text.Trim)

        Dim dt_filename As New DataTable
        dt_filename = BindFileName()

        Dim dt_filename_M As New DataTable
        dt_filename_M = BindFileName_M()

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim c1, c2, c3 As Boolean
        c1 = True
        c2 = True
        c3 = True

        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            c1 = UpdateData_CD(oleTrans, dt_filename, dt_data)
        End If

        If Not IsNothing(dt_filename_M) AndAlso dt_filename_M.Rows.Count > 0 Then
            c2 = UpdateData_M(oleTrans, dt_filename_M, dt_data)
        End If

        c3 = UpdateFlag(oleTrans, txtBatchNo.Text.Trim)

        If c1 And c2 And c3 Then
            oleTrans.Commit()

            GenerateTextFile(txtBatchNo.Text.Trim)

            'BindBatchNo()
            'MsgBox("Generate text file successfully")
        Else
            oleTrans.Rollback()

            MsgBox("Can not generate text file!")
        End If

    End Sub
    Private Sub Run_Report()
        PrintReport(txtBatchNo.Text.Trim, "", "ALL")
        'PrintReport(txtBatchNo.Text.Trim, " HAVING SUM(P.GP_AMOUNT) > 10000000 ", "Group A")
        'PrintReport(txtBatchNo.Text.Trim, " HAVING SUM(P.GP_AMOUNT) > 2000000 AND SUM(P.GP_AMOUNT) <= 10000000 ", "Group B")
        'PrintReport(txtBatchNo.Text.Trim, " HAVING SUM(P.GP_AMOUNT) >=0 AND SUM(P.GP_AMOUNT) <= 2000000  ", "Group C")

        For Each drPayoutGroupSetup As DataRow In dtPayoutGroupSetup.Rows

            If drPayoutGroupSetup("APPROVEGROUP") = "A" Then
                PrintReport(txtBatchNo.Text.Trim, " HAVING SUM(P.GP_AMOUNT) >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup) + " ", "Group " + drPayoutGroupSetup("APPROVEGROUP"))
            Else
                PrintReport(txtBatchNo.Text.Trim, " HAVING SUM(P.GP_AMOUNT) >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup) + " AND SUM(P.GP_AMOUNT) <= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "maxamount", dtPayoutGroupSetup) + " ", "Group " + drPayoutGroupSetup("APPROVEGROUP"))
            End If

        Next

        dtPayoutGroupSetup = Nothing
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtBatchNo.Text = "" Then
            MsgBox("No Data", MsgBoxStyle.Information)
            Exit Sub
        End If

        dtPayoutGroupSetup = clsGPS_PayoutGroupSetup.GetGps_Payoutgroup_Setup()
        If IsNothing(dtPayoutGroupSetup) Then
            MsgBox("Gps_Payoutgroup_Setup is missing.", MsgBoxStyle.Information)
            Exit Sub
        End If

        'btnPrint.Enabled = False

        Try
            timework = 1
            timework = timework * 100
            Dim progress As New frmProgress(Me.BackgroundWorker1)
            progress.ShowDialog()
        Catch ex As Exception
            StopWorker()
            MsgBox("Process Error!")
        End Try

        'btnPrint.Enabled = True
    End Sub
    Private Sub GenerateTextFile(ByVal batchno As String)
        Dim dt_filename As New DataTable
        dt_filename = cls.GetTextFileForGen(clsUtility.gConnGP, batchno)
        fnGenTextFile(dt_filename)

        Dim dt_filename_M As New DataTable
        dt_filename_M = cls.GetTextFileForGen_M(clsUtility.gConnGP, batchno)
        fnGenTextFile(dt_filename_M)

    End Sub
    Function UpdateFlag(ByVal oleTrans As OleDbTransaction, ByVal batchno As String) As Boolean
        Dim rec As Integer
        rec = cls.UpdateFlag(clsUtility.gConnGP, oleTrans, batchno, gUserLogin)

        If rec = 1 Then
            Return True
        Else
            Return False
        End If
    End Function
    Function UpdateData_CD(ByVal oleTrans As OleDbTransaction, ByVal dt_filename As DataTable, ByVal dt_data As DataTable) As Boolean
        Dim rec As Integer
        Dim rec2 As Integer
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            For Each dr As DataRow In dt_filename.Rows

                rec = rec + cls.UpdateFileName(clsUtility.gConnGP, oleTrans, dr, gUserLogin)
                rec2 = rec2 + UpdateData(oleTrans, dt_data, dr("FILENAME"), dr("TREF_PAYMTH"), dr("TREF_PAIDDATE"))

            Next

            If (rec = dt_filename.Rows.Count) And (rec2 = dt_filename.Rows.Count) Then
                Return True
            Else
                Return False
            End If

        End If


    End Function
    Function UpdateData_M(ByVal oleTrans As OleDbTransaction, ByVal dt_filename As DataTable, ByVal dt_data As DataTable) As Boolean
        Dim rec As Integer
        Dim rec2 As Integer
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            For Each dr As DataRow In dt_filename.Rows

                rec = rec + cls.UpdateFileName_M(clsUtility.gConnGP, oleTrans, dr, gUserLogin)
                rec2 = rec2 + UpdateData_Media(oleTrans, dt_data, dr("FILENAME"), dr("TREF_PAYMTH"), dr("TREF_PAIDDATE"), dr("GP_BNKCODE"))

            Next

            If (rec = dt_filename.Rows.Count) And (rec2 = dt_filename.Rows.Count) Then
                Return True
            Else
                Return False
            End If

        Else
            Return True
        End If

    End Function
    Function UpdateData(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal filename As String, ByVal paymth As String, ByVal paiddate As String) As String
        Dim rec As Integer
        Dim result() As DataRow
        If dt.Rows.Count > 0 Then

            result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            Dim id As String
            id = 1
            For Each row As DataRow In result
                rec = rec + cls.UpdateData(clsUtility.gConnGP, oleTrans, row, id.PadLeft(4, "0"), filename, gUserLogin)
                id = id + 1

            Next

            If rec = result.Length Then
                Return 1
            Else
                Return 0
            End If
        Else
            Return 0
        End If

    End Function
    Function UpdateData_Media(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal filename As String, ByVal paymth As String, ByVal paiddate As String, ByVal bankcode As String) As String
        Dim rec As Integer
        Dim result() As DataRow
        If dt.Rows.Count > 0 Then

            If bankcode = "SCB" Then  ''GP_BNKSCODE
                result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' AND GP_BNKCODE='SCB' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            Else
                result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' AND GP_BNKCODE<>'SCB' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            End If

            Dim id As String
            id = 1
            For Each row As DataRow In result
                rec = rec + cls.UpdateData(clsUtility.gConnGP, oleTrans, row, id.PadLeft(4, "0"), filename, gUserLogin)
                id = id + 1

            Next

            If rec = result.Length Then
                Return 1
            Else
                Return 0
            End If
        Else
            Return 0
        End If

    End Function
    Function BindFileName() As DataTable
        Dim dt As New DataTable
        dt = cls.GroupDataByPaymentType(clsUtility.gConnGP, txtBatchNo.Text.Trim)

        Dim systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim idCC As Integer
            idCC = cls.GetMaxID(clsUtility.gConnGP, "C", systemdate)
            Dim idDD As Integer
            idDD = cls.GetMaxID(clsUtility.gConnGP, "D", systemdate)

            For Each dr As DataRow In dt.Rows

                Dim filename As String

                filename = "S" & Microsoft.VisualBasic.Right(systemdate, 6) & "01" & dr("TREF_PAYMTH")

                Select Case dr("TREF_PAYMTH")
                    Case "C"
                        dr("FILENAME") = filename & idCC.ToString.PadLeft(2, "0")
                        idCC = idCC + 1
                    Case "D"
                        dr("FILENAME") = filename & idDD.ToString.PadLeft(2, "0")
                        idDD = idDD + 1
                End Select

            Next

            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function BindFileName_M() As DataTable
        Dim dt As New DataTable
        dt = cls.GroupDataByPaymentType_M(clsUtility.gConnGP, txtBatchNo.Text.Trim)
        Dim systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim idM_SCB As Integer
            idM_SCB = cls.GetMaxID_M(clsUtility.gConnGP, True, systemdate)
            Dim idM As Integer
            idM = cls.GetMaxID_M(clsUtility.gConnGP, False, systemdate)

            For Each dr As DataRow In dt.Rows

                Dim filename As String
                filename = "S" & Microsoft.VisualBasic.Right(systemdate, 6) & "01" & dr("TREF_PAYMTH")

                If dr("GP_BNKCODE") = "SCB" Then

                    dr("FILENAME") = filename & idM_SCB.ToString.PadLeft(2, "0")
                    idM_SCB = idM_SCB + 1
                Else

                    If idM = 0 Then
                        idM = "50"
                    Else
                        idM = idM
                    End If
                    dr("FILENAME") = filename & idM.ToString.PadLeft(2, "0")
                    idM = idM + 1

                End If

            Next

            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click

        Me.Close()
        'PrintReport("GP2014112201", "", "ALL")
        'PrintReport("GP2014112201", " HAVING SUM(P.GP_AMOUNT) > 10000000 ", "Group A")
        'PrintReport("GP2014112201", " HAVING SUM(P.GP_AMOUNT) > 2000000 AND SUM(P.GP_AMOUNT) <= 10000000 ", "Group B")
        'PrintReport("GP2014112201", " HAVING SUM(P.GP_AMOUNT) >=0 AND SUM(P.GP_AMOUNT) <= 2000000  ", "Group C")

    End Sub
    Private Sub PrintReport(ByVal batchno As String, ByVal condition As String, ByVal group As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSumPaymentTransfer.rpt")

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataPaymentSummaryReport(clsUtility.gConnGP, batchno, condition)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)
        Else
            dt = cls.GetDummyForReport(clsUtility.gConnGP)
            frm1.FillDataTableToReport(dt)
        End If

        Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param1 As New CrystalDecisions.Shared.ParameterField()
        Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param2 As New CrystalDecisions.Shared.ParameterField()
        Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        param1.ParameterFieldName = "pGroup"
        discrete1.Value = group
        param1.CurrentValues.Add(discrete1)
        paramFields.Add(param1)

        param2.ParameterFieldName = "pTransdate"
        discrete2.Value = Now.ToString("dd/MM/yyyy")
        param2.CurrentValues.Add(discrete2)
        paramFields.Add(param2)

        paramUser.ParameterFieldName = "pUser"
        discreteUser.Value = gUserFullName
        paramUser.CurrentValues.Add(discreteUser)
        paramFields.Add(paramUser)

        frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

    End Sub
    Private Sub fnGenTextFile(ByVal dt_filename As DataTable)
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then

            For Each dr As DataRow In dt_filename.Rows
                Dim dt As DataTable

                Dim filename As String
                Dim path As String
                Dim pathServer As String
                pathServer = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")
                path = "D:\"

                filename = path & dr("GP_EXPTOBANK_FILENME") & ".txt"

                If dr("TREF_PAYMTH") = "M" Then
                    dt = cls.GetDataForGenTextFile_M(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    GenTextFile_M(dt, filename)
                Else
                    dt = cls.GetDataForGenTextFile(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    GenTextFile(dt, filename)
                End If

                '--CopytoNewFile(filename)
                CopytoNewFileServer(filename, path, pathServer)

            Next

        End If
    End Sub
    Public Sub GenTextFile(ByVal dt As DataTable, ByVal filename As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If

        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)

        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        For Each dr As DataRow In dt.Rows

            GenDetail(sw, filename, dr, (dt.Rows.IndexOf(dr) + 1), dr("GP_AMOUNT2"))

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()

        InsertLog(IO.Path.GetFileName(filename), dt.Rows(0)("GP_PAIDDATE").ToString, dt.Rows.Count, Convert.ToInt16(l_NoOf9), dt.Rows(0)("GP_PAYMTH").ToString, dt.Rows(0)("GP_SUB_PAYMTH").ToString, Convert.ToDouble(l_DrAmount9))

    End Sub
    Public Sub GenTextFile_M(ByVal dt As DataTable, ByVal filename As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If
        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)

        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadRight(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        Dim line As Integer = 1
        Dim amt As Double
        Dim amt_split As Double = 2000000

        For Each dr As DataRow In dt.Rows

            amt = Convert.ToDecimal(dr("GP_AMOUNT2"))

            If amt > amt_split Then
                Dim c As Integer = 1
                Dim i As Integer
                i = Math.Ceiling(amt / amt_split)

                Do While c < i

                    GenDetail(sw, filename, dr, line, amt_split)

                    line = line + 1
                    c = c + 1
                Loop

                amt = amt - (amt_split * (c - 1))
                GenDetail(sw, filename, dr, line, amt.ToString("#############.000"))

                line = line + 1
            Else

                GenDetail(sw, filename, dr, line, amt.ToString("#############.000"))
                line = line + 1

            End If

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()

        InsertLog(IO.Path.GetFileName(filename), dt.Rows(0)("GP_PAIDDATE").ToString, dt.Rows.Count, Convert.ToInt16(l_NoOf9), dt.Rows(0)("GP_PAYMTH").ToString, dt.Rows(0)("GP_SUB_PAYMTH").ToString, Convert.ToDouble(l_DrAmount9))

    End Sub
    Private Sub InsertLog(ByVal filename As String, ByVal paiddate As String, ByVal tbrow As Integer, ByVal txtrow As Integer,
                          ByVal paymth As String, ByVal sub_paymth As String, ByVal amt As Double)
        Dim table As New DataTable

        table.Columns.Add("GFLOG_BATCH_NO")
        table.Columns.Add("GFLOG_EXPTOBANK_DATE")
        table.Columns.Add("GFLOG_EXPTOBANK_FILENME")
        table.Columns.Add("GFLOG_PAYMTH")
        table.Columns.Add("GFLOG_SUB_PAYMTH")
        table.Columns.Add("GFLOG_PAIDDATE")
        table.Columns.Add("GFLOG_TOT_RECORD_TB")
        table.Columns.Add("GFLOG_TOT_RECORD_TXT")
        table.Columns.Add("GFLOG_TOT_AMOUNT")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")


        Dim row As DataRow
        row = table.NewRow()

        row("GFLOG_BATCH_NO") = txtBatchNo.Text.Trim
        row("GFLOG_EXPTOBANK_DATE") = Now.ToString("yyyyMMdd")
        row("GFLOG_EXPTOBANK_FILENME") = filename.ToUpper.Replace(".TXT", "")
        row("GFLOG_PAYMTH") = paymth
        row("GFLOG_SUB_PAYMTH") = sub_paymth
        row("GFLOG_PAIDDATE") = paiddate
        row("GFLOG_TOT_RECORD_TB") = tbrow
        row("GFLOG_TOT_RECORD_TXT") = txtrow
        row("GFLOG_TOT_AMOUNT") = amt / 1000
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec As Integer

        rec = cls.InsertLog(clsUtility.gConnGP, oleTrans, row)
        If rec = 1 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()
        End If

    End Sub
    Private Sub GenDetail(ByVal sw As StreamWriter, ByVal filename As String, ByVal dr As DataRow, ByVal line As Integer, ByVal amt As String)

        If InStr(amt.ToString, ".") Then
            amt = amt.Trim.Replace(".", "")
        Else
            amt = amt & "000"
        End If

        Dim l_RecordType3 = "003"
        sw.Write(l_RecordType3)
        Dim l_SeqOfCr = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr)

        Dim l_CrAccount
        If dr("GP_PAYMTH") = "M" Then
            l_CrAccount = dr("GP_PAYEE_BNKACCNO_NEW").ToString.PadRight(25, " ")
        Else
            l_CrAccount = "".PadRight(25, " ")
        End If
        sw.Write(l_CrAccount)
        Dim l_CrAmount = amt.ToString.PadLeft(16, "0")
        sw.Write(l_CrAmount)
        Dim l_CrCurrency = "THB"
        sw.Write(l_CrCurrency)
        Dim l_CrIntenalRef = "00000001"
        sw.Write(l_CrIntenalRef)
        Dim l_WHTPresent = "N"
        sw.Write(l_WHTPresent)
        Dim l_InvoicePresent = "N"
        sw.Write(l_InvoicePresent)
        Dim l_CrAdviceRequest = "N"
        sw.Write(l_CrAdviceRequest)
        Dim l_DeliveryMode = "P"
        sw.Write(l_DeliveryMode)
        Dim l_PicupLocation = "C002"
        sw.Write(l_PicupLocation)
        Dim l_WHTType = "00"
        sw.Write(l_WHTType)
        Dim l_WHTNo = "".PadRight(14, " ")
        sw.Write(l_WHTNo)
        Dim l_WHTAttNo = "000000"
        sw.Write(l_WHTAttNo)
        Dim l_WHTNoDetail = "00"
        sw.Write(l_WHTNoDetail)
        Dim l_WHTTotalAmt = "0000000000000000"
        sw.Write(l_WHTTotalAmt)
        Dim l_WHTNoInvoiceDetail = "000000"
        sw.Write(l_WHTNoInvoiceDetail)
        Dim l_WHTInvoiceAmt = "0000000000000000"
        sw.Write(l_WHTInvoiceAmt)
        Dim l_WHTPayType = "0"
        sw.Write(l_WHTPayType)
        Dim l_WHTRemark = "".PadRight(40, " ")
        sw.Write(l_WHTRemark)
        Dim l_WHTDeductDate = "".PadRight(8, " ")
        sw.Write(l_WHTDeductDate)
        Dim l_ReceiveBnkCode = dr("GP_BNKCODE_NO").ToString.PadRight(3, " ")
        sw.Write(l_ReceiveBnkCode)

        '-------------------------------------------------------------------------
        Dim l_ReceiveBnkName
        '-- SR-25591007-0014 ��� business net - change receiving bank and branch
        '--If dr("GP_BNKCODE") = "SCB" Then
        '--   l_ReceiveBnkName = dr("BKMST_BNKNAME_ENG").ToString.PadRight(35, " ")
        '--Else
        '--   l_ReceiveBnkName = dr("BKMST_BNKNAME").ToString.PadRight(35, " ")
        '--End If
        '-- SR-25591007-0014 ��� business net - change receiving bank and branch
        l_ReceiveBnkName = dr("BKMST_BNKNAME_ENG").ToString.PadRight(35, " ") '<-- SR-25591007-0014 ��� business net - change receiving bank and branch
        sw.Write(l_ReceiveBnkName.Substring(0, 35))
        '-------------------------------------------------------------------------

        Dim l_ReceiveBranchCode = dr("GP_BNKBRN_NEW").ToString.PadRight(4, " ")
        sw.Write(l_ReceiveBranchCode)

        Dim l_ReceiveBranchName
        If dr("GP_BNKCODE") = "SCB" Then
            l_ReceiveBranchName = "CHIDLOM BRANCH".PadRight(35, " ")
        Else
            '--l_ReceiveBranchName = "".PadRight(35, " ") '<-- SR-25591007-0014 ��� business net - change receiving bank and branch
            l_ReceiveBranchName = "BRANCH NAME".PadRight(35, " ") '<-- SR-25591007-0014 ��� business net - change receiving bank and branch
        End If
        sw.Write(l_ReceiveBranchName)

        Dim l_WHTSignatory = "".PadRight(1, " ")
        sw.Write(l_WHTSignatory)
        Dim l_ChqIssuance = "N"
        sw.Write(l_ChqIssuance)
        Dim l_ChqRefNo = dr("GP_CUSTREFNO").ToString.PadRight(20, " ")
        sw.Write(l_ChqRefNo)
        Dim l_ChqRefType = "3"
        sw.Write(l_ChqRefType)
        Dim l_PayTypeCode = "".PadRight(3, " ")
        sw.Write(l_PayTypeCode)

        Dim l_ServiceType
        If dr("GP_PAYMTH") = "M" Then
            l_ServiceType = "04"
        Else
            l_ServiceType = "".PadRight(2, " ")
        End If
        sw.Write(l_ServiceType)

        Dim l_002Remark = "".PadRight(68, " ")
        sw.Write(l_002Remark)
        Dim l_Bene_Flag = "".PadRight(2, " ")
        sw.Write(l_Bene_Flag)
        sw.WriteLine()


        'Generate 004
        Dim l_RecordType4 = "004"
        sw.Write(l_RecordType4)
        Dim l_CrIntenalRef4 = "00000001"
        sw.Write(l_CrIntenalRef4)
        Dim l_SeqOfCr4 = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr4)
        Dim l_PayeeIDCard = "".PadRight(15, " ")
        sw.Write(l_PayeeIDCard)

        Dim l_PayeeName
        If dr("GP_PAYMTH") = "M" Then
            l_PayeeName = dr("GP_PAYEE_BNKACCNME").ToString.PadRight(100, " ")
        Else
            l_PayeeName = dr("GP_PAYEE_NAME").ToString.PadRight(100, " ")
        End If
        sw.Write(l_PayeeName.ToString.Substring(0, 100))

        Dim l_Address1
        If dr("GP_PAYMTH") = "D" Then
            l_Address1 = dr("GP_ADDRESS1").ToString.PadRight(70, " ")
        Else
            l_Address1 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address1.ToString.Substring(0, 70))

        Dim l_Address2
        If dr("GP_PAYMTH") = "D" Then
            l_Address2 = dr("GP_DISTRICT").ToString.PadRight(70, " ")
        Else
            l_Address2 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address2)

        Dim l_Address3
        If dr("GP_PAYMTH") = "D" Then
            l_Address3 = dr("GP_PROVINCE").ToString.PadRight(70, " ")
        Else
            l_Address3 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address3)

        Dim l_PayeeTaxId = "".PadRight(10, " ")
        sw.Write(l_PayeeTaxId)
        Dim l_PayeeNameEng = "".PadRight(70, " ")
        sw.Write(l_PayeeNameEng.ToString.Substring(0, 70))
        Dim l_PayeeFax = "".PadRight(10, " ")
        sw.Write(l_PayeeFax)
        Dim l_PayeeMobile = "".PadRight(10, " ")
        sw.Write(l_PayeeMobile)
        Dim l_PayeeEmail = "".PadRight(64, " ")
        sw.Write(l_PayeeEmail.ToString.Substring(0, 64))
        Dim l_PayeeNameThai = "".PadRight(100, " ")
        sw.Write(l_PayeeNameThai.ToString.Substring(0, 100))
        Dim l_Payee2Address1 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address1.ToString.Substring(0, 70))
        Dim l_Payee2Address2 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address2.ToString.Substring(0, 70))
        Dim l_Payee2Address3 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address3.ToString.Substring(0, 70))

        sw.WriteLine()
    End Sub
    Private Sub CopytoNewFile(ByVal oldFilename As String)

        Dim newFilename As String
        Dim newFilenameTxt As String
        newFilename = cls.getPrefixFilename(clsUtility.gConnGP) & cls.getCoperateId(clsUtility.gConnGP) & cls.getBankCode(clsUtility.gConnGP) & cls.getFileType(clsUtility.gConnGP) & cls.getSysDateTime(clsUtility.gConnGP)
        newFilenameTxt = newFilename & ".txt"

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec1, rec2 As Integer

        rec1 = cls.InsertMap(clsUtility.gConnGP, oleTrans, System.IO.Path.GetFileName(oldFilename), newFilenameTxt)
        rec2 = cls.InsertRound(clsUtility.gConnGP, oleTrans, System.IO.Path.GetFileName(oldFilename))

        If rec1 = 1 And rec2 = 1 Then
            System.IO.File.Copy(oldFilename, System.IO.Path.GetDirectoryName(oldFilename) & "/" & newFilenameTxt, True)
            oleTrans.Commit()
        Else
            oleTrans.Rollback()
        End If

        Dim fs As FileStream = File.Create(System.IO.Path.GetDirectoryName(oldFilename) & "/" & newFilename & ".ctrl")
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(newFilenameTxt & ".gpg")
        fs.Write(info, 0, info.Length)
        fs.Close()

        System.Threading.Thread.Sleep(1000)

    End Sub

    Private Sub CopytoNewFileServer(ByVal oldFilenameIncludePath As String, ByVal LocalPath As String, ByVal ToServerPath As String)

        Dim newFilename As String
        Dim newFilenameTxt As String
        Dim clsH As New ClsHashTotalErrorLOCancel

        newFilename = cls.getPrefixFilename(clsUtility.gConnGP) & cls.getCoperateId(clsUtility.gConnGP) & cls.getBankCode(clsUtility.gConnGP) & cls.getFileType(clsUtility.gConnGP) & cls.getSysDateTime(clsUtility.gConnGP)
        newFilenameTxt = newFilename & ".txt"

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec1, rec2 As Integer

        rec1 = cls.InsertMap(clsUtility.gConnGP, oleTrans, System.IO.Path.GetFileName(oldFilenameIncludePath), newFilenameTxt)
        rec2 = cls.InsertRound(clsUtility.gConnGP, oleTrans, System.IO.Path.GetFileName(oldFilenameIncludePath))

        If rec1 = 1 And rec2 = 1 Then
            System.IO.File.Copy(oldFilenameIncludePath, System.IO.Path.GetDirectoryName(oldFilenameIncludePath) & "/" & newFilenameTxt, True)
            'MsgBox("backup : from-" & System.IO.Path.GetDirectoryName(oldFilenameIncludePath) & newFilenameTxt & ".txt" & vbCrLf & " to-" & ToServerPath & newFilename & ".txt")
            If clsUtility.BackupFile(System.IO.Path.GetDirectoryName(oldFilenameIncludePath) & newFilenameTxt, ToServerPath & newFilenameTxt) Then
            End If
            If clsUtility.BackupFile(oldFilenameIncludePath, ToServerPath & System.IO.Path.GetFileName(oldFilenameIncludePath)) Then
            End If

            oleTrans.Commit()
        Else
            oleTrans.Rollback()
        End If

        Dim fs As FileStream = File.Create(System.IO.Path.GetDirectoryName(oldFilenameIncludePath) & "/" & newFilename & ".ctrl")
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(newFilenameTxt & ".gpg")
        fs.Write(info, 0, info.Length)
        fs.Close()

        If clsUtility.BackupFile(LocalPath & newFilename & ".ctrl", ToServerPath & newFilename & ".ctrl") Then
        End If

        System.Threading.Thread.Sleep(1000)

    End Sub

End Class
