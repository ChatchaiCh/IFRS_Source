Public Class FrmByBatchReport

End Class