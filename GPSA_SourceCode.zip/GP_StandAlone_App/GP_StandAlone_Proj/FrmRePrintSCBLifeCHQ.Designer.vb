<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRePrintSCBLifeCHQ
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtReason = New System.Windows.Forms.TextBox()
        Me.txtEnd = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBegin = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTo = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cboBankCode = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.LblAmount = New System.Windows.Forms.Label()
        Me.txtLine = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.btnPrint = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnLoad = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelD1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtReason
        '
        Me.txtReason.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtReason.Location = New System.Drawing.Point(117, 63)
        Me.txtReason.MaxLength = 100
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(549, 20)
        Me.txtReason.TabIndex = 65
        '
        'txtEnd
        '
        Me.txtEnd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtEnd.Location = New System.Drawing.Point(316, 38)
        Me.txtEnd.MaxLength = 15
        Me.txtEnd.Name = "txtEnd"
        Me.txtEnd.Size = New System.Drawing.Size(161, 20)
        Me.txtEnd.TabIndex = 64
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(17, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "Reason :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(303, 17)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'txtBegin
        '
        Me.txtBegin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBegin.Location = New System.Drawing.Point(117, 38)
        Me.txtBegin.MaxLength = 15
        Me.txtBegin.Name = "txtBegin"
        Me.txtBegin.Size = New System.Drawing.Size(161, 20)
        Me.txtBegin.TabIndex = 63
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(17, 93)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 13)
        Me.Label13.TabIndex = 61
        Me.Label13.Text = "Format Cheque :"
        '
        'txtBankName
        '
        Me.txtBankName.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtBankName.Enabled = False
        Me.txtBankName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBankName.Location = New System.Drawing.Point(281, 13)
        Me.txtBankName.MaxLength = 15
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(385, 20)
        Me.txtBankName.TabIndex = 62
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(912, 26)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Re-Print Cheque"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTo
        '
        Me.lblTo.AutoSize = True
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblTo.ForeColor = System.Drawing.Color.Black
        Me.lblTo.Location = New System.Drawing.Point(290, 45)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(20, 13)
        Me.lblTo.TabIndex = 50
        Me.lblTo.Text = "To"
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.txtReason)
        Me.PanelD1.Controls.Add(Me.txtEnd)
        Me.PanelD1.Controls.Add(Me.txtBegin)
        Me.PanelD1.Controls.Add(Me.txtBankName)
        Me.PanelD1.Controls.Add(Me.Label13)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.lblTo)
        Me.PanelD1.Controls.Add(Me.cboBankCode)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Location = New System.Drawing.Point(15, 60)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(916, 123)
        Me.PanelD1.TabIndex = 69
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(114, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 13)
        Me.Label6.TabIndex = 50
        Me.Label6.Text = "(A=A/C Payee Only)"
        '
        'cboBankCode
        '
        Me.cboBankCode.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.cboBankCode.Enabled = False
        Me.cboBankCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboBankCode.FormattingEnabled = True
        Me.cboBankCode.Location = New System.Drawing.Point(117, 13)
        Me.cboBankCode.Name = "cboBankCode"
        Me.cboBankCode.Size = New System.Drawing.Size(161, 21)
        Me.cboBankCode.TabIndex = 46
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(17, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Bank Cheque :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(17, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Cheque No Begin :"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtAmount)
        Me.Panel1.Controls.Add(Me.LblAmount)
        Me.Panel1.Controls.Add(Me.txtLine)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Location = New System.Drawing.Point(15, 189)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(916, 279)
        Me.Panel1.TabIndex = 72
        '
        'txtAmount
        '
        Me.txtAmount.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtAmount.Enabled = False
        Me.txtAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAmount.Location = New System.Drawing.Point(395, 239)
        Me.txtAmount.MaxLength = 30
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(224, 20)
        Me.txtAmount.TabIndex = 80
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblAmount
        '
        Me.LblAmount.AutoSize = True
        Me.LblAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.LblAmount.ForeColor = System.Drawing.Color.Black
        Me.LblAmount.Location = New System.Drawing.Point(313, 246)
        Me.LblAmount.Name = "LblAmount"
        Me.LblAmount.Size = New System.Drawing.Size(76, 13)
        Me.LblAmount.TabIndex = 79
        Me.LblAmount.Text = "Total Amount :"
        '
        'txtLine
        '
        Me.txtLine.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtLine.Enabled = False
        Me.txtLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtLine.Location = New System.Drawing.Point(73, 239)
        Me.txtLine.MaxLength = 30
        Me.txtLine.Name = "txtLine"
        Me.txtLine.Size = New System.Drawing.Size(182, 20)
        Me.txtLine.TabIndex = 78
        Me.txtLine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(7, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 77
        Me.Label7.Text = "Total Line :"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(4, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(883, 233)
        Me.DataGridView1.TabIndex = 72
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label4)
        Me.PanelH1.Location = New System.Drawing.Point(19, 28)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(912, 26)
        Me.PanelH1.TabIndex = 70
        '
        'btnPrint
        '
        Me.btnPrint.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrint.Enabled = False
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnPrint.Image = Nothing
        Me.btnPrint.ImageKey = ""
        Me.btnPrint.ImageList = Nothing
        Me.btnPrint.Location = New System.Drawing.Point(113, 474)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.Size = New System.Drawing.Size(92, 28)
        Me.btnPrint.TabIndex = 76
        Me.btnPrint.Text = "Print"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(309, 474)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.Size = New System.Drawing.Size(92, 28)
        Me.btnClose.TabIndex = 75
        Me.btnClose.Text = "Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnLoad
        '
        Me.btnLoad.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnLoad.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLoad.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLoad.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnLoad.ForeColor = System.Drawing.Color.White
        Me.btnLoad.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnLoad.Image = Nothing
        Me.btnLoad.ImageKey = ""
        Me.btnLoad.ImageList = Nothing
        Me.btnLoad.Location = New System.Drawing.Point(15, 474)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.Size = New System.Drawing.Size(92, 28)
        Me.btnLoad.TabIndex = 73
        Me.btnLoad.Text = "Load"
        Me.btnLoad.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnLoad.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(211, 474)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 74
        Me.btnClear.Text = "Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmRePrintSCBLifeCHQ
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(943, 526)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnLoad)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelH1)
        Me.Name = "FrmRePrintSCBLifeCHQ"
        Me.Text = "Reprint Cheque"
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelH1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtReason As System.Windows.Forms.TextBox
    Friend WithEvents txtEnd As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnLoad As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtBegin As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtBankName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblTo As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboBankCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents LblAmount As System.Windows.Forms.Label
    Friend WithEvents txtLine As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
