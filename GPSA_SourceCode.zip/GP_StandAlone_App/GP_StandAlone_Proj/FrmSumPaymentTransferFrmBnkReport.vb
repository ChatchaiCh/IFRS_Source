Imports System.Text
Imports UtilityClassLibrary
Imports System.Data.OleDb
Public Class FrmSumPaymentTransferFrmBnkReport
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim PaymentMethod As String
    Dim SubPaymentMethod As String
    Dim PaidDate As String
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)


    End Sub
    Private Sub FrmPrintSCBLifeCHQ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()

        Dim sb As New StringBuilder()

        sb.Append(" select to_char(sysdate,'DD/MM/YYYY') as currentDate from dual  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count <> 0 Then
            txtAsOfDate.Text = dt.Rows(0)("currentDate").ToString

        End If


    End Sub


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        PrintReport()

    End Sub
    Private Sub PrintReport()

      

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RPTPayTransFromBank.rpt")


        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pTransdate"
            discrete1.Value = Trim(txtAsOfDate.Text)
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            'discreteUser.Value = "SOA"
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


            Dim frm As New FrmSumPaymentTransferFrmBnkReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox("��辺�����ŵ�����͹�")
        End If


    End Sub

    Function GetDataGL() As DataTable

        Dim sb As New StringBuilder()

        sb.Append(" select BNKS_BNKSCODE_NO , BKMST_BNKCODE , BKMST_BNKNAME , BKMST_BNKNAME_ENG ")
        sb.Append(" , PAYT_PAY_GROUP , GP_PAYMTH ,  StrPaymentType , GP_SUB_PAYMTH  ")
        sb.Append(" , GP_EXPTOBANK_DATE , GP_EXPTOBANK_DATE_SHOW ,GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME , StrSubPaymentType ")
        sb.Append(" , GP_PAIDDATE , GP_PAIDDATE_SHOW  ")
        sb.Append(" , GFLOG_TOT_RECORD_TXT as GP_COUNT  ")
        sb.Append(" , sum(GP_AMOUNT) as GP_AMOUNT  ")
        sb.Append(" from ( ")

        sb.Append(" select  GPS_TL_BANKSERVICE1.BNKS_BNKSCODE_NO , GPS_TL_BANKMASTER.BKMST_BNKCODE , GPS_TL_BANKMASTER.BKMST_BNKNAME  ")
        sb.Append(" , GPS_TL_BANKMASTER.BKMST_BNKNAME_ENG , GPS_TL_PAYTYPE.PAYT_PAY_GROUP , GPS_PAYMENT.GP_PAYMTH  ")
        sb.Append("  , case GPS_PAYMENT.GP_PAYMTH  ")
        sb.Append(" when 'C' then 'Cheque & Draft' ")
        sb.Append(" when 'D' then 'Cheque & Draft' ")
        sb.Append(" else 'Media' end  as StrPaymentType ")
        sb.Append(" , GPS_PAYMENT.GP_SUB_PAYMTH , GPS_PAYMENT.GP_EXPTOBANK_DATE  ")
        sb.Append(" , substr(GPS_PAYMENT.GP_EXPTOBANK_DATE,7,2)||'/'||substr(GPS_PAYMENT.GP_EXPTOBANK_DATE,5,2)||'/'||substr(GPS_PAYMENT.GP_EXPTOBANK_DATE,1,4) as GP_EXPTOBANK_DATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_EXPTOBANK_FILENME ")
        sb.Append(" ,  case ")
        sb.Append(" when (GPS_PAYMENT.GP_PAYMTH='M') and (to_number(substr(GPS_PAYMENT.GP_EXPTOBANK_FILENME,length(GPS_PAYMENT.GP_EXPTOBANK_FILENME)-1,2))>=50) ")
        sb.Append(" then 'Media Clearing'  ")
        sb.Append(" when (GPS_PAYMENT.GP_PAYMTH='M') and (to_number(substr(GPS_PAYMENT.GP_EXPTOBANK_FILENME,length(GPS_PAYMENT.GP_EXPTOBANK_FILENME)-1,2))<50) ")
        sb.Append(" then 'Direct Credit' ")
        sb.Append(" when (GPS_PAYMENT.GP_PAYMTH='C') ")
        sb.Append(" then 'Cheque' ")
        sb.Append(" else 'Draft' end as StrSubPaymentType , GPS_PAYMENT.GP_PAIDDATE  ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_PAIDDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,1,4) as GP_PAIDDATE_SHOW  ")
        sb.Append(" , GPS_GENPAYMENTFILE_LOG.GFLOG_TOT_RECORD_TXT ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT ")
        sb.Append(" from GPS_PAYMENT ")
        '------- �֧�����Ū��� sub  payment method
        sb.Append(" left join GPS_TL_PAYTYPE  ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH  ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '------- �֧�����Ū���ʶҹС�þ����
        sb.Append(" left join GPS_TL_BANKSERVICE1  ")
        sb.Append(" on GPS_TL_PAYTYPE.PAYT_PAY_GROUP = GPS_TL_BANKSERVICE1.BNKS_PAY_GROUP ")

        '------- �֧������ TAX
        sb.Append(" left join GPS_TL_BANKMASTER ")
        sb.Append(" on GPS_TL_BANKSERVICE1.BNKS_BNKSCODE_NO =   GPS_TL_BANKMASTER.BKMST_BNKCODE_NO ")

        '------- �֧�ӹǹ��¡�� ���͵ç�Ѻ��¡��� text file ����Ѻ �Թ�Թ 2 ��ҹ
        sb.Append(" left join GPS_GENPAYMENTFILE_LOG ")
        sb.Append(" on GPS_PAYMENT.GP_EXPTOBANK_FILENME = GPS_GENPAYMENTFILE_LOG.gflog_exptobank_filenme ")

        sb.Append(" where GPS_PAYMENT.GP_EXPTOBANK_FILENME is not null ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_EXPTOBANK = 'Y' ")
        sb.Append(" and GPS_PAYMENT.GP_FLAG_GET_RESULT  = 'N'  ")

        sb.Append(" ) masterdate ")

        '------- Begin Adjust Incident log by Songpol 20/01/2015
        ' ���͹���ǹ�֧������ C or D �е�ͧ���� �ѹ��� condition ��� �ѹ��� Export ����ͧ���¡����ѹ���������§ҹ (sysdate)
        'sb.Append("WHERE (GP_PAYMTH<>'M') OR(GP_PAYMTH='M' AND GP_PAIDDATE <=TO_CHAR(SYSDATE,'YYYYMMDD')) ")

        sb.Append("WHERE (GP_PAYMTH<>'M' AND GP_EXPTOBANK_DATE < TO_CHAR(SYSDATE,'YYYYMMDD') ) OR ( GP_PAYMTH='M' AND GP_PAIDDATE <=TO_CHAR(SYSDATE,'YYYYMMDD')) ")

        '------- End Adjust Incident log by Songpol 20/01/2015

        sb.Append(" group by BNKS_BNKSCODE_NO , BKMST_BNKCODE , BKMST_BNKNAME , BKMST_BNKNAME_ENG  ")
        sb.Append(" , PAYT_PAY_GROUP , GP_PAYMTH ,  StrPaymentType , GP_SUB_PAYMTH  ")
        sb.Append(" , GP_EXPTOBANK_DATE , GP_EXPTOBANK_DATE_SHOW ,GP_EXPTOBANK_FILENME , StrSubPaymentType ")
        sb.Append(" , GP_PAIDDATE , GP_PAIDDATE_SHOW, GFLOG_TOT_RECORD_TXT ")
        sb.Append(" order by BNKS_BNKSCODE_NO , BKMST_BNKCODE , BKMST_BNKNAME , BKMST_BNKNAME_ENG  ")
        sb.Append(" , PAYT_PAY_GROUP , GP_PAYMTH ,  StrPaymentType , GP_SUB_PAYMTH  ")
        sb.Append(" , GP_EXPTOBANK_DATE , GP_EXPTOBANK_DATE_SHOW ,GP_EXPTOBANK_FILENME , StrSubPaymentType ")
        sb.Append(" , GP_PAIDDATE , GP_PAIDDATE_SHOW, GFLOG_TOT_RECORD_TXT ")


        'MsgBox(sb.ToString)
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function


End Class