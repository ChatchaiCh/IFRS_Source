﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmHashTotalError
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtToFile = New System.Windows.Forms.TextBox()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.txtRejectFile = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ComboBoxFile = New System.Windows.Forms.ComboBox()
        Me.btnAddfile = New System.Windows.Forms.Button()
        Me.txtLine = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgvReject = New System.Windows.Forms.DataGridView()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dgvfile = New System.Windows.Forms.DataGridView()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.dgvPayment = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbStatusWork = New System.Windows.Forms.ListBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.btnCheck = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnReject = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnSearch = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgvReject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvfile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.dgvPayment, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtToFile)
        Me.Panel1.Controls.Add(Me.btnBrowse)
        Me.Panel1.Controls.Add(Me.txtRejectFile)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.ComboBoxFile)
        Me.Panel1.Controls.Add(Me.btnAddfile)
        Me.Panel1.Controls.Add(Me.txtLine)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(12, 63)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(814, 67)
        Me.Panel1.TabIndex = 0
        '
        'txtToFile
        '
        Me.txtToFile.Location = New System.Drawing.Point(575, 36)
        Me.txtToFile.Name = "txtToFile"
        Me.txtToFile.Size = New System.Drawing.Size(146, 20)
        Me.txtToFile.TabIndex = 8
        Me.txtToFile.Visible = False
        '
        'btnBrowse
        '
        Me.btnBrowse.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnBrowse.Location = New System.Drawing.Point(726, 35)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(75, 20)
        Me.btnBrowse.TabIndex = 7
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = False
        Me.btnBrowse.Visible = False
        '
        'txtRejectFile
        '
        Me.txtRejectFile.Location = New System.Drawing.Point(423, 36)
        Me.txtRejectFile.Name = "txtRejectFile"
        Me.txtRejectFile.Size = New System.Drawing.Size(146, 20)
        Me.txtRejectFile.TabIndex = 6
        Me.txtRejectFile.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(420, 14)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(127, 13)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "ชื่อไฟล์ Reject Payment : "
        Me.Label7.Visible = False
        '
        'ComboBoxFile
        '
        Me.ComboBoxFile.FormattingEnabled = True
        Me.ComboBoxFile.Location = New System.Drawing.Point(67, 11)
        Me.ComboBoxFile.Name = "ComboBoxFile"
        Me.ComboBoxFile.Size = New System.Drawing.Size(266, 21)
        Me.ComboBoxFile.TabIndex = 4
        '
        'btnAddfile
        '
        Me.btnAddfile.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnAddfile.Location = New System.Drawing.Point(339, 11)
        Me.btnAddfile.Name = "btnAddfile"
        Me.btnAddfile.Size = New System.Drawing.Size(75, 45)
        Me.btnAddfile.TabIndex = 3
        Me.btnAddfile.Text = "Add"
        Me.btnAddfile.UseVisualStyleBackColor = False
        '
        'txtLine
        '
        Me.txtLine.Location = New System.Drawing.Point(67, 36)
        Me.txtLine.Name = "txtLine"
        Me.txtLine.Size = New System.Drawing.Size(266, 20)
        Me.txtLine.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 39)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Line No :   "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "ชื่อไฟล์ S1 : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(328, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(163, 24)
        Me.Label2.TabIndex = 90
        Me.Label2.Text = "Hash Total Error"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(312, 16)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgvReject)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.dgvfile)
        Me.Panel2.Location = New System.Drawing.Point(12, 134)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(814, 122)
        Me.Panel2.TabIndex = 91
        '
        'dgvReject
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvReject.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgvReject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvReject.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgvReject.Location = New System.Drawing.Point(412, 24)
        Me.dgvReject.Name = "dgvReject"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvReject.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgvReject.Size = New System.Drawing.Size(389, 91)
        Me.dgvReject.TabIndex = 3
        Me.dgvReject.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(409, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "รายการยกเลิก"
        Me.Label9.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 1)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(99, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "รายละเอียดไฟล์จ่าย"
        '
        'dgvfile
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvfile.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvfile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvfile.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgvfile.Location = New System.Drawing.Point(3, 18)
        Me.dgvfile.Name = "dgvfile"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvfile.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgvfile.Size = New System.Drawing.Size(808, 91)
        Me.dgvfile.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.dgvPayment)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Location = New System.Drawing.Point(12, 257)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(814, 161)
        Me.Panel3.TabIndex = 92
        '
        'dgvPayment
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPayment.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.dgvPayment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvPayment.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgvPayment.Location = New System.Drawing.Point(3, 20)
        Me.dgvPayment.Name = "dgvPayment"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPayment.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.dgvPayment.Size = New System.Drawing.Size(805, 137)
        Me.dgvPayment.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 4)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "ข้อมูลรายละเอียดการจ่าย"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.lbStatusWork)
        Me.Panel4.Location = New System.Drawing.Point(12, 422)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(814, 70)
        Me.Panel4.TabIndex = 94
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Process Status"
        '
        'lbStatusWork
        '
        Me.lbStatusWork.FormattingEnabled = True
        Me.lbStatusWork.Location = New System.Drawing.Point(6, 21)
        Me.lbStatusWork.Name = "lbStatusWork"
        Me.lbStatusWork.Size = New System.Drawing.Size(802, 43)
        Me.lbStatusWork.TabIndex = 95
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnConfirm
        '
        Me.btnConfirm.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnConfirm.ForeColor = System.Drawing.Color.White
        Me.btnConfirm.Location = New System.Drawing.Point(507, 498)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(136, 28)
        Me.btnConfirm.TabIndex = 8
        Me.btnConfirm.Text = "Confirm Auto FTP"
        Me.btnConfirm.UseVisualStyleBackColor = False
        '
        'BtnCancel
        '
        Me.BtnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.BtnCancel.ForeColor = System.Drawing.Color.White
        Me.BtnCancel.Location = New System.Drawing.Point(649, 498)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(139, 28)
        Me.BtnCancel.TabIndex = 95
        Me.BtnCancel.Text = "Cancel Auto FTP"
        Me.BtnCancel.UseVisualStyleBackColor = False
        '
        'btnCheck
        '
        Me.btnCheck.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnCheck.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnCheck.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnCheck.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCheck.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnCheck.ForeColor = System.Drawing.Color.White
        Me.btnCheck.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnCheck.Image = Nothing
        Me.btnCheck.ImageKey = ""
        Me.btnCheck.ImageList = Nothing
        Me.btnCheck.Location = New System.Drawing.Point(435, 498)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnCheck.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnCheck.Size = New System.Drawing.Size(46, 28)
        Me.btnCheck.TabIndex = 96
        Me.btnCheck.Text = "Check"
        Me.btnCheck.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCheck.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(312, 498)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.Size = New System.Drawing.Size(92, 28)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(214, 498)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnReject
        '
        Me.btnReject.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnReject.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnReject.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnReject.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReject.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnReject.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnReject.ForeColor = System.Drawing.Color.White
        Me.btnReject.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnReject.Image = Nothing
        Me.btnReject.ImageKey = ""
        Me.btnReject.ImageList = Nothing
        Me.btnReject.Location = New System.Drawing.Point(116, 498)
        Me.btnReject.Name = "btnReject"
        Me.btnReject.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnReject.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnReject.Size = New System.Drawing.Size(92, 28)
        Me.btnReject.TabIndex = 5
        Me.btnReject.Text = "Reject"
        Me.btnReject.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnReject.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnSearch
        '
        Me.btnSearch.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.White
        Me.btnSearch.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnSearch.Image = Nothing
        Me.btnSearch.ImageKey = ""
        Me.btnSearch.ImageList = Nothing
        Me.btnSearch.Location = New System.Drawing.Point(18, 498)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSearch.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSearch.Size = New System.Drawing.Size(92, 28)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmHashTotalError
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(838, 538)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.BtnCancel)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnReject)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FrmHashTotalError"
        Me.Text = "Hash Total Error"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.dgvReject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvfile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.dgvPayment, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtLine As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgvfile As System.Windows.Forms.DataGridView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents dgvPayment As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnAddfile As System.Windows.Forms.Button
    Friend WithEvents btnSearch As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnReject As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lbStatusWork As System.Windows.Forms.ListBox
    Friend WithEvents ComboBoxFile As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtRejectFile As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents dgvReject As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btnConfirm As System.Windows.Forms.Button
    Friend WithEvents BtnCancel As System.Windows.Forms.Button
    Friend WithEvents txtToFile As System.Windows.Forms.TextBox
    Friend WithEvents btnCheck As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
