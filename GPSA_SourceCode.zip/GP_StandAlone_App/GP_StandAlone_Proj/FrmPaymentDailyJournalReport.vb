Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmPaymentDailyJournalReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub FrmRptDailyJournalApprove_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        ControlStyle()

        ListSection()
        ListDataSource()
        ListJournalType()

    End Sub
    Private Sub ListSection()
        Dim sb As New StringBuilder()

        sb.Append("SELECT A.DTS_MERGE_DEP, B.DEP_DEPNAME  ")
        sb.Append("FROM GPS_TL_DATASOURCE A LEFT JOIN GPS_TL_DEPARTMENT B ON A.DTS_MERGE_DEP=B.DEP_DEPCODE  ")
        sb.Append("WHERE A.DTS_CORE_SYSTEM='ACC' GROUP BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ORDER BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboSection
                .DataSource = dt
                .DisplayMember = "DEP_DEPNAME"
                .ValueMember = "DTS_MERGE_DEP"
            End With
        End If
        cboSection.SelectedIndex = 0
    End Sub
    Private Sub ListJournalType()
        Dim sb As New StringBuilder()

        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_C) AS ID,DTS_JN_TYPE_C AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_C <> ' ' ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_J_NOPAY) AS ID,DTS_JN_TYPE_J_NOPAY AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_J_NOPAY <> ' ' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboJournalType
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
    End Sub
    Private Sub ListDataSource()
        cboDataSource.Items.Add("All")
        cboDataSource.Items.Add("TLM")
        cboDataSource.Items.Add("Non TLM")
        cboDataSource.SelectedIndex = 0
    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()
            Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramHeader As New CrystalDecisions.Shared.ParameterField()


            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = IIf(txtEntryDate.Text.Trim = "", "ALL", txtEntryDate.Text.Trim) 'dtpDueDate.Value.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            paramHeader.ParameterFieldName = "pHeader"
            discreteHeader.Value = "��§ҹ Daily Journal Approval  ��Ш��ѹ"
            paramHeader.CurrentValues.Add(discreteHeader)
            paramFields.Add(paramHeader)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmPaymentDailyJournalReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Function GetDataGL() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT L.* ,S.ACNT_NAME_TH AS SUBACCNAME FROM GPS_GL_CREATION L LEFT JOIN ")
        sb.Append("GLM_ACCOUNT_SETUP S ON L.GLCR_SUB_ACCT=S.ACNT_S_CODE INNER JOIN ")
        sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_TRANSREF ")
        sb.Append("FROM GPS_TRANSREF_REL ")
        sb.Append("WHERE 1=1 ")

        If cboSection.SelectedValue.ToString = "DIS" Then
            sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
        Else
            sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
        End If

        Select Case cboDataSource.SelectedIndex
            Case "1"
                sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
            Case "2"
                sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
        End Select

        If txtEntryDate.Text.Trim <> "" Then
            Dim entrydate As String
            entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
            sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
        End If
        If txtDueDate.Text.Trim <> "" Then
            Dim duedate As String
            duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
            sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
        End If

        sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

        If txtJnFrom.Text.Trim <> "" And txtJnTo.Text.Trim <> "" Then
            sb.Append("AND TREF_JN_HOLD BETWEEN '" & txtJnFrom.Text.Trim & "' AND '" & txtJnTo.Text.Trim & "'  ")

        Else

            If txtJnFrom.Text.Trim <> "" Then
                sb.Append("AND TREF_JN_HOLD='" & txtJnFrom.Text.Trim & "' ")
            End If

            If txtJnTo.Text.Trim <> "" Then
                sb.Append("AND TREF_JN_HOLD='" & txtJnTo.Text.Trim & "' ")
            End If

        End If

        sb.Append("AND TREF_APPROVEDBY IS NULL ")
        sb.Append("ORDER BY TREF_JN_HOLD) A ")
        sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE ")
        sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM ")
        sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF ")
        sb.Append("ORDER BY L.GLCR_LINENO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Function fnGetJournalHold() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT L.GLCR_JN_HOLD  FROM GPS_GL_CREATION L INNER JOIN ")
        sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_TRANSREF ")
        sb.Append("FROM GPS_TRANSREF_REL ")
        sb.Append("WHERE 1=1 ")

        If cboSection.SelectedValue.ToString = "DIS" Then
            sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
        Else
            sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
        End If

        Select Case cboDataSource.SelectedIndex
            Case "1"
                sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
            Case "2"
                sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
        End Select

        If txtEntryDate.Text.Trim <> "" Then
            Dim entrydate As String
            entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
            sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
        End If
        If txtDueDate.Text.Trim <> "" Then
            Dim duedate As String
            duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
            sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
        End If

        sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")


        sb.Append("AND TREF_APPROVEDBY IS NULL ")
        sb.Append("ORDER BY TREF_JN_HOLD) A ")
        sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE ")
        sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM ")
        sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF ")
        sb.Append("GROUP BY L.GLCR_JN_HOLD ORDER BY L.GLCR_JN_HOLD ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Function fnGetJournalHold_old() As DataTable
        Try

            Dim sb As New StringBuilder()

            sb.Append("SELECT TREF_JN_HOLD,TREF_TRANSREF ")
            sb.Append("FROM GPS_TRANSREF_REL ")
            sb.Append("WHERE 1=1 ")

            If cboSection.SelectedValue.ToString = "DIS" Then
                sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
            Else
                sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
            End If

            'If cboDataSource.Text.ToUpper <> "ALL" Then
            '    sb.Append("AND TREF_DTSOURCE = '" & cboDataSource.Text & "' ")
            'End If

            Select Case cboDataSource.SelectedIndex
                Case "1"
                    sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
                Case "2"
                    sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
            End Select

            If txtEntryDate.Text.Trim <> "" Then
                Dim entrydate As String
                entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
                sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
            End If
            If txtDueDate.Text.Trim <> "" Then
                Dim duedate As String
                duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
                sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
            End If

            sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

            sb.Append("AND TREF_APPROVEDBY IS NULL ")
            sb.Append("ORDER BY TREF_JN_HOLD ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)


            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Private Sub BindJournalHold()
        Try
            Dim dt As DataTable
            dt = fnGetJournalHold()

            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                txtJnFrom.Text = dt.Rows(0)("GLCR_JN_HOLD").ToString
                txtJnTo.Text = dt.Rows(dt.Rows.Count - 1)("GLCR_JN_HOLD").ToString
            Else
                txtJnFrom.Text = ""
                txtJnTo.Text = ""
            End If
        Catch ex As Exception

        End Try


    End Sub
    Private Sub cboSection_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSection.SelectedIndexChanged
        BindJournalHold()
    End Sub

    Private Sub cboDataSource_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDataSource.SelectedIndexChanged
        BindJournalHold()
    End Sub

    Private Sub dtpDateCreated_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs)
        BindJournalHold()
    End Sub

    Private Sub cboJournalType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboJournalType.SelectedIndexChanged
        BindJournalHold()
    End Sub

    Private Sub dtpDueDate_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs)
        BindJournalHold()
    End Sub

    Private Sub txtEntryDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtEntryDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtEntryDate.Text.Trim = "" Then
                BindJournalHold()
            Else
                Dim dateString As String = txtEntryDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    BindJournalHold()
                Else
                    MsgBox("Date format is not valid")
                    txtEntryDate.Text = ""
                    txtJnTo.Text = ""
                    txtJnFrom.Text = ""
                    txtEntryDate.Focus()
                End If
            End If

        End If
    End Sub

    Private Sub txtDueDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDueDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDueDate.Text.Trim = "" Then
                BindJournalHold()
            Else
                Dim dateString As String = txtDueDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    BindJournalHold()
                Else
                    MsgBox("Date format is not valid")
                    txtDueDate.Text = ""
                    txtJnTo.Text = ""
                    txtJnFrom.Text = ""
                    txtDueDate.Focus()
                End If
            End If

        End If
    End Sub
    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click

        PrintReport()

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class