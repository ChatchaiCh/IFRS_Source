<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAccManualKeyIn
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmAccManualKeyIn))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.RipsWareImageButtonBase2 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.RipsWareImageButtonBase1 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.btnBrowse = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.txtTextURL = New GP_StandAlone_App.WaterMarkTextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.WaterMarkTextBox5 = New GP_StandAlone_App.WaterMarkTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(14, 271)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(969, 385)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.RipsWareImageButtonBase2)
        Me.TabPage1.Controls.Add(Me.RipsWareImageButtonBase1)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(961, 359)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "GL"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'RipsWareImageButtonBase2
        '
        Me.RipsWareImageButtonBase2.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.RipsWareImageButtonBase2.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.RipsWareImageButtonBase2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RipsWareImageButtonBase2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RipsWareImageButtonBase2.ForeColor = System.Drawing.Color.White
        Me.RipsWareImageButtonBase2.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.RipsWareImageButtonBase2.Image = Nothing
        Me.RipsWareImageButtonBase2.ImageKey = ""
        Me.RipsWareImageButtonBase2.ImageList = Nothing
        Me.RipsWareImageButtonBase2.Location = New System.Drawing.Point(8, 318)
        Me.RipsWareImageButtonBase2.Name = "RipsWareImageButtonBase2"
        Me.RipsWareImageButtonBase2.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase2.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.RipsWareImageButtonBase2.Size = New System.Drawing.Size(92, 28)
        Me.RipsWareImageButtonBase2.TabIndex = 41
        Me.RipsWareImageButtonBase2.Text = "&Add"
        Me.RipsWareImageButtonBase2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RipsWareImageButtonBase2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'RipsWareImageButtonBase1
        '
        Me.RipsWareImageButtonBase1.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.RipsWareImageButtonBase1.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.RipsWareImageButtonBase1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RipsWareImageButtonBase1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RipsWareImageButtonBase1.ForeColor = System.Drawing.Color.White
        Me.RipsWareImageButtonBase1.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.RipsWareImageButtonBase1.Image = Nothing
        Me.RipsWareImageButtonBase1.ImageKey = ""
        Me.RipsWareImageButtonBase1.ImageList = Nothing
        Me.RipsWareImageButtonBase1.Location = New System.Drawing.Point(106, 318)
        Me.RipsWareImageButtonBase1.Name = "RipsWareImageButtonBase1"
        Me.RipsWareImageButtonBase1.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.RipsWareImageButtonBase1.Size = New System.Drawing.Size(92, 28)
        Me.RipsWareImageButtonBase1.TabIndex = 42
        Me.RipsWareImageButtonBase1.Text = "&Update"
        Me.RipsWareImageButtonBase1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RipsWareImageButtonBase1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Location = New System.Drawing.Point(-16, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(981, 312)
        Me.Panel1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(961, 359)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "GP"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(-17, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(957, 317)
        Me.Panel2.TabIndex = 8
        '
        'TabPage3
        '
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(961, 359)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Tax"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.Controls.Add(Me.btnBrowse)
        Me.PanelD1.Controls.Add(Me.txtTextURL)
        Me.PanelD1.Controls.Add(Me.DateTimePicker1)
        Me.PanelD1.Controls.Add(Me.Button11)
        Me.PanelD1.Controls.Add(Me.Button10)
        Me.PanelD1.Controls.Add(Me.TextBox2)
        Me.PanelD1.Controls.Add(Me.Button9)
        Me.PanelD1.Controls.Add(Me.Button8)
        Me.PanelD1.Controls.Add(Me.WaterMarkTextBox5)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Location = New System.Drawing.Point(14, 76)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(969, 189)
        Me.PanelD1.TabIndex = 34
        '
        'btnBrowse
        '
        Me.btnBrowse.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnBrowse.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnBrowse.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnBrowse.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnBrowse.ForeColor = System.Drawing.Color.White
        Me.btnBrowse.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnBrowse.Image = Nothing
        Me.btnBrowse.ImageKey = ""
        Me.btnBrowse.ImageList = Nothing
        Me.btnBrowse.Location = New System.Drawing.Point(545, 126)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnBrowse.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnBrowse.Size = New System.Drawing.Size(75, 23)
        Me.btnBrowse.TabIndex = 43
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'txtTextURL
        '
        Me.txtTextURL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtTextURL.Location = New System.Drawing.Point(173, 126)
        Me.txtTextURL.Name = "txtTextURL"
        Me.txtTextURL.Size = New System.Drawing.Size(367, 20)
        Me.txtTextURL.TabIndex = 28
        Me.txtTextURL.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtTextURL.WaterMarkText = "Choose File Import"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(173, 7)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(213, 20)
        Me.DateTimePicker1.TabIndex = 27
        '
        'Button11
        '
        Me.Button11.Enabled = False
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(173, 33)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(29, 24)
        Me.Button11.TabIndex = 26
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.Control
        Me.Button10.Image = Global.GP_StandAlone_App.My.Resources.Resources.last
        Me.Button10.Location = New System.Drawing.Point(413, 33)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(29, 24)
        Me.Button10.TabIndex = 25
        Me.Button10.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(229, 36)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(159, 20)
        Me.TextBox2.TabIndex = 24
        '
        'Button9
        '
        Me.Button9.Image = Global.GP_StandAlone_App.My.Resources.Resources.next1
        Me.Button9.Location = New System.Drawing.Point(389, 33)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(24, 24)
        Me.Button9.TabIndex = 23
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Enabled = False
        Me.Button8.Image = Global.GP_StandAlone_App.My.Resources.Resources.previous11
        Me.Button8.Location = New System.Drawing.Point(202, 33)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(24, 24)
        Me.Button8.TabIndex = 22
        Me.Button8.UseVisualStyleBackColor = True
        '
        'WaterMarkTextBox5
        '
        Me.WaterMarkTextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.WaterMarkTextBox5.Location = New System.Drawing.Point(173, 64)
        Me.WaterMarkTextBox5.Multiline = True
        Me.WaterMarkTextBox5.Name = "WaterMarkTextBox5"
        Me.WaterMarkTextBox5.Size = New System.Drawing.Size(765, 56)
        Me.WaterMarkTextBox5.TabIndex = 20
        Me.WaterMarkTextBox5.WaterMarkColor = System.Drawing.Color.Gray
        Me.WaterMarkTextBox5.WaterMarkText = "Enter Description"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(11, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(87, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Description :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(11, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Withholding Tax Type :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(11, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Account Code :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(15, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(235, 15)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label4)
        Me.PanelH1.Location = New System.Drawing.Point(15, 32)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(968, 38)
        Me.PanelH1.TabIndex = 35
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(968, 38)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "ACCOUNTING MANUAL KEY IN"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FrmAccManualKeyIn
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(995, 710)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FrmAccManualKeyIn"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmAccManualKeyIn"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents WaterMarkTextBox5 As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents RipsWareImageButtonBase2 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents RipsWareImageButtonBase1 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnBrowse As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtTextURL As GP_StandAlone_App.WaterMarkTextBox
End Class
