Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration

Module ModDefination
    Public dsUser As DataSet
    Public gUserReport As String
    Public gUserLogin As String
    Public gUserFullName As String
    Public gUserGroupCode As String
    'Public gUserReport As String = ConfigurationManager.AppSettings("UserID_report").ToString
    'Public gPasswordReport As String = ConfigurationManager.AppSettings("Password_Report").ToString
    Public ValidationReportPath As String = ConfigurationManager.AppSettings("VALIDATION_REPORT_PATH").ToString

    Public psProjectCode As String = ConfigurationManager.AppSettings("PROJECTCODE").ToString
    Public CALLSCBATSPROG As String = ConfigurationManager.AppSettings("CALLSCBATSPROG").ToString
    Public CALLATSE2000PROG As String = ConfigurationManager.AppSettings("CALLATSE2000PROG").ToString
    Public CALLHASH As String = ConfigurationManager.AppSettings("CALLHASH").ToString

    '--Begin Adjust By Songpol 21/01/2015  
    '--Add call Function ATS  
    Public CALLOpenPRT As String = ConfigurationManager.AppSettings("CALLOpenPRT").ToString
    Public CALLClosePRT As String = ConfigurationManager.AppSettings("CALLClosePRT").ToString
    '--End Adjust By Songpol 21/01/2015 

    Public G_sReportPath As String '�� Path Report
    Public G_sUDLPath As String '�� UDL File
    Public G_sConnection As String  'Connectionstring ValiableVALIDATION_REPORT_PATH
    Public G_sUserCode As String 'Windows Authentication User Logon
    Public G_DsProject As New DataSet

    Public G_sUDLPath_Compen As String '�� UDL File
    Public G_sUDLPath_Corecompen As String '�� UDL File
    Public G_sUDLPath_ADUPS As String '�� UDL File


    Public retAccCode As String
    Public retAccName As String
    Public retCreateDate As String
    Public retCoreSystem As String
    Public retJnHold As String
    Public retTransRef As String
    Public retVCHNo As String
    Public retBatchNo As String
    Public retHR As Boolean
    Public retChkStart As Boolean
    Public retFileNameIL As String
    Public retPayNoIL As String
    'Public sReportPath As String = System.AppDomain.CurrentDomain.BaseDirectory().Replace("\bin\Debug\", ConfigurationManager.AppSettings("REPORT_PATH").ToString) ' System.AppDomain.CurrentDomain.BaseDirectory() & "Report\"
    Public sReportPath As String = System.AppDomain.CurrentDomain.BaseDirectory() & ConfigurationManager.AppSettings("REPORT_PATH").ToString ' System.AppDomain.CurrentDomain.BaseDirectory() & "Report\"
    Public gDSN_GPStandAlone As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToString

    '-- CAS Definition
    Public CAS_NamespaceProject As String = ConfigurationManager.AppSettings("NamespaceProject").ToString
    Public CAS_AppName As String = ConfigurationManager.AppSettings("AppName").ToString
    Public CAS_AppTitle As String = ConfigurationManager.AppSettings("AppTitle").ToString
    Public CAS_CASWS As String = ConfigurationManager.AppSettings("CASWS").ToString
    Public CAS_objSession As Object

    Public Structure lookupInfo
        Public pStrSearch As String
        Public pStrConnectionection As String
        Public pStrDataTable As String
        Public pStrSQLSelectedFields As String
        Public pStrWhereFields As String
        Public pStrOrderFields As String
    End Structure
    Public gLookup As lookupInfo

    'Question
    Public Const pStrQuestionSave As String = "Do you want to save? (Y/N)"
    Public Const pStrQuestionConfirm As String = "Do you want to confirm? (Y/N)"
    Public Const pStrQuestionUpdate As String = "Do you want to update? (Y/N)"
    Public Const pStrQuestionDelete As String = "Do you want to delete? (Y/N)"
    Public Const pStrQuestionExit As String = "Do you want to exit? (Y/N)"
    'Process Complete
    Public Const pStrCompleteSave As String = "Data already saved."
    Public Const pStrCompleteConfirm As String = "Data already confirmed."
    Public Const pStrCompleteUpdate As String = "Data already updated."
    Public Const pStrCompleteDelete As String = "Data already deleted."
    'Deny
    Public Const pStrDenySave As String = "Data cannot be saved."
    Public Const pStrDenyConfirm As String = "Data cannot be confirmed."
    Public Const pStrDenyDelete As String = "Data cannot be deleted."
    Public Const pStrDenyUpdate As String = "Data cannot be updated."
    'Warning
    Public Const pStrWarningCompletely As String = "Please input data completely and correctly."
    Public Const pStrWarningAlready As String = "Data already exist."
    Public Const pStrWarningNotFound As String = "Data not found."
    Public Const pStrWarningAccessMenu As String = "You are not allowed to access this menu." 'Or Unauthorized to access this menu. Or Access is denied. 'No.7

    '����������Ѻ���ҹ��� Path ��ҧ� 
    Public Sub GetFilePath()
        Try
            GetConfigXML()
            Dim dr As DataRow = G_DsProject.Tables(0).Rows.Find("FSOVSystem")
            G_sUDLPath_Compen = dr("udlPath_Compensation").ToString
            G_sUDLPath_Corecompen = dr("udlPath_Corecompensation").ToString
            G_sUDLPath_ADUPS = dr("udlPath_Adups").ToString

            G_sReportPath = dr("reportPath").ToString

        Catch ex As Exception
            'MessageBox.Show(ex.Message, frmBRNTAB.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Throw New ApplicationException(ex.Message)
        End Try
    End Sub


    Public Sub gClearTextBox(ByVal pFrm As Form)
        Dim myCtl As Control
        For Each myCtl In pFrm.Controls
            If TypeOf myCtl Is TextBox Then
                myCtl.Text = ""
            End If
        Next
    End Sub

    'program to read xmlfile2 format 
    Public Function GetConfigXML(ByVal strID As String) As DataRow
        Dim ds As New DataSet
        'Set reference in .NET option to system.configuration
        ds.ReadXml(ConfigurationManager.AppSettings("XMLPath").ToString)
        Dim dc As DataColumn = ds.Tables(0).Columns(0)
        ds.Tables(0).Constraints.Add("key1", dc, True)
        Dim dr As DataRow = ds.Tables(0).Rows.Find(strID)
        Return dr
    End Function

    Public Function GetConfigXML() As DataSet
        'Set reference in .NET option to system.configuration
        G_DsProject.ReadXml(ConfigurationManager.AppSettings("XMLPath").ToString)
        Dim dc As DataColumn = G_DsProject.Tables(0).Columns(0)
        G_DsProject.Tables(0).Constraints.Add("key1", dc, True)
        Return G_DsProject

    End Function

End Module
