Public Class FrmHashTotalProgram

    Private Sub FrmHashTotalProgram_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Process.Start("""" & CALLHASH & """")
        Catch ex As Exception
            Me.Close()
        End Try
        Me.Close()
    End Sub
End Class