Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmSumPaymentApproveReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub FrmRptSummaryAccounting_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListSection()
    End Sub
    Private Sub ListSection()
        Dim sb As New StringBuilder()

        sb.Append("SELECT A.DTS_MERGE_DEP, B.DEP_DEPNAME  ")
        sb.Append("FROM GPS_TL_DATASOURCE A LEFT JOIN GPS_TL_DEPARTMENT B ON A.DTS_MERGE_DEP=B.DEP_DEPCODE  ")
        sb.Append("WHERE A.DTS_CORE_SYSTEM='ACC' GROUP BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ORDER BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboSection
                .DataSource = dt
                .DisplayMember = "DEP_DEPNAME"
                .ValueMember = "DTS_MERGE_DEP"
            End With
        End If
        cboSection.SelectedIndex = 0
    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryAccounting.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataReport()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pHeader"
            discrete1.Value = "��§ҹ��ػ��è��»�Ш��ѹ (��ǹ�ѭ��)"
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = dtpApproveDate.Value.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmSumPaymentApproveReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub
    Function GetDataReport() As DataTable
        Dim sb As New StringBuilder()
        Dim txtdate As String = dtpApproveDate.Value.ToString("yyyyMMdd")

        sb.Append("select 'PAY' as maingroup,a.tref_createdate, a.tref_core_system, a.tref_transref, a.tref_paymth, a.tref_sub_paymth, a.tref_paiddate,a.tref_paycretyp_id, b.payt_paytype,  ")
        sb.Append("c.payg_pay_group, c.payg_pay_groupname, d.dts_merge_dep, e.dep_depname, a.tref_vch_no_c, f.gpcr_record, f.gpcr_amount, ")
        sb.Append(" nvl(g.taxcr_base_amt,0) as taxcr_base_amt , nvl(g.taxcr_tax_amt,0) as taxcr_tax_amt ")
        sb.Append("from gps_transref_rel a left join gps_tl_paytype b on a.tref_paymth=b.payt_paymth and ")
        sb.Append("a.tref_sub_paymth=b.payt_sub_paymth ")
        sb.Append("left join gps_tl_paygroup c on b.payt_pay_group=c.payg_pay_group ")
        sb.Append("left join (select dts_merge_dep, dts_dep_keyin ")
        sb.Append("from gps_tl_datasource    ")
        sb.Append("where dts_core_system='ACC' or dts_core_system='TLM' ")
        sb.Append("group by dts_merge_dep, dts_dep_keyin) d on a.tref_dep_keyin=d.dts_dep_keyin ")
        sb.Append("left join gps_tl_department e on d.dts_merge_dep=e.dep_depcode ")
        sb.Append("left join (select t.gpcr_createdate, t.gpcr_core_system, t.gpcr_transref, count(t.gpcr_gptref_seqno) as gpcr_record, sum(t.gpcr_amount) as gpcr_amount  ")
        sb.Append("from gps_payment_creation t ")
        sb.Append("where t.gpcr_approveddate='" & txtdate & "'   ")
        sb.Append("  and t.gpcr_flag_validate='COMPLETE'  ") '-- cancel all case
        sb.Append("group by t.gpcr_createdate, t.gpcr_core_system, t.gpcr_transref) f on a.tref_createdate=f.gpcr_createdate and ")
        sb.Append("a.tref_core_system=f.gpcr_core_system and ")
        sb.Append("a.tref_transref=f.gpcr_transref ")
        sb.Append("left join (select t.taxcr_createdate, t.taxcr_core_system, t.taxcr_transref, sum(t.taxcr_base_amt) as taxcr_base_amt, sum(t.taxcr_tax_amt) as taxcr_tax_amt  ")
        sb.Append("from gps_wht_creation t ")
        sb.Append("where t.taxcr_approveddate='" & txtdate & "'  ")
        sb.Append("  and t.taxcr_flag_validate='COMPLETE'  ") '-- cancel all case
        sb.Append("group by t.taxcr_createdate, t.taxcr_core_system, t.taxcr_transref) g on a.tref_createdate=g.taxcr_createdate and ")
        sb.Append("a.tref_core_system=g.taxcr_core_system and ")
        sb.Append("a.tref_transref=g.taxcr_transref ")
        sb.Append("where a.tref_paycretyp_id<>'006' and a.tref_paycretyp_id<>'003' and a.tref_approveddate='" & txtdate & "'  and d.dts_merge_dep='" & cboSection.SelectedValue.ToString & "' ")
        sb.Append("   and not f.gpcr_record is null ") '-- cancel all case
        sb.Append("   and not f.gpcr_amount is null ") '-- cancel all case
        sb.Append("union ")
        sb.Append("select 'ZNONPAY' as maingroup,A.tref_createdate, A.tref_core_system, A.tref_transref, A.tref_paymth, A.tref_sub_paymth, A.Tref_Paiddate,A.tref_paycretyp_id, B.Payt_Paytype,  ")
        sb.Append("C.PAYG_PAY_GROUP,'ZNon pay' as PAYG_PAY_GROUPNAME, D.DTS_MERGE_DEP, E.Dep_Depname, A.Tref_Vch_No_c, G.gpcr_record, (G.taxcr_base_amt-G.taxcr_tax_amt) As gpcr_amount, ")
        sb.Append("G.taxcr_base_amt, G.taxcr_tax_amt ")
        sb.Append("from GPS_TRANSREF_REL A LEFT JOIN GPS_TL_PAYTYPE B ON A.tref_paymth=B.PAYT_PAYMTH AND ")
        sb.Append("A.tref_sub_paymth=B.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN (select dts_merge_dep, dts_dep_keyin ")
        sb.Append("from GPS_TL_DATASOURCE    ")
        sb.Append("where dts_core_system='ACC' Or dts_core_system='TLM' ")
        sb.Append("group by dts_merge_dep, dts_dep_keyin) D ON A.TREF_DEP_KEYIN=D.dts_dep_keyin ")
        sb.Append("LEFT JOIN GPS_TL_DEPARTMENT E ON D.DTS_MERGE_DEP=E.DEP_DEPCODE ")
        sb.Append("LEFT JOIN (select t.taxcr_createdate, t.taxcr_core_system, t.taxcr_transref, count(t.taxcr_lineno) As gpcr_record, sum(t.taxcr_base_amt) As taxcr_base_amt, sum(t.taxcr_tax_amt) As taxcr_tax_amt  ")
        sb.Append("from GPS_WHT_CREATION t ")
        sb.Append("where t.taxcr_APPROVEDDATE='" & txtdate & "'   ")
        sb.Append("  and t.taxcr_flag_validate='COMPLETE'  ") '-- cancel all case
        sb.Append("group by t.taxcr_createdate, t.taxcr_core_system, t.taxcr_transref) G ON A.tref_createdate=G.taxcr_createdate AND ")
        sb.Append("A.tref_core_system=G.taxcr_core_system AND ")
        sb.Append("A.tref_transref=G.taxcr_transref ")
        sb.Append("where A.tref_paycretyp_id='006' And A.Tref_APPROVEDDATE='" & txtdate & "'  And D.DTS_MERGE_DEP='" & cboSection.SelectedValue.ToString & "' ")
        sb.Append("   and not g.gpcr_record is null ") '-- cancel all case
        sb.Append("   and not g.taxcr_tax_amt is null ") '-- cancel all case
        sb.Append(" order by maingroup,payg_pay_groupname,tref_paymth,tref_sub_paymth, tref_paiddate,tref_transref")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click

        PrintReport()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class