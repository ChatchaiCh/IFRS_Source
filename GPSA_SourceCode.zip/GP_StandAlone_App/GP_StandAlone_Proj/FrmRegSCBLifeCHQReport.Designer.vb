<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRegSCBLifeCHQReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPrintDateTo = New System.Windows.Forms.TextBox()
        Me.txtPrintDateFrom = New System.Windows.Forms.TextBox()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.txtChqNoTo = New System.Windows.Forms.TextBox()
        Me.txtChqNoFrom = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBatchNo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmdPreview = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(245, 84)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(20, 13)
        Me.Label5.TabIndex = 67
        Me.Label5.Text = "To"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(245, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 13)
        Me.Label4.TabIndex = 66
        Me.Label4.Text = "To"
        '
        'txtPrintDateTo
        '
        Me.txtPrintDateTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPrintDateTo.Location = New System.Drawing.Point(274, 79)
        Me.txtPrintDateTo.MaxLength = 10
        Me.txtPrintDateTo.Name = "txtPrintDateTo"
        Me.txtPrintDateTo.Size = New System.Drawing.Size(108, 20)
        Me.txtPrintDateTo.TabIndex = 65
        '
        'txtPrintDateFrom
        '
        Me.txtPrintDateFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPrintDateFrom.Location = New System.Drawing.Point(129, 79)
        Me.txtPrintDateFrom.MaxLength = 10
        Me.txtPrintDateFrom.Name = "txtPrintDateFrom"
        Me.txtPrintDateFrom.Size = New System.Drawing.Size(108, 20)
        Me.txtPrintDateFrom.TabIndex = 64
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(418, 38)
        Me.PanelH1.TabIndex = 48
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(136, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(155, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "��§ҹ����¹�������"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "�ѹ������� From"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.txtChqNoTo)
        Me.PanelD1.Controls.Add(Me.txtChqNoFrom)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.txtBatchNo)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.Label4)
        Me.PanelD1.Controls.Add(Me.txtPrintDateTo)
        Me.PanelD1.Controls.Add(Me.txtPrintDateFrom)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(418, 136)
        Me.PanelD1.TabIndex = 49
        '
        'txtChqNoTo
        '
        Me.txtChqNoTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtChqNoTo.Location = New System.Drawing.Point(274, 47)
        Me.txtChqNoTo.MaxLength = 10
        Me.txtChqNoTo.Name = "txtChqNoTo"
        Me.txtChqNoTo.Size = New System.Drawing.Size(108, 20)
        Me.txtChqNoTo.TabIndex = 71
        '
        'txtChqNoFrom
        '
        Me.txtChqNoFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtChqNoFrom.Location = New System.Drawing.Point(129, 47)
        Me.txtChqNoFrom.MaxLength = 60000
        Me.txtChqNoFrom.Name = "txtChqNoFrom"
        Me.txtChqNoFrom.Size = New System.Drawing.Size(108, 20)
        Me.txtChqNoFrom.TabIndex = 70
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "Batch No"
        '
        'txtBatchNo
        '
        Me.txtBatchNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBatchNo.Location = New System.Drawing.Point(129, 14)
        Me.txtBatchNo.MaxLength = 15
        Me.txtBatchNo.Name = "txtBatchNo"
        Me.txtBatchNo.Size = New System.Drawing.Size(253, 20)
        Me.txtBatchNo.TabIndex = 68
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cheque No From"
        '
        'CmdPreview
        '
        Me.CmdPreview.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdPreview.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.CmdPreview.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdPreview.ForeColor = System.Drawing.Color.White
        Me.CmdPreview.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdPreview.Image = Nothing
        Me.CmdPreview.ImageKey = ""
        Me.CmdPreview.ImageList = Nothing
        Me.CmdPreview.Location = New System.Drawing.Point(235, 199)
        Me.CmdPreview.Name = "CmdPreview"
        Me.CmdPreview.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.Size = New System.Drawing.Size(95, 28)
        Me.CmdPreview.TabIndex = 110
        Me.CmdPreview.Text = "Print"
        Me.CmdPreview.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdPreview.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(336, 199)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(95, 28)
        Me.btnExit.TabIndex = 111
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmRegSCBLifeCHQReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(443, 239)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.CmdPreview)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Name = "FrmRegSCBLifeCHQReport"
        Me.Text = "��§ҹ����¹�������"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPrintDateTo As System.Windows.Forms.TextBox
    Friend WithEvents txtPrintDateFrom As System.Windows.Forms.TextBox
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtBatchNo As System.Windows.Forms.TextBox
    Friend WithEvents txtChqNoTo As System.Windows.Forms.TextBox
    Friend WithEvents txtChqNoFrom As System.Windows.Forms.TextBox
    Friend WithEvents CmdPreview As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
