<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMainMenu))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSLogOut = New System.Windows.Forms.ToolStripMenuItem()
        Me.TS1DateTime = New System.Windows.Forms.ToolStripMenuItem()
        Me.TS1User = New System.Windows.Forms.ToolStripMenuItem()
        Me.TS1Machine = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.tre1 = New System.Windows.Forms.TreeView()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel7 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.DirectorySearcher1 = New System.DirectoryServices.DirectorySearcher()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.MenuStrip1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EXITToolStripMenuItem, Me.TSLogOut, Me.TS1DateTime, Me.TS1User, Me.TS1Machine})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1008, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.EXITToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.EXITToolStripMenuItem.Text = "Hide Menu"
        Me.EXITToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TSLogOut
        '
        Me.TSLogOut.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TSLogOut.ForeColor = System.Drawing.Color.White
        Me.TSLogOut.Name = "TSLogOut"
        Me.TSLogOut.Size = New System.Drawing.Size(54, 20)
        Me.TSLogOut.Text = "LogOut"
        '
        'TS1DateTime
        '
        Me.TS1DateTime.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TS1DateTime.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TS1DateTime.ForeColor = System.Drawing.Color.White
        Me.TS1DateTime.Image = CType(resources.GetObject("TS1DateTime.Image"), System.Drawing.Image)
        Me.TS1DateTime.Name = "TS1DateTime"
        Me.TS1DateTime.Size = New System.Drawing.Size(131, 20)
        Me.TS1DateTime.Text = "ToolStripMenuItem1"
        '
        'TS1User
        '
        Me.TS1User.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TS1User.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TS1User.ForeColor = System.Drawing.Color.White
        Me.TS1User.Image = CType(resources.GetObject("TS1User.Image"), System.Drawing.Image)
        Me.TS1User.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TS1User.Name = "TS1User"
        Me.TS1User.Size = New System.Drawing.Size(131, 20)
        Me.TS1User.Text = "ToolStripMenuItem1"
        '
        'TS1Machine
        '
        Me.TS1Machine.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TS1Machine.ForeColor = System.Drawing.Color.White
        Me.TS1Machine.Image = CType(resources.GetObject("TS1Machine.Image"), System.Drawing.Image)
        Me.TS1Machine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.TS1Machine.Name = "TS1Machine"
        Me.TS1Machine.Size = New System.Drawing.Size(130, 20)
        Me.TS1Machine.Text = "ToolStripMenuItem1"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "02Final.ico")
        Me.ImageList1.Images.SetKeyName(1, "02Work.ico")
        Me.ImageList1.Images.SetKeyName(2, "01Finalyello.ico")
        Me.ImageList1.Images.SetKeyName(3, "01WorkYello.ico")
        Me.ImageList1.Images.SetKeyName(4, "01Verify.ico")
        Me.ImageList1.Images.SetKeyName(5, "01Report.ico")
        Me.ImageList1.Images.SetKeyName(6, "run_green32.ico")
        Me.ImageList1.Images.SetKeyName(7, "home.png")
        Me.ImageList1.Images.SetKeyName(8, "folder.png")
        Me.ImageList1.Images.SetKeyName(9, "folder-document.png")
        Me.ImageList1.Images.SetKeyName(10, "printer.png")
        Me.ImageList1.Images.SetKeyName(11, "paper-box.png")
        Me.ImageList1.Images.SetKeyName(12, "office-building.png")
        Me.ImageList1.Images.SetKeyName(13, "Folders-Generic-Purple-Folder.ico")
        Me.ImageList1.Images.SetKeyName(14, "Labeled purple 2.ico")
        Me.ImageList1.Images.SetKeyName(15, "purple.ico")
        Me.ImageList1.Images.SetKeyName(16, "folder-3-24.ico")
        Me.ImageList1.Images.SetKeyName(17, "folder-2-24.ico")
        Me.ImageList1.Images.SetKeyName(18, "full-folder-24.ico")
        Me.ImageList1.Images.SetKeyName(19, "text-file-4-24.ico")
        Me.ImageList1.Images.SetKeyName(20, "document-24.ico")
        Me.ImageList1.Images.SetKeyName(21, "home-5-24.ico")
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.tre1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.AutoScroll = True
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer1.Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SplitContainer1.Size = New System.Drawing.Size(1008, 703)
        Me.SplitContainer1.SplitterDistance = 250
        Me.SplitContainer1.TabIndex = 8
        '
        'tre1
        '
        Me.tre1.BackColor = System.Drawing.SystemColors.Control
        Me.tre1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tre1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.tre1.ForeColor = System.Drawing.Color.Black
        Me.tre1.ImageIndex = 0
        Me.tre1.ImageList = Me.ImageList1
        Me.tre1.Location = New System.Drawing.Point(0, 0)
        Me.tre1.Name = "tre1"
        Me.tre1.SelectedImageIndex = 0
        Me.tre1.Size = New System.Drawing.Size(250, 703)
        Me.tre1.TabIndex = 7
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.LightBlue
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel6, Me.ToolStripStatusLabel7})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 727)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1008, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(89, 17)
        Me.ToolStripStatusLabel1.Text = "GP Stand Alone"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(71, 17)
        Me.ToolStripStatusLabel2.Text = "User Name :"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(120, 17)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(70, 17)
        Me.ToolStripStatusLabel4.Text = "Login Date :"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(120, 17)
        Me.ToolStripStatusLabel5.Text = "ToolStripStatusLabel5"
        '
        'ToolStripStatusLabel6
        '
        Me.ToolStripStatusLabel6.Name = "ToolStripStatusLabel6"
        Me.ToolStripStatusLabel6.Size = New System.Drawing.Size(73, 17)
        Me.ToolStripStatusLabel6.Text = "Login Time :"
        '
        'ToolStripStatusLabel7
        '
        Me.ToolStripStatusLabel7.Name = "ToolStripStatusLabel7"
        Me.ToolStripStatusLabel7.Size = New System.Drawing.Size(120, 17)
        Me.ToolStripStatusLabel7.Text = "ToolStripStatusLabel7"
        '
        'DirectorySearcher1
        '
        Me.DirectorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01")
        Me.DirectorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01")
        Me.DirectorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01")
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(342, 2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(202, 20)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Visible = False
        '
        'FrmMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 749)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmMainMenu"
        Me.Text = "Special Pay In : Application Mapping"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents tre1 As System.Windows.Forms.TreeView
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel6 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel7 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TS1User As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TS1DateTime As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TS1Machine As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DirectorySearcher1 As System.DirectoryServices.DirectorySearcher
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TSLogOut As System.Windows.Forms.ToolStripMenuItem
End Class
