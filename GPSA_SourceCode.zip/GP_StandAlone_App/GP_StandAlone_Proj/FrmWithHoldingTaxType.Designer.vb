<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmWithHoldingTaxType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboWHTTaxType = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.txtDesc = New GP_StandAlone_App.WaterMarkTextBox()
        Me.txtAccCode = New GP_StandAlone_App.WaterMarkTextBox()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnAdd = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnUpdate = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnDelete = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboWHTTaxType
        '
        Me.cboWHTTaxType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboWHTTaxType.FormattingEnabled = True
        Me.cboWHTTaxType.Location = New System.Drawing.Point(171, 35)
        Me.cboWHTTaxType.Name = "cboWHTTaxType"
        Me.cboWHTTaxType.Size = New System.Drawing.Size(225, 21)
        Me.cboWHTTaxType.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(10, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(303, 17)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(10, 217)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(724, 312)
        Me.DataGridView1.TabIndex = 35
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(32, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Description :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(32, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Withholding Tax Type :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(32, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Account Code :"
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(724, 38)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "WITHHOLDING TAX TYPE"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label4)
        Me.PanelH1.Location = New System.Drawing.Point(10, 31)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(724, 38)
        Me.PanelH1.TabIndex = 32
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.Controls.Add(Me.cboWHTTaxType)
        Me.PanelD1.Controls.Add(Me.txtDesc)
        Me.PanelD1.Controls.Add(Me.txtAccCode)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Location = New System.Drawing.Point(10, 75)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(724, 136)
        Me.PanelD1.TabIndex = 33
        '
        'txtDesc
        '
        Me.txtDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtDesc.Location = New System.Drawing.Point(171, 64)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(481, 56)
        Me.txtDesc.TabIndex = 20
        Me.txtDesc.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtDesc.WaterMarkText = "Enter Description"
        '
        'txtAccCode
        '
        Me.txtAccCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtAccCode.Location = New System.Drawing.Point(171, 8)
        Me.txtAccCode.Name = "txtAccCode"
        Me.txtAccCode.Size = New System.Drawing.Size(225, 20)
        Me.txtAccCode.TabIndex = 17
        Me.txtAccCode.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtAccCode.WaterMarkText = "Enter Accont Code"
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(304, 535)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 39
        Me.btnClear.Text = "&Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(402, 535)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClose.Size = New System.Drawing.Size(92, 28)
        Me.btnClose.TabIndex = 40
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnAdd
        '
        Me.btnAdd.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnAdd.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAdd.Enabled = False
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.White
        Me.btnAdd.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnAdd.Image = Nothing
        Me.btnAdd.ImageKey = ""
        Me.btnAdd.ImageList = Nothing
        Me.btnAdd.Location = New System.Drawing.Point(10, 535)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnAdd.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnAdd.Size = New System.Drawing.Size(92, 28)
        Me.btnAdd.TabIndex = 36
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnUpdate
        '
        Me.btnUpdate.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnUpdate.Image = Nothing
        Me.btnUpdate.ImageKey = ""
        Me.btnUpdate.ImageList = Nothing
        Me.btnUpdate.Location = New System.Drawing.Point(108, 535)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnUpdate.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnUpdate.Size = New System.Drawing.Size(92, 28)
        Me.btnUpdate.TabIndex = 37
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnDelete
        '
        Me.btnDelete.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnDelete.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnDelete.Image = Nothing
        Me.btnDelete.ImageKey = ""
        Me.btnDelete.ImageList = Nothing
        Me.btnDelete.Location = New System.Drawing.Point(206, 535)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnDelete.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnDelete.Size = New System.Drawing.Size(92, 28)
        Me.btnDelete.TabIndex = 38
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmWithHoldingTaxType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(745, 575)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Name = "FrmWithHoldingTaxType"
        Me.Text = "FrmWithHoldingTaxType"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelH1.ResumeLayout(False)
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents cboWHTTaxType As System.Windows.Forms.ComboBox
    Friend WithEvents btnAdd As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnUpdate As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtDesc As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents btnDelete As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents txtAccCode As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
End Class
