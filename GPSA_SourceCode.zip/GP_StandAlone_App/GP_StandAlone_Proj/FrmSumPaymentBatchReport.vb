Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmSumPaymentBatchReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim lstType As New List(Of AddListType)
    Public Class AddListType
        Public TypeName As String
        Public TypeID As String
        Sub New(ByVal TypeName As String, ByVal TypeID As String)
            Me.TypeName = TypeName
            Me.TypeID = TypeID
        End Sub
        Public Overrides Function ToString() As String
            Return Me.TypeName
        End Function
    End Class
    Private Sub FrmRptSummaryAccounting_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListType()
        ListStatus()

        dtpBatchDate.Value = Now.ToString("dd/MM/yyyy")
    End Sub
  
    Private Sub ListType()
        lstType.Add(New AddListType("����", "A"))
        lstType.Add(New AddListType("��觴�ǹ", "M"))

        cboType.DataSource = lstType
        cboType.SelectedIndex = 0
    End Sub
    Private Sub ListStatus()
        cboStatus.Items.Add("All")
        cboStatus.Items.Add("Complete")
        cboStatus.Items.Add("Incomplete")
        cboStatus.SelectedIndex = 0
    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryBatch.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataReport()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pHeader"
            If cboType.Text = "����" Then
                discrete1.Value = "��§ҹ Summary ��¡�è��»Դ Batch"
            Else
                discrete1.Value = "��§ҹ Summary ��¡�è��»Դ Batch (��ǹ�ѭ��) - Case ��觴�ǹ"
            End If

            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = dtpBatchDate.Value.ToString("dd/MM/yyyy") 'Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)


            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmSumPaymentBatchReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub

    Function fnStrComplete_org(ByVal batchdate As String, ByVal status As String) As StringBuilder
        Dim sb As New StringBuilder()
        Dim item As AddListType = TryCast(cboType.SelectedItem, AddListType)


        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (����� non Pay) -Complete
        sb.Append("select 'Complete' As BatchStatus,'PAY' as maingroup, A.gpcm_batchdate As batch_date, A.gpcm_batch_no As batch_no, A.gpcm_core_system As core_system, A.gpcm_paymth AS paymth, A.gpcm_sub_paymth As sub_paymth,  ")
        sb.Append(" A.gpcm_paymth||A.gpcm_sub_paymth||B.Payt_Paytype as Payt_Paytype, ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt , NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.GPCM_AMOUNT) AS Net_AMOUNT, Count(A.gpcm_batchdate) As No_Record ")
        sb.Append("from GPS_PAYMENT_COMPLETE A LEFT JOIN GPS_TL_PAYTYPE B ON A.gpcm_paymth=B.PAYT_PAYMTH AND ")
        sb.Append("A.gpcm_sub_paymth=B.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gpcm_core_system=D.CSYS_CORE_SYSTEM ")
        sb.Append("LEFT JOIN (select t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH, ")
        sb.Append("sum(t.taxcm_base_amt) As taxcm_base_amt, sum(t.taxcm_tax_amt) As taxcm_tax_amt  ")
        sb.Append("from GPS_WHT_COMPLETE t left join GPS_TRANSREF_REL u ON t.taxcm_createdate=u.tref_CREATEDATE AND ")
        sb.Append("t.taxcm_core_system=u.tref_core_system AND ")
        sb.Append("t.taxcm_transref=u.tref_transref ")
        sb.Append("where t.TAXCM_BATCHDATE='" & batchdate & "'  ")
        sb.Append("group by t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G  ")
        sb.Append("ON A.gpcm_batchdate=G.TAXCM_BATCHDATE AND ")
        sb.Append("A.gpcm_batch_no=G.TAXCM_BATCH_NO AND ")
        sb.Append("A.gpcm_core_system=G.TAXCM_CORE_SYSTEM AND  ")
        sb.Append("A.gpcm_paymth=G.TREF_PAYMTH AND ")
        sb.Append("A.gpcm_sub_paymth=G.TREF_SUB_PAYMTH ")
        sb.Append("where A.gpcm_batchdate='" & batchdate & "' And A.gpcm_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("and A.gpcm_batchtype='" & item.TypeID & "' ")

        sb.Append("Group by A.gpcm_batchdate, A.gpcm_batch_no, A.gpcm_core_system, A.gpcm_paymth, A.gpcm_sub_paymth, B.Payt_Paytype,  ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("union ")

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (non Pay) -Complete
        sb.Append("select 'Complete' As BatchStatus,'ZNONPAY' as maingroup, A.TAXCM_BATCHDATE As batch_date, A.TAXCM_BATCH_NO As batch_no, A.TAXCM_CORE_SYSTEM As core_system, ' ' As paymth, ' ' As sub_paymth, 'ZZNon Pay' As Payt_Paytype,  ")
        sb.Append("'ZNon Pay' As PAYG_PAY_GROUP, 'ZNon Pay' As PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, SUM(A.taxcm_base_amt) As taxcm_base_amt, SUM(A.taxcm_tax_amt) AS taxcm_tax_amt,  ")
        'sb.Append(", 0 AS Net_AMOUNT,0 As No_Record ")
        sb.Append("SUM(A.taxcm_base_amt)-SUM(A.taxcm_tax_amt)  AS Net_AMOUNT,Count(A.taxcm_batchdate) As No_Record ")
        sb.Append("from GPS_WHT_COMPLETE A LEFT JOIN GPS_TRANSREF_REL U ON A.taxcm_createdate=U.tref_CREATEDATE AND ")
        sb.Append("A.taxcm_core_system=U.tref_core_system AND ")
        sb.Append("A.taxcm_transref=U.tref_transref AND   ")
        sb.Append("A.TAXCM_BATCHDATE=U.tref_BATCHDATE ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.TAXCM_CORE_SYSTEM=D.CSYS_CORE_SYSTEM ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.TAXCM_BATCH_NO=H.TRAN_BATCH_ID ")
        'sb.Append("where A.TAXCM_BATCHDATE='" & batchdate & "' And U.TREF_PAYCRETYP_ID='006' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where A.TAXCM_BATCHDATE='" & batchdate & "' And U.TREF_PAYCRETYP_ID='006'  And A.TAXCM_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.TAXCM_BATCHDATE, A.TAXCM_BATCH_NO, A.TAXCM_CORE_SYSTEM, D.CSYS_CORE_SYSTEMNAME ")

        Return sb

    End Function
    Function fnStrInComplete_org(ByVal batchdate As String, ByVal status As String) As StringBuilder
        Dim sb As New StringBuilder()
        Dim item As AddListType = TryCast(cboType.SelectedItem, AddListType)

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (����� non Pay) -InComplete ")
        sb.Append("select 'InComplete' As BatchStatus,'PAY' as maingroup, A.gprj_batchdate As batch_date, A.gprj_batch_no As batch_no, A.gprj_core_system As core_system, A.gprj_paymth AS paymth, A.gprj_sub_paymth As sub_paymth ,  ")
        sb.Append(" A.gprj_paymth||A.gprj_sub_paymth||B.Payt_Paytype as Payt_Paytype, ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt, NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.gprj_AMOUNT) AS Net_AMOUNT, Count(A.gprj_batchdate) As No_Record ")
        sb.Append("from GPS_PAYMENT_REJ A LEFT JOIN GPS_TL_PAYTYPE B ON A.gprj_paymth=B.PAYT_PAYMTH AND ")
        sb.Append("A.gprj_sub_paymth=B.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gprj_core_system=D.CSYS_CORE_SYSTEM ")
        sb.Append("LEFT JOIN (select t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH, ")
        sb.Append("sum(t.taxrj_base_amt) As taxcm_base_amt, sum(t.taxrj_tax_amt) As taxcm_tax_amt  ")
        sb.Append("from GPS_WHT_REJ t left join GPS_TRANSREF_REL u ON t.taxrj_createdate=u.tref_CREATEDATE AND ")
        sb.Append("t.taxrj_core_system=u.tref_core_system AND ")
        sb.Append("t.taxrj_transref=u.tref_transref                           ")
        sb.Append("where t.TAXRJ_BATCHDATE='" & batchdate & "'  ")
        sb.Append("group by t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G  ")
        sb.Append("ON A.gprj_batchdate=G.TAXRJ_BATCHDATE AND ")
        sb.Append("A.gprj_batch_no=G.TAXRJ_BATCH_NO AND ")
        sb.Append("A.gprj_core_system=G.TAXRJ_CORE_SYSTEM AND  ")
        sb.Append("A.gprj_paymth=G.TREF_PAYMTH AND ")
        sb.Append("A.gprj_sub_paymth=G.TREF_SUB_PAYMTH  ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.gprj_batch_no=H.TRAN_BATCH_ID ")
        'sb.Append("where A.gprj_batchdate='" & batchdate & "' And A.gprj_reject_type <>'BANK' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where A.gprj_batchdate='" & batchdate & "' And  A.gprj_reject_type <>'BANK' And  A.gprj_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.gprj_batchdate, A.gprj_batch_no, A.gprj_core_system, A.gprj_paymth, A.gprj_sub_paymth, B.Payt_Paytype,  ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("union ")

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (non Pay) -InComplete ")
        sb.Append("select 'InComplete' As BatchStatus,'ZNONPAY' as maingroup, A.taxrj_BATCHDATE As batch_date, A.taxrj_BATCH_NO As batch_no, A.taxrj_CORE_SYSTEM As core_system, ' ' As paymth, ' ' As sub_paymth, 'ZZNon Pay' As Payt_Paytype,  ")
        sb.Append("'ZNon Pay' As PAYG_PAY_GROUP, 'ZNon Pay' As PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, SUM(A.taxrj_base_amt) As taxcm_base_amt, SUM(A.taxrj_tax_amt) AS taxcm_tax_amt, ")
        'sb.Append(", 0 AS Net_AMOUNT,0 As No_Record ")
        sb.Append("SUM(A.taxrj_base_amt)-SUM(A.taxrj_tax_amt)  AS Net_AMOUNT,Count(A.taxrj_batchdate) As No_Record ")
        sb.Append("from GPS_WHT_REJ A LEFT JOIN GPS_TRANSREF_REL U ON A.taxrj_createdate=U.tref_CREATEDATE AND ")
        sb.Append("A.taxrj_core_system=U.tref_core_system AND ")
        sb.Append("A.taxrj_transref=U.tref_transref AND   ")
        sb.Append("A.taxrj_BATCHDATE=U.tref_BATCHDATE ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.taxrj_CORE_SYSTEM=D.CSYS_CORE_SYSTEM ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.taxrj_BATCH_NO=H.TRAN_BATCH_ID ")
        'sb.Append("where A.taxrj_BATCHDATE='" & batchdate & "' And A.taxrj_reject_type <>'BANK' And U.TREF_PAYCRETYP_ID='006' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where  A.taxrj_BATCHDATE='" & batchdate & "' And A.taxrj_reject_type <>'BANK' And U.TREF_PAYCRETYP_ID='006' And A.taxrj_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.taxrj_BATCHDATE, A.taxrj_BATCH_NO, A.taxrj_CORE_SYSTEM, D.CSYS_CORE_SYSTEMNAME ")


        Return sb
    End Function
    Function fnStrComplete(ByVal batchdate As String, ByVal status As String) As StringBuilder
        Dim sb As New StringBuilder()
        Dim item As AddListType = TryCast(cboType.SelectedItem, AddListType)


        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (����� non Pay) -Complete
        sb.Append("select 'Complete' As BatchStatus,'PAY' as maingroup, A.gpcm_batchdate As batch_date, A.gpcm_batch_no As batch_no, A.gpcm_core_system As core_system, A.gpcm_paymth AS paymth, A.gpcm_sub_paymth As sub_paymth,  ")
        sb.Append(" A.gpcm_paymth||A.gpcm_sub_paymth||B.Payt_Paytype as Payt_Paytype, ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt , NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.GPCM_AMOUNT) AS Net_AMOUNT, Count(A.gpcm_batchdate) As No_Record ")
        sb.Append("from GPS_PAYMENT_COMPLETE A LEFT JOIN GPS_TL_PAYTYPE B ON A.gpcm_paymth=B.PAYT_PAYMTH AND ")
        sb.Append("A.gpcm_sub_paymth=B.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gpcm_core_system=D.CSYS_CORE_SYSTEM ")
        sb.Append("LEFT JOIN (select t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH, ")
        sb.Append("sum(t.taxcm_base_amt) As taxcm_base_amt, sum(t.taxcm_tax_amt) As taxcm_tax_amt  ")
        sb.Append("from GPS_WHT_COMPLETE t left join GPS_TRANSREF_REL u ON t.taxcm_createdate=u.tref_CREATEDATE AND ")
        sb.Append("t.taxcm_core_system=u.tref_core_system AND ")
        sb.Append("t.taxcm_transref=u.tref_transref ")
        sb.Append("where t.TAXCM_BATCHDATE='" & batchdate & "'  ")

        If cboType.Text = "����" Then
            sb.Append(" and nvl(u.tref_paycretyp_id,'000') <> '003' ")
        Else
            sb.Append(" and nvl(u.tref_paycretyp_id,'000') = '003' ")
        End If

        sb.Append("group by t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G  ")
        sb.Append("ON A.gpcm_batchdate=G.TAXCM_BATCHDATE AND ")
        sb.Append("A.gpcm_batch_no=G.TAXCM_BATCH_NO AND ")
        sb.Append("A.gpcm_core_system=G.TAXCM_CORE_SYSTEM AND  ")
        sb.Append("A.gpcm_paymth=G.TREF_PAYMTH AND ")
        sb.Append("A.gpcm_sub_paymth=G.TREF_SUB_PAYMTH ")
        sb.Append("where A.gpcm_batchdate='" & batchdate & "' And A.gpcm_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("and A.gpcm_batchtype='" & item.TypeID & "' ")

        sb.Append("Group by A.gpcm_batchdate, A.gpcm_batch_no, A.gpcm_core_system, A.gpcm_paymth, A.gpcm_sub_paymth, B.Payt_Paytype,  ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("union ")

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (non Pay) -Complete
        sb.Append("select 'Complete' As BatchStatus,'ZNONPAY' as maingroup, A.TAXCM_BATCHDATE As batch_date, A.TAXCM_BATCH_NO As batch_no, A.TAXCM_CORE_SYSTEM As core_system, ' ' As paymth, ' ' As sub_paymth, 'ZZNon Pay' As Payt_Paytype,  ")
        sb.Append("'ZNon Pay' As PAYG_PAY_GROUP, 'ZNon Pay' As PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, SUM(A.taxcm_base_amt) As taxcm_base_amt, SUM(A.taxcm_tax_amt) AS taxcm_tax_amt,  ")
        'sb.Append(", 0 AS Net_AMOUNT,0 As No_Record ")
        sb.Append("SUM(A.taxcm_base_amt)-SUM(A.taxcm_tax_amt)  AS Net_AMOUNT,Count(A.taxcm_batchdate) As No_Record ")
        sb.Append("from GPS_WHT_COMPLETE A LEFT JOIN GPS_TRANSREF_REL U ON A.taxcm_createdate=U.tref_CREATEDATE AND ")
        sb.Append("A.taxcm_core_system=U.tref_core_system AND ")
        sb.Append("A.taxcm_transref=U.tref_transref AND   ")
        sb.Append("A.TAXCM_BATCHDATE=U.tref_BATCHDATE ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.TAXCM_CORE_SYSTEM=D.CSYS_CORE_SYSTEM ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.TAXCM_BATCH_NO=H.TRAN_BATCH_ID ")
        'sb.Append("where A.TAXCM_BATCHDATE='" & batchdate & "' And U.TREF_PAYCRETYP_ID='006' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where A.TAXCM_BATCHDATE='" & batchdate & "' And U.TREF_PAYCRETYP_ID='006'  And A.TAXCM_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.TAXCM_BATCHDATE, A.TAXCM_BATCH_NO, A.TAXCM_CORE_SYSTEM, D.CSYS_CORE_SYSTEMNAME ")

        Return sb

    End Function
    Function fnStrInComplete(ByVal batchdate As String, ByVal status As String) As StringBuilder
        Dim sb As New StringBuilder()
        Dim item As AddListType = TryCast(cboType.SelectedItem, AddListType)

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (����� non Pay) -InComplete ")
        sb.Append("select 'InComplete' As BatchStatus,'PAY' as maingroup, A.gprj_batchdate As batch_date, A.gprj_batch_no As batch_no, A.gprj_core_system As core_system, A.gprj_paymth AS paymth, A.gprj_sub_paymth As sub_paymth ,  ")
        sb.Append(" A.gprj_paymth||A.gprj_sub_paymth||B.Payt_Paytype as Payt_Paytype, ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt, NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.gprj_AMOUNT) AS Net_AMOUNT, Count(A.gprj_batchdate) As No_Record ")
        sb.Append("from GPS_PAYMENT_REJ A LEFT JOIN GPS_TL_PAYTYPE B ON A.gprj_paymth=B.PAYT_PAYMTH AND ")
        sb.Append("A.gprj_sub_paymth=B.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gprj_core_system=D.CSYS_CORE_SYSTEM ")
        sb.Append("LEFT JOIN (select t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH, ")
        sb.Append("sum(t.taxrj_base_amt) As taxcm_base_amt, sum(t.taxrj_tax_amt) As taxcm_tax_amt  ")
        sb.Append("from GPS_WHT_REJ t left join GPS_TRANSREF_REL u ON t.taxrj_createdate=u.tref_CREATEDATE AND ")
        sb.Append("t.taxrj_core_system=u.tref_core_system AND ")
        sb.Append("t.taxrj_transref=u.tref_transref                           ")
        sb.Append("where t.TAXRJ_BATCHDATE='" & batchdate & "'  ")

        If cboType.Text = "����" Then
            sb.Append(" and nvl(u.tref_paycretyp_id,'000') <> '003' ")
        Else
            sb.Append(" and nvl(u.tref_paycretyp_id,'000') = '003' ")
        End If

        sb.Append("group by t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G  ")
        sb.Append("ON A.gprj_batchdate=G.TAXRJ_BATCHDATE AND ")
        sb.Append("A.gprj_batch_no=G.TAXRJ_BATCH_NO AND ")
        sb.Append("A.gprj_core_system=G.TAXRJ_CORE_SYSTEM AND  ")
        sb.Append("A.gprj_paymth=G.TREF_PAYMTH AND ")
        sb.Append("A.gprj_sub_paymth=G.TREF_SUB_PAYMTH  ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.gprj_batch_no=H.TRAN_BATCH_ID ")
        'sb.Append("where A.gprj_batchdate='" & batchdate & "' And A.gprj_reject_type <>'BANK' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where A.gprj_batchdate='" & batchdate & "' And  A.gprj_reject_type <>'BANK' And  A.gprj_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.gprj_batchdate, A.gprj_batch_no, A.gprj_core_system, A.gprj_paymth, A.gprj_sub_paymth, B.Payt_Paytype,  ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("union ")

        'Query ��������§ҹ Summary ��¡�è��»Դ Batch (non Pay) -InComplete ")
        sb.Append("select 'InComplete' As BatchStatus,'ZNONPAY' as maingroup, A.taxrj_BATCHDATE As batch_date, A.taxrj_BATCH_NO As batch_no, A.taxrj_CORE_SYSTEM As core_system, ' ' As paymth, ' ' As sub_paymth, 'ZZNon Pay' As Payt_Paytype,  ")
        sb.Append("'ZNon Pay' As PAYG_PAY_GROUP, 'ZNon Pay' As PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, SUM(A.taxrj_base_amt) As taxcm_base_amt, SUM(A.taxrj_tax_amt) AS taxcm_tax_amt, ")
        'sb.Append(", 0 AS Net_AMOUNT,0 As No_Record ")
        sb.Append("SUM(A.taxrj_base_amt)-SUM(A.taxrj_tax_amt)  AS Net_AMOUNT,Count(A.taxrj_batchdate) As No_Record ")
        sb.Append("from GPS_WHT_REJ A LEFT JOIN GPS_TRANSREF_REL U ON A.taxrj_createdate=U.tref_CREATEDATE AND ")
        sb.Append("A.taxrj_core_system=U.tref_core_system AND ")
        sb.Append("A.taxrj_transref=U.tref_transref AND   ")
        sb.Append("A.taxrj_BATCHDATE=U.tref_BATCHDATE ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.taxrj_CORE_SYSTEM=D.CSYS_CORE_SYSTEM ")
        'sb.Append("LEFT JOIN GPS_TRANSLOG H ON A.taxrj_BATCH_NO=H.TRAN_BATCH_ID ")
        'sb.Append("where A.taxrj_BATCHDATE='" & batchdate & "' And A.taxrj_reject_type <>'BANK' And U.TREF_PAYCRETYP_ID='006' And H.TRAN_BATCH_TYPE='" & item.TypeID & "' And H.TRAN_STATUS='COMPLETE' ")
        sb.Append("where  A.taxrj_BATCHDATE='" & batchdate & "' And A.taxrj_reject_type <>'BANK' And U.TREF_PAYCRETYP_ID='006' And A.taxrj_BATCHTYPE='" & item.TypeID & "' ")
        sb.Append("Group by A.taxrj_BATCHDATE, A.taxrj_BATCH_NO, A.taxrj_CORE_SYSTEM, D.CSYS_CORE_SYSTEMNAME ")


        Return sb
    End Function
    Function GetDataReport() As DataTable
        Dim sb As New StringBuilder()
        Dim batchdate As String = dtpBatchDate.Value.ToString("yyyyMMdd")

        Select Case cboStatus.SelectedIndex
            Case 0
                sb.Append(fnStrComplete(batchdate, cboType.SelectedValue.ToString).ToString)
                sb.Append(" union ")
                sb.Append(fnStrInComplete(batchdate, cboType.SelectedValue.ToString).ToString)
            Case 1
                sb.Append(fnStrComplete(batchdate, cboType.SelectedValue.ToString).ToString)
            Case 2
                sb.Append(fnStrInComplete(batchdate, cboType.SelectedValue.ToString).ToString)
        End Select

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click
        PrintReport()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class