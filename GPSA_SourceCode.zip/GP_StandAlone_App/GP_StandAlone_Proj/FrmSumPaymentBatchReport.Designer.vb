<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSumPaymentBatchReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboType = New System.Windows.Forms.ComboBox()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.dtpBatchDate = New CustomControls.DatePicker()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.CmdPreview = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboType
        '
        Me.cboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboType.FormattingEnabled = True
        Me.cboType.Location = New System.Drawing.Point(119, 51)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(162, 21)
        Me.cboType.TabIndex = 17
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(338, 38)
        Me.PanelH1.TabIndex = 42
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(32, 11)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(265, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "��§ҹ Summary ��¡�è��»Դ Batch"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtpBatchDate
        '
        Me.dtpBatchDate.Culture = New System.Globalization.CultureInfo("en-GB")
        Me.dtpBatchDate.Location = New System.Drawing.Point(119, 11)
        Me.dtpBatchDate.Name = "dtpBatchDate"
        Me.dtpBatchDate.Size = New System.Drawing.Size(162, 22)
        Me.dtpBatchDate.TabIndex = 40
        Me.dtpBatchDate.Value = New Date(2014, 11, 11, 0, 0, 0, 0)
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.cboStatus)
        Me.PanelD1.Controls.Add(Me.dtpBatchDate)
        Me.PanelD1.Controls.Add(Me.cboType)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(338, 136)
        Me.PanelD1.TabIndex = 43
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Status"
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(119, 85)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(162, 21)
        Me.cboStatus.TabIndex = 41
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "��������ûԴ Batch"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "�ѹ���Դ Batch"
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(269, 198)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(81, 28)
        Me.btnExit.TabIndex = 108
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'CmdPreview
        '
        Me.CmdPreview.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdPreview.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.CmdPreview.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdPreview.ForeColor = System.Drawing.Color.White
        Me.CmdPreview.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdPreview.Image = Nothing
        Me.CmdPreview.ImageKey = ""
        Me.CmdPreview.ImageList = Nothing
        Me.CmdPreview.Location = New System.Drawing.Point(182, 198)
        Me.CmdPreview.Name = "CmdPreview"
        Me.CmdPreview.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.Size = New System.Drawing.Size(81, 28)
        Me.CmdPreview.TabIndex = 107
        Me.CmdPreview.Text = "Print"
        Me.CmdPreview.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdPreview.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmSumPaymentBatchReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 235)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.CmdPreview)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Name = "FrmSumPaymentBatchReport"
        Me.Text = "��§ҹ��ػ�Դ Batch"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cboType As System.Windows.Forms.ComboBox
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents dtpBatchDate As CustomControls.DatePicker
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CmdPreview As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
