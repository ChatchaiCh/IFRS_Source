Public Class frmProgress

    Private WithEvents _BGW As System.ComponentModel.BackgroundWorker

    Public Sub New(ByVal BGW As System.ComponentModel.BackgroundWorker)
        _BGW = BGW
        InitializeComponent()
    End Sub

    Private Sub frmProgress_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If Not IsNothing(_BGW) Then
            _BGW.RunWorkerAsync()
            lblprogress.Text = "processing..."
        End If
    End Sub

    Private Sub _BGW_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles _BGW.ProgressChanged
        ProgressBar1.Value = e.ProgressPercentage
        lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub

    Private Sub _BGW_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles _BGW.RunWorkerCompleted
        Me.Close()
    End Sub
   
    
End Class