Imports UtilityClassLibrary
Imports System.Text

Public Class FrmPendingReceiptReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsReport
    Private Sub FrmOutstanding_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        Dim d As Date = Date.Today
        d = d.AddDays(-1)

        ListCoreSystem()

        dtpDateFrom.Value = d.ToString("dd/MM/yyyy")
        dtpDateTo.Value = d.ToString("dd/MM/yyyy")
    End Sub
    Private Sub ListCoreSystem()
        Dim sb As New StringBuilder()

        sb.Append("select csys_core_system,csys_core_systemname from gps_tl_core_system ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            With cboCoreSystem
                .DataSource = dt
                .DisplayMember = "csys_core_systemname"
                .ValueMember = "csys_core_system"
            End With
        End If
        cboCoreSystem.SelectedIndex = 0
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        PrintReport()
    End Sub
    Private Sub PrintReport()


        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPendingReceipt.rpt")

        Dim condition As String = ""
        Dim dt As DataTable = New DataTable()

        dt = cls.DtRptPendingReceipt(clsUtility.gConnGP, dtpDateFrom.Value.ToString("yyyyMMdd"), dtpDateTo.Value.ToString("yyyyMMdd"), cboCoreSystem.SelectedValue.ToString)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramHeader As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            paramHeader.ParameterFieldName = "pTransDate"
            discreteHeader.Value = dtpDateFrom.Value.ToString("dd/MM/yyyy") & " to " & dtpDateTo.Value.ToString("dd/MM/yyyy")
            paramHeader.CurrentValues.Add(discreteHeader)
            paramFields.Add(paramHeader)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmPendingReceiptReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class