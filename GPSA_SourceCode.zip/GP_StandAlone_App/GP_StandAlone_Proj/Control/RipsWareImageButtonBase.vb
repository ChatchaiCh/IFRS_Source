Imports System.Windows.Forms.Design
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Design

Namespace RipsWare.Controls.Base.Button

    <Designer(GetType(ImageButtonBaseDesigner)), ToolboxBitmap(GetType(Windows.Forms.Button))> _
    Public Class RipsWareImageButtonBase
        Inherits RipsWareButtonBase

#Region "Images"

        Private _NormalImage As Bitmap
        Public Property NormalImage() As Bitmap
            Get
                Return _NormalImage
            End Get
            Set(ByVal value As Bitmap)
                _NormalImage = value
                GenenerateStrechedImage(_NormalImage, NormalImageD)
                Me.Invalidate()
                Me.OnNormalImageChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event NormalImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnNormalImageChanged(ByVal e As System.EventArgs)
            RaiseEvent NormalImageChanged(Me, e)
        End Sub

        Private _ActiveImage As Bitmap
        Public Property ActiveImage() As Bitmap
            Get
                Return _ActiveImage
            End Get
            Set(ByVal value As Bitmap)
                _ActiveImage = value
                GenenerateStrechedImage(_ActiveImage, ActiveImageD)
                Me.Invalidate()
                Me.OnActiveImageChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event ActiveImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnActiveImageChanged(ByVal e As System.EventArgs)
            RaiseEvent ActiveImageChanged(Me, e)
        End Sub

        Private _HoverImage As Bitmap
        Public Property HoverImage() As Bitmap
            Get
                Return _HoverImage
            End Get
            Set(ByVal value As Bitmap)
                _HoverImage = value
                GenenerateStrechedImage(_HoverImage, HoverImageD)
                Me.Invalidate()
                Me.OnHoverImageChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event HoverImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnHoverImageChanged(ByVal e As System.EventArgs)
            RaiseEvent HoverImageChanged(Me, e)
        End Sub

        Private _PressedImage As Bitmap
        Public Property PressedImage() As Bitmap
            Get
                Return _PressedImage
            End Get
            Set(ByVal value As Bitmap)
                _PressedImage = value
                GenenerateStrechedImage(_PressedImage, PressedImageD)
                Me.Invalidate()
                Me.OnPressedImageChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event PressedImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnPressedImageChanged(ByVal e As System.EventArgs)
            RaiseEvent PressedImageChanged(Me, e)
        End Sub

        Private NormalImageD, HoverImageD, PressedImageD, ActiveImageD As New Bitmap(1, 1)
        Private gcont As Drawing2D.GraphicsContainer
        ''' <summary>
        ''' Generate Button state from given image (Resize the button image)
        ''' </summary>
        ''' <param name="imgSource">Source Image</param>
        ''' <param name="imgDest">Result image</param>
        ''' <remarks></remarks>
        Private Sub GenenerateStrechedImage(ByRef imgSource As Bitmap, ByRef imgDest As Bitmap)
            If Me.Width = 0 Or Me.Height = 0 Then
                Return
            End If
            imgDest = New Bitmap(Me.Width, Me.Height)
            If IsNothing(imgSource) Then
                Return
            End If
            imgSource.SetResolution(96, 96)
            Dim sprt As New TileImages(imgSource, 3, 3)
            imgDest.SetResolution(96, 96)
            Dim w As Integer = sprt.ItemWidth 'Slice Image Width
            Dim h As Integer = sprt.ItemHeight 'Sliced Image Height
            Dim eH, eW As Integer
            eH = CInt((Height - h * 3) / 2) 'Empty space height
            eW = CInt((Width - w * 3) / 2) 'Empty space width
            Using g As Graphics = Graphics.FromImage(imgDest)
                Dim br As Drawing.TextureBrush

                If eW > 0 Then
                    'top left
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(0, 0), w - 1, 0, 1, h), Drawing2D.WrapMode.TileFlipX)
                    g.FillRectangle(br, w, 0, eW, h)

                    'top right
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(0, 1), w - 1, 0, 1, h))
                    g.FillRectangle(br, w * 2 + eW, 0, eW, h)

                    'midle left
                    gcont = g.BeginContainer
                    g.TranslateTransform(0, h + eH)
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(1, 0), w - 1, 0, 1, h), Drawing2D.WrapMode.TileFlipX)
                    g.FillRectangle(br, w, 0, eW, h)

                    'top right
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(1, 1), w - 1, 0, 1, h))
                    g.FillRectangle(br, w * 2 + eW, 0, eW, h)
                    g.EndContainer(gcont)

                    'bottom left
                    gcont = g.BeginContainer
                    g.TranslateTransform(0, h * 2 + eH * 2)
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(2, 0), w - 1, 0, 1, h), Drawing2D.WrapMode.TileFlipX)
                    g.FillRectangle(br, w, 0, eW, h)

                    'bottom right
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(2, 1), w - 1, 0, 1, h))
                    g.FillRectangle(br, w * 2 + eW, 0, eW, h)
                    g.EndContainer(gcont)
                End If

                If eH > 0 Then
                    'left top
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(0, 0), 0, h - 1, w, 1))
                    g.FillRectangle(br, 0, h, w, eH)

                    'left bottom
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(2, 0), 0, 0, w, 1))
                    g.FillRectangle(br, 0, h * 2 + eH, w, eH)

                    'midle top
                    gcont = g.BeginContainer
                    g.TranslateTransform(w + eW, 0)
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(0, 1), 0, h - 1, w, 1))
                    g.FillRectangle(br, 0, h, w, eH)

                    'midle bottom
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(2, 1), 0, 0, w, 1))
                    g.FillRectangle(br, 0, h * 2 + eH, w, eH)
                    g.EndContainer(gcont)

                    'rigth top
                    gcont = g.BeginContainer
                    g.TranslateTransform(w * 2 + eW * 2, 0)
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(0, 2), 0, h - 1, w, 1))
                    g.FillRectangle(br, 0, h, w, eH)

                    'rigth bottom
                    br = New Drawing.TextureBrush(CropImage(sprt.GetImage(2, 2), 0, 0, w, 1))
                    g.FillRectangle(br, 0, h * 2 + eH, w, eH)
                    g.EndContainer(gcont)
                End If

                If eW > 0 And eH > 0 Then

                    gcont = g.BeginContainer
                    g.TranslateTransform(0, h)
                    br = New Drawing.TextureBrush(CropImage(imgDest, w - 1, h, 1, eH))
                    g.FillRectangle(br, w, 0, eW, eH)
                    br = New Drawing.TextureBrush(CropImage(imgDest, w * 2 + eW - 1, h, 1, eH))
                    g.FillRectangle(New SolidBrush(sprt.GetImage(0, 1).GetPixel(w - 1, h - 1)), w * 2 + eW, 0, eW, eH)
                    g.EndContainer(gcont)

                    gcont = g.BeginContainer
                    g.TranslateTransform(0, h * 2 + eH)
                    br = New Drawing.TextureBrush(CropImage(imgDest, w - 1, h * 2 + eH, 1, eH))
                    g.FillRectangle(br, w, 0, eW, eH)
                    br = New Drawing.TextureBrush(CropImage(imgDest, w * 2 + eW - 1, h * 2 + eH, 1, eH))
                    g.FillRectangle(br, w * 2 + eW, 0, eW, eH)
                    g.EndContainer(gcont)
                End If

                g.DrawImageUnscaled(sprt.GetImage(0, 0), 0, 0)
                g.DrawImageUnscaled(sprt.GetImage(0, 1), w + eW, 0)
                g.DrawImageUnscaled(sprt.GetImage(0, 2), eW * 2 + w * 2, 0)

                g.DrawImageUnscaled(sprt.GetImage(1, 0), 0, h + eH)
                g.DrawImageUnscaled(sprt.GetImage(1, 1), w + eW, h + eH)
                g.DrawImageUnscaled(sprt.GetImage(1, 2), eW * 2 + w * 2, h + eH)

                g.DrawImageUnscaled(sprt.GetImage(2, 0), 0, eH * 2 + h * 2)
                g.DrawImageUnscaled(sprt.GetImage(2, 1), w + eW, eH * 2 + h * 2)
                g.DrawImageUnscaled(sprt.GetImage(2, 2), eW * 2 + w * 2, eH * 2 + h * 2)
            End Using
            sprt.Dispose()
            sprt = Nothing
        End Sub

        Private Function CropImage(ByVal sImage As Bitmap, ByVal x As Integer, ByVal y As Integer, ByVal w As Integer, ByVal h As Integer)
            If w <= 0 Or h <= 0 Then
                Return New Bitmap(1, 1)
            End If
            Dim bmp As New Bitmap(w, h)
            bmp.SetResolution(96, 96)
            Using g As Graphics = Graphics.FromImage(bmp)
                g.DrawImageUnscaled(sImage, -x, -y)
            End Using
            Return bmp
        End Function

        Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
            MyBase.OnSizeChanged(e)
            If Me.Width = 0 Or Me.Height = 0 Then
                Return
            End If
            'Resizing Button image state
            GenenerateStrechedImage(_NormalImage, NormalImageD)
            GenenerateStrechedImage(_HoverImage, HoverImageD)
            GenenerateStrechedImage(_PressedImage, PressedImageD)
            GenenerateStrechedImage(_ActiveImage, ActiveImageD)
        End Sub

#End Region

        Protected Overrides Sub OnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
            MyBase.OnMouseMove(e)
            Me.Invalidate()
        End Sub

        Protected Overrides Sub DrawDisabledState(ByRef g As System.Drawing.Graphics)
            MyBase.DrawDisabledState(g)
        End Sub

        Protected Overrides Sub DrawNormalState(ByRef g As System.Drawing.Graphics)
            g.DrawImageUnscaled(NormalImageD, 0, 0)
            MyBase.DrawNormalState(g)
        End Sub

        Protected Overrides Sub DrawActiveState(ByRef g As System.Drawing.Graphics)
            If IsNothing(Me._ActiveImage) Then
                Me.DrawNormalState(g)
            Else
                g.DrawImageUnscaled(ActiveImageD, 0, 0)
            End If
            MyBase.DrawActiveState(g)
        End Sub

        Protected Overrides Sub DrawHoverState(ByRef g As System.Drawing.Graphics)
            g.DrawImageUnscaled(HoverImageD, 0, 0)
            MyBase.DrawHoverState(g)
        End Sub

        Protected Overrides Sub DrawPressedState(ByRef g As System.Drawing.Graphics)
            g.DrawImageUnscaled(PressedImageD, 0, 0)
            MyBase.DrawPressedState(g)
        End Sub

    End Class

    Public Class TileImages
        Implements IDisposable

        Public Sub New(ByVal img As Bitmap, ByVal column As Integer, ByVal row As Integer)
            Me._SpritImage = img
            _SpritImage.SetResolution(96, 96)
            Me._Column = column
            Me._Row = row
            BuildList()
        End Sub

        Private lst As New List(Of Bitmap)
        Private Sub BuildList()
            lst.Clear()
            If IsNothing(_SpritImage) Then
                Return
            End If
            _ItemWidth = _SpritImage.Width / _Column
            _ItemHeight = _SpritImage.Height / _Row
            If _ItemWidth * _Column < _SpritImage.Width Then
                _ItemWidth += 1
            End If
            If _ItemHeight * _Row < _SpritImage.Height Then
                _ItemHeight += 1
            End If
            For r As Integer = 0 To _Row - 1
                For c As Integer = 0 To _Column - 1
                    lst.Add(CropImage(_SpritImage, c * _ItemWidth, _
                                    r * _ItemHeight, _ItemWidth, _ItemHeight))
                Next
            Next
        End Sub

        ''' <summary>
        ''' Zero base index
        ''' </summary>
        ''' <param name="row">Row of image with zero based index</param>
        ''' <param name="column">Column of image with zero based index</param>
        ''' <returns>Bitmap</returns>
        ''' <remarks></remarks>
        Public Function GetImage(ByVal row As Integer, _
                                Optional ByVal column As Integer = 0) As Bitmap
            If row < 0 Or column < 0 Then
                Return Nothing
            End If
            Return lst(row * _Column + column)
        End Function

        Private _SpritImage As Bitmap
        Public Property SpritImage() As Bitmap
            Get
                Return _SpritImage
            End Get
            Set(ByVal value As Bitmap)
                _SpritImage = value
                _SpritImage.SetResolution(96, 96)
                BuildList()
                Me.OnSpritImageChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event SpritImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnSpritImageChanged(ByVal e As System.EventArgs)
            RaiseEvent SpritImageChanged(Me, e)
        End Sub

        Private _Column As Integer = 1
        Public Property Column() As Integer
            Get
                Return _Column
            End Get
            Set(ByVal value As Integer)
                _Column = value
                BuildList()
                Me.OnColumnChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event ColumnChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnColumnChanged(ByVal e As System.EventArgs)
            RaiseEvent ColumnChanged(Me, e)
        End Sub

        Private _Row As Integer = 1
        Public Property Row() As Integer
            Get
                Return _Row
            End Get
            Set(ByVal value As Integer)
                _Row = value
                BuildList()
                Me.OnRowChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event RowChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnRowChanged(ByVal e As System.EventArgs)
            RaiseEvent RowChanged(Me, e)
        End Sub

        Private _ItemWidth As Integer
        Public ReadOnly Property ItemWidth() As Integer
            Get
                Return _ItemWidth
            End Get
        End Property

        Private _ItemHeight As Integer
        Public ReadOnly Property ItemHeight() As Integer
            Get
                Return _ItemHeight
            End Get
        End Property

        ''' <summary>
        ''' Crop image
        ''' </summary>
        ''' <param name="sImage">Source bitmap</param>
        ''' <param name="x">X location</param>
        ''' <param name="y">Y location</param>
        ''' <param name="w">Width</param>
        ''' <param name="h">Height</param>
        ''' <returns>Cropped image</returns>
        ''' <remarks></remarks>
        Private Function CropImage(ByVal sImage As Bitmap, _
                                    ByVal x As Integer, ByVal y As Integer, _
                                    ByVal w As Integer, ByVal h As Integer)
            If w <= 0 Or h <= 0 Then
                Return New Bitmap(1, 1)
            End If
            Dim bmp As New Bitmap(w, h)
            bmp.SetResolution(96, 96)
            Using g As Graphics = Graphics.FromImage(bmp)
                g.DrawImageUnscaled(sImage, -x, -y)
            End Using
            Return bmp
        End Function


#Region " IDisposable Support "
        Private disposedValue As Boolean = False        ' To detect redundant calls

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
            If Not Me.disposedValue Then
                If disposing Then
                    ' TODO: free unmanaged resources when explicitly called
                End If
                lst.Clear()
                ' TODO: free shared unmanaged resources
            End If
            Me.disposedValue = True
        End Sub

        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region

    End Class

End Namespace
