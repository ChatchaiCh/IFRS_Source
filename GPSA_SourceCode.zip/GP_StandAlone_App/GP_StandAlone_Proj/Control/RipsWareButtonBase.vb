Imports System.Windows.Forms.Design
Imports System.Drawing.Design
Imports System.ComponentModel
Namespace RipsWare.Controls.Base.Button

    Public MustInherit Class RipsWareButtonBase
        Inherits Control
        Implements IButtonControl

        Public Sub New()
            SetStyle(ControlStyles.Selectable Or ControlStyles.AllPaintingInWmPaint Or ControlStyles.OptimizedDoubleBuffer Or ControlStyles.SupportsTransparentBackColor Or ControlStyles.ResizeRedraw, True)
            SetStyle(ControlStyles.Selectable, True)
        End Sub

        Private _DialogResult As System.Windows.Forms.DialogResult
        Public Property DialogResult() As System.Windows.Forms.DialogResult Implements IButtonControl.DialogResult
            Get
                Return _DialogResult
            End Get
            Set(ByVal value As System.Windows.Forms.DialogResult)
                _DialogResult = value
                Me.OnDialogResultChanged(EventArgs.Empty)
            End Set
        End Property

        Private _text As String = MyBase.Text
        <Browsable(True)> _
        Public Shadows Property Text() As String
            Get
                Return _text
            End Get
            Set(ByVal value As String)
                _text = value
                MyBase.Text = value
                Me.Invalidate()
            End Set
        End Property

        Public Shadows Property Font() As Font
            Get
                Return MyBase.Font
            End Get
            Set(ByVal value As Font)
                MyBase.Font = value
                Me.Invalidate()
            End Set
        End Property

        Public Shadows Property ForeColor() As Color
            Get
                Return MyBase.ForeColor
            End Get
            Set(ByVal value As Color)
                MyBase.ForeColor = value
                Me.Invalidate()
            End Set
        End Property

        Public Shadows Property BackColor() As Color
            Get
                Return MyBase.BackColor
            End Get
            Set(ByVal value As Color)
                MyBase.BackColor = value
                Me.Invalidate()
            End Set
        End Property

        Private _TextImageRelation As TextImageRelation = Windows.Forms.TextImageRelation.ImageBeforeText
        <Category("Appearance")> <System.ComponentModel.DefaultValue(4)> _
        Public Property TextImageRelation() As TextImageRelation
            Get
                Return _TextImageRelation
            End Get
            Set(ByVal value As TextImageRelation)
                _TextImageRelation = value
                ResizeRect()
            End Set
        End Property

        Private _ImageList As ImageList
        Public Property ImageList() As ImageList
            Get
                Return _ImageList
            End Get
            Set(ByVal value As ImageList)
                _ImageList = value
                Me.OnImageListChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event ImageListChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnImageListChanged(ByVal e As System.EventArgs)
            RaiseEvent ImageListChanged(Me, e)
        End Sub

        Private _ImageKey As String
        Public Property ImageKey() As String
            Get
                Return _ImageKey
            End Get
            Set(ByVal value As String)
                _ImageKey = value
                If Not IsNothing(Me._ImageList) AndAlso Me._ImageList.Images.ContainsKey(value) Then
                    _image = Me._ImageList.Images(value)
                    Me._ImageIndex = Me._ImageList.Images.IndexOfKey(value)
                    If Not IsNothing(_image) Then
                        _image.SetResolution(96, 96)
                        ResizeRect()
                    End If
                End If
                Me.OnImageKeyChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event ImageKeyChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnImageKeyChanged(ByVal e As System.EventArgs)
            RaiseEvent ImageKeyChanged(Me, e)
        End Sub

        Private _ImageIndex As Integer = -1
        <DefaultValue(-1)> _
        Public Property ImageIndex() As Integer
            Get
                Return _ImageIndex
            End Get
            Set(ByVal value As Integer)
                _ImageIndex = value
                If Not IsNothing(Me._ImageList) AndAlso (value > -1 And value < Me._ImageList.Images.Count) Then
                    _image = Me._ImageList.Images(value)
                    Me._ImageKey = Me._ImageList.Images.Keys(value)
                    If Not IsNothing(_image) Then
                        _image.SetResolution(96, 96)
                        ResizeRect()
                    End If
                End If
                Me.OnImageIndexChanged(EventArgs.Empty)
            End Set
        End Property

        Public Event ImageIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnImageIndexChanged(ByVal e As System.EventArgs)
            RaiseEvent ImageIndexChanged(Me, e)
        End Sub

        Private _image As Bitmap = Nothing
        Private ImageToDraw As Bitmap
        Private ImgRect As Rectangle
        <Category("Appearance")> _
        Public Shadows Property Image() As Bitmap
            Get
                Return _image
            End Get
            Set(ByVal value As Bitmap)
                _image = value
                Me._ImageKey = ""
                Me._ImageIndex = -1
                If Not IsNothing(_image) Then
                    _image.SetResolution(96, 96)
                    ResizeRect()
                End If
                Me.OnImageChanged(New System.EventArgs())
            End Set
        End Property

        Private Sub ResizeRect()
            If Me.Width <= 0 Or Me.Height <= 0 Then
                Return
            End If
            TextRect = New Rectangle(2, 2, Width - 4, Height - 4)
            Dim sz As Size
            If IsNothing(_image) = False Then
                Select Case Me.TextImageRelation
                    Case Is = Windows.Forms.TextImageRelation.ImageAboveText
                        sz = TextRenderer.MeasureText(Me.Text, Me.Font)
                        sz.Height += 4
                        ImgRect = New Rectangle(TextRect.X, TextRect.Y, TextRect.Width, TextRect.Height - sz.Height)
                        TextRect = New Rectangle(TextRect.X, ImgRect.Bottom, TextRect.Width, sz.Height)
                    Case Is = Windows.Forms.TextImageRelation.TextAboveImage
                        sz = TextRenderer.MeasureText(Me.Text, Me.Font)
                        sz.Height += 4
                        ImgRect = New Rectangle(TextRect.X, TextRect.Y + sz.Height, TextRect.Width, TextRect.Height - sz.Height)
                        TextRect = New Rectangle(TextRect.X, TextRect.Y, TextRect.Width, sz.Height)
                    Case Is = Windows.Forms.TextImageRelation.ImageBeforeText
                        ImgRect = New Rectangle(TextRect.X, TextRect.Y, Me.TextRect.Width * 0.25, TextRect.Height)
                        TextRect = New Rectangle(ImgRect.Right, TextRect.Y, TextRect.Width - ImgRect.Width, TextRect.Height)
                    Case Is = Windows.Forms.TextImageRelation.TextBeforeImage
                        TextRect = New Rectangle(TextRect.X, TextRect.Y, TextRect.Width - (TextRect.Width * 0.25), TextRect.Height)
                        ImgRect = New Rectangle(TextRect.Right, TextRect.Y, TextRect.Width * 0.25, TextRect.Height)
                    Case Is = Windows.Forms.TextImageRelation.Overlay
                        ImgRect = TextRect
                End Select
                If _image.Width > ImgRect.Width Or _image.Height > ImgRect.Height Then
                    ImageToDraw = DrawUtility.ResizeImage(_image, ImgRect.Size)
                Else
                    ImageToDraw = _image
                End If
                ImageToDraw.SetResolution(96, 96)
            End If
            Me.Invalidate()
        End Sub

        Public Event ImageChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnImageChanged(ByVal e As System.EventArgs)
            RaiseEvent ImageChanged(Me, e)
        End Sub

        Protected State As ButtonState = ButtonState.Inactive

        Public Event DialogResultChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Protected Overridable Sub OnDialogResultChanged(ByVal e As System.EventArgs)
            RaiseEvent DialogResultChanged(Me, e)
        End Sub

        Public Sub NotifyDefault(ByVal value As Boolean) Implements System.Windows.Forms.IButtonControl.NotifyDefault
            _IsDefault = value
        End Sub

        Private _IsDefault As Boolean
        Public ReadOnly Property IsDefault() As Boolean
            Get
                Return _IsDefault
            End Get
        End Property

        Public Sub PerformClick() Implements System.Windows.Forms.IButtonControl.PerformClick
            Me.OnClick(EventArgs.Empty)
        End Sub

        Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)
            MyBase.OnTextChanged(e)
            Me.Invalidate()
        End Sub

        Protected Overrides Sub OnFontChanged(ByVal e As System.EventArgs)
            MyBase.OnFontChanged(e)
            Me.Invalidate()
        End Sub

        Protected Overrides Sub OnMouseEnter(ByVal e As System.EventArgs)
            MyBase.OnMouseEnter(e)
            Me.State = ButtonState.Normal
            Me.Invalidate()
        End Sub

        Protected Overrides Sub OnMouseLeave(ByVal e As System.EventArgs)
            MyBase.OnMouseLeave(e)
            Me.State = ButtonState.Inactive
            Me.Invalidate()
            GC.Collect()
        End Sub

        Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
            MyBase.OnMouseDown(e)
            If Me.State <> ButtonState.Pushed Then
                Me.State = ButtonState.Pushed
                Me.Invalidate()
            End If

            If Me.ContainsFocus = False Then
                Me.Focus()
            End If
        End Sub

        Protected Overrides Sub OnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
            MyBase.OnMouseMove(e)
            If e.Button = Windows.Forms.MouseButtons.Left Then
                If Me.ClientRectangle.Contains(e.Location) Then
                    If Me.State <> ButtonState.Pushed Then
                        Me.State = ButtonState.Pushed
                        Me.Invalidate()
                    End If
                Else
                    If Me.State = ButtonState.Pushed Then
                        Me.State = ButtonState.Normal
                        Me.Invalidate()
                    End If
                End If
            End If
        End Sub

        Protected Overrides Sub OnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
            MyBase.OnMouseUp(e)
            If Me.ClientRectangle.Contains(e.Location) Then
                Me.State = ButtonState.Normal
                Me.Invalidate()
            Else
                Me.State = ButtonState.Inactive
                Me.Invalidate()
            End If
        End Sub

        Protected Overrides Function ProcessMnemonic(ByVal charCode As Char) As Boolean
            If Control.IsMnemonic(charCode, MyBase.Text) Then
                Me.PerformClick()
                Return True
            End If
            Return MyBase.ProcessMnemonic(charCode)
        End Function

        Protected Overrides Sub OnKeyDown(ByVal e As System.Windows.Forms.KeyEventArgs)
            MyBase.OnKeyDown(e)
            If e.KeyData = Keys.Space Or e.KeyData = Keys.Enter Then
                Me.PerformClick()
                If Me.State <> ButtonState.Pushed Then
                    Me.State = ButtonState.Pushed
                    Me.Invalidate()
                End If
            End If
        End Sub

        Protected Overrides Sub OnKeyUp(ByVal e As System.Windows.Forms.KeyEventArgs)
            MyBase.OnKeyUp(e)
            If Me.State = ButtonState.Pushed Then
                If Me.ClientRectangle.Contains(Me.PointToClient(Windows.Forms.Cursor.Position)) Then
                    Me.State = ButtonState.Normal
                Else
                    Me.State = ButtonState.Inactive
                End If
                Me.Invalidate()
            End If
        End Sub

        Protected Overrides Sub OnGotFocus(ByVal e As System.EventArgs)
            MyBase.OnGotFocus(e)
            Me.Invalidate()
        End Sub

        Protected Overrides Sub OnLostFocus(ByVal e As System.EventArgs)
            MyBase.OnLostFocus(e)
            Me.Invalidate()
        End Sub

#Region "Text Formating"
        Protected TextFormat As TextFormatFlags = TextFormatFlags.WordBreak Or TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter
        Private _textAlign As System.Drawing.ContentAlignment = ContentAlignment.MiddleCenter

        <DefaultValue(32)> _
        Public Property TextAlign() As System.Drawing.ContentAlignment
            Get
                Return _textAlign
            End Get
            Set(ByVal value As System.Drawing.ContentAlignment)
                _textAlign = value
                Select Case value
                    Case Is = ContentAlignment.TopLeft
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Left Or TextFormatFlags.Top
                    Case Is = ContentAlignment.TopCenter
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.HorizontalCenter Or TextFormatFlags.Top
                    Case Is = ContentAlignment.TopRight
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Right Or TextFormatFlags.Top
                    Case Is = ContentAlignment.MiddleLeft
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Left Or TextFormatFlags.VerticalCenter
                    Case Is = ContentAlignment.MiddleCenter
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter
                    Case Is = ContentAlignment.MiddleRight
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Right Or TextFormatFlags.VerticalCenter
                    Case Is = ContentAlignment.BottomLeft
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Left Or TextFormatFlags.Bottom
                    Case Is = ContentAlignment.BottomCenter
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.HorizontalCenter Or TextFormatFlags.Bottom
                    Case Is = ContentAlignment.BottomRight
                        TextFormat = TextFormatFlags.WordBreak Or TextFormatFlags.Right Or TextFormatFlags.Bottom
                End Select
                Me.Invalidate()
            End Set
        End Property

        Protected TextRect As New Rectangle(0, 0, 10, 10)

        Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
            MyBase.OnSizeChanged(e)
            ResizeRect()
        End Sub

#End Region

#Region "Drawing"

        Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
            MyBase.OnPaint(e)
            DrawButton(e.Graphics)
        End Sub

        Protected Overridable Sub DrawButton(ByRef g As Graphics)
            If Me.Enabled = False Then
                Me.DrawDisabledState(g)
                Me.DrawText(g, Me.TextFormat)
                Me.DrawImage(g)
                Return
            End If

            Select Case Me.State
                Case Is = ButtonState.Normal  'Hover state
                    Me.DrawHoverState(g)
                Case Is = ButtonState.Pushed 'On mouse down
                    Me.DrawPressedState(g)
                Case Is = ButtonState.Checked
                    Me.DrawPressedState(g)
                Case Is = ButtonState.Flat
                Case Is = ButtonState.Normal  'Hover state
                Case Else 'Normal state
                    If Me.ContainsFocus Then
                        DrawActiveState(g)
                    Else
                        Me.DrawNormalState(g)
                    End If
            End Select

            Me.DrawImage(g)
            Me.DrawText(g, Me.TextFormat)

            If Me.IsDefault = True Then
                Me.DrawHotstate(g)
            End If
        End Sub

        Protected Overridable Sub DrawHotstate(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawHoverState(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawPressedState(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawActiveState(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawNormalState(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawDisabledState(ByRef g As Graphics)

        End Sub

        Protected Overridable Sub DrawText(ByRef g As Graphics, ByVal format As TextFormatFlags)
            TextRenderer.DrawText(g, Me.Text, Me.Font, TextRect, IIf(Me.Enabled, Me.ForeColor, SystemColors.GrayText), format)
        End Sub

        Protected Overridable Sub DrawImage(ByRef g As Graphics)
            If IsNothing(_image) = True Then
                Return
            End If
            With ImgRect
                If Me.Enabled = True Then
                    g.DrawImageUnscaled(Me.ImageToDraw, .X + .Width / 2 - ImageToDraw.Width / 2, .Y + .Height / 2 - ImageToDraw.Height / 2)
                Else
                    ControlPaint.DrawImageDisabled(g, Me.ImageToDraw, .X + .Width / 2 - ImageToDraw.Width / 2, .Y + .Height / 2 - ImageToDraw.Height / 2, Color.Transparent)
                End If
            End With
        End Sub

#End Region

    End Class

    Public NotInheritable Class DrawUtility

        Public Shared Function ResizeImage(ByVal image As Bitmap, ByVal size As Size, Optional ByVal KeepAspectRatio As Boolean = True) As Bitmap
            If Not IsNothing(image) Then
                If KeepAspectRatio Then
                    With GetPropImageSize(image, size)
                        Return New Bitmap(image, .Width, .Height)
                    End With
                Else
                    Return New Bitmap(image, size.Width, size.Height)
                End If
            Else
                Return Nothing
            End If
        End Function

        Public Shared Function GetPropImageSize(ByRef img As Bitmap, ByVal _sz As Size) As Size
            If Not IsNothing(img) Then
                Dim percent As Double
                Dim h, w As Integer

                percent = (_sz.Width - 1) / img.Width * 100
                h = CInt(img.Height * percent / 100)
                w = _sz.Width - 1

                If h >= _sz.Height Then
                    percent = (_sz.Height - 1) / img.Height * 100
                    h = _sz.Height - 1
                    w = CInt(img.Width * percent / 100)
                End If

                Return New Size(w, h)
            End If
        End Function

    End Class

End Namespace