
Imports System.ComponentModel.Design
Imports System.Windows.Forms.Design
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms.Design.Behavior

Namespace RipsWare.Controls.Base.Button

    Public Class ImageButtonBaseDesigner
        Inherits ControlDesigner

        Private _imageButtonActionList As RipsWareImageButtonBaseActionList
        Public Sub New()
            MyBase.New()
            'Record instance of control we're designing
        End Sub

        Public Overrides ReadOnly Property ActionLists() As System.ComponentModel.Design.DesignerActionListCollection
            Get
                Return MyBase.ActionLists
            End Get
        End Property

        Private _imageButton As RipsWareImageButtonBase
        Public Overrides Sub Initialize(ByVal component As System.ComponentModel.IComponent)
            MyBase.Initialize(component)

            _imageButton = DirectCast(Me.Control, RipsWareImageButtonBase)
            _imageButtonActionList = New RipsWareImageButtonBaseActionList(component)
            Me.ActionLists.Add(_imageButtonActionList)
        End Sub

        Public Overrides Function CanBeParentedTo(ByVal parentDesigner As System.ComponentModel.Design.IDesigner) As Boolean
            Return MyBase.CanBeParentedTo(parentDesigner)
        End Function

    End Class

    Public Class RipsWareImageButtonBaseActionList
        Inherits DesignerActionList

        Private _imageButton As RipsWareImageButtonBase
        Private _DesignerService As DesignerActionUIService = Nothing

        Public Sub New(ByVal component As IComponent)
            MyBase.New(component)
            _imageButton = CType(component, RipsWareImageButtonBase)
            _DesignerService = CType(GetService(GetType(DesignerActionUIService)), DesignerActionUIService)
            Me.AutoShow = True
            InitItems()
        End Sub

        Private Items As New DesignerActionItemCollection
        Public Overrides Function GetSortedActionItems() As System.ComponentModel.Design.DesignerActionItemCollection
            Return Items
        End Function

        Private Sub InitItems()
            With GetSortedActionItems()
                .Add(New DesignerActionHeaderItem("Design"))
                .Add(New DesignerActionPropertyItem("Text", "Text", "Design"))
                .Add(New DesignerActionPropertyItem("TextAlign", "Text Align", "Design"))
                .Add(New DesignerActionPropertyItem("ForeColor", "Forecolor", "Design"))
                .Add(New DesignerActionPropertyItem("Image", "Icon", "Design"))
                .Add(New DesignerActionPropertyItem("TextImageRelation", "Image Placement", "Design"))


                .Add(New DesignerActionHeaderItem("Button Image"))
                .Add(New DesignerActionPropertyItem("NormalImage", "Normal Image", "Button Image"))
                .Add(New DesignerActionPropertyItem("HoverImage", "Hover Image", "Button Image"))
                .Add(New DesignerActionPropertyItem("PressedImage", "Pressed Image", "Button Image"))
                .Add(New DesignerActionPropertyItem("ActiveImage", "Active Image", "Button Image"))
            End With
        End Sub

        Public Property Text() As String
            Get
                Return _imageButton.Text
            End Get
            Set(ByVal value As String)
                SetControlProperty("Text", value)
            End Set
        End Property

        Public Property TextAlign() As ContentAlignment
            Get
                Return _imageButton.TextAlign
            End Get
            Set(ByVal value As ContentAlignment)
                SetControlProperty("TextAlign", value)
            End Set
        End Property

        Public Property TextImageRelation() As TextImageRelation
            Get
                Return _imageButton.TextImageRelation
            End Get
            Set(ByVal value As TextImageRelation)
                SetControlProperty("TextImageRelation", value)
            End Set
        End Property

        Public Property Image() As Bitmap
            Get
                Return _imageButton.Image
            End Get
            Set(ByVal value As Bitmap)
                SetControlProperty("Image", value)
            End Set
        End Property

        Public Property NormalImage() As Bitmap
            Get
                Return _imageButton.NormalImage
            End Get
            Set(ByVal value As Bitmap)
                SetControlProperty("NormalImage", value)
            End Set
        End Property

        Public Property ActiveImage() As Bitmap
            Get
                Return _imageButton.ActiveImage
            End Get
            Set(ByVal value As Bitmap)
                SetControlProperty("ActiveImage", value)
            End Set
        End Property

        Public Property HoverImage() As Bitmap
            Get
                Return _imageButton.HoverImage
            End Get
            Set(ByVal value As Bitmap)
                SetControlProperty("HoverImage", value)
            End Set
        End Property

        Public Property PressedImage() As Bitmap
            Get
                Return _imageButton.PressedImage
            End Get
            Set(ByVal value As Bitmap)
                SetControlProperty("PressedImage", value)
            End Set
        End Property

        Public Property ForeColor() As Color
            Get
                Return _imageButton.ForeColor
            End Get
            Set(ByVal value As Color)
                SetControlProperty("ForeColor", value)
            End Set
        End Property

        Private Sub SetControlProperty(ByVal property_name As String, ByVal value As Object)
            TypeDescriptor.GetProperties(_imageButton)(property_name).SetValue(_imageButton, value)
        End Sub

    End Class

End Namespace