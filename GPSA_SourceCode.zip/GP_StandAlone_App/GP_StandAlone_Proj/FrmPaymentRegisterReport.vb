Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class FrmPaymentRegisterReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsConfirmBatch
    Dim cryRpt As New ReportDocument

    Private Sub FrmPaymentRegisterReport_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If (e.Control AndAlso (e.KeyCode = Keys.S)) Then
            ' When Control + S is pressed, the Click event for the show encryptdecrypt form
            ' button is raised.
            frmEncryptDecrypt.ShowDialog()
        End If

    End Sub
    Private Sub FrmRptPaymentRegisterTransByBatch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        txtDateFrom.Text = Now.ToString("dd/MM/yyyy")
        txtDateTo.Text = Now.ToString("dd/MM/yyyy")

        ListPayGroup()
        ListStatus()

    End Sub
    Private Sub ListPayGroup()
        Dim sb As New StringBuilder()

        sb.Append("SELECT PAYG_PAY_GROUP,PAYG_PAY_GROUPNAME FROM GPS_TL_PAYGROUP ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!PAYG_PAY_GROUP = 0
            dr!PAYG_PAY_GROUPNAME = "All"
            dt.Rows.InsertAt(dr, 0)
            With cboPaymentType
                .DataSource = dt
                .DisplayMember = "PAYG_PAY_GROUPNAME"
                .ValueMember = "PAYG_PAY_GROUP"
            End With
        End If
        cboPaymentType.SelectedIndex = 0
    End Sub
    Private Sub ListStatus()
        Dim sb As New StringBuilder()

        sb.Append("SELECT S.STS_STATUS,S.STS_DESC ")
        sb.Append("FROM (GPS_TL_STATUS S INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON S.STS_PAYMTH=T.PAYT_PAYMTH AND S.STS_SUB_PAYMTH=T.PAYT_SUB_PAYMTH) ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP ")
        sb.Append("WHERE S.STS_TYPE='LSTUPD_STS' ")

        If cboPaymentType.SelectedIndex <> 0 Then
            sb.Append("AND G.PAYG_PAY_GROUP='" & cboPaymentType.SelectedValue.ToString & "' ")
        End If

        sb.Append("GROUP BY S.STS_STATUS,S.STS_DESC ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!STS_STATUS = 0
            dr!STS_DESC = "All"
            dt.Rows.InsertAt(dr, 0)
            With cboPaymentStatus
                .DataSource = dt
                .DisplayMember = "STS_DESC"
                .ValueMember = "STS_STATUS"
            End With
        End If
        cboPaymentStatus.SelectedIndex = 0
    End Sub

    Function GetDataHead() As DataTable
        Dim dateto, datefrom, paymenttype, paymentstatus As String
        If txtDateTo.Text.Trim <> "" Then
            dateto = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
        Else
            dateto = ""
        End If
        If txtDateFrom.Text.Trim <> "" Then
            datefrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
        Else
            datefrom = ""
        End If

        If cboPaymentType.Text.ToUpper = "ALL" Then
            paymenttype = ""
        Else
            paymenttype = cboPaymentType.SelectedValue.ToString
        End If
        If cboPaymentStatus.Text.ToUpper = "ALL" Then
            paymentstatus = ""
        Else
            paymentstatus = cboPaymentType.SelectedValue.ToString
        End If

        Dim dt As DataTable
        dt = cls.GetDataRptPaymentRegistrationByBatch(clsUtility.gConnGP, txtBatchFrom.Text.Trim, txtBatchTo.Text.Trim, datefrom, dateto, paymenttype, paymentstatus)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataDetail() As DataTable
        Dim dateto, datefrom, paymenttype, paymentstatus As String

        If txtDateTo.Text.Trim <> "" Then
            dateto = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
        Else
            dateto = ""
        End If
        If txtDateFrom.Text.Trim <> "" Then
            datefrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
        Else
            datefrom = ""
        End If
        If cboPaymentType.Text.ToUpper = "ALL" Then
            paymenttype = ""
        Else
            paymenttype = cboPaymentType.SelectedValue.ToString
        End If
        If cboPaymentStatus.Text.ToUpper = "ALL" Then
            paymentstatus = ""
        Else
            paymentstatus = cboPaymentType.SelectedValue.ToString
        End If

        Dim dt As DataTable
        dt = cls.GetDataRptPaymentRegistrationByBatch_Detail(clsUtility.gConnGP, txtBatchFrom.Text.Trim, txtBatchTo.Text.Trim, datefrom, dateto, paymenttype, paymentstatus)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub PrintReportRegister_OLD()
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPaymentRegisterByBatch_Detail.rpt")


        Dim DSRpt As New DSPaymentRegister

        Dim dtHead As DataTable = New DSPaymentRegister.dtHeadDataTable
        Dim dtDetail As DataTable = New DSPaymentRegister.dtDetailDataTable

        dtHead = GetDataHead()

        If Not IsNothing(dtHead) AndAlso dtHead.Rows.Count > 0 Then
            DSRpt.Merge(dtHead, True, MissingSchemaAction.Ignore)
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
            Exit Sub
        End If

        dtDetail = GetDataDetail()

        If Not IsNothing(dtDetail) AndAlso dtDetail.Rows.Count > 0 Then
            DSRpt.Merge(dtDetail, True, MissingSchemaAction.Ignore)
        End If

        If Not IsNothing(dtHead) AndAlso dtHead.Rows.Count > 0 Then

            'frm1.FillDataTableToReport(dt)

            frm1.FillDataSetToReport(DSRpt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmPaymentRegisterReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub PrintReportRegister()
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPaymentRegisterByBatch.rpt")


        Dim dtHead As DataTable
        dtHead = GetDataHead()
        dtHead = MaskPanData(dtHead)

        If Not IsNothing(dtHead) AndAlso dtHead.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dtHead)


            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmPaymentRegisterReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub txtDateFrom_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateFrom.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateFrom.Text.Trim = "" Then
                'AutoBindData()
            Else
                Dim dateString As String = txtDateFrom.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    'AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtDateFrom.Text = ""
                    txtDateFrom.Focus()
                    'ClearData()
                End If
            End If

        End If
    End Sub

    Private Sub txtDateTo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateTo.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateTo.Text.Trim = "" Then
                'AutoBindData()
            Else
                Dim dateString As String = txtDateTo.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    'AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtDateTo.Text = ""
                    txtDateTo.Focus()
                    'ClearData()
                End If
            End If

        End If
    End Sub

    Private Sub cboPaymentType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPaymentType.SelectedIndexChanged
        ListStatus()
    End Sub


    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click
        PrintReportRegister()


    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Function MaskingPan(value As String) As String
        Try
            Return value.ToString().Substring(0, 6) & "XXXXXX" & value.Substring(12, 4)
        Catch ex As Exception
            Return value
        End Try
    End Function

    Private Function MaskPanData(dtHead As DataTable) As DataTable
        Try
            Using clsREFID As New UtilityClassLibrary.clsREFIDEnquiry()
                clsREFID.OpenConnecttion()
                Dim dtRefID As DataTable
                For Each dr As DataRow In dtHead.Rows
                    If (dr.Item("PAYG_PAY_GROUPNAME").ToString().Trim().ToUpper() = "CREDIT CARD") Then
                        If (Not dr.IsNull("CHQNO")) Then
                            If (dr("CHQNO").ToString().Length >= 16) Then
                                dtRefID = Nothing
                                dtRefID = clsREFID.GetMaskingPan(dr("CHQNO").ToString())
                                If (dtRefID Is Nothing) Then
                                    dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                                Else
                                    If (dtRefID.Rows.Count > 0) Then
                                        dr("CHQNO") = dtRefID.Rows(0)("Mask").ToString()
                                    Else
                                        dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next
                clsREFID.CloseConnection()
            End Using
        Catch ex As Exception
            'MsgBox(AcceptButton.DialogResult, Global.Microsoft.VisualBasic.MsgBoxStyle.Critical, "Error !!!")
            'MessageBox.Show(ex.Message, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Throw ex
            For Each dr As DataRow In dtHead.Rows
                If (dr.Item("PAYG_PAY_GROUPNAME").ToString().Trim().ToUpper() = "CREDIT CARD") Then
                    dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                End If
            Next
        End Try

        Return dtHead
    End Function

End Class