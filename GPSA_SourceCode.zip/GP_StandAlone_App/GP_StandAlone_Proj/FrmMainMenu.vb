'***********************************************************************************************
'*
'*  Assumptions: ������������������ �ӹǹ�Ż���ª�� FSOV (INPUT OUTPUT DB COMPENSATION)
'*  Purpose: �������㹡��  �ӹǹ�Ż���ª�� FSOV 
'*  Create by:  wassayos wirojwaranuruk
'*  Revisions:  
'*  13/12/2011  1.0.0	wassayos wirojwaranuruk 	Original written
'* 
'************************************************************************************************

'Imports System.Data.OracleClient
Imports System.Reflection
Imports SCBLIFE.StandardFunction.Utility
Imports SCBLife.StandardFunction.Authorization
Imports UtilityClassLibrary
'Imports FSOVSystem.BusObject
Imports SCBLife.Network
Imports SCBLife.Security
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq


Public Class FrmMainMenu

    Private busUtillity As New clsUtility
    Private busAuthority As New clsAuthorization

    Dim GNode As TreeNode  ' Selected Node
    Dim sConn As String
    Dim sStatus As String

    Dim ClsDataWork As New DataClass.clsData_WORK

    Dim sTempworkcode As String
    Dim sTempworkparentcode As String
    Dim sTempworkurl As String
    Dim sTempworktype As String
    Dim sTempworkname As String

    Dim dsMenu As DataSet
    Dim dsFuntbl As DataSet

    Dim sGroupbyUser As String

    Dim mErrorMessage As String

    Private Sub CloseAllChildForm()
        Dim i As Integer
        For i = System.Windows.Forms.Application.OpenForms.Count - 1 To 1 Step -1
            Dim form As Form = System.Windows.Forms.Application.OpenForms(i)
            If form.Name <> "FrmMainMenu" Then
                form.Close()
            End If

        Next i
    End Sub
    Private Sub ControlStyle()
        'Me.MenuStrip1.BackColor = Color.FromArgb(255, 235, 200)
        Me.SplitContainer1.Panel2.BackColor = Color.FromArgb(255, 245, 240)
        tre1.BackColor = Color.FromArgb(240, 240, 240)
        tre1.ForeColor = Color.FromArgb(232, 119, 34)
    End Sub
    Private Sub FrmMainMenu_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Global.System.Windows.Forms.Application.Exit()
    End Sub

    Private Sub FrmMainMenu_Enter(sender As Object, e As System.EventArgs) Handles Me.Enter

    End Sub
    Private Sub FrmMainMenu_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Cursor = Cursors.WaitCursor
        ControlStyle()

        'GetFilePath()
        Me.Text = "GP Stand Alone Version " & Application.ProductVersion

        ''If busAuthority.RightProject(psProjectCode, G_sUDLPath_ADUPS) = False Then
        ''    MessageBox.Show("���ʢͧ�س ������Ѻ�Է��㹡�������ҹ ����� " & psProjectCode, "�š�õ�Ǩ�ͺ", MessageBoxButtons.OK)
        ''    End
        ''End If
        'OpenConnSPI()

        '-- dsFuntbl = ClsDataWork.GetDataSet(G_sUDLPath_ADUPS, psProjectCode)
        '-- dsMenu = ClsDataWork.GetDataSetGroupWork(G_sUDLPath_ADUPS, psProjectCode)

        '-- CAS Interface
        Dim objCASResult As Object = GetMenu_CAS(gUserLogin, CAS_AppName)
        If objCASResult Is Nothing Then
            Cursor = Cursors.Default
            MsgBox("Permission not found!", vbOK, "Warnning")
            Exit Sub
        End If

        dsFuntbl = ObjectToDataSet(objCASResult)
        gUserGroupCode = dsFuntbl.Tables(0).Rows(0)("RoleName").ToString


        'dscorecompen = clsData_CDCS_AGSTRUCTURE.GetDataset(pStrUDLPath_Corecompen)
        'dscompen = clsData_FSOV_FM_MO.GetDataset(pStrUDLPath_Compen)

        Me.WindowState = FormWindowState.Maximized

        'Dim CurrentWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        'Dim CurrentHeight As Integer = Screen.PrimaryScreen.Bounds.Height
        'If CurrentWidth < 1024 OrElse CurrentHeight < 768 Then
        '    MessageBox.Show("��سһ�Ѻ���������´�ͧ���Ҿ ����� 1024*768 ����", "�š�õ�Ǩ�ͺ", MessageBoxButtons.OK)
        '    End
        'End If


        'Update by Pattamalin
        'sGroupbyUser = FindGroupID(busUtillity.GetUserName)

        '-- sGroupbyUser = FindGroupID(dsUser.Tables("VWUSER").Rows(0)("USERSCODE").ToString)

        '-- GetInitNode()
        GetInitNode_CAS(objCASResult)

        '-- G_sUserCode = dsUser.Tables("VWUSER").Rows(0)("USERSCODE").ToString 'busUtillity.GetUserName
        G_sUserCode = gUserLogin

        '-- gUserFullName = dsUser.Tables("VWUSER").Rows(0)("USERSNAME").ToString & " " & dsUser.Tables("VWUSER").Rows(0)("USERSSURNAME").ToString
        ToolStripStatusLabel3.Text = G_sUserCode
        ToolStripStatusLabel5.Text = Now.ToString("dd/MM/yyyy")
        ToolStripStatusLabel7.Text = Now.ToString("hh:mm:ss")
        TS1User.Text = "User Login : " & gUserFullName
        TS1DateTime.Text = "Login Date : " & Now.ToString("dd/MM/yyyy") & "  Login Time : " & Now.ToString("hh:mm:ss")
        TS1Machine.Text = " Computer Name :" & System.Environment.MachineName & " (" & gDSN_GPStandAlone & ") "


        Cursor = Cursors.Default

        '        busAuthority.RightProject(pStrProjectCode, pStrUDLPath)
        '        MnuCalFSOV.Visible = busAuthority.RightMenu("FrmCalAgencyOV", pStrProjectCode, pStrUDLPath) = True

        'Resolution.SetResolution(1024, 768)

    End Sub
    Function FindGroupID(ByVal sUserId As String) As String

        Dim objDr As DataRow()
        Dim stemp As String = ""
        Dim dbli As Double

        objDr = ClsDataWork.GetData_GroupID(G_sUDLPath_ADUPS, sUserId)
        If objDr.Length > 0 Then
            stemp = "("
            For dbli = 0 To UBound(objDr)
                If dbli = 0 Then
                    stemp = stemp & "'" & Trim(CStr(IIf(IsDBNull(objDr(dbli).Item("groupcode")), " ", objDr(dbli).Item("groupcode")))) & "'"
                Else
                    stemp = stemp & ",'" & Trim(CStr(IIf(IsDBNull(objDr(dbli).Item("groupcode")), " ", objDr(dbli).Item("groupcode")))) & "'"
                End If
            Next
            stemp = stemp & ")"
        End If

        FindGroupID = stemp
    End Function
    Sub GetInitNode()

        Dim objclsData_WORK As New DataClass.clsData_WORK
        Dim dbli As Integer
        Dim dr As DataRow()
        Dim N1 As New TreeNode
        dr = objclsData_WORK.GetDataRow_GetIniNode(G_sUDLPath_ADUPS, psProjectCode)
        If dr.Length <= 0 Then
            MsgBox("not found")
        Else
            'dblTtlCount = objDs2.Tables(0).Rows.Count
            For dbli = 0 To UBound(dr)

                N1.Text = CStr(IIf(IsDBNull(dr(dbli).Item("WORKNAME")), " ", dr(dbli).Item("WORKNAME")))

                N1.Tag = CStr(IIf(IsDBNull(dr(dbli).Item("WORKCODE")), " ", dr(dbli).Item("WORKCODE"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("WORKPARENTCODE")), " ", dr(dbli).Item("WORKPARENTCODE"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("WORKNAME")), " ", dr(dbli).Item("WORKNAME"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("WORKURL")), " ", dr(dbli).Item("WORKURL"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("WORKtype")), " ", dr(dbli).Item("WORKtype")))

                N1.ImageIndex = 21
                N1.SelectedImageIndex = 21
                If dbli = 0 Then
                    N1.EnsureVisible()
                    N1.Expand()
                End If
                tre1.Nodes.Add(N1)
            Next
            'GetAllNode(tre1.Nodes(0))
            GetAllNodeByGroup(tre1.Nodes(0))
        End If
        objclsData_WORK = Nothing
    End Sub
    Sub GetAllNodeByGroup(ByVal xNode As TreeNode)
        Dim objclsData_WORK As New DataClass.clsData_WORK
        'Dim dr As DataRow()
        'Dim i As Integer
        If Not xNode Is Nothing Then
            Dim seach_message() As String
            Dim intmsg As Integer
            seach_message = Split(Trim(CStr(xNode.Tag)), "::", -1, CType(1, CompareMethod))
            If UBound(seach_message) >= 0 Then
                For intmsg = 0 To UBound(seach_message)
                    Debug.Print(CStr(intmsg) & seach_message(intmsg))
                    Select Case intmsg
                        Case 0
                            sTempworkcode = Trim(seach_message(intmsg))
                        Case 1
                            sTempworkparentcode = Trim(seach_message(intmsg))
                        Case 2
                            sTempworkname = Trim(seach_message(intmsg))
                    End Select
                Next
            End If
            If xNode.Nodes.Count = 0 Then
                'objClsMT_Funtbl.workcode = strtTempworkcode
                'dr = objClsMT_Funtbl.GetDataRow_GetChild

                Dim objdview As DataView
                Dim objrowview As DataRowView
                Dim ssql As String


                ssql = " workparentcode ='" & REPLACE1CODE(sTempworkcode) & "'"
                objdview = dsFuntbl.Tables(0).DefaultView
                objdview.RowFilter = ssql
                objdview.Sort = "workname"
                For Each objrowview In objdview
                    Dim N1 As New TreeNode


                    N1.Text = CStr(IIf(IsDBNull(objrowview.Item("workname")), " ", objrowview.Item("workname"))) & " "
                    N1.Tag = CStr(IIf(IsDBNull(objrowview.Item("workcode")), " ", objrowview.Item("workcode"))) & "::" & _
                                CStr(IIf(IsDBNull(objrowview.Item("workparentcode")), " ", objrowview.Item("workparentcode"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("workname")), " ", objrowview.Item("workname"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("workurl")), " ", objrowview.Item("workurl"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("worktype")), " ", objrowview.Item("worktype")))

                    If CStr(IIf(IsDBNull(objrowview.Item("workcode")), " ", objrowview.Item("workcode"))) = "0017" Then
                        Debug.Print("qq")

                    End If


                    If ClsDataWork.Find_Funcid_FIX(sGroupbyUser, CStr(IIf(IsDBNull(objrowview.Item("workcode")), " ", objrowview.Item("workcode"))), dsMenu) Then

                        N1.Checked = True
                        If objrowview.Item("worktype").ToString = "G" Then
                            N1.ImageIndex = 13
                            N1.SelectedImageIndex = 16
                        ElseIf objrowview.Item("worktype").ToString = "F" Then
                            N1.ImageIndex = 18
                            N1.SelectedImageIndex = 17
                        ElseIf objrowview.Item("worktype").ToString = "R" Then
                            N1.ImageIndex = 20
                            N1.SelectedImageIndex = 19
                        End If
                        xNode.Nodes.Add(N1)

                    Else
                        If objrowview.Item("worktype").ToString = "G" Then
                            N1.ImageIndex = 13
                            N1.SelectedImageIndex = 16
                        ElseIf objrowview.Item("worktype").ToString = "F" Then
                            N1.ImageIndex = 18
                            N1.SelectedImageIndex = 17
                        ElseIf objrowview.Item("worktype").ToString = "R" Then
                            N1.ImageIndex = 20
                            N1.SelectedImageIndex = 19
                        End If

                    End If

                    'N1.Checked = True
                    'If objrowview.Item("worktype").ToString = "G" Then
                    '    N1.ImageIndex = 2
                    '    N1.SelectedImageIndex = 3
                    'ElseIf objrowview.Item("worktype").ToString = "F" Then
                    '    N1.ImageIndex = 8
                    '    N1.SelectedImageIndex = 9
                    'ElseIf objrowview.Item("worktype").ToString = "R" Then
                    '    N1.ImageIndex = 11
                    '    N1.SelectedImageIndex = 10
                    'End If
                    'xNode.Nodes.Add(N1)


                    'End If
                    Application.DoEvents()
                Next


            End If
            'recursive
            If xNode.Nodes.Count > 0 Then
                Dim N2 As TreeNode = xNode.Nodes(0)
                Me.GetAllNodeByGroup(N2)
            End If
            xNode = xNode.NextNode
            If Not xNode Is Nothing Then
                Me.GetAllNodeByGroup(xNode)
            End If

        End If
        Application.DoEvents()
        objclsData_WORK = Nothing
        'dsMenu.Dispose()
        dsFuntbl.Dispose()
    End Sub
    Sub GetAllNode(ByVal xNode As TreeNode)
        Dim objclsData_WORK As New DataClass.clsData_WORK
        Dim dr As DataRow()
        Dim dbli As Integer


        If Not xNode Is Nothing Then
            Dim seach_message() As String
            Dim intmsg As Integer
            seach_message = Split(Trim(CStr(xNode.Tag)), "::", -1, CType(1, CompareMethod))
            If UBound(seach_message) >= 0 Then
                For intmsg = 0 To UBound(seach_message)
                    Debug.Print(CStr(intmsg) & seach_message(intmsg))
                    Select Case intmsg
                        Case 0
                            sTempworkcode = Trim(seach_message(intmsg))
                        Case 1
                            sTempworkparentcode = Trim(seach_message(intmsg))
                        Case 2
                            sTempworkname = Trim(seach_message(intmsg))
                    End Select
                Next
            End If


            If xNode.Nodes.Count = 0 Then
                dr = objclsData_WORK.GetDataRow_GetChild(sTempworkcode, G_sUDLPath_ADUPS, psProjectCode)
                If dr.Length <= 0 Then

                Else
                    For dbli = 0 To UBound(dr)
                        Dim N1 As New TreeNode
                        N1.Text = CStr(IIf(IsDBNull(dr(dbli).Item("workname")), " ", dr(dbli).Item("workname"))) & " "


                        N1.Tag = CStr(IIf(IsDBNull(dr(dbli).Item("workcode")), " ", dr(dbli).Item("workcode"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("workparentcode")), " ", dr(dbli).Item("workparentcode"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("workname")), " ", dr(dbli).Item("workname"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("FunCodeName")), " ", dr(dbli).Item("FunCodeName"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("worktype")), " ", dr(dbli).Item("worktype")))

                        If dr(dbli).Item("worktype").ToString = "G" Then
                            N1.ImageIndex = 2
                            N1.SelectedImageIndex = 3
                        ElseIf dr(dbli).Item("worktype").ToString = "F" Then
                            N1.ImageIndex = 8
                            N1.SelectedImageIndex = 9
                        ElseIf dr(dbli).Item("worktype").ToString = "R" Then
                            N1.ImageIndex = 11
                            N1.SelectedImageIndex = 10
                        End If



                        'N1.ImageIndex = 2
                        'N1.SelectedImageIndex = 3
                        xNode.Nodes.Add(N1)
                        'xNode.Expand()
                    Next
                End If
            End If

            'recursive
            If xNode.Nodes.Count > 0 Then
                Dim N2 As TreeNode = xNode.Nodes(0)
                Me.GetAllNode(N2)
            End If
            xNode = xNode.NextNode
            If Not xNode Is Nothing Then
                Me.GetAllNode(xNode)
            End If
        End If
        objclsData_WORK = Nothing
    End Sub
    Public Function REPLACE1CODE(ByVal sName As String) As String
        Return Replace(Trim(sName), "'", "''")
    End Function

    Private Sub tre1_AfterSelect_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tre1.AfterSelect
        Cursor = Cursors.WaitCursor
        GNode = e.Node
        TextBox1.Text = CStr(GNode.Tag)

        Dim seach_message() As String
        Dim intmsg As Integer
        seach_message = Split(Trim(CStr(GNode.Tag)), "::", -1, CType(1, CompareMethod))
        If UBound(CType(seach_message, Array)) >= 0 Then
            For intmsg = 0 To UBound(CType(seach_message, Array))
                Select Case intmsg
                    Case 0
                        sTempworkcode = Trim(seach_message(intmsg))
                    Case 1
                        sTempworkparentcode = Trim(seach_message(intmsg))
                    Case 2
                        sTempworkname = Trim(seach_message(intmsg))
                    Case 3
                        sTempworkurl = Trim(seach_message(intmsg))
                    Case 4
                        sTempworktype = Trim(seach_message(intmsg))
                End Select
            Next
            'objClsMT_Funtbl.workparentcode = strtTempworkparentcode
            'objClsMT_Funtbl.Get_Parent()
        End If
        'GetAllNodeByGroup2(e.Node)
        Cursor = Cursors.Default

    End Sub
    Public Class ObjectFinder
        Public Shared Function CreateObjectInstance(ByVal objectName As String) As Object
            ' Creates and returns an instance of any object in the assembly by its type name.

            Dim obj As Object

            Try
                If objectName.LastIndexOf(".") = -1 Then
                    'Appends the root namespace if not specified.
                    objectName = [Assembly].GetEntryAssembly.GetName.Name & "." & objectName
                End If

                obj = [Assembly].GetEntryAssembly.CreateInstance(objectName)

            Catch ex As Exception
                obj = Nothing
            End Try
            Return obj

        End Function

        Public Shared Function CreateForm(ByVal formName As String) As Form
            ' Return the instance of the form by specifying its name.
            Return DirectCast(CreateObjectInstance(formName), Form)
        End Function

    End Class
    Private Sub tre1_DoubleClick1(ByVal sender As Object, ByVal e As System.EventArgs) Handles tre1.DoubleClick

        'Dim dr As DataRow()
        'Dim i As Integer
        If Not GNode Is Nothing Then
            'Dim X As String = Mid(CStr(GNode.Tag), 1, 1)
            Dim seach_message() As String
            Dim intmsg As Integer
            seach_message = Split(Trim(CStr(GNode.Tag)), "::", -1, CType(1, CompareMethod))
            If UBound(seach_message) >= 0 Then
                For intmsg = 0 To UBound(seach_message)
                    Debug.Print(CStr(intmsg) & seach_message(intmsg))
                    Select Case intmsg
                        Case 0
                            sTempworkcode = Trim(seach_message(intmsg))
                        Case 1
                            sTempworkparentcode = Trim(seach_message(intmsg))
                        Case 2
                            sTempworkname = Trim(seach_message(intmsg))
                        Case 3
                            sTempworkurl = Trim(seach_message(intmsg))
                        Case 4
                            sTempworktype = Trim(seach_message(intmsg))
                    End Select
                Next
            End If


            If sTempworktype = "F" Then
                Try

                    Dim frm As Form
                    frm = ObjectFinder.CreateForm(sTempworkurl)

                    Me.CloseAllChildForm()
                    With frm
                        .Icon = Icon.Clone()
                        .WindowState = FormWindowState.Maximized
                        .Text = sTempworkname & "(" & sTempworkurl & ")"
                        .TopLevel = False
                        .Parent = SplitContainer1.Panel2
                        .Dock = DockStyle.Fill
                        Me.SplitContainer1.Panel2.Controls.Add(frm)
                        .Show()
                    End With
                    frm = Nothing

                Catch ex As Exception

                End Try

            End If

            If sTempworktype = "R" Then

                Try

                    Dim frm As Form
                    frm = ObjectFinder.CreateForm(sTempworkurl)

                    Me.CloseAllChildForm()
                    With frm
                        .Text = sTempworkname & "(" & sTempworkurl & ")"
                        .StartPosition = FormStartPosition.CenterParent
                        .ShowDialog(Me)
                    End With
                    frm = Nothing

                Catch ex As Exception

                End Try

                '----------------Old Version-----------------
                'Dim seach_messagerpt() As String
                'Dim strtTemp_Rpt As String = ""
                'seach_messagerpt = Split(Trim(CStr(sTempworkurl)), "|", -1, CType(1, CompareMethod))

                'If UBound(seach_messagerpt) >= 0 Then
                '    For intmsg = 0 To UBound(seach_messagerpt)
                '        Debug.Print(CStr(intmsg) & seach_messagerpt(intmsg))
                '        Select Case intmsg
                '            Case 0
                '                sTempworkname = Trim(seach_messagerpt(intmsg))
                '            Case 1
                '                strtTemp_Rpt = Trim(seach_messagerpt(intmsg))
                '        End Select
                '    Next
                'End If
                'Select Case UCase(sTempworkname)
                '    Case "FRMREPORT"
                '        Dim frm As New FrmPaymentCreationProcess
                '        Me.CloseAllChildForm()
                '        With frm
                '            .Icon = Icon.Clone()
                '            .Text = Trim(seach_message(intmsg))
                '            .TopLevel = False
                '            .Anchor = AnchorStyles.Left And AnchorStyles.Top And AnchorStyles.Right And AnchorStyles.Bottom
                '            .Parent = SplitContainer1.Panel2
                '            .Dock = DockStyle.Fill
                '            SplitContainer1.Panel1Collapsed = True
                '            EXITToolStripMenuItem.Text = "Show Menu"
                '            Me.SplitContainer1.Panel2.Controls.Add(frm)
                '            .Show()
                '        End With
                '        frm = Nothing
                '    Case "FRMREPORTBYROUND"
                '        Dim frm As New FrmDailyReport
                '        Me.CloseAllChildForm()
                '        With frm
                '            .Text = Trim(seach_message(intmsg))
                '            .ShowDialog(Me)
                '        End With
                '        frm = Nothing
                'End Select

            End If
        End If
    End Sub
    Private Sub ExitProgram()
        If MessageBox.Show("Exit program [y/n] ?:", "Confirm..!", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then Exit Sub
        If Not Logout_CAS() Then
            MsgBox(mErrorMessage, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        Global.System.Windows.Forms.Application.Exit()
    End Sub
    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        'ExitProgram()
        If SplitContainer1.Panel1Collapsed Then
            SplitContainer1.Panel1Collapsed = False
            EXITToolStripMenuItem.Text = "Hide Menu"
        Else
            SplitContainer1.Panel1Collapsed = True
            EXITToolStripMenuItem.Text = "Show Menu"
        End If
    End Sub

    Private Sub TSLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TSLogOut.Click
        ExitProgram()
    End Sub

    Private Sub tre1_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles tre1.KeyPress
        If e.KeyChar = Convert.ToChar(13) Then
            If Not GNode Is Nothing Then
                'Dim X As String = Mid(CStr(GNode.Tag), 1, 1)
                Dim seach_message() As String
                Dim intmsg As Integer
                seach_message = Split(Trim(CStr(GNode.Tag)), "::", -1, CType(1, CompareMethod))
                If UBound(seach_message) >= 0 Then
                    For intmsg = 0 To UBound(seach_message)
                        Debug.Print(CStr(intmsg) & seach_message(intmsg))
                        Select Case intmsg
                            Case 0
                                sTempworkcode = Trim(seach_message(intmsg))
                            Case 1
                                sTempworkparentcode = Trim(seach_message(intmsg))
                            Case 2
                                sTempworkname = Trim(seach_message(intmsg))
                            Case 3
                                sTempworkurl = Trim(seach_message(intmsg))
                            Case 4
                                sTempworktype = Trim(seach_message(intmsg))
                        End Select
                    Next
                End If


                If sTempworktype = "F" Then
                    Try

                        Dim frm As Form
                        frm = ObjectFinder.CreateForm(sTempworkurl)

                        Me.CloseAllChildForm()
                        With frm
                            .Icon = Icon.Clone()
                            .WindowState = FormWindowState.Maximized
                            .Text = sTempworkname & "(" & sTempworkurl & ")"
                            .TopLevel = False
                            .Parent = SplitContainer1.Panel2
                            .Dock = DockStyle.Fill
                            Me.SplitContainer1.Panel2.Controls.Add(frm)
                            .Show()
                        End With
                        frm = Nothing

                    Catch ex As Exception

                    End Try

                End If

                If sTempworktype = "R" Then

                    Try

                        Dim frm As Form
                        frm = ObjectFinder.CreateForm(sTempworkurl)

                        Me.CloseAllChildForm()
                        With frm
                            .Text = sTempworkname & "(" & sTempworkurl & ")"
                            .StartPosition = FormStartPosition.CenterParent
                            .ShowDialog(Me)
                        End With
                        frm = Nothing

                    Catch ex As Exception

                    End Try


                End If
            End If
        End If
    End Sub

    Private Function GetMenu_CAS(ByRef strUserName As String, ByRef strAppName As String) As Object
        Try

            Dim dicData As New Dictionary(Of String, Object)()
            dicData.Add("MethodName", "GetMenuPermission")
            dicData.Add("UserName", strUserName)
            dicData.Add("ApplicationName", CAS_AppName)

            Dim strJsonRequest As String = JsonConvert.SerializeObject(dicData)
            ' CASWS Dev    = "http://10.38.3.92/MyService/WebApi/CASService.aspx"
            ' CASWS UAT    = "http://casws/WebApi/CASService.aspx"
            ' CASWS PROD   = "http://casws/WebApi/CASService.aspx"
            Dim CASWS As String = System.Configuration.ConfigurationManager.AppSettings("CASWS").ToString()
            Dim strResult As String = HttpUtil.Post(CASWS, strJsonRequest)
            Dim objResult As Dictionary(Of String, Object) = Nothing
            objResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strResult)
            If objResult("StatusCode").ToString() = "200" Then
                Dim lstMenuList As List(Of Object) = DirectCast(Newtonsoft.Json.JsonConvert.DeserializeObject(objResult("Message").ToString(), GetType(List(Of Object))), List(Of Object))
                Return lstMenuList
            Else
                MessageBox.Show(objResult("StatusCode").ToString & vbCrLf & objResult("Message").ToString(), objResult("Status").ToString())
                Return Nothing
            End If


        Catch ex As Exception
            mErrorMessage = ex.ToString
            Return Nothing
        End Try

    End Function

    Private Function ObjectToDataSet(ByRef lstObject As List(Of Object)) As DataSet
        Try
            Dim dsTemp As New DataSet
            Dim dtTemp As New DataTable
            With dtTemp
                .Columns.Add("RolePermissionID")
                .Columns.Add("MenuID")
                .Columns.Add("RoleID")
                .Columns.Add("RoleName")
                .Columns.Add("RoleDescr")
                .Columns.Add("UserID")
                .Columns.Add("UserName")
                .Columns.Add("ParentID")
                .Columns.Add("ModuleName")
                .Columns.Add("MenuName")
                .Columns.Add("PageUrl")
                .Columns.Add("IconUrl")
                .Columns.Add("Ordinary")
                .Columns.Add("ApplicationName")
                .Columns.Add("Permission")
                .Columns.Add("CanRead")
            End With
            Dim objMenu As Object
            For Each objMenu In lstObject
                Dim row As DataRow = dtTemp.NewRow
                row(0) = objMenu("RolePermissionID")
                row(1) = objMenu("MenuID")
                row(2) = objMenu("RoleID")
                row(3) = objMenu("RoleName")
                row(4) = objMenu("RoleDescr")
                row(5) = objMenu("UserID")
                row(6) = objMenu("UserName")
                row(7) = objMenu("ParentID")
                row(8) = objMenu("ModuleName")
                row(9) = objMenu("MenuName")
                row(10) = objMenu("PageUrl")
                row(11) = objMenu("IconUrl")
                row(12) = objMenu("Ordinary")
                row(13) = objMenu("ApplicationName")
                row(14) = objMenu("Permission")
                row(15) = objMenu("CanRead")
                dtTemp.Rows.Add(row)
            Next
            dsTemp.Tables.Add(dtTemp)
            Return dsTemp
        Catch ex As Exception
            mErrorMessage = ex.ToString
            Return Nothing
        End Try
    End Function

    Private Sub GernerateMenuTreeFirstLevel_CAS(ByVal lstMenuList As List(Of Object))
        Try
            Dim Node As TreeNode
            Dim dt As New DataTable
            dt = ObjectToDataSet(lstMenuList).Tables(0)
            dt.DefaultView.Sort = "MenuName"
            '-- dt.DefaultView.Sort
        Catch ex As Exception
            mErrorMessage = ex.ToString
        End Try
    End Sub

    Private Sub GernerateMenuTreeOtherLevel_CAS(ByVal lstMenuList As List(Of Object), strMenuParentID As String)
        Try
            Dim Node As TreeNode
            Dim dtTemp As New DataTable
            Dim dvTemp As New DataView
            dtTemp = ObjectToDataSet(lstMenuList).Tables(0)
            dvTemp = dtTemp.DefaultView
            dvTemp.RowFilter = " workparentcode = '" & REPLACE1CODE(strMenuParentID) & "'"
            dvTemp.Sort = "workname"

        Catch ex As Exception
            mErrorMessage = ex.ToString
        End Try
    End Sub

    Sub GetInitNode_CAS(ByVal lstMenuList As List(Of Object))

        '--Dim objclsData_WORK As New DataClass.clsData_WORK
        Dim dbli As Integer
        Dim dr As DataRow()
        Dim dtTemp As DataTable
        Dim N1 As New TreeNode
        '--dr = objclsData_WORK.GetDataRow_GetIniNode(G_sUDLPath_ADUPS, psProjectCode)
        dtTemp = ObjectToDataSet(lstMenuList).Tables(0)
        dr = dtTemp.Select
        If dr.Length <= 0 Then
            MsgBox("not found")
        Else
            'dblTtlCount = objDs2.Tables(0).Rows.Count
            For dbli = 0 To 0 '-- UBound(dr)

                N1.Text = CStr(IIf(IsDBNull(dr(dbli).Item("MENUNAME")), " ", dr(dbli).Item("MENUNAME")))

                N1.Tag = CStr(IIf(IsDBNull(dr(dbli).Item("MENUID")), " ", dr(dbli).Item("MENUID"))) & "::" & _
                            CStr(IIf(IsDBNull(dr(dbli).Item("ParentID")), " ", dr(dbli).Item("ParentID"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("MENUNAME")), " ", dr(dbli).Item("MENUNAME"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("PageUrl")), " ", dr(dbli).Item("PageUrl"))) & "::" & _
                CStr(IIf(IsDBNull(dr(dbli).Item("IconUrl")), " ", dr(dbli).Item("IconUrl")))

                N1.ImageIndex = 21
                N1.SelectedImageIndex = 21
                If dbli = 0 Then
                    N1.EnsureVisible()
                    N1.Expand()
                End If
                tre1.Nodes.Add(N1)
            Next
            'GetAllNode(tre1.Nodes(0))
            GetAllNodeByGroup_CAS(tre1.Nodes(0))
        End If
        '--objclsData_WORK = Nothing
    End Sub

    Sub GetAllNodeByGroup_CAS(ByVal xNode As TreeNode)
        Dim objclsData_WORK As New DataClass.clsData_WORK
        'Dim dr As DataRow()
        'Dim i As Integer
        If Not xNode Is Nothing Then
            Dim seach_message() As String
            Dim intmsg As Integer
            seach_message = Split(Trim(CStr(xNode.Tag)), "::", -1, CType(1, CompareMethod))
            If UBound(seach_message) >= 0 Then
                For intmsg = 0 To UBound(seach_message)
                    Debug.Print(CStr(intmsg) & seach_message(intmsg))
                    Select Case intmsg
                        Case 0
                            sTempworkcode = Trim(seach_message(intmsg))
                        Case 1
                            sTempworkparentcode = Trim(seach_message(intmsg))
                        Case 2
                            sTempworkname = Trim(seach_message(intmsg))
                    End Select
                Next
            End If
            If xNode.Nodes.Count = 0 Then
                'objClsMT_Funtbl.workcode = strtTempworkcode
                'dr = objClsMT_Funtbl.GetDataRow_GetChild

                Dim objdview As DataView
                Dim objrowview As DataRowView
                Dim ssql As String


                ssql = " ParentID ='" & REPLACE1CODE(sTempworkcode) & "'"
                objdview = dsFuntbl.Tables(0).DefaultView
                objdview.RowFilter = ssql
                objdview.Sort = "MENUNAME"
                For Each objrowview In objdview
                    Dim N1 As New TreeNode


                    N1.Text = CStr(IIf(IsDBNull(objrowview.Item("MENUNAME")), " ", objrowview.Item("MENUNAME"))) & " "
                    N1.Tag = CStr(IIf(IsDBNull(objrowview.Item("MENUID")), " ", objrowview.Item("MENUID"))) & "::" & _
                                CStr(IIf(IsDBNull(objrowview.Item("ParentID")), " ", objrowview.Item("ParentID"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("MENUNAME")), " ", objrowview.Item("MENUNAME"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("PageUrl")), " ", objrowview.Item("PageUrl"))) & "::" & _
                    CStr(IIf(IsDBNull(objrowview.Item("IconUrl")), " ", objrowview.Item("IconUrl")))


                    ''If ClsDataWork.Find_Funcid_FIX(sGroupbyUser, CStr(IIf(IsDBNull(objrowview.Item("MENUID")), " ", objrowview.Item("MENUID"))), dsMenu) Then

                    ''    N1.Checked = True
                    ''    If objrowview.Item("worktype").ToString = "G" Then
                    ''        N1.ImageIndex = 13
                    ''        N1.SelectedImageIndex = 16
                    ''    ElseIf objrowview.Item("worktype").ToString = "F" Then
                    ''        N1.ImageIndex = 18
                    ''        N1.SelectedImageIndex = 17
                    ''    ElseIf objrowview.Item("worktype").ToString = "R" Then
                    ''        N1.ImageIndex = 20
                    ''        N1.SelectedImageIndex = 19
                    ''    End If
                    ''    xNode.Nodes.Add(N1)

                    ''Else
                    ''    If objrowview.Item("worktype").ToString = "G" Then
                    ''        N1.ImageIndex = 13
                    ''        N1.SelectedImageIndex = 16
                    ''    ElseIf objrowview.Item("worktype").ToString = "F" Then
                    ''        N1.ImageIndex = 18
                    ''        N1.SelectedImageIndex = 17
                    ''    ElseIf objrowview.Item("worktype").ToString = "R" Then
                    ''        N1.ImageIndex = 20
                    ''        N1.SelectedImageIndex = 19
                    ''    End If

                    ''End If

                    N1.Checked = True
                    If objrowview.Item("IconUrl").ToString = "G" Then
                        N1.ImageIndex = 13
                        N1.SelectedImageIndex = 16
                    ElseIf objrowview.Item("IconUrl").ToString = "F" Then
                        N1.ImageIndex = 18
                        N1.SelectedImageIndex = 17
                    ElseIf objrowview.Item("IconUrl").ToString = "R" Then
                        N1.ImageIndex = 20
                        N1.SelectedImageIndex = 19
                    Else
                        N1.ImageIndex = 13
                        N1.SelectedImageIndex = 16
                    End If
                    xNode.Nodes.Add(N1)


                    'End If
                    Application.DoEvents()
                Next


            End If
            'recursive
            If xNode.Nodes.Count > 0 Then
                Dim N2 As TreeNode = xNode.Nodes(0)
                Me.GetAllNodeByGroup_CAS(N2)
            End If
            xNode = xNode.NextNode
            If Not xNode Is Nothing Then
                Me.GetAllNodeByGroup_CAS(xNode)
            End If

        End If
        Application.DoEvents()
        objclsData_WORK = Nothing
        'dsMenu.Dispose()
        dsFuntbl.Dispose()
    End Sub

    Private Function Logout_CAS() As Boolean
        '----Dim strStep As String
        Try

            Dim dicData As New Dictionary(Of String, Object)()
            dicData.Add("MethodName", "Logout")
            dicData.Add("SessionID", CAS_objSession("TokenKey").ToString)
            dicData.Add("ApplicationName", CAS_AppName)
            dicData.Add("Application", CAS_AppTitle)
            dicData.Add("UserName", gUserLogin)
            '----strStep = "1"
            Dim strJsonRequest As String = JsonConvert.SerializeObject(dicData)

            ' CASWS Dev    = "http://10.38.3.92/MyService/WebApi/CASService.aspx"
            ' CASWS UAT    = "http://casws/WebApi/CASService.aspx"
            ' CASWS PROD   = "http://casws/WebApi/CASService.aspx"
            '--Dim CASWS As String = System.Configuration.ConfigurationManager.AppSettings("CASWS").ToString()
            '----strStep = "2"
            Dim strResult As String = HttpUtil.Post(CAS_CASWS, strJsonRequest)
            '----strStep = "3"
            Dim objResult As Dictionary(Of String, Object) = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strResult)

            '----strStep = "4"
            mErrorMessage = objResult("Message").ToString()
            If objResult("StatusCode").ToString() = "200" Then
                Return True
            Else
                '----MsgBox(strStep & vbCrLf & strResult)
                Return False
            End If

        Catch ex As Exception
            '----MsgBox(strStep & vbCrLf & ex.ToString)
            mErrorMessage = ex.ToString
            Return False
        End Try

    End Function

End Class