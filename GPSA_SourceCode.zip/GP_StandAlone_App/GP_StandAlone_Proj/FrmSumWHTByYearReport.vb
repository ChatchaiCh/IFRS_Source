Imports UtilityClassLibrary
Public Class FrmSumWHTByYearReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsWHT
    Private Sub FrmSumWHTByYearReport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListPhorNgorDor()
        ListYear()
        
    End Sub
    Private Sub ListPhorNgorDor()
        cboPhorNgorDor.Items.Add("��� 2")
        cboPhorNgorDor.Items.Add("��� 3")
        cboPhorNgorDor.Items.Add("��� 53")
        cboPhorNgorDor.SelectedIndex = 0
    End Sub
    Private Sub ListYear()
        Dim i As Integer
        'cboYear.Items.Insert(0, "---Select Year---")
        For i = DateTime.Now.Year - 5 To DateTime.Now.Year
            cboYear.Items.Add(i)
        Next
        cboYear.Text = Now.Year
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim phorngordor As String = ""
        Select Case cboPhorNgorDor.Text.Trim
            Case "��� 2"
                phorngordor = "02"
            Case "��� 3"
                phorngordor = "03"
            Case "��� 53"
                phorngordor = "53"
        End Select
        PrintReport(cboYear.Text, phorngordor)
    End Sub
    Private Sub PrintReport(ByVal year As String, ByVal phorngordor As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryWHTByYear.rpt")

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataWHTByYear(clsUtility.gConnGP, year, phorngordor)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pTaxType"
            discrete1.Value = phorngordor
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pYear"
            discrete2.Value = Now.Year
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub

  
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class