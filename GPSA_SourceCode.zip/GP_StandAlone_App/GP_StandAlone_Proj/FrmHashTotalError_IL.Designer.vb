﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmHashTotalError_IL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnAddFile = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTotalAmtIL = New System.Windows.Forms.TextBox()
        Me.dgvFile = New System.Windows.Forms.DataGridView()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnAuto = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.txtBrowseFile = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtTotalAmtLO = New System.Windows.Forms.TextBox()
        Me.dgvLo = New System.Windows.Forms.DataGridView()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnRejectFile = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvFile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.dgvLo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(287, 16)
        Me.Label1.TabIndex = 90
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(15, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(904, 53)
        Me.Label2.TabIndex = 91
        Me.Label2.Text = "Reject Payment Transaction - Hash Total Error && LO Cancel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Integral Life)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.btnAddFile)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.txtTotalAmtIL)
        Me.Panel1.Controls.Add(Me.dgvFile)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Location = New System.Drawing.Point(15, 82)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(904, 234)
        Me.Panel1.TabIndex = 92
        '
        'btnAddFile
        '
        Me.btnAddFile.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAddFile.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnAddFile.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAddFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnAddFile.ForeColor = System.Drawing.Color.Black
        Me.btnAddFile.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnAddFile.Image = Nothing
        Me.btnAddFile.ImageKey = ""
        Me.btnAddFile.ImageList = Nothing
        Me.btnAddFile.Location = New System.Drawing.Point(124, 21)
        Me.btnAddFile.Name = "btnAddFile"
        Me.btnAddFile.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAddFile.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAddFile.Size = New System.Drawing.Size(81, 23)
        Me.btnAddFile.TabIndex = 1
        Me.btnAddFile.Text = "Search"
        Me.btnAddFile.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Hash Total Error"
        '
        'txtTotalAmtIL
        '
        Me.txtTotalAmtIL.Location = New System.Drawing.Point(767, 200)
        Me.txtTotalAmtIL.Name = "txtTotalAmtIL"
        Me.txtTotalAmtIL.ReadOnly = True
        Me.txtTotalAmtIL.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalAmtIL.TabIndex = 3
        '
        'dgvFile
        '
        Me.dgvFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvFile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFile.Location = New System.Drawing.Point(7, 49)
        Me.dgvFile.Name = "dgvFile"
        Me.dgvFile.Size = New System.Drawing.Size(894, 145)
        Me.dgvFile.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(873, 203)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(26, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "บาท"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(692, 203)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Total Amount"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "ระบุชื่อไฟล์ / LineNo"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.btnAuto)
        Me.Panel2.Controls.Add(Me.txtBrowseFile)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.txtTotalAmtLO)
        Me.Panel2.Controls.Add(Me.dgvLo)
        Me.Panel2.Controls.Add(Me.TextBox2)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Location = New System.Drawing.Point(15, 322)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(904, 229)
        Me.Panel2.TabIndex = 93
        '
        'btnAuto
        '
        Me.btnAuto.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAuto.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnAuto.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAuto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnAuto.ForeColor = System.Drawing.Color.Black
        Me.btnAuto.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnAuto.Image = Nothing
        Me.btnAuto.ImageKey = ""
        Me.btnAuto.ImageList = Nothing
        Me.btnAuto.Location = New System.Drawing.Point(814, 15)
        Me.btnAuto.Name = "btnAuto"
        Me.btnAuto.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAuto.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnAuto.Size = New System.Drawing.Size(85, 23)
        Me.btnAuto.TabIndex = 7
        Me.btnAuto.Text = "Auto"
        Me.btnAuto.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'txtBrowseFile
        '
        Me.txtBrowseFile.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.txtBrowseFile.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.txtBrowseFile.DialogResult = System.Windows.Forms.DialogResult.None
        Me.txtBrowseFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBrowseFile.ForeColor = System.Drawing.Color.Black
        Me.txtBrowseFile.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.txtBrowseFile.Image = Nothing
        Me.txtBrowseFile.ImageKey = ""
        Me.txtBrowseFile.ImageList = Nothing
        Me.txtBrowseFile.Location = New System.Drawing.Point(814, 44)
        Me.txtBrowseFile.Name = "txtBrowseFile"
        Me.txtBrowseFile.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.txtBrowseFile.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.txtBrowseFile.Size = New System.Drawing.Size(85, 23)
        Me.txtBrowseFile.TabIndex = 5
        Me.txtBrowseFile.Text = "Browse"
        Me.txtBrowseFile.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.txtBrowseFile.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.Location = New System.Drawing.Point(3, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "LO Cancel"
        '
        'txtTotalAmtLO
        '
        Me.txtTotalAmtLO.Location = New System.Drawing.Point(763, 196)
        Me.txtTotalAmtLO.Name = "txtTotalAmtLO"
        Me.txtTotalAmtLO.ReadOnly = True
        Me.txtTotalAmtLO.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalAmtLO.TabIndex = 6
        '
        'dgvLo
        '
        Me.dgvLo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvLo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLo.Location = New System.Drawing.Point(7, 46)
        Me.dgvLo.Name = "dgvLo"
        Me.dgvLo.Size = New System.Drawing.Size(894, 144)
        Me.dgvLo.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(68, 18)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(745, 20)
        Me.TextBox2.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(868, 199)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(26, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "บาท"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Load File : "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(687, 199)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Total Amount"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnConfirm
        '
        Me.btnConfirm.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnConfirm.ForeColor = System.Drawing.Color.White
        Me.btnConfirm.Location = New System.Drawing.Point(503, 557)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(139, 28)
        Me.btnConfirm.TabIndex = 10
        Me.btnConfirm.Text = "Confirm Auto FTP"
        Me.btnConfirm.UseVisualStyleBackColor = False
        '
        'BtnCancel
        '
        Me.BtnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.BtnCancel.ForeColor = System.Drawing.Color.White
        Me.BtnCancel.Location = New System.Drawing.Point(648, 557)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(139, 28)
        Me.BtnCancel.TabIndex = 94
        Me.BtnCancel.Text = "Cancel Auto FTP"
        Me.BtnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(307, 557)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.Size = New System.Drawing.Size(92, 28)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnClear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(208, 557)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnRejectFile
        '
        Me.btnRejectFile.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnRejectFile.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnRejectFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnRejectFile.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRejectFile.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnRejectFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnRejectFile.ForeColor = System.Drawing.Color.White
        Me.btnRejectFile.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnRejectFile.Image = Nothing
        Me.btnRejectFile.ImageKey = ""
        Me.btnRejectFile.ImageList = Nothing
        Me.btnRejectFile.Location = New System.Drawing.Point(26, 557)
        Me.btnRejectFile.Name = "btnRejectFile"
        Me.btnRejectFile.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnRejectFile.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnRejectFile.Size = New System.Drawing.Size(176, 28)
        Me.btnRejectFile.TabIndex = 7
        Me.btnRejectFile.Text = "Reject/Regen File"
        Me.btnRejectFile.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnRejectFile.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmHashTotalError_IL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(931, 604)
        Me.Controls.Add(Me.BtnCancel)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnRejectFile)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmHashTotalError_IL"
        Me.Text = "Reject Payment Transaction - Hash Total Error & LO Cancel(Integral Life)"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgvFile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.dgvLo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dgvFile As System.Windows.Forms.DataGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dgvLo As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtTotalAmtLO As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnRejectFile As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnAddFile As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtBrowseFile As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Public WithEvents txtTotalAmtIL As System.Windows.Forms.TextBox
    Friend WithEvents btnAuto As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnConfirm As System.Windows.Forms.Button
    Friend WithEvents BtnCancel As System.Windows.Forms.Button
End Class
