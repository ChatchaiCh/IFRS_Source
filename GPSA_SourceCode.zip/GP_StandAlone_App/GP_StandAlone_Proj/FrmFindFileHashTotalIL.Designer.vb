﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFindFileHashTotalIL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvFindFile = New System.Windows.Forms.DataGridView()
        Me.btnConfirm = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        CType(Me.dgvFindFile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvFindFile
        '
        Me.dgvFindFile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFindFile.Location = New System.Drawing.Point(24, 13)
        Me.dgvFindFile.Name = "dgvFindFile"
        Me.dgvFindFile.Size = New System.Drawing.Size(424, 251)
        Me.dgvFindFile.TabIndex = 0
        '
        'btnConfirm
        '
        Me.btnConfirm.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConfirm.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnConfirm.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnConfirm.ForeColor = System.Drawing.Color.Black
        Me.btnConfirm.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnConfirm.Image = Nothing
        Me.btnConfirm.ImageKey = ""
        Me.btnConfirm.ImageList = Nothing
        Me.btnConfirm.Location = New System.Drawing.Point(277, 279)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConfirm.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConfirm.Size = New System.Drawing.Size(75, 23)
        Me.btnConfirm.TabIndex = 78
        Me.btnConfirm.Text = "Confirm"
        Me.btnConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnConfirm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Black
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(373, 279)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 78
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmFindFileHashTotalIL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(475, 314)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.dgvFindFile)
        Me.Name = "FrmFindFileHashTotalIL"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ระบุชื่อไฟล์ / LineNo "
        CType(Me.dgvFindFile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgvFindFile As System.Windows.Forms.DataGridView
    Friend WithEvents btnConfirm As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
