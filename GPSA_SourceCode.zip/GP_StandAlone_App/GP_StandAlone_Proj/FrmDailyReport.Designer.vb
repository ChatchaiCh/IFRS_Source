<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDailyReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.DatePicker1 = New CustomControls.DatePicker()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.CmdOk = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.DatePicker1)
        Me.PanelD1.Controls.Add(Me.ComboBox1)
        Me.PanelD1.Controls.Add(Me.CmdOk)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(10, 50)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(410, 118)
        Me.PanelD1.TabIndex = 39
        '
        'DatePicker1
        '
        Me.DatePicker1.Culture = New System.Globalization.CultureInfo("en-GB")
        Me.DatePicker1.Location = New System.Drawing.Point(79, 27)
        Me.DatePicker1.Name = "DatePicker1"
        Me.DatePicker1.Size = New System.Drawing.Size(202, 22)
        Me.DatePicker1.TabIndex = 40
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(79, 70)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(202, 21)
        Me.ComboBox1.TabIndex = 17
        '
        'CmdOk
        '
        Me.CmdOk.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdOk.BackColor = System.Drawing.Color.Transparent
        Me.CmdOk.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdOk.ForeColor = System.Drawing.Color.White
        Me.CmdOk.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdOk.Image = Global.GP_StandAlone_App.My.Resources.Resources.document_print_preview
        Me.CmdOk.ImageKey = ""
        Me.CmdOk.ImageList = Nothing
        Me.CmdOk.Location = New System.Drawing.Point(302, 11)
        Me.CmdOk.Name = "CmdOk"
        Me.CmdOk.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdOk.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.CmdOk.Size = New System.Drawing.Size(92, 95)
        Me.CmdOk.TabIndex = 16
        Me.CmdOk.Text = "Preview"
        Me.CmdOk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "��ǹ�ҹ"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Start Date"
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(10, 6)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(410, 38)
        Me.PanelH1.TabIndex = 38
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(116, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(165, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "Select Report Criteria"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FrmDailyReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(430, 177)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.PanelH1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmDailyReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmDailyReport"
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents CmdOk As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents DatePicker1 As CustomControls.DatePicker
End Class
