Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmPrtWHTCertificate
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsWHT
    Private _IsSelectAllChecked As Boolean
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub FrmReprintWHTaxCertificate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ControlStyle()
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

    End Sub
    Private Sub AddSelectAllCheckBox(ByVal theDataGridView As DataGridView)
        Dim cbx As New CheckBox
        cbx.Name = "SelectAll"
        'The box size
        cbx.Size = New Size(14, 14)

        Dim rect As Rectangle
        rect = theDataGridView.GetCellDisplayRectangle(0, -1, True)
        'Put CheckBox in the middle-center of the column header.
        cbx.Location = New System.Drawing.Point(rect.Location.X + ((rect.Width - cbx.Width) / 2), rect.Location.Y + ((rect.Height - cbx.Height) / 2))
        cbx.BackColor = Color.White
        theDataGridView.Controls.Add(cbx)

        'Handle header CheckBox check/uncheck function
        AddHandler cbx.Click, AddressOf HeaderCheckBox_Click
        'When any CheckBox value in the DataGridViewRows changed,
        'check/uncheck the header CheckBox accordingly.
        AddHandler theDataGridView.CellValueChanged, AddressOf DataGridView_CellChecked
        'This event handler is necessary to commit new CheckBox cell value right after
        'user clicks the CheckBox.
        'Without it, CellValueChanged event occurs until the CheckBox cell lose focus
        'which means the header CheckBox won't display corresponding checked state instantly when user
        'clicks any one of the CheckBoxes.
        AddHandler theDataGridView.CurrentCellDirtyStateChanged, AddressOf DataGridView_CurrentCellDirtyStateChanged
    End Sub
    Private Sub HeaderCheckBox_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me._IsSelectAllChecked = True

        Dim cbx As CheckBox
        cbx = DirectCast(sender, CheckBox)
        Dim theDataGridView As DataGridView = cbx.Parent

        For Each row As DataGridViewRow In theDataGridView.Rows
            row.Cells(0).Value = cbx.Checked
        Next

        theDataGridView.EndEdit()

        Me._IsSelectAllChecked = False
    End Sub
    Private Sub DataGridView_CellChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If Not Me._IsSelectAllChecked Then
            If dataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = False Then
                'When any single CheckBox is unchecked, uncheck the header CheckBox.
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = False
            Else
                'When any single CheckBox is checked, loop through all CheckBoxes to determine
                'if the header CheckBox needs to be unchecked.
                Dim isAllChecked As Boolean = True
                For Each row As DataGridViewRow In dataGridView.Rows
                    If row.Cells(0).Value = False Then
                        isAllChecked = False
                        Exit For
                    End If
                Next
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = isAllChecked
            End If
        End If
    End Sub
    Private Sub DataGridView_CurrentCellDirtyStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If TypeOf dataGridView.CurrentCell Is DataGridViewCheckBoxCell Then
            'When the value changed cell is DataGridViewCheckBoxCell, commit the change
            'to invoke the CellValueChanged event.
            dataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim chk As New DataGridViewCheckBoxColumn
        With chk
            DataGridView1.Columns.Add(chk)

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .ReadOnly = True
            .DataPropertyName = "TAX_WHTNO"
            .Name = "�Ţ���˹ѧ����Ѻ�ͧ"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .ReadOnly = True
            .DataPropertyName = "TAX_TAXDATE"
            .Name = "�ѹ ��͹ �� ���շ�����"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c2)
        End With
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .ReadOnly = True
            .DataPropertyName = "FNAME"
            .Name = "���ͼ��١�ѡ����"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .ReadOnly = True
            .DataPropertyName = "TAX_TAXID"
            .Name = "TAXID"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .ReadOnly = True
            .DataPropertyName = "TAX_IDCARD"
            .Name = "IDCARD"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c5)
        End With
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .ReadOnly = True
            .DataPropertyName = "TAX_BASE_AMT"
            .Name = "�ӹǹ�Թ������"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c6)
        End With
        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .ReadOnly = True
            .DataPropertyName = "TAX_TAX_AMT"
            .Name = "���շ���ѡ��й������"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c7)
        End With
        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .ReadOnly = True
            .DataPropertyName = "TAX_PRINTWHT_STS"
            .Name = "ʶҹС�þ����"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c8)
        End With
        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .ReadOnly = True
            .DataPropertyName = "TAX_PRINTWHT_STSDATE"
            .Name = "�ѹ��ʶҹС�þ����"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c9)
        End With


        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)
        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With
        DataGridView1.Columns(6).DefaultCellStyle.Format = "###,###.00"
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(7).DefaultCellStyle.Format = "###,###.00"
        DataGridView1.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        'If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

        '    retAccCode = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
        '    retAccName = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
        '    Me.Close()

        'End If
    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim count1 As Integer = 0
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = True Then
                count1 += 1
            End If
        Next

        If count1 < 1 Then
            MsgBox("No Data", MsgBoxStyle.Information)
            Exit Sub
        End If
        Dim countrow As Integer = 0
        Dim sb As New StringBuilder
        For index As Integer = 0 To DataGridView1.RowCount - 1
            If DataGridView1.Rows(index).Cells(0).Value = True Then

                sb.Append("'" & DataGridView1.Rows(index).Cells(1).Value & "',")

            End If
        Next

        If sb.ToString.Length > 0 Then
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim c1 As Boolean
            c1 = UpdateStatus(oleTrans, sb.ToString.TrimEnd(","))

            If c1 Then
                oleTrans.Commit()
                PrintReportCertificate(sb.ToString.TrimEnd(","))
                BindData()
            Else
                oleTrans.Rollback()
            End If


        End If


    End Sub
    Function UpdateStatus(ByVal oleTrans As OleDbTransaction, ByVal whtno As String) As Boolean

        Dim chk As Boolean
        chk = cls.UPD_STATUS(clsUtility.gConnGP, oleTrans, whtno, gUserLogin)

        Return chk
    End Function
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        
        BindData()

    End Sub
    Private Sub BindData()
        Dim datefrom, dateto As String
        If txtDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

            Else
                MsgBox("Date format is not valid")
                Exit Sub
            End If

            datefrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
        Else
            datefrom = ""
        End If
        If txtDateTo.Text.Trim <> "" Then
            Dim dateString As String = txtDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

            Else
                MsgBox("Date format is not valid")
                Exit Sub
            End If

            dateto = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
        Else
            dateto = ""
        End If

        Dim dt As DataTable = New DataTable()
        dt = cls.BindDataCertificate(clsUtility.gConnGP, txtWHTNo.Text.Trim, datefrom, dateto, txtTaxID.Text.Trim, txtIDCard.Text.Trim, txtName.Text.Trim)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
            AddSelectAllCheckBox(DataGridView1)
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub
    Private Sub PrintReportCertificate(ByVal whtno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "WHTTaxCertificate.rpt")

        Dim dt As DataTable = New DataTable()
        dt = cls.GetDataCertificateReport(clsUtility.gConnGP, whtno)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.ExportPDF(dt, "Print Tax Certificate")

            'frm1.FillDataTableToReportForCertificate(dt)

            'Dim clsExportPDF As New clsCrystalToPDFConverter

            'clsExportPDF.SetCrystalReportFilePath(sReportPath & "WHTTaxCertificate.rpt")
            'clsExportPDF.SetPdfDestinationFilePath(certificateReportPath & "RptCertification_RePrint" & ".pdf")

            'clsExportPDF.ExportReportCetificate(dt)

        End If

    End Sub

    Private Sub txtDateFrom_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateFrom.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateFrom.Text.Trim = "" Then

            Else
                Dim dateString As String = txtDateFrom.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")

                    txtDateFrom.Focus()
                End If
            End If

        End If
    End Sub

    Private Sub txtDateTo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateTo.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateTo.Text.Trim = "" Then

            Else
                Dim dateString As String = txtDateTo.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")

                    txtDateTo.Focus()
                End If
            End If

        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtWHTNo.Text = ""
        txtDateFrom.Text = ""
        txtDateTo.Text = ""
        txtTaxID.Text = ""
        txtIDCard.Text = ""
        txtName.Text = ""

        Dim dt As New DataTable
        dt = Nothing
        GetDataToGrid(dt)

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
