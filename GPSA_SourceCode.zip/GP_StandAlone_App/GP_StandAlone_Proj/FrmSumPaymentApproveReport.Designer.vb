<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSumPaymentApproveReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.dtpApproveDate = New CustomControls.DatePicker()
        Me.cboSection = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.CmdPreview = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(377, 38)
        Me.PanelH1.TabIndex = 40
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(97, 12)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(184, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "��§ҹ��ػ��è��»�Ш��ѹ"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtpApproveDate
        '
        Me.dtpApproveDate.Culture = New System.Globalization.CultureInfo("en-GB")
        Me.dtpApproveDate.Location = New System.Drawing.Point(85, 62)
        Me.dtpApproveDate.Name = "dtpApproveDate"
        Me.dtpApproveDate.Size = New System.Drawing.Size(196, 22)
        Me.dtpApproveDate.TabIndex = 40
        '
        'cboSection
        '
        Me.cboSection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSection.FormattingEnabled = True
        Me.cboSection.Location = New System.Drawing.Point(85, 21)
        Me.cboSection.Name = "cboSection"
        Me.cboSection.Size = New System.Drawing.Size(196, 21)
        Me.cboSection.TabIndex = 17
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "��ǹ�ҹ"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.dtpApproveDate)
        Me.PanelD1.Controls.Add(Me.cboSection)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(377, 118)
        Me.PanelD1.TabIndex = 41
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "�ѹ��� Approve"
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(301, 180)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(92, 28)
        Me.btnExit.TabIndex = 106
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'CmdPreview
        '
        Me.CmdPreview.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdPreview.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.CmdPreview.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdPreview.ForeColor = System.Drawing.Color.White
        Me.CmdPreview.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdPreview.Image = Nothing
        Me.CmdPreview.ImageKey = ""
        Me.CmdPreview.ImageList = Nothing
        Me.CmdPreview.Location = New System.Drawing.Point(201, 180)
        Me.CmdPreview.Name = "CmdPreview"
        Me.CmdPreview.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.Size = New System.Drawing.Size(92, 28)
        Me.CmdPreview.TabIndex = 105
        Me.CmdPreview.Text = "Print"
        Me.CmdPreview.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdPreview.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmSumPaymentApproveReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(403, 216)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.CmdPreview)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmSumPaymentApproveReport"
        Me.Text = "��§ҹ��ػ��è��»�Ш��ѹ(��ǹ�ѭ��)"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents dtpApproveDate As CustomControls.DatePicker
    Friend WithEvents cboSection As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdPreview As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
