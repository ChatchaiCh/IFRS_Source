﻿Imports UtilityClassLibrary
Imports System.Globalization
Imports System.Data.OleDb
Imports System.Text

Public Class FrmUpdWHT
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsWHT
    Dim clsLog As New ClsLog
    Private Sub ControlStyle()
        Panel1.BackColor = Color.FromArgb(255, 235, 200)
        Panel2.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub

    Private Sub FrmUpdWHT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        btnUpdate.Enabled = False

        ControlStyle()
    End Sub

    Private Sub GenGridWHT(ByVal dt As DataTable)

        With dgvWHT

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvWHT.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cWHTNO As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cWHTNO
            .DataPropertyName = "TAX_WHTNO"
            .Name = "เลขที่หนังสือรับรอง"
            .Width = 90
            dgvWHT.Columns.Add(cWHTNO)

        End With

        Dim cTAXID As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTAXID
            .DataPropertyName = "TAX_TAXID"
            .Name = "TAX ID"
            .Width = 100
            dgvWHT.Columns.Add(cTAXID)
        End With

        Dim cIDCARD As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cIDCARD
            .DataPropertyName = "TAX_IDCARD"
            .Name = "ID CARD"
            .Width = 100
            dgvWHT.Columns.Add(cIDCARD)
        End With

        Dim cAPFNAME As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAPFNAME
            .DataPropertyName = "TAX_AP_FNAME"
            .Name = "AP NAME"
            .Width = 250
            dgvWHT.Columns.Add(cAPFNAME)
        End With

        Dim cADDRESS As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cADDRESS
            .DataPropertyName = "TAX_ADDRESS"
            .Name = "ADDRESS"
            .Width = 400
            dgvWHT.Columns.Add(cADDRESS)
        End With

        Dim cITEM As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cITEM
            .DataPropertyName = "TAX_TAXITEM"
            .Name = "TAX_ITEM"
            .Width = 70
            dgvWHT.Columns.Add(cITEM)
        End With

        Dim cBASEAMT As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBASEAMT
            .DataPropertyName = "TAX_BASE_AMT"
            .Name = "BASE AMOUNT"
            .Width = 100
            dgvWHT.Columns.Add(cBASEAMT)
        End With

        Dim cDESC As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDESC
            .DataPropertyName = "TAX_DESC"
            .Name = "Description"
            .Width = 250
            dgvWHT.Columns.Add(cDESC)
        End With

        Dim cCREATEDATE As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCREATEDATE
            .DataPropertyName = "TAX_CREATEDATE"
            .Name = "Create Date"
            .ReadOnly = True
            .Width = 80
            dgvWHT.Columns.Add(cCREATEDATE)
        End With

        Dim cCORESYSTEM As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCORESYSTEM
            .DataPropertyName = "TAX_CORE_SYSTEM"
            .Name = "Core System"
            .ReadOnly = True
            .Width = 50
            dgvWHT.Columns.Add(cCORESYSTEM)
        End With

        Dim cTRANSREF As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTRANSREF
            .DataPropertyName = "TAX_TRANSREF"
            .Name = "Trans Ref No"
            .ReadOnly = True
            .Width = 150
            dgvWHT.Columns.Add(cTRANSREF)
        End With

        Dim cGPLine As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cGPLine
            .DataPropertyName = "TAX_GPTREF_SEQNO"
            .Name = "GP Line"
            .ReadOnly = True
            .Width = 50
            dgvWHT.Columns.Add(cGPLine)
        End With

        Dim cTaxamt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxamt
            .DataPropertyName = "TAX_TAX_AMT"
            .Name = "TAX_TAX_AMT"
            .ReadOnly = True
            .Width = 50
            dgvWHT.Columns.Add(cTaxamt)
        End With

        Dim cTaxrate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxrate
            .DataPropertyName = "TAX_TAX_RATE"
            .Name = "TAX_TAX_RATE"
            .ReadOnly = True
            .Width = 50
            dgvWHT.Columns.Add(cTaxrate)
        End With

        Dim cTaxLine As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxLine
            .DataPropertyName = "TAX_LINENO"
            .Name = "TAX_LINENO"
            .ReadOnly = True
            .Width = 90
            dgvWHT.Columns.Add(cTaxLine)
        End With

        dgvWHT.Columns(6).DefaultCellStyle.Format = "###,###.00" 'AMOUNT BASE
        dgvWHT.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgvWHT.Columns(12).Visible = False
        dgvWHT.Columns(13).Visible = False
        'dgvWHT.Columns(14).Visible = False

    End Sub
    'Clear btn
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Me.ClearForm()
    End Sub

    Private Function ClearForm()
        'Clear TextBox Data
        txtBookNo.Clear()
        txtDateFrom.Clear()
        txtDateTo.Clear()
        txtTaxID.Clear()
        txtIDCard.Clear()

        'enable all textbox
        txtBookNo.Enabled = True
        txtDateFrom.Enabled = True
        txtDateTo.Enabled = True
        txtTaxID.Enabled = True
        txtIDCard.Enabled = True

        'Clear Grid Data
        dgvWHT.Columns.Clear()
        dgvWHT.Controls.Clear()

    End Function
    'Clear btn

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Dim dt As DataTable

        Dim taxWhtno, dateFrom, dateTo, taxId, idCard As String
        taxWhtno = txtBookNo.Text.Trim
        dateFrom = txtDateFrom.Text.Trim
        dateTo = txtDateTo.Text.Trim
        taxId = txtTaxID.Text.Trim
        idCard = txtIDCard.Text.Trim

        Dim validateSearch As Boolean = False

        If txtDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                dateFrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateFrom.Text = ""
                txtDateFrom.Focus()
                dateFrom = ""
            End If
        Else
            dateFrom = ""
        End If
        If txtDateTo.Text.Trim <> "" Then

            Dim dateString As String = txtDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                dateTo = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateTo.Text = ""
                txtDateTo.Focus()
                dateTo = ""
            End If
        Else
            dateTo = ""
        End If

        If taxWhtno <> "" Then
            validateSearch = True
        ElseIf dateFrom <> "" And dateTo <> "" Then
            If (taxId <> "" Or idCard <> "") And (dateFrom <> "" And dateTo <> "") Then
                validateSearch = True
            Else
                MsgBox("กรุณาเพิ่มข้อมูลระหว่าง Tax ID หรือ Idcard")
            End If
        Else
            MsgBox("กรุณาระบุเงื่อนไขในการค้นหา ให้ครบถ้วน")
        End If

        If validateSearch = True Then

            dt = cls.GetDataForUpdWHT(clsUtility.gConnGP, txtBookNo.Text.Trim, dateFrom, dateTo, txtTaxID.Text.Trim, txtIDCard.Text.Trim)
            GenGridWHT(dt)

        End If

        btnUpdate.Enabled = False

    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim oleConn As OleDbConnection
        Dim oleTrans As OleDbTransaction
        oleConn = clsUtility.gConnGP
        Dim c, i, r, logId, countRs As Integer
        Dim tableName As New ArrayList
        Dim dt As DataTable
        Dim whtNoSb As New StringBuilder
        Dim logTypeId, logType, logMaxid, dateFrom, dateTo As String
        logTypeId = "002"
        tableName.Add("GPS_WHT_COMPLETE")
        tableName.Add("GPS_WHT_CREATION")
        tableName.Add("GPS_WHT_LOAD")
        tableName.Add("GPS_WHT")
        If txtDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                dateFrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateFrom.Text = ""
                txtDateFrom.Focus()

            End If
        Else
            dateFrom = ""
        End If
        If txtDateTo.Text.Trim <> "" Then

            Dim dateString As String = txtDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                dateTo = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateTo.Text = ""
                txtDateTo.Focus()

            End If
        Else
            dateTo = ""
        End If
        Try
            countRs = 0
            For index As Integer = 0 To dgvWHT.RowCount - 1

                Dim cWHTNO As String = dgvWHT.Rows(index).Cells(0).Value.ToString
                Dim cTAXID As String = dgvWHT.Rows(index).Cells(1).Value.ToString
                Dim cIDCARD As String = dgvWHT.Rows(index).Cells(2).Value.ToString
                Dim cAPFNAME As String = dgvWHT.Rows(index).Cells(3).Value.ToString
                Dim cADDRESS As String = dgvWHT.Rows(index).Cells(4).Value.ToString
                Dim cTAXITEM As String = dgvWHT.Rows(index).Cells(5).Value.ToString
                Dim cBasemount As String = dgvWHT.Rows(index).Cells(6).Value.ToString
                Dim cDESC As String = dgvWHT.Rows(index).Cells(7).Value.ToString
                Dim cCREATEDATE As String = dgvWHT.Rows(index).Cells(8).Value.ToString
                Dim cCORESYSTEM As String = dgvWHT.Rows(index).Cells(9).Value.ToString
                Dim cTRANSREF As String = dgvWHT.Rows(index).Cells(10).Value.ToString
                Dim cGPLine As String = dgvWHT.Rows(index).Cells(11).Value.ToString
                Dim cTaxamt As String = dgvWHT.Rows(index).Cells(12).Value.ToString
                Dim cTaxrate As String = dgvWHT.Rows(index).Cells(13).Value.ToString
                Dim cTaxLine As String = dgvWHT.Rows(index).Cells(14).Value.ToString
                If index > 0 Then
                    whtNoSb.Append(",")
                End If
                whtNoSb.Append(cWHTNO)

                countRs = countRs + 1
            Next

        Catch ex As Exception
            MsgBox("รายการ WHT ไม่ถูกต้อง!")
            Exit Sub
        End Try
        If MessageBox.Show("Do you want to Update WHT ? (Y/N)", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            c = 0
            r = 0

            logMaxid = clsLog.fnGetAdjMaxId(oleConn, logTypeId)
            logType = clsLog.fnGetAdjType(oleConn, logTypeId)

            oleTrans = oleConn.BeginTransaction

            For index2 As Integer = 0 To dgvWHT.RowCount - 1
                Dim cWHTNO As String = dgvWHT.Rows(index2).Cells(0).Value.ToString
                Dim cTAXID As String = dgvWHT.Rows(index2).Cells(1).Value.ToString
                Dim cIDCARD As String = dgvWHT.Rows(index2).Cells(2).Value.ToString
                Dim cAPFNAME As String = dgvWHT.Rows(index2).Cells(3).Value.ToString
                Dim cADDRESS As String = dgvWHT.Rows(index2).Cells(4).Value.ToString
                Dim cTAXITEM As String = dgvWHT.Rows(index2).Cells(5).Value.ToString
                Dim cBasemount As String = dgvWHT.Rows(index2).Cells(6).Value.ToString
                Dim cDESC As String = dgvWHT.Rows(index2).Cells(7).Value.ToString
                Dim cCREATEDATE As String = dgvWHT.Rows(index2).Cells(8).Value.ToString
                Dim cCORESYSTEM As String = dgvWHT.Rows(index2).Cells(9).Value.ToString
                Dim cTRANSREF As String = dgvWHT.Rows(index2).Cells(10).Value.ToString
                Dim cGPLine As String = dgvWHT.Rows(index2).Cells(11).Value.ToString
                Dim cTaxamt As String = dgvWHT.Rows(index2).Cells(12).Value.ToString
                Dim cTaxrate As String = dgvWHT.Rows(index2).Cells(13).Value.ToString
                Dim cTaxLine As String = dgvWHT.Rows(index2).Cells(14).Value.ToString

                If (logMaxid <> 0) Then
                    logId = logMaxid + 1
                    r = r + clsLog.startAdjLog(oleConn, oleTrans, logId, logTypeId, cWHTNO, txtTaxID.Text, txtIDCard.Text, dateFrom, dateTo, "", "", logType, gUserLogin)
                    c = c + 1
                    logMaxid = logMaxid + 1
                Else
                    logId = 1
                    r = r + clsLog.startAdjLog(oleConn, oleTrans, logId, logTypeId, cWHTNO, txtTaxID.Text, txtIDCard.Text, dateFrom, dateTo, "", "", logType, gUserLogin)
                    c = c + 1
                    logMaxid = logMaxid + 1
                End If

                For i = 0 To tableName.Count - 1
                    r = r + cls.UpdateWHT(oleConn, oleTrans, cTAXID, cIDCARD, cAPFNAME, cADDRESS, cDESC, cCREATEDATE, cCORESYSTEM, cTRANSREF, cGPLine, gUserLogin, tableName(i), cTAXITEM, cBasemount, cTaxLine)
                    c = c + 1

                    r = r + clsLog.updateLogWhtUPD(oleConn, oleTrans, logId, cCREATEDATE, cCORESYSTEM, cTRANSREF, cGPLine, gUserLogin, tableName(i), cTaxLine)
                    c = c + 1
                Next

                r = r + clsLog.endAdjLog(oleConn, oleTrans, logId, logTypeId, 1, gUserLogin)
                c = c + 1
            Next


            If c = r Then
                oleTrans.Commit()
                MsgBox("Update Seccessfully")
            Else
                oleTrans.Rollback()
                MsgBox("Update Fail")
            End If

            ClearForm()

        End If
    End Sub

    Private Sub dgvWHT_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvWHT.CellEndEdit
        Dim oleConn As OleDbConnection
        oleConn = clsUtility.gConnGP
        Dim amt As Decimal
        Dim whtNo, apName, apAddress, taxId, idCard As String
        Dim updateWht As Boolean = False
        Try
            dgvWHT.AllowUserToAddRows = False

            Dim iRow = dgvWHT.CurrentCell.RowIndex
            'apName = dgvWHT.Rows(iRow).Cells(3).Value
            'apAddress = dgvWHT.Rows(iRow).Cells(4).Value

            'updateWht = True

            If (dgvWHT.CurrentCell.OwningColumn.Index.ToString() = 1) Then
                If dgvWHT.Rows(iRow).Cells(1).Value.ToString <> "" Then
                    dgvWHT.Rows(iRow).Cells(2).Value = ""
                End If
            End If

            If (dgvWHT.CurrentCell.OwningColumn.Index.ToString() = 2) Then
                If dgvWHT.Rows(iRow).Cells(2).Value.ToString <> "" Then
                    dgvWHT.Rows(iRow).Cells(1).Value = ""
                End If
            End If

            whtNo = dgvWHT.Rows(iRow).Cells(0).Value.ToString
            taxId = dgvWHT.Rows(iRow).Cells(1).Value.ToString
            idCard = dgvWHT.Rows(iRow).Cells(2).Value.ToString
            amt = cls.fnGet_baseAmt(oleConn, whtNo)
            apName = cls.fnGet_apName(oleConn, taxId, idCard)
            apAddress = cls.fnGet_apAddress(oleConn, taxId, idCard)

            If dgvWHT.Rows(iRow).Cells(1).Value.ToString = "" And dgvWHT.Rows(iRow).Cells(2).Value.ToString = "" Then
                updateWht = False
            End If

            If Not String.IsNullOrEmpty(dgvWHT.Rows(iRow).Cells(6).Value) Then
                Dim baseamt, taxamt, taxrate, sumamt As Decimal
                baseamt = Convert.ToDecimal(dgvWHT.Rows(iRow).Cells(6).Value)
                taxamt = Convert.ToDecimal(dgvWHT.Rows(iRow).Cells(12).Value)
                taxrate = Convert.ToDecimal(dgvWHT.Rows(iRow).Cells(13).Value)
                sumamt = (baseamt * (taxrate / 100)) - taxamt
                If (sumamt < 1 And sumamt > -1) Then
                Else
                    MsgBox("ส่วนต่างของ Tax Amount มากกว่า 1 บาท หรือ น้อยกว่า 1 บาท กรุณาตรวจสอบ.")
                    dgvWHT.Rows(iRow).Cells(6).Value = amt
                    updateWht = False
                End If
            End If

            If apName <> dgvWHT.Rows(iRow).Cells(3).Value.ToString Then
                dgvWHT.Rows(iRow).Cells(3).Value = apName
                MsgBox("กรุณาแก้ไขข้อมูลชื่อ AP ในไฟล์ config ก่อนแก้ไขข้อมูล WHT")

                updateWht = False
            End If

            If apAddress <> dgvWHT.Rows(iRow).Cells(4).Value.ToString Then
                dgvWHT.Rows(iRow).Cells(4).Value = apAddress
                MsgBox("กรุณาแก้ไขข้อมูลที่อยู่ AP ในไฟล์ config ก่อนแก้ไขข้อมูล WHT")

                updateWht = False
            End If

            If apName <> "" And apAddress <> "" Then
                updateWht = True
            End If


        Catch ex As Exception
            updateWht = False
        End Try

        If updateWht = True Then
            btnUpdate.Enabled = True
        Else
            btnUpdate.Enabled = False
        End If

    End Sub

    Private Sub txtBookNo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtBookNo.TextChanged

        Dim txtBookNoValue As String
        txtBookNoValue = txtBookNo.Text

        If txtBookNoValue <> "" Then
            txtDateFrom.Clear()
            txtDateTo.Clear()
            txtTaxID.Clear()
            txtIDCard.Clear()

            'enable all textbox
            txtDateFrom.Enabled = False
            txtDateTo.Enabled = False
            txtTaxID.Enabled = False
            txtIDCard.Enabled = False
        Else
            txtDateFrom.Clear()
            txtDateTo.Clear()
            txtTaxID.Clear()
            txtIDCard.Clear()

            'enable all textbox
            txtDateFrom.Enabled = True
            txtDateTo.Enabled = True
            txtTaxID.Enabled = True
            txtIDCard.Enabled = True
        End If


    End Sub

    Private Sub txtTaxID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTaxID.TextChanged
        Dim txtTaxIDValue As String
        txtTaxIDValue = txtTaxID.Text

        If txtTaxIDValue <> "" Then
            txtIDCard.Clear()
            txtIDCard.Enabled = False
        Else
            txtIDCard.Clear()
            txtIDCard.Enabled = True
        End If

    End Sub

    Private Sub txtIDCard_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtIDCard.TextChanged
        Dim txtIDCardValue As String
        txtIDCardValue = txtIDCard.Text

        If txtIDCardValue <> "" Then
            txtTaxID.Clear()
            txtTaxID.Enabled = False
        Else
            txtTaxID.Clear()
            txtTaxID.Enabled = True
        End If
    End Sub

End Class