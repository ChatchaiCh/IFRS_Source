Public Class FrmCallATSE2000PROG

    Private Sub FrmCallATSE2000PROG_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Process.Start("""" & CALLATSE2000PROG & """")
        Catch ex As Exception
            Me.Close()
        End Try
        Me.Close()
    End Sub
End Class