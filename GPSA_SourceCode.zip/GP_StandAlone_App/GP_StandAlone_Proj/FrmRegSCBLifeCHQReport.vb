Imports UtilityClassLibrary
Imports System.Text
Public Class FrmRegSCBLifeCHQReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim sqlconditionwhere As String
    Dim PrintDateFrom As String
    Dim PrintDateTo As String
    Private Sub FrmRptPrintCheque_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        txtPrintDateFrom.Text = Now.ToString("dd/MM/yyyy")
        txtPrintDateTo.Text = Now.ToString("dd/MM/yyyy")
        txtBatchNo.Text = clsBusiness.fnCallLastBatchNo(clsUtility.gConnGP, "SCBLIFE_CHQ")
    End Sub
    Private Sub PrintReport()
        
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPrintCheque.rpt")



        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()

            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()

            Dim discrete3 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param3 As New CrystalDecisions.Shared.ParameterField()

            Dim discrete4 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param4 As New CrystalDecisions.Shared.ParameterField()

            Dim discrete5 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param5 As New CrystalDecisions.Shared.ParameterField()

            Dim discrete6 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param6 As New CrystalDecisions.Shared.ParameterField()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()



            param1.ParameterFieldName = "pBatchNo"
            'discrete1.Value = cboJournalType.Text
            discrete1.Value = Trim(txtBatchNo.Text)
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pChqNoFrom"
            discrete2.Value = Trim(txtChqNoFrom.Text)
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            param3.ParameterFieldName = "pChqNoTo"
            discrete3.Value = Trim(txtChqNoTo.Text)
            param3.CurrentValues.Add(discrete3)
            paramFields.Add(param3)

            param4.ParameterFieldName = "pPrintDateFrom"
            discrete4.Value = Trim(txtPrintDateFrom.Text)
            param4.CurrentValues.Add(discrete4)
            paramFields.Add(param4)

            param5.ParameterFieldName = "pPrintDateTo"
            discrete5.Value = Trim(txtPrintDateTo.Text)
            param5.CurrentValues.Add(discrete5)
            paramFields.Add(param5)


            param6.ParameterFieldName = "pTransdate"
            discrete6.Value = "01/10/2014"
            param6.CurrentValues.Add(discrete6)
            paramFields.Add(param6)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            'discreteUser.Value = "SOA"
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmRegSCBLifeCHQReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox("��辺�����ŵ�����͹�")
        End If

        'gConnSPI.Close()
    End Sub

    Function GetDataGL() As DataTable


        Dim sb As New StringBuilder()
        sb.Append(" select * from (  ")
        sb.Append(" (  ")
        sb.Append("  Select ")
        sb.Append(" GPS_TRANSREF_REL.TREF_BATCH_NO  as BatchNo ")

        'pattamalin 2015/02/05
        'sb.Append(" , GPS_PAYMENT.GP_BNKCODE , GPS_PAYMENT.GP_BNKNAME , GPS_PAYMENT.GP_TRANSREF ")
        sb.Append(" , GPS_PAYMENT.GP_BNKCODE ,B.BKMST_BNKCODE || ' ' ||B.BKMST_BNKNAME AS GP_BNKNAME, GPS_PAYMENT.GP_TRANSREF ")

        sb.Append(" , GPS_PAYMENT.GP_PAYMTH , GPS_PAYMENT.GP_SUB_PAYMTH , GPS_TL_PAYTYPE.PAYT_PAYTYPE ")
        sb.Append(" , GPS_PAYMENT.GP_CHQNO , GPS_PAYMENT.GP_PAIDDATE , GPS_PAYMENT.GP_PAYEE_NAME ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_CORE_SYSTEM , GPS_PAYMENT.GP_CONFIRMDATE ")
        sb.Append(" , GPS_PAYMENT.GP_GPTREF_SEQNO ")
        sb.Append(" ,  nvl(GPS_WHT.TAX_TAX_AMT,0) as TAX_TAX_AMT ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as AMOUNT , GPS_PAYMENT.GP_PRINTCHQ_STSDATE ")
        sb.Append(" , nvl(GPS_WHT.TAX_WHTNO,'') as WHTNo , GPS_PAYMENT.GP_PRINTCHQ_STS  ")
        sb.Append(" , NVL(GPS_TL_STATUS.STS_DESC,'') as STS_DESC , GPS_PAYMENT.GP_CHQNO_OLD as ChqCancel , '' as Remark , GPS_TL_STATUS.STS_TYPE as SYS_TYPE ")
        sb.Append(" from  GPS_PAYMENT ")
        '------- �֧�������Ţ Batch No
        'pattamalin 2015/02/05
        sb.Append("INNER JOIN GPS_TL_BANKMASTER B  ")
        sb.Append("ON GPS_PAYMENT.GP_BNKSCODE_NO=B.BKMST_BNKCODE_NO ")

        sb.Append(" left join GPS_TRANSREF_REL  ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM =  GPS_TRANSREF_REL.TREF_CORE_SYSTEM  ")
        sb.Append(" and GPS_PAYMENT.GP_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        'sb.Append(" and GPS_PAYMENT.GP_CONFIRMDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        '------- �֧�����Ū��� sub  payment method
        sb.Append(" left join GPS_TL_PAYTYPE  ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH  ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '------- �֧�����Ū���ʶҹС�þ����
        sb.Append(" left join GPS_TL_STATUS ")
        sb.Append(" on GPS_PAYMENT.GP_PRINTCHQ_STS = GPS_TL_STATUS.STS_STATUS ")
        sb.Append(" and GPS_TL_STATUS.STS_TYPE = 'PRN_SCBLIFE_CHQ' ")
        '------- �֧������ TAX
        sb.Append(" left join GPS_WHT ")
        sb.Append(" on GPS_WHT.TAX_TRANSREF = GPS_PAYMENT.GP_TRANSREF ")
        sb.Append(" and GPS_WHT.TAX_CONFIRMDATE = GPS_PAYMENT.GP_CONFIRMDATE ")
        sb.Append(" and  GPS_WHT.TAX_CORE_SYSTEM = GPS_PAYMENT.GP_CORE_SYSTEM ")
        sb.Append(" and GPS_WHT.TAX_GPTREF_SEQNO = GPS_PAYMENT.GP_GPTREF_SEQNO ")
        sb.Append(" where GPS_PAYMENT.GP_TRANSREF in  ")
        sb.Append(" ( ")
        sb.Append(" select  GPS_TRANSREF_REL.TREF_TRANSREF from GPS_TRANSREF_REL  ")
        sb.Append("  " + sqlconditionwhere + " ")
        'sb.Append(" where GPS_TRANSREF_REL.TREF_BATCH_NO = 'GP20140924001' ")
        sb.Append(" group by GPS_TRANSREF_REL.TREF_BATCH_NO  , GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" ) ")
        '------- �֧�����ŷ���� ����� SCBL chq ���� SCBL chq �����㺵�����ҹ��
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_PAYMTH = 'C' ")
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH = 'Q'    ")
        sb.Append(" ) ")
        sb.Append(" union ")
        sb.Append(" (  ")
        sb.Append("  Select ")
        sb.Append(" GPS_TRANSREF_REL.TREF_BATCH_NO  as BatchNo ")

        'pattamalin 2015/02/05
        'sb.Append(" , GPS_PAYMENT.GP_BNKCODE , GPS_PAYMENT.GP_BNKNAME , GPS_PAYMENT.GP_TRANSREF ")
        sb.Append(" , GPS_PAYMENT.GP_BNKCODE ,B.BKMST_BNKCODE || ' ' || B.BKMST_BNKNAME AS GP_BNKNAME, GPS_PAYMENT.GP_TRANSREF ")


        sb.Append(" , GPS_PAYMENT.GP_PAYMTH , GPS_PAYMENT.GP_SUB_PAYMTH , GPS_TL_PAYTYPE.PAYT_PAYTYPE ")
        sb.Append(" , GPS_PAYMENT.GP_CHQNO , GPS_PAYMENT.GP_PAIDDATE , GPS_PAYMENT.GP_PAYEE_NAME ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_CORE_SYSTEM , GPS_PAYMENT.GP_CONFIRMDATE ")
        sb.Append(" , GPS_PAYMENT.GP_GPTREF_SEQNO ")
        '------- group ���ǹ�ͧ TAX ���ʹ���
        sb.Append(" , ( select sum (GPS_WHT.TAX_TAX_AMT)  from GPS_WHT ")
        sb.Append(" where GPS_WHT.TAX_TRANSREF = GPS_PAYMENT.GP_TRANSREF ")
        sb.Append(" and GPS_WHT.TAX_CONFIRMDATE = GPS_PAYMENT.GP_CONFIRMDATE ")
        sb.Append(" and  GPS_WHT.TAX_CORE_SYSTEM = GPS_PAYMENT.GP_CORE_SYSTEM ")
        sb.Append(" group by GPS_WHT.TAX_TRANSREF ) as TAX_TAX_AMT ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT as AMOUNT , GPS_PAYMENT.GP_PRINTCHQ_STSDATE ")
        '------- group ���ǹ�ͧ TAX �� min ��� max �ͧ�Ţ�������
        sb.Append(" , ( select min(GPS_WHT.TAX_WHTNO)||'-'||max(GPS_WHT.TAX_WHTNO) from GPS_WHT  ")
        sb.Append(" where GPS_WHT.TAX_TRANSREF = GPS_PAYMENT.GP_TRANSREF and GPS_WHT.TAX_CONFIRMDATE = GPS_PAYMENT.GP_CONFIRMDATE ")
        sb.Append(" and  GPS_WHT.TAX_CORE_SYSTEM = GPS_PAYMENT.GP_CORE_SYSTEM ")
        sb.Append(" group by GPS_WHT.TAX_TRANSREF ) as WHTNo ")
        sb.Append(" , GPS_PAYMENT.GP_PRINTCHQ_STS , NVL(GPS_TL_STATUS.STS_DESC,'') as STS_DESC ")
        sb.Append(" , GPS_PAYMENT.GP_CHQNO_OLD as ChqCancel , '' as Remark , GPS_TL_STATUS.STS_TYPE as SYS_TYPE ")
        sb.Append(" from  GPS_PAYMENT ")

        'pattamalin 2015/02/05
        sb.Append("INNER JOIN GPS_TL_BANKMASTER B  ")
        sb.Append("ON GPS_PAYMENT.GP_BNKSCODE_NO=B.BKMST_BNKCODE_NO ")


        '------- �֧�������Ţ Batch No
        sb.Append(" left join GPS_TRANSREF_REL  ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM =  GPS_TRANSREF_REL.TREF_CORE_SYSTEM  ")
        sb.Append(" and GPS_PAYMENT.GP_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        'sb.Append(" and GPS_PAYMENT.GP_CONFIRMDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        '------- �֧�����Ū��� sub  payment method
        sb.Append(" left join GPS_TL_PAYTYPE ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '------- �֧�����Ū���ʶҹС�þ����
        sb.Append(" left join GPS_TL_STATUS ")
        sb.Append(" on GPS_PAYMENT.GP_PRINTCHQ_STS = GPS_TL_STATUS.STS_STATUS ")
        sb.Append(" and GPS_TL_STATUS.STS_TYPE = 'PRN_SCBLIFE_CHQ' ")
        sb.Append(" where GPS_PAYMENT.GP_TRANSREF in ")
        sb.Append(" ( select  GPS_TRANSREF_REL.TREF_TRANSREF from GPS_TRANSREF_REL ")
        sb.Append("  " + sqlconditionwhere + " ")
        'sb.Append(" where GPS_TRANSREF_REL.TREF_BATCH_NO = 'GP20140924001' ")
        sb.Append(" group by GPS_TRANSREF_REL.TREF_BATCH_NO  , GPS_TRANSREF_REL.TREF_TRANSREF )")
        '------- �֧�����ŷ���� ����� SCBL chq ���� �ѡɳ��͡ chq 1 � ����仫��������� 
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_PAYMTH = 'C' ")
        sb.Append(" and GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH in ( 'B' , 'G' , 'H' , 'T'  ) ")
        sb.Append(" )  ")
        sb.Append("  ) MasterDate ")
        sb.Append(" order by BatchNo , GP_BNKCODE , GP_TRANSREF , GP_CHQNO ")

        'MsgBox(sb.ToString)
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click
        If (txtBatchNo.Text = "") And (txtChqNoFrom.Text = "") And (txtChqNoTo.Text = "") And (txtPrintDateFrom.Text = "") And (txtPrintDateTo.Text = "") Then
            MsgBox("�ô�кآ��������͹����ҧ���� 1 ��ͧ������")

        Else
            sqlconditionwhere = ""

            'PrintDateFrom = Trim(txtPrintDateFrom.Text.Substring(6, 4)) + Trim(txtPrintDateFrom.Text.Substring(3, 2)) + Trim(txtPrintDateFrom.Text.Substring(0, 2))
            'PrintDateTo = Trim(txtPrintDateTo.Text.Substring(6, 4)) + Trim(txtPrintDateTo.Text.Substring(3, 2)) + Trim(txtPrintDateTo.Text.Substring(0, 2))

            If (txtBatchNo.Text <> "") Then
                sqlconditionwhere = sqlconditionwhere + " GPS_TRANSREF_REL.TREF_BATCH_NO like '%" + Trim(txtBatchNo.Text) + "%' "
            End If

            If (txtChqNoFrom.Text <> "") Or (txtChqNoTo.Text <> "") Then

                If sqlconditionwhere <> "" Then
                    sqlconditionwhere = sqlconditionwhere + " AND "
                End If

                If (txtChqNoFrom.Text <> "") And (txtChqNoTo.Text <> "") Then
                    sqlconditionwhere = sqlconditionwhere + " ( GPS_PAYMENT.GP_CHQNO Between '" + Trim(txtChqNoFrom.Text) + "' and '" + Trim(txtChqNoTo.Text) + "' )"
                ElseIf (txtChqNoFrom.Text <> "") And (txtChqNoTo.Text = "") Then
                    sqlconditionwhere = sqlconditionwhere + " GPS_PAYMENT.GP_CHQNO >= '" + Trim(txtChqNoFrom.Text) + "' "
                Else
                    sqlconditionwhere = sqlconditionwhere + " GPS_PAYMENT.GP_CHQNO <= '" + Trim(txtChqNoTo.Text) + "' "
                End If


            End If

            If (txtPrintDateFrom.Text <> "") Or (txtPrintDateTo.Text <> "") Then

                If sqlconditionwhere <> "" Then
                    sqlconditionwhere = sqlconditionwhere + " AND "
                End If

                If (txtPrintDateFrom.Text <> "") And (txtPrintDateTo.Text <> "") Then

                    PrintDateFrom = Trim(txtPrintDateFrom.Text.Substring(6, 4)) + Trim(txtPrintDateFrom.Text.Substring(3, 2)) + Trim(txtPrintDateFrom.Text.Substring(0, 2))
                    PrintDateTo = Trim(txtPrintDateTo.Text.Substring(6, 4)) + Trim(txtPrintDateTo.Text.Substring(3, 2)) + Trim(txtPrintDateTo.Text.Substring(0, 2))

                    sqlconditionwhere = sqlconditionwhere + " ( GPS_PAYMENT.GP_PRINTCHQ_STSDATE Between '" + Trim(PrintDateFrom) + "' and '" + Trim(PrintDateTo) + "' )"
                ElseIf (txtPrintDateFrom.Text <> "") And (txtPrintDateTo.Text = "") Then
                    PrintDateFrom = Trim(txtPrintDateFrom.Text.Substring(6, 4)) + Trim(txtPrintDateFrom.Text.Substring(3, 2)) + Trim(txtPrintDateFrom.Text.Substring(0, 2))
                    PrintDateTo = ""


                    sqlconditionwhere = sqlconditionwhere + " GPS_PAYMENT.GP_PRINTCHQ_STSDATE >= '" + Trim(PrintDateFrom) + "' "
                Else
                    PrintDateFrom = ""
                    PrintDateTo = Trim(txtPrintDateTo.Text.Substring(6, 4)) + Trim(txtPrintDateTo.Text.Substring(3, 2)) + Trim(txtPrintDateTo.Text.Substring(0, 2))

                    sqlconditionwhere = sqlconditionwhere + " GPS_PAYMENT.GP_PRINTCHQ_STSDATE <= '" + Trim(PrintDateTo) + "' "
                End If

            Else
                PrintDateFrom = ""
                PrintDateTo = ""

            End If


            sqlconditionwhere = " WHERE " + sqlconditionwhere

            'MsgBox(sqlconditionwhere)
            PrintReport()
        End If

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class