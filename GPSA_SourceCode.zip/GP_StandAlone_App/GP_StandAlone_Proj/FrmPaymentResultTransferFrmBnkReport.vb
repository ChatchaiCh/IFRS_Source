Imports System.Text
Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.IO
Public Class FrmPaymentResultTransferFrmBnkReport
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim PaymentMethod As String
    Dim SubPaymentMethod As String
    Dim PaidDate As String
    Dim AsOfDate As String
    Dim cls As New ClsHashTotalErrorLOCancel


#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)


    End Sub
    Private Sub FrmPrintSCBLifeCHQ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()

        Dim sb As New StringBuilder()

        sb.Append(" select to_char(sysdate,'DD/MM/YYYY') as currentDate from dual  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count <> 0 Then
            txtAsOfDate.Text = dt.Rows(0)("currentDate").ToString
            AsOfDate = dt.Rows(0)("currentDate").ToString
        End If
        'cboBatchNo.Items.Add(" ")
        cboBatchNo.Items.Add("1")
        cboBatchNo.Items.Add("2")



    End Sub


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        'MsgBox(cboBatchNo.SelectedItem.ToString())
        If (Trim(cboBatchNo.Text) <> "") Then
            PrintReport()
            PrintReport2()

            Dim frm As New FrmPaymentResultTransferFrmBnkReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox(" ��س��кآ����� Batch No ")
        End If
    End Sub

    Private Sub PrintReport()
        'Dim fromdate As String
        'Dim todate As String
        'fromdate = CStr(dtpFromDate.Value.ToString("yyyyMMdd"))
        'todate = CStr(dtpToDate.Value.ToString("yyyyMMdd"))

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RPTPayResultTransFromBank.rpt")



        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pTransdate"
            'discrete1.Value = Trim(txtAsOfDate.Text)
            discrete1.Value = txtAsOfDate.Text.Trim  'Trim(AsOfDate)
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            'discreteUser.Value = "SOA"
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            param2.ParameterFieldName = "pBatchNo"
            discrete2.Value = Trim(cboBatchNo.Text)
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        Else
            MsgBox("��辺�����ŵ�����͹�")
        End If

        'gConnSPI.Close()
    End Sub

    Private Sub PrintReport2()
        'Dim fromdate As String
        'Dim todate As String
        'fromdate = CStr(dtpFromDate.Value.ToString("yyyyMMdd"))
        'todate = CStr(dtpToDate.Value.ToString("yyyyMMdd"))

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RPTPayResultTransFromBank_CD.rpt")



        Dim dt As DataTable = New DataTable()

        dt = GetDataGL_Detail()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pTransdate"
            'discrete1.Value = Trim(txtAsOfDate.Text)
            discrete1.Value = txtAsOfDate.Text.Trim 'Trim(AsOfDate)
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            'discreteUser.Value = "SOA"
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            param2.ParameterFieldName = "pBatchNo"
            discrete2.Value = Trim(cboBatchNo.Text)
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()



            'Else
            'MsgBox("��辺�����ŵ�����͹�")
        End If

        'gConnSPI.Close()
    End Sub

    Private Sub PrintReportRRR()

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim tempDir As String = "temp\"
        Dim aa As Integer
        Dim dt As DataTable = New DataTable()
        Dim pathLOReport As String = cls.getPathLOReport(clsUtility.gConnGP)
        Dim pathReport As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")
        Dim oFile As System.IO.StreamWriter
        Dim sBatchDate As String
        oFile = My.Computer.FileSystem.OpenTextFileWriter("D:\" & Now.ToString("yyyyMMddHHMMss") & ".TXT", True)
        sBatchDate = Trim(txtAsOfDate.Text.Substring(6, 4)) + Trim(txtAsOfDate.Text.Substring(3, 2)) + Trim(txtAsOfDate.Text.Substring(0, 2))

        If System.IO.Directory.Exists(tempDir) Then
            '--System.IO.Directory.Delete(tempDir, True)
            For Each foundFile As String In My.Computer.FileSystem.GetFiles(tempDir, FileIO.SearchOption.SearchTopLevelOnly, "*.*")
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Delete --> " & foundFile)
                File.Delete(foundFile)
            Next
        Else
            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Create Directory --> " & tempDir)
            System.IO.Directory.CreateDirectory(tempDir)
            For aa = 1 To 1000
                Console.WriteLine(aa.ToString)
            Next
        End If

        cls.genReportErrorbyHashTotalLO_Reprint(clsUtility.gConnGP, sBatchDate, tempDir, sReportPath, gUserFullName, cboBatchNo.Text.ToString)

        'Exit Sub

        For Each reportFilename As String In System.IO.Directory.GetFiles(tempDir)

            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport)
            'MsgBox(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport, MsgBoxStyle.Information)

            'MsgBox("Report path: " & pathReport, MsgBoxStyle.Information)
            If clsUtility.BackupFile(reportFilename, pathReport & System.IO.Path.GetFileName(reportFilename)) Then
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport & " completed!")
            Else
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport & " failed!")
            End If

            If System.IO.File.Exists(pathReport & reportFilename.Replace(tempDir, "").Replace("\", "")) Then
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport & " completed!")
            Else
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport & " failed!")
                'MsgBox("Report path: " & pathReport & reportFilename.Replace(tempDir, "").Replace("\", "") & " backup failed!", MsgBoxStyle.Exclamation)
            End If

        Next
        oFile.Close()

        MsgBox("Reject Payment Transaction - Hash Total Error & LO Cancel (Integral Life)" & vbCrLf & "Reprint completed.", MsgBoxStyle.Information)
        '---

    End Sub

    Function GetDataGL() As DataTable

        Dim sb As New StringBuilder()
        Dim PaidDate As String

        sb.Append(" select GPS_PAYMENT.GP_CORE_SYSTEM , GPS_TL_CORE_SYSTEM.CSYS_CORE_SYSTEMNAME , GPS_PAYMENT.GP_PAYMTH ")
        sb.Append(" , case GPS_PAYMENT.GP_PAYMTH ")
        sb.Append(" when 'C' then 'Cheque' ")
        sb.Append(" when 'D' then 'Draft' ")
        sb.Append(" else 'Media' end  as StrPaymentType ")
        sb.Append(" ,GPS_TRANSREF_REL.TREF_DEP_KEYIN ")
        sb.Append(" , ( select GPS_TL_DEPARTMENT.DEP_DEPNAME ")
        sb.Append(" from GPS_TL_DEPARTMENT ")
        sb.Append(" where GPS_TL_DEPARTMENT.DEP_DEPCODE = GPS_TRANSREF_REL.TREF_DEP_KEYIN ) as DEP_DEPNAME  ")
        sb.Append(" , GPS_PAYMENT.GP_TRANSREF , GPS_PAYMENT.GP_BNKSCODE , GPS_PAYMENT.GP_BNKCODE , GPS_PAYMENT.GP_PAYEE_NAME ")
        sb.Append(" , GPS_PAYMENT.GP_PAYEE_BNKACCNME , GPS_PAYMENT.GP_POLNO , GPS_PAYMENT.GP_CHQNO , GPS_PAYMENT.GP_LASTUPD_STSDATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,1,4) as GP_LASTUPD_STSDATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_PAIDDATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_PAIDDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,1,4) as GP_PAIDDATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_GET_RESULT_DATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_GET_RESULT_DATE,7,2)||'/'||substr(GPS_PAYMENT.GP_GET_RESULT_DATE,5,2)||'/'||substr(GPS_PAYMENT.GP_GET_RESULT_DATE,1,4) as GP_GET_RESULT_DATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_PAYDESC , GPS_TRANSREF_REL.TREF_APPROVEDBY as DataUserID ")
        sb.Append(" from GPS_PAYMENT ")
        '------- �֧������ core system ��� ��ǹ�ҹ
        sb.Append(" left join GPS_TRANSREF_REL ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        sb.Append(" and GPS_PAYMENT.GP_CREATEDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        sb.Append(" and GPS_PAYMENT.GP_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        '------- �֧�����Ū�����ǹ�ҹ
        sb.Append(" left join GPS_TL_CORE_SYSTEM ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TL_CORE_SYSTEM.CSYS_CORE_SYSTEM ")

        'sb.Append(" where GPS_PAYMENT.GP_GET_RESULT_DATE is not null ")
        sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        '------- Begin Adjust Incident log by Songpol 20/01/2015
        ' ������� Bug ���ͧ�ҡ�к�����ʴ������� ���˵� ������ Condition ��Ǩ�ͺ�Ţ�������� �����繤����ҧ ���������� Media ����ʴ�
        'sb.Append(" and GPS_PAYMENT.GP_CHQNO is not null  ")
        '------- End Adjust Incident log by Songpol 20/01/2015
        PaidDate = Trim(txtAsOfDate.Text.Substring(6, 4)) + Trim(txtAsOfDate.Text.Substring(3, 2)) + Trim(txtAsOfDate.Text.Substring(0, 2))

        'sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE = '" & Trim(PaidDate) & "' ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = '" & Trim(PaidDate) & "' ")


        If (cboBatchNo.Text <> "") Then
            sb.Append(" and GPS_PAYMENT.GP_EXPTOOTHSYS_NO = '" & Trim(cboBatchNo.Text) & "' ")
        End If
        sb.Append(" and  GPS_PAYMENT.GP_EXPTOBANK_FILENME is not null ")
        'sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
        sb.Append(" order by GPS_PAYMENT.GP_CORE_SYSTEM , GPS_PAYMENT.GP_PAYMTH ")



        'MsgBox(sb.ToString)
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Function GetDataGL_Detail() As DataTable

        Dim sb As New StringBuilder()
        Dim PaidDate As String

        sb.Append(" select GP_PAYMTH , StrPaymentType , GP_CORE_SYSTEM , CSYS_CORE_SYSTEMNAME , GP_PAIDDATE , GP_PAIDDATE_SHOW  ")
        sb.Append(" , min(NVL(GP_CHQNO,'')) as GP_CHQNO_MIN  ")
        sb.Append(" , max(NVL(GP_CHQNO,'')) as GP_CHQNO_MAX  ")
        sb.Append(", min(NVL(TAX_WHTNO_53,'')) as TAX_WHTNO_53_MIN  ")
        sb.Append(", max(NVL(TAX_WHTNO_53,'')) as TAX_WHTNO_53_MAX  ")
        sb.Append(", min(NVL(TAX_WHTNO_03,'')) as TAX_WHTNO_03_MIN  ")
        sb.Append(", max(NVL(TAX_WHTNO_03,'')) as TAX_WHTNO_03_MAX  ")
        sb.Append(", min(NVL(TAX_WHTNO_02,'')) as TAX_WHTNO_02_MIN  ")
        sb.Append(", max(NVL(TAX_WHTNO_02,'')) as TAX_WHTNO_02_MAX  ")

        sb.Append(" from ( ")

        sb.Append(" select GPS_PAYMENT.GP_CORE_SYSTEM , GPS_TL_CORE_SYSTEM.CSYS_CORE_SYSTEMNAME , GPS_PAYMENT.GP_PAYMTH ")
        sb.Append(" , case GPS_PAYMENT.GP_PAYMTH ")
        sb.Append(" when 'C' then 'Cheque' ")
        sb.Append(" when 'D' then 'Draft' ")
        sb.Append(" else 'Media' end  as StrPaymentType ")
        sb.Append(" ,GPS_TRANSREF_REL.TREF_DEP_KEYIN ")
        sb.Append(" , ( select GPS_TL_DEPARTMENT.DEP_DEPNAME ")
        sb.Append(" from GPS_TL_DEPARTMENT ")
        sb.Append(" where GPS_TL_DEPARTMENT.DEP_DEPCODE = GPS_TRANSREF_REL.TREF_DEP_KEYIN ) as DEP_DEPNAME  ")
        sb.Append(" , GPS_PAYMENT.GP_TRANSREF , GPS_PAYMENT.GP_BNKSCODE , GPS_PAYMENT.GP_BNKCODE , GPS_PAYMENT.GP_PAYEE_NAME ")
        sb.Append(" , GPS_PAYMENT.GP_PAYEE_BNKACCNME , GPS_PAYMENT.GP_POLNO , GPS_PAYMENT.GP_CHQNO , GPS_PAYMENT.GP_LASTUPD_STSDATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_LASTUPD_STSDATE,1,4) as GP_LASTUPD_STSDATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_PAIDDATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_PAIDDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,1,4) as GP_PAIDDATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_GET_RESULT_DATE ")
        sb.Append(" ,  substr(GPS_PAYMENT.GP_GET_RESULT_DATE,7,2)||'/'||substr(GPS_PAYMENT.GP_GET_RESULT_DATE,5,2)||'/'||substr(GPS_PAYMENT.GP_GET_RESULT_DATE,1,4) as GP_GET_RESULT_DATE_SHOW ")
        sb.Append(" , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_PAYDESC , GPS_TRANSREF_REL.TREF_APPROVEDBY as DataUserID ")

        sb.Append(" ,  GPS_WHT.TAX_WHTNO ")

        sb.Append(" ,  case substr(GPS_WHT.TAX_WHTNO,1,2) ")
        sb.Append(" when '53' then GPS_WHT.TAX_WHTNO ")
        sb.Append(" else '' end  as TAX_WHTNO_53 ")

        sb.Append(" ,  case substr(GPS_WHT.TAX_WHTNO,1,2) ")
        sb.Append(" when '03' then GPS_WHT.TAX_WHTNO ")
        sb.Append(" else '' end  as TAX_WHTNO_03 ")

        sb.Append(" ,  case substr(GPS_WHT.TAX_WHTNO,1,2) ")
        sb.Append(" when '02' then GPS_WHT.TAX_WHTNO ")
        sb.Append(" else '' end  as TAX_WHTNO_02 ")

        sb.Append(" from GPS_PAYMENT ")
        '------- �֧������ core system ��� ��ǹ�ҹ
        sb.Append(" left join GPS_TRANSREF_REL ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        sb.Append(" and GPS_PAYMENT.GP_CREATEDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        sb.Append(" and GPS_PAYMENT.GP_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        '------- �֧�����Ū�����ǹ�ҹ
        sb.Append(" left join GPS_TL_CORE_SYSTEM ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM = GPS_TL_CORE_SYSTEM.CSYS_CORE_SYSTEM ")

        '------- �֧���������ǹ�ͧ����
        sb.Append(" left join GPS_WHT  ")
        sb.Append(" on GPS_PAYMENT.GP_CORE_SYSTEM = GPS_WHT.TAX_CORE_SYSTEM ")
        sb.Append(" and GPS_PAYMENT.GP_CREATEDATE = GPS_WHT.TAX_CREATEDATE ")
        sb.Append(" and GPS_PAYMENT.GP_TRANSREF = GPS_WHT.TAX_TRANSREF ")
        sb.Append(" and GPS_PAYMENT.GP_GPTREF_SEQNO = GPS_WHT.TAX_GPTREF_SEQNO ")

        sb.Append(" where GPS_PAYMENT.GP_FLAG_GET_RESULT = 'Y' ")
        '------- Begin Adjust Incident log by Songpol 20/01/2015
        ' ������� Bug ���ͧ�ҡ�к�����ʴ������� ���˵� ������ Condition ��Ǩ�ͺ�Ţ�������� �����繤����ҧ ���������� Media ����ʴ�
        'sb.Append(" and GPS_PAYMENT.GP_CHQNO is not null  ")
        '------- End Adjust Incident log by Songpol 20/01/2015
        PaidDate = Trim(txtAsOfDate.Text.Substring(6, 4)) + Trim(txtAsOfDate.Text.Substring(3, 2)) + Trim(txtAsOfDate.Text.Substring(0, 2))

        'sb.Append(" and GPS_PAYMENT.GP_GET_RESULT_DATE = '" & Trim(PaidDate) & "' ")
        sb.Append(" and GPS_PAYMENT.GP_EXPTOOTHSYS_DATE = '" & Trim(PaidDate) & "' ")
        If (cboBatchNo.Text <> "") Then
            sb.Append(" and GPS_PAYMENT.GP_EXPTOOTHSYS_NO = '" & Trim(cboBatchNo.Text) & "' ")
        End If
        sb.Append(" and  GPS_PAYMENT.GP_EXPTOBANK_FILENME is not null ")
        'sb.Append(" and GPS_PAYMENT.GP_CORE_SYSTEM in ('PP' , 'TLM' ) ")
        'sb.Append(" order by GPS_PAYMENT.GP_CORE_SYSTEM , GPS_PAYMENT.GP_PAYMTH ")
        sb.Append(" ) ")
        sb.Append(" group by  GP_PAYMTH , StrPaymentType ,  GP_CORE_SYSTEM , CSYS_CORE_SYSTEMNAME , GP_PAIDDATE , GP_PAIDDATE_SHOW ")
        sb.Append(" order by  GP_PAYMTH , StrPaymentType,  GP_CORE_SYSTEM , CSYS_CORE_SYSTEMNAME , GP_PAIDDATE , GP_PAIDDATE_SHOW ")



        'MsgBox(sb.ToString)
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function


    Private Sub btnRRR_Click(sender As Object, e As EventArgs) Handles btnRRR.Click
        If (Trim(cboBatchNo.Text) <> "") Then
            PrintReportRRR()
        Else
            MsgBox(" ��س��кآ����� Batch No ")
        End If
    End Sub
End Class