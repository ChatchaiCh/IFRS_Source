Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmMaintainWatchList2
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub FrmMaintainWatchLists_Add_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.WaitCursor
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click


        If txtFirstName.Text.Trim = "" Then
            MsgBox("��سҡ�͡����", MsgBoxStyle.Information)
            txtFirstName.Focus()
            Exit Sub
        End If
        If txtLastName.Text.Trim = "" Then
            MsgBox("��سҡ�͡���ʡ��", MsgBoxStyle.Information)
            txtLastName.Focus()
            Exit Sub
        End If
        If txtMoney.Text.Trim = "" Then
            MsgBox("��سҡ�͡�ӹǹ�Թ", MsgBoxStyle.Information)
            txtMoney.Focus()
            Exit Sub
        ElseIf Convert.ToDouble(txtMoney.Text.Trim) <= 0 Then
            MsgBox("��سҡ�͡�ӹǹ�Թ", MsgBoxStyle.Information)
            txtMoney.Focus()
            Exit Sub
        End If
        If dtpDateTo.Value.ToString("yyyyMMdd") < dtpDateFrom.Value.ToString("yyyyMMdd") Then
            MsgBox("�ѹ���������� / ����ش ���͹�������١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim sbchk As New StringBuilder()
        sbchk.Append("SELECT * FROM GPS_WATCHLISTS_MA2 ")
        sbchk.Append("WHERE WLSTP_FNAME='" & txtFirstName.Text.Trim & "' ")
        sbchk.Append("AND WLSTP_LNAME='" & txtLastName.Text.Trim & "' ")
        sbchk.Append("AND WLSTP_S_EFFDATE='" & dtpDateFrom.Value.ToString("yyyyMMdd") & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)
        If dt.Rows.Count > 0 Then
            GetData()
            MsgBox("Data is duplicated")
            Exit Sub
        End If

        Try

            Dim sb As New StringBuilder()

            sb.Append("INSERT INTO GPS_WATCHLISTS_MA2 VALUES (")
            sb.Append("'" & txtFirstName.Text.Trim & "', ")
            sb.Append("'" & txtLastName.Text.Trim & "', ")
            sb.Append("'" & txtPolNo.Text & "', ")
            sb.Append("'" & txtMoney.Text & "', ")
            sb.Append("'" & dtpDateFrom.Value.ToString("yyyyMMdd") & "', ")
            sb.Append("'" & dtpDateTo.Value.ToString("yyyyMMdd") & "', ")
            sb.Append("'ACTIVE',")
            sb.Append("'" & gUserLogin & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
            sb.Append("'" & gUserLogin & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')) ")

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim Rec As Integer
            Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
            If Rec > 0 Then
                oleTrans.Commit()

                Clear()
                GetData()
                MsgBox("Data inserted successfully")
            Else
                oleTrans.Rollback()

                MsgBox("Cannot insert data" & vbCrLf & clsUtility.ErrConnectDBMessage)
            End If

        Catch ex As Exception
            MsgBox("Cannot insert data" & vbCrLf & ex.ToString)
        End Try

    End Sub
    Private Sub Clear()
        btnAdd.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False

        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtPolNo.Text = ""
        txtMoney.Text = ""
        dtpDateFrom.Value = Date.Now
        dtpDateTo.Value = Date.Now
        txtFirstName.ReadOnly = False
        txtLastName.ReadOnly = False
        dtpDateFrom.Enabled = True

        'Chk1.Checked = False
        'Chk2.Checked = False
        'dtpDateFrom.Enabled = False
        'dtpDateTo.Enabled = False

    End Sub
    Private Sub GetData()


        Dim sb As New StringBuilder()
        'sb.Append("SELECT * FROM GPS_WATCHLISTS_MA2 WHERE WLSTP_STATUS='ACTIVE'")

        sb.Append("SELECT WLSTP_FNAME,WLSTP_LNAME,WLSTP_POLNO,WLSTP_AMOUNT, ")
        sb.Append("TO_CHAR(TO_DATE(WLSTP_S_EFFDATE,'YYYYMMDD'),'DD/MM/YYYY') AS WLSTP_S_EFFDATE, ")
        sb.Append("TO_CHAR(TO_DATE(WLSTP_E_EFFDATE,'YYYYMMDD'),'DD/MM/YYYY') AS WLSTP_E_EFFDATE ")
        sb.Append("FROM GPS_WATCHLISTS_MA2 ")
        sb.Append("WHERE WLSTP_STATUS = 'ACTIVE' ")

        If txtFirstName.Text <> "" Then
            sb.Append("AND WLSTP_FNAME LIKE '%" & txtFirstName.Text & "%'")
        End If
        If txtLastName.Text <> "" Then
            sb.Append("AND WLSTP_LNAME LIKE '%" & txtLastName.Text & "%'")
        End If


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        GetData()
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        'For Each row As DataGridViewRow In DataGridView1.SelectedRows
        'Next
        If MessageBox.Show("Do you want to delete ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                    Exit Sub
                End If
            End If

            Dim sb As New StringBuilder()

            sb.Append("UPDATE GPS_WATCHLISTS_MA2 SET ")
            sb.Append("WLSTP_STATUS='INACTIVE', ")
            sb.Append("UPDATEDBY='" & gUserLogin & "',")
            sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
            sb.Append("WHERE WLSTP_FNAME='" & txtFirstName.Text.Trim & "' ")
            sb.Append("AND WLSTP_LNAME='" & txtLastName.Text.Trim & "' ")
            sb.Append("AND WLSTP_S_EFFDATE='" & dtpDateFrom.Value.ToString("yyyyMMdd") & "' ")

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim Rec As Integer
            Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

            If Rec > 0 Then
                oleTrans.Commit()

                Clear()
                GetData()
                MsgBox("Data deleted successfully")

            Else
                oleTrans.Rollback()

                MsgBox("Cannot delete data" & vbCrLf & clsUtility.ErrConnectDBMessage)
            End If

        End If

    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "WLSTP_FNAME"
            .Name = "����"
            .ReadOnly = True
            .Width = 200
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "WLSTP_LNAME"
            .Name = "���ʡ��"
            .ReadOnly = True
            .Width = 200
            DataGridView1.Columns.Add(c2)
        End With

        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "WLSTP_POLNO"
            .Name = "�Ţ����������"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c3)
        End With

        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "WLSTP_AMOUNT"
            .Name = "�ӹǹ�Թ������"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c4)
        End With

        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "WLSTP_S_EFFDATE"
            .Name = "�ѹ����������"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c5)
        End With

        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "WLSTP_E_EFFDATE"
            .Name = "�ѹ�������ش"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c6)
        End With

        'Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        'With c7
        '    .DataPropertyName = "WLSTP_STATUS"
        '    .Name = "ʶҹ�"
        '    .ReadOnly = True
        '    .Width = 80
        '    DataGridView1.Columns.Add(c7)
        'End With

        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)

        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(3).DefaultCellStyle.Format = "###,###.00" 'AMOUNT
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
            Dim format As String
            format = "dd/MM/yyyy"

            txtFirstName.Text = CStr(Me.DataGridView1.SelectedCells(0).Value.ToString)
            txtLastName.Text = CStr(Me.DataGridView1.SelectedCells(1).Value.ToString)
            txtPolNo.Text = CStr(Me.DataGridView1.SelectedCells(2).Value.ToString)
            txtMoney.Text = Convert.ToDouble(Me.DataGridView1.SelectedCells(3).Value).ToString("###,##0.00")
            dtpDateFrom.Value = Date.ParseExact(Me.DataGridView1.SelectedCells(4).Value.ToString, format, New Globalization.CultureInfo("en-US"))
            dtpDateTo.Value = Date.ParseExact(Me.DataGridView1.SelectedCells(5).Value.ToString, format, New Globalization.CultureInfo("en-US"))

            txtFirstName.ReadOnly = True
            txtLastName.ReadOnly = True
            dtpDateFrom.Enabled = False

            btnAdd.Enabled = False
            btnUpdate.Enabled = True
            btnDelete.Enabled = True

        End If
    End Sub
    Private Sub txtMoney_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMoney.KeyPress
        If e.KeyChar = "."c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("."c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.WaitCursor
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        'If txtFirstName.Text.Trim = "" Then
        '    MsgBox("��سҡ�͡����", MsgBoxStyle.Information)
        '    txtFirstName.Focus()
        '    Exit Sub
        'End If
        'If txtLastName.Text.Trim = "" Then
        '    MsgBox("��سҡ�͡���ʡ��", MsgBoxStyle.Information)
        '    txtLastName.Focus()
        '    Exit Sub
        'End If

        If txtMoney.Text.Trim = "" Then
            MsgBox("��سҡ�͡�ӹǹ�Թ", MsgBoxStyle.Information)
            txtMoney.Focus()
            Exit Sub
        ElseIf Convert.ToDouble(txtMoney.Text.Trim) <= 0 Then
            MsgBox("��سҡ�͡�ӹǹ�Թ", MsgBoxStyle.Information)
            txtMoney.Focus()
            Exit Sub
        End If
        If dtpDateTo.Value.ToString("yyyyMMdd") < dtpDateFrom.Value.ToString("yyyyMMdd") Then
            MsgBox("�ѹ���������� / ����ش ���͹�������١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim sb As New StringBuilder()

        sb.Append("UPDATE GPS_WATCHLISTS_MA2 SET ")
        sb.Append("WLSTP_POLNO='" & txtPolNo.Text & "', ")
        sb.Append("WLSTP_AMOUNT='" & Convert.ToDouble(txtMoney.Text.Trim) & "', ")
        sb.Append("WLSTP_E_EFFDATE='" & dtpDateTo.Value.ToString("yyyyMMdd") & "', ")
        sb.Append("UPDATEDBY='" & gUserLogin & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE WLSTP_FNAME='" & txtFirstName.Text.Trim & "' ")
        sb.Append("AND WLSTP_LNAME='" & txtLastName.Text.Trim & "' ")
        sb.Append("AND WLSTP_S_EFFDATE='" & dtpDateFrom.Value.ToString("yyyyMMdd") & "' ")


        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim Rec As Integer
        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
        If Rec > 0 Then
            oleTrans.Commit()

            Clear()
            GetData()
            MsgBox("Data updated successfully")

        Else
            oleTrans.Rollback()

            MsgBox("Cannot update data" & vbCrLf & clsUtility.ErrConnectDBMessage)
        End If
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Clear()
        'GetData()
    End Sub
    Private Sub Chk1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chk1.CheckedChanged
        If Chk1.Checked = True Then
            dtpDateFrom.Enabled = True
        Else
            dtpDateFrom.Enabled = False
        End If
    End Sub
    Private Sub Chk2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chk2.CheckedChanged
        If Chk2.Checked = True Then
            dtpDateTo.Enabled = True
        Else
            dtpDateTo.Enabled = False
        End If
    End Sub
    'Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs) Handles dtpDateFrom.ValueChanged
    '    TextBox1.Text = dtpDateFrom.Value.ToString("dd/MM/yyyy")
    'End Sub


End Class