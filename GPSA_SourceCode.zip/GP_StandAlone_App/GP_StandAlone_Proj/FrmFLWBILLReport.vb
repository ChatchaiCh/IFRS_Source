﻿Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Imports System.Globalization

Public Class FrmFLWBILLReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim lstType As New List(Of AddListType)
    Public Class AddListType
        Public TypeName As String
        Public TypeID As String
        Sub New(ByVal TypeName As String, ByVal TypeID As String)
            Me.TypeName = TypeName
            Me.TypeID = TypeID
        End Sub
        Public Overrides Function ToString() As String
            Return Me.TypeName
        End Function
    End Class

    Private Sub FrmFlagGPReport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListType()
        ListCoreSystem()

        setTxtPurPoseDateEnabled(True)
        setTxtApproveDateEnabled(True)

        'txtPurPoseDateFrom.Text = Now.ToString("dd/MM/yyyy")
        'txtPurPoseDateTo.Text = Now.ToString("dd/MM/yyyy")

        'txtApproveDateFrom.Text = Now.ToString("dd/MM/yyyy")
        'txtApproveDateTo.Text = Now.ToString("dd/MM/yyyy")

    End Sub

    Private Sub ListType()
        lstType.Add(New AddListType("ALL", "A"))
        lstType.Add(New AddListType("Y", "Y"))
        lstType.Add(New AddListType("N", "N"))
        lstType.Add(New AddListType(" ", " "))

        cboType.DataSource = lstType
        cboType.SelectedIndex = 0
    End Sub
    Private Sub ListCoreSystem()
        Dim sb As New StringBuilder()

        sb.Append("select csys_core_system,csys_core_systemname from gps_tl_core_system where csys_core_system <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            With cboCoreSystem
                .DataSource = dt
                .DisplayMember = "csys_core_systemname"
                .ValueMember = "csys_core_system"
            End With
        End If
        cboCoreSystem.SelectedIndex = 0
    End Sub

    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptGPFollowFlag.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataReport()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()

            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()
            Dim discretePdate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramPdate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteAdate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramAdate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteFlag As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramFlag As New CrystalDecisions.Shared.ParameterField()
            Dim discreteCoreSystem As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramCoreSystem As New CrystalDecisions.Shared.ParameterField()

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)


            paramPdate.ParameterFieldName = "pPurposeDate"
            discretePdate.Value = txtPurPoseDateFrom.Text.Trim & " To " & txtPurPoseDateTo.Text.Trim
            paramPdate.CurrentValues.Add(discretePdate)
            paramFields.Add(paramPdate)

            paramAdate.ParameterFieldName = "pApproveDate"
            discreteAdate.Value = txtApproveDateFrom.Text.Trim & " To " & txtApproveDateTo.Text.Trim
            paramAdate.CurrentValues.Add(discreteAdate)
            paramFields.Add(paramAdate)

            paramFlag.ParameterFieldName = "pFlag"
            discreteFlag.Value = cboType.Text.ToString
            paramFlag.CurrentValues.Add(discreteFlag)
            paramFields.Add(paramFlag)

            paramCoreSystem.ParameterFieldName = "pCoreSystem"
            discreteCoreSystem.Value = cboCoreSystem.Text.Trim
            paramCoreSystem.CurrentValues.Add(discreteCoreSystem)
            paramFields.Add(paramCoreSystem)


            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmFLWBILLReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub

    Function GetDataReport() As DataTable
        Dim item As AddListType = TryCast(cboType.SelectedItem, AddListType)

        Dim sb As New StringBuilder()

        sb.Append("select l.tref_core_system as core_system, ")
        sb.Append("l.tref_transref as transref, ")
        sb.Append("l.tref_jn_hold as jn_hold, ")
        sb.Append("l.tref_paiddate as paid_date, ")
        sb.Append("case when l.tref_paymth ='M' then p.gpcr_payee_bnkaccnme else p.gpcr_payee_name end payee_name, ")
        sb.Append("nvl(p.gpcr_amount,0) as amount, ")
        sb.Append("nvl(w.taxcr_tax_amt,0) as tax_amount ")
        sb.Append("from gps_transref_rel l inner join gps_payment_creation p ")
        sb.Append("on l.tref_createdate=p.gpcr_createdate ")
        sb.Append("and l.tref_core_system=p.gpcr_core_system ")
        sb.Append("and l.tref_transref=p.gpcr_transref ")
        sb.Append("left join gps_wht_creation w ")
        sb.Append("on l.tref_createdate=w.taxcr_createdate ")
        sb.Append("and l.tref_core_system=w.taxcr_core_system ")
        sb.Append("and l.tref_transref=w.taxcr_transref ")
        sb.Append("and p.gpcr_gptref_seqno=w.taxcr_gptref_seqno ")
        sb.Append("where 1=1 ")
        sb.Append("and tref_core_system = '" & cboCoreSystem.SelectedValue.ToString & "' ")


        If item.TypeID <> "A" Then
            sb.Append("and p.gpcr_flag_flwbill='" & item.TypeID & "' ")
        End If

        If txtPurPoseDateFrom.Text.Trim <> "" Then
            Dim datefrom As String
            datefrom = txtPurPoseDateFrom.Text.Substring(6, 4) & txtPurPoseDateFrom.Text.Substring(3, 2) & txtPurPoseDateFrom.Text.Substring(0, 2)
            sb.Append("and l.tref_createdate >= '" & datefrom & "' ")
        End If

        If txtPurPoseDateTo.Text.Trim <> "" Then
            Dim dateto As String
            dateto = txtPurPoseDateTo.Text.Substring(6, 4) & txtPurPoseDateTo.Text.Substring(3, 2) & txtPurPoseDateTo.Text.Substring(0, 2)
            sb.Append("and l.tref_createdate <= '" & dateto & "' ")
            sb.Append("and l.tref_approveddate is null ")
        End If

        If txtApproveDateFrom.Text.Trim <> "" Then
            Dim datefrom As String
            datefrom = txtApproveDateFrom.Text.Substring(6, 4) & txtApproveDateFrom.Text.Substring(3, 2) & txtApproveDateFrom.Text.Substring(0, 2)
            sb.Append("and l.tref_approveddate >= '" & datefrom & "' ")

        End If

        If txtApproveDateTo.Text.Trim <> "" Then
            Dim dateto As String
            dateto = txtApproveDateTo.Text.Substring(6, 4) & txtApproveDateTo.Text.Substring(3, 2) & txtApproveDateTo.Text.Substring(0, 2)
            sb.Append("and l.tref_approveddate <= '" & dateto & "' ")
        End If


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click
        Dim dateApproveFrom As DateTime
        Dim dateApproveto As DateTime
        Dim datePurposeFrom As DateTime
        Dim datePurposeto As DateTime

        If txtPurPoseDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtPurPoseDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"

            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, datePurposeFrom) Then

            Else
                MsgBox("Purpose Date format is not valid")
                Exit Sub
            End If
        End If

        If txtPurPoseDateTo.Text.Trim <> "" Then
            Dim dateString As String = txtPurPoseDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"

            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, datePurposeto) Then

            Else
                MsgBox("Purpose Date format is not valid")
                Exit Sub
            End If
        End If

        If txtApproveDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtApproveDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"

            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateApproveFrom) Then

            Else
                MsgBox("Approve Date format is not valid")
                Exit Sub
            End If
        End If

        If txtApproveDateTo.Text.Trim <> "" Then
            Dim dateString As String = txtApproveDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"

            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateApproveto) Then

            Else
                MsgBox("Approve Date format is not valid")
                Exit Sub
            End If
        End If

        'Validate textbox
        If txtPurPoseDateFrom.Text.Trim <> "" And txtPurPoseDateTo.Text.Trim <> "" Then
            If datePurposeto < datePurposeFrom Then
                MsgBox("Purpose date from must not more than date to")
                Exit Sub
            End If
        End If

        If txtApproveDateFrom.Text.Trim <> "" And txtApproveDateTo.Text.Trim <> "" Then
            If dateApproveto < dateApproveFrom Then
                MsgBox("Approve date from must not more than date to")
                Exit Sub
            End If
        End If

        PrintReport()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    '<<===============Begin Event
    'Event pre posting date
    Private Sub txtPurPoseDateFrom_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPurPoseDateFrom.TextChanged
        If txtPurPoseDateFrom.Text <> "" And txtPurPoseDateTo.Text <> "" Then
            setTxtApproveDateEnabled(False)
        ElseIf txtPurPoseDateFrom.Text = "" And txtPurPoseDateTo.Text <> "" Then
            setTxtApproveDateEnabled(False)
        ElseIf txtPurPoseDateFrom.Text <> "" And txtPurPoseDateTo.Text = "" Then
            setTxtApproveDateEnabled(False)
        Else
            setTxtApproveDateEnabled(True)
        End If
    End Sub

    Private Sub txtPurPoseDateTo_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPurPoseDateTo.TextChanged
        If txtPurPoseDateTo.Text <> "" And txtPurPoseDateFrom.Text <> "" Then
            setTxtApproveDateEnabled(False)
        ElseIf txtPurPoseDateTo.Text = "" And txtPurPoseDateFrom.Text <> "" Then
            setTxtApproveDateEnabled(False)
        ElseIf txtPurPoseDateTo.Text <> "" And txtPurPoseDateFrom.Text = "" Then
            setTxtApproveDateEnabled(False)
        Else
            setTxtApproveDateEnabled(True)
        End If
    End Sub

    'Event approve date
    Private Sub txtApproveDateFrom_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtApproveDateFrom.TextChanged
        If txtApproveDateFrom.Text <> "" And txtApproveDateTo.Text <> "" Then
            setTxtPurPoseDateEnabled(False)
        ElseIf txtApproveDateFrom.Text = "" And txtApproveDateTo.Text <> "" Then
            setTxtPurPoseDateEnabled(False)
        ElseIf txtApproveDateFrom.Text <> "" And txtApproveDateTo.Text = "" Then
            setTxtPurPoseDateEnabled(False)
        Else
            setTxtPurPoseDateEnabled(True)
        End If
    End Sub

    Private Sub txtApproveDateTo_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtApproveDateTo.TextChanged
        If txtApproveDateTo.Text <> "" And txtApproveDateFrom.Text <> "" Then
            setTxtPurPoseDateEnabled(False)
        ElseIf txtApproveDateTo.Text = "" And txtApproveDateFrom.Text <> "" Then
            setTxtPurPoseDateEnabled(False)
        ElseIf txtApproveDateTo.Text <> "" And txtApproveDateFrom.Text = "" Then
            setTxtPurPoseDateEnabled(False)
        Else
            setTxtPurPoseDateEnabled(True)
        End If
    End Sub

    'Function
    Public Function setTxtPurPoseDateEnabled(ByVal isEnabled As Boolean)
        txtPurPoseDateFrom.Text = ""
        txtPurPoseDateTo.Text = ""
        txtPurPoseDateFrom.Enabled = isEnabled
        txtPurPoseDateTo.Enabled = isEnabled
    End Function

    Public Function setTxtApproveDateEnabled(ByVal isEnabled As Boolean)
        txtApproveDateFrom.Text = ""
        txtApproveDateTo.Text = ""
        txtApproveDateFrom.Enabled = isEnabled
        txtApproveDateTo.Enabled = isEnabled
    End Function
    '<<===============END
End Class