Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmBuyDraftReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsBuyBankDraft
    Dim countRptData As Integer = 0
    Private Sub FrmPrintChequeGiftDraft_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        txtBatchDate.Text = Now.ToString("dd/MM/yyyy")
        txtBatchNo.Text = clsBusiness.fnCallLastBatchNo(clsUtility.gConnGP, "SCBLIFE_CHQ")
        BindPaymentType()
        BindFormat()
    End Sub
    Private Sub BindPaymentType()

        Dim dt As DataTable
        dt = cls.BindPaymentType(clsUtility.gConnGP)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!ID = 0
            dr!NAME = "ALL"
            dt.Rows.InsertAt(dr, 0)
            With cboPaymentType
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
    End Sub
    Private Sub BindFormat()
        cboFormatReport.Items.Add("ALL")
        cboFormatReport.Items.Add("Excel")
        cboFormatReport.Items.Add("PDF")

        cboFormatReport.SelectedIndex = 0
    End Sub
    Private Sub PrintReportAttFile()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPrintChequeGiftDraft.rpt")

        Dim batchdate As String
        If txtBatchDate.Text.Trim <> "" Then
            batchdate = txtBatchDate.Text.Substring(6, 4) & txtBatchDate.Text.Substring(3, 2) & txtBatchDate.Text.Substring(0, 2)
        Else
            batchdate = ""
        End If

        Dim dt As DataTable = New DataTable()
        dt = cls.BindDataInstrument(clsUtility.gConnGP, batchdate, txtBatchNo.Text, cboPaymentType.Text.Trim)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            countRptData = countRptData + 1
            'frm1.ExportPDF(dt, "������Ṻ")

            frm1.FillDataTableToReport(dt)
            frm1.Text = Me.Text
            frm1.Show()

            'Else
            'MsgBox("����բ������Ṻ", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub PrintReportForm()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptApplicationForm.rpt") 'RptCertification

        Dim batchdate As String
        If txtBatchDate.Text.Trim <> "" Then
            batchdate = txtBatchDate.Text.Substring(6, 4) & txtBatchDate.Text.Substring(3, 2) & txtBatchDate.Text.Substring(0, 2)
        Else
            batchdate = ""
        End If

        Dim dt As DataTable = New DataTable()
        dt = cls.BindDataPayment(clsUtility.gConnGP, batchdate, txtBatchNo.Text, cboPaymentType.Text.Trim)


        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            countRptData = countRptData + 1
            'frm1.ExportPDF(dt, "�����㺤Ӣ�")

            frm1.FillDataTableToReport(dt)
            frm1.Text = Me.Text
            frm1.Show()
            'Else
            'MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub PrintReportXLS()

        Dim batchdate As String
        If txtBatchDate.Text.Trim <> "" Then
            batchdate = txtBatchDate.Text.Substring(6, 4) & txtBatchDate.Text.Substring(3, 2) & txtBatchDate.Text.Substring(0, 2)
        Else
            batchdate = ""
        End If


        Dim dt As DataTable = New DataTable()
        dt = cls.GroupByDataInstrument(clsUtility.gConnGP, batchdate, txtBatchNo.Text, cboPaymentType.Text.Trim)


        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            countRptData = countRptData + 1

          
            'frm1.ExportExcel(dt, "�͡��� Update ������")
            For Each dr As DataRow In dt.Rows

                Dim frm1 As New FrmRptViewer
                frm1.TopLevel = False
                frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
                FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


                frm1.CrDoc.Close()
                frm1.CrDoc.Load(sReportPath & "RptInstrumentXLS.rpt")

                Dim dtrpt As New DataTable
                dtrpt = cls.BindDataInstrumentForXls(clsUtility.gConnGP, dr("GP_CHQNO"))

                If Not IsNothing(dtrpt) AndAlso dtrpt.Rows.Count > 0 Then

                    frm1.FillDataTableToReport(dtrpt)
                    frm1.Text = Me.Text
                    frm1.Show()

                End If

            Next


            'Else
            'MsgBox("No Data XLS File", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtBatchNo.Text = "" Then
            MsgBox("��س��к��Ţ��� Bach No")
            Exit Sub
        End If

        Select Case cboFormatReport.Text
            Case "ALL"
                If cboPaymentType.Text = "ALL" Then
                    PrintReportAttFile()
                Else
                    If cboPaymentType.SelectedValue.ToString = "C:G" Or cboPaymentType.SelectedValue.ToString = "C:B" Then
                        PrintReportAttFile()
                    End If
                End If

                PrintReportForm()
                PrintReportXLS()
            Case "Excel"
                PrintReportXLS()
            Case "PDF"
                If cboPaymentType.Text = "ALL" Then
                    PrintReportAttFile()
                Else
                    If cboPaymentType.SelectedValue.ToString = "C:G" Or cboPaymentType.SelectedValue.ToString = "C:B" Then
                        PrintReportAttFile()
                    End If
                End If

                PrintReportForm()
        End Select

        If countRptData < 1 Then
            MsgBox("No Data", MsgBoxStyle.Information)
        Else
            Dim frm As New FrmBuyDraftReport

            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()
        End If
       
    End Sub
    Private Sub txtBatchDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtBatchDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtBatchDate.Text.Trim = "" Then

            Else
                Dim dateString As String = txtBatchDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")
                    txtBatchDate.Text = ""
                    txtBatchDate.Focus()

                End If
            End If

        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
        'PrintReportForm()
    End Sub
End Class