﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Imports System.Globalization

Public Class frmExportPHORNGORDOR2
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim clsRpt As New ClsReport
    Dim clsWht As New ClsWHT
    Dim clsLog As New ClsLog
    Dim clsHashLO As New ClsHashTotalErrorLOCancel
    Dim LO_Dup As New StringBuilder
    Dim sDataExist As New StringBuilder
    Dim strPathExportFile As String
    Dim clsConnectDB As ConnectDB


    Private Sub frmExportPHORNGORDOR2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2 = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        strPathExportFile = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "PHORNGORDOR2_PATH")

        InitializeForm()

    End Sub
    Private Sub InitializeForm()
        Dim strFormatDate As String = "dd-MM-yyyy"
        Dim dteDateShow As Date = DateTime.Today.AddMonths(-1)
        Dim dteEndMonthShow As New DateTime(DateTime.Today.Year, DateTime.Today.Month, 1)
        dtpFromDate.CustomFormat = strFormatDate
        dtpFromDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), 1)
        dtpToDate.CustomFormat = strFormatDate
        dtpToDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), dteEndMonthShow.AddDays(-1).Day)
        btnCancel.Focus()
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnExport_Click(sender As System.Object, e As System.EventArgs) Handles btnExport.Click
        Try

            Dim csv As String = String.Empty
            Dim csv_exten As String = String.Empty
            Dim dt As DataTable = clsWht.GetDataPhorngordor2(clsUtility.gConnGP, dtpFromDate.Value.ToString("yyyyMMdd"), dtpToDate.Value.ToString("yyyyMMdd"))
            Dim dt_exten As DataTable = clsWht.GetDataPhorngordor2_Exten(clsUtility.gConnGP, dtpFromDate.Value.ToString("yyyyMMdd"), dtpToDate.Value.ToString("yyyyMMdd"))

            If dt Is Nothing Then
                MsgBox("ไม่พบข้อมูล", vbExclamation)
                Exit Sub
            End If
            If dt.Rows.Count <= 0 Then
                MsgBox("ไม่พบข้อมูล", vbExclamation)
                Exit Sub
            End If

            For Each row As DataRow In dt.Rows
                'Add the Data rows.
                csv += row(0).ToString & vbCr & vbLf
            Next

            'Exporting to text file
            Dim strFileName As String = "PHORNGORDOR2_" & dtpFromDate.Value.ToString("yyyyMM") & ".txt"
            File.WriteAllText("D:\" & strFileName, csv, Encoding.Unicode)
            '-- move file to server
            Dim strSourceFileName As String = "D:\" & strFileName
            Dim strDestinationFileName As String = strPathExportFile & strFileName
            clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
            '-- end move file to server

            If Not dt_exten Is Nothing AndAlso dt_exten.Rows.Count > 0 Then
                For Each row As DataRow In dt_exten.Rows
                    'Add the Data rows.
                    csv_exten += row(0).ToString & vbCr & vbLf
                Next
                'Exporting to text file
                Dim strFileName_exten As String = "PHORNGORDOR2_" & dtpFromDate.Value.ToString("yyyyMM") & "_EXTEN.txt"
                File.WriteAllText("D:\" & strFileName_exten, csv_exten, Encoding.Unicode)
                '-- move file to server
                Dim strSourceFileName_exten As String = "D:\" & strFileName_exten
                Dim strDestinationFileName_exten As String = strPathExportFile & strFileName_exten
                clsUtility.BackupFile(strSourceFileName_exten, strDestinationFileName_exten)
                '-- end move file to server
                MsgBox("Export ภงด.2 เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & "PHORNGORDOR2_" & dtpFromDate.Value.ToString("yyyyMM") & ".txt" & vbCrLf & "==> " & strPathExportFile & "PHORNGORDOR2_" & dtpFromDate.Value.ToString("yyyyMM") & "_EXTEN.txt", MsgBoxStyle.Information)
            Else
                MsgBox("Export ภงด.2 เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & "PHORNGORDOR2_" & dtpFromDate.Value.ToString("yyyyMM") & ".txt", MsgBoxStyle.Information)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical)
        End Try

    End Sub
End Class