<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMaintainCHQNO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.ChkChq2 = New System.Windows.Forms.CheckBox()
        Me.ChkChq1 = New System.Windows.Forms.CheckBox()
        Me.txtServiceName = New System.Windows.Forms.TextBox()
        Me.txtServiceCode = New System.Windows.Forms.TextBox()
        Me.txtPayGroup = New System.Windows.Forms.TextBox()
        Me.txtAccountCode = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_e_chq2 = New System.Windows.Forms.TextBox()
        Me.txt_s_chq2 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_e_chq1 = New System.Windows.Forms.TextBox()
        Me.txt_s_chq1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnUpdate = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 271)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(724, 231)
        Me.DataGridView1.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(303, 17)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.Controls.Add(Me.ChkChq2)
        Me.PanelD1.Controls.Add(Me.ChkChq1)
        Me.PanelD1.Controls.Add(Me.txtServiceName)
        Me.PanelD1.Controls.Add(Me.txtServiceCode)
        Me.PanelD1.Controls.Add(Me.txtPayGroup)
        Me.PanelD1.Controls.Add(Me.txtAccountCode)
        Me.PanelD1.Controls.Add(Me.Label10)
        Me.PanelD1.Controls.Add(Me.txt_e_chq2)
        Me.PanelD1.Controls.Add(Me.txt_s_chq2)
        Me.PanelD1.Controls.Add(Me.Label8)
        Me.PanelD1.Controls.Add(Me.txt_e_chq1)
        Me.PanelD1.Controls.Add(Me.txt_s_chq1)
        Me.PanelD1.Controls.Add(Me.Label9)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Location = New System.Drawing.Point(12, 82)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(724, 183)
        Me.PanelD1.TabIndex = 24
        '
        'ChkChq2
        '
        Me.ChkChq2.AutoSize = True
        Me.ChkChq2.Location = New System.Drawing.Point(493, 143)
        Me.ChkChq2.Name = "ChkChq2"
        Me.ChkChq2.Size = New System.Drawing.Size(91, 17)
        Me.ChkChq2.TabIndex = 36
        Me.ChkChq2.Text = "����� Stock"
        Me.ChkChq2.UseVisualStyleBackColor = True
        '
        'ChkChq1
        '
        Me.ChkChq1.AutoSize = True
        Me.ChkChq1.Location = New System.Drawing.Point(493, 118)
        Me.ChkChq1.Name = "ChkChq1"
        Me.ChkChq1.Size = New System.Drawing.Size(91, 17)
        Me.ChkChq1.TabIndex = 35
        Me.ChkChq1.Text = "����� Stock"
        Me.ChkChq1.UseVisualStyleBackColor = True
        '
        'txtServiceName
        '
        Me.txtServiceName.Enabled = False
        Me.txtServiceName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtServiceName.Location = New System.Drawing.Point(188, 59)
        Me.txtServiceName.MaxLength = 15
        Me.txtServiceName.Name = "txtServiceName"
        Me.txtServiceName.Size = New System.Drawing.Size(298, 20)
        Me.txtServiceName.TabIndex = 34
        '
        'txtServiceCode
        '
        Me.txtServiceCode.Enabled = False
        Me.txtServiceCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtServiceCode.Location = New System.Drawing.Point(188, 34)
        Me.txtServiceCode.MaxLength = 15
        Me.txtServiceCode.Name = "txtServiceCode"
        Me.txtServiceCode.Size = New System.Drawing.Size(298, 20)
        Me.txtServiceCode.TabIndex = 33
        '
        'txtPayGroup
        '
        Me.txtPayGroup.Enabled = False
        Me.txtPayGroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPayGroup.Location = New System.Drawing.Point(188, 8)
        Me.txtPayGroup.MaxLength = 15
        Me.txtPayGroup.Name = "txtPayGroup"
        Me.txtPayGroup.Size = New System.Drawing.Size(298, 20)
        Me.txtPayGroup.TabIndex = 32
        '
        'txtAccountCode
        '
        Me.txtAccountCode.Enabled = False
        Me.txtAccountCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAccountCode.Location = New System.Drawing.Point(188, 88)
        Me.txtAccountCode.MaxLength = 15
        Me.txtAccountCode.Name = "txtAccountCode"
        Me.txtAccountCode.Size = New System.Drawing.Size(122, 20)
        Me.txtAccountCode.TabIndex = 31
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(316, 143)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "����ش"
        '
        'txt_e_chq2
        '
        Me.txt_e_chq2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_e_chq2.Location = New System.Drawing.Point(364, 143)
        Me.txt_e_chq2.MaxLength = 10
        Me.txt_e_chq2.Name = "txt_e_chq2"
        Me.txt_e_chq2.Size = New System.Drawing.Size(122, 20)
        Me.txt_e_chq2.TabIndex = 27
        '
        'txt_s_chq2
        '
        Me.txt_s_chq2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_s_chq2.Location = New System.Drawing.Point(188, 143)
        Me.txt_s_chq2.MaxLength = 10
        Me.txt_s_chq2.Name = "txt_s_chq2"
        Me.txt_s_chq2.Size = New System.Drawing.Size(122, 20)
        Me.txt_s_chq2.TabIndex = 26
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(316, 118)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "����ش"
        '
        'txt_e_chq1
        '
        Me.txt_e_chq1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_e_chq1.Location = New System.Drawing.Point(364, 115)
        Me.txt_e_chq1.MaxLength = 10
        Me.txt_e_chq1.Name = "txt_e_chq1"
        Me.txt_e_chq1.Size = New System.Drawing.Size(122, 20)
        Me.txt_e_chq1.TabIndex = 24
        '
        'txt_s_chq1
        '
        Me.txt_s_chq1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_s_chq1.Location = New System.Drawing.Point(188, 115)
        Me.txt_s_chq1.MaxLength = 10
        Me.txt_s_chq1.Name = "txt_s_chq1"
        Me.txt_s_chq1.Size = New System.Drawing.Size(122, 20)
        Me.txt_s_chq1.TabIndex = 23
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(9, 143)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Cheque No ��ǧ��� 2 :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(9, 118)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Cheque No ��ǧ��� 1 :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(9, 95)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Bank Service Account Code :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(9, 66)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Bank Service Name :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(9, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Bank Service Code :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(9, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "�������������è��� :"
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(3, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(718, 24)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Maintenance Cheque No"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label4)
        Me.PanelH1.Location = New System.Drawing.Point(12, 38)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(724, 38)
        Me.PanelH1.TabIndex = 23
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(268, 508)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClose.Size = New System.Drawing.Size(122, 28)
        Me.btnClose.TabIndex = 29
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.BackColor = System.Drawing.Color.Transparent
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(140, 508)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClear.Size = New System.Drawing.Size(122, 28)
        Me.btnClear.TabIndex = 28
        Me.btnClear.Text = "&Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnUpdate
        '
        Me.btnUpdate.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnUpdate.Image = Nothing
        Me.btnUpdate.ImageKey = ""
        Me.btnUpdate.ImageList = Nothing
        Me.btnUpdate.Location = New System.Drawing.Point(12, 508)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnUpdate.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnUpdate.Size = New System.Drawing.Size(122, 28)
        Me.btnUpdate.TabIndex = 27
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmMaintainCHQNO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(764, 570)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.btnUpdate)
        Me.Name = "FrmMaintainCHQNO"
        Me.Text = "FrmMaintainCHQNO"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnUpdate As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtAccountCode As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_e_chq2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_s_chq2 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_e_chq1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_s_chq1 As System.Windows.Forms.TextBox
    Friend WithEvents txtServiceCode As System.Windows.Forms.TextBox
    Friend WithEvents txtPayGroup As System.Windows.Forms.TextBox
    Friend WithEvents txtServiceName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents ChkChq2 As System.Windows.Forms.CheckBox
    Friend WithEvents ChkChq1 As System.Windows.Forms.CheckBox
End Class
