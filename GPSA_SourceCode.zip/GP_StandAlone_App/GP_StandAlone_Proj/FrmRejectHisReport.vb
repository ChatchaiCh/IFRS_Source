Imports UtilityClassLibrary
Public Class FrmRejectHisReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsReport
    Private Sub FrmRptRejectHistorical_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListRejectType()
        dtpFromDate.Value = Now.ToString("dd/MM/yyyy")
        dtpToDate.Value = Now.ToString("dd/MM/yyyy")
    End Sub
    Private Sub ListRejectType()
        cboRejectType.Items.Add("ALL")
        cboRejectType.Items.Add("Reject by Validate")
        cboRejectType.Items.Add("Reject by Hash Total")
        cboRejectType.Items.Add("Reject by Bank")
        cboRejectType.Items.Add("Reject by Account dept.")
        cboRejectType.SelectedIndex = 0
    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        'frm1.CrDoc.Load(sReportPath & "RptErrorByValidation.rpt")
        frm1.CrDoc.Load(sReportPath & "RptHistorical.rpt")

        Dim dt As DataTable = New DataTable()
        dt = cls.DtRptRejectHis(clsUtility.gConnGP, dtpFromDate.Value.ToString("yyyyMMdd"), dtpToDate.Value.ToString("yyyyMMdd"), cboRejectType.SelectedIndex)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)


            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramHeader As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            paramHeader.ParameterFieldName = "pTransDate"
            discreteHeader.Value = dtpFromDate.Value.ToString("dd/MM/yyyy") & " to " & dtpToDate.Value.ToString("dd/MM/yyyy")
            paramHeader.CurrentValues.Add(discreteHeader)
            paramFields.Add(paramHeader)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmRejectHisReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            'dt = clsBusiness.DtEmptyRpt(clsUtility.gConnGP)
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        PrintReport()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class