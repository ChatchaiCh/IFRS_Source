Imports CrystalDecisions.Shared
Imports System.Configuration
Imports CrystalDecisions.CrystalReports.Engine
Imports System.IO
Imports System.Web

Public Class FrmRptViewer
    Public sTitle As String
    Public CrDoc As New ReportDocument
    Public CrConnectionInfo As New ConnectionInfo
    Public CrTable As Table
    Public CrTables As Tables
    Public CrTablesLogInfo As TableLogOnInfo
    Public Sub SetReportConnection(ByVal sUserId As String, ByVal sPassword As String, ByVal sServer As String, ByVal sDB As String)
        With CrConnectionInfo
            .ServerName = sServer
            .DatabaseName = sDB
            .UserID = sUserId
            .Password = sPassword
            .Type = ConnectionInfoType.CRQE

        End With
        CrTables = CrDoc.Database.Tables
        For Each CrTable In CrTables
            CrTablesLogInfo = CrTable.LogOnInfo
            CrTablesLogInfo.ConnectionInfo = CrConnectionInfo
            CrTable.ApplyLogOnInfo(CrTablesLogInfo)
            CrDoc.SetDatabaseLogon(sUserId, sPassword)
        Next
        Try
            CrDoc.VerifyDatabase()
        Catch ex As Exception
            'do nothing
        End Try
        CrDoc.SetDatabaseLogon(sUserId, sPassword)
        CrViewer.ReportSource = CrDoc
    End Sub
    Public Sub FillDataSetToReport(ByVal ds As DataSet)

        Try

            With CrDoc

                .SetDataSource(ds)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub ExportPDF(ByVal dt As DataTable, ByVal title As String)

        Try

            With CrDoc

                .SetDataSource(dt)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

                Dim SaveFileDialog1 As New SaveFileDialog
                With SaveFileDialog1
                    .Title = "Save as report(.pdf) - " & title
                    .Filter = "PDF File (*.pdf)|*.pdf"
                    '.FilterIndex = 0
                End With

                If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    If SaveFileDialog1.FileNames.Length <> 0 Then
                        Dim fname As String
                        fname = SaveFileDialog1.FileName
                        CrDoc.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, fname)
                    End If
                End If
            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub ExportExcelDS(ByVal ds As DataSet, ByVal title As String)

        Try

            With CrDoc

                .SetDataSource(ds)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

                Dim SaveFileDialog1 As New SaveFileDialog
                With SaveFileDialog1
                    .Title = "Save as report(.xls) - " & title
                    .Filter = "Excel File (*.xls)|*.xls"
                    '.FilterIndex = 0
                End With

                If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    If SaveFileDialog1.FileNames.Length <> 0 Then
                        Dim fname As String
                        fname = SaveFileDialog1.FileName
                        CrDoc.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.ExcelRecord, fname)
                    End If
                End If
            End With

            'Dim CrExportOptions As ExportOptions
            'Dim CrDiskFileDestinationOptions As New  _
            'DiskFileDestinationOptions()
            'Dim CrFormatTypeOptions As New ExcelFormatOptions
            'CrDiskFileDestinationOptions.DiskFileName = _
            '                            "c:\crystalExport.xls"
            'CrExportOptions = CrDoc.ExportOptions
            'With CrExportOptions
            '    .ExportDestinationType = ExportDestinationType.DiskFile
            '    .ExportFormatType = ExportFormatType.Excel
            '    .DestinationOptions = CrDiskFileDestinationOptions
            '    '.FormatOptions = CrFormatTypeOptions
            'End With
            'CrDoc.Export()

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub ExportExcel(ByVal dt As DataTable, ByVal title As String)

        Try

            With CrDoc

                .SetDataSource(dt)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

                Dim SaveFileDialog1 As New SaveFileDialog
                With SaveFileDialog1
                    .Title = "Save as report(.xls) - " & title
                    .Filter = "Excel File (*.xls)|*.xls"
                    '.FilterIndex = 0
                End With

                If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    If SaveFileDialog1.FileNames.Length <> 0 Then
                        Dim fname As String
                        fname = SaveFileDialog1.FileName
                        CrDoc.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.Excel, fname)
                    End If
                End If
            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub FillDataTableToReport(ByVal dt As DataTable)

        Try

            With CrDoc

                .SetDataSource(dt)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub FillDataTableToReportForCertificate(ByVal dt As DataTable)

        Try

            With CrDoc

                .SetDataSource(dt)
                .Subreports(0).SetDataSource(dt)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()

            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub

    Public Function ExportToPDF(ByVal dt As DataTable) As System.IO.MemoryStream

        Try

            With CrDoc

                .SetDataSource(dt)
                CrViewer.ReportSource = CrDoc
                CrViewer.Refresh()
            End With
            '--Dim fname As String = "c:\RptPrintSCBLifeCHQ.pdf"
            Dim fname As String = "d:\RptPrintSCBLifeCHQ.pdf"
            CrDoc.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, fname)

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Function

    Private Sub FrmRptViewer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.WindowState = FormWindowState.Maximized

    End Sub

End Class