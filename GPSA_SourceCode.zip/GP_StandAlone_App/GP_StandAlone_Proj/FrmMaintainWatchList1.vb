Imports UtilityClassLibrary
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class FrmMaintainWatchList1
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim dataTableWL As DataTable
    Dim Extension As String
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub FrmMaintainWatchLists_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        BindWatchListType()
        BindWatchListSubType()

        GetData()
    End Sub
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            .Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.csv;*.xls;*.xlsx)|*.csv;*.xls;*.xlsx"
            .FilterIndex = 0
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURL.Text = OpenFileDialog1.FileName
                Extension = System.IO.Path.GetExtension(OpenFileDialog1.FileName)
                ''Dim dt As New DataTable
                'Try
                '    'dt = clsBusiness.ReadTextGL(txtTextURLGL.Text, ",")
                '    'GetDataToGrid(dt)

                'Catch ex As Exception
                '    'dt = Nothing
                '    'GetDataToGrid(dt)
                '    MsgBox("file format not valid")
                'End Try

            End If
        End If
    End Sub
    Private Sub GetData()
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.WaitCursor
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_WATCHLISTS_MA1 WHERE WLST_SUBTYPE_CODE ='" & cboSubType.SelectedValue.ToString & "' ")
        sb.Append("AND WLST_LOADDATE='" & Date.Now.ToString("yyyyMMdd") & "'")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
        Else
            dt = Nothing
            GetDataToGrid(dt)
            'MsgBox("��辺������")
        End If

    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "WLST_LOADDATE"
            .Name = "WLST_LOADDATE"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "WLST_SUBTYPE_CODE"
            .Name = "WLST_SUBTYPE_CODE"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c2)
        End With

        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "WLST_REFNO"
            .Name = "WLST_REFNO"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With

        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "WLST_DIST_TYPE"
            .Name = "WLST_DIST_TYPE"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c4)
        End With

        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "WLST_TTL"
            .Name = "WLST_TTL"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c5)
        End With

        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "WLST_FNAME"
            .Name = "WLST_FNAME"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c6)
        End With

        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "WLST_LNAME"
            .Name = "WLST_LNAME"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c7)
        End With

        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .DataPropertyName = "WLST_CHK_NAME"
            .Name = "WLST_CHK_NAME"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c8)
        End With

        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .DataPropertyName = "WLST_GENDER"
            .Name = "WLST_GENDER"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c9)
        End With

        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .DataPropertyName = "WLST_DOB"
            .Name = "WLST_DOB"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c10)
        End With

        Dim c11 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c11
            .DataPropertyName = "WLST_ID"
            .Name = "WLST_ID"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c11)
        End With

        Dim c12 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c12
            .DataPropertyName = "WLST_REJ_CODE"
            .Name = "WLST_REJ_CODE"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c12)
        End With

        Dim c13 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c13
            .DataPropertyName = "WLST_STATUS"
            .Name = "WLST_STATUS"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c13)
        End With

        Dim c14 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c14
            .DataPropertyName = "WLST_REMARK"
            .Name = "WLST_REMARK"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c14)
        End With

        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)

        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Function CheckFormatExcel(ByVal txtExcelURL As String) As Boolean
        Dim ret As Boolean = False
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            dataTableWL = New DataTable

            dataTableWL.Columns.Add("Code")
            dataTableWL.Columns.Add("Ref No")
            dataTableWL.Columns.Add("Disc Type")
            dataTableWL.Columns.Add("Announced Date")
            dataTableWL.Columns.Add("Title")
            dataTableWL.Columns.Add("Name")
            dataTableWL.Columns.Add("Surname")
            dataTableWL.Columns.Add("Gender")
            dataTableWL.Columns.Add("DOB")
            dataTableWL.Columns.Add("ID")
            dataTableWL.Columns.Add("Rej Code")
            dataTableWL.Columns.Add("Status")
            dataTableWL.Columns.Add("Remark")

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            'For rowIndex As Integer = 1 To oSheet.UsedRange.Rows.Count()
            Dim rowIndex As Integer = 1

            rowNew = dataTableWL.NewRow
            firstColumnIsNothing = False
            For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
                'If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                '    firstColumnIsNothing = True
                '    Exit For
                'ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                '    rowNew.Item(columnIndex - 1) = ""
                'Else
                '    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                'End If
                If myvalues(rowIndex, columnIndex) Is Nothing Then
                    Exit For
                Else
                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                End If
            Next
            If firstColumnIsNothing = False Then
                dataTableWL.Rows.Add(rowNew)
            End If

            dataTableWL.AcceptChanges()
            If dataTableWL.Rows.Count > 0 Then
                For Each row As DataRow In dataTableWL.Rows
                    For i As Integer = 0 To dataTableWL.Columns.Count - 1
                        Dim cname, rname As String
                        cname = dataTableWL.Columns(i).ColumnName()
                        rname = row.Item(i)
                        If cname.ToUpper = rname.ToUpper Then
                            ret = True
                        Else
                            ret = False
                            clsBusiness.gLastErrMessage = "Column name : " & rname & " is not valid"
                            Exit Function
                        End If
                    Next
                Next
            End If
            ret = True
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    'Private Function CheckMatchType(ByVal txtExcelURL As String, ByVal WLType As String) As Boolean
    '    Dim ret As Boolean = False
    '    Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
    '    Dim INSERT As String = ""
    '    System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
    '    oXL = New Excel.Application
    '    oBook = oXL.Workbooks.Open(txtExcelURL)

    '    Try

    '        dataTableWL = New DataTable

    '        dataTableWL.Columns.Add("Code")


    '        oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
    '        myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

    '        '�ŧ�ҡ Array 
    '        Dim rowNew As DataRow, firstColumnIsNothing As Boolean
    '        For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
    '            rowNew = dataTableWL.NewRow
    '            firstColumnIsNothing = False
    '            'For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
    '            Dim columnIndex As Integer = 1
    '            If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
    '                firstColumnIsNothing = True
    '                Exit For
    '            ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
    '                rowNew.Item(columnIndex - 1) = ""
    '            Else
    '                rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
    '            End If
    '            'Next
    '            If firstColumnIsNothing = False Then
    '                dataTableWL.Rows.Add(rowNew)
    '            End If
    '        Next
    '        dataTableWL.AcceptChanges()
    '        If dataTableWL.Rows.Count > 0 Then
    '            For Each row As DataRow In dataTableWL.Rows
    '                If row.Item(0).ToString = WLType Then
    '                    ret = True
    '                Else
    '                    ret = False
    '                    clsBusiness.gLastErrMessage = "Error at row : " & dataTableWL.Rows.IndexOf(row) + 1 & " " & row.Item(0).ToString & "<>" & cboSubType.SelectedValue.ToString
    '                    Exit Function
    '                End If
    '            Next
    '        End If

    '    Catch ex As Exception
    '        If ex.Message.IndexOf("BADINDEX") <> -1 Then
    '            Throw New Exception("Sheet name in excel file not correct")
    '        End If
    '    Finally
    '        oSheet = Nothing
    '        oBook.Close()
    '        oBook = Nothing
    '        oXL.Quit()
    '        oXL = Nothing
    '    End Try

    '    Return ret

    'End Function
    ''Function Import_To_DT(ByVal FilePath As String, ByVal Extension As String, ByVal isHDR As String) As DataTable
    ''isHDR = Has Header ?
    'Try

    '    Dim conStr As String = ""
    '    Select Case Extension
    '        Case ".xls"
    '            'Excel 97-03
    '            conStr = gConnectExcel103
    '            Exit Select
    '        Case ".xlsx"
    '            'Excel 07
    '            conStr = gConnectExcel107
    '            Exit Select
    '    End Select
    '    conStr = String.Format(conStr, FilePath, isHDR)

    '    Dim connExcel As New OleDbConnection(conStr)
    '    Dim cmdExcel As New OleDbCommand()
    '    Dim oda As New OleDbDataAdapter()
    '    Dim dt As New DataTable

    '    cmdExcel.Connection = connExcel

    '    'Get the name of First Sheet
    '    connExcel.Open()
    '    Dim dtExcelSchema As New DataTable
    '    dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

    '    Dim SheetName As String = dtExcelSchema.Rows(0)("TABLE_NAME").ToString()
    '    connExcel.Close()

    '    'Read Data from First Sheet
    '    connExcel.Open()
    '    cmdExcel.CommandText = "SELECT * From [" & SheetName & "]"
    '    oda.SelectCommand = cmdExcel
    '    oda.Fill(dt)

    '    connExcel.Close()

    '    Return dt
    'Catch ex As Exception
    '    Return Nothing
    '    clsBusiness.gLastErrMessage = ex.ToString
    'End Try

    'End Function
    Private Function readExcel(ByVal txtExcelURL As String) As DataTable
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application

        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            dataTableWL = New DataTable

            dataTableWL.Columns.Add("Code")
            dataTableWL.Columns.Add("Ref No")
            dataTableWL.Columns.Add("Disc Type")
            dataTableWL.Columns.Add("Announced Date")
            dataTableWL.Columns.Add("Title")
            dataTableWL.Columns.Add("Name")
            dataTableWL.Columns.Add("Surname")
            dataTableWL.Columns.Add("Gender")
            dataTableWL.Columns.Add("DOB")
            dataTableWL.Columns.Add("ID")
            dataTableWL.Columns.Add("Rej Code")
            dataTableWL.Columns.Add("Status")
            dataTableWL.Columns.Add("Remark")

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"


            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
                rowNew = dataTableWL.NewRow
                firstColumnIsNothing = False
                If myvalues(rowIndex, 1) Is Nothing Then
                    firstColumnIsNothing = True
                    Exit For
                End If
                For columnIndex As Integer = 1 To 13 'oSheet.UsedRange.Columns.Count()
                    'If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                    '    firstColumnIsNothing = True
                    '    Exit For
                    If myvalues(rowIndex, columnIndex) Is Nothing Then
                        rowNew.Item(columnIndex - 1) = ""
                    Else
                        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                    End If
                Next
                If firstColumnIsNothing = False Then
                    dataTableWL.Rows.Add(rowNew)
                End If
            Next
            dataTableWL.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableWL
    End Function

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtTextURL.Text <> "" Then

            '�� Header � excel ��� format �١��ͧ�������
            If CheckFormatExcel(txtTextURL.Text) = False Then
                MsgBox(clsBusiness.gLastErrMessage, MsgBoxStyle.Information)
                Exit Sub
            End If

            ''�� Header � excel ��� format �١��ͧ�������
            'If CheckMatchType(txtTextURL.Text, cboSubType.SelectedValue.ToString) = False Then
            '    MsgBox(clsBusiness.gLastErrMessage, MsgBoxStyle.Information)
            '    Exit Sub
            'End If

            Dim dt As New DataTable
            Dim i As Integer
            Dim oleTrans As OleDbTransaction
            Dim Rec As Integer

            'read row to datatable
            dt = readExcel(txtTextURL.Text)

            'import excel to datatable
            'dt = Import_To_DT(txtTextURL.Text, Extension, "Yes")

            If dt.Rows.Count > 0 Then

                oleTrans = clsUtility.gConnGP.BeginTransaction()
                For i = 0 To dt.Rows.Count - 1
                    Dim sb As New StringBuilder()
                    Dim fname, lname, dob, id As String

                    If Not IsDBNull(dt.Rows(i)(5).ToString) Then
                        fname = dt.Rows(i)(5).ToString.Trim
                    Else
                        fname = ""
                    End If

                    If Not IsDBNull(dt.Rows(i)(6).ToString) Then
                        lname = dt.Rows(i)(6).ToString.Trim
                    Else
                        lname = ""
                    End If

                    If Not IsDBNull(dt.Rows(i)(8).ToString) And dt.Rows(i)(8).trim <> "" Then
                        dob = CDate(dt.Rows(i)(8)).ToString("yyyyMMdd")
                    Else
                        dob = ""
                    End If

                    Try
                        id = CDbl(dt.Rows(i)(9)).ToString("#00")
                    Catch ex As Exception
                        id = dt.Rows(i)(9).ToString
                    End Try



                    sb.Append("INSERT INTO GPS_WATCHLISTS_MA1 VALUES ( ")
                    sb.Append("'" & Date.Now.ToString("yyyyMMdd") & "',")
                    sb.Append("'" & dt.Rows(i)(0) & "' ,")
                    sb.Append("'" & dt.Rows(i)(1) & "' ,")
                    sb.Append("'" & dt.Rows(i)(2) & "' ,")
                    sb.Append("'" & dt.Rows(i)(3) & "' ,")
                    sb.Append("'" & dt.Rows(i)(4) & "' ,")
                    sb.Append("'" & fname.Replace("'", "''") & "' ,")
                    sb.Append("'" & lname.Replace("'", "''") & "' ,")
                    sb.Append("'" & fname.Replace("'", "''") & lname.Replace("'", "''") & "' ,")
                    sb.Append("'" & dt.Rows(i)(7) & "' ,")
                    sb.Append("'" & dob & "' ,")
                    sb.Append("'" & id & "' ,")
                    sb.Append("'" & dt.Rows(i)(10) & "' ,")
                    sb.Append("'" & dt.Rows(i)(11) & "' ,")
                    sb.Append("'" & dt.Rows(i)(12) & "' ,")
                    sb.Append("'" & gUserLogin & "' ,")
                    sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                    sb.Append("'" & gUserLogin & "' ,")
                    sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

                    Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                    'If Rec < 0 Then
                    '    MsgBox("error")
                    'End If

                    If dt.Rows(i)(0).ToString.ToUpper <> cboSubType.SelectedValue.ToString.ToUpper Then
                        clsBusiness.gLastErrMessage = "error at row : " & i + 1 & " " & dt.Rows(i)(0).ToString & "<>" & cboSubType.SelectedValue.ToString
                        oleTrans.Rollback()
                        MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
                        Exit Sub
                    End If

                Next i

                If Rec = dt.Rows.Count Then
                    oleTrans.Commit()
                    GetData()
                    MsgBox(i & " Records inserted successfully")
                Else
                    oleTrans.Rollback()
                    MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
                End If

            End If
        Else
            MsgBox("Please select file")
        End If


    End Sub
    Private Sub BindWatchListType()

        Dim sb As New StringBuilder()
        sb.Append("SELECT DISTINCT(T.WLSTT_TYPE),T.WLSTT_TYPE||' : '||N.WLSTN_TYPE_NAME AS WLSTN_TYPE_NAME ")
        sb.Append("FROM GPS_TL_WATCHLISTS_TYPE T INNER JOIN GPS_TL_WATCHLISTS_TYPNME N ")
        sb.Append("ON T.WLSTT_TYPE=N.WLSTN_TYPE ")
        sb.Append("WHERE T.WLSTT_STATUS='ACTIVE' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count <> 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboType
                .DataSource = dt
                .DisplayMember = "WLSTN_TYPE_NAME"
                .ValueMember = "WLSTT_TYPE"
            End With
        End If
        'cboType.SelectedValue = 0
    End Sub
    Private Sub BindWatchListSubType()

        Dim sb As New StringBuilder()
        sb.Append("SELECT T.WLSTT_SUBTYPE,T.WLSTT_SUBTYPE||' : '||N.WLSTN_SUBTYPE_NAME AS WLSTN_SUBTYPE_NAME ")
        sb.Append("FROM GPS_TL_WATCHLISTS_TYPE T INNER JOIN GPS_TL_WATCHLISTS_SUBTYPNME N ")
        sb.Append("ON T.WLSTT_SUBTYPE=N.WLSTN_SUBTYPE ")
        sb.Append("WHERE T.WLSTT_STATUS='ACTIVE' ")
        sb.Append("AND T.WLSTT_TYPE='" & cboType.SelectedValue.ToString & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count <> 0 Then
            With cboSubType
                .DataSource = dt
                .DisplayMember = "WLSTN_SUBTYPE_NAME"
                .ValueMember = "WLSTT_SUBTYPE"
            End With
        End If
    End Sub
    Private Sub cboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboType.SelectedIndexChanged
        BindWatchListSubType()
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub cboSubType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSubType.SelectedIndexChanged
        GetData()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

    End Sub
End Class