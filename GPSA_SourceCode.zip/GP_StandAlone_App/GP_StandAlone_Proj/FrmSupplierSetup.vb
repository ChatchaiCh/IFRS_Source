﻿Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Imports System.Configuration
Imports System.IO

Public Class FrmSupplierSetup

    Enum ButtonStatus
        NewClick
        UpdateClick
        CancelClick
    End Enum

    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim clsSupplier As New clsGLM_SUPPLIER_SETUP
    Dim dt As New DataTable
    Dim dtType As New DataTable



    Private Sub SetupForm()
        With lblHead
            .Left = (Me.Width - .Width) / 2
        End With
        With dgvSupplier
            '.Width = Me.Width - .Width
        End With

        txtsupp_code.Enabled = False

        btnAdd.Enabled = True
        btnUpdate.Enabled = False
        'btnDelete.Enabled = False
    End Sub

    Private Sub BindDataToGrid(ByRef dt As DataTable)
        Try

            With dgvSupplier
                .DataSource = dt
                '--lblTotal.Text = "Total : " & .RowCount.ToString & " record(s)"
                With .Columns("supp_date")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .Frozen = True
                    .HeaderText = "supp_date"
                    .ReadOnly = True
                    .Visible = False
                End With
                With .Columns("supp_code")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .Frozen = True
                    .HeaderText = "supp_code"
                    .ReadOnly = True
                End With
                With .Columns("supp_s_account")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_s_account"
                    .ReadOnly = True
                End With
                With .Columns("supp_name_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_name_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_name_tax")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_name_tax"
                    .ReadOnly = True
                End With

                With .Columns("supp_taxid")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_taxid"
                    .ReadOnly = True
                End With

                With .Columns("supp_bnkcode_no_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_bnkcode_no_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_bnkaccno_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_bnkaccno_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_address_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_address_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_ampenm_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_ampenm_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_provnm_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_provnm_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_agzip_gp")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_agzip_gp"
                    .ReadOnly = True
                End With
                With .Columns("supp_address_tax")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_address_tax"
                    .ReadOnly = True
                End With
                With .Columns("supp_ampenm_tax")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_ampenm_tax"
                    .ReadOnly = True
                End With
                With .Columns("supp_provnm_tax")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_provnm_tax"
                    .ReadOnly = True
                End With
                With .Columns("supp_agzip_tax")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_agzip_tax"
                    .ReadOnly = True
                End With
                With .Columns("supp_country")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_country"
                    .ReadOnly = True
                End With
                With .Columns("supp_tel_no")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_tel_no"
                    .ReadOnly = True
                End With
                With .Columns("supp_fax_no")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_fax_no"
                    .ReadOnly = True
                End With
                With .Columns("supp_status")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "supp_status"
                    .ReadOnly = True
                End With

                With .Columns("CREATEDBY")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "CREATED BY"
                    .ReadOnly = True
                    '.Visible = False
                End With
                With .Columns("CREATEDDATE")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "CREATED DATE"
                    .ReadOnly = True
                    '.Visible = False
                End With
                With .Columns("UPDATEDBY")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "UPDATED BY"
                    .ReadOnly = True
                    '.Visible = False
                End With
                With .Columns("UPDATEDDATE")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader
                    .HeaderText = "UPDATED DATE"
                    .ReadOnly = True
                    '.Visible = False
                End With
            End With
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub dgvSupplier_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvSupplier.CellClick
        Try

            With e
                txtsupp_date.Text = dgvSupplier.Rows(e.RowIndex).Cells(0).Value.ToString '-- hide
                txtsupp_code.Text = dgvSupplier.Rows(e.RowIndex).Cells(1).Value.ToString
                txtsupp_s_account.Text = dgvSupplier.Rows(e.RowIndex).Cells(2).Value.ToString
                txtsupp_name_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(3).Value.ToString
                txtsupp_name_tax.Text = dgvSupplier.Rows(e.RowIndex).Cells(4).Value.ToString
                txtsupp_taxid.Text = dgvSupplier.Rows(e.RowIndex).Cells(5).Value.ToString
                txtsupp_bnkcode_no_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(6).Value.ToString
                txtsupp_bnkaccno_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(7).Value.ToString
                txtsupp_address_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(8).Value.ToString
                txtsupp_ampenm_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(9).Value.ToString '-- hide
                txtsupp_provnm_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(10).Value.ToString '-- hide
                txtsupp_agzip_gp.Text = dgvSupplier.Rows(e.RowIndex).Cells(11).Value.ToString '-- hide
                txtsupp_address_tax.Text = dgvSupplier.Rows(e.RowIndex).Cells(12).Value.ToString
                txtsupp_ampenm_tax.Text = dgvSupplier.Rows(e.RowIndex).Cells(13).Value.ToString '-- hide
                txtsupp_provnm_tax.Text = dgvSupplier.Rows(e.RowIndex).Cells(14).Value.ToString '-- hide
                txtsupp_agzip_tax.Text = dgvSupplier.Rows(e.RowIndex).Cells(15).Value.ToString '-- hide
                txtsupp_country.Text = dgvSupplier.Rows(e.RowIndex).Cells(16).Value.ToString '-- hide
                txtsupp_tel_no.Text = dgvSupplier.Rows(e.RowIndex).Cells(17).Value.ToString
                txtsupp_fax_no.Text = dgvSupplier.Rows(e.RowIndex).Cells(18).Value.ToString '-- hide
                txtsupp_status.Text = dgvSupplier.Rows(e.RowIndex).Cells(19).Value.ToString '-- hide

            End With

            Call SetupFormFor(ButtonStatus.UpdateClick)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SetupFormFor(sButtonStatus As ButtonStatus)
        Select Case sButtonStatus
            Case ButtonStatus.NewClick
                txtsupp_code.Enabled = True
                txtsupp_code.Text = ""
                txtsupp_s_account.Text = ""
                txtsupp_name_gp.Text = ""
                txtsupp_name_tax.Text = ""
                txtsupp_taxid.Text = ""
                txtsupp_bnkcode_no_gp.Text = ""
                txtsupp_bnkaccno_gp.Text = ""
                txtsupp_address_gp.Text = ""
                txtsupp_address_tax.Text = ""
                txtsupp_tel_no.Text = ""

                dgvSupplier.Enabled = False
                btnAdd.Enabled = False
                btnUpdate.Text = "&Save"
                btnUpdate.Enabled = True
                '--btnDelete.Enabled = False
                btnClose.Text = "&Cancel"
                btnClose.Enabled = True
                txtsupp_code.Focus()
            Case ButtonStatus.CancelClick
                txtsupp_code.Enabled = False
                txtsupp_code.Text = ""
                txtsupp_s_account.Text = ""
                txtsupp_name_gp.Text = ""
                txtsupp_name_tax.Text = ""
                txtsupp_taxid.Text = ""
                txtsupp_bnkcode_no_gp.Text = ""
                txtsupp_bnkaccno_gp.Text = ""
                txtsupp_address_gp.Text = ""
                txtsupp_address_tax.Text = ""
                txtsupp_tel_no.Text = ""


                dgvSupplier.Enabled = True
                btnAdd.Enabled = True
                btnUpdate.Text = "&Update"
                btnUpdate.Enabled = False
                '--btnDelete.Enabled = False
                btnClose.Text = "&Close"
                btnClose.Enabled = True
            Case ButtonStatus.UpdateClick
                If btnUpdate.Text = "&Update" Then
                    txtsupp_code.Enabled = False
                Else
                    txtsupp_code.Enabled = True
                End If
                dgvSupplier.Enabled = True
                btnAdd.Enabled = False
                btnUpdate.Text = "&Update"
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
                btnClose.Text = "&Cancel"
                btnClose.Enabled = True
        End Select
    End Sub


    Private Sub FrmSupplierSetup_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Windows.Forms.Cursor.Current = Cursors.WaitCursor

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GL Mapping" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        clsSupplier.ConnDB = clsUtility.gConnGP
        dt = clsSupplier.GetRecord("")

        Call SetupForm()
        Call BindDataToGrid(dt)

        Windows.Forms.Cursor.Current = Cursors.Arrow

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As System.EventArgs) Handles btnAdd.Click
        Call SetupFormFor(ButtonStatus.NewClick)
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        If btnClose.Text = "&Cancel" Then
            Call SetupFormFor(ButtonStatus.CancelClick)
        Else
            dt.Dispose()
            dt = Nothing
            clsUtility = Nothing
            clsBusiness = Nothing
            Me.Close()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnUpdate.Click
        Dim strMessage As String

        Windows.Forms.Cursor.Current = Cursors.WaitCursor

        With clsSupplier

            .supp_date = txtsupp_date.Text.ToString.Trim  '= dgvSupplier.Rows(e.RowIndex).Cells(0).Value.ToString '-- hide
            .supp_code = txtsupp_code.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(1).Value.ToString
            .supp_s_account = txtsupp_s_account.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(2).Value.ToString
            .supp_name_gp = txtsupp_name_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(3).Value.ToString
            .supp_name_tax = txtsupp_name_tax.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(4).Value.ToString
            .supp_taxid = txtsupp_taxid.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(5).Value.ToString
            .supp_bnkcode_no_gp = txtsupp_bnkcode_no_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(6).Value.ToString
            .supp_bnkaccno_gp = txtsupp_bnkaccno_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(7).Value.ToString
            .supp_address_gp = txtsupp_address_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(8).Value.ToString
            .supp_ampenm_gp = txtsupp_ampenm_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(9).Value.ToString '-- hide
            .supp_provnm_gp = txtsupp_provnm_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(10).Value.ToString '-- hide
            .supp_agzip_gp = txtsupp_agzip_gp.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(11).Value.ToString '-- hide
            .supp_address_tax = txtsupp_address_tax.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(12).Value.ToString
            .supp_ampenm_tax = txtsupp_ampenm_tax.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(13).Value.ToString '-- hide
            .supp_provnm_tax = txtsupp_provnm_tax.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(14).Value.ToString '-- hide
            .supp_agzip_tax = txtsupp_agzip_tax.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(15).Value.ToString '-- hide
            .supp_country = txtsupp_country.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(16).Value.ToString '-- hide
            .supp_tel_no = txtsupp_tel_no.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(17).Value.ToString
            .supp_fax_no = txtsupp_fax_no.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(18).Value.ToString '-- hide
            .supp_status = txtsupp_status.Text.ToString.Trim '= dgvSupplier.Rows(e.RowIndex).Cells(19).Value.ToString '-- hide

            If btnUpdate.Text = "&Update" Then
                .updatedby = gUserLogin
                If .Update() Then
                    strMessage = "Update : " & txtsupp_name_tax.Text.ToString.Trim & " completed."
                    MsgBox(strMessage, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Information")
                    Call SetupFormFor(ButtonStatus.CancelClick)

                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(0).Value = .supp_date
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(1).Value = .supp_code
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(2).Value = .supp_s_account
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(3).Value = .supp_name_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(4).Value = .supp_name_tax
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(5).Value = .supp_taxid
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(6).Value = .supp_bnkcode_no_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(7).Value = .supp_bnkaccno_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(8).Value = .supp_address_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(9).Value = .supp_ampenm_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(10).Value = .supp_provnm_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(11).Value = .supp_agzip_gp
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(12).Value = .supp_address_tax
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(13).Value = .supp_ampenm_tax
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(14).Value = .supp_provnm_tax
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(15).Value = .supp_agzip_tax
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(16).Value = .supp_country
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(17).Value = .supp_tel_no
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(18).Value = .supp_fax_no
                    dgvSupplier.Rows(dgvSupplier.CurrentRow.Index).Cells(19).Value = .supp_status

                    '--lblTotal.Text = "Total : " & dgvSupplier.RowCount & " record(s)"

                Else
                    strMessage = "Cannot update : " & txtsupp_name_tax.Text.ToString.Trim & ""
                    MsgBox(strMessage, MsgBoxStyle.Critical, "Error Message")
                End If
            Else '-- Add New Record
                .createdby = gUserLogin
                If .Insert() Then
                    strMessage = "Add : " & txtsupp_name_tax.Text.ToString.Trim & " completed."
                    MsgBox(strMessage, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Information")
                    Call SetupFormFor(ButtonStatus.CancelClick)
                    Call BindDataToGrid(.GetRecord(""))
                Else
                    strMessage = "Cannot add : " & txtsupp_name_tax.Text.ToString.Trim & ""
                    MsgBox(strMessage, MsgBoxStyle.Critical, "Error Message")
                End If
            End If

        End With

        Windows.Forms.Cursor.Current = Cursors.Arrow

    End Sub
End Class