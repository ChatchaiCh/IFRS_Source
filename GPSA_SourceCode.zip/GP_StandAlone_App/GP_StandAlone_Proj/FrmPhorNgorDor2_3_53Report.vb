Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmPhorNgorDor2_3_53Report
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsWHT
    Private Sub FrmPhorNgorDor2_3_53_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListPhorNgorDor()
        txtAccPeriod.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")

    End Sub
    Private Sub ListPhorNgorDor()
        cboPhorNgorDor.Items.Add("��� 2")
        cboPhorNgorDor.Items.Add("��� 3")
        cboPhorNgorDor.Items.Add("��� 53")
        cboPhorNgorDor.SelectedIndex = 0
    End Sub
    Private Sub PrintReport(ByVal reportname As String, ByVal period As String, ByVal phorngordor As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()

        frm1.CrDoc.Load(sReportPath & reportname)

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataPhorNgorDor_ByPeriod(clsUtility.gConnGP, period, phorngordor)
        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        frm1.FillDataTableToReport(dt)

        'Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        'Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        'Dim param1 As New CrystalDecisions.Shared.ParameterField()
        'Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        'Dim param2 As New CrystalDecisions.Shared.ParameterField()
        'Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        'Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        'param1.ParameterFieldName = "pJournalType"
        'discrete1.Value = cboJournalType.Text
        'param1.CurrentValues.Add(discrete1)
        'paramFields.Add(param1)

        'param2.ParameterFieldName = "pTransdate"
        'discrete2.Value = Now.ToString("dd/MM/yyyy")
        'param2.CurrentValues.Add(discrete2)
        'paramFields.Add(param2)

        'paramUser.ParameterFieldName = "pUser"
        'discreteUser.Value = gUserFullName
        'paramUser.CurrentValues.Add(discreteUser)
        'paramFields.Add(paramUser)

        'frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

        Dim frm As New FrmPhorNgorDor2_3_53Report
        frm.TopLevel = False
        frm.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
        frm.Show()

        Me.Close()

        'End If

    End Sub
  
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtAccPeriod.Text.Trim = "" Then
            MsgBox("Plese Enter Account Period")
            Exit Sub
        End If

        Dim reportname As String = ""
        Dim phorngordor As String = ""
        Dim period As String = ""
        If txtAccPeriod.Text <> "" Then
            period = txtAccPeriod.Text.Substring(4, 4) & txtAccPeriod.Text.Substring(1, 2)
            Select Case cboPhorNgorDor.Text.Trim
                Case "��� 2"
                    reportname = "RptPhorNgorDor2.rpt"
                    phorngordor = "02"
                Case "��� 3"
                    reportname = "RptPhorNgorDor3.rpt"
                    phorngordor = "03"
                Case "��� 53"
                    reportname = "RptPhorNgorDor53.rpt"
                    phorngordor = "53"
            End Select

            PrintReport(reportname, period, phorngordor)
        End If
    End Sub

    Private Sub RipsWareImageButtonBase1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RipsWareImageButtonBase1.Click
        Me.Close()
    End Sub
End Class