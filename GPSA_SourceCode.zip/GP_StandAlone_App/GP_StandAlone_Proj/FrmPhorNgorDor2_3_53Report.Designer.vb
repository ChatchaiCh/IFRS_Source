<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPhorNgorDor2_3_53Report
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboPhorNgorDor = New System.Windows.Forms.ComboBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtAccPeriod = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.btnPrint = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.RipsWareImageButtonBase1 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboPhorNgorDor
        '
        Me.cboPhorNgorDor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPhorNgorDor.FormattingEnabled = True
        Me.cboPhorNgorDor.Location = New System.Drawing.Point(119, 21)
        Me.cboPhorNgorDor.Name = "cboPhorNgorDor"
        Me.cboPhorNgorDor.Size = New System.Drawing.Size(162, 21)
        Me.cboPhorNgorDor.TabIndex = 17
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(47, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(223, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "�����㺵�� ���. 2,3,53 (��蹻���) "
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.Label11)
        Me.PanelD1.Controls.Add(Me.txtAccPeriod)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.cboPhorNgorDor)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(321, 118)
        Me.PanelD1.TabIndex = 47
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(212, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 104
        Me.Label11.Text = "(MMM/CCYY)"
        '
        'txtAccPeriod
        '
        Me.txtAccPeriod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAccPeriod.Location = New System.Drawing.Point(119, 65)
        Me.txtAccPeriod.MaxLength = 10
        Me.txtAccPeriod.Name = "txtAccPeriod"
        Me.txtAccPeriod.Size = New System.Drawing.Size(87, 20)
        Me.txtAccPeriod.TabIndex = 91
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "WHT Period :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "������ ��� :"
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(321, 38)
        Me.PanelH1.TabIndex = 46
        '
        'btnPrint
        '
        Me.btnPrint.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnPrint.Image = Nothing
        Me.btnPrint.ImageKey = ""
        Me.btnPrint.ImageList = Nothing
        Me.btnPrint.Location = New System.Drawing.Point(164, 180)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.Size = New System.Drawing.Size(79, 28)
        Me.btnPrint.TabIndex = 103
        Me.btnPrint.Text = "Print"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'RipsWareImageButtonBase1
        '
        Me.RipsWareImageButtonBase1.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.RipsWareImageButtonBase1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RipsWareImageButtonBase1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RipsWareImageButtonBase1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RipsWareImageButtonBase1.ForeColor = System.Drawing.Color.White
        Me.RipsWareImageButtonBase1.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.RipsWareImageButtonBase1.Image = Nothing
        Me.RipsWareImageButtonBase1.ImageKey = ""
        Me.RipsWareImageButtonBase1.ImageList = Nothing
        Me.RipsWareImageButtonBase1.Location = New System.Drawing.Point(249, 180)
        Me.RipsWareImageButtonBase1.Name = "RipsWareImageButtonBase1"
        Me.RipsWareImageButtonBase1.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.Size = New System.Drawing.Size(79, 28)
        Me.RipsWareImageButtonBase1.TabIndex = 104
        Me.RipsWareImageButtonBase1.Text = "Exit"
        Me.RipsWareImageButtonBase1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RipsWareImageButtonBase1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmPhorNgorDor2_3_53Report
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 214)
        Me.Controls.Add(Me.RipsWareImageButtonBase1)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.PanelH1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmPhorNgorDor2_3_53Report"
        Me.Text = "�����㺵�� ���. 2,3,53 (��蹻���)"
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cboPhorNgorDor As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtAccPeriod As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents RipsWareImageButtonBase1 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
