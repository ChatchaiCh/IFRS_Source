﻿Imports UtilityClassLibrary
Imports System.Text

Public Class FrmFindFileHashTotalIL

    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim clsHashLO As New ClsHashTotalErrorLOCancel
    Private table As DataTable
    Private Sub FrmFindFileHashTotalIL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim dt As DataTable

        If dgvFindFile.RowCount <= 0 Then
            getDataFile()
        End If

        Dim sysdate As String = clsHashLO.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")

        dt = clsHashLO.getFileName(clsUtility.gConnGP, sysdate)
        'dt = clsHashLO.getFileName(clsUtility.gConnGP, "201509210") 'test
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            For Each dr As DataRow In dt.Rows
                Dim row As String() = New String() {dr("pays_file_name"), ""}
                dgvFindFile.Rows.Add(row)
            Next
        Else
            MsgBox("ไม่พบไฟล์ข้อมูล Media Clearing และ Direct Credit ของวันนี้...")
            Me.Close()
        End If

    End Sub

    Private Sub getDataFile() 'ByVal dt As DataTable)
        With dgvFindFile

            '.ReadOnly = True
            '.DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "fileName"
            .Name = "File Name"
            .ReadOnly = True
            .Width = 250
            dgvFindFile.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "lineNo"
            .Name = "Line No"
            .ReadOnly = False
            .Width = 150
            dgvFindFile.Columns.Add(c2)
        End With
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        retFileNameIL = CType("", String)
        retPayNoIL = CType("", String)
        Me.Close()
    End Sub

    Private Sub dgvFindFile_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvFindFile.CellEndEdit
        Try
            dgvFindFile.AllowUserToAddRows = False

            Dim iRow = e.RowIndex
            Dim line As String = dgvFindFile.Rows(iRow).Cells(1).Value
            Dim checkLine As Boolean = False

            If Not String.IsNullOrEmpty(dgvFindFile.Rows(iRow).Cells(1).Value) Then

                ' Split string based on spaces.
                Dim words As String() = line.Split(New Char() {","c})
                ' Use For Each loop over words and display them.
                Dim word As String
                For Each word In words
                    If Information.IsNumeric(word) Then
                        checkLine = False
                    Else
                        checkLine = True
                    End If
                Next
                If checkLine Then
                    dgvFindFile.Rows(iRow).Cells(1).Value = String.Empty
                    MsgBox("กรุณากรอกตัวเลขและเครื่องหมาย(,)เท่านั้น.")
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click
        If MessageBox.Show("Do you want to Confirm ? (Y/N)", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            table = New DataTable()

            table.Columns.Add("fileName", GetType(String))
            table.Columns.Add("lineNo", GetType(String))

            For index As Integer = 0 To dgvFindFile.RowCount - 1

                Dim fileName As String = dgvFindFile.Rows(index).Cells(0).Value.ToString()
                Dim lineNo As String = dgvFindFile.Rows(index).Cells(1).Value.ToString()
                If lineNo <> "" Then
                    'frmHashIL.TXT.Rows.Add(fileName, lineNo)
                    table.Rows.Add(fileName, lineNo)
                End If
            Next

            Dim sysdate As String = clsHashLO.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")
            Dim pathIL As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")
            'Dim pathIL As String = "D:\Work_SCB\GPS\Work_201509\testIL\" 'test
            Dim sbFile, sbAcc As New StringBuilder
            Dim dt As DataTable
            Dim iAcc, iFile As Integer
            iAcc = 0
            iFile = 0

            Try
                'Loop for read file
                For Each row As DataRow In table.Rows

                    Dim filename, line, pathfilename, bankAcc As String
                    filename = row.Item(0)
                    line = row.Item(1)
                    pathfilename = pathIL & filename
                    ' Split string based on spaces.
                    If Not line.IndexOf(",") = -1 Then
                        Dim words As String() = line.Split(New Char() {","c})
                        ' Use For Each loop over words and display them.
                        Dim word As String
                        For Each word In words
                            'Read file string aray 
                            Dim lines As String() = IO.File.ReadAllLines(pathfilename, Encoding.Default)
                            Dim rs As String = lines(word - 1)
                            bankAcc = rs.Substring(259, 15)
                            If iAcc > 0 Then
                                sbAcc.Append(",")
                            End If
                            sbAcc.Append("trim('")
                            sbAcc.Append(Trim(bankAcc))
                            sbAcc.Append("')")
                            iAcc = iAcc + 1
                        Next
                    Else
                        Dim lines As String() = IO.File.ReadAllLines(pathfilename, Encoding.Default)
                        Dim rs As String = lines(line - 1)
                        bankAcc = rs.Substring(259, 15)
                        If iAcc > 0 Then
                            sbAcc.Append(",")
                        End If
                        sbAcc.Append("trim('")
                        sbAcc.Append(Trim(bankAcc))
                        sbAcc.Append("')")
                        iAcc = iAcc + 1
                    End If

                    If iFile > 0 Then
                        sbFile.Append("|")
                    End If
                    sbFile.Append("^")
                    sbFile.Append(filename)
                    sbFile.Append("$")

                    'file name Ex. ^IL20150731001DC01.TXT$|^IL20150731001MC01.TXT$
                    'accountNo Ex. trim('000002287')
                    'loop file name and line no
                    iFile = iFile + 1
                Next


                retFileNameIL = CType(sbFile.ToString, String)
                retPayNoIL = CType(sbAcc.ToString, String)

            Catch ex As Exception
                MsgBox("Search File Error.")
                Exit Sub
            End Try

        End If

        Me.Close()
    End Sub

End Class