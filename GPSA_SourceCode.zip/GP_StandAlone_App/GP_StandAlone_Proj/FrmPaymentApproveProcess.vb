Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports System.Net.Mail
Imports UtilityClassLibrary

Public Class FrmPaymentApproveProcess
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls_cr As New clsCreation
    Private _IsSelectAllChecked As Boolean
    Dim timework As Integer = 1
    Dim ret_msg As String
    Dim paytype As String
    Dim countrow As Integer = 0
    Dim second As Integer
    Dim en As New System.Globalization.CultureInfo("en-GB")
    Dim strSQL As String
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
#Region "BackgroundWorker_Wait"


    Private Sub BackgroundWorker2_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker2.DoWork

        Dim X As Integer
        Dim i As Integer

        For i = 0 To 100 Step +1

            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker2.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                'BackgroundWorker1.ReportProgress(i / countrow)

                ' X = i / countrow
                If ChkSTART() Then
                    StopWorker_wait()
                    Exit Sub
                End If
                BackgroundWorker2.ReportProgress(i)
                System.Threading.Thread.Sleep(600)
            End If
        Next

    End Sub
    Private Sub BackgroundWorker2_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker2.ProgressChanged
        ''���� 1 progress      
        'Me.ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker_wait()
        If BackgroundWorker2.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker2.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker2_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker2.RunWorkerCompleted
        'If ret_msg <> "" Then
        '    MsgBox(ret_msg, MsgBoxStyle.Critical, "Validate")
        'End If


        'AutoBindData()


    End Sub
#End Region
#Region "BackgroundWorker"


    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

        Approve()

        Dim X As Integer
        Dim i As Integer

        For i = 0 To timework Step +1
            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                'BackgroundWorker1.ReportProgress(i / countrow)

                X = i / countrow
                BackgroundWorker1.ReportProgress(X)
                System.Threading.Thread.Sleep(countrow)
            End If
        Next

    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ''���� 1 progress      
        'Me.ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        If ret_msg <> "" Then
            MsgBox(ret_msg, MsgBoxStyle.Critical, "Validate")
        End If


        AutoBindData()
        'MsgBox(ret_msg)

    End Sub
#End Region

    Private Sub ControlStyle()
        '--PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        '--PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        '--Panel1.BackColor = Color.FromArgb(255, 245, 240)

        PanelD1.BackColor = Color.FromArgb(255, 235, 200)
        Panel1.BackColor = Color.FromArgb(255, 235, 200)

        '--btnApprove.BackColor = Color.FromArgb(255, 235, 220)
        btnApprove.Height = 25
        btnApprove.Enabled = False
    End Sub
    Private Sub FrmPaymentApprove_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
      
        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        ListSection()
        ListType()
        ListDataSource()
        ListPaymentMethod()
        ListJournalType()
        btnApprove.Enabled = False
    End Sub
    Private Sub ListSection()
        Dim sb As New StringBuilder()

        sb.Append("SELECT A.DTS_MERGE_DEP, B.DEP_DEPNAME  ")
        sb.Append("FROM GPS_TL_DATASOURCE A LEFT JOIN GPS_TL_DEPARTMENT B ON A.DTS_MERGE_DEP=B.DEP_DEPCODE  ")
        sb.Append("WHERE A.DTS_CORE_SYSTEM='ACC' GROUP BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ORDER BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboSection
                .DataSource = dt
                .DisplayMember = "DEP_DEPNAME"
                .ValueMember = "DTS_MERGE_DEP"
            End With
        End If
        cboSection.SelectedIndex = 0
    End Sub
    Private Sub ListType()
        CboType.Items.Add("case ��觴�ǹ")
        CboType.Items.Add("normal approve")
        CboType.SelectedIndex = 1
    End Sub
    Private Sub ListDataSource()
        cboDataSource.Items.Add("All")
        cboDataSource.Items.Add("TLM")
        cboDataSource.Items.Add("Non TLM")
        cboDataSource.SelectedIndex = 0
    End Sub
    Private Sub ListPaymentMethod()
        cboPaymentMethod.Items.Add("C")
        cboPaymentMethod.Items.Add("D")
        cboPaymentMethod.Items.Add("M")
        cboPaymentMethod.Items.Add("WHT(non pay)")
        cboPaymentMethod.SelectedIndex = 0
    End Sub
    Private Sub ListJournalType()
        Dim sb As New StringBuilder()


        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_C) AS ID,DTS_JN_TYPE_C AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_C <> ' ' ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_J_NOPAY) AS ID,DTS_JN_TYPE_J_NOPAY AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_J_NOPAY <> ' ' ")
      
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboJournalType
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
    End Sub
    Private Sub AddSelectAllCheckBox(ByVal theDataGridView As DataGridView)
        Dim cbx As New CheckBox
        cbx.Name = "SelectAll"
        'The box size
        cbx.Size = New Size(14, 14)

        Dim rect As Rectangle
        rect = theDataGridView.GetCellDisplayRectangle(0, -1, True)
        'Put CheckBox in the middle-center of the column header.
        cbx.Location = New System.Drawing.Point(rect.Location.X + ((rect.Width - cbx.Width) / 2), rect.Location.Y + ((rect.Height - cbx.Height) / 2))
        cbx.BackColor = Color.White
        theDataGridView.Controls.Add(cbx)

        'Handle header CheckBox check/uncheck function
        AddHandler cbx.Click, AddressOf HeaderCheckBox_Click
        'When any CheckBox value in the DataGridViewRows changed,
        'check/uncheck the header CheckBox accordingly.
        AddHandler theDataGridView.CellValueChanged, AddressOf DataGridView_CellChecked
        'This event handler is necessary to commit new CheckBox cell value right after
        'user clicks the CheckBox.
        'Without it, CellValueChanged event occurs until the CheckBox cell lose focus
        'which means the header CheckBox won't display corresponding checked state instantly when user
        'clicks any one of the CheckBoxes.
        AddHandler theDataGridView.CurrentCellDirtyStateChanged, AddressOf DataGridView_CurrentCellDirtyStateChanged
    End Sub
    Private Sub HeaderCheckBox_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me._IsSelectAllChecked = True

        Dim cbx As CheckBox
        cbx = DirectCast(sender, CheckBox)
        Dim theDataGridView As DataGridView = cbx.Parent

        For Each row As DataGridViewRow In theDataGridView.Rows
            row.Cells(0).Value = cbx.Checked
        Next

        theDataGridView.EndEdit()

        Me._IsSelectAllChecked = False
    End Sub
    Private Sub DataGridView_CellChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If Not Me._IsSelectAllChecked Then
            If dataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = False Then
                'When any single CheckBox is unchecked, uncheck the header CheckBox.
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = False
            Else
                'When any single CheckBox is checked, loop through all CheckBoxes to determine
                'if the header CheckBox needs to be unchecked.
                Dim isAllChecked As Boolean = True
                For Each row As DataGridViewRow In dataGridView.Rows
                    If row.Cells(0).Value = False Then
                        isAllChecked = False
                        Exit For
                    End If
                Next
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = isAllChecked
            End If
        End If
    End Sub
    Private Sub DataGridView_CurrentCellDirtyStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If TypeOf dataGridView.CurrentCell Is DataGridViewCheckBoxCell Then
            'When the value changed cell is DataGridViewCheckBoxCell, commit the change
            'to invoke the CellValueChanged event.
            dataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray



        End With


        'Dim colCheckbox As New DataGridViewCheckBoxColumn()

        'colCheckbox.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader

        'colCheckbox.ThreeState = False
        'colCheckbox.TrueValue = 1
        'colCheckbox.FalseValue = 0
        'colCheckbox.IndeterminateValue = System.DBNull.Value
        'colCheckbox.DataPropertyName = "Checkbox"
        'colCheckbox.HeaderText = "SelectAll"
        'colCheckbox.Name = "Checkbox"
        'colCheckbox.ReadOnly = False
        'DataGridView1.Columns.Add(colCheckbox)


        Dim chk As New DataGridViewCheckBoxColumn
        With chk
            DataGridView1.Columns.Add(chk)

        End With

        '-- COLUMN 1 : TREF_JN_HOLD
        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .ReadOnly = True
            .DataPropertyName = "TREF_JN_HOLD"
            .Name = "Journal Hold"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c1)

        End With

        '-- COLUMN 2 : GL_AMT
        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .ReadOnly = True
            .DataPropertyName = "GL_AMT"
            .Name = "Total GL Amt (Cr)"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c2)
        End With

        '-- COLUMN 3 : GP_AMT
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .ReadOnly = True
            .DataPropertyName = "GP_AMT"
            .Name = "Total GP Amt"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With

        '-- COLUMN 4 : TAX_AMT
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .ReadOnly = True
            .DataPropertyName = "TAX_AMT"
            .Name = "Total WHT Amt"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c4)
        End With

        '-- COLUMN 5 : TREF_CREATEDATE
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_CREATEDATE"
            .Name = "CreateDate"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c5)
        End With

        '-- COLUMN 6 : TREF_CORE_SYSTEM
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_CORE_SYSTEM"
            .Name = "CoreSystem"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c6)
        End With

        '-- COLUMN 7 : TREF_TRANSREF
        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_TRANSREF"
            .Name = "TransRef"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c7)
        End With

        '-- COLUMN 8 : TREF_PAYCRETYP_ID
        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_PAYCRETYP_ID"
            .Name = "TREF_PAYCRETYP_ID"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c8)
        End With

        '-- COLUMN 9 : TREF_PAYMTH
        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_PAYMTH"
            .Name = "TREF_PAYMTH"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c9)
        End With

        '-- COLUMN 10 : TREF_SUB_PAYMTH
        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_SUB_PAYMTH"
            .Name = "TREF_SUB_PAYMTH"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c10)
        End With

        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)
        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(2).DefaultCellStyle.Format = "###,###.00" 'AMOUNT GL
        DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(3).DefaultCellStyle.Format = "###,###.00" 'AMOUNT GP
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(4).DefaultCellStyle.Format = "###,###.00" 'AMOUNT TAX
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        'If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

        '    retAccCode = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
        '    retAccName = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
        '    Me.Close()

        'End If
    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    'Private Sub BindJournalHold()
    '    Dim dt As DataTable
    '    dt = fnGetJournalHold()

    '    If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
    '        txtJnFrom.Text = dt.Rows(0)("TREF_JN_HOLD").ToString
    '        txtJnTo.Text = dt.Rows(dt.Rows.Count - 1)("TREF_JN_HOLD").ToString
    '    Else
    '        txtJnFrom.Text = ""
    '        txtJnTo.Text = ""
    '    End If

    'End Sub
    Function fnSringMain() As StringBuilder
        Dim sb As New StringBuilder()

        sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH ")
        sb.Append("FROM GPS_TRANSREF_REL ")
        sb.Append("WHERE 1=1 ")

        If cboSection.SelectedValue.ToString = "DIS" Then
            sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
        Else
            sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
        End If

        If CboType.SelectedIndex = 0 Then
            sb.Append("AND TREF_PAYCRETYP_ID = '003' ")
        Else
            sb.Append("AND TREF_PAYCRETYP_ID <> '003' ")
        End If

        Select Case cboDataSource.SelectedIndex
            Case "1"
                sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
            Case "2"
                sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
        End Select

        If txtEntryDate.Text.Trim <> "" Then
            Dim entrydate As String
            entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
            sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
            'sb.Append("AND TREF_CREATEDATE='" & dtpEntryDate.Value.ToString("yyyyMMdd") & "'")
        End If


        If cboPaymentMethod.Text.ToUpper = "WHT(NON PAY)" Then
            sb.Append("AND TREF_PAYMTH IS NULL ")
        Else
            sb.Append("AND TREF_PAYMTH = '" & cboPaymentMethod.Text.Trim & "'   ")
        End If


        If txtDueDate.Text.Trim <> "" Then
            Dim duedate As String
            duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
            sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
            'sb.Append("AND TREF_PAIDDATE='" & dtpDueDate.Value.ToString("yyyyMMdd") & "'")
        End If

        sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

        sb.Append("AND TREF_APPROVEDBY IS NULL ")
        sb.Append("ORDER BY TREF_JN_HOLD) A ")

        Return sb

    End Function

    Function GetData() As DataTable
        Try

            Dim str As String

            str = fnSringMain.ToString
            strSQL = str

            Dim sb As New StringBuilder()

            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' OR SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53') ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH)L ")
            sb.Append("LEFT JOIN ")

            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function GetData_Validate(ByVal str As String, ByVal transref As String) As DataTable
        Try

            Dim sb As New StringBuilder()

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT ")
            '-- AP-2016-008
            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT, NVL(GPCR_BNKCODE,' ') GPCR_BNKCODE ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' OR SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53') ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH)L ")
            sb.Append("LEFT JOIN ")

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            '-- AP-2016-008
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE, SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            '-- AP-2016-008 
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append(" WHERE L.TREF_TRANSREF = '" & transref & "'")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function GetDataNonPay() As DataTable
        Try

            Dim str As String

            str = fnSringMain.ToString
            strSQL = str

            Dim sb As New StringBuilder()

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,GL_AMT,GP_AMT,TAX_AMT ")
            '-- AP-2016-008
            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,GL_AMT,GP_AMT,TAX_AMT, GPCR_BNKCODE ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            'sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            'sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            'sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' AND SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID)L ")
            sb.Append("LEFT JOIN ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            '-- AP-2016-008
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE, SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            '-- AP-2016-008
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Function fnGetJournalHold() As DataTable
        Try


            Dim sb As New StringBuilder()
            sb.Append("SELECT TREF_JN_HOLD,TREF_TRANSREF ")
            sb.Append("FROM GPS_TRANSREF_REL ")
            sb.Append("WHERE 1=1 ")

            If cboSection.SelectedValue.ToString = "DIS" Then
                sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
            Else
                sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
            End If

            ''sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")

            'If cboDataSource.Text.ToUpper <> "ALL" Then
            '    sb.Append("AND TREF_DTSOURCE = '" & cboDataSource.Text & "' ")
            'End If
            Select Case cboDataSource.SelectedIndex
                Case "1"
                    sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
                Case "2"
                    sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
            End Select

            If txtEntryDate.Text.Trim <> "" Then
                Dim entrydate As String
                entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
                sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
                'sb.Append("AND TREF_CREATEDATE='" & dtpEntryDate.Value.ToString("yyyyMMdd") & "'")
            End If


            If cboPaymentMethod.Text.ToUpper = "WHT(NON PAY)" Then
                sb.Append("AND TREF_PAYMTH IS NULL ")
            Else
                sb.Append("AND TREF_PAYMTH = '" & cboPaymentMethod.Text.Trim & "'   ")
            End If

            If txtDueDate.Text.Trim <> "" Then
                Dim duedate As String
                duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
                sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
                'sb.Append("AND TREF_PAIDDATE='" & dtpDueDate.Value.ToString("yyyyMMdd") & "'")
            End If

            sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

            sb.Append("AND TREF_APPROVEDBY IS NULL ")
            sb.Append("ORDER BY TREF_JN_HOLD ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Function fnApproveTransref(ByVal oleTrans As OleDbTransaction, ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean

        Dim sb As New StringBuilder
        Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_TRANSREF_REL SET ")
        sb.Append("TREF_APPROVEDBY = '" & gUserLogin & "',")
        sb.Append("TREF_APPROVEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("UPDATEDBY = '" & gUserLogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE TREF_CREATEDATE = '" & createdate & "' ")
        sb.Append("AND TREF_CORE_SYSTEM ='" & core_system & "' ")
        sb.Append("AND TREF_TRANSREF ='" & transref & "'")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If Rec >= 0 Then
            'oleTrans.Commit()
            ret = True
        Else
            'oleTrans.Rollback()
            ret = False
        End If
        Return ret
    End Function
    Function fnApproveGL(ByVal oleTrans As OleDbTransaction, ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean

        Dim sb As New StringBuilder
        Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_GL_CREATION SET ")
        sb.Append("GLCR_APPROVEDBY = '" & gUserLogin & "',")
        sb.Append("GLCR_APPROVEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("UPDATEDBY = '" & gUserLogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE GLCR_CREATEDATE = '" & createdate & "' ")
        sb.Append("AND GLCR_CORE_SYSTEM ='" & core_system & "' ")
        sb.Append("AND GLCR_TRANSREF ='" & transref & "'")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If Rec >= 0 Then
            'oleTrans.Commit()
            ret = True
        Else
            'oleTrans.Rollback()
            ret = False
        End If
        Return ret
    End Function
    Function fnApproveGP(ByVal oleTrans As OleDbTransaction, ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean

        Dim sb As New StringBuilder
        Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_PAYMENT_CREATION SET ")
        sb.Append("GPCR_APPROVEDBY = '" & gUserLogin & "',")
        sb.Append("GPCR_APPROVEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("UPDATEDBY = '" & gUserLogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE GPCR_CREATEDATE = '" & createdate & "' ")
        sb.Append("AND GPCR_CORE_SYSTEM ='" & core_system & "' ")
        sb.Append("AND GPCR_TRANSREF ='" & transref & "'")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If Rec >= 0 Then
            'oleTrans.Commit()
            ret = True
        Else
            'oleTrans.Rollback()
            ret = False
        End If

        Return ret

    End Function
    Function fnApproveTAX(ByVal oleTrans As OleDbTransaction, ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean

        Dim sb As New StringBuilder
        Dim Rec As Integer
        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_WHT_CREATION SET ")
        sb.Append("TAXCR_APPROVEDBY = '" & gUserLogin & "',")
        sb.Append("TAXCR_APPROVEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("UPDATEDBY = '" & gUserLogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE TAXCR_CREATEDATE = '" & createdate & "' ")
        sb.Append("AND TAXCR_CORE_SYSTEM ='" & core_system & "' ")
        sb.Append("AND TAXCR_TRANSREF ='" & transref & "'")

        Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If Rec >= 0 Then
            'oleTrans.Commit()
            ret = True
        Else
            'oleTrans.Rollback()
            ret = False
        End If
        Return ret
    End Function
    Private Sub AutoBindData()
        'BindJournalHold()

        Dim dt As DataTable

        If cboPaymentMethod.Text.ToUpper = "WHT(NON PAY)" Then
            dt = GetDataNonPay()
        Else
            dt = GetData()
        End If



        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
            AddSelectAllCheckBox(DataGridView1)
            btnApprove.Enabled = True

            txtJnFrom.Text = dt.Rows(0)("TREF_JN_HOLD").ToString
            txtJnTo.Text = dt.Rows(dt.Rows.Count - 1)("TREF_JN_HOLD").ToString

        Else
            dt = Nothing
            GetDataToGrid(dt)
            btnApprove.Enabled = False

            txtJnFrom.Text = ""
            txtJnTo.Text = ""
        End If
    End Sub
    Private Sub btnApprove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnApprove.Click
        ret_msg = ""
        countrow = 0
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = True Then
                countrow += 1
            End If
        Next

        If countrow < 1 Then
            Exit Sub
        End If

        If MessageBox.Show("Do you want to approve data ? (Y/N)", "Confirm Approve", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            paytype = cboPaymentMethod.Text.ToUpper
            Try
                Dim chk As Boolean
                chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_NO")

                If chk = False Then
                   
                    If retChkStart = False Then
                        'MsgBox("�������ö�ӡ��  Approve ���س����ѡ���� ���Ƿӡ�� Approve �����ա����", MsgBoxStyle.Information)
                        'Exit Sub

                        Dim frmwait As New frmProgresswait(Me.BackgroundWorker2)
                        frmwait.ShowDialog()

                    End If

                End If

                chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_NO")
                If chk = False Then
                    MsgBox("�������ö�ӡ��  Approve �����ͧ�ҡ�Թ���ҷ���ͤ��" & vbCrLf & _
                           "��سҷӡ�� Approve �����ա����", MsgBoxStyle.Information)
                    Exit Sub
                Else
                    timework = 100 * countrow
                    Dim progress As New frmProgress(Me.BackgroundWorker1)
                    progress.ShowDialog()
                End If

            Catch ex As Exception
                StopWorker()
                MsgBox("Process Error!")
            End Try

            strSQL = ""

            UPDATE_INTERFACE_CONTROL_STATUS("STOP")


        End If

    End Sub

    '�������͹�㹡�ô֧������ due_date
    Function SetDefaultDueDate_ORG(ByVal payment_subpayment As String, ByVal core_system As String) As String
        Dim ret As String
        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim dateString As String
        Dim format As String = "yyyyMMdd"
        Dim StartDate As Date
        Dim Duedate As Date
        Dim countworkdate As Integer
        Dim i_date As Integer


        dateString = DateTime.Now.ToString("yyyyMMdd", en)

        StartDate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-GB"))
        Duedate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-GB"))


        Select Case payment_subpayment
            Case "C:C" '"SCB M Cheque"
                i_date = 2
            Case "D:D" '"SCB M Draft"
                i_date = 2
            Case "M:M" '"Media Clearing"
                i_date = 3
            Case "C:Q" '"Company Cheque"
                i_date = 1
            Case "C:H" '"SCB Cashier Cheque"
                i_date = 2
            Case "M:A" '"ATS �ͧ SCB"
                i_date = 3
            Case "C:G" '"SCB Gift Cheque (�礢ͧ��ѭ)"
                i_date = 2
            Case "C:T" '"Money Order (��ҳѵ�)"
                i_date = 2
            Case "C:B" '"Bank Draft"
                i_date = 2
            Case "M:C" '"Credit Card (�ѵ��ôԵ)"
                'i_date = 7

                'Check ���͹���������
                If "TLM".Equals(core_system) Then
                    i_date = 6 'Due date for "TLM"
                Else
                    i_date = 7 'Due date for "ACC"
                End If
            Case "M:B" '"�͹�Թ��ҧ�����"
                i_date = 2
        End Select


        Do While countworkdate <> i_date
            Duedate = DateAdd(DateInterval.Day, 1, Duedate)

            chkHoliday = LookUpHoliday(Duedate.ToString("yyyyMMdd", en), Duedate.ToString("yyyyMMdd", en))
            If chkHoliday > 0 Then
                i_date = i_date + 1
            End If

            chkWorkDay = GetWorkDay(Duedate)
            If chkWorkDay Then
                countworkdate += 1
            End If

        Loop


        ret = Duedate.ToString("yyyyMMdd", en) 'Duedate.ToString("yyyyMMdd")
        Return ret
    End Function

    Function SetDefaultDueDate(ByVal payment_subpayment As String _
                             , ByVal core_system As String _
                             , Optional ByVal bankcode As String = "" _
                              ) As String
        Dim ret As String
        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim dateString As String
        Dim format As String = "yyyyMMdd"
        Dim StartDate As Date
        Dim Duedate As Date
        Dim countworkdate As Integer
        Dim i_date As Integer


        dateString = DateTime.Now.ToString("yyyyMMdd", en)

        StartDate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-GB"))
        Duedate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-GB"))


        Select Case payment_subpayment
            Case "C:C" '"SCB M Cheque"
                '-- AP-2016-008 'i_date = 2
                i_date = 1
            Case "D:D" '"SCB M Draft"
                i_date = 1
            Case "M:M" '"Media Clearing"
                'i_date = 2
                '-- cannot approve SCB same day --- If core_system.Trim <> "TLM" And core_system.Trim <> "ACC" And bankcode = "SCB" Then
                If core_system.Trim <> "TLM" And bankcode = "SCB" Then
                    i_date = 0
                Else
                    i_date = 2
                End If
            Case "C:Q" '"Company Cheque"
                i_date = 1
            Case "C:H" '"SCB Cashier Cheque"
                i_date = 2
            Case "M:A" '"ATS �ͧ SCB"
                i_date = 3
            Case "C:G" '"SCB Gift Cheque (�礢ͧ��ѭ)"
                i_date = 2
            Case "C:T" '"Money Order (��ҳѵ�)"
                i_date = 2
            Case "C:B" '"Bank Draft"
                i_date = 2
            Case "M:C" '"Credit Card (�ѵ��ôԵ)"
                'i_date = 7

                'Check ���͹���������
                If "TLM".Equals(core_system) Then
                    i_date = 6 'Due date for "TLM"
                Else
                    i_date = 7 'Due date for "ACC"
                End If
            Case "M:B" '"�͹�Թ��ҧ�����"
                i_date = 2
        End Select


        Do While countworkdate <> i_date
            Duedate = DateAdd(DateInterval.Day, 1, Duedate)

            chkHoliday = LookUpHoliday(Duedate.ToString("yyyyMMdd", en), Duedate.ToString("yyyyMMdd", en))
            If chkHoliday > 0 Then
                i_date = i_date + 1
            End If

            chkWorkDay = GetWorkDay(Duedate)
            If chkWorkDay Then
                countworkdate += 1
            End If

        Loop


        ret = Duedate.ToString("yyyyMMdd", en) 'Duedate.ToString("yyyyMMdd")
        Return ret
    End Function
    Function LookUpHoliday(ByVal d_start As String, ByVal d_end As String) As Integer

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE BETWEEN '" & d_start & "'  AND '" & d_end & "'  AND HLDS_COMPANY_CODE='SCB' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return 0
        End If

    End Function
    Public Function CountWorkDay(ByVal StartDate As Date, ByVal EndDate As Date)
        Dim count = 0
        Dim totalDays = (EndDate - StartDate).Days
        Dim i As Integer
        For i = 0 To totalDays
            Dim weekday As DayOfWeek = StartDate.AddDays(i).DayOfWeek
            If weekday <> DayOfWeek.Saturday AndAlso weekday <> DayOfWeek.Sunday Then
                count += 1
            End If
        Next
        Return count
    End Function
    Public Function GetWorkDay(ByVal CurrentDate As DateTime) As Boolean

        Select Case CurrentDate.DayOfWeek
            Case DayOfWeek.Saturday
                Return False
            Case DayOfWeek.Sunday
                Return False
            Case Else
                'handles sunday through thursday
                Return True
        End Select

    End Function
    Function ValidateData_ORG(ByVal create_date As String _
                            , ByVal core_system As String _
                            , ByVal transref As String _
                            , ByVal jnhold As String _
                            , ByVal keyid As String _
                            , ByVal paymth As String _
                             ) As Boolean

        Dim ret As Boolean = True

        Dim PAMT_NOMAT As Boolean
        Dim PDTE_NOMAT As Boolean
        Dim DUPT_ERR As Boolean
        Dim TAMT_NOMAT As Boolean
        Dim PDTE_ERR As Boolean

        If keyid <> "003" And paytype <> "WHT(NON PAY)" Then

            Dim d As String
            d = SetDefaultDueDate(paymth, core_system) '�� core_system �������㹡�ô֧ due_date

            Dim pdate As String
            pdate = cls_cr.GetPaidDate_GLGP(clsUtility.gConnGP, create_date, core_system, transref)

            If pdate >= d Then
                ret = True
            Else
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " ��س���� Duedate ���١��ͧ" & vbCrLf
                ret = False
            End If


        Else

            Dim busdate As String
            busdate = DateTime.Now.ToString("yyyyMMdd", en)

            PDTE_ERR = cls_cr.fnPaidDateErr(clsUtility.gConnGP, create_date, core_system, transref, keyid, busdate)
            If PDTE_ERR = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " ��س���� Duedate ���١��ͧ" & vbCrLf
                ret = False

            End If

        End If



        ''--------------fValidateNetAmountNotMatch--------------
        If paytype <> "WHT(NON PAY)" Then
            PAMT_NOMAT = cls_cr.fnNetAmountNotMatch(clsUtility.gConnGP, create_date, core_system, transref)
            If PAMT_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PAMT_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If

        End If

        ''--------------fValidatePaidDateNotMatch--------------

        If paytype = "WHT(NON PAY)" Then
            PDTE_NOMAT = cls_cr.fnPaidDateNotMatch_NONPAY(clsUtility.gConnGP, create_date, core_system, transref)
            If PDTE_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If
        Else
            PDTE_NOMAT = cls_cr.fnPaidDateNotMatch(clsUtility.gConnGP, create_date, core_system, transref)
            If PDTE_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If
        End If

        ''--------------fValidateTransrefError--------------
        DUPT_ERR = CHK_DUPT_ERR(clsUtility.gConnGP, create_date, core_system, transref)
        If DUPT_ERR = False Then
            Dim msg As String
            msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "DUPT_ERR")
            ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
            'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
            ret = False
            'Exit Function
        End If
        ''--------------fValidateWHTAmountNotMatch--------------
        TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, create_date, core_system, transref)
        If TAMT_NOMAT = False Then
            Dim msg As String
            msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
            ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
            'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
            ret = False
            'Exit Function
        End If

        Return ret

    End Function

    Function ValidateData(ByVal create_date As String _
                        , ByVal core_system As String _
                        , ByVal transref As String _
                        , ByVal jnhold As String _
                        , ByVal keyid As String _
                        , ByVal paymth As String _
                        ) As Boolean

        Dim ret As Boolean = True

        Dim PAMT_NOMAT As Boolean
        Dim PDTE_NOMAT As Boolean
        Dim DUPT_ERR As Boolean
        Dim TAMT_NOMAT As Boolean
        Dim PDTE_ERR As Boolean

        If keyid <> "003" And paytype <> "WHT(NON PAY)" Then

            Dim d As String
            '-- AP-2016-008 'd = SetDefaultDueDate(paymth, core_system, bankcode) '�� core_system �������㹡�ô֧ due_date

            Dim pdate As String
            '-- AP-2016-008 'pdate = cls_cr.GetPaidDate_GLGP(clsUtility.gConnGP, create_date, core_system, transref)

            '-- AP-2016-008 'If pdate >= d Then
            '-- AP-2016-008 '   ret = True
            '-- AP-2016-008 'Else
            '-- AP-2016-008 '   Dim msg As String
            '-- AP-2016-008 '   msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
            '-- AP-2016-008 '   ret_msg = ret_msg & " Journal Hold " & jnhold & " ��س���� Duedate ���١��ͧ" & vbCrLf
            '-- AP-2016-008 '   ret = False
            '-- AP-2016-008 'End If

            '----------------------------------------------------------
            '-- AP-2016-008 add loop check due date by gpcr_bankcode --
            '----------------------------------------------------------
            Dim dt As New DataTable
            Dim msg As String
            Dim bankcode As String
            Dim blnCheckDueDate As Boolean = True
            dt = GetData_Validate(strSQL, transref)
            blnCheckDueDate = False
            For Each dr As DataRow In dt.Rows

                bankcode = dr("GPCR_BNKCODE").ToString.Trim

                d = SetDefaultDueDate(paymth, core_system, bankcode) '�� core_system �������㹡�ô֧ due_date
                pdate = cls_cr.GetPaidDate_GLGP(clsUtility.gConnGP, create_date, core_system, transref)

                If pdate >= d Then
                    blnCheckDueDate = True
                Else
                    blnCheckDueDate = False
                    Exit For
                End If

            Next
            If blnCheckDueDate Then
                ret = True
            Else
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " ��س���� Duedate ���١��ͧ" & vbCrLf
                ret = False
            End If
            '----------------------------------------------------------
            '-- AP-2016-008 add loop check due date by gpcr_bankcode --
            '----------------------------------------------------------

        Else

            Dim busdate As String
            busdate = DateTime.Now.ToString("yyyyMMdd", en)

            PDTE_ERR = cls_cr.fnPaidDateErr(clsUtility.gConnGP, create_date, core_system, transref, keyid, busdate)
            If PDTE_ERR = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " ��س���� Duedate ���١��ͧ" & vbCrLf
                ret = False

            End If

        End If


        ''--------------fValidateNetAmountNotMatch--------------
        If paytype <> "WHT(NON PAY)" Then
            PAMT_NOMAT = cls_cr.fnNetAmountNotMatch(clsUtility.gConnGP, create_date, core_system, transref)
            If PAMT_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PAMT_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If

        End If

        ''--------------fValidatePaidDateNotMatch--------------

        If paytype = "WHT(NON PAY)" Then
            PDTE_NOMAT = cls_cr.fnPaidDateNotMatch_NONPAY(clsUtility.gConnGP, create_date, core_system, transref)
            If PDTE_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If
        Else
            PDTE_NOMAT = cls_cr.fnPaidDateNotMatch(clsUtility.gConnGP, create_date, core_system, transref)
            If PDTE_NOMAT = False Then
                Dim msg As String
                msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
                ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
                'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If
        End If

        ''--------------fValidateTransrefError--------------
        DUPT_ERR = CHK_DUPT_ERR(clsUtility.gConnGP, create_date, core_system, transref)
        If DUPT_ERR = False Then
            Dim msg As String
            msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "DUPT_ERR")
            ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
            'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
            ret = False
            'Exit Function
        End If
        ''--------------fValidateWHTAmountNotMatch--------------
        TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, create_date, core_system, transref)
        If TAMT_NOMAT = False Then
            Dim msg As String
            msg = cls_cr.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
            ret_msg = ret_msg & " Journal Hold " & jnhold & " " & msg & vbCrLf
            'MsgBox(msg & " Journal Hold " & jnhold, MsgBoxStyle.Critical, "Validate")
            ret = False
            'Exit Function
        End If

        Return ret

    End Function
    Function CHK_DUPT_ERR(ByVal oConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True

        dt = cls_cr.fValidateDuplicateTransRef(clsUtility.gConnGP, create_date, core_system, transref)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
            Exit Function
        End If

        Return ret

    End Function
    Function CHK_WHT_ERR(ByVal oConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True

        dt = cls_cr.fnValidateWHTAmountNotMatch(clsUtility.gConnGP, create_date, core_system, transref)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
            Exit Function
        End If

        Return ret

    End Function
    Private Sub UPDATE_INTERFACE_CONTROL_STATUS(ByVal status As String)

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_NO", status, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If
    End Sub
    Private Sub UPDATE_INTERFACE_CONTROL_NO()

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_NO(clsUtility.gConnGP, "JN_NO", oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Function GetJournalNo() As String
        'Cursor = Cursors.WaitCursor
        retJnHold = ""
        Dim chk As Boolean
        Dim no As String
        chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_NO")

        If chk Then


            UPDATE_INTERFACE_CONTROL_STATUS("START")

            no = clsBusiness.GET_NO_INTERFACE_CONTROL(clsUtility.gConnGP, "JN_NO")

            'UPDATE_INTERFACE_CONTROL_NO()

            'UPDATE_INTERFACE_CONTROL_STATUS("STOP")

            'Cursor = Cursors.Default
        Else
            no = ""
        End If

        Return no

    End Function
    Function ChkSTART() As Boolean
        Dim chk As Boolean = False

        chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_NO")
        Return chk
    End Function
    Private Sub Approve()
        Dim chk As Integer = 0
        Dim countrow As Integer = 0
        Dim counttrans As Integer = 0
        Dim chk_tref, chk_gl, chk_gp, chk_tax As Boolean
        Dim chk_totemp, chk_complete, chk_rej, chk_aml As Boolean
        Dim blnInsertDataToTemp As Boolean
        Dim jnno As String = ""

        'Dim ret As String = "FALSE"
        'Do While ret.ToUpper = "FALSE"
        '    jnno = GetJournalNo()
        'Loop

        jnno = GetJournalNo()

        If jnno = "" Then
            StopWorker()
            MsgBox("�������ö�ӡ��  Approve ���س����ѡ���� ���Ƿӡ�� Approve �����ա����")
            Exit Sub
        End If



        If jnno <> "" Then
            For index As Integer = 0 To DataGridView1.RowCount - 1
                If DataGridView1.Rows(index).Cells(0).Value = True Then
                    'countrow += 1
                    chk += 1
                    Dim chk_validate As Boolean
                    Dim paymth As String
                    paymth = DataGridView1.Rows(index).Cells(9).Value & ":" & DataGridView1.Rows(index).Cells(10).Value

                    chk_validate = ValidateData(DataGridView1.Rows(index).Cells(5).Value, DataGridView1.Rows(index).Cells(6).Value, DataGridView1.Rows(index).Cells(7).Value, DataGridView1.Rows(index).Cells(1).Value, DataGridView1.Rows(index).Cells(8).Value, paymth)

                    If chk_validate Then
                        countrow += 1

                        Dim jnho As String = DataGridView1.Rows(index).Cells(1).Value
                        If CallApprove(jnno, jnho, gUserLogin) Then
                            counttrans += 1
                        End If

                        Dim oleTrans As OleDbTransaction
                        oleTrans = clsUtility.gConnGP.BeginTransaction()

                        'Dim jnho As String = DataGridView1.Rows(index).Cells(1).Value

                        chk_tref = fnApproveTransref(oleTrans, DataGridView1.Rows(index).Cells(5).Value, DataGridView1.Rows(index).Cells(6).Value, DataGridView1.Rows(index).Cells(7).Value)
                        chk_gl = fnApproveGL(oleTrans, DataGridView1.Rows(index).Cells(5).Value, DataGridView1.Rows(index).Cells(6).Value, DataGridView1.Rows(index).Cells(7).Value)
                        chk_gp = fnApproveGP(oleTrans, DataGridView1.Rows(index).Cells(5).Value, DataGridView1.Rows(index).Cells(6).Value, DataGridView1.Rows(index).Cells(7).Value)
                        chk_tax = fnApproveTAX(oleTrans, DataGridView1.Rows(index).Cells(5).Value, DataGridView1.Rows(index).Cells(6).Value, DataGridView1.Rows(index).Cells(7).Value)

                        If chk_tref And chk_gl And chk_gp And chk_tax Then
                            oleTrans.Commit()
                        Else
                            oleTrans.Rollback()
                        End If

                        '' ''-- AP-2016-008
                        ' ''If chk_tref And chk_gl And chk_gp And chk_tax Then
                        ' ''    '-- 1. get batchno
                        ' ''    chk_complete = True
                        ' ''    chk_rej = True
                        ' ''    chk_aml = True
                        ' ''    Dim strStatus As Integer = "1.0"
                        ' ''    Dim systemdate As String = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
                        ' ''    strStatus = "1.1"
                        ' ''    Dim batchno As String = clsBusiness.fnCallBatchNo(clsUtility.gConnGP, systemdate)
                        ' ''    strStatus = "1.2"
                        ' ''    '-- 2. insert data to temp table 
                        ' ''    Dim oleTrans2 As OleDbTransaction
                        ' ''    oleTrans2 = clsUtility.gConnGP_2.BeginTransaction()
                        ' ''    '-- 2.1 clear temp
                        ' ''    If DeleteOldDataTemp(systemdate, oleTrans2, batchno, DataGridView1.Rows(index).Cells(7).Value) Then
                        ' ''        oleTrans2.Commit()
                        ' ''    End If

                        ' ''    oleTrans2 = clsUtility.gConnGP_2.BeginTransaction()

                        ' ''    blnInsertDataToTemp = InsertDataToTemp(systemdate, batchno, oleTrans2)
                        ' ''    If blnInsertDataToTemp Then
                        ' ''        oleTrans2.Commit()
                        ' ''    Else
                        ' ''        oleTrans2.Rollback()
                        ' ''    End If
                        ' ''    '-- 3. call sp validate
                        ' ''    If blnInsertDataToTemp Then
                        ' ''        Dim blnValidateData As Boolean = ValidateDataTemp(systemdate)
                        ' ''        If blnValidateData Then

                        ' ''            '-- 4. insert to complete table

                        ' ''            '��Ǩ�ͺ��Ҿ������� COMPLETE
                        ' ''            Dim dataCM As Integer
                        ' ''            dataCM = chkDataComplete(systemdate)
                        ' ''            '��Ǩ�ͺ��Ҿ������� INCOMPLETE
                        ' ''            Dim dataRJ As Integer
                        ' ''            dataRJ = chkDataReject(systemdate)

                        ' ''            '--Dim oleTrans As OleDbTransaction
                        ' ''            oleTrans = clsUtility.gConnGP.BeginTransaction()
                        ' ''            'Insert to AML
                        ' ''            chk_aml = InsertTableAML(oleTrans)
                        ' ''            '��Ǩ�ͺ��Ҿ������� COMPLETE ��� insert data ŧ table Complete
                        ' ''            If dataCM > 0 Then
                        ' ''                chk_complete = InsertTableComplete(oleTrans)
                        ' ''            End If

                        ' ''            '-- 5. insert to reject table

                        ' ''            '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� insert data ŧ table Reject
                        ' ''            If dataRJ > 0 Then
                        ' ''                chk_rej = InsertTableReject(oleTrans)
                        ' ''            End If

                        ' ''            If chk_complete And chk_rej And chk_aml Then
                        ' ''                oleTrans.Commit()

                        ' ''                Dim chk_updateflag As Boolean
                        ' ''                chk_updateflag = UpdateFlag(systemdate, oleTrans)

                        ' ''                Dim chk_updateflag_GL As Boolean
                        ' ''                chk_updateflag_GL = UpdateFlag_GL(systemdate, oleTrans)

                        ' ''                Dim chk_updateflag_TAX As Boolean
                        ' ''                chk_updateflag_TAX = UpdateFlag_TAX(systemdate, oleTrans)

                        ' ''                If chk_updateflag And chk_updateflag_GL And chk_updateflag_TAX Then
                        ' ''                    '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� update reject type � table creation
                        ' ''                    If dataRJ > 0 Then
                        ' ''                        UpdatePaymentReject_CR(oleTrans)
                        ' ''                        clsBusiness.gLastErrMessage = "UpdatePaymentReject_CR"
                        ' ''                        InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                        ' ''                        UpdateWHTReject_CR(oleTrans)
                        ' ''                        clsBusiness.gLastErrMessage = "UpdateWHTReject_CR"
                        ' ''                        InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                        ' ''                        '--UpdatePaymentReject_LD()
                        ' ''                        '--UpdateWHTReject_LD()
                        ' ''                    End If

                        ' ''                    clsBusiness.gLastErrMessage = "update flag GP, GL, WHT"
                        ' ''                    InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                        ' ''                Else
                        ' ''                    clsBusiness.gLastErrMessage = "update flag GP, GL, WHT some one no data"
                        ' ''                    InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                        ' ''                End If

                        ' ''                clsBusiness.gLastErrMessage = "Insert Payment, Reject, AML"
                        ' ''                InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                        ' ''            Else
                        ' ''                oleTrans.Rollback()
                        ' ''                clsBusiness.gLastErrMessage = "Update flag rollback!"
                        ' ''                InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
                        ' ''            End If

                        ' ''            '-- 6. call sp CallGL_REJ_PARTIAL &
                        ' ''            '-- 7. call sp CaLLGL_REJ_ALL
                        ' ''            '�������� Incomplete ��� generate report and send email
                        ' ''            If dataRJ > 0 Then

                        ' ''                CallGL_REJ_PARTIAL(systemdate, batchno, gUserLogin)
                        ' ''                CallGL_REJ_ALL(systemdate, batchno, gUserLogin)

                        ' ''                '-- 8. GenValidateReport
                        ' ''                GenValidationReport(systemdate)

                        ' ''                '-- 9. SendEmailSCBLife
                        ' ''                '------------SendEmail("ERR_AUTOBATCH")-----------
                        ' ''                SendEmailSCBLife("ERR_BY_VALIDATE")

                        ' ''                clsBusiness.gLastErrMessage = "Call GL"
                        ' ''                InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                        ' ''            End If
                        ' ''        Else
                        ' ''            clsBusiness.gLastErrMessage = "Validate not comlplete 17 function"
                        ' ''            InsertTransLog("APPROVE, VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
                        ' ''        End If
                        ' ''    End If
                        ' ''End If
                        '' ''-- AP-2016-008


                        'Else
                        'UPDATE_INTERFACE_CONTROL_STATUS("STOP")
                        ''Stop Progress bar
                        'StopWorker()
                        'Exit Sub
                    End If
                    '1:
                End If

            Next


            If countrow <> counttrans Then
                UPDATE_INTERFACE_CONTROL_STATUS("STOP")
                ''Stop Progress bar
                StopWorker()
                MsgBox("Call GL Error")
                Exit Sub
            Else
                StopWorker()
                UPDATE_INTERFACE_CONTROL_NO()
                UPDATE_INTERFACE_CONTROL_STATUS("STOP")
            End If
        End If
    End Sub
    Function CallApprove(ByVal jn_no As String, ByVal jn_ho As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_journal_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_journal_no").Value = jn_no ' "1400001"
        dbComm.Parameters.Add("p_hold_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_hold_no").Value = jn_ho ' "1400001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_GET_JournalNO_Approve"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Private Sub cboSection_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSection.SelectedIndexChanged
        AutoBindData()
    End Sub
    Private Sub cboDataSource_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDataSource.SelectedIndexChanged
        AutoBindData()
    End Sub
    Private Sub dtpEntryDate_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs)
        AutoBindData()
    End Sub
    Private Sub cboPaymentMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPaymentMethod.SelectedIndexChanged
        AutoBindData()
    End Sub
    Private Sub dtpDueDate_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs)
        AutoBindData()
    End Sub
    Private Sub cboJournalType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboJournalType.SelectedIndexChanged
        AutoBindData()
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ClearData()
    End Sub
    Private Sub ClearData()

        txtJnFrom.Text = ""
        txtJnTo.Text = ""

        Dim dt As DataTable
        dt = Nothing
        GetDataToGrid(dt)
        btnApprove.Enabled = False
    End Sub
    Private Sub txtEntryDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtEntryDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtEntryDate.Text.Trim = "" Then
                AutoBindData()
            Else
                Dim dateString As String = txtEntryDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtEntryDate.Text = ""
                    txtEntryDate.Focus()
                    ClearData()
                End If
            End If

        End If
    End Sub
    Private Sub txtDueDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDueDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDueDate.Text.Trim = "" Then
                AutoBindData()
            Else
                Dim dateString As String = txtDueDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtDueDate.Text = ""
                    txtDueDate.Focus()
                    ClearData()
                End If
            End If

        End If
    End Sub

    'Private Function jnno() As String
    '    Throw New NotImplementedException
    'End Function

    Private Sub CboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboType.SelectedIndexChanged
        AutoBindData()
    End Sub

    Function InsertToTempPayment_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_PAYMENT ( ")
        sb.Append("GP_BATCHDATE,")
        sb.Append("GP_BATCH_NO,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_DESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_FLAG_VALIDATE,")
        sb.Append("GP_REJECT_TYPE,")
        sb.Append("GP_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE, ")
        sb.Append("GP_FLAG_CC,")
        sb.Append("GP_CC_APPROVEDBY) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("GPCR_CREATEDATE, ")
        sb.Append("GPCR_CORE_SYSTEM, ")
        sb.Append("GPCR_TRANSREF, ")
        sb.Append("GPCR_GPTREF_SEQNO, ")
        sb.Append("GPCR_POLNO, ")
        sb.Append("GPCR_BILLNO, ")
        sb.Append("GPCR_PAIDDATE, ")
        sb.Append("GPCR_AMOUNT, ")
        sb.Append("GPCR_DESC, ")
        sb.Append("GPCR_PAYMTH, ")
        sb.Append("GPCR_PAYEE_NAME, ")
        sb.Append("GPCR_BNKCODE, ")
        sb.Append("GPCR_BNKCODE_NO, ")
        sb.Append("GPCR_BNKBRN, ")
        sb.Append("GPCR_BNKNAME, ")
        sb.Append("GPCR_PAYEE_BNKACCNO, ")
        sb.Append("GPCR_PAYEE_BNKACCNME, ")
        sb.Append("GPCR_COMMENT, ")
        sb.Append("GPCR_ADDRESS1, ")
        sb.Append("GPCR_DISTRICT, ")
        sb.Append("GPCR_PROVINCE, ")
        sb.Append("GPCR_INSURENAME, ")
        sb.Append("GPCR_DATASOURCE_NME, ")
        sb.Append("GPCR_Reserve6, ")
        sb.Append("GPCR_MERCHN_NO, ")
        sb.Append("GPCR_CDCARD_DATE, ")
        sb.Append("GPCR_Reserve9, ")
        sb.Append("GPCR_Reserve10, ")
        sb.Append("GPCR_SYS_REF, ")
        sb.Append("GPCR_SYS_GR, ")
        sb.Append("GPCR_SUB_PAYMTH, ")
        sb.Append("GPCR_FLAG_FLWBILL, ")
        sb.Append("GPCR_OSEA_LIST, ")
        sb.Append("GPCR_PHONE, ")
        sb.Append("GPCR_FAX, ")
        sb.Append("GPCR_SWIFT_CODE, ")
        sb.Append("GPCR_BNKBRN_NAME, ")
        sb.Append("GPCR_BNKADDR, ")
        sb.Append("GPCR_COUNTRY, ")
        sb.Append("GPCR_CURRENCY, ")
        sb.Append("GPCR_EXCHN_RATE, ")
        sb.Append("GPCR_BNKCHARGES, ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'), ")
        sb.Append("GPCR_fLAG_CC, ")
        sb.Append("GPCR_CC_APPROVEDBY ")
        sb.Append("FROM GPS_PAYMENT_CREATION WHERE GPCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("AND GPCR_FLAG_BATCH='N' AND GPCR_APPROVEDDATE = '" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertToTempWHT_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXCR_CREATEDATE, ")
        sb.Append("TAXCR_CORE_SYSTEM, ")
        sb.Append("TAXCR_TRANSREF, ")
        sb.Append("TAXCR_GPTREF_SEQNO, ")
        sb.Append("TAXCR_LINENO, ")
        sb.Append("TAXCR_TAXID, ")
        sb.Append("TAXCR_IDCARD, ")
        sb.Append("TAXCR_AP_TTL, ")
        sb.Append("TAXCR_AP_FNAME, ")
        sb.Append("TAXCR_AP_LNAME, ")
        sb.Append("TAXCR_ADDRESS, ")
        sb.Append("TAXCR_AMPENM, ")
        sb.Append("TAXCR_PROVNM, ")
        sb.Append("TAXCR_AGZIP, ")
        sb.Append("TAXCR_TAXTYPE, ")
        sb.Append("TAXCR_TAXITEM, ")
        sb.Append("TAXCR_TAXDATE, ")
        sb.Append("TAXCR_BASE_AMT, ")
        sb.Append("TAXCR_TAX_AMT, ")
        sb.Append("TAXCR_PAYEE, ")
        sb.Append("TAXCR_TAX_RATE, ")
        sb.Append("TAXCR_DESC, ")
        sb.Append("TAXCR_GL_ACCOUNT, ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_WHT_CREATION WHERE TAXCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("AND TAXCR_FLAG_BATCH='N' AND TAXCR_APPROVEDDATE = '" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub InsertTransLog(ByVal fn As String, ByVal systemdate As String, ByVal batchno As String, ByVal s_systemtime As String, ByVal status As String, ByVal total_rec As Integer)
        Dim oleTrans As OleDbTransaction

        Dim e_systemtime As String

        'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        e_systemtime = Now.ToString("HH:mm:ss")
        'e_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)


        'Dim total_rec, total_creation, total_load As Integer
        'total_creation = GetPaymentCreationRecord(systemdate)
        'total_load = GetPaymentLoadRecord(systemdate)

        'total_rec = total_creation + total_load

        Dim sb As New StringBuilder
        Dim rec As Integer

        'oleTrans = clsUtility.gConnGP.BeginTransaction()


        sb.Append("INSERT INTO GPS_TRANSLOG( ")
        sb.Append("TRAN_DATE,")
        sb.Append("TRAN_FUNCTION,")
        sb.Append("TRAN_BATCH_ID,")
        sb.Append("TRAN_S_TIME,")
        sb.Append("TRAN_E_TIME,")
        sb.Append("TRAN_RECORD,")
        sb.Append("TRAN_BATCH_TYPE,")
        sb.Append("TRAN_STATUS,")
        sb.Append("TRAN_REMARK,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & fn & "',")
        sb.Append("'" & batchno & "',")
        sb.Append("'" & s_systemtime & "',")
        sb.Append("'" & e_systemtime & "',")
        sb.Append("'" & total_rec & "',")
        sb.Append("'A',")
        sb.Append("'" & status & "',")
        sb.Append("'" & clsBusiness.gLastErrMessage & "',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            'oleTrans.Commit()
        Else
            'oleTrans.Rollback()
        End If

    End Sub

    Function InsertDataToTemp(ByVal systemdate As String, ByVal batchno As String, ByVal oleTrans As OleDbTransaction) As Boolean
        Dim insPaymentTLM, insWHTTLM As Boolean
        Dim strStatus As String
        strStatus = "2.0"
        '--oleTrans = clsUtility.gConnGP.BeginTransaction()
        strStatus = "2.1"
        insPaymentTLM = InsertToTempPayment_TLM(oleTrans, systemdate, batchno)
        strStatus = "2.2"
        insWHTTLM = InsertToTempWHT_TLM(oleTrans, systemdate, batchno)
        strStatus = "2.3"
        If insPaymentTLM = False Then
            clsBusiness.gLastErrMessage = "err insert TLM to gps_tmp_payment"
            InsertTransLog("APPROVE, TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        Else
            InsertTransLog("APPROVE, TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "COMPLETE", 0)
        End If
        strStatus = "2.4"
        If insWHTTLM = False Then
            clsBusiness.gLastErrMessage = "err insert TLM to gps_wht_payment"
            InsertTransLog("APPROVE, TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        Else
            InsertTransLog("APPROVE, TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "COMPLETE", 0)
        End If
        strStatus = "2.5"
        If insPaymentTLM And insWHTTLM Then
            '--oleTrans.Commit()
            strStatus = "2.5.1"
            Return True
        Else
            '--oleTrans.Rollback()
            strStatus = "2.5.2"
            Return False
        End If
    End Function

    Function Call_GPS_SP_VALIDATE_PAY_APP(ByVal batchdate As String) As Integer
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP_2.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate
        dbComm.Parameters.Add("v_error", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_VALIDATE_PAY_APP"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("v_error").Value


    End Function

    Function ValidateDataTemp(ByVal systemdate) As Boolean
        Dim ret As Integer

        ret = Call_GPS_SP_VALIDATE_PAY_APP(systemdate)

        If ret >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function chkDataComplete(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='COMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP_2, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If


    End Function

    Function chkDataReject(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder
        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP_2, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If

    End Function

    Private Sub GenValidationReport(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        Dim clsExportPDF As New clsCrystalToPDFConverter
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then


            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
            clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_PaymentApprove.pdf")

            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")

            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)
        End If
    End Sub

    Function InsertTableAML(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chk As Boolean

        chk = InsertAML(oleTrans)

        If chk Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function

    Function InsertAML(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_AML( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE ,")
        sb.Append("GP_WLSTT_SUBTYPE ,")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_WLSTT_TYPE='AML' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function

    Function InsertPaymentComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_COMPLETE( ")
        sb.Append("GPCM_BATCHDATE,")
        sb.Append("GPCM_BATCH_NO,")
        sb.Append("GPCM_CREATEDATE,")
        sb.Append("GPCM_CORE_SYSTEM,")
        sb.Append("GPCM_TRANSREF,")
        sb.Append("GPCM_GPTREF_SEQNO,")
        sb.Append("GPCM_POLNO,")
        sb.Append("GPCM_BILLNO,")
        sb.Append("GPCM_PAIDDATE,")
        sb.Append("GPCM_AMOUNT,")
        sb.Append("GPCM_DESC,")
        sb.Append("GPCM_PAYMTH,")
        sb.Append("GPCM_PAYEE_NAME,")
        sb.Append("GPCM_BNKCODE,")
        sb.Append("GPCM_BNKCODE_NO,")
        sb.Append("GPCM_BNKBRN,")
        sb.Append("GPCM_BNKNAME,")
        sb.Append("GPCM_PAYEE_BNKACCNO,")
        sb.Append("GPCM_PAYEE_BNKACCNME,")
        sb.Append("GPCM_COMMENT,")
        sb.Append("GPCM_ADDRESS1,")
        sb.Append("GPCM_DISTRICT,")
        sb.Append("GPCM_PROVINCE,")
        sb.Append("GPCM_INSURENAME,")
        sb.Append("GPCM_DATASOURCE_NME,")
        sb.Append("GPCM_RESERVE6,")
        sb.Append("GPCM_MERCHN_NO,")
        sb.Append("GPCM_CDCARD_DATE,")
        sb.Append("GPCM_RESERVE9,")
        sb.Append("GPCM_RESERVE10,")
        sb.Append("GPCM_SYS_REF,")
        sb.Append("GPCM_SYS_GR,")
        sb.Append("GPCM_SUB_PAYMTH,")
        sb.Append("GPCM_FLAG_FLWBILL,")
        sb.Append("GPCM_OSEA_LIST,")
        sb.Append("GPCM_PHONE,")
        sb.Append("GPCM_FAX,")
        sb.Append("GPCM_SWIFT_CODE,")
        sb.Append("GPCM_BNKBRN_NAME,")
        sb.Append("GPCM_BNKADDR,")
        sb.Append("GPCM_COUNTRY,")
        sb.Append("GPCM_CURRENCY,")
        sb.Append("GPCM_EXCHN_RATE,")
        sb.Append("GPCM_BNKCHARGES,")
        sb.Append("GPCM_BATCHTYPE,")
        sb.Append("GPCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_COMPLETE( ")
        sb.Append("TAXCM_BATCHDATE,")
        sb.Append("TAXCM_BATCH_NO,")
        sb.Append("TAXCM_CREATEDATE,")
        sb.Append("TAXCM_CORE_SYSTEM,")
        sb.Append("TAXCM_TRANSREF,")
        sb.Append("TAXCM_GPTREF_SEQNO,")
        sb.Append("TAXCM_LINENO,")
        sb.Append("TAXCM_TAXID,")
        sb.Append("TAXCM_IDCARD,")
        sb.Append("TAXCM_AP_TTL,")
        sb.Append("TAXCM_AP_FNAME,")
        sb.Append("TAXCM_AP_LNAME,")
        sb.Append("TAXCM_ADDRESS,")
        sb.Append("TAXCM_AMPENM,")
        sb.Append("TAXCM_PROVNM,")
        sb.Append("TAXCM_AGZIP,")
        sb.Append("TAXCM_TAXTYPE,")
        sb.Append("TAXCM_TAXITEM,")
        sb.Append("TAXCM_TAXDATE,")
        sb.Append("TAXCM_BASE_AMT,")
        sb.Append("TAXCM_TAX_AMT,")
        sb.Append("TAXCM_PAYEE,")
        sb.Append("TAXCM_TAX_RATE,")
        sb.Append("TAXCM_DESC,")
        sb.Append("TAXCM_GL_ACCOUNT,")
        sb.Append("TAXCM_BATCHTYPE,")
        sb.Append("TAXCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='COMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertTableComplete(ByVal oleTrans As OleDbTransaction) As Boolean


        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentComplete(oleTrans)
        chkWHT = InsertWHTComplete(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

    End Function
    Function InsertTableReject(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentReject(oleTrans)
        chkWHT = InsertWHTReject(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function

    Function InsertPaymentReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_REJ( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE, ")
        sb.Append("GP_WLSTT_SUBTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_REJ ( ")
        sb.Append("TAXRJ_BATCHDATE,")
        sb.Append("TAXRJ_BATCH_NO,")
        sb.Append("TAXRJ_CREATEDATE,")
        sb.Append("TAXRJ_CORE_SYSTEM,")
        sb.Append("TAXRJ_TRANSREF,")
        sb.Append("TAXRJ_GPTREF_SEQNO,")
        sb.Append("TAXRJ_LINENO,")
        sb.Append("TAXRJ_TAXID,")
        sb.Append("TAXRJ_IDCARD,")
        sb.Append("TAXRJ_AP_TTL,")
        sb.Append("TAXRJ_AP_FNAME,")
        sb.Append("TAXRJ_AP_LNAME,")
        sb.Append("TAXRJ_ADDRESS,")
        sb.Append("TAXRJ_AMPENM,")
        sb.Append("TAXRJ_PROVNM,")
        sb.Append("TAXRJ_AGZIP,")
        sb.Append("TAXRJ_TAXTYPE,")
        sb.Append("TAXRJ_TAXITEM,")
        sb.Append("TAXRJ_TAXDATE,")
        sb.Append("TAXRJ_BASE_AMT,")
        sb.Append("TAXRJ_TAX_AMT,")
        sb.Append("TAXRJ_PAYEE,")
        sb.Append("TAXRJ_TAX_RATE,")
        sb.Append("TAXRJ_DESC,")
        sb.Append("TAXRJ_GL_ACCOUNT,")
        sb.Append("TAXRJ_REJECT_TYPE,")
        sb.Append("TAXRJ_REJECT_FUNC,")
        sb.Append("TAXRJ_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='INCOMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function UpdateFlag(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        '--Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chkTranref, chkPayment, chkTranref_nonpay As Boolean

        chkPayment = UpdateFlagPayment_CR(oleTrans, systemdate)
        chkTranref = UpdateFlagTransRef(oleTrans, systemdate)
        chkTranref_nonpay = UpdateFlagTransRef_NONPAY(oleTrans, systemdate)

        'chkWHT = UpdateFlagWHT_CR(oleTrans, systemdate)
        'chk_gl = UpdateFlagGL_CR(oleTrans, systemdate)

        If chkTranref And chkPayment And chkTranref_nonpay Then
            oleTrans.Commit()
            Return True
        Else
            oleTrans.Rollback()
            Return False
        End If

    End Function
    Function UpdateFlag_GL(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk_gl As Boolean

        chk_gl = UpdateFlagGL_CR(systemdate, oleTrans)

        If chk_gl Then
            Return True
        Else
            Return False
        End If

    End Function
    Function UpdateFlag_TAX(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk, chknonpay As Boolean

        chk = UpdateFlagTAX_CR(systemdate, oleTrans)

        chknonpay = UpdateFlagTAX_CR_NONPAY(systemdate, oleTrans)

        If chk And chknonpay Then
            Return True
        Else
            Return False
        End If

    End Function

    Function UpdateFlagTransRef(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.TREF_BATCH_NO=T.GP_BATCH_NO, ")
        sb.Append("A.TREF_BATCHTYPE='A',   ")
        sb.Append("A.TREF_FLAG_BATCH='Y',   ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagTransRef_NONPAY(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A    ")
        sb.Append("USING     ")
        sb.Append("(    ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R  ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE  ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM  ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF  ")
        sb.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append(") T ON (   ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE   ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM   ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF   ")
        sb.Append(")     ")
        sb.Append("WHEN MATCHED THEN UPDATE     ")
        sb.Append("SET A.TREF_BATCH_NO=T.TAX_BATCH_NO,  ")
        sb.Append("A.TREF_BATCHTYPE='A',    ")
        sb.Append("A.TREF_FLAG_BATCH='Y',    ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagPayment_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT_CREATION A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.GPCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.GPCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.GPCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.GPCR_FLAG_BATCH='Y', ")
        sb.Append("A.GPCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagWHT_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_WHT_CREATION A ")
        sb.Append("USING ")
        sb.Append("( ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF ")
        'sb.Append("WHERE R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TAXCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TAXCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TAXCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.TAXCR_FLAG_BATCH='Y', ")
        sb.Append("A.TAXCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function

    Function UpdateFlagTAX_CR(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function
    Function UpdateFlagTAX_CR_NONPAY(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbChk As New StringBuilder()

        'sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        'sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        'sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        'sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        'sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        'sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        sbChk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO    ")
        sbChk.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R    ")
        sbChk.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE    ")
        sbChk.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM    ")
        sbChk.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF AND T.TAX_BATCHDATE='" & systemdate & "'    ")
        sbChk.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sbChk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbChk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function

    Public Function UPD_TAXCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_WHT_CREATION  ")
        sb.Append("SET TAXCR_FLAG_BATCH='Y', TAXCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE TAXCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND TAXCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND TAXCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Function UpdateFlagGL_CR(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_GLCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function

    Function UpdatePaymentReject_CR(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPCR_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPCR_CREATEDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPCR_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPCR_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPCR_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdatePaymentReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPLD_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPLD_BATCHDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPLD_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPLD_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPLD_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_CR(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_CREATION SET TAXCR_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXCR_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXCR_CREATEDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXCR_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXCR_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXCR_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_LOAD SET TAXLD_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXLD_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXLD_BATCHDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXLD_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXLD_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXLD_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function

    Function CallGL_REJ_PARTIAL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectpartial"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Function CallGL_REJ_ALL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectall"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Function SendEmailSCBLife(ByVal mailfuction As String) As String
        Dim Email As New MailMessage()
        Try
            Dim SMTPServer As New SmtpClient

            'For Each Attachment As String In Attachments
            '    Email.Attachments.Add(New Attachment(Attachment))
            'Next
            'Email.From = New MailAddress("AutomaticValidateReject@scblife.com")
            'For Each Recipient As String In Recipients
            '    Email.To.Add(Recipient)
            'Next

            'For Each CC As String In CCs
            '    If Trim(CC) <> "" Then
            '        Email.CC.Add(CC)
            '    End If
            'Next

            Email.From = New MailAddress("AutomaticValidateReject@scblife.com")

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    Email.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

            End If
            Email.Subject = "Reject Payment Transaction by Validation  [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
            Email.Body = "����������¡�è������١��ͧ (Error by Validation) ú�ǹ��Ǩ�ͺ��� path : " & ValidationReportPath
            SMTPServer.Host = "mailsmtp.scnyl.local"
            SMTPServer.Port = 25
            ''SMTPServer.Credentials = New System.Net.NetworkCredential(UserName, Password)
            ''SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()
            Return "Complete"
        Catch ex As SmtpException
            Email.Dispose()
            Return "Sending Email Failed. Smtp Error."
        Catch ex As ArgumentOutOfRangeException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        Catch Ex As InvalidOperationException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        End Try
    End Function

    Function GetEmail(ByVal mailfuction As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""
        sb.Append("SELECT EMAIL_ADDRESS FROM GPS_EMAIL_SETUP WHERE EMAIL_FUNC='" & mailfuction & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function

    Public Function UPD_GLCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_GL_CREATION  ")
        sb.Append("SET GLCR_FLAG_BATCH='Y', GLCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE GLCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND GLCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND GLCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Function DeleteOldDataTemp(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal transref As String) As Boolean
        Dim sb As New StringBuilder
        Dim d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14 As Boolean

        d7 = fnDelete(oleTrans, "delete from gps_tmp_payment ")

        d8 = fnDelete(oleTrans, "delete from gps_tmp_wht ")

        d9 = fnDelete(oleTrans, "delete from gps_payment_complete where gpcm_batchdate='" & systemdate & "' and gpcm_batchtype='A' and gpcm_batch_no = '" & batchno & "'")

        d10 = fnDelete(oleTrans, "delete from gps_wht_complete where taxcm_batchdate='" & systemdate & "' and taxcm_batchtype='A' and taxcm_batch_no = '" & batchno & "'")

        d11 = fnDelete(oleTrans, "delete from gps_payment_rej where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A' and (gprj_reject_type is null OR gprj_reject_type<>'BANK')  and gprj_batch_no = '" & batchno & "'")

        d12 = fnDelete(oleTrans, "delete from gps_wht_rej where taxrj_batchdate='" & systemdate & "' and taxrj_batchtype='A' and (taxrj_reject_type is null OR taxrj_reject_type<>'BANK')  and taxrj_batch_no = '" & batchno & "'")

        d13 = fnDelete(oleTrans, "delete from glm_gl_daily where gl_posting_date='" & systemdate & "' and gl_system_name='GPSA' and gl_transref = '" & transref & "' and gl_function = 'GP01' and upper(createdby) <> 'SYSTEM'")

        d14 = fnDelete(oleTrans, "delete from gps_aml where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A'  and gprj_batch_no = '" & batchno & "'")

        If (d7 And d8 And d9 And d10 And d11 And d12 And d13 And d14) Then
            Return True
            'MsgBox("Update already")
        Else
            'MsgBox(clsBusiness.gLastErrMessage)
            Return False
        End If

    End Function

    Function fnDelete(ByVal oleTrans As OleDbTransaction, ByVal str As String) As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        sb.Append(str)

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function


End Class