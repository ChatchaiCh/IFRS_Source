﻿Imports System.Text
Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.IO
Imports System.Globalization


Public Class frmExportSWC_PND2_3_53

    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB

    Dim l_strSQLGetPORNGORDOR As String = "select t.id, t.tax_type_name_th from gps_taxswc_taxtype_setup t order by t.tax_type_name_th"
    Dim strPathExportFile As String

    Private Sub frmExportSWC_PND2_3_53_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        txtAccPeriod.Text = Now.ToString("MM/yyyy", CultureInfo.InvariantCulture).PadLeft(8, "0")
        txtWHTPeriod.Text = Now.ToString("MM/yyyy", CultureInfo.InvariantCulture).PadLeft(8, "0")
        txtAccYear.Text = Now.ToString("yyyy", CultureInfo.InvariantCulture)
        txtWHTYear.Text = Now.ToString("yyyy", CultureInfo.InvariantCulture)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If ListPhorNgorDor() Then
            Cursor = Cursors.Default
            MsgBox("Cannot get Por Ngor Dor list" & vbCrLf, MsgBoxStyle.Critical)
            Exit Sub
        End If


        strPathExportFile = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "PHORNGORDOR2_PATH")
        With Panel3
            .Visible = False
            .Location = New Point(12, 87)
            .Width = Panel2.Width
            .Height = Panel2.Height
        End With

    End Sub

    Private Function ListPhorNgorDor() As Boolean

        Dim sb As New StringBuilder()
        Dim cls As New clsGPS_TAXSWC_TAXTYPE_SETUP
        Dim strWHERE As String = ""
        Dim dt As DataTable

        With cls
            .ConnDB = clsUtility.gConnGP
            dt = .GetRecord(strWHERE)
        End With

        '--sb.Append(l_strSQLGetPORNGORDOR)
        '--dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboPhorNgorDor
                .DataSource = dt
                .DisplayMember = "tax_type_name_th"
                .ValueMember = "tax_type_code"
            End With
        End If

        cboPhorNgorDor.SelectedIndex = 0

    End Function

    Private Sub RipsWareImageButtonBase1_Click(sender As System.Object, e As System.EventArgs) Handles RipsWareImageButtonBase1.Click

        Me.Close()

    End Sub

    Private Sub btnExport_Click(sender As System.Object, e As System.EventArgs) Handles btnExport.Click

        If cboPhorNgorDor.SelectedValue.ToString = "02A" Then
            If txtWHTYear.Text.Trim = "" Then
                MsgBox("Plese Enter WHT year")
                Exit Sub
            End If
        Else
            If txtAccPeriod.Text.Trim = "" Then
                MsgBox("Plese Enter Account Period")
                Exit Sub
            End If

            If txtWHTPeriod.Text.Trim = "" Then
                MsgBox("Plese Enter WHT Period")
                Exit Sub
            End If
        End If

        Dim x
        Dim strAcctPeriod() As String = txtAccPeriod.Text.Split("/")
        Dim strWHTPeriod() As String = txtWHTPeriod.Text.Split("/")
        Dim strAcctPeriodYM As String = strAcctPeriod(1) & strAcctPeriod(0).Substring(1, 2)
        Dim strWHTPeriodYM As String = strWHTPeriod(1) & strWHTPeriod(0).Substring(1, 2)
        Dim strTAXSWC As String = String.Empty
        Dim clsTAX As New ClsWHT
        Dim clsTAXSWC_Config As New clsGPS_TAXSWC_CONFIG_SETUP
        Dim strFormType As String = String.Empty
        Dim clsTAXSWC_TYPE As New clsGPS_TAXSWC_TAXTYPE_SETUP
        Dim strFlagIsYearly As String

        With clsTAXSWC_Config
            .ConnDB = clsUtility.gConnGP
            .GetConfig()
        End With
        With clsTAXSWC_TYPE
            .ConnDB = clsUtility.gConnGP
            strFlagIsYearly = .GetTaxTypeIsYearly(cboPhorNgorDor.SelectedValue.ToString)
        End With

        If strFlagIsYearly = "Y" Then
            strFormType = "00"
            strTAXSWC = clsTAX.GenSWCText(clsUtility.gConnGP, cboPhorNgorDor.SelectedValue, txtWHTYear.Text.Trim, txtAccYear.Text.Trim, strFormType)
        Else
            If strAcctPeriodYM = strWHTPeriodYM Then '--ยื่นปกติ
                strFormType = "00"
                strTAXSWC = clsTAX.GenSWCText(clsUtility.gConnGP, cboPhorNgorDor.SelectedValue, strWHTPeriodYM, strAcctPeriodYM, strFormType)
            ElseIf strAcctPeriodYM > strWHTPeriodYM Then '--ยื่นเพิ่มเติม
                strFormType = "01"
                strTAXSWC = clsTAX.GenSWCText(clsUtility.gConnGP, cboPhorNgorDor.SelectedValue, strWHTPeriodYM, strAcctPeriodYM, strFormType)
            Else
                strTAXSWC = ""
            End If
        End If

        '-- no data
        If clsTAX.TAXSWC_TOT_LINE = 0 Then
            MsgBox("Export " & cboPhorNgorDor.Text & ": No data!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        '-- no data

        '-- Update Export Round
        Dim clsExportOutRound As New clsGPS_TAXSWC_OUT
        Dim clsTaxType As New clsGPS_TAXSWC_TAXTYPE_SETUP
        clsTaxType.ConnDB = clsUtility.gConnGP

        With clsExportOutRound
            .ConnDB = clsUtility.gConnGP
            .ID = .GetdMaxID() + 1
            .GEN_DATE = Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)
            .TAX_PERIOD = strWHTPeriodYM
            .ACC_PERIOD = strAcctPeriodYM
            .TAX_TYPE = clsTaxType.GetTaxTypeID(cboPhorNgorDor.SelectedValue) '--cboPhorNgorDor.SelectedValue
            .TOTAL_LINE = clsTAX.TAXSWC_TOT_LINE
            .TOTAL_AMT = clsTAX.TAXSWC_TOT_AMT
            .TOTAL_TAX_AMT = clsTAX.TAXSWC_TOT_TAX
            .GEN_TYPE = strFormType
            .GEN_ROUND = .GetdRoundByFormType(cboPhorNgorDor.SelectedValue, strFormType, strWHTPeriodYM.ToString)
        End With
        '-- Update Export Round

        'Exporting to text file
        Dim strFileName As String
        If strFlagIsYearly = "Y" Then
            strFileName = clsTAXSWC_Config.configFILENAME_TAX_TYPE & cboPhorNgorDor.SelectedValue.ToString.Replace("0", "") _
                          & "_" _
                          & clsTAXSWC_Config.configFILENAME_NID _
                          & "_" _
                          & clsTAXSWC_Config.configFILENAME_BRANCH_NO _
                          & "_" _
                          & CStr(CInt(txtWHTYear.Text.Trim) + IIf(clsTAXSWC_Config.configFILENAME_TAX_YEAR = "YYBB", 543, 0)).Trim _
                          & "_" _
                          & "00" _
                          & "_" _
                          & strFormType _
                          & "_" _
                          & clsExportOutRound.GEN_ROUND.ToString.PadLeft(clsTAXSWC_Config.configFILENAME_ROUND.Replace("{", "").Replace("}", "").Length, "0") _
                          & "." _
                          & clsTAXSWC_Config.configFILENAME_EXTENSION
        Else
            strFileName = clsTAXSWC_Config.configFILENAME_TAX_TYPE & cboPhorNgorDor.SelectedValue.ToString.Replace("0", "") _
                          & "_" _
                          & clsTAXSWC_Config.configFILENAME_NID _
                          & "_" _
                          & clsTAXSWC_Config.configFILENAME_BRANCH_NO _
                          & "_" _
                          & CStr(CInt(strWHTPeriodYM.Substring(0, 4)) + IIf(clsTAXSWC_Config.configFILENAME_TAX_YEAR = "YYBB", 543, 0)).Trim _
                          & "_" _
                          & strWHTPeriodYM.Substring(4, 2) _
                          & "_" _
                          & strFormType _
                          & "_" _
                          & clsExportOutRound.GEN_ROUND.ToString.PadLeft(clsTAXSWC_Config.configFILENAME_ROUND.Replace("{", "").Replace("}", "").Length, "0") _
                          & "." _
                          & clsTAXSWC_Config.configFILENAME_EXTENSION
        End If

        Try
            Select Case clsTAXSWC_Config.configFILE_ENCODE
                Case "UTF-8"
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.UTF8)
                Case "ASCII"
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.ASCII)
                Case "BigEndianUnicode" '-- UTF-L 16
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.BigEndianUnicode)
                Case "ANSI" '-- default
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.Default)
                Case "UTF-16" '-- unicode
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.Unicode)
                Case "UTF-32"
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.UTF32)
                Case "UTF-7"
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.UTF7)
                Case Else
                    File.WriteAllText("D:\" & strFileName, strTAXSWC, Encoding.Default)
            End Select
            '-- move file to server
            Dim strSourceFileName As String = "D:\" & strFileName
            Dim strDestinationFileName As String = strPathExportFile & strFileName
            clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
            '-- end move file to server

            If clsExportOutRound.Insert() Then
                MsgBox("Export " & cboPhorNgorDor.Text & ": " & strFileName & " completed.", MsgBoxStyle.Information)
            Else
                MsgBox("Export " & cboPhorNgorDor.Text & ": " & strFileName & " error!" & vbCrLf & vbCrLf & "Insert export log error, Please contact administrator.", MsgBoxStyle.Exclamation)
            End If


        Catch ex As Exception
            'Throw ex
            MsgBox("Export " & cboPhorNgorDor.Text & " error!" & vbCrLf & vbCrLf & "Error message: " & ex.ToString, MsgBoxStyle.Critical)
        End Try
        '-------------------------------------------------

    End Sub

    Private Sub cboPhorNgorDor_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles cboPhorNgorDor.SelectedIndexChanged

        If cboPhorNgorDor.SelectedValue.ToString = "02A" Then
            Panel3.Visible = True
            Panel2.Visible = False
        Else
            Panel2.Visible = True
            Panel3.Visible = False
        End If

    End Sub

End Class