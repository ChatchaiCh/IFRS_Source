<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPaymentCreationReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboJournalType = New System.Windows.Forms.ComboBox()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.cboDueDate = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboUser = New System.Windows.Forms.ComboBox()
        Me.CmdOk = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboJournalType
        '
        Me.cboJournalType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboJournalType.FormattingEnabled = True
        Me.cboJournalType.Location = New System.Drawing.Point(119, 89)
        Me.cboJournalType.Name = "cboJournalType"
        Me.cboJournalType.Size = New System.Drawing.Size(162, 21)
        Me.cboJournalType.TabIndex = 17
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(410, 38)
        Me.PanelH1.TabIndex = 44
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(116, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(188, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "��§ҹ Payment Creation"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "JournalType :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "DueDate :"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.cboDueDate)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.cboUser)
        Me.PanelD1.Controls.Add(Me.cboJournalType)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(410, 136)
        Me.PanelD1.TabIndex = 45
        '
        'cboDueDate
        '
        Me.cboDueDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDueDate.FormattingEnabled = True
        Me.cboDueDate.Location = New System.Drawing.Point(119, 55)
        Me.cboDueDate.Name = "cboDueDate"
        Me.cboDueDate.Size = New System.Drawing.Size(162, 21)
        Me.cboDueDate.TabIndex = 43
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "User ID :"
        '
        'cboUser
        '
        Me.cboUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUser.FormattingEnabled = True
        Me.cboUser.Location = New System.Drawing.Point(119, 22)
        Me.cboUser.Name = "cboUser"
        Me.cboUser.Size = New System.Drawing.Size(162, 21)
        Me.cboUser.TabIndex = 41
        '
        'CmdOk
        '
        Me.CmdOk.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdOk.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.CmdOk.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdOk.ForeColor = System.Drawing.Color.White
        Me.CmdOk.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdOk.Image = Nothing
        Me.CmdOk.ImageKey = ""
        Me.CmdOk.ImageList = Nothing
        Me.CmdOk.Location = New System.Drawing.Point(260, 198)
        Me.CmdOk.Name = "CmdOk"
        Me.CmdOk.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdOk.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdOk.Size = New System.Drawing.Size(77, 28)
        Me.CmdOk.TabIndex = 103
        Me.CmdOk.Text = "Print"
        Me.CmdOk.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdOk.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(343, 198)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(77, 28)
        Me.btnExit.TabIndex = 104
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmPaymentCreationReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(442, 232)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.CmdOk)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmPaymentCreationReport"
        Me.Text = "FrmPaymentCreationReport"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cboJournalType As System.Windows.Forms.ComboBox
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents cboDueDate As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboUser As System.Windows.Forms.ComboBox
    Friend WithEvents CmdOk As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
