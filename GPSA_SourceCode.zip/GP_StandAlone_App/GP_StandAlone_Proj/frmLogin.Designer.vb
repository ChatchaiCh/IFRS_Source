<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLogin))
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.PasswordLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtUsername = New GP_StandAlone_App.WaterMarkTextBox()
        Me.TxtPassword = New GP_StandAlone_App.WaterMarkTextBox()
        Me.CmdOk = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'UsernameLabel
        '
        Me.UsernameLabel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.UsernameLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.UsernameLabel.Location = New System.Drawing.Point(15, 48)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(78, 25)
        Me.UsernameLabel.TabIndex = 12
        Me.UsernameLabel.Text = "&UserName"
        Me.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PasswordLabel
        '
        Me.PasswordLabel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.PasswordLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.PasswordLabel.Location = New System.Drawing.Point(15, 98)
        Me.PasswordLabel.Name = "PasswordLabel"
        Me.PasswordLabel.Size = New System.Drawing.Size(78, 25)
        Me.PasswordLabel.TabIndex = 13
        Me.PasswordLabel.Text = "&Password"
        Me.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.UsernameLabel)
        Me.Panel1.Controls.Add(Me.PasswordLabel)
        Me.Panel1.Controls.Add(Me.TxtUsername)
        Me.Panel1.Controls.Add(Me.TxtPassword)
        Me.Panel1.Location = New System.Drawing.Point(1, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(246, 165)
        Me.Panel1.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(14, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(218, 21)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Login to GP StandAlone"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TxtUsername
        '
        Me.TxtUsername.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TxtUsername.Location = New System.Drawing.Point(18, 76)
        Me.TxtUsername.Name = "TxtUsername"
        Me.TxtUsername.Size = New System.Drawing.Size(171, 20)
        Me.TxtUsername.TabIndex = 1
        Me.TxtUsername.WaterMarkColor = System.Drawing.Color.Gray
        Me.TxtUsername.WaterMarkText = "Enter UserName"
        '
        'TxtPassword
        '
        Me.TxtPassword.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TxtPassword.Location = New System.Drawing.Point(18, 124)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtPassword.Size = New System.Drawing.Size(171, 20)
        Me.TxtPassword.TabIndex = 2
        Me.TxtPassword.WaterMarkColor = System.Drawing.Color.Gray
        Me.TxtPassword.WaterMarkText = "Enter Password"
        '
        'CmdOk
        '
        Me.CmdOk.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.CmdOk.BackColor = System.Drawing.Color.Transparent
        Me.CmdOk.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdOk.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdOk.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOk.ForeColor = System.Drawing.Color.White
        Me.CmdOk.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdOk.Image = Global.GP_StandAlone_App.My.Resources.Resources.sq_br_next
        Me.CmdOk.ImageKey = ""
        Me.CmdOk.ImageList = Nothing
        Me.CmdOk.Location = New System.Drawing.Point(246, 2)
        Me.CmdOk.Name = "CmdOk"
        Me.CmdOk.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdOk.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.CmdOk.Size = New System.Drawing.Size(92, 167)
        Me.CmdOk.TabIndex = 15
        Me.CmdOk.Text = "OK"
        Me.CmdOk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'FrmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(341, 169)
        Me.Controls.Add(Me.CmdOk)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLogin"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GP Stand Alone"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents PasswordLabel As System.Windows.Forms.Label
    Friend WithEvents TxtPassword As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents TxtUsername As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CmdOk As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
