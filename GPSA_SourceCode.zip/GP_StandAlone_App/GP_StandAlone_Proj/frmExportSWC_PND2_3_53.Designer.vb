﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExportSWC_PND2_3_53
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtAccPeriod = New System.Windows.Forms.TextBox()
        Me.txtWHTPeriod = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RipsWareImageButtonBase1 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExport = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txtAccYear = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtWHTYear = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cboPhorNgorDor = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(351, 42)
        Me.Panel1.TabIndex = 113
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(57, 11)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(240, 17)
        Me.Label33.TabIndex = 9
        Me.Label33.Text = "Export POR NGOR DOR to SWC"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.txtAccPeriod)
        Me.Panel2.Controls.Add(Me.txtWHTPeriod)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(12, 87)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(351, 63)
        Me.Panel2.TabIndex = 114
        '
        'txtAccPeriod
        '
        Me.txtAccPeriod.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAccPeriod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAccPeriod.Location = New System.Drawing.Point(158, 8)
        Me.txtAccPeriod.MaxLength = 10
        Me.txtAccPeriod.Name = "txtAccPeriod"
        Me.txtAccPeriod.Size = New System.Drawing.Size(87, 20)
        Me.txtAccPeriod.TabIndex = 120
        '
        'txtWHTPeriod
        '
        Me.txtWHTPeriod.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtWHTPeriod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtWHTPeriod.Location = New System.Drawing.Point(158, 35)
        Me.txtWHTPeriod.MaxLength = 10
        Me.txtWHTPeriod.Name = "txtWHTPeriod"
        Me.txtWHTPeriod.Size = New System.Drawing.Size(87, 20)
        Me.txtWHTPeriod.TabIndex = 119
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(247, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 117
        Me.Label3.Text = "(MMM/CCYY)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 13)
        Me.Label4.TabIndex = 116
        Me.Label4.Text = "Account Period :"
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(247, 38)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 115
        Me.Label11.Text = "(MMM/CCYY)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 114
        Me.Label2.Text = "WHT Period :"
        '
        'RipsWareImageButtonBase1
        '
        Me.RipsWareImageButtonBase1.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RipsWareImageButtonBase1.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.RipsWareImageButtonBase1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RipsWareImageButtonBase1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RipsWareImageButtonBase1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.RipsWareImageButtonBase1.ForeColor = System.Drawing.Color.White
        Me.RipsWareImageButtonBase1.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.RipsWareImageButtonBase1.Image = Nothing
        Me.RipsWareImageButtonBase1.ImageKey = ""
        Me.RipsWareImageButtonBase1.ImageList = Nothing
        Me.RipsWareImageButtonBase1.Location = New System.Drawing.Point(284, 162)
        Me.RipsWareImageButtonBase1.Name = "RipsWareImageButtonBase1"
        Me.RipsWareImageButtonBase1.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.RipsWareImageButtonBase1.Size = New System.Drawing.Size(79, 28)
        Me.RipsWareImageButtonBase1.TabIndex = 116
        Me.RipsWareImageButtonBase1.Text = "Exit"
        Me.RipsWareImageButtonBase1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RipsWareImageButtonBase1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExport
        '
        Me.btnExport.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExport.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExport.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExport.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExport.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExport.ForeColor = System.Drawing.Color.White
        Me.btnExport.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExport.Image = Nothing
        Me.btnExport.ImageKey = ""
        Me.btnExport.ImageList = Nothing
        Me.btnExport.Location = New System.Drawing.Point(194, 162)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExport.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExport.Size = New System.Drawing.Size(79, 28)
        Me.btnExport.TabIndex = 115
        Me.btnExport.Text = "Export"
        Me.btnExport.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExport.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.txtAccYear)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.txtWHTYear)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Location = New System.Drawing.Point(12, 155)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(351, 65)
        Me.Panel3.TabIndex = 117
        '
        'txtAccYear
        '
        Me.txtAccYear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAccYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAccYear.Location = New System.Drawing.Point(158, 36)
        Me.txtAccYear.MaxLength = 10
        Me.txtAccYear.Name = "txtAccYear"
        Me.txtAccYear.Size = New System.Drawing.Size(87, 20)
        Me.txtAccYear.TabIndex = 126
        Me.txtAccYear.Visible = False
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(250, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 125
        Me.Label7.Text = "(CCYY)"
        Me.Label7.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(27, 39)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 13)
        Me.Label8.TabIndex = 124
        Me.Label8.Text = "Account Year :"
        Me.Label8.Visible = False
        '
        'txtWHTYear
        '
        Me.txtWHTYear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtWHTYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtWHTYear.Location = New System.Drawing.Point(158, 9)
        Me.txtWHTYear.MaxLength = 10
        Me.txtWHTYear.Name = "txtWHTYear"
        Me.txtWHTYear.Size = New System.Drawing.Size(87, 20)
        Me.txtWHTYear.TabIndex = 123
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(249, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 122
        Me.Label5.Text = "(CCYY)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 121
        Me.Label6.Text = "WHT Year :"
        '
        'cboPhorNgorDor
        '
        Me.cboPhorNgorDor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboPhorNgorDor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPhorNgorDor.FormattingEnabled = True
        Me.cboPhorNgorDor.Location = New System.Drawing.Point(171, 63)
        Me.cboPhorNgorDor.Name = "cboPhorNgorDor"
        Me.cboPhorNgorDor.Size = New System.Drawing.Size(162, 21)
        Me.cboPhorNgorDor.TabIndex = 122
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 121
        Me.Label1.Text = "ประเภท ภงด :"
        '
        'frmExportSWC_PND2_3_53
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(375, 198)
        Me.Controls.Add(Me.RipsWareImageButtonBase1)
        Me.Controls.Add(Me.btnExport)
        Me.Controls.Add(Me.cboPhorNgorDor)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmExportSWC_PND2_3_53"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmExportSWC_PND2_3_53"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtAccPeriod As System.Windows.Forms.TextBox
    Friend WithEvents txtWHTPeriod As System.Windows.Forms.TextBox
    Friend WithEvents RipsWareImageButtonBase1 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnExport As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents txtWHTYear As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboPhorNgorDor As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtAccYear As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
