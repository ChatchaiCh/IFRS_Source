﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Imports System.Globalization

Public Class frmExportPayment
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim clsRpt As New ClsReport
    Dim clsLog As New ClsLog
    Dim clsHashLO As New ClsHashTotalErrorLOCancel
    Dim LO_Dup As New StringBuilder
    Dim sDataExist As New StringBuilder
    Dim strPathExportFile As String
    Dim clsConnectDB As ConnectDB


    Private Sub frmExportPayment_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2 = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        strPathExportFile = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "PHORNGORDOR2_PATH")

        InitializeForm()

    End Sub
    Private Sub InitializeForm()
        Dim strFormatDate As String = "dd-MM-yyyy"
        Dim dteDateShow As Date = DateTime.Today.AddMonths(-1)
        Dim dteEndMonthShow As New DateTime(DateTime.Today.Year, DateTime.Today.Month, 1)
        dtpFromDate.CustomFormat = strFormatDate
        dtpFromDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), 1)
        dtpToDate.CustomFormat = strFormatDate
        dtpToDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), dteEndMonthShow.AddDays(-1).Day)
        btnCancel.Focus()
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnExport_Click(sender As System.Object, e As System.EventArgs) Handles btnExport.Click
        Try

            Dim csv As String = """เลขที่ Batch"",""ประเภทกลุ่มการจ่าย"",""Payment Method"",""No"",""Payment Date"",""Voucher No"",""TransactionRef. No."",""เลขที่ Cheque"",""InstrumentNo"",""ธนาคาร"",""ชื่อ-นามสกุล"","" จำนวนเงิน"","" ภาษีหัก ณ ที่จ่าย"","" จำนวนสุทธิ"",""WHT Tax No"",""Description"",""LastUpdate Status"",""LastUpdateStatusDate""" & vbCr & vbLf
            Dim csvRej As String = """System"",""Department"",""Payment Date"",""Payment Method"",""Business"",""Voucher No"",""Description"",""Policy No"",""Bank Code"",""Bank A/C No."",""Payee Name"",""Amount"",""Reject Group"",""Reject Type"",""Reason"",""Status Date""" & vbCr & vbLf
            Dim dt As DataTable = clsRpt.GetDataPayment(clsUtility.gConnGP, dtpFromDate.Value.ToString("yyyyMMdd"), dtpToDate.Value.ToString("yyyyMMdd"))
            Dim dtRej As DataTable = clsRpt.GetDataPaymentReject(clsUtility.gConnGP, dtpFromDate.Value.ToString("yyyyMMdd"), dtpToDate.Value.ToString("yyyyMMdd"))

            If dt Is Nothing And dtRej Is Nothing Then
                MsgBox("ไม่พบข้อมูล", vbExclamation)
                Exit Sub
            End If

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    'Add the Data rows.
                    csv += row(0).ToString & vbCr & vbLf
                Next
                'Exporting to text file
                Dim strFileName As String = "PAYMENT_" & dtpFromDate.Value.ToString("yyyyMM") & ".csv"
                '-- move file to server
                'Dim strSourceFileName As String = "D:\" & strFileName
                'Dim strDestinationFileName As String = strPathExportFile & strFileName
                'clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
                '-- end move file to server
                strPathExportFile = "D:\"
                File.WriteAllText(strPathExportFile & strFileName, csv, Encoding.UTF8)

                MsgBox("Export PAYMENT เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & "PAYMENT_" & dtpFromDate.Value.ToString("yyyyMM") & ".csv", MsgBoxStyle.Information)
            End If

            If Not IsNothing(dtRej) AndAlso dtRej.Rows.Count > 0 Then
                For Each row As DataRow In dtRej.Rows
                    'Add the Data rows.
                    csvRej += row(0).ToString & vbCr & vbLf
                Next
                'Exporting to text file
                Dim strFileName As String = "PAYMENT_REJ_" & dtpFromDate.Value.ToString("yyyyMM") & ".csv"
                '-- move file to server
                'Dim strSourceFileName As String = "D:\" & strFileName
                'Dim strDestinationFileName As String = strPathExportFile & strFileName
                'clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
                '-- end move file to server
                strPathExportFile = "D:\"
                File.WriteAllText(strPathExportFile & strFileName, csvRej, Encoding.UTF8)

                MsgBox("Export PAYMENT REJECT เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & "PAYMENT_REJ_" & dtpFromDate.Value.ToString("yyyyMM") & ".csv", MsgBoxStyle.Information)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical)
        End Try

    End Sub
End Class