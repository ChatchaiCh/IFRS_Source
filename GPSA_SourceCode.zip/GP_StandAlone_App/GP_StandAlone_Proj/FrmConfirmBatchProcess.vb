Imports System.ComponentModel
Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary

Public Class FrmConfirmBatchProcess
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsConfirmBatch
    Dim timework As Integer = 1
    Dim clsGPS_PayoutGroupSetup As New ClsGPS_PayOutGroup_Setup
#Region "BackgroundWorker"
    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

        ConfirmProcess()

        Dim i As Integer
        For i = 0 To timework Step +1

            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                BackgroundWorker1.ReportProgress(i)
                System.Threading.Thread.Sleep(timework)
            End If
        Next



    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ''���� 1 progress      
        ProgressBar1.Value = e.ProgressPercentage
        lblprogress.Text = "processing... " & e.ProgressPercentage & " %"
        
    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
   
        ShowReport()
        ListBatchNo()
        ClearData()
        Cursor = Cursors.Default
        'Me.Close()

    End Sub
    
#End Region
    Private Sub FrmGeneratePayment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = False
        My.Application.ChangeCulture("en-GB")

        ControlStyle()
        lblDate.Text = Now.ToString("dd/MM/yyyy")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListBatchNo()
        ListPayType()

        btnConfirm.Enabled = False
      
    End Sub
    Private Sub ControlStyle()
        Panel1.BackColor = Color.FromArgb(255, 235, 200)

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelH2.BackColor = Color.FromArgb(255, 235, 200)
        PanelH3.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        PanelD2.BackColor = Color.FromArgb(255, 245, 240)
        PanelD3.BackColor = Color.FromArgb(255, 245, 240)

        'txtNonPay.BackColor = Color.FromArgb(255, 235, 200)

        btnConfirm.BackColor = Color.FromArgb(255, 235, 220)
        btnConfirm.Height = 25
    End Sub
    Private Sub ListBatchNo()

        Dim dt As DataTable
        dt = cls.ListBatchNo(clsUtility.gConnGP)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        With cboBatchNo
            .DataSource = dt
            .DisplayMember = "gpcm_batch_no"
            .ValueMember = "gpcm_batch_no"
        End With
        ' End If

    End Sub
    Private Sub ListPayType()
        Try
            Dim dt As DataTable
            dt = cls.ListPayType(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim dr As DataRow = dt.NewRow
                dr!id = 0
                dr!name = "-----(All)-----"
                dt.Rows.InsertAt(dr, 0)
                With cboPayType
                    .DataSource = dt
                    .DisplayMember = "name"
                    .ValueMember = "id"
                End With
            End If
        Catch ex As Exception

        End Try


    End Sub
  
    Private Sub BindData()

        If cboBatchNo.Text = "" Or cboPayType.Text = "" Then
            Exit Sub
        End If

        Dim sb As New StringBuilder()
        If cboPayType.SelectedValue.ToString <> "zNON_PAY" Then

            Dim dt As DataTable
            If cboPayType.SelectedIndex <> 0 Then
                dt = cls.BindData(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString, cboPayType.SelectedValue.ToString)
            Else
                dt = cls.BindData(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString, "")
            End If

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                For Each dr As DataRow In dt.Rows
                    Dim pay_subpay As String
                    pay_subpay = dr("GPCM_PAYMTH").ToString & ":" & dr("GPCM_SUB_PAYMTH").ToString
                    Select Case pay_subpay
                        Case "C:C"
                            txtM_Cheque.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "D:D"
                            txtM_Draft.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "M:M"
                            txtMedia.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "C:Q"
                            txtCompanyCheque.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "C:H"
                            txtCashierCheque.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "C:G"
                            txtGiftCheque.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "C:T"
                            txtMoneyOrder.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "C:B"
                            txtBankDraft.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "M:C"
                            txtCreditCard.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "M:A"
                            txtATS.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")
                        Case "M:B"
                            txtOverSea.Text = Convert.ToDouble(dr("AMT")).ToString("###,##0.00")

                    End Select
                Next

                If cboPayType.SelectedIndex = 0 Then
                    BindNonPay()
                End If

            End If
        Else
            BindNonPay()
        End If

        If CheckCHQNO() Then
            btnConfirm.Enabled = True
        Else
            btnConfirm.Enabled = False
        End If

    End Sub
    Private Sub BindNonPay()
        Dim dt As DataTable
        dt = cls.BindDataNonPay(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            txtNonPay.Text = Convert.ToDouble(dt.Rows(0)("amt")).ToString("###,##0.00")
        End If
    End Sub
    Private Sub BindNonPay_1Time()
        Dim dt As DataTable
        dt = cls.BindDataNonPay(clsUtility.gConnGP, txtBatchNo.Text)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            txtNonPay.Text = Convert.ToDouble(dt.Rows(0)("amt")).ToString("###,##0.00")
        End If
    End Sub
    Private Sub ClearData()
        txtM_Cheque.Text = "0.00"
        txtM_Draft.Text = "0.00"
        txtMedia.Text = "0.00"
        txtCompanyCheque.Text = "0.00"
        txtCashierCheque.Text = "0.00"
        txtGiftCheque.Text = "0.00"
        txtMoneyOrder.Text = "0.00"
        txtBankDraft.Text = "0.00"
        txtCreditCard.Text = "0.00"
        txtATS.Text = "0.00"
        txtOverSea.Text = "0.00"
        txtNonPay.Text = "0.00"
    End Sub
    Function CheckStockCHQ(ByVal dtchq As DataTable) As Double
        Dim min1, max1, min2, max2 As Double
        Dim p1, p2 As Double
        Dim remain As Double

        If dtchq.Rows.Count > 0 Then
            min1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ1"))
            max1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ1"))
            min2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ2"))
            max2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ2"))

           

            If max1 = 0 And min1 = 0 Then
                p1 = 0
            Else
                If (min1 = max1) And (Not IsDBNull(dtchq.Rows(0)("CHQS_S_CHQ1_FINISH")) AndAlso dtchq.Rows(0)("CHQS_S_CHQ1_FINISH") = "Y") Then
                    p1 = 0
                Else
                    p1 = (max1 - min1) + 1
                End If

            End If

            If max2 = 0 And min2 = 0 Then
                p2 = 0
            Else
                If (min2 = max2) And (Not IsDBNull(dtchq.Rows(0)("CHQS_S_CHQ2_FINISH")) AndAlso dtchq.Rows(0)("CHQS_S_CHQ2_FINISH") = "Y") Then
                    p2 = 0
                Else
                    p2 = (max2 - min2) + 1
                End If
            End If

            remain = p1 + p2


            Return remain

        End If
    End Function
    Function CheckCHQNO() As Boolean
        Dim ret As Boolean
        Dim dt As New DataTable
        dt = cls.fnCountCHQNO(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        Dim dtchq As New DataTable
        dtchq = cls.GetChequeNo(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim quse, remain As Double
            quse = dt.Rows.Count
            remain = CheckStockCHQ(dtchq)

            If quse > remain Then

                btnConfirm.Enabled = False
                MsgBox("�ӹǹ��� Stock �����§��" & vbCrLf & _
                       "Stock Cheque : " & remain & " ��Ѻ" & vbCrLf & _
                       "�ӹǹ Cheque ����ͧ�����㹤��駹�� : " & quse & " ��Ѻ" & vbCrLf & _
                       "��س� Maintain Stock Cheque ��͹ Confirm Batch �ա����", MsgBoxStyle.Exclamation)

                ret = False
            Else
                ret = True
            End If
        Else
            ret = True
        End If

        Return ret
    End Function
    Private Sub ConfirmProcess()

        btnConfirm.Enabled = False

        Dim oleTrans As OleDbTransaction
        Dim chk1, chk2, chk3, chk4, chk_wht, chk_whtperiod As Boolean


        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        ClearData()
        BindData()

        Dim dt As New DataTable
        dt = cls.GetDataForINS(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        If IsNothing(dt) Then
            StopWorker()
            Exit Sub
        End If

        Dim dtchq As New DataTable
        dtchq = cls.GetChequeNo(clsUtility.gConnGP)

        Dim dtIns As New DataTable
        dtIns = cls.GetDataForInstrument(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        Dim dtWHT As New DataTable
        dtWHT = cls.GetDataWHT(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        Dim dtWHTSeq As New DataTable
        dtWHTSeq = cls.GetDataWHTSeqNo(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString)

        Dim idPay As Integer
        idPay = cls.GetMaxID(clsUtility.gConnGP, "GP_SEQNO", "GPS_PAYMENT")

        Dim idWHT As Integer
        idWHT = cls.GetMaxID(clsUtility.gConnGP, "TAX_SEQNO", "GPS_WHT")

        Dim filterchq() As DataRow = dt.Select("PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")

        'If filterchq.Length > 0 Then
        '    Dim quse, remain As Double
        '    quse = filterchq.Length
        '    remain = CheckStockCHQ(dtchq)

        '    If quse > remain Then

        '        btnConfirm.Enabled = False
        '        MsgBox("�ӹǹ��� Stock �����§��" & vbCrLf & _
        '               "Stock Cheque : " & remain & " ��Ѻ" & vbCrLf & _
        '               "�ӹǹ Cheque ����ͧ�����㹤��駹�� : " & quse & " ��Ѻ" & vbCrLf & _
        '               "��س� Maintain Stock Cheque ��͹ Confirm Batch �ա����", MsgBoxStyle.Exclamation)
        '        StopWorker()
        '        Exit Sub

        '    End If

        'End If

        Dim lst As ArrayList = MaintainChequeNo(dtchq, filterchq.Length)

        Dim pay_subpay As String
        If cboPayType.SelectedIndex <> 0 Then
            pay_subpay = cls.GetPaymentMethod(clsUtility.gConnGP, cboPayType.SelectedValue.ToString)
        Else
            pay_subpay = cls.GetPaymentMethod(clsUtility.gConnGP, "")
        End If


        oleTrans = clsUtility.gConnGP.BeginTransaction()

        chk1 = cls.UpdateConfirmPayment(clsUtility.gConnGP, oleTrans, pay_subpay, cboBatchNo.SelectedValue.ToString, gUserLogin)

        chk_wht = cls.UpdateConfirmWHT(clsUtility.gConnGP, oleTrans, cboBatchNo.SelectedValue.ToString.ToString, gUserLogin)

        chk_whtperiod = cls.UpdateWHTPeriod(clsUtility.gConnGP, oleTrans, cboBatchNo.SelectedValue.ToString.ToString, gUserLogin)

        chk2 = INSERTDATA(oleTrans, dt, lst, dtIns, idPay, systemdate)

        chk3 = UpdateChequeNo(oleTrans, dtchq, filterchq.Length)

        chk4 = INSERTWHT(oleTrans, dtWHT, idWHT, dtWHTSeq, systemdate)

        If (chk1 And chk2 And chk3 And chk4 And chk_wht) Then
            oleTrans.Commit()

            Dim chkcall As Boolean

            chkcall = Call_GPS_SP_GET_TRANSACTIONAC(cboBatchNo.SelectedValue.ToString.Substring(2, 8), cboBatchNo.SelectedValue.ToString, gUserLogin)

            If chkcall = False Then
                MsgBox("�������ö Generate GL ��Ѻ���� ��سҵԴ��� Admin")
                StopWorker()
            End If

            PrintReportCertificate(cboBatchNo.SelectedValue.ToString)

        Else
            oleTrans.Rollback()

            MsgBox("Confirm Batch Error!")
            StopWorker()
        End If

      
    End Sub
    Function Call_GPS_SP_GET_TRANSACTIONAC(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "GPS_SP_GET_TRANSACTIONAC"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Private Sub ShowReport()
        PrintReportRegister(cboBatchNo.SelectedValue.ToString)
        PrintReportWHT(cboBatchNo.SelectedValue.ToString)
        'PrintReportCertificate(cboBatchNo.SelectedValue.ToString)
    End Sub

    Function MaintainChequeNo(ByVal dtchq As DataTable, ByVal total_use As Int16) As ArrayList
        Dim min1, max1, min2, max2 As Double

        If dtchq.Rows.Count > 0 Then
            min1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ1"))
            max1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ1"))
            min2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ2"))
            max2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ2"))
        End If
        Dim arr As New ArrayList

        If min1 <= max1 And (Not IsDBNull(dtchq.Rows(0)("CHQS_S_CHQ1_FINISH")) AndAlso dtchq.Rows(0)("CHQS_S_CHQ1_FINISH") = "N") Then
            If total_use <= (max1 - min1) + 1 Then
                For i As Integer = 0 To total_use
                    arr.Add(min1)
                    min1 = min1 + 1
                Next
            Else
                Dim remain As Integer
                remain = (max1 - min1) + 1

                For i As Integer = 1 To remain
                    arr.Add(min1)
                    min1 = min1 + 1
                Next

                Dim remain2 As Integer
                remain2 = total_use - (remain)
                For i As Integer = 1 To remain2
                    arr.Add(min2)
                    min2 = min2 + 1
                Next


            End If
        Else
            If total_use <= (max2 - min2) + 1 Then
                For i As Integer = 0 To total_use
                    arr.Add(min2)
                    min2 = min2 + 1
                Next
            Else
                Dim remain As Integer
                remain = (max2 - min2) + 1

                For i As Integer = 1 To remain
                    arr.Add(min2)
                    min2 = min2 + 1
                Next

                Dim remain2 As Integer
                remain2 = total_use - (remain)
                For i As Integer = 1 To remain2
                    arr.Add(min1)
                    min1 = min1 + 1
                Next


            End If
        End If

        Return arr
    End Function
    Function UpdateChequeNo(ByVal oleTrans As OleDbTransaction, ByVal dtchq As DataTable, ByVal total_use As Int16) As Boolean
        Dim ret As Boolean

        If total_use <> 0 Then

            Dim min1, max1, min2, max2 As Double

            If dtchq.Rows.Count > 0 Then
                min1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ1"))
                max1 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ1"))
                min2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_S_CHQ2"))
                max2 = Convert.ToDouble(dtchq.Rows(0)("CHQS_E_CHQ2"))
            End If
            Dim arr As New ArrayList


            If (Not IsDBNull(dtchq.Rows(0)("CHQS_S_CHQ1_FINISH")) AndAlso dtchq.Rows(0)("CHQS_S_CHQ1_FINISH") = "N") Then
                If total_use = (max1 - min1) + 1 Then
                    ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, max1, min2, "Y", "", gUserLogin)
                ElseIf total_use < (max1 - min1) + 1 Then
                    ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, min1 + total_use, min2, "", "", gUserLogin)
                Else
                    Dim remain As Integer
                    remain = (max1 - min1) + 1
                    Dim remain2 As Integer
                    remain2 = total_use - remain

                    If remain2 = (max2 - min2) + 1 Then
                        ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, max1, max2, "Y", "Y", gUserLogin)
                    Else
                        ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, max1, min2 + remain2, "Y", "", gUserLogin)
                    End If

                End If
            Else
                Dim remain As Integer
                remain = (max2 - min2) + 1

                If total_use = remain Then
                    ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, max1, max2, "Y", "Y", gUserLogin)
                Else
                    ret = cls.UpdateChequeNo(clsUtility.gConnGP, oleTrans, max1, min2 + total_use, "Y", "", gUserLogin)
                End If

            End If


        Else
            ret = True
        End If

        Return ret
    End Function
    Function INSERTDATA(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal lstchq As ArrayList, ByVal dtIns As DataTable, ByVal idPay As Integer, ByVal systemdate As String) As Boolean

        Dim rec As Integer
        Dim rec2 As Integer
        Dim c_ism As Integer
        Dim index_chq As Integer = 0

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows
                Dim sb As New StringBuilder

                If dr("PAYT_PAY_GROUP") = "SCBLIFE_CHQ" Then

                    sb.Append(cls.InsertPayment(dr, idPay, systemdate, lstchq(index_chq), gUserLogin))
                    index_chq = index_chq + 1

                Else
                    sb.Append(cls.InsertPayment(dr, idPay, systemdate, "", gUserLogin))
                End If

                If dr("GPCM_TRANSREF") = "ACC7909/395414" Then
                    Debug.Print(sb.ToString)
                End If

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


                If dr("GPCM_PAYMTH") = "C" And (dr("GPCM_SUB_PAYMTH") = "H" Or dr("GPCM_SUB_PAYMTH") = "G" Or dr("GPCM_SUB_PAYMTH") = "B" Or dr("GPCM_SUB_PAYMTH") = "T") Then

                    If dtIns.Rows.Count > 0 Then
                        Dim foundRows_link() As DataRow
                        foundRows_link = dtIns.Select("GPCM_TRANSREF='" & dr("GPCM_TRANSREF") & "'")

                        'For Each drIns As DataRow In dtIns.Rows
                        For Each drIns As DataRow In foundRows_link
                            Dim sb2 As New StringBuilder

                            sb2.Append(cls.InsertInstrument(drIns, idPay, systemdate, gUserLogin))

                            rec2 = rec2 + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

                            c_ism = c_ism + 1

                        Next
                    End If


                End If

                idPay = idPay + 1

            Next



            If (rec = dt.Rows.Count) And (rec2 = c_ism) Then
                Return True

            Else
                Return False

            End If

        Else
            Return True
        End If

    End Function
    Function INSERTWHT(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal id As Integer, ByVal dtSeq As DataTable, ByVal systemdate As String) As Boolean
        Dim rec As Integer

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows

                Dim sb As New StringBuilder
                Dim groupSeq As String
                groupSeq = dr("TAXCM_TAXTYPE") & ":" & dr("TAXCM_TAXDATE").ToString.Substring(0, 6)

                For Each drSeq As DataRow In dtSeq.Rows

                    If groupSeq = drSeq("TAXCM_TAXTYPE") & ":" & drSeq("TAXDATE") Then

                        drSeq("CHQNO") = Convert.ToInt16(drSeq("CHQNO")) + 1

                        Dim chqno As String
                        chqno = dr("PNGD_PHORNGORDOR").ToString & dr("TAXCM_TAXDATE").ToString.Substring(0, 6) & drSeq("CHQNO").ToString.PadLeft(4, "0")

                        sb.Append(cls.InsertWHT(dr, id, chqno, systemdate, gUserLogin))

                        rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

                    End If

                Next

                id = id + 1

            Next


            If rec = dt.Rows.Count Then
                Return True

            Else
                Return False
            End If
        Else
            Return True
        End If


    End Function
    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click

        If chkNonPay.Checked = True Then

            Dim insPaymentTLM, insWHTTLM, insPaymentPP, insWHTPP As Boolean
            Dim chkPayment, chkWHT As Boolean
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()
            insWHTTLM = InsertToTempWHT_TLM(oleTrans, Mid(txtBatchNo.Text, 3, 8), txtBatchNo.Text)
            oleTrans.Commit()
            oleTrans = clsUtility.gConnGP.BeginTransaction()
            chkWHT = InsertWHTComplete(oleTrans)
            oleTrans.Commit()

            BindNonPay_1Time()

            Dim chk1, chk2, chk3, chk4, chk_wht, chk_whtperiod As Boolean
            Dim idWHT As Integer
            idWHT = cls.GetMaxID(clsUtility.gConnGP, "TAX_SEQNO", "GPS_WHT")
            oleTrans = clsUtility.gConnGP.BeginTransaction()
            chk_wht = cls.UpdateConfirmWHT(clsUtility.gConnGP, oleTrans, txtBatchNo.Text, gUserLogin)
            chk_whtperiod = cls.UpdateWHTPeriod(clsUtility.gConnGP, oleTrans, txtBatchNo.Text, gUserLogin)
            oleTrans.Commit()
            Dim dtWHT As New DataTable
            dtWHT = cls.GetDataWHT(clsUtility.gConnGP, txtBatchNo.Text)
            Dim dtWHTSeq As New DataTable
            dtWHTSeq = cls.GetDataWHTSeqNo(clsUtility.gConnGP, txtBatchNo.Text)
            oleTrans = clsUtility.gConnGP.BeginTransaction()
            chk4 = INSERTWHT(oleTrans, dtWHT, idWHT, dtWHTSeq, Mid(txtBatchNo.Text, 3, 8))
            oleTrans.Commit()

            PrintReportCertificate(txtBatchNo.Text)
            '            btnConfirm.Enabled = True
        Else
            ClearData()
            BindData()
        End If
        '-- test
        '--        PrintReportCertificate(cboBatchNo.SelectedValue.ToString)

    End Sub
    Private Sub cboBatchNo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBatchNo.SelectedIndexChanged
        ListPayType()
        ClearData()
        btnConfirm.Enabled = False
    End Sub
    Function GetDataHead(ByVal batchno As String) As DataTable
        Dim dt As DataTable
        dt = cls.GetDataRptPaymentRegistrationByBatch(clsUtility.gConnGP, batchno)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataDetail(ByVal batchno As String) As DataTable
        Dim dt As DataTable
        dt = cls.GetDataRptPaymentRegistrationByBatch_Detail(clsUtility.gConnGP, batchno)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataWHT(ByVal batchno As String) As DataTable

        Dim dt As DataTable
        dt = clsBusiness.GetDataRptWHT(clsUtility.gConnGP, batchno)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataCertificate(ByVal batchno As String) As DataTable

        Dim dt As DataTable

        dt = cls.GetDataCertificateReport(clsUtility.gConnGP, batchno)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub PrintReportRegister(ByVal batchno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPaymentRegisterByBatch.rpt")



        Dim dtHead As DataTable

        dtHead = GetDataHead(batchno)
        dtHead = MaskPanData(dtHead)


        If Not IsNothing(dtHead) AndAlso dtHead.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dtHead)


            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub
    Private Sub PrintReportRegister_OLD(ByVal batchno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPaymentRegisterByBatch_Detail.rpt")


        Dim DSRpt As New DSPaymentRegister

        Dim dtHead As DataTable = New DSPaymentRegister.dtHeadDataTable
        Dim dtDetail As DataTable = New DSPaymentRegister.dtDetailDataTable

        dtHead = GetDataHead(batchno)
        dtDetail = GetDataDetail(batchno)

        DSRpt.Merge(dtHead, True, MissingSchemaAction.Ignore)

        If Not IsNothing(dtDetail) AndAlso dtDetail.Rows.Count > 0 Then
            DSRpt.Merge(dtDetail, True, MissingSchemaAction.Ignore)
        End If


        'Dim dt As DataTable = New DataTable()
        'dt = GetDataHead()



        If Not IsNothing(dtHead) AndAlso dtHead.Rows.Count > 0 Then
            'frm1.FillDataTableToReport(dt)

            frm1.FillDataSetToReport(DSRpt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub
    Private Sub PrintReportWHT(ByVal batchno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptWHT.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataWHT(batchno)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub
    Private Sub PrintReportCertificate(ByVal batchno As String)

        Dim dt As DataTable = New DataTable()

        dt = GetDataCertificate(batchno)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim clsExportPDF As New clsCrystalToPDFConverter
            Dim path As String
            path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "WHTCER_PAHT")

            clsExportPDF.SetCrystalReportFilePath(sReportPath & "WHTTaxCertificate.rpt")
            clsExportPDF.SetPdfDestinationFilePath(path & "RptCertification_" & batchno & ".pdf")

            clsExportPDF.ExportReportCetificate(dt)

        End If

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()

        'PrintReportRegister("GP2014112801")
        'PrintReportWHT("GP2014112801")
        'PrintReportCertificate("GP2014121601")
        'FrmHashReport.Show()

    End Sub
    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click
        If cboBatchNo.Text = "" Then
            MsgBox("Not found data!")
            Exit Sub
        End If

        Try
            timework = 1
            timework = timework * 100
            Dim progress As New frmProgress(Me.BackgroundWorker1)
            progress.ShowDialog()

        Catch ex As Exception
            StopWorker()
            MsgBox("Process Error!")
        End Try
    End Sub

    Private Function MaskPanData(dtHead As DataTable) As DataTable
        Try
            Using clsREFID As New UtilityClassLibrary.clsREFIDEnquiry()
                clsREFID.OpenConnecttion()
                Dim dtRefID As DataTable
                For Each dr As DataRow In dtHead.Rows
                    If (dr.Item("PAYG_PAY_GROUPNAME").ToString().Trim().ToUpper() = "CREDIT CARD") Then
                        If (Not dr.IsNull("CHQNO")) Then
                            If (dr("CHQNO").ToString().Length >= 16) Then
                                dtRefID = Nothing
                                dtRefID = clsREFID.GetMaskingPan(dr("CHQNO").ToString())
                                If (dtRefID Is Nothing) Then
                                    dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                                Else
                                    If (dtRefID.Rows.Count > 0) Then
                                        dr("CHQNO") = dtRefID.Rows(0)("Mask").ToString()
                                    Else
                                        dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next
                clsREFID.CloseConnection()
            End Using
        Catch ex As Exception
            'MsgBox(AcceptButton.DialogResult, Global.Microsoft.VisualBasic.MsgBoxStyle.Critical, "Error !!!")
            'MessageBox.Show(ex.Message, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Throw ex
            For Each dr As DataRow In dtHead.Rows
                If (dr.Item("PAYG_PAY_GROUPNAME").ToString().Trim().ToUpper() = "CREDIT CARD") Then
                    dr("CHQNO") = MaskingPan(dr("CHQNO").ToString())
                End If
            Next
        End Try

        Return dtHead
    End Function

    Private Function MaskingPan(value As String) As String
        Try
            Return value.ToString().Substring(0, 6) & "XXXXXX" & value.Substring(12, 4)
        Catch ex As Exception
            Return value
        End Try
    End Function

    '------------------------------------------
    Function InsertToTempWHT_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXCR_CREATEDATE, ")
        sb.Append("TAXCR_CORE_SYSTEM, ")
        sb.Append("TAXCR_TRANSREF, ")
        sb.Append("TAXCR_GPTREF_SEQNO, ")
        sb.Append("TAXCR_LINENO, ")
        sb.Append("TAXCR_TAXID, ")
        sb.Append("TAXCR_IDCARD, ")
        sb.Append("TAXCR_AP_TTL, ")
        sb.Append("TAXCR_AP_FNAME, ")
        sb.Append("TAXCR_AP_LNAME, ")
        sb.Append("TAXCR_ADDRESS, ")
        sb.Append("TAXCR_AMPENM, ")
        sb.Append("TAXCR_PROVNM, ")
        sb.Append("TAXCR_AGZIP, ")
        sb.Append("TAXCR_TAXTYPE, ")
        sb.Append("TAXCR_TAXITEM, ")
        sb.Append("TAXCR_TAXDATE, ")
        sb.Append("TAXCR_BASE_AMT, ")
        sb.Append("TAXCR_TAX_AMT, ")
        sb.Append("TAXCR_PAYEE, ")
        sb.Append("TAXCR_TAX_RATE, ")
        sb.Append("TAXCR_DESC, ")
        sb.Append("TAXCR_GL_ACCOUNT, ")

        '-- sb.Append("'COMPLETE', ")
        sb.Append("TAXCR_FLAG_VALIDATE, ")

        sb.Append("TAXCR_REJECT_TYPE, ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append(" FROM GPS_WHT_CREATION ")
        '-- sb.Append("       INNER JOIN GPS_TRANSREF_REL  ")
        '-- sb.Append("         ON GPS_WHT_CREATION.TAXCR_CREATEDATE = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        '-- sb.Append("        AND GPS_WHT_CREATION.TAXCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        '-- sb.Append("        AND GPS_WHT_CREATION.TAXCR_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" WHERE TAXCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("   /*AND TAXCR_FLAG_BATCH='N'*/ AND TAXCR_APPROVEDDATE < '" & systemdate & "' ")
        sb.Append("   AND taxcr_transref in ('ACC20210222', 'ACC20210223') ")
        '-- sb.Append("   AND GPS_TRANSREF_REL.TREF_PAYCRETYP_ID NOT IN ( '003', '006' ) ")
        sb.Append("   AND TAXCR_FLAG_VALIDATE = 'COMPLETE' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertWHTComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_COMPLETE( ")
        sb.Append("TAXCM_BATCHDATE,")
        sb.Append("TAXCM_BATCH_NO,")
        sb.Append("TAXCM_CREATEDATE,")
        sb.Append("TAXCM_CORE_SYSTEM,")
        sb.Append("TAXCM_TRANSREF,")
        sb.Append("TAXCM_GPTREF_SEQNO,")
        sb.Append("TAXCM_LINENO,")
        sb.Append("TAXCM_TAXID,")
        sb.Append("TAXCM_IDCARD,")
        sb.Append("TAXCM_AP_TTL,")
        sb.Append("TAXCM_AP_FNAME,")
        sb.Append("TAXCM_AP_LNAME,")
        sb.Append("TAXCM_ADDRESS,")
        sb.Append("TAXCM_AMPENM,")
        sb.Append("TAXCM_PROVNM,")
        sb.Append("TAXCM_AGZIP,")
        sb.Append("TAXCM_TAXTYPE,")
        sb.Append("TAXCM_TAXITEM,")
        sb.Append("TAXCM_TAXDATE,")
        sb.Append("TAXCM_BASE_AMT,")
        sb.Append("TAXCM_TAX_AMT,")
        sb.Append("TAXCM_PAYEE,")
        sb.Append("TAXCM_TAX_RATE,")
        sb.Append("TAXCM_DESC,")
        sb.Append("TAXCM_GL_ACCOUNT,")
        sb.Append("TAXCM_BATCHTYPE,")
        sb.Append("TAXCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='COMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
End Class