﻿Imports System.Text
Imports UtilityClassLibrary
Imports System.Globalization

Public Class FrmAgingReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Function GetDataGL() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT  ")
        sb.Append("            Case SUBSTR(GP.GP_TRANSREF, 1,3)")
        sb.Append("         WHEN 'ACC' THEN 'Accounting'")
        sb.Append("         WHEN 'BRN' THEN 'Accounting'")
        sb.Append("         WHEN 'GRO' THEN 'Group Operation Support'")
        sb.Append("         WHEN 'GRO' THEN 'Group Operation Support'")
        sb.Append("         WHEN 'HR' THEN 'Human Resources'")
        sb.Append("         WHEN 'HR' THEN 'New Business'")
        sb.Append("         WHEN 'BBB' THEN 'POS'")
        sb.Append("         WHEN 'BBI' THEN 'POS'")
        sb.Append("         WHEN 'BCB' THEN 'POS'")
        sb.Append("         WHEN 'BCI' THEN 'POS'")
        sb.Append("         WHEN 'BMB' THEN 'POS'")
        sb.Append("         WHEN 'BMI' THEN 'POS'")
        sb.Append("         WHEN 'DMP' THEN 'Premuim & Billing'")
        sb.Append("         WHEN 'LNB' THEN 'POS'")
        sb.Append("         WHEN 'LNI' THEN 'POS'")
        sb.Append("         WHEN 'LOA' THEN 'POS'")
        sb.Append("         WHEN 'POS' THEN 'POS'")
        sb.Append("         WHEN 'RIB' THEN 'POS'")
        sb.Append("         WHEN 'RII' THEN 'POS'")
        sb.Append("         WHEN 'SRB' THEN 'POS'")
        sb.Append("         WHEN 'SRI' THEN 'POS'")
        sb.Append("         WHEN 'SUR' THEN 'POS'")
        sb.Append("         WHEN 'TLM' THEN 'TLM'")
        sb.Append("         WHEN 'PRB' THEN 'Premuim & Billing'")
        sb.Append("         WHEN 'CLH' THEN 'Claim'")
        sb.Append("         WHEN 'CLM' THEN 'Claim'")
        sb.Append("         WHEN 'CGY' THEN 'Claim'")
        sb.Append("         WHEN 'NBU' THEN 'New Business'")
        sb.Append("         ELSE DP.DTS_BUSINESS")
        sb.Append("       END DEPARTMENT_NAME")
        sb.Append("     , CASE GP.GP_CORE_SYSTEM ")
        sb.Append("          WHEN 'PP' THEN SUBSTR(GP.GP_TRANSREF, 4, 3) ")
        sb.Append("          WHEN 'TLM' THEN 'TALIS' ")
        sb.Append("          ELSE GP.GP_TRANSREF ")
        sb.Append("       END PREFIX, SUBSTR(GP.GP_PAIDDATE,7,2) || '/' || SUBSTR(GP.GP_PAIDDATE,5,2) || '/' || SUBSTR(GP.GP_PAIDDATE,1,4) GP_PAIDDATE, GL.GL_VCH_NO, GP.GP_POLNO, CASE NVL(GP.GP_PAYEE_NAME, '-') WHEN '-' THEN NVL(GP.GP_PAYEE_BNKACCNME, '-') ELSE NVL(GP.GP_PAYEE_NAME, '-') END GP_PAYEE_NAME")
        sb.Append("     , CASE GP.GP_PAYMTH WHEN 'M' THEN NVL(GP.GP_PAYEE_BNKACCNO,'-') ELSE NVL(GP.GP_CHQNO, '-') END CHQDRF_ACC, GP.GP_PAYDESC")
        sb.Append("     , CASE WHEN GP.AGING_DAY <= 181 THEN GP.GP_AMOUNT ELSE 0 END AGE_181")
        sb.Append("     , CASE WHEN GP.AGING_DAY BETWEEN 182 AND (365*2) THEN GP.GP_AMOUNT ELSE 0 END AGE_2Y")
        sb.Append("     , CASE WHEN GP.AGING_DAY BETWEEN (365*2)+1 AND (365*5) THEN GP.GP_AMOUNT ELSE 0 END AGE_5Y")
        sb.Append("     , CASE WHEN GP.AGING_DAY BETWEEN (365*5)+1 AND (365*10) THEN GP.GP_AMOUNT ELSE 0 END AGE_10Y")
        sb.Append("     , CASE WHEN GP.AGING_DAY >= (365*10)+1 THEN GP.GP_AMOUNT ELSE 0 END AGE_10YM")
        sb.Append("     , GP.GP_PAYMTH || GP.GP_SUB_PAYMTH PAYMENT_TYPE")
        sb.Append("     , CASE WHEN  GP.GP_PAIDDATE <= '20160624' THEN CASE GP.GP_PAYMTH || GP.GP_SUB_PAYMTH WHEN 'CC' THEN 'SCB M Cheque' WHEN 'MM' THEN CASE GP.GP_BNKCODE_NO WHEN '014' THEN 'Direct Credit' ELSE PT.PAYT_PAYTYPE END ELSE PT.PAYT_PAYTYPE END ELSE PT.PAYT_PAYTYPE END PAYMENT_NAME")
        sb.Append("  FROM (SELECT T.*, CASE T.GP_CORE_SYSTEM WHEN 'PP' THEN SUBSTR(T.GP_DATASOURCE_NME, 4, 3) WHEN 'TLM' THEN 'TLM' ELSE T.GP_DATASOURCE_NME END DATESOURCE_CDE")
        sb.Append("            , (TRUNC(SYSDATE)-TO_DATE(GP_PAIDDATE, 'YYYYMMDD')+1) AGING_DAY FROM GENERATEPAYMENT.GPS_PAYMENT T) GP")
        sb.Append("       LEFT JOIN (SELECT F.TREF_CREATEDATE, F.TREF_CORE_SYSTEM, F.TREF_TRANSREF, F.TREF_DEP_KEYIN FROM GENERATEPAYMENT.GPS_TRANSREF_REL F GROUP BY F.TREF_CREATEDATE, F.TREF_CORE_SYSTEM, F.TREF_TRANSREF, F.TREF_DEP_KEYIN) TR")
        sb.Append("         ON GP.GP_CREATEDATE = TR.TREF_CREATEDATE")
        sb.Append("        AND GP.GP_CORE_SYSTEM = TR.TREF_CORE_SYSTEM")
        sb.Append("        AND GP.GP_TRANSREF = TR.TREF_TRANSREF")
        sb.Append("       LEFT JOIN (SELECT * FROM GENERATEPAYMENT.GPS_TL_PAYTYPE) PT")
        sb.Append("         ON GP.GP_PAYMTH = PT.PAYT_PAYMTH")
        sb.Append("        AND GP.GP_SUB_PAYMTH = PT.PAYT_SUB_PAYMTH")
        sb.Append("       LEFT JOIN (SELECT DISTINCT GL_TRANSREF, LISTAGG(GL_VCH_NO, ', ') WITHIN GROUP (ORDER BY GL_VCH_NO) GL_VCH_NO FROM (SELECT DISTINCT GL_TRANSREF, GL_VCH_NO FROM GENERATEPAYMENT.GLM_GL_DAILY GL1) GROUP BY GL_TRANSREF) GL")
        sb.Append("         ON GP.GP_TRANSREF = GL.GL_TRANSREF")
        sb.Append("       LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE, DTS_DEP_KEYIN, DTS_BUSINESS FROM GPS_TL_DATASOURCE GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE, DTS_DEP_KEYIN, DTS_BUSINESS) DP")
        sb.Append("         ON GP.GP_CORE_SYSTEM = DP.DTS_CORE_SYSTEM")
        sb.Append("        AND TRIM(GP.DATESOURCE_CDE) = TRIM(DP.DTS_DTSOURCE)")
        sb.Append("        AND TR.TREF_DEP_KEYIN = DP.DTS_DEP_KEYIN")
        sb.Append("       INNER JOIN (SELECT * FROM GENERATEPAYMENT.GPS_TL_PAYTYPE) PT")
        sb.Append("         ON GP.GP_PAYMTH = PT.PAYT_PAYMTH")
        sb.Append("        AND GP.GP_SUB_PAYMTH = PT.PAYT_SUB_PAYMTH")
        sb.Append("        WHERE(1 = 1)")
        sb.Append("   AND GP.GP_LASTUPD_STS = 'O'")
        '--sb.Append("   AND GP.GP_PAIDDATE between '" & DateTimePicker1.Value.ToString("yyyyMMdd", New CultureInfo("en-GB")) & "' and '" & DateTimePicker2.Value.ToString("yyyyMMdd", New CultureInfo("en-GB")) & "'")
        sb.Append("   AND GP.GP_PAIDDATE <= '" & DateTimePicker1.Value.ToString("yyyyMMdd", New CultureInfo("en-GB")) & "'") '-- and '" & DateTimePicker2.Value.ToString("yyyyMMdd", New CultureInfo("en-GB")) & "'")
        sb.Append(" ORDER BY DEPARTMENT_NAME, GP.GP_PAIDDATE")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub PrintReport1()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        'frm1.CrDoc.Close()
        'frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            frm1.CrDoc.Close()
            frm1.CrDoc.Load(sReportPath & "RptAgingExpiredPayment.rpt")

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            Dim discreteFromDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramFromDate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteToDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramToDate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteTransDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramTransDate As New CrystalDecisions.Shared.ParameterField()

            paramFromDate.ParameterFieldName = "pFromDate"
            discreteFromDate.Value = DateTimePicker1.Value.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramFromDate.CurrentValues.Add(discreteFromDate)
            paramFields.Add(paramFromDate)

            paramToDate.ParameterFieldName = "pToDate"
            discreteToDate.Value = DateTimePicker2.Value.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramToDate.CurrentValues.Add(discreteToDate)
            paramFields.Add(paramToDate)

            paramTransDate.ParameterFieldName = "pTransDate"
            discreteTransDate.Value = Now.Date.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramTransDate.CurrentValues.Add(discreteTransDate)
            paramFields.Add(paramTransDate)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub PrintReport2()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        'frm1.CrDoc.Close()
        'frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            frm1.CrDoc.Close()
            frm1.CrDoc.Load(sReportPath & "RptAgingExpiredPayment_Sum.rpt")

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            Dim discreteFromDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramFromDate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteToDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramToDate As New CrystalDecisions.Shared.ParameterField()
            Dim discreteTransDate As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramTransDate As New CrystalDecisions.Shared.ParameterField()

            paramFromDate.ParameterFieldName = "pFromDate"
            discreteFromDate.Value = DateTimePicker1.Value.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramFromDate.CurrentValues.Add(discreteFromDate)
            paramFields.Add(paramFromDate)

            paramToDate.ParameterFieldName = "pToDate"
            discreteToDate.Value = DateTimePicker2.Value.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramToDate.CurrentValues.Add(discreteToDate)
            paramFields.Add(paramToDate)

            paramTransDate.ParameterFieldName = "pTransDate"
            discreteTransDate.Value = Now.Date.ToString("dd/MM/yyyy", New CultureInfo("en-GB"))
            paramTransDate.CurrentValues.Add(discreteTransDate)
            paramFields.Add(paramTransDate)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub CmdOk_Click(sender As System.Object, e As System.EventArgs) Handles CmdOk.Click

        Me.Cursor = Cursors.WaitCursor

        PrintReport1()
        PrintReport2()

        Dim frm As New FrmAgingReport
        frm.TopLevel = False
        frm.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
        frm.Show()

        Me.Cursor = Cursors.Arrow

        Me.Close()

    End Sub

    Private Sub FrmAgingReport_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        DateTimePicker1.Value = Now
        DateTimePicker2.Value = Now
    End Sub

    Private Sub DateTimePicker1_LostFocus(sender As Object, e As System.EventArgs) Handles DateTimePicker1.LostFocus
        If DateTimePicker1.Value > DateTimePicker2.Value Then
            MsgBox("From date must less than or equal to date", MsgBoxStyle.Exclamation, "Warning")
            DateTimePicker1.Value = DateTimePicker2.Value
        End If
    End Sub

    Private Sub DateTimePicker2_LostFocus(sender As Object, e As System.EventArgs) Handles DateTimePicker2.LostFocus
        If DateTimePicker1.Value > DateTimePicker2.Value Then
            MsgBox("To date must greater than or equal to date", MsgBoxStyle.Exclamation, "Warning")
            DateTimePicker2.Value = DateTimePicker1.Value
        End If
    End Sub
End Class