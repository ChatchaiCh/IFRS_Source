<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPaymentCreationProcess
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.txtPurpose = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.cboPayMth = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.lblDept = New System.Windows.Forms.Label()
        Me.txtSection = New System.Windows.Forms.TextBox()
        Me.dtpDueDate = New CustomControls.DatePicker()
        Me.txtAccPeriod = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtJournalHold = New System.Windows.Forms.TextBox()
        Me.cboOverSea = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cboDataSource = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtTransRef = New System.Windows.Forms.TextBox()
        Me.cboJournalType = New System.Windows.Forms.ComboBox()
        Me.txtEntryDate = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cboGroup = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnAddRowGL = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtRCCode = New System.Windows.Forms.TextBox()
        Me.txtCompanyCode = New System.Windows.Forms.TextBox()
        Me.txtActualFlag = New System.Windows.Forms.TextBox()
        Me.txtCurrencyCode = New System.Windows.Forms.TextBox()
        Me.txtCategoryName = New System.Windows.Forms.TextBox()
        Me.txtSourceName = New System.Windows.Forms.TextBox()
        Me.txtBookID = New System.Windows.Forms.TextBox()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.lbltxtTotalLine = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lblTotalLine = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtOutOfBalance = New System.Windows.Forms.TextBox()
        Me.txtAmtCredits = New System.Windows.Forms.TextBox()
        Me.txtAmtDebits = New System.Windows.Forms.TextBox()
        Me.cboEntryType = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgvGL = New System.Windows.Forms.DataGridView()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.chkFlagAllGP = New System.Windows.Forms.CheckBox()
        Me.btnAddRowGP = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.cboEntryTypeGP = New System.Windows.Forms.ComboBox()
        Me.txtAmtCreditGP = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgvGP = New System.Windows.Forms.DataGridView()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btnAddRowTax = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cboEntryTypeTAX = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.dgvTax = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtBaseAmt = New System.Windows.Forms.TextBox()
        Me.txtInputWHTAmt = New System.Windows.Forms.TextBox()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.lblAlert = New System.Windows.Forms.Label()
        Me.btnDelete = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnUpdate = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnPrintGL = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnFind = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClose = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnSave = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClear = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnConvert = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnBrowseGL = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.txtTextURLGL = New GP_StandAlone_App.WaterMarkTextBox()
        Me.btnClearAll = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClearGL = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnGetAPGP = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.txtTextURLGP = New GP_StandAlone_App.WaterMarkTextBox()
        Me.btnClearAllGP = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnLoadFileGP = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClearGP = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnGetAPTax = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.txtTextURLTax = New GP_StandAlone_App.WaterMarkTextBox()
        Me.btnClearAllTax = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnClearTax = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnLoadFileTax = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvGL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgvGP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dgvTax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(314, 16)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "FWD Life Insurance Public Company Limited"
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label4)
        Me.PanelH1.Location = New System.Drawing.Point(12, 21)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(1017, 26)
        Me.PanelH1.TabIndex = 39
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(1017, 26)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "PAYMENT CREATION"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.PanelD1.Controls.Add(Me.txtPurpose)
        Me.PanelD1.Controls.Add(Me.Label33)
        Me.PanelD1.Controls.Add(Me.cboPayMth)
        Me.PanelD1.Controls.Add(Me.lblStatus)
        Me.PanelD1.Controls.Add(Me.lblDept)
        Me.PanelD1.Controls.Add(Me.txtSection)
        Me.PanelD1.Controls.Add(Me.dtpDueDate)
        Me.PanelD1.Controls.Add(Me.txtAccPeriod)
        Me.PanelD1.Controls.Add(Me.Label24)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.txtJournalHold)
        Me.PanelD1.Controls.Add(Me.cboOverSea)
        Me.PanelD1.Controls.Add(Me.Label13)
        Me.PanelD1.Controls.Add(Me.Label12)
        Me.PanelD1.Controls.Add(Me.cboDataSource)
        Me.PanelD1.Controls.Add(Me.Label11)
        Me.PanelD1.Controls.Add(Me.Label10)
        Me.PanelD1.Controls.Add(Me.Label9)
        Me.PanelD1.Controls.Add(Me.Label8)
        Me.PanelD1.Controls.Add(Me.txtTransRef)
        Me.PanelD1.Controls.Add(Me.cboJournalType)
        Me.PanelD1.Controls.Add(Me.txtEntryDate)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.cboGroup)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Location = New System.Drawing.Point(11, 54)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(1018, 152)
        Me.PanelD1.TabIndex = 38
        '
        'txtPurpose
        '
        Me.txtPurpose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPurpose.Location = New System.Drawing.Point(481, 123)
        Me.txtPurpose.MaxLength = 100
        Me.txtPurpose.Name = "txtPurpose"
        Me.txtPurpose.Size = New System.Drawing.Size(371, 20)
        Me.txtPurpose.TabIndex = 96
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(352, 127)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(112, 13)
        Me.Label33.TabIndex = 95
        Me.Label33.Text = "Purpose of Purchase :"
        '
        'cboPayMth
        '
        Me.cboPayMth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPayMth.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboPayMth.FormattingEnabled = True
        Me.cboPayMth.Location = New System.Drawing.Point(144, 51)
        Me.cboPayMth.Name = "cboPayMth"
        Me.cboPayMth.Size = New System.Drawing.Size(316, 21)
        Me.cboPayMth.TabIndex = 94
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(858, 74)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(47, 13)
        Me.lblStatus.TabIndex = 93
        Me.lblStatus.Text = "lblStatus"
        Me.lblStatus.Visible = False
        '
        'lblDept
        '
        Me.lblDept.AutoSize = True
        Me.lblDept.Location = New System.Drawing.Point(858, 35)
        Me.lblDept.Name = "lblDept"
        Me.lblDept.Size = New System.Drawing.Size(40, 13)
        Me.lblDept.TabIndex = 91
        Me.lblDept.Text = "lblDept"
        Me.lblDept.Visible = False
        '
        'txtSection
        '
        Me.txtSection.Enabled = False
        Me.txtSection.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtSection.Location = New System.Drawing.Point(607, 31)
        Me.txtSection.MaxLength = 10
        Me.txtSection.Name = "txtSection"
        Me.txtSection.Size = New System.Drawing.Size(245, 20)
        Me.txtSection.TabIndex = 90
        '
        'dtpDueDate
        '
        Me.dtpDueDate.Culture = New System.Globalization.CultureInfo("en-GB")
        Me.dtpDueDate.Location = New System.Drawing.Point(144, 74)
        Me.dtpDueDate.Name = "dtpDueDate"
        Me.dtpDueDate.PickerDayHeaderFont = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.dtpDueDate.PickerHeaderFont = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.dtpDueDate.Size = New System.Drawing.Size(131, 22)
        Me.dtpDueDate.TabIndex = 4
        '
        'txtAccPeriod
        '
        Me.txtAccPeriod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAccPeriod.Location = New System.Drawing.Point(607, 76)
        Me.txtAccPeriod.MaxLength = 7
        Me.txtAccPeriod.Name = "txtAccPeriod"
        Me.txtAccPeriod.Size = New System.Drawing.Size(79, 20)
        Me.txtAccPeriod.TabIndex = 10
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(12, 125)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(72, 13)
        Me.Label24.TabIndex = 65
        Me.Label24.Text = "Journal Hold :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(12, 102)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 13)
        Me.Label7.TabIndex = 64
        Me.Label7.Text = "��¡�÷�����Թ�͡ :"
        '
        'txtJournalHold
        '
        Me.txtJournalHold.Enabled = False
        Me.txtJournalHold.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtJournalHold.Location = New System.Drawing.Point(144, 123)
        Me.txtJournalHold.MaxLength = 10
        Me.txtJournalHold.Name = "txtJournalHold"
        Me.txtJournalHold.Size = New System.Drawing.Size(108, 20)
        Me.txtJournalHold.TabIndex = 6
        '
        'cboOverSea
        '
        Me.cboOverSea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOverSea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboOverSea.FormattingEnabled = True
        Me.cboOverSea.Location = New System.Drawing.Point(144, 99)
        Me.cboOverSea.Name = "cboOverSea"
        Me.cboOverSea.Size = New System.Drawing.Size(316, 21)
        Me.cboOverSea.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(11, 53)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(81, 13)
        Me.Label13.TabIndex = 61
        Me.Label13.Text = "Payment Type :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(477, 8)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(73, 13)
        Me.Label12.TabIndex = 60
        Me.Label12.Text = "Data Source :"
        '
        'cboDataSource
        '
        Me.cboDataSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDataSource.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboDataSource.FormattingEnabled = True
        Me.cboDataSource.Location = New System.Drawing.Point(607, 8)
        Me.cboDataSource.Name = "cboDataSource"
        Me.cboDataSource.Size = New System.Drawing.Size(245, 21)
        Me.cboDataSource.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(12, 79)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 13)
        Me.Label11.TabIndex = 57
        Me.Label11.Text = "Due Date :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(692, 81)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(160, 13)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "Default system date (MM/YYYY)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(477, 79)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 13)
        Me.Label9.TabIndex = 54
        Me.Label9.Text = "Accounting Period :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(478, 54)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(122, 13)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Transaction Reference :"
        '
        'txtTransRef
        '
        Me.txtTransRef.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtTransRef.Location = New System.Drawing.Point(607, 54)
        Me.txtTransRef.MaxLength = 15
        Me.txtTransRef.Name = "txtTransRef"
        Me.txtTransRef.Size = New System.Drawing.Size(245, 20)
        Me.txtTransRef.TabIndex = 9
        '
        'cboJournalType
        '
        Me.cboJournalType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboJournalType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboJournalType.FormattingEnabled = True
        Me.cboJournalType.Location = New System.Drawing.Point(144, 5)
        Me.cboJournalType.Name = "cboJournalType"
        Me.cboJournalType.Size = New System.Drawing.Size(316, 21)
        Me.cboJournalType.TabIndex = 1
        '
        'txtEntryDate
        '
        Me.txtEntryDate.Enabled = False
        Me.txtEntryDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtEntryDate.Location = New System.Drawing.Point(607, 99)
        Me.txtEntryDate.Name = "txtEntryDate"
        Me.txtEntryDate.Size = New System.Drawing.Size(81, 20)
        Me.txtEntryDate.TabIndex = 48
        Me.txtEntryDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(478, 106)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 47
        Me.Label6.Text = "Entry Date :"
        '
        'cboGroup
        '
        Me.cboGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboGroup.FormattingEnabled = True
        Me.cboGroup.Location = New System.Drawing.Point(144, 28)
        Me.cboGroup.Name = "cboGroup"
        Me.cboGroup.Size = New System.Drawing.Size(316, 21)
        Me.cboGroup.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(11, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "������ѹ�֡�������������к� :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(11, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Journal Type :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(478, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Section :"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnAddRowGL)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.Label28)
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.Label25)
        Me.TabPage1.Controls.Add(Me.txtRCCode)
        Me.TabPage1.Controls.Add(Me.txtCompanyCode)
        Me.TabPage1.Controls.Add(Me.txtActualFlag)
        Me.TabPage1.Controls.Add(Me.txtCurrencyCode)
        Me.TabPage1.Controls.Add(Me.txtCategoryName)
        Me.TabPage1.Controls.Add(Me.txtSourceName)
        Me.TabPage1.Controls.Add(Me.txtBookID)
        Me.TabPage1.Controls.Add(Me.txtStatus)
        Me.TabPage1.Controls.Add(Me.lbltxtTotalLine)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.lblTotalLine)
        Me.TabPage1.Controls.Add(Me.btnConvert)
        Me.TabPage1.Controls.Add(Me.btnBrowseGL)
        Me.TabPage1.Controls.Add(Me.txtTextURLGL)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.txtOutOfBalance)
        Me.TabPage1.Controls.Add(Me.txtAmtCredits)
        Me.TabPage1.Controls.Add(Me.txtAmtDebits)
        Me.TabPage1.Controls.Add(Me.cboEntryType)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.btnClearAll)
        Me.TabPage1.Controls.Add(Me.btnClearGL)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1010, 359)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "�ѹ�֡������ GL"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnAddRowGL
        '
        Me.btnAddRowGL.Location = New System.Drawing.Point(824, 130)
        Me.btnAddRowGL.Name = "btnAddRowGL"
        Me.btnAddRowGL.Size = New System.Drawing.Size(32, 23)
        Me.btnAddRowGL.TabIndex = 101
        Me.btnAddRowGL.Text = "+"
        Me.btnAddRowGL.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(315, 109)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(56, 13)
        Me.Label29.TabIndex = 100
        Me.Label29.Text = "RC Code :"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(315, 85)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(85, 13)
        Me.Label30.TabIndex = 99
        Me.Label30.Text = "Company Code :"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(315, 61)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(66, 13)
        Me.Label31.TabIndex = 98
        Me.Label31.Text = "Actual Flag :"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(315, 38)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(83, 13)
        Me.Label32.TabIndex = 97
        Me.Label32.Text = "Currency Code :"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(17, 113)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(86, 13)
        Me.Label28.TabIndex = 96
        Me.Label28.Text = "Category Name :"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(17, 89)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(78, 13)
        Me.Label27.TabIndex = 95
        Me.Label27.Text = "Source Name :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(17, 65)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(52, 13)
        Me.Label26.TabIndex = 94
        Me.Label26.Text = "Book ID :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(17, 42)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(43, 13)
        Me.Label25.TabIndex = 93
        Me.Label25.Text = "Status :"
        '
        'txtRCCode
        '
        Me.txtRCCode.Enabled = False
        Me.txtRCCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtRCCode.Location = New System.Drawing.Point(405, 103)
        Me.txtRCCode.MaxLength = 10
        Me.txtRCCode.Name = "txtRCCode"
        Me.txtRCCode.Size = New System.Drawing.Size(108, 20)
        Me.txtRCCode.TabIndex = 92
        '
        'txtCompanyCode
        '
        Me.txtCompanyCode.Enabled = False
        Me.txtCompanyCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCompanyCode.Location = New System.Drawing.Point(405, 79)
        Me.txtCompanyCode.MaxLength = 10
        Me.txtCompanyCode.Name = "txtCompanyCode"
        Me.txtCompanyCode.Size = New System.Drawing.Size(108, 20)
        Me.txtCompanyCode.TabIndex = 91
        '
        'txtActualFlag
        '
        Me.txtActualFlag.Enabled = False
        Me.txtActualFlag.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtActualFlag.Location = New System.Drawing.Point(405, 55)
        Me.txtActualFlag.MaxLength = 10
        Me.txtActualFlag.Name = "txtActualFlag"
        Me.txtActualFlag.Size = New System.Drawing.Size(108, 20)
        Me.txtActualFlag.TabIndex = 90
        '
        'txtCurrencyCode
        '
        Me.txtCurrencyCode.Enabled = False
        Me.txtCurrencyCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCurrencyCode.Location = New System.Drawing.Point(405, 32)
        Me.txtCurrencyCode.MaxLength = 10
        Me.txtCurrencyCode.Name = "txtCurrencyCode"
        Me.txtCurrencyCode.Size = New System.Drawing.Size(108, 20)
        Me.txtCurrencyCode.TabIndex = 89
        '
        'txtCategoryName
        '
        Me.txtCategoryName.Enabled = False
        Me.txtCategoryName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCategoryName.Location = New System.Drawing.Point(103, 106)
        Me.txtCategoryName.MaxLength = 10
        Me.txtCategoryName.Name = "txtCategoryName"
        Me.txtCategoryName.Size = New System.Drawing.Size(108, 20)
        Me.txtCategoryName.TabIndex = 88
        '
        'txtSourceName
        '
        Me.txtSourceName.Enabled = False
        Me.txtSourceName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtSourceName.Location = New System.Drawing.Point(103, 82)
        Me.txtSourceName.MaxLength = 10
        Me.txtSourceName.Name = "txtSourceName"
        Me.txtSourceName.Size = New System.Drawing.Size(108, 20)
        Me.txtSourceName.TabIndex = 87
        '
        'txtBookID
        '
        Me.txtBookID.Enabled = False
        Me.txtBookID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBookID.Location = New System.Drawing.Point(103, 58)
        Me.txtBookID.MaxLength = 10
        Me.txtBookID.Name = "txtBookID"
        Me.txtBookID.Size = New System.Drawing.Size(108, 20)
        Me.txtBookID.TabIndex = 86
        '
        'txtStatus
        '
        Me.txtStatus.Enabled = False
        Me.txtStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtStatus.Location = New System.Drawing.Point(103, 35)
        Me.txtStatus.MaxLength = 10
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.Size = New System.Drawing.Size(108, 20)
        Me.txtStatus.TabIndex = 66
        '
        'lbltxtTotalLine
        '
        Me.lbltxtTotalLine.AutoSize = True
        Me.lbltxtTotalLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lbltxtTotalLine.Location = New System.Drawing.Point(97, 140)
        Me.lbltxtTotalLine.Name = "lbltxtTotalLine"
        Me.lbltxtTotalLine.Size = New System.Drawing.Size(14, 13)
        Me.lbltxtTotalLine.TabIndex = 85
        Me.lbltxtTotalLine.Text = "0"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(137, 140)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(53, 13)
        Me.Label23.TabIndex = 84
        Me.Label23.Text = "Reccords"
        '
        'lblTotalLine
        '
        Me.lblTotalLine.AutoSize = True
        Me.lblTotalLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblTotalLine.ForeColor = System.Drawing.Color.Black
        Me.lblTotalLine.Location = New System.Drawing.Point(17, 140)
        Me.lblTotalLine.Name = "lblTotalLine"
        Me.lblTotalLine.Size = New System.Drawing.Size(60, 13)
        Me.lblTotalLine.TabIndex = 82
        Me.lblTotalLine.Text = "Total Line :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(17, 17)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(64, 13)
        Me.Label17.TabIndex = 73
        Me.Label17.Text = "Entry Type :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(530, 88)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(84, 13)
        Me.Label16.TabIndex = 77
        Me.Label16.Text = "Out of Balance :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(530, 62)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 13)
        Me.Label15.TabIndex = 76
        Me.Label15.Text = "Amt Credits :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(530, 38)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 13)
        Me.Label14.TabIndex = 70
        Me.Label14.Text = "Amt Debits :"
        '
        'txtOutOfBalance
        '
        Me.txtOutOfBalance.BackColor = System.Drawing.Color.White
        Me.txtOutOfBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtOutOfBalance.ForeColor = System.Drawing.Color.Black
        Me.txtOutOfBalance.Location = New System.Drawing.Point(614, 82)
        Me.txtOutOfBalance.Name = "txtOutOfBalance"
        Me.txtOutOfBalance.ReadOnly = True
        Me.txtOutOfBalance.Size = New System.Drawing.Size(144, 20)
        Me.txtOutOfBalance.TabIndex = 75
        Me.txtOutOfBalance.Text = "0.00"
        Me.txtOutOfBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAmtCredits
        '
        Me.txtAmtCredits.BackColor = System.Drawing.Color.White
        Me.txtAmtCredits.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAmtCredits.ForeColor = System.Drawing.Color.Black
        Me.txtAmtCredits.Location = New System.Drawing.Point(614, 56)
        Me.txtAmtCredits.Name = "txtAmtCredits"
        Me.txtAmtCredits.ReadOnly = True
        Me.txtAmtCredits.Size = New System.Drawing.Size(144, 20)
        Me.txtAmtCredits.TabIndex = 74
        Me.txtAmtCredits.Text = "0.00"
        Me.txtAmtCredits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAmtDebits
        '
        Me.txtAmtDebits.BackColor = System.Drawing.Color.White
        Me.txtAmtDebits.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAmtDebits.ForeColor = System.Drawing.Color.Black
        Me.txtAmtDebits.Location = New System.Drawing.Point(614, 32)
        Me.txtAmtDebits.Name = "txtAmtDebits"
        Me.txtAmtDebits.ReadOnly = True
        Me.txtAmtDebits.Size = New System.Drawing.Size(144, 20)
        Me.txtAmtDebits.TabIndex = 71
        Me.txtAmtDebits.Text = "0.00"
        Me.txtAmtDebits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cboEntryType
        '
        Me.cboEntryType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEntryType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboEntryType.FormattingEnabled = True
        Me.cboEntryType.ItemHeight = 13
        Me.cboEntryType.Location = New System.Drawing.Point(103, 9)
        Me.cboEntryType.Name = "cboEntryType"
        Me.cboEntryType.Size = New System.Drawing.Size(184, 21)
        Me.cboEntryType.TabIndex = 11
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.Panel1.Controls.Add(Me.dgvGL)
        Me.Panel1.Location = New System.Drawing.Point(12, 155)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(847, 161)
        Me.Panel1.TabIndex = 0
        '
        'dgvGL
        '
        Me.dgvGL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvGL.Location = New System.Drawing.Point(3, 5)
        Me.dgvGL.Name = "dgvGL"
        Me.dgvGL.Size = New System.Drawing.Size(841, 153)
        Me.dgvGL.TabIndex = 75
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(11, 213)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1018, 385)
        Me.TabControl1.TabIndex = 37
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btnGetAPGP)
        Me.TabPage2.Controls.Add(Me.chkFlagAllGP)
        Me.TabPage2.Controls.Add(Me.btnAddRowGP)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.cboEntryTypeGP)
        Me.TabPage2.Controls.Add(Me.txtAmtCreditGP)
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.txtTextURLGP)
        Me.TabPage2.Controls.Add(Me.btnClearAllGP)
        Me.TabPage2.Controls.Add(Me.btnLoadFileGP)
        Me.TabPage2.Controls.Add(Me.btnClearGP)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1010, 359)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "�ѹ�֡������ GP"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'chkFlagAllGP
        '
        Me.chkFlagAllGP.AutoSize = True
        Me.chkFlagAllGP.Location = New System.Drawing.Point(699, 321)
        Me.chkFlagAllGP.Name = "chkFlagAllGP"
        Me.chkFlagAllGP.Size = New System.Drawing.Size(160, 17)
        Me.chkFlagAllGP.TabIndex = 103
        Me.chkFlagAllGP.Text = "Flag �Դ�������� (All)"
        Me.chkFlagAllGP.UseVisualStyleBackColor = True
        '
        'btnAddRowGP
        '
        Me.btnAddRowGP.Location = New System.Drawing.Point(827, 13)
        Me.btnAddRowGP.Name = "btnAddRowGP"
        Me.btnAddRowGP.Size = New System.Drawing.Size(32, 23)
        Me.btnAddRowGP.TabIndex = 102
        Me.btnAddRowGP.Text = "+"
        Me.btnAddRowGP.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(8, 14)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(64, 13)
        Me.Label18.TabIndex = 82
        Me.Label18.Text = "Entry Type :"
        '
        'cboEntryTypeGP
        '
        Me.cboEntryTypeGP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEntryTypeGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboEntryTypeGP.FormattingEnabled = True
        Me.cboEntryTypeGP.ItemHeight = 13
        Me.cboEntryTypeGP.Location = New System.Drawing.Point(94, 9)
        Me.cboEntryTypeGP.Name = "cboEntryTypeGP"
        Me.cboEntryTypeGP.Size = New System.Drawing.Size(184, 21)
        Me.cboEntryTypeGP.TabIndex = 81
        '
        'txtAmtCreditGP
        '
        Me.txtAmtCreditGP.BackColor = System.Drawing.Color.White
        Me.txtAmtCreditGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAmtCreditGP.ForeColor = System.Drawing.Color.Black
        Me.txtAmtCreditGP.Location = New System.Drawing.Point(614, 13)
        Me.txtAmtCreditGP.Name = "txtAmtCreditGP"
        Me.txtAmtCreditGP.ReadOnly = True
        Me.txtAmtCreditGP.Size = New System.Drawing.Size(192, 20)
        Me.txtAmtCreditGP.TabIndex = 76
        Me.txtAmtCreditGP.Text = "0.00"
        Me.txtAmtCreditGP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.dgvGP)
        Me.Panel2.Location = New System.Drawing.Point(-3, 39)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(862, 276)
        Me.Panel2.TabIndex = 8
        '
        'dgvGP
        '
        Me.dgvGP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGP.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvGP.Location = New System.Drawing.Point(0, 3)
        Me.dgvGP.Name = "dgvGP"
        Me.dgvGP.Size = New System.Drawing.Size(862, 273)
        Me.dgvGP.TabIndex = 74
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(484, 14)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(93, 13)
        Me.Label22.TabIndex = 73
        Me.Label22.Text = "Total Amt Credits :"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btnGetAPTax)
        Me.TabPage3.Controls.Add(Me.btnAddRowTax)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.cboEntryTypeTAX)
        Me.TabPage3.Controls.Add(Me.Panel3)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.txtBaseAmt)
        Me.TabPage3.Controls.Add(Me.txtInputWHTAmt)
        Me.TabPage3.Controls.Add(Me.txtTextURLTax)
        Me.TabPage3.Controls.Add(Me.btnClearAllTax)
        Me.TabPage3.Controls.Add(Me.btnClearTax)
        Me.TabPage3.Controls.Add(Me.btnLoadFileTax)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1010, 359)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "�ѹ�֡������ TAX"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btnAddRowTax
        '
        Me.btnAddRowTax.Location = New System.Drawing.Point(824, 27)
        Me.btnAddRowTax.Name = "btnAddRowTax"
        Me.btnAddRowTax.Size = New System.Drawing.Size(32, 23)
        Me.btnAddRowTax.TabIndex = 102
        Me.btnAddRowTax.Text = "+"
        Me.btnAddRowTax.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(8, 11)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(64, 13)
        Me.Label19.TabIndex = 84
        Me.Label19.Text = "Entry Type :"
        '
        'cboEntryTypeTAX
        '
        Me.cboEntryTypeTAX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEntryTypeTAX.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboEntryTypeTAX.FormattingEnabled = True
        Me.cboEntryTypeTAX.ItemHeight = 13
        Me.cboEntryTypeTAX.Location = New System.Drawing.Point(94, 6)
        Me.cboEntryTypeTAX.Name = "cboEntryTypeTAX"
        Me.cboEntryTypeTAX.Size = New System.Drawing.Size(184, 21)
        Me.cboEntryTypeTAX.TabIndex = 83
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.dgvTax)
        Me.Panel3.Location = New System.Drawing.Point(-4, 68)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(863, 249)
        Me.Panel3.TabIndex = 0
        '
        'dgvTax
        '
        Me.dgvTax.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTax.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvTax.Location = New System.Drawing.Point(7, 0)
        Me.dgvTax.Name = "dgvTax"
        Me.dgvTax.Size = New System.Drawing.Size(853, 246)
        Me.dgvTax.TabIndex = 75
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(476, 32)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(132, 13)
        Me.Label21.TabIndex = 65
        Me.Label21.Text = "Total Input WHT Amount :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(476, 6)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(103, 13)
        Me.Label20.TabIndex = 64
        Me.Label20.Text = "Total Base Amount :"
        '
        'txtBaseAmt
        '
        Me.txtBaseAmt.BackColor = System.Drawing.Color.White
        Me.txtBaseAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBaseAmt.ForeColor = System.Drawing.Color.Black
        Me.txtBaseAmt.Location = New System.Drawing.Point(614, 3)
        Me.txtBaseAmt.Name = "txtBaseAmt"
        Me.txtBaseAmt.ReadOnly = True
        Me.txtBaseAmt.Size = New System.Drawing.Size(180, 20)
        Me.txtBaseAmt.TabIndex = 51
        Me.txtBaseAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtInputWHTAmt
        '
        Me.txtInputWHTAmt.BackColor = System.Drawing.Color.White
        Me.txtInputWHTAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtInputWHTAmt.ForeColor = System.Drawing.Color.Black
        Me.txtInputWHTAmt.Location = New System.Drawing.Point(614, 29)
        Me.txtInputWHTAmt.Name = "txtInputWHTAmt"
        Me.txtInputWHTAmt.ReadOnly = True
        Me.txtInputWHTAmt.Size = New System.Drawing.Size(180, 20)
        Me.txtInputWHTAmt.TabIndex = 52
        Me.txtInputWHTAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'lblAlert
        '
        Me.lblAlert.AutoSize = True
        Me.lblAlert.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblAlert.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.lblAlert.Location = New System.Drawing.Point(323, 208)
        Me.lblAlert.Name = "lblAlert"
        Me.lblAlert.Size = New System.Drawing.Size(437, 37)
        Me.lblAlert.TabIndex = 102
        Me.lblAlert.Text = "���ѧ�����ż����� ��س����ѡ����..."
        Me.lblAlert.Visible = False
        '
        'btnDelete
        '
        Me.btnDelete.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnDelete.Image = Nothing
        Me.btnDelete.ImageKey = ""
        Me.btnDelete.ImageList = Nothing
        Me.btnDelete.Location = New System.Drawing.Point(489, 604)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnDelete.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnDelete.Size = New System.Drawing.Size(92, 28)
        Me.btnDelete.TabIndex = 53
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnUpdate
        '
        Me.btnUpdate.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnUpdate.Image = Nothing
        Me.btnUpdate.ImageKey = ""
        Me.btnUpdate.ImageList = Nothing
        Me.btnUpdate.Location = New System.Drawing.Point(393, 604)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnUpdate.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnUpdate.Size = New System.Drawing.Size(92, 28)
        Me.btnUpdate.TabIndex = 52
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnPrintGL
        '
        Me.btnPrintGL.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrintGL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnPrintGL.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrintGL.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrintGL.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnPrintGL.ForeColor = System.Drawing.Color.White
        Me.btnPrintGL.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnPrintGL.Image = Nothing
        Me.btnPrintGL.ImageKey = ""
        Me.btnPrintGL.ImageList = Nothing
        Me.btnPrintGL.Location = New System.Drawing.Point(110, 604)
        Me.btnPrintGL.Name = "btnPrintGL"
        Me.btnPrintGL.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrintGL.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrintGL.Size = New System.Drawing.Size(92, 28)
        Me.btnPrintGL.TabIndex = 51
        Me.btnPrintGL.Text = "Print GL"
        Me.btnPrintGL.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrintGL.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnFind
        '
        Me.btnFind.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnFind.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFind.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnFind.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnFind.ForeColor = System.Drawing.Color.White
        Me.btnFind.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnFind.Image = Nothing
        Me.btnFind.ImageKey = ""
        Me.btnFind.ImageList = Nothing
        Me.btnFind.Location = New System.Drawing.Point(297, 604)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnFind.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnFind.Size = New System.Drawing.Size(92, 28)
        Me.btnFind.TabIndex = 50
        Me.btnFind.Text = "Find"
        Me.btnFind.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnFind.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClose
        '
        Me.btnClose.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClose.Image = Nothing
        Me.btnClose.ImageKey = ""
        Me.btnClose.ImageList = Nothing
        Me.btnClose.Location = New System.Drawing.Point(708, 604)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClose.Size = New System.Drawing.Size(92, 28)
        Me.btnClose.TabIndex = 49
        Me.btnClose.Text = "Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnSave
        '
        Me.btnSave.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnSave.Image = Nothing
        Me.btnSave.ImageKey = ""
        Me.btnSave.ImageList = Nothing
        Me.btnSave.Location = New System.Drawing.Point(14, 604)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSave.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnSave.Size = New System.Drawing.Size(92, 28)
        Me.btnSave.TabIndex = 47
        Me.btnSave.Text = "Save"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClear
        '
        Me.btnClear.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnClear.Image = Nothing
        Me.btnClear.ImageKey = ""
        Me.btnClear.ImageList = Nothing
        Me.btnClear.Location = New System.Drawing.Point(587, 604)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 48
        Me.btnClear.Text = "Clear All"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnConvert
        '
        Me.btnConvert.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConvert.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnConvert.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnConvert.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnConvert.ForeColor = System.Drawing.Color.Black
        Me.btnConvert.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnConvert.Image = Nothing
        Me.btnConvert.ImageKey = ""
        Me.btnConvert.ImageList = Nothing
        Me.btnConvert.Location = New System.Drawing.Point(84, 322)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConvert.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnConvert.Size = New System.Drawing.Size(66, 23)
        Me.btnConvert.TabIndex = 80
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnBrowseGL
        '
        Me.btnBrowseGL.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnBrowseGL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnBrowseGL.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnBrowseGL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnBrowseGL.ForeColor = System.Drawing.Color.Black
        Me.btnBrowseGL.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnBrowseGL.Image = Nothing
        Me.btnBrowseGL.ImageKey = ""
        Me.btnBrowseGL.ImageList = Nothing
        Me.btnBrowseGL.Location = New System.Drawing.Point(11, 322)
        Me.btnBrowseGL.Name = "btnBrowseGL"
        Me.btnBrowseGL.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnBrowseGL.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnBrowseGL.Size = New System.Drawing.Size(66, 23)
        Me.btnBrowseGL.TabIndex = 12
        Me.btnBrowseGL.Text = "Load File"
        Me.btnBrowseGL.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'txtTextURLGL
        '
        Me.txtTextURLGL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtTextURLGL.Location = New System.Drawing.Point(293, 9)
        Me.txtTextURLGL.Name = "txtTextURLGL"
        Me.txtTextURLGL.Size = New System.Drawing.Size(220, 20)
        Me.txtTextURLGL.TabIndex = 78
        Me.txtTextURLGL.Visible = False
        Me.txtTextURLGL.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtTextURLGL.WaterMarkText = "Choose File Import"
        '
        'btnClearAll
        '
        Me.btnClearAll.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearAll.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearAll.ForeColor = System.Drawing.Color.Black
        Me.btnClearAll.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearAll.Image = Nothing
        Me.btnClearAll.ImageKey = ""
        Me.btnClearAll.ImageList = Nothing
        Me.btnClearAll.Location = New System.Drawing.Point(237, 322)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAll.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAll.Size = New System.Drawing.Size(75, 23)
        Me.btnClearAll.TabIndex = 69
        Me.btnClearAll.Text = "Clear All"
        Me.btnClearAll.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClearGL
        '
        Me.btnClearGL.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearGL.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearGL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearGL.ForeColor = System.Drawing.Color.Black
        Me.btnClearGL.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearGL.Image = Nothing
        Me.btnClearGL.ImageKey = ""
        Me.btnClearGL.ImageList = Nothing
        Me.btnClearGL.Location = New System.Drawing.Point(156, 322)
        Me.btnClearGL.Name = "btnClearGL"
        Me.btnClearGL.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGL.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGL.Size = New System.Drawing.Size(75, 23)
        Me.btnClearGL.TabIndex = 68
        Me.btnClearGL.Text = "Clear"
        Me.btnClearGL.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnGetAPGP
        '
        Me.btnGetAPGP.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPGP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnGetAPGP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnGetAPGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnGetAPGP.ForeColor = System.Drawing.Color.Black
        Me.btnGetAPGP.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnGetAPGP.Image = Nothing
        Me.btnGetAPGP.ImageKey = ""
        Me.btnGetAPGP.ImageList = Nothing
        Me.btnGetAPGP.Location = New System.Drawing.Point(87, 321)
        Me.btnGetAPGP.Name = "btnGetAPGP"
        Me.btnGetAPGP.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPGP.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPGP.Size = New System.Drawing.Size(75, 23)
        Me.btnGetAPGP.TabIndex = 104
        Me.btnGetAPGP.Text = "Get AP"
        Me.btnGetAPGP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'txtTextURLGP
        '
        Me.txtTextURLGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtTextURLGP.Location = New System.Drawing.Point(293, 9)
        Me.txtTextURLGP.Name = "txtTextURLGP"
        Me.txtTextURLGP.Size = New System.Drawing.Size(153, 20)
        Me.txtTextURLGP.TabIndex = 79
        Me.txtTextURLGP.Visible = False
        Me.txtTextURLGP.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtTextURLGP.WaterMarkText = "Choose File Import"
        '
        'btnClearAllGP
        '
        Me.btnClearAllGP.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllGP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearAllGP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearAllGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearAllGP.ForeColor = System.Drawing.Color.Black
        Me.btnClearAllGP.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearAllGP.Image = Nothing
        Me.btnClearAllGP.ImageKey = ""
        Me.btnClearAllGP.ImageList = Nothing
        Me.btnClearAllGP.Location = New System.Drawing.Point(249, 321)
        Me.btnClearAllGP.Name = "btnClearAllGP"
        Me.btnClearAllGP.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllGP.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllGP.Size = New System.Drawing.Size(75, 23)
        Me.btnClearAllGP.TabIndex = 80
        Me.btnClearAllGP.Text = "Clear All"
        Me.btnClearAllGP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnLoadFileGP
        '
        Me.btnLoadFileGP.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileGP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnLoadFileGP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLoadFileGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnLoadFileGP.ForeColor = System.Drawing.Color.Black
        Me.btnLoadFileGP.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnLoadFileGP.Image = Nothing
        Me.btnLoadFileGP.ImageKey = ""
        Me.btnLoadFileGP.ImageList = Nothing
        Me.btnLoadFileGP.Location = New System.Drawing.Point(6, 321)
        Me.btnLoadFileGP.Name = "btnLoadFileGP"
        Me.btnLoadFileGP.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileGP.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileGP.Size = New System.Drawing.Size(75, 23)
        Me.btnLoadFileGP.TabIndex = 75
        Me.btnLoadFileGP.Text = "Load File"
        Me.btnLoadFileGP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClearGP
        '
        Me.btnClearGP.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearGP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearGP.ForeColor = System.Drawing.Color.Black
        Me.btnClearGP.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearGP.Image = Nothing
        Me.btnClearGP.ImageKey = ""
        Me.btnClearGP.ImageList = Nothing
        Me.btnClearGP.Location = New System.Drawing.Point(168, 321)
        Me.btnClearGP.Name = "btnClearGP"
        Me.btnClearGP.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGP.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearGP.Size = New System.Drawing.Size(75, 23)
        Me.btnClearGP.TabIndex = 74
        Me.btnClearGP.Text = "Clear"
        Me.btnClearGP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnGetAPTax
        '
        Me.btnGetAPTax.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPTax.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnGetAPTax.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnGetAPTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnGetAPTax.ForeColor = System.Drawing.Color.Black
        Me.btnGetAPTax.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnGetAPTax.Image = Nothing
        Me.btnGetAPTax.ImageKey = ""
        Me.btnGetAPTax.ImageList = Nothing
        Me.btnGetAPTax.Location = New System.Drawing.Point(86, 323)
        Me.btnGetAPTax.Name = "btnGetAPTax"
        Me.btnGetAPTax.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPTax.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnGetAPTax.Size = New System.Drawing.Size(75, 23)
        Me.btnGetAPTax.TabIndex = 103
        Me.btnGetAPTax.Text = "Get AP"
        Me.btnGetAPTax.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'txtTextURLTax
        '
        Me.txtTextURLTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtTextURLTax.Location = New System.Drawing.Point(295, 6)
        Me.txtTextURLTax.Name = "txtTextURLTax"
        Me.txtTextURLTax.Size = New System.Drawing.Size(161, 20)
        Me.txtTextURLTax.TabIndex = 80
        Me.txtTextURLTax.Visible = False
        Me.txtTextURLTax.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtTextURLTax.WaterMarkText = "Choose File Import"
        '
        'btnClearAllTax
        '
        Me.btnClearAllTax.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllTax.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearAllTax.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearAllTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearAllTax.ForeColor = System.Drawing.Color.Black
        Me.btnClearAllTax.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearAllTax.Image = Nothing
        Me.btnClearAllTax.ImageKey = ""
        Me.btnClearAllTax.ImageList = Nothing
        Me.btnClearAllTax.Location = New System.Drawing.Point(248, 323)
        Me.btnClearAllTax.Name = "btnClearAllTax"
        Me.btnClearAllTax.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllTax.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearAllTax.Size = New System.Drawing.Size(75, 23)
        Me.btnClearAllTax.TabIndex = 81
        Me.btnClearAllTax.Text = "Clear All"
        Me.btnClearAllTax.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnClearTax
        '
        Me.btnClearTax.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearTax.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnClearTax.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnClearTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClearTax.ForeColor = System.Drawing.Color.Black
        Me.btnClearTax.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnClearTax.Image = Nothing
        Me.btnClearTax.ImageKey = ""
        Me.btnClearTax.ImageList = Nothing
        Me.btnClearTax.Location = New System.Drawing.Point(167, 323)
        Me.btnClearTax.Name = "btnClearTax"
        Me.btnClearTax.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearTax.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnClearTax.Size = New System.Drawing.Size(75, 23)
        Me.btnClearTax.TabIndex = 70
        Me.btnClearTax.Text = "Clear"
        Me.btnClearTax.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnLoadFileTax
        '
        Me.btnLoadFileTax.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileTax.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.btnLoadFileTax.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLoadFileTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnLoadFileTax.ForeColor = System.Drawing.Color.Black
        Me.btnLoadFileTax.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnLoadFileTax.Image = Nothing
        Me.btnLoadFileTax.ImageKey = ""
        Me.btnLoadFileTax.ImageList = Nothing
        Me.btnLoadFileTax.Location = New System.Drawing.Point(5, 323)
        Me.btnLoadFileTax.Name = "btnLoadFileTax"
        Me.btnLoadFileTax.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileTax.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnLoadFileTax.Size = New System.Drawing.Size(75, 23)
        Me.btnLoadFileTax.TabIndex = 71
        Me.btnLoadFileTax.Text = "Load File"
        Me.btnLoadFileTax.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmPaymentCreationProcess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 638)
        Me.Controls.Add(Me.lblAlert)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnPrintGL)
        Me.Controls.Add(Me.btnFind)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FrmPaymentCreationProcess"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmPaymentCreation"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelH1.ResumeLayout(False)
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgvGL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgvGP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.dgvTax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents cboJournalType As System.Windows.Forms.ComboBox
    Friend WithEvents txtEntryDate As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboGroup As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cboDataSource As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtTransRef As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents txtInputWHTAmt As System.Windows.Forms.TextBox
    Friend WithEvents txtBaseAmt As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnClearAll As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClearGL As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnLoadFileTax As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClearTax As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtOutOfBalance As System.Windows.Forms.TextBox
    Friend WithEvents txtAmtCredits As System.Windows.Forms.TextBox
    Friend WithEvents txtAmtDebits As System.Windows.Forms.TextBox
    Friend WithEvents cboEntryType As System.Windows.Forms.ComboBox
    Friend WithEvents dgvGP As System.Windows.Forms.DataGridView
    Friend WithEvents btnLoadFileGP As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClearGP As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents dgvTax As System.Windows.Forms.DataGridView
    Friend WithEvents txtAmtCreditGP As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowseGL As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtTextURLGL As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents btnConvert As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents lblTotalLine As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents lbltxtTotalLine As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtJournalHold As System.Windows.Forms.TextBox
    Friend WithEvents cboOverSea As System.Windows.Forms.ComboBox
    Friend WithEvents btnFind As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClose As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnSave As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClear As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtRCCode As System.Windows.Forms.TextBox
    Friend WithEvents txtCompanyCode As System.Windows.Forms.TextBox
    Friend WithEvents txtActualFlag As System.Windows.Forms.TextBox
    Friend WithEvents txtCurrencyCode As System.Windows.Forms.TextBox
    Friend WithEvents txtCategoryName As System.Windows.Forms.TextBox
    Friend WithEvents txtSourceName As System.Windows.Forms.TextBox
    Friend WithEvents txtBookID As System.Windows.Forms.TextBox
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents dgvGL As System.Windows.Forms.DataGridView
    Friend WithEvents btnPrintGL As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtTextURLGP As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents txtTextURLTax As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents btnClearAllGP As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnClearAllTax As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents txtAccPeriod As System.Windows.Forms.TextBox
    Friend WithEvents dtpDueDate As CustomControls.DatePicker
    Friend WithEvents txtSection As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cboEntryTypeGP As System.Windows.Forms.ComboBox
    Friend WithEvents lblDept As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cboEntryTypeTAX As System.Windows.Forms.ComboBox
    Friend WithEvents btnUpdate As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnDelete As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cboPayMth As System.Windows.Forms.ComboBox
    Friend WithEvents btnAddRowGL As System.Windows.Forms.Button
    Friend WithEvents btnAddRowGP As System.Windows.Forms.Button
    Friend WithEvents btnAddRowTax As System.Windows.Forms.Button
    Friend WithEvents chkFlagAllGP As System.Windows.Forms.CheckBox
    Friend WithEvents txtPurpose As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents btnGetAPGP As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnGetAPTax As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents lblAlert As System.Windows.Forms.Label
End Class
