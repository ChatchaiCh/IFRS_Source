﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Imports System.Globalization

Public Class frmExportReconcileDataGL
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim clsRpt As New ClsReport
    Dim clsLog As New ClsLog
    Dim clsHashLO As New ClsHashTotalErrorLOCancel
    Dim LO_Dup As New StringBuilder
    Dim sDataExist As New StringBuilder
    Dim strPathExportFile As String
    Dim clsConnectDB As ConnectDB

    Private Sub frmExportReconcileDataGL_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2 = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        strPathExportFile = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "PHORNGORDOR2_PATH")

        InitializeForm()
    End Sub

    Private Sub InitializeForm()
        Dim strFormatDate As String = "dd-MM-yyyy"
        Dim dteDateShow As Date = DateTime.Today.AddMonths(-1)
        Dim dteEndMonthShow As New DateTime(DateTime.Today.Year, DateTime.Today.Month, 1)

        dtpFromGlDate.Format = DateTimePickerFormat.Short
        dtpFromGlDate.CustomFormat = strFormatDate
        dtpFromGlDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), 1)

        dtpToGlDate.Format = DateTimePickerFormat.Short
        dtpToGlDate.CustomFormat = strFormatDate
        dtpToGlDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), dteEndMonthShow.AddDays(-1).Day)

        dtpFromTransDate.Format = DateTimePickerFormat.Short
        dtpFromTransDate.CustomFormat = strFormatDate
        dtpFromTransDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), 1)

        dtpToTransDate.Format = DateTimePickerFormat.Short
        dtpToTransDate.CustomFormat = strFormatDate
        dtpToTransDate.Value = New Date(Year(dteDateShow), Month(dteDateShow), dteEndMonthShow.AddDays(-1).Day)

        btnCancel.Focus()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click

        Try
            Dim csv As String = """Transaction Date"",""Accounting Date"",""SourceSystem"",""File Propose"",""Company"",""LoB"",""Account (Local)"",""SubAccount (Local)"",""Account (Group)"",""SubAccount (Group)"",""Product (Local)"",""Cost Centre (Local)"",""Analysis (Local)"",""Channel (Local)"",""Project (Local)"",""Intercompany (Local)"",""SPARE1 (Local)"",""Treaty Code (Local)"",""Event Code (Local)"",""Local 3 (Local)"",""Local 4 (Local)"",""REF_1 (Local)"",""REF_2 (Local)"",""REF_3 (Local)"",""REF_4 (Local)"",""REF_5 (Local)"",""REF_6 (Local)"",""REF_7 (Local)"",""REF_8 (Local)"",""REF_9 (Local)"",""REF_10 (Local)"",""Product (Group)"",""Cost Centre (Group)"",""Analysis (Group)"",""Channel (Group)"",""Project (Group)"",""Intercompany (Group)"",""SPARE1 (Group)"",""Treaty Code (Group)"",""Event Code (Group)"",""Local 3 (Group)"",""Local 4 (Group)"",""REF_1 (Group)"",""REF_2 (Group)"",""REF_3 (Group)"",""REF_4 (Group)"",""REF_5 (Group)"",""REF_6 (Group)"",""REF_7 (Group)"",""REF_8 (Group)"",""REF_9 (Group)"",""REF_10 (Group)"",""Currency"",""Charge code"",""Accounting Amount"",""Accounting Amount with GL Sign"",""Dr./Cr. sign (D / C)""" & vbCr & vbLf
            Dim csvDetail As String = """Accounting Date (GL Date)"",""Effective Date"",""Transaction Date"",""TranNo"",""TranNo_Reverse"",""Contract No."",""Reference No."",""OWNERNAME "",""BATCTRCDE"",""BATCBATCH"",""RDOCNUM"",""Contract type (CNTTYPE)"",""Receive Date (RECPTDT)"",""ACCT (Local)"",""SUB_ACCT (Local)"",""ACCT  (Group)"",""SUB_ACCT (Group)"",""SACSCODE"",""SACSTYP"",""GLCODE"",""Source of Business"",""RLDGACCT"",""YRSINF"",""BANKCODE"",""BNKDSC"",""Charge code"",""Agent code"",""Pay to Agent"",""DEFAULT_AMOUNT"",""DEFAULT_AMOUNT with GL Sign"",""DEFAULT_CURRENCY"",""CONVERSION_TYPE"",""CONVERSION_RATE"",""CONVERSION_DATE"",""ACCOUNTED_AMOUNT"",""ACCOUNTED_AMOUNT with GL Sign"",""DR_CR"",""LINE_DESCRIPTION"",""LINE_TRX_REF1"",""LINE_TRX_REF2"",""LINE_TRX_REF3"",""COMPANY (Local)"",""LOB (Local)"",""PRODUCT (Local)"",""CC (Local)"",""ANALYSIS (Local)"",""CHANNEL (Local)"",""PROJECT (Local)"",""INTERCOMPANY (Local)"",""SPARE1"",""Treaty Code"",""Event Code"",""Local 3"",""Local 4"",""REF_1"",""REF_2"",""REF_3"",""REF_4"",""REF_5"",""REF_6"",""REF_7"",""REF_8"",""REF_9"",""REF_10"",""PRODUCT (Group)"",""CC  (Group)"",""ANALYSIS  (Group)"",""CHANNEL  (Group)"",""PROJECT  (Group)"",""INTERCOMPANY  (Group)"",""SPARE1"",""Treaty Code"",""Event Code"",""Local 3"",""Local 4"",""REF_1"",""REF_2"",""REF_3"",""REF_4"",""REF_5"",""REF_6"",""REF_7"",""REF_8"",""REF_9"",""REF_10"",""SourceSystem""" & vbCr & vbLf
            Dim StartAccount, ToAccount, StartSubAccount, ToSubAccount As String
            If (txtStartAccount.TextLength = 0) Then
                StartAccount = "0000000"
            Else
                StartAccount = txtStartAccount.Text.Trim
            End If
            If (txtToAccount.TextLength = 0) Then
                ToAccount = "9999999"
            Else
                ToAccount = txtToAccount.Text.Trim
            End If
            If (txtStartSubAccount.TextLength = 0) Then
                StartSubAccount = "0000000"
            Else
                StartSubAccount = txtStartSubAccount.Text.Trim
            End If
            If (txtToSubAccount.TextLength = 0) Then
                ToSubAccount = "ZZZZZZZ"
            Else
                ToSubAccount = txtToSubAccount.Text.Trim
            End If
            Dim dt As DataTable = clsRpt.GetDataReconcileSummaryGL(clsUtility.gConnGP, dtpFromTransDate.Value.ToString("yyyyMMdd"), dtpToTransDate.Value.ToString("yyyyMMdd"), dtpFromGlDate.Value.ToString("yyyyMMdd"), dtpToGlDate.Value.ToString("yyyyMMdd"), StartAccount, ToAccount, StartSubAccount, ToSubAccount)
            Dim dtDetail As DataTable = clsRpt.GetDataReconcileDetailGL(clsUtility.gConnGP, dtpFromTransDate.Value.ToString("yyyyMMdd"), dtpToTransDate.Value.ToString("yyyyMMdd"), dtpFromGlDate.Value.ToString("yyyyMMdd"), dtpToGlDate.Value.ToString("yyyyMMdd"), StartAccount, ToAccount, StartSubAccount, ToSubAccount)

            If dt Is Nothing And dtDetail Is Nothing Then
                MsgBox("ไม่พบข้อมูล", vbExclamation)
                Exit Sub
            End If

            Dim running As Integer = clsRpt.GetRunningDataGL(clsUtility.gConnGP)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each row As DataRow In dt.Rows
                    'Add the Data rows.
                    csv += row(0).ToString & vbCr & vbLf
                Next

                'Exporting to text file
                Dim strFileName As String = "SUMGL_GPS_" & dtpFromGlDate.Value.ToString("yyyyMMdd") & "_" & running.ToString("0000") & "_" & gUserLogin & ".csv"
                '-- move file to server
                'Dim strSourceFileName As String = "D:\" & strFileName
                'Dim strDestinationFileName As String = strPathExportFile & strFileName
                'clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
                '-- end move file to server
                strPathExportFile = "D:\"
                File.WriteAllText(strPathExportFile & strFileName, csv, Encoding.UTF8)

                MsgBox("Export Reconcile Summary GL เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & strFileName, MsgBoxStyle.Information)

            End If

            If Not IsNothing(dtDetail) AndAlso dtDetail.Rows.Count > 0 Then
                For Each row As DataRow In dtDetail.Rows
                    'Add the Data rows.
                    csvDetail += row(0).ToString & vbCr & vbLf
                Next

                'Exporting to text file
                Dim strFileName As String = "DELGL_GPS_" & dtpFromGlDate.Value.ToString("yyyyMMdd") & "_" & running.ToString("0000") & "_" & gUserLogin & ".csv"
                '-- move file to server
                'Dim strSourceFileName As String = "D:\" & strFileName
                'Dim strDestinationFileName As String = strPathExportFile & strFileName
                'clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
                '-- end move file to server
                strPathExportFile = "D:\"
                File.WriteAllText(strPathExportFile & strFileName, csvDetail, Encoding.UTF8)

                MsgBox("Export Reconcile Detail GL เรียบร้อยแล้ว" & vbCrLf & "==> " & strPathExportFile & strFileName, MsgBoxStyle.Information)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical)
        End Try

    End Sub

End Class