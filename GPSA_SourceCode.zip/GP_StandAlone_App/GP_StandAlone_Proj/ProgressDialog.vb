﻿Option Explicit On
Option Strict On
Imports System.Windows.Forms

''' <summary>
''' Dialog class with a ProgressBar widget to 
''' show the progress of a long running task
''' </summary>
''' <remarks></remarks>
Public Class ProgressDialog
    Inherits Form
    Delegate Sub DelegateUpdate(ByVal progress As Integer)
    Delegate Sub DelegateClose(ByRef dialog As Form)
    Public Sub New()
        InitializeComponent()

    End Sub
    Public Sub UpdateProgress(ByVal progress As Integer)
        If ProgressBar1.InvokeRequired Then
            ProgressBar1.BeginInvoke(New DelegateUpdate(AddressOf UpdateDelegateImpl), progress)
        Else
            ProgressBar1.Value = progress
        End If
    End Sub
    Public Overloads Sub Close()
        If Me.InvokeRequired Then
            Me.BeginInvoke(New _
                           DelegateClose(AddressOf CloseDelegateImpl), Me)
        Else
            Me.Close()
        End If
    End Sub
    Sub UpdateDelegateImpl(ByVal progress As Integer)
        ProgressBar1.Value = progress
        LabelProgress.Text = ""
        LabelProgress.Text = progress & CStr("%")
    End Sub
    Sub CloseDelegateImpl(ByRef dialog As Form)
        dialog.Close()
    End Sub
    Private Declare Auto Function SendMessage Lib "user32.dll" (ByVal hwnd As IntPtr, ByVal wMsg As Int32, ByVal wParam As Int32, ByVal lParam As Int32) As Int32
    ' this code let you change the forecolor 
    Private Sub PbSetForeColor(ByVal Pb As ProgressBar, ByVal NewColor As Int32)
        SendMessage(Pb.Handle, &H409, 0, NewColor)
    End Sub
    ' this code will let you change the back color
    Private Sub PbSetBackColor(ByVal Pb As ProgressBar, ByVal NewColor As Int32)
        SendMessage(Pb.Handle, &H2001, 0, NewColor)
    End Sub
    Private Sub ProgressDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      

    End Sub
End Class
