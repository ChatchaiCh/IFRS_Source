Imports System
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Imports System.Globalization
Imports System.Net.Mail

Public Class FrmTLMManualCloseBatchProcess
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsValidateManualCloseBatch
    Dim timework As Integer = 1
    Dim systemdate As String = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
#Region "BackgroundWorker"


    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

        CloseBatch()

        Dim i As Integer
        For i = 0 To timework Step +1
            '����ա����� Cancel �����ش�ѹ��
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                '��§ҹ����� prgress ���� 1 progress
                BackgroundWorker1.ReportProgress(i)
                System.Threading.Thread.Sleep(timework)
            End If
        Next

    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ''���� 1 progress      
        'Me.ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            '������ BackgroundWorker ��ش�ӧҹ
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        'MsgBox("Complete")
        'btnConfirm.Enabled = False
        'Me.Dispose()

        'Cursor = Cursors.Default
        'Me.Close()
        PrintReport()
        btnConfirm.Enabled = False

    End Sub
#End Region
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)


        btnConfirm.BackColor = Color.FromArgb(255, 235, 220)
        btnConfirm.Height = 25
        btnConfirm.Enabled = False
        btnPreview.BackColor = Color.FromArgb(255, 235, 220)
        btnPreview.Height = 25
        btnPreview.Enabled = False
    End Sub
    Private Sub FrmManualCloseBatch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = False

        ControlStyle()
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        'Dim dt As New DataTable
        'dt = Nothing
        'GetDataToGrid(dt)

        txtDate.Text = systemdate.Substring(6, 2) & "/" & systemdate.Substring(4, 2) & "/" & systemdate.Substring(0, 4) ' Now.ToString("dd/MM/yyyy")
    End Sub
    Function GetData(ByVal systemdate As String) As DataTable

        Dim sb As New StringBuilder()
        sb.Append("select t.tref_vch_no_c as voucher_no,t.tref_transref as transref,sum(p.gpcr_amount) as net_amt ")
        sb.Append(",t.tref_createdate,t.tref_core_system  ")
        sb.Append("from gps_payment_creation p inner join gps_transref_rel t ")
        sb.Append("on p.gpcr_createdate=t.tref_createdate ")
        sb.Append("and p.gpcr_core_system=t.tref_core_system ")
        sb.Append("and p.gpcr_transref=t.tref_transref ")

        sb.Append("where t.tref_approvedby is not null  ")

        sb.Append("  and t.tref_flag_batch='N' ")

        sb.Append("and t.tref_approveddate = '" & systemdate.Substring(0, 8) & "'  ")

        sb.Append("and t.tref_paycretyp_id NOT IN ( '003', '006' ) ")

        sb.Append(" and p.gpcr_flag_validate = 'COMPLETE' ") '--> cancel payment

        sb.Append("group by  t.tref_vch_no_c,t.tref_transref,t.tref_createdate,t.tref_core_system  ")
        sb.Append("order by t.tref_vch_no_c ")

        Dim dt As New DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function InsertToTempPayment(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_PAYMENT ( ")
        sb.Append("GP_BATCHDATE,")
        sb.Append("GP_BATCH_NO,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_DESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_FLAG_VALIDATE,")
        sb.Append("GP_REJECT_TYPE,")
        sb.Append("GP_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE, ")
        sb.Append("GP_FLAG_CC,")
        sb.Append("GP_CC_APPROVEDBY) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("GPCR_CREATEDATE, ")
        sb.Append("GPCR_CORE_SYSTEM, ")
        sb.Append("GPCR_TRANSREF, ")
        sb.Append("GPCR_GPTREF_SEQNO, ")
        sb.Append("GPCR_POLNO, ")
        sb.Append("GPCR_BILLNO, ")
        sb.Append("GPCR_PAIDDATE, ")
        sb.Append("GPCR_AMOUNT, ")
        sb.Append("GPCR_DESC, ")
        sb.Append("GPCR_PAYMTH, ")
        sb.Append("GPCR_PAYEE_NAME, ")
        sb.Append("GPCR_BNKCODE, ")
        sb.Append("GPCR_BNKCODE_NO, ")
        sb.Append("GPCR_BNKBRN, ")
        sb.Append("GPCR_BNKNAME, ")
        sb.Append("GPCR_PAYEE_BNKACCNO, ")
        sb.Append("GPCR_PAYEE_BNKACCNME, ")
        sb.Append("GPCR_COMMENT, ")
        sb.Append("GPCR_ADDRESS1, ")
        sb.Append("GPCR_DISTRICT, ")
        sb.Append("GPCR_PROVINCE, ")
        sb.Append("GPCR_INSURENAME, ")
        sb.Append("GPCR_DATASOURCE_NME, ")
        sb.Append("GPCR_Reserve6, ")
        sb.Append("GPCR_MERCHN_NO, ")
        sb.Append("GPCR_CDCARD_DATE, ")
        sb.Append("GPCR_Reserve9, ")
        sb.Append("GPCR_Reserve10, ")
        sb.Append("GPCR_SYS_REF, ")
        sb.Append("GPCR_SYS_GR, ")
        sb.Append("GPCR_SUB_PAYMTH, ")
        sb.Append("GPCR_FLAG_FLWBILL, ")
        sb.Append("GPCR_OSEA_LIST, ")
        sb.Append("GPCR_PHONE, ")
        sb.Append("GPCR_FAX, ")
        sb.Append("GPCR_SWIFT_CODE, ")
        sb.Append("GPCR_BNKBRN_NAME, ")
        sb.Append("GPCR_BNKADDR, ")
        sb.Append("GPCR_COUNTRY, ")
        sb.Append("GPCR_CURRENCY, ")
        sb.Append("GPCR_EXCHN_RATE, ")
        sb.Append("GPCR_BNKCHARGES, ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'M', ")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'), ")
        sb.Append("GPCR_fLAG_CC, ")
        sb.Append("GPCR_CC_APPROVEDBY ")
        sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN GPS_TRANSREF_REL T ")
        sb.Append("ON P.GPCR_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND P.GPCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GPCR_TRANSREF=T.TREF_TRANSREF ")
        sb.Append("WHERE T.TREF_APPROVEDBY IS NOT NULL ")
        sb.Append("AND T.TREF_FLAG_BATCH='N' ")
        sb.Append("AND T.TREF_APPROVEDDATE = '" & systemdate & "' ")
        sb.Append("AND T.TREF_PAYCRETYP_ID='003' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertToTempWHT(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT   ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXCR_CREATEDATE, ")
        sb.Append("TAXCR_CORE_SYSTEM, ")
        sb.Append("TAXCR_TRANSREF, ")
        sb.Append("TAXCR_GPTREF_SEQNO, ")
        sb.Append("TAXCR_LINENO, ")
        sb.Append("TAXCR_TAXID, ")
        sb.Append("TAXCR_IDCARD, ")
        sb.Append("TAXCR_AP_TTL, ")
        sb.Append("TAXCR_AP_FNAME, ")
        sb.Append("TAXCR_AP_LNAME, ")
        sb.Append("TAXCR_ADDRESS, ")
        sb.Append("TAXCR_AMPENM, ")
        sb.Append("TAXCR_PROVNM, ")
        sb.Append("TAXCR_AGZIP, ")
        sb.Append("TAXCR_TAXTYPE, ")
        sb.Append("TAXCR_TAXITEM, ")
        sb.Append("TAXCR_TAXDATE, ")
        sb.Append("TAXCR_BASE_AMT, ")
        sb.Append("TAXCR_TAX_AMT, ")
        sb.Append("TAXCR_PAYEE, ")
        sb.Append("TAXCR_TAX_RATE, ")
        sb.Append("TAXCR_DESC, ")
        sb.Append("TAXCR_GL_ACCOUNT, ")
        sb.Append("'COMPLETE', ")
        sb.Append("'', ")
        sb.Append("'M', ")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_WHT_CREATION W INNER JOIN GPS_TRANSREF_REL T ")
        sb.Append("ON W.TAXCR_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND W.TAXCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")
        sb.Append("AND W.TAXCR_TRANSREF=T.TREF_TRANSREF ")
        sb.Append("WHERE T.TREF_APPROVEDBY IS NOT NULL ")
        sb.Append("AND T.TREF_FLAG_BATCH='N' ")
        sb.Append("AND T.TREF_APPROVEDDATE = '" & systemdate & "' ")
        sb.Append("AND T.TREF_PAYCRETYP_ID='003' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertDataToTemp_manual(ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim insPayment, insWHT As Boolean


        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        insPayment = InsertToTempPayment(oleTrans, systemdate, batchno)
        insWHT = InsertToTempWHT(oleTrans, systemdate, batchno)

        If insPayment And insWHT Then
            oleTrans.Commit()

            Return True
        Else
            oleTrans.Rollback()

            Return False
        End If
    End Function
    Function fnDelete_manual(ByVal oleTrans As OleDbTransaction, ByVal str As String) As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        sb.Append(str)

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Function DeleteOldData() As Boolean
        Dim oleTrans As OleDbTransaction
        Dim sb As New StringBuilder
        Dim d1, d2 As Boolean

        oleTrans = clsUtility.gConnGP.BeginTransaction()

        d1 = fnDelete(oleTrans, "delete from gps_tmp_payment ")

        d2 = fnDelete(oleTrans, "delete from gps_tmp_wht ")

        If (d1 And d2) Then
            oleTrans.Commit()

            Return True
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            'MsgBox(clsBusiness.gLastErrMessage)
            Return False
        End If
    End Function
    Function InsertTableComplete_manual(ByVal oleTrans As OleDbTransaction) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentComplete(oleTrans)
        chkWHT = InsertWHTComplete(oleTrans)

        If chkPayment And chkWHT Then
            'oleTrans.Commit()
            Return True
        Else
            'oleTrans.Rollback()
            Return False
        End If

    End Function
    Function InsertTableReject_manual(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentReject(oleTrans)
        chkWHT = InsertWHTReject(oleTrans)

        If chkPayment And chkWHT Then
            Return True

        Else
            Return False
        End If


    End Function
    Function InsertPaymentComplete_manual(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_COMPLETE ( ")
        sb.Append("GPCM_BATCHDATE,")
        sb.Append("GPCM_BATCH_NO,")
        sb.Append("GPCM_CREATEDATE,")
        sb.Append("GPCM_CORE_SYSTEM,")
        sb.Append("GPCM_TRANSREF,")
        sb.Append("GPCM_GPTREF_SEQNO,")
        sb.Append("GPCM_POLNO,")
        sb.Append("GPCM_BILLNO,")
        sb.Append("GPCM_PAIDDATE,")
        sb.Append("GPCM_AMOUNT,")
        sb.Append("GPCM_DESC,")
        sb.Append("GPCM_PAYMTH,")
        sb.Append("GPCM_PAYEE_NAME,")
        sb.Append("GPCM_BNKCODE,")
        sb.Append("GPCM_BNKCODE_NO,")
        sb.Append("GPCM_BNKBRN,")
        sb.Append("GPCM_BNKNAME,")
        sb.Append("GPCM_PAYEE_BNKACCNO,")
        sb.Append("GPCM_PAYEE_BNKACCNME,")
        sb.Append("GPCM_COMMENT,")
        sb.Append("GPCM_ADDRESS1,")
        sb.Append("GPCM_DISTRICT,")
        sb.Append("GPCM_PROVINCE,")
        sb.Append("GPCM_INSURENAME,")
        sb.Append("GPCM_DATASOURCE_NME,")
        sb.Append("GPCM_RESERVE6,")
        sb.Append("GPCM_MERCHN_NO,")
        sb.Append("GPCM_CDCARD_DATE,")
        sb.Append("GPCM_RESERVE9,")
        sb.Append("GPCM_RESERVE10,")
        sb.Append("GPCM_SYS_REF,")
        sb.Append("GPCM_SYS_GR,")
        sb.Append("GPCM_SUB_PAYMTH,")
        sb.Append("GPCM_FLAG_FLWBILL,")
        sb.Append("GPCM_OSEA_LIST,")
        sb.Append("GPCM_PHONE,")
        sb.Append("GPCM_FAX,")
        sb.Append("GPCM_SWIFT_CODE,")
        sb.Append("GPCM_BNKBRN_NAME,")
        sb.Append("GPCM_BNKADDR,")
        sb.Append("GPCM_COUNTRY,")
        sb.Append("GPCM_CURRENCY,")
        sb.Append("GPCM_EXCHN_RATE,")
        sb.Append("GPCM_BNKCHARGES,")
        sb.Append("GPCM_BATCHTYPE,")
        sb.Append("GPCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE)")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("'N', ")
        sb.Append("CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE' ")
        sb.Append("AND CREATEDBY='" & gUserLogin & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTComplete_manual(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_COMPLETE( ")
        sb.Append("TAXCM_BATCHDATE,")
        sb.Append("TAXCM_BATCH_NO,")
        sb.Append("TAXCM_CREATEDATE,")
        sb.Append("TAXCM_CORE_SYSTEM,")
        sb.Append("TAXCM_TRANSREF,")
        sb.Append("TAXCM_GPTREF_SEQNO,")
        sb.Append("TAXCM_LINENO,")
        sb.Append("TAXCM_TAXID,")
        sb.Append("TAXCM_IDCARD,")
        sb.Append("TAXCM_AP_TTL,")
        sb.Append("TAXCM_AP_FNAME,")
        sb.Append("TAXCM_AP_LNAME,")
        sb.Append("TAXCM_ADDRESS,")
        sb.Append("TAXCM_AMPENM,")
        sb.Append("TAXCM_PROVNM,")
        sb.Append("TAXCM_AGZIP,")
        sb.Append("TAXCM_TAXTYPE,")
        sb.Append("TAXCM_TAXITEM,")
        sb.Append("TAXCM_TAXDATE,")
        sb.Append("TAXCM_BASE_AMT,")
        sb.Append("TAXCM_TAX_AMT,")
        sb.Append("TAXCM_PAYEE,")
        sb.Append("TAXCM_TAX_RATE,")
        sb.Append("TAXCM_DESC,")
        sb.Append("TAXCM_GL_ACCOUNT,")
        sb.Append("TAXCM_BATCHTYPE,")
        sb.Append("TAXCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='COMPLETE' ")
        sb.Append("AND CREATEDBY='" & gUserLogin & "' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function chkDataComplete_manual(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder
        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE' AND CREATEDBY='" & gUserLogin & "' ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='COMPLETE' AND CREATEDBY='" & gUserLogin & "') A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If

    End Function
    Function chkDataReject_manual(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder
        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND CREATEDBY='" & gUserLogin & "' ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND CREATEDBY='" & gUserLogin & "') A ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If

    End Function
    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click
        If DataGridView1.RowCount <= 0 Then
            MsgBox("Data not found!")
            Exit Sub
        End If

        Try
            timework = 1
            timework = timework * 100
            Dim progress As New frmProgress(Me.BackgroundWorker1)
            progress.ShowDialog()

        Catch ex As Exception
            StopWorker()
            MsgBox("Process Error!")
        End Try


        Dim dt As New DataTable
        'Dim systemdate As String = clsBusiness.GetSystemDate(clsUtility.gConnGP)
        dt = GetData(systemdate)
        GetDataToGrid(dt)
        txtBatchNo.Text = ""
        'Bind Data
        'btnPreview.Enabled = True


    End Sub
    Private Sub CloseBatch()

        Dim chk_aml As Boolean
        Dim dataCM As Integer
        Dim dataRJ As Integer
        Dim chk_totemp, chk_complete, chk_rej As Boolean

        If DataGridView1.RowCount > 0 Then
            btnConfirm.Enabled = False

            'Dim systemdate As String
            Dim s_systemtime As String

            'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
            s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

            'For index As Integer = 0 To DataGridView1.RowCount - 1
            If DeleteOldData() Then

                Dim batchno As String
                batchno = clsBusiness.fnCallBatchNo(clsUtility.gConnGP, systemdate)

                Dim oleTrans As OleDbTransaction
                oleTrans = clsUtility.gConnGP.BeginTransaction()

                Try
                    chk_complete = True
                    chk_rej = True

                    chk_totemp = InsertDataToTemp(systemdate, batchno, oleTrans)

                    If chk_totemp Then
                        oleTrans.Commit()
                        'ValidateData(systemdate, batchno)
                        If ValidateData(systemdate, batchno) Then

                            '��Ǩ�ͺ��Ҿ������� COMPLETE
                            dataCM = chkDataComplete(systemdate)
                            '��Ǩ�ͺ��Ҿ������� INCOMPLETE
                            dataRJ = chkDataReject(systemdate)

                            oleTrans = clsUtility.gConnGP.BeginTransaction()

                            'Insert to AML
                            chk_aml = InsertTableAML(oleTrans)

                            '��Ǩ�ͺ��Ҿ������� COMPLETE ��� insert data ŧ table Complete
                            If dataCM > 0 Then
                                chk_complete = InsertTableComplete(oleTrans)
                            End If
                            '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� insert data ŧ table Reject
                            If dataRJ > 0 Then
                                chk_rej = InsertTableReject(oleTrans)
                            End If

                            If chk_complete And chk_rej And chk_aml Then
                                oleTrans.Commit()

                                Dim chk_updateflag As Boolean
                                chk_updateflag = UpdateFlag(systemdate, oleTrans)

                                Dim chk_updateflag_GL As Boolean
                                chk_updateflag_GL = UpdateFlag_GL(systemdate, oleTrans)

                                Dim chk_updateflag_TAX As Boolean
                                chk_updateflag_TAX = UpdateFlag_TAX(systemdate, oleTrans)

                                If chk_updateflag And chk_updateflag_GL And chk_updateflag_TAX Then

                                    '��Ǩ�ͺ��Ҿ������� INCOMPLETE ��� update reject type � table creation
                                    If dataRJ > 0 Then

                                        UpdatePaymentReject_CR(oleTrans)
                                        clsBusiness.gLastErrMessage = "UpdatePaymentReject_CR"
                                        InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                                        UpdateWHTReject_CR(oleTrans)
                                        clsBusiness.gLastErrMessage = "UpdateWHTReject_CR"
                                        InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                                        '--UpdatePaymentReject_LD()
                                        '--UpdateWHTReject_LD()
                                    End If

                                    clsBusiness.gLastErrMessage = "update flag GP, GL, WHT"
                                    InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                                Else
                                    clsBusiness.gLastErrMessage = "update flag GP, GL, WHT"
                                    InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)
                                End If

                            Else
                                oleTrans.Rollback()
                                StopWorker()
                                clsBusiness.gLastErrMessage = "TLM Manual Close Batch incomplete!"
                                InsertTransLog(systemdate, batchno, s_systemtime, "INCOMPLETE", 0)

                                MsgBox("Manual close batch incomplete!" & vbCrLf & "Please contact GPSA administrator.", MsgBoxStyle.Information, Label4.Text)

                            End If

                            '�������� Incomplete ��� generate report and send email

                            If dataRJ > 0 Then

                                CallGL_REJ_PARTIAL(systemdate, batchno, gUserLogin)
                                CallGL_REJ_ALL(systemdate, batchno, gUserLogin)

                                clsBusiness.gLastErrMessage = "Call GL"
                                InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                                '-- 8. GenValidateReport
                                GenValidationReport(systemdate)
                                'GenValidationReport_TempPath(systemdate)

                                clsBusiness.gLastErrMessage = "Generate validation report"
                                InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                                '-- 9. SendEmailSCBLife
                                '------------SendEmail("ERR_AUTOBATCH")-----------
                                Dim strSendEmailResult As String
                                strSendEmailResult = SendEmailSCBLife("ERR_BY_VALIDATE")

                                clsBusiness.gLastErrMessage = strSendEmailResult
                                InsertTransLog("TLM Manual Close Batch, ", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                            End If

                            clsBusiness.gLastErrMessage = "TLM manual close batch complete"
                            InsertTransLog("TLM Manual Close Batch,", systemdate, batchno, Now.ToString("HH:mm:ss"), "COMPLETE", dataCM + dataRJ)

                            MsgBox("Manual close batch finish.", MsgBoxStyle.Information, Label4.Text)

                        Else 'Validate
                            StopWorker()
                            clsBusiness.gLastErrMessage = "Can not validate data!"
                            InsertTransLog(systemdate, batchno, s_systemtime, "INCOMPLETE", 0)

                            MsgBox(clsBusiness.gLastErrMessage & vbCrLf & "Please contact GPSA administrator.", MsgBoxStyle.Information, Label4.Text)

                        End If
                    Else 'Totemp
                        oleTrans.Rollback()

                        StopWorker()
                        clsBusiness.gLastErrMessage = "Can not insert data to temp"
                        InsertTransLog(systemdate, batchno, s_systemtime, "INCOMPLETE", 0)

                        MsgBox(clsBusiness.gLastErrMessage & vbCrLf & "Please contact GPSA administrator.", MsgBoxStyle.Information, Label4.Text)

                    End If


                Catch ex As Exception
                    StopWorker()

                    MsgBox(ex.Message & vbCrLf & "Please contact GPSA administrator.", MsgBoxStyle.Information, Label4.Text)
                    'InsertTransLog(systemdate, batchno, s_systemtime, "INCOMPLETE", 0)
                End Try


            End If


        End If

    End Sub
    Function GetPaymentRecord(ByVal systemdate) As Integer

        Dim sb As New StringBuilder()

        sb.Append("select count(*) rec ")
        sb.Append("from gps_payment_creation p inner join gps_transref_rel t ")
        sb.Append("on p.gpcr_createdate=t.tref_createdate ")
        sb.Append("and p.gpcr_core_system=t.tref_core_system ")
        sb.Append("and p.gpcr_transref=t.tref_transref ")
        sb.Append("where t.tref_approvedby is not null ")
        sb.Append("and t.tref_flag_batch='N' ")
        sb.Append("and t.tref_approveddate = '" & systemdate & "' ")
        sb.Append("and t.tref_paycretyp_id='003' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)("rec").ToString()
        Else
            Return 0
        End If


    End Function
    Function UpdatePaymentReject() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND CREATEDBY= '" & gUserLogin & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPCR_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPCR_CREATEDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPCR_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPCR_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPCR_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()

            Else
                oleTrans.Rollback()

            End If

        End If
    End Function
    Function UpdateWHTReject() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND CREATEDBY= '" & gUserLogin & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_CREATION SET TAXCR_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXCR_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXCR_CREATEDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXCR_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXCR_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXCR_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()

            Else
                oleTrans.Rollback()

            End If

        End If
    End Function
    Function UpdateFlag_manual(ByVal systemdate As String) As Boolean

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chkTranref, chkPayment, chkWHT, chkGL As Boolean

        chkPayment = UpdateFlagPayment(oleTrans, systemdate)
        chkWHT = UpdateFlagWHT(oleTrans, systemdate)
        chkTranref = UpdateFlagTransRef(oleTrans, systemdate)
        chkGL = UpdateFlagGL(oleTrans, systemdate)
        If chkTranref And chkPayment And chkWHT And chkGL Then
            oleTrans.Commit()

            Return True
        Else
            oleTrans.Rollback()

            Return False
        End If

    End Function
    Function UpdateFlagTransRef_manual(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("WHERE T.CREATEDBY='" & gUserLogin & "'   ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.TREF_BATCH_NO=T.GP_BATCH_NO, ")
        sb.Append("A.TREF_FLAG_BATCH='Y',   ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagGL(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_GL_CREATION A    ")
        sb.Append("USING     ")
        sb.Append("(    ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R  ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE  ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM  ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF  ")
        sb.Append("WHERE T.CREATEDBY='" & gUserLogin & "'    ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")
        sb.Append(") T ON (   ")
        sb.Append("A.GLCR_CREATEDATE=T.TREF_CREATEDATE   ")
        sb.Append("AND A.GLCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM   ")
        sb.Append("AND A.GLCR_TRANSREF=T.TREF_TRANSREF   ")
        sb.Append(")     ")
        sb.Append("WHEN MATCHED THEN UPDATE     ")
        sb.Append("SET A.GLCR_FLAG_BATCH='Y',    ")
        sb.Append("A.GLCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagPayment(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT_CREATION A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("WHERE T.CREATEDBY='" & gUserLogin & "'   ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.GPCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.GPCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.GPCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.GPCR_FLAG_BATCH='Y',   ")
        sb.Append("A.GPCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagWHT(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_WHT_CREATION A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("WHERE T.CREATEDBY='" & gUserLogin & "'   ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TAXCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TAXCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TAXCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.TAXCR_FLAG_BATCH='Y',   ")
        sb.Append("A.TAXCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Private Sub InsertTransLog(ByVal systemdate As String, ByVal batchno As String, ByVal s_systemtime As String, ByVal status As String, ByVal total_rec As Integer)
        Dim oleTrans As OleDbTransaction


        Dim e_systemtime As String

        'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        e_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)


        Dim sb As New StringBuilder
        Dim rec As Integer

        oleTrans = clsUtility.gConnGP.BeginTransaction()


        sb.Append("INSERT INTO GPS_TRANSLOG( ")
        sb.Append("TRAN_DATE,")
        sb.Append("TRAN_FUNCTION,")
        sb.Append("TRAN_BATCH_ID,")
        sb.Append("TRAN_S_TIME,")
        sb.Append("TRAN_E_TIME,")
        sb.Append("TRAN_RECORD,")
        sb.Append("TRAN_BATCH_TYPE,")
        sb.Append("TRAN_STATUS,")
        sb.Append("TRAN_REMARK,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & systemdate & "',")
        sb.Append("'MANUAL BATCH',")
        sb.Append("'" & batchno & "',")
        sb.Append("'" & s_systemtime & "',")
        sb.Append("'" & e_systemtime & "',")
        sb.Append("'" & total_rec & "',")
        sb.Append("'M',")
        sb.Append("'" & status & "',")
        sb.Append("'" & clsBusiness.gLastErrMessage & "',")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()

        Else
            oleTrans.Rollback()

        End If

    End Sub
    Function InsertPaymentReject_manual(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_REJ( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE, ")
        sb.Append("GP_WLSTT_SUBTYPE, ")
        sb.Append("CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'")
        sb.Append("AND CREATEDBY='" & gUserLogin & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTReject_manual(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_REJ ( ")
        sb.Append("TAXRJ_BATCHDATE,")
        sb.Append("TAXRJ_BATCH_NO,")
        sb.Append("TAXRJ_CREATEDATE,")
        sb.Append("TAXRJ_CORE_SYSTEM,")
        sb.Append("TAXRJ_TRANSREF,")
        sb.Append("TAXRJ_GPTREF_SEQNO,")
        sb.Append("TAXRJ_LINENO,")
        sb.Append("TAXRJ_TAXID,")
        sb.Append("TAXRJ_IDCARD,")
        sb.Append("TAXRJ_AP_TTL,")
        sb.Append("TAXRJ_AP_FNAME,")
        sb.Append("TAXRJ_AP_LNAME,")
        sb.Append("TAXRJ_ADDRESS,")
        sb.Append("TAXRJ_AMPENM,")
        sb.Append("TAXRJ_PROVNM,")
        sb.Append("TAXRJ_AGZIP,")
        sb.Append("TAXRJ_TAXTYPE,")
        sb.Append("TAXRJ_TAXITEM,")
        sb.Append("TAXRJ_TAXDATE,")
        sb.Append("TAXRJ_BASE_AMT,")
        sb.Append("TAXRJ_TAX_AMT,")
        sb.Append("TAXRJ_PAYEE,")
        sb.Append("TAXRJ_TAX_RATE,")
        sb.Append("TAXRJ_DESC,")
        sb.Append("TAXRJ_GL_ACCOUNT,")
        sb.Append("TAXRJ_REJECT_TYPE,")
        sb.Append("TAXRJ_REJECT_FUNC,")
        sb.Append("TAXRJ_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='INCOMPLETE' ")
        sb.Append("AND CREATEDBY='" & gUserLogin & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim dt As New DataTable
        'Dim systemdate As String '= Now.ToString("yyyyMMdd")
        'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        dt = GetData(systemdate)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            btnConfirm.Enabled = True
            Dim batchno As String
            batchno = clsBusiness.fnCallBatchNo(clsUtility.gConnGP, systemdate)
            txtBatchNo.Text = batchno
        End If
        GetDataToGrid(dt)

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click

        Me.Close()

    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)


        With DataGridView1

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray



        End With


        'Dim chk As New DataGridViewCheckBoxColumn
        'With chk
        '    DataGridView1.Columns.Add(chk)

        'End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .ReadOnly = True
            .DataPropertyName = "voucher_no"
            .Name = "Voucher No"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .ReadOnly = True
            .DataPropertyName = "transref"
            .Name = "Trans Ref."
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c2)
        End With
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .ReadOnly = True
            .DataPropertyName = "net_amt"
            .Name = "Net Amount"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c3)
        End With
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .ReadOnly = True
            .Visible = False
            .DataPropertyName = "tref_createdate"
            .Name = "createdate"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .ReadOnly = True
            .Visible = False
            .DataPropertyName = "tref_core_system"
            .Name = "core_system"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c5)
        End With

        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With
        DataGridView1.Columns(2).DefaultCellStyle.Format = "###,###.00" 'Net Amount
        DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click

        If txtBatchNo.Text.Trim <> "" Then
            PrintReport()
        End If

    End Sub
    Private Sub GenValidationReport_manual(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' and r.gprj_sub_paymth='M' then r.gprj_payee_bnkaccno else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_batchdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='M' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then


            Dim clsExportPDF As New clsCrystalToPDFConverter

            Dim path As String
            path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")

            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
            clsExportPDF.SetPdfDestinationFilePath(path & "RptErrorByValidation_" & systemdate & ".pdf")

            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")

            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)
        End If
    End Sub
    Function fnStrSql(ByVal batchdate As String) As StringBuilder
        Dim sb As New StringBuilder()

        sb.Append("select 'Complete' As BatchStatus,'PAY' as maingroup, A.gpcm_batchdate As batch_date, A.gpcm_batch_no As batch_no, A.gpcm_core_system As core_system, A.gpcm_paymth AS paymth, A.gpcm_sub_paymth As sub_paymth, A.gpcm_paymth||A.gpcm_sub_paymth||B.Payt_Paytype as Payt_Paytype,   ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt , NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.GPCM_AMOUNT) AS Net_AMOUNT, Count(A.gpcm_batchdate) As No_Record  ")
        sb.Append("from GPS_PAYMENT_COMPLETE A LEFT JOIN GPS_TL_PAYTYPE B ON A.gpcm_paymth=B.PAYT_PAYMTH AND  ")
        sb.Append("A.gpcm_sub_paymth=B.PAYT_SUB_PAYMTH  ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gpcm_core_system=D.CSYS_CORE_SYSTEM  ")
        sb.Append("LEFT JOIN (select t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH,  ")
        sb.Append("sum(t.taxcm_base_amt) As taxcm_base_amt, sum(t.taxcm_tax_amt) As taxcm_tax_amt   ")
        sb.Append("from GPS_WHT_COMPLETE t left join GPS_TRANSREF_REL u ON t.taxcm_createdate=u.tref_CREATEDATE AND  ")
        sb.Append("t.taxcm_core_system=u.tref_core_system AND  ")
        sb.Append("t.taxcm_transref=u.tref_transref  ")
        sb.Append("where t.TAXCM_BATCHDATE='" & batchdate & "'   ")
        sb.Append("group by t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G   ")
        sb.Append("ON A.gpcm_batchdate=G.TAXCM_BATCHDATE AND  ")
        sb.Append("A.gpcm_batch_no=G.TAXCM_BATCH_NO AND  ")
        sb.Append("A.gpcm_core_system=G.TAXCM_CORE_SYSTEM AND   ")
        sb.Append("A.gpcm_paymth=G.TREF_PAYMTH AND  ")
        sb.Append("A.gpcm_sub_paymth=G.TREF_SUB_PAYMTH  ")
        sb.Append("where A.gpcm_batchdate='" & batchdate & "'  And A.gpcm_batch_no='" & txtBatchNo.Text.Trim & "'   ")
        sb.Append("and A.gpcm_batchtype='M'  ")
        sb.Append("Group by A.gpcm_batchdate, A.gpcm_batch_no, A.gpcm_core_system, A.gpcm_paymth, A.gpcm_sub_paymth, B.Payt_Paytype,   ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("union ")

        'sb.Append("select 'InComplete' As BatchStatus,'PAY' as maingroup, A.gprj_batchdate As batch_date, A.gprj_batch_no As batch_no, A.gprj_core_system As core_system, A.gprj_paymth AS paymth, A.gprj_sub_paymth As sub_paymth, A.gprj_paymth||A.gprj_sub_paymth||B.Payt_Paytype as Payt_Paytype,   ")
        'sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt, NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.gprj_AMOUNT) AS Net_AMOUNT, Count(A.gprj_batchdate) As No_Record  ")
        'sb.Append("from GPS_PAYMENT_REJ A LEFT JOIN GPS_TL_PAYTYPE B ON A.gprj_paymth=B.PAYT_PAYMTH AND  ")
        'sb.Append("A.gprj_sub_paymth=B.PAYT_SUB_PAYMTH  ")
        'sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP  ")
        'sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gprj_core_system=D.CSYS_CORE_SYSTEM  ")
        'sb.Append("LEFT JOIN (select t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH,  ")
        'sb.Append("sum(t.taxcm_base_amt) As taxcm_base_amt, sum(t.taxcm_tax_amt) As taxcm_tax_amt   ")
        'sb.Append("from GPS_WHT_COMPLETE t left join GPS_TRANSREF_REL u ON t.taxcm_createdate=u.tref_CREATEDATE AND  ")
        'sb.Append("t.taxcm_core_system=u.tref_core_system AND  ")
        'sb.Append("t.taxcm_transref=u.tref_transref                            ")
        'sb.Append("where t.TAXCM_BATCHDATE='" & batchdate & "'   ")
        'sb.Append("group by t.TAXCM_BATCHDATE, t.TAXCM_BATCH_NO, t.TAXCM_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G   ")
        'sb.Append("ON A.gprj_batchdate=G.TAXCM_BATCHDATE AND  ")
        'sb.Append("A.gprj_batch_no=G.TAXCM_BATCH_NO AND  ")
        'sb.Append("A.gprj_core_system=G.TAXCM_CORE_SYSTEM AND   ")
        'sb.Append("A.gprj_paymth=G.TREF_PAYMTH AND  ")
        'sb.Append("A.gprj_sub_paymth=G.TREF_SUB_PAYMTH   ")
        'sb.Append("where A.gprj_batchdate='" & batchdate & "'  And A.gprj_batch_no='" & txtBatchNo.Text.Trim & "' and  A.gprj_reject_type <>'BANK' And  A.gprj_BATCHTYPE='M'  ")
        'sb.Append("Group by A.gprj_batchdate, A.gprj_batch_no, A.gprj_core_system, A.gprj_paymth, A.gprj_sub_paymth, B.Payt_Paytype,   ")
        'sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        sb.Append("select 'InComplete' As BatchStatus,'PAY' as maingroup, A.gprj_batchdate As batch_date, A.gprj_batch_no As batch_no, A.gprj_core_system As core_system, A.gprj_paymth AS paymth, A.gprj_sub_paymth As sub_paymth, A.gprj_paymth||A.gprj_sub_paymth||B.Payt_Paytype as Payt_Paytype,    ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, NVL(G.taxcm_base_amt,0) as taxcm_base_amt, NVL(G.taxcm_tax_amt,0) as taxcm_tax_amt, SUM(A.gprj_AMOUNT) AS Net_AMOUNT, Count(A.gprj_batchdate) As No_Record   ")
        sb.Append("from GPS_PAYMENT_REJ A LEFT JOIN GPS_TL_PAYTYPE B ON A.gprj_paymth=B.PAYT_PAYMTH AND   ")
        sb.Append("A.gprj_sub_paymth=B.PAYT_SUB_PAYMTH   ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP C ON B.PAYT_PAY_GROUP=C.PAYG_PAY_GROUP   ")
        sb.Append("LEFT JOIN GPS_TL_CORE_SYSTEM D ON A.gprj_core_system=D.CSYS_CORE_SYSTEM   ")
        sb.Append("LEFT JOIN (select t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH,   ")
        sb.Append("sum(t.taxrj_base_amt) As taxcm_base_amt, sum(t.taxrj_tax_amt) As taxcm_tax_amt    ")
        sb.Append("from GPS_WHT_REJ t left join GPS_TRANSREF_REL u ON t.taxrj_createdate=u.tref_CREATEDATE AND   ")
        sb.Append("t.taxrj_core_system=u.tref_core_system AND   ")
        sb.Append("t.taxrj_transref=u.tref_transref                             ")
        sb.Append("where t.TAXRJ_BATCHDATE='" & batchdate & "'   ")
        sb.Append("group by t.TAXRJ_BATCHDATE, t.TAXRJ_BATCH_NO, t.TAXRJ_CORE_SYSTEM, u.TREF_PAYMTH, u.TREF_SUB_PAYMTH) G    ")
        sb.Append("ON A.gprj_batchdate=G.TAXRJ_BATCHDATE AND   ")
        sb.Append("A.gprj_batch_no=G.TAXRJ_BATCH_NO AND   ")
        sb.Append("A.gprj_core_system=G.TAXRJ_CORE_SYSTEM AND    ")
        sb.Append("A.gprj_paymth=G.TREF_PAYMTH AND   ")
        sb.Append("A.gprj_sub_paymth=G.TREF_SUB_PAYMTH    ")
        sb.Append("where A.gprj_batchdate='" & batchdate & "'  ")
        sb.Append("And A.gprj_batch_no='" & txtBatchNo.Text.Trim & "' and  A.gprj_reject_type <>'BANK' And  A.gprj_BATCHTYPE='M'   ")
        sb.Append("Group by A.gprj_batchdate, A.gprj_batch_no, A.gprj_core_system, A.gprj_paymth, A.gprj_sub_paymth, B.Payt_Paytype,    ")
        sb.Append("C.PAYG_PAY_GROUP, C.PAYG_PAY_GROUPNAME, D.CSYS_CORE_SYSTEMNAME, G.taxcm_base_amt, G.taxcm_tax_amt ")

        Return sb

    End Function
    Function GetDataReport(ByVal batchdate As String) As DataTable
        Dim sb As New StringBuilder()


        sb.Append(fnStrSql(batchdate).ToString)

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryBatch.rpt")

        Dim dt As DataTable = New DataTable()

        'Dim systemdate As String
        'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        dt = GetDataReport(systemdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pHeader"
            discrete1.Value = "��§ҹ Summary ��¡�è��»Դ Batch (��ǹ�ѭ��) - Case ��觴�ǹ"
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        End If
    End Sub
    Function ValidateData(ByVal systemdate As String, ByVal batchno As String) As Boolean

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Function
            End If
        End If

        Dim TOTAL_REC As Integer
        Dim PAMT_NOMAT As Integer
        Dim PDTE_NOMAT As Integer
        Dim DUPT_ERR As Integer
        Dim TAMT_NOMAT As Integer
        Dim TREF_ERR As Integer
        Dim WLST_ERR As Integer
        Dim CHAR_ERR As Integer
        Dim PDTE_ERR As Integer
        Dim PAMT_ERR As Integer
        Dim BKCD_ERR As Integer
        Dim BKAC_ERR As Integer
        Dim ACNM_ERR As Integer
        Dim PAYEE_ERR As Integer
        Dim LENGT_ERR As Integer
        Dim ADDR_ERR As Integer
        Dim MCHN_ERR As Integer
        Dim NB_CANCEL As Integer
        Dim status As String
        Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

        '--------------fValidateNetAmountNotMatch--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAMT_NOMAT = Validate_1(clsUtility.gConnGP_2, oleTrans, systemdate, "PAMT_NOMAT")
        TOTAL_REC = PAMT_NOMAT
        If PAMT_NOMAT = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", batchno, Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatePaidDateNotMatch--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PDTE_NOMAT = Validate_2(clsUtility.gConnGP_2, oleTrans, systemdate, "PDTE_NOMAT")
        TOTAL_REC = TOTAL_REC + PDTE_NOMAT
        If PDTE_NOMAT = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidateDuplicateTransRef--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        DUPT_ERR = Validate_3(clsUtility.gConnGP_2, oleTrans, systemdate, "DUPT_ERR")
        TOTAL_REC = TOTAL_REC + DUPT_ERR
        If DUPT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        '�Ѵ�͡ 2015/02/14
        '' ''--------------fValidateWHTAmountNotMatch--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'TAMT_NOMAT = Validate_4(clsUtility.gConnGP_2, oleTrans, systemdate, "TAMT_NOMAT")
        'TOTAL_REC = TOTAL_REC + TAMT_NOMAT
        'If TAMT_NOMAT = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()

        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()

        'End If

        'clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        'InsertTransLog("VALIDATE", batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidateTransrefError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        TREF_ERR = Validate_5(clsUtility.gConnGP_2, oleTrans, systemdate, "TREF_ERR")
        TOTAL_REC = TOTAL_REC + TREF_ERR
        If TREF_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        '���ͧ�ҡ�ա�� Validate ���˹�� Creation ���Ǩ֧�Ѵ�͡

        ' '' ''--------------fValidatWatchLists--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'WLST_ERR = Validate_6(clsUtility.gConnGP_2, oleTrans, systemdate, "WLST_ERR")
        'TOTAL_REC = TOTAL_REC + WLST_ERR
        'If WLST_ERR = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()

        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()

        'End If

        'clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        'InsertTransLog("VALIDATE", batchno, Now.ToString("HH:mm:ss"), status, 0)

        '�Ѵ�͡ 2015/02/14
        '' ''--------------fValidatSpecialCharacterError--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'CHAR_ERR = Validate_7(clsUtility.gConnGP_2, oleTrans, systemdate, "CHAR_ERR")
        'TOTAL_REC = TOTAL_REC + CHAR_ERR
        'If CHAR_ERR = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()

        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()

        'End If

        'clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        'InsertTransLog("VALIDATE", batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidatePaidDateError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PDTE_ERR = Validate_8(clsUtility.gConnGP_2, oleTrans, systemdate, "PDTE_ERR")
        TOTAL_REC = TOTAL_REC + PDTE_ERR
        If PDTE_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidatePaidAmountError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAMT_ERR = Validate_9(clsUtility.gConnGP_2, oleTrans, systemdate, "PAMT_ERR")
        TOTAL_REC = TOTAL_REC + PAMT_ERR
        If PAMT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidateBankCodeError--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'BKCD_ERR = Validate_10_1(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        'TOTAL_REC = TOTAL_REC + BKCD_ERR
        'If BKCD_ERR = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()
        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()
        'End If

        ''clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        ''InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateBankCodeError--------------
        'oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        'BKCD_ERR = Validate_10_2(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        'TOTAL_REC = TOTAL_REC + BKCD_ERR
        'If BKCD_ERR = 1 Then
        '    status = "COMPLETE"
        '    oleTrans.Commit()
        'Else
        '    status = "INCOMPLETE"
        '    oleTrans.Rollback()
        'End If

        ''clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        ''InsertTransLog("VALIDATE", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), status, 0)


        ''-----��� Validate Bank Acc ��͹ Bank Code--------------

        ''--------------fValidateBankAccountError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        BKAC_ERR = Validate_11(clsUtility.gConnGP_2, oleTrans, systemdate, "BKAC_ERR")
        TOTAL_REC = TOTAL_REC + BKAC_ERR
        If BKAC_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)


        ''--------------fValidateBankCodeError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        BKCD_ERR = Validate_10(clsUtility.gConnGP_2, oleTrans, systemdate, "BKCD_ERR")
        TOTAL_REC = TOTAL_REC + BKCD_ERR
        If BKCD_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)


        ''--------------fValidateBankAccountNameError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        ACNM_ERR = Validate_12(clsUtility.gConnGP_2, oleTrans, systemdate, "ACNM_ERR")
        TOTAL_REC = TOTAL_REC + ACNM_ERR
        If ACNM_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        '--------------fValidatePayeeNameError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        PAYEE_ERR = Validate_13(clsUtility.gConnGP_2, oleTrans, systemdate, "PAYEE_ERR")
        TOTAL_REC = TOTAL_REC + PAYEE_ERR
        If PAYEE_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidatePayeeLengthFieldError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        LENGT_ERR = Validate_14(clsUtility.gConnGP_2, oleTrans, systemdate, "LENGT_ERR")
        TOTAL_REC = TOTAL_REC + LENGT_ERR
        If LENGT_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateAddressError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        ADDR_ERR = Validate_15(clsUtility.gConnGP_2, oleTrans, systemdate, "ADDR_ERR")
        TOTAL_REC = TOTAL_REC + ADDR_ERR
        If ADDR_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ''--------------fValidateMerchantError--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        MCHN_ERR = Validate_16(clsUtility.gConnGP_2, oleTrans, systemdate, "MCHN_ERR")
        TOTAL_REC = TOTAL_REC + MCHN_ERR
        If MCHN_ERR = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)

        ' ''--------------fValidateNBCancel--------------
        oleTrans = clsUtility.gConnGP_2.BeginTransaction()
        NB_CANCEL = Validate_17(clsUtility.gConnGP_2, oleTrans, systemdate, "NB_CANCEL")
        TOTAL_REC = TOTAL_REC + NB_CANCEL
        If NB_CANCEL = 1 Then
            status = "COMPLETE"
            oleTrans.Commit()

        Else
            status = "INCOMPLETE"
            oleTrans.Rollback()

        End If

        clsBusiness.gLastErrMessage = "Validate_" & TOTAL_REC
        InsertTransLog("VALIDATE", systemdate, batchno, Now.ToString("HH:mm:ss"), status, 0)


        If TOTAL_REC = 14 Then
            'oleTrans.Commit()
            Return True
        Else
            'oleTrans.Rollback()
            Return False
        End If

    End Function
    Function Validate_1(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateNetAmountNotMatch_NORMAL(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows

                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_2(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidDateNotMatch_NORMAL(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_3(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim dt2 As New DataTable
        Dim r_payment As Integer
        Dim i_chk As Integer
        Dim r_wht As Integer
        dt = cls.fValidateDuplicateTransRef_1_NORMAL(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows

                dt2 = cls.fValidateDuplicateTransRef_2(clsUtility.gConnGP, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                If Not IsNothing(dt2) AndAlso dt2.Rows.Count > 0 Then

                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
                    i_chk = i_chk + 1

                Else
                    Return 1
                End If

            Next

            If (r_payment = i_chk) And (r_wht = i_chk) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_4(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateWHTAmountNotMatch_NORMAL(clsUtility.gConnGP, batchdate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_5(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidateTransrefError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows


                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"))
            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_6(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_rej As Integer
        Dim r_aml As Integer
        Dim i_rej As Integer
        Dim i_aml As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer

        dt = cls.fValidatWatchLists_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            For Each dr As DataRow In dt.Rows

                'Data Reject 
                Dim dt_wl As New DataTable
                dt_wl = cls.CHECK_WATCHLIST_FOR_REJ(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString.Replace(" ", ""))


                'Data AML
                Dim dt_aml As New DataTable
                dt_aml = cls.CHECK_WATCHLIST_FOR_AML(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString.Replace(" ", ""))


                If Not IsNothing(dt_wl) AndAlso dt_wl.Rows.Count > 0 Then


                    Dim chk_effdate As Boolean
                    chk_effdate = cls.CHECK_WATCHLIST_EFFDATE(clsUtility.gConnGP, dr("GP_PAYEE_NAME").ToString, batchdate)


                    If chk_effdate = False Then


                        r_rej = r_rej + cls.UPD_WATCHLIST_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"), dt_wl.Rows(0)("WLSTT_TYPE"), dt_wl.Rows(0)("WLST_SUBTYPE_CODE"))
                        i_rej = i_rej + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1

                    End If

                End If


                If Not IsNothing(dt_aml) AndAlso dt_aml.Rows.Count > 0 Then

                    r_aml = r_aml + cls.UPD_WATCHLIST_AML(oConn, oleTrans, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"), dt_aml.Rows(0)("WLSTT_TYPE"), dt_aml.Rows(0)("WLST_SUBTYPE_CODE"))
                    i_aml = i_aml + 1

                End If

            Next

            If (r_rej = i_rej) And (r_aml = i_aml) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

        Return 1
    End Function
    Function Validate_7(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim dt_char As New DataTable
        Dim r_err As Integer
        dt = cls.fValidatSpecialCharacterError_NORMAL(clsUtility.gConnGP)
        dt_char = cls.GetSpecialCharacter(clsUtility.gConnGP)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim txt_payeename As String
                Dim txt_address As String
                Dim txt_district As String
                Dim txt_province As String
                Dim txt_payee_bnkname As String

                txt_payeename = dr("GP_PAYEE_NAME").ToString.Trim
                txt_address = dr("GP_ADDRESS1").ToString.Trim
                txt_district = dr("GP_DISTRICT").ToString.Trim
                txt_province = dr("GP_PROVINCE").ToString.Trim
                txt_payee_bnkname = dr("GP_PAYEE_BNKACCNME").ToString.Trim

                For Each dr_char As DataRow In dt_char.Rows
                    If InStr(txt_payeename, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_payeename = txt_payeename.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PAYEE_NAME", txt_payeename, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_address, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_address = txt_address.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_ADDRESS1", txt_address, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_district, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_district = txt_district.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_DISTRICT", txt_district, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_province, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_province = txt_province.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PROVINCE", txt_province, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                    If InStr(txt_payee_bnkname, dr_char("SPE_CHAR").ToString.Trim) > 0 Then
                        txt_payee_bnkname = txt_payee_bnkname.Replace(dr_char("SPE_CHAR").ToString.Trim, " ")
                        r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, "GP_PAYEE_BNKACCNME", txt_payee_bnkname, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        If r_err < 0 Then
                            r_err = -1
                            Exit Function
                        End If
                    End If
                Next
            Next

            If (r_err >= 0) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_8(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim i_payment As Integer
        Dim i_wht As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidDateError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            For Each dr As DataRow In dt.Rows
                If CheckDate(dr("GP_PAIDDATE"), batchdate) Then

                    Select Case dr("PAYT_PAY_GROUP")
                        Case "SCB_NET"
                            If Convert.ToInt32(dr("GP_PAIDDATE")) >= Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                If chk_holiday Then
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1

                                End If
                            Else
                                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_payment += 1

                                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_wht = i_wht + 1
                            End If
                        Case "SCBLIFE_CHQ"
                            If Convert.ToInt32(dr("GP_PAIDDATE")) < Convert.ToInt32(batchdate) Then
                                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_payment += 1

                                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_wht = i_wht + 1
                            End If

                        Case "OVERSEA"
                            If Convert.ToInt32(dr("GP_PAIDDATE")) >= Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                If chk_holiday Then
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1

                                End If
                            Else
                                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_payment += 1

                                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_wht = i_wht + 1
                            End If
                        Case "ATS", "CREDIT_CARD"
                            If Convert.ToInt32(dr("GP_PAIDDATE")) > Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday_SCB(clsUtility.gConnGP, dr("GP_PAIDDATE"))
                                If chk_holiday Then
                                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_payment += 1

                                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                    i_wht = i_wht + 1

                                End If
                            Else
                                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_payment += 1

                                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                                i_wht = i_wht + 1
                            End If

                    End Select

                Else 'format <> "CCYYYMMDD" 
                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_payment += 1

                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_wht = i_wht + 1
                End If

            Next

            If (r_payment = i_payment) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_9(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim r_wht As Integer
        dt = cls.fValidatePaidAmountError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))

            Next

            If (r_payment = dt.Rows.Count) And (r_wht = dt.Rows.Count) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_10_1(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim v1, v2 As Integer

        v1 = cls.UPD_VALIDATE10_1_NORMAL(oConn, oleTrans, errtype)
        v2 = cls.UPD_VALIDATE10_2(oConn, oleTrans, errtype)

        If (v1 = 1 And v2 = 1) Then
            ' oleTrans.Commit()
            Return 1
        Else
            'oleTrans.Rollback()
            clsBusiness.gLastErrMessage = errtype
            Return 0
        End If


    End Function
    Function Validate_10_2(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim v3, v4 As Integer

        v3 = cls.UPD_VALIDATE10_3(oConn, oleTrans, errtype)
        v4 = cls.UPD_VALIDATE10_4(oConn, oleTrans, errtype)

        If (v3 = 1 And v4 = 1) Then
            ' oleTrans.Commit()
            Return 1
        Else
            'oleTrans.Rollback()
            clsBusiness.gLastErrMessage = errtype
            Return 0
        End If


    End Function
    Function Validate_10(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankCodeError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim chk As Boolean
                chk = cls.CHK_BKMST_BNKCODE(clsUtility.gConnGP, dr("GP_BNKCODE_NO").ToString)
                If chk Then

                    If dr("GP_PAYMTH") = "C" Or dr("GP_PAYMTH") = "D" Then
                        Dim chk2 As Boolean
                        chk2 = cls.CHK_BNKS_BNKSCODE_NO(clsUtility.gConnGP, dr("PAYT_PAY_GROUP"), dr("GP_BNKCODE_NO"))

                        If chk2 = False Then

                            'MsgBox("CHK_BNKS_BNKSCODE_NO" & "/" & dr("PAYT_PAY_GROUP") & "/" & dr("GP_BNKCODE_NO"))

                            r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            c_err += 1

                            r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            i_wht = i_wht + 1

                            'Dim s_systemtime As String
                            's_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
                            'clsBusiness.gLastErrMessage = "CHK_BNKS_BNKSCODE_NO" & "/" & dr("PAYT_PAY_GROUP") & "/" & dr("GP_BNKCODE_NO")
                            'InsertTransLog("AUTO BATCH", Now.ToString("yyyyMMdd"), "", s_systemtime, "INCOMPLETE", 0)
                        End If
                    End If

                Else
                    'MsgBox("CHK_BKMST_BNKCODE" & "/" & dr("GP_BNKCODE_NO").ToString)

                    r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    c_err += 1

                    r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                    i_wht = i_wht + 1


                    'Dim s_systemtime As String
                    's_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(), 8)
                    'clsBusiness.gLastErrMessage = "CHK_BKMST_BNKCODE" & "/" & dr("GP_BNKCODE_NO").ToString
                    'InsertTransLog("AUTO BATCH", Now.ToString("yyyyMMdd"), "", s_systemtime, "INCOMPLETE", 0)

                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_11(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankAccountError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            For Each dr As DataRow In dt.Rows

                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_12(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateBankAccountNameError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            For Each dr As DataRow In dt.Rows
                If dr("GP_PAYMTH") = "M" Then
                    If dr("GP_PAYEE_BNKACCNME").ToString.Trim = "" Or IsDBNull(dr("GP_PAYEE_BNKACCNME")) Then
                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        c_err = c_err + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1

                    End If
                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                ' oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_13(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidatePayeeNameError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                If dr("GP_PAYMTH") = "C" Or dr("GP_PAYMTH") = "D" Then
                    If dr("GP_PAYEE_NAME").ToString.Trim = "" Or IsDBNull(dr("GP_PAYEE_NAME")) Then
                        r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        c_err = c_err + 1

                        r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                        i_wht = i_wht + 1
                    End If
                End If

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_14(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidatePayeeLengthFieldError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_15(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateAddressError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim pay_subpay As String
                pay_subpay = dr("GP_PAYMTH") & ":" & dr("GP_SUB_PAYMTH")
                Select Case pay_subpay
                    Case "D:D" ', "C:H", "C:Q", "C:T", "C:B"
                        If dr("ADDRESS").ToString.Trim = "" Or IsDBNull(dr("ADDRESS")) Then
                            r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            c_err += 1

                            r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                            i_wht = i_wht + 1
                        End If
                End Select

            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_16(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateMerchantError_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Function Validate_17(ByVal oConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal errtype As String) As Integer
        Dim dt As New DataTable
        Dim r_payment As Integer
        Dim c_err As Integer
        Dim r_wht As Integer
        Dim i_wht As Integer
        dt = cls.fValidateNBCancel_NORMAL(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            'Dim oleTrans As OleDbTransaction
            'oleTrans = clsUtility.gConnGP_2.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_payment = r_payment + cls.UPD_PAYMENT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                c_err += 1

                r_wht = r_wht + cls.UPD_WHT_REJ(oConn, oleTrans, errtype, dr("GP_CREATEDATE"), dr("GP_CORE_SYSTEM"), dr("GP_TRANSREF"), dr("GP_GPTREF_SEQNO"))
                i_wht = i_wht + 1
            Next

            If (r_payment = c_err) And (r_wht = i_wht) Then
                'oleTrans.Commit()
                Return 1
            Else
                'oleTrans.Rollback()
                clsBusiness.gLastErrMessage = errtype
                Return 0
            End If
        Else
            Return 1
        End If

    End Function
    Public Function CheckDate(ByVal dateString As String, ByVal systemdate As String) As Boolean

        Dim formats As String = "yyyyMMdd"
        Dim dateValue As DateTime

        Select Case Convert.ToInt16(dateString.Substring(0, 4))
            Case Convert.ToInt16(systemdate.Substring(0, 4))
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Convert.ToInt16(systemdate.Substring(0, 4)) + 1
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Else
                Return False
        End Select

    End Function

    Function InsertToTempPayment_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_PAYMENT ( ")
        sb.Append("GP_BATCHDATE,")
        sb.Append("GP_BATCH_NO,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_DESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_FLAG_VALIDATE,")
        sb.Append("GP_REJECT_TYPE,")
        sb.Append("GP_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE, ")
        sb.Append("GP_FLAG_CC,")
        sb.Append("GP_CC_APPROVEDBY) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("GPCR_CREATEDATE, ")
        sb.Append("GPCR_CORE_SYSTEM, ")
        sb.Append("GPCR_TRANSREF, ")
        sb.Append("GPCR_GPTREF_SEQNO, ")
        sb.Append("GPCR_POLNO, ")
        sb.Append("GPCR_BILLNO, ")
        sb.Append("GPCR_PAIDDATE, ")
        sb.Append("GPCR_AMOUNT, ")
        sb.Append("GPCR_DESC, ")
        sb.Append("GPCR_PAYMTH, ")
        sb.Append("GPCR_PAYEE_NAME, ")
        sb.Append("GPCR_BNKCODE, ")
        sb.Append("GPCR_BNKCODE_NO, ")
        sb.Append("GPCR_BNKBRN, ")
        sb.Append("GPCR_BNKNAME, ")
        sb.Append("GPCR_PAYEE_BNKACCNO, ")
        sb.Append("GPCR_PAYEE_BNKACCNME, ")
        sb.Append("GPCR_COMMENT, ")
        sb.Append("GPCR_ADDRESS1, ")
        sb.Append("GPCR_DISTRICT, ")
        sb.Append("GPCR_PROVINCE, ")
        sb.Append("GPCR_INSURENAME, ")
        sb.Append("GPCR_DATASOURCE_NME, ")
        sb.Append("GPCR_Reserve6, ")
        sb.Append("GPCR_MERCHN_NO, ")
        sb.Append("GPCR_CDCARD_DATE, ")
        sb.Append("GPCR_Reserve9, ")
        sb.Append("GPCR_Reserve10, ")
        sb.Append("GPCR_SYS_REF, ")
        sb.Append("GPCR_SYS_GR, ")
        sb.Append("GPCR_SUB_PAYMTH, ")
        sb.Append("GPCR_FLAG_FLWBILL, ")
        sb.Append("GPCR_OSEA_LIST, ")
        sb.Append("GPCR_PHONE, ")
        sb.Append("GPCR_FAX, ")
        sb.Append("GPCR_SWIFT_CODE, ")
        sb.Append("GPCR_BNKBRN_NAME, ")
        sb.Append("GPCR_BNKADDR, ")
        sb.Append("GPCR_COUNTRY, ")
        sb.Append("GPCR_CURRENCY, ")
        sb.Append("GPCR_EXCHN_RATE, ")
        sb.Append("GPCR_BNKCHARGES, ")
        '--sb.Append("'COMPLETE', ")
        '--sb.Append("'', ")

        '-- sb.Append("'COMPLETE', ")
        sb.Append("GPCR_FLAG_VALIDATE, ")
        '-- sb.Append("'', ")
        sb.Append("GPCR_REJECT_TYPE, ")

        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'), ")
        sb.Append("GPCR_fLAG_CC, ")
        sb.Append("GPCR_CC_APPROVEDBY ")
        sb.Append("FROM GPS_PAYMENT_CREATION WHERE GPCR_APPROVEDDATE IS NOT NULL ")
        sb.Append("AND GPCR_FLAG_BATCH='N' AND GPCR_APPROVEDDATE = '" & systemdate & "' ")
        sb.Append("AND GPCR_TRANSREF NOT IN (SELECT DISTINCT T.TREF_TRANSREF FROM GPS_TRANSREF_REL t WHERE T.TREF_CREATEDATE = '" & systemdate & "' AND T.TREF_PAYCRETYP_ID = '003' GROUP BY T.TREF_TRANSREF) ")
        sb.Append("   AND GPCR_FLAG_VALIDATE = 'COMPLETE' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertToTempWHT_TLM(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String, ByVal batchno As String) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_TMP_WHT( ")
        sb.Append("TAX_BATCHDATE,")
        sb.Append("TAX_BATCH_NO,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_FLAG_VALIDATE,")
        sb.Append("TAX_REJECT_TYPE,")
        sb.Append("TAX_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("'" & systemdate & "', ")
        sb.Append("'" & batchno & "', ")
        sb.Append("TAXCR_CREATEDATE, ")
        sb.Append("TAXCR_CORE_SYSTEM, ")
        sb.Append("TAXCR_TRANSREF, ")
        sb.Append("TAXCR_GPTREF_SEQNO, ")
        sb.Append("TAXCR_LINENO, ")
        sb.Append("TAXCR_TAXID, ")
        sb.Append("TAXCR_IDCARD, ")
        sb.Append("TAXCR_AP_TTL, ")
        sb.Append("TAXCR_AP_FNAME, ")
        sb.Append("TAXCR_AP_LNAME, ")
        sb.Append("TAXCR_ADDRESS, ")
        sb.Append("TAXCR_AMPENM, ")
        sb.Append("TAXCR_PROVNM, ")
        sb.Append("TAXCR_AGZIP, ")
        sb.Append("TAXCR_TAXTYPE, ")
        sb.Append("TAXCR_TAXITEM, ")
        sb.Append("TAXCR_TAXDATE, ")
        sb.Append("TAXCR_BASE_AMT, ")
        sb.Append("TAXCR_TAX_AMT, ")
        sb.Append("TAXCR_PAYEE, ")
        sb.Append("TAXCR_TAX_RATE, ")
        sb.Append("TAXCR_DESC, ")
        sb.Append("TAXCR_GL_ACCOUNT, ")
        '--sb.Append("'COMPLETE', ")
        '--sb.Append("'', ")

        sb.Append("TAXCR_FLAG_VALIDATE, ")
        sb.Append("TAXCR_REJECT_TYPE, ")

        sb.Append("'A', ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_WHT_CREATION WHERE TAXCR_APPROVEDDATE IS NOT NULL  ")
        sb.Append("AND TAXCR_FLAG_BATCH='N' AND TAXCR_APPROVEDDATE = '" & systemdate & "' ")
        sb.Append("AND TAXCR_TRANSREF NOT IN (SELECT DISTINCT T.TREF_TRANSREF FROM GPS_TRANSREF_REL t WHERE T.TREF_CREATEDATE = '" & systemdate & "' AND T.TREF_PAYCRETYP_ID = '003' GROUP BY T.TREF_TRANSREF) ")
        sb.Append("   AND TAXCR_FLAG_VALIDATE = 'COMPLETE' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub InsertTransLog(ByVal fn As String, ByVal systemdate As String, ByVal batchno As String, ByVal s_systemtime As String, ByVal status As String, ByVal total_rec As Integer)
        Dim oleTrans As OleDbTransaction

        Dim e_systemtime As String

        'systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        e_systemtime = Now.ToString("HH:mm:ss")
        'e_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)


        'Dim total_rec, total_creation, total_load As Integer
        'total_creation = GetPaymentCreationRecord(systemdate)
        'total_load = GetPaymentLoadRecord(systemdate)

        'total_rec = total_creation + total_load

        Dim sb As New StringBuilder
        Dim rec As Integer

        'oleTrans = clsUtility.gConnGP.BeginTransaction()


        sb.Append("INSERT INTO GPS_TRANSLOG( ")
        sb.Append("TRAN_DATE,")
        sb.Append("TRAN_FUNCTION,")
        sb.Append("TRAN_BATCH_ID,")
        sb.Append("TRAN_S_TIME,")
        sb.Append("TRAN_E_TIME,")
        sb.Append("TRAN_RECORD,")
        sb.Append("TRAN_BATCH_TYPE,")
        sb.Append("TRAN_STATUS,")
        sb.Append("TRAN_REMARK,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & fn & "',")
        sb.Append("'" & batchno & "',")
        sb.Append("'" & s_systemtime & "',")
        sb.Append("'" & e_systemtime & "',")
        sb.Append("'" & total_rec & "',")
        sb.Append("'A',")
        sb.Append("'" & status & "',")
        sb.Append("'" & clsBusiness.gLastErrMessage & "',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP_2, sb, oleTrans)

        If rec >= 0 Then
            'oleTrans.Commit()
        Else
            'oleTrans.Rollback()
        End If

    End Sub

    Function InsertDataToTemp(ByVal systemdate As String, ByVal batchno As String, ByVal oleTrans As OleDbTransaction) As Boolean
        Dim insPaymentTLM, insWHTTLM As Boolean
        Dim strStatus As String
        strStatus = "2.0"
        '--oleTrans = clsUtility.gConnGP.BeginTransaction()
        strStatus = "2.1"
        insPaymentTLM = InsertToTempPayment_TLM(oleTrans, systemdate, batchno)
        strStatus = "2.2"
        insWHTTLM = InsertToTempWHT_TLM(oleTrans, systemdate, batchno)
        strStatus = "2.3"
        If insPaymentTLM = False Then
            clsBusiness.gLastErrMessage = "err insert TLM to gps_tmp_payment"
            InsertTransLog("TLM Manual Close Batch, PAYMENT TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        Else
            InsertTransLog("TLM Manual Close Batch, PAYMENT TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "COMPLETE", 0)
        End If
        strStatus = "2.4"
        If insWHTTLM = False Then
            clsBusiness.gLastErrMessage = "err insert TLM to gps_wht_payment"
            InsertTransLog("TLM Manual Close Batch, WHT TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
        Else
            InsertTransLog("TLM Manual Close Batch, WHT TO TEMP", Now.ToString("yyyyMMdd"), "", Now.ToString("HH:mm:ss"), "COMPLETE", 0)
        End If
        strStatus = "2.5"
        If insPaymentTLM And insWHTTLM Then
            '--oleTrans.Commit()
            strStatus = "2.5.1"
            Return True
        Else
            '--oleTrans.Rollback()
            strStatus = "2.5.2"
            Return False
        End If
    End Function

    Function Call_GPS_SP_VALIDATE_AUTO(ByVal batchdate As String) As Integer
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP_2.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate
        dbComm.Parameters.Add("v_error", OleDbType.VarChar, 100).Direction = ParameterDirection.Output


        dbComm.CommandText = "GPS_SP_VALIDATE_AUTO"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("v_error").Value


    End Function

    Function ValidateDataTemp(ByVal systemdate) As Boolean
        Dim ret As Integer

        ret = Call_GPS_SP_VALIDATE_AUTO(systemdate)

        If ret >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function chkDataComplete(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='COMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If


    End Function

    Function chkDataReject(ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder
        sb.Append("SELECT COUNT(*) REC FROM ")
        sb.Append("(SELECT GP_TRANSREF AS TRANSREF FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'  ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT TAX_TRANSREF AS TRANSREF FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' ) A ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP_2, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0))
        Else
            Return 0
        End If

    End Function

    Private Sub GenValidationReport(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        Dim clsExportPDF As New clsCrystalToPDFConverter
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then

            Try


                clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
                '-- clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf")

                Dim strFileName As String = "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf"

                Dim strFileFrom As String = "D:\" & strFileName
                clsExportPDF.SetPdfDestinationFilePath(strFileFrom)

                Dim lstname As New ArrayList
                Dim lstvalue As New ArrayList

                lstname.Add("pTransdate")
                lstname.Add("pUser")

                lstvalue.Add(systemdate)
                lstvalue.Add(gUserFullName)

                clsExportPDF.ExportReport(dt, lstname, lstvalue)
                clsExportPDF = Nothing

                Dim strFileTo As String = ValidationReportPath & strFileName 

                ''--If System.IO.File.Exists(strFileFrom) Then
                ''--    '-- MsgBox("System.IO.File.Exists(strFileFrom)=True")
                ''--    My.Computer.FileSystem.MoveFile(strFileFrom, strFileTo)
                ''--    If System.IO.File.Exists(strFileTo) Then
                ''--        '-- MsgBox("System.IO.File.Exists(strFileTo)=True")
                ''--    Else
                ''--        '-- MsgBox("System.IO.File.Exists(strFileTo)=False")
                ''--    End If
                ''--Else
                ''--    '-- MsgBox("System.IO.File.Exists(strFileFrom)=False")
                ''--End If

                '-- If clsUtility.BackupFile(strFileFrom, strFileTo) Then
                If clsUtility.BackupFile(strFileFrom, strFileTo) Then
                    If System.IO.File.Exists(strFileTo) Then
                        My.Computer.FileSystem.DeleteFile(strFileFrom)
                    End If
                End If

                clsBusiness.gLastErrMessage = "Generate validation report success."
                InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "COMPLETE", 0)

            Catch ex As Exception

                clsBusiness.gLastErrMessage = ex.Message
                InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "ERROR", 0)

            End Try
        End If
    End Sub

    Private Sub GenValidationReport_RunAs(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        Dim clsExportPDF As New clsCrystalToPDFConverter
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then

            Try


                clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
                clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf")

                Dim lstname As New ArrayList
                Dim lstvalue As New ArrayList

                lstname.Add("pTransdate")
                lstname.Add("pUser")

                lstvalue.Add(systemdate)
                lstvalue.Add(gUserFullName)

                clsExportPDF.ExportReport(dt, lstname, lstvalue)

                clsBusiness.gLastErrMessage = "Generate validation report success."
                InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "COMPLETE", 0)

            Catch ex As Exception

                clsBusiness.gLastErrMessage = ex.Message
                InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "ERROR", 0)

            End Try
        End If
    End Sub

    Private Sub GenValidationReport_TempPath(ByVal systemdate As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As DataTable
        Dim clsExportPDF As New clsCrystalToPDFConverter
        Dim strPathTemp As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\"
        strPathTemp = "D\"
        Dim strPDFDestinationFilePath As String
        Dim strServerPath As String

        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then

            Try


                clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
                ''clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf")
                strPDFDestinationFilePath = strPathTemp & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf"
                strServerPath = ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf"
                clsExportPDF.SetPdfDestinationFilePath(strPDFDestinationFilePath)

                Dim lstname As New ArrayList
                Dim lstvalue As New ArrayList

                lstname.Add("pTransdate")
                lstname.Add("pUser")

                lstvalue.Add(systemdate)
                lstvalue.Add(gUserFullName)

                clsExportPDF.ExportReport(dt, lstname, lstvalue)

                If File.Exists(strPDFDestinationFilePath) Then

                    File.Move(""" & strPDFDestinationFilePath & """, """ & strServerPath & """)

                    If File.Exists(strServerPath) Then
                        clsBusiness.gLastErrMessage = "Generate validation report success."
                        InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "COMPLETE", 0)
                    Else
                        clsBusiness.gLastErrMessage = "Can not generate validation report!"
                        InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
                    End If
                Else
                    clsBusiness.gLastErrMessage = "Can not generate validation report!"
                    InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "INCOMPLETE", 0)
                End If


            Catch ex As Exception

                clsBusiness.gLastErrMessage = ex.Message
                InsertTransLog("GenValidationReport", systemdate, Now.ToString("HH:mm:ss"), "ERROR", 0)

            End Try
        End If
    End Sub

    Function InsertTableAML(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chk As Boolean

        chk = InsertAML(oleTrans)

        If chk Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function

    Function InsertAML(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_AML( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE ,")
        sb.Append("GP_WLSTT_SUBTYPE ,")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_WLSTT_TYPE='AML' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function

    Function InsertPaymentComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_COMPLETE( ")
        sb.Append("GPCM_BATCHDATE,")
        sb.Append("GPCM_BATCH_NO,")
        sb.Append("GPCM_CREATEDATE,")
        sb.Append("GPCM_CORE_SYSTEM,")
        sb.Append("GPCM_TRANSREF,")
        sb.Append("GPCM_GPTREF_SEQNO,")
        sb.Append("GPCM_POLNO,")
        sb.Append("GPCM_BILLNO,")
        sb.Append("GPCM_PAIDDATE,")
        sb.Append("GPCM_AMOUNT,")
        sb.Append("GPCM_DESC,")
        sb.Append("GPCM_PAYMTH,")
        sb.Append("GPCM_PAYEE_NAME,")
        sb.Append("GPCM_BNKCODE,")
        sb.Append("GPCM_BNKCODE_NO,")
        sb.Append("GPCM_BNKBRN,")
        sb.Append("GPCM_BNKNAME,")
        sb.Append("GPCM_PAYEE_BNKACCNO,")
        sb.Append("GPCM_PAYEE_BNKACCNME,")
        sb.Append("GPCM_COMMENT,")
        sb.Append("GPCM_ADDRESS1,")
        sb.Append("GPCM_DISTRICT,")
        sb.Append("GPCM_PROVINCE,")
        sb.Append("GPCM_INSURENAME,")
        sb.Append("GPCM_DATASOURCE_NME,")
        sb.Append("GPCM_RESERVE6,")
        sb.Append("GPCM_MERCHN_NO,")
        sb.Append("GPCM_CDCARD_DATE,")
        sb.Append("GPCM_RESERVE9,")
        sb.Append("GPCM_RESERVE10,")
        sb.Append("GPCM_SYS_REF,")
        sb.Append("GPCM_SYS_GR,")
        sb.Append("GPCM_SUB_PAYMTH,")
        sb.Append("GPCM_FLAG_FLWBILL,")
        sb.Append("GPCM_OSEA_LIST,")
        sb.Append("GPCM_PHONE,")
        sb.Append("GPCM_FAX,")
        sb.Append("GPCM_SWIFT_CODE,")
        sb.Append("GPCM_BNKBRN_NAME,")
        sb.Append("GPCM_BNKADDR,")
        sb.Append("GPCM_COUNTRY,")
        sb.Append("GPCM_CURRENCY,")
        sb.Append("GPCM_EXCHN_RATE,")
        sb.Append("GPCM_BNKCHARGES,")
        sb.Append("GPCM_BATCHTYPE,")
        sb.Append("GPCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='COMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTComplete(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_COMPLETE( ")
        sb.Append("TAXCM_BATCHDATE,")
        sb.Append("TAXCM_BATCH_NO,")
        sb.Append("TAXCM_CREATEDATE,")
        sb.Append("TAXCM_CORE_SYSTEM,")
        sb.Append("TAXCM_TRANSREF,")
        sb.Append("TAXCM_GPTREF_SEQNO,")
        sb.Append("TAXCM_LINENO,")
        sb.Append("TAXCM_TAXID,")
        sb.Append("TAXCM_IDCARD,")
        sb.Append("TAXCM_AP_TTL,")
        sb.Append("TAXCM_AP_FNAME,")
        sb.Append("TAXCM_AP_LNAME,")
        sb.Append("TAXCM_ADDRESS,")
        sb.Append("TAXCM_AMPENM,")
        sb.Append("TAXCM_PROVNM,")
        sb.Append("TAXCM_AGZIP,")
        sb.Append("TAXCM_TAXTYPE,")
        sb.Append("TAXCM_TAXITEM,")
        sb.Append("TAXCM_TAXDATE,")
        sb.Append("TAXCM_BASE_AMT,")
        sb.Append("TAXCM_TAX_AMT,")
        sb.Append("TAXCM_PAYEE,")
        sb.Append("TAXCM_TAX_RATE,")
        sb.Append("TAXCM_DESC,")
        sb.Append("TAXCM_GL_ACCOUNT,")
        sb.Append("TAXCM_BATCHTYPE,")
        sb.Append("TAXCM_FLAG_CONFIRMPAY,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'N',")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='COMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertTableComplete(ByVal oleTrans As OleDbTransaction) As Boolean


        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentComplete(oleTrans)
        chkWHT = InsertWHTComplete(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

    End Function
    Function InsertTableReject(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chkPayment, chkWHT As Boolean

        chkPayment = InsertPaymentReject(oleTrans)
        chkWHT = InsertWHTReject(oleTrans)

        If chkPayment And chkWHT Then

            Return True
        Else

            Return False
        End If

        'End If
    End Function

    Function InsertPaymentReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_PAYMENT_REJ( ")
        sb.Append("GPRJ_BATCHDATE,")
        sb.Append("GPRJ_BATCH_NO,")
        sb.Append("GPRJ_CREATEDATE,")
        sb.Append("GPRJ_CORE_SYSTEM,")
        sb.Append("GPRJ_TRANSREF,")
        sb.Append("GPRJ_GPTREF_SEQNO,")
        sb.Append("GPRJ_POLNO,")
        sb.Append("GPRJ_BILLNO,")
        sb.Append("GPRJ_PAIDDATE,")
        sb.Append("GPRJ_AMOUNT,")
        sb.Append("GPRJ_DESC,")
        sb.Append("GPRJ_PAYMTH,")
        sb.Append("GPRJ_PAYEE_NAME,")
        sb.Append("GPRJ_BNKCODE,")
        sb.Append("GPRJ_BNKCODE_NO,")
        sb.Append("GPRJ_BNKBRN,")
        sb.Append("GPRJ_BNKNAME,")
        sb.Append("GPRJ_PAYEE_BNKACCNO,")
        sb.Append("GPRJ_PAYEE_BNKACCNME,")
        sb.Append("GPRJ_COMMENT,")
        sb.Append("GPRJ_ADDRESS1,")
        sb.Append("GPRJ_DISTRICT,")
        sb.Append("GPRJ_PROVINCE,")
        sb.Append("GPRJ_INSURENAME,")
        sb.Append("GPRJ_DATASOURCE_NME,")
        sb.Append("GPRJ_RESERVE6,")
        sb.Append("GPRJ_MERCHN_NO,")
        sb.Append("GPRJ_CDCARD_DATE,")
        sb.Append("GPRJ_RESERVE9,")
        sb.Append("GPRJ_RESERVE10,")
        sb.Append("GPRJ_SYS_REF,")
        sb.Append("GPRJ_SYS_GR,")
        sb.Append("GPRJ_SUB_PAYMTH,")
        sb.Append("GPRJ_FLAG_FLWBILL,")
        sb.Append("GPRJ_OSEA_LIST,")
        sb.Append("GPRJ_PHONE,")
        sb.Append("GPRJ_FAX,")
        sb.Append("GPRJ_SWIFT_CODE,")
        sb.Append("GPRJ_BNKBRN_NAME,")
        sb.Append("GPRJ_BNKADDR,")
        sb.Append("GPRJ_COUNTRY,")
        sb.Append("GPRJ_CURRENCY,")
        sb.Append("GPRJ_EXCHN_RATE,")
        sb.Append("GPRJ_BNKCHARGES,")
        sb.Append("GPRJ_REJECT_TYPE,")
        sb.Append("GPRJ_REJECT_FUNC,")
        sb.Append("GPRJ_BATCHTYPE,")
        sb.Append("GPRJ_WLSTT_TYPE,")
        sb.Append("GPRJ_WLSTT_SUBTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("GP_BATCHDATE, ")
        sb.Append("GP_BATCH_NO, ")
        sb.Append("GP_CREATEDATE, ")
        sb.Append("GP_CORE_SYSTEM, ")
        sb.Append("GP_TRANSREF, ")
        sb.Append("GP_GPTREF_SEQNO, ")
        sb.Append("GP_POLNO, ")
        sb.Append("GP_BILLNO, ")
        sb.Append("GP_PAIDDATE, ")
        sb.Append("GP_AMOUNT, ")
        sb.Append("GP_DESC, ")
        sb.Append("GP_PAYMTH, ")
        sb.Append("GP_PAYEE_NAME, ")
        sb.Append("GP_BNKCODE, ")
        sb.Append("GP_BNKCODE_NO, ")
        sb.Append("GP_BNKBRN, ")
        sb.Append("GP_BNKNAME, ")
        sb.Append("GP_PAYEE_BNKACCNO, ")
        sb.Append("GP_PAYEE_BNKACCNME, ")
        sb.Append("GP_COMMENT, ")
        sb.Append("GP_ADDRESS1, ")
        sb.Append("GP_DISTRICT, ")
        sb.Append("GP_PROVINCE, ")
        sb.Append("GP_INSURENAME, ")
        sb.Append("GP_DATASOURCE_NME, ")
        sb.Append("GP_RESERVE6, ")
        sb.Append("GP_MERCHN_NO, ")
        sb.Append("GP_CDCARD_DATE, ")
        sb.Append("GP_RESERVE9, ")
        sb.Append("GP_RESERVE10, ")
        sb.Append("GP_SYS_REF, ")
        sb.Append("GP_SYS_GR, ")
        sb.Append("GP_SUB_PAYMTH, ")
        sb.Append("GP_FLAG_FLWBILL, ")
        sb.Append("GP_OSEA_LIST, ")
        sb.Append("GP_PHONE, ")
        sb.Append("GP_FAX, ")
        sb.Append("GP_SWIFT_CODE, ")
        sb.Append("GP_BNKBRN_NAME, ")
        sb.Append("GP_BNKADDR, ")
        sb.Append("GP_COUNTRY, ")
        sb.Append("GP_CURRENCY, ")
        sb.Append("GP_EXCHN_RATE, ")
        sb.Append("GP_BNKCHARGES, ")
        sb.Append("GP_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("GP_BATCHTYPE, ")
        sb.Append("GP_WLSTT_TYPE, ")
        sb.Append("GP_WLSTT_SUBTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function InsertWHTReject(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_WHT_REJ ( ")
        sb.Append("TAXRJ_BATCHDATE,")
        sb.Append("TAXRJ_BATCH_NO,")
        sb.Append("TAXRJ_CREATEDATE,")
        sb.Append("TAXRJ_CORE_SYSTEM,")
        sb.Append("TAXRJ_TRANSREF,")
        sb.Append("TAXRJ_GPTREF_SEQNO,")
        sb.Append("TAXRJ_LINENO,")
        sb.Append("TAXRJ_TAXID,")
        sb.Append("TAXRJ_IDCARD,")
        sb.Append("TAXRJ_AP_TTL,")
        sb.Append("TAXRJ_AP_FNAME,")
        sb.Append("TAXRJ_AP_LNAME,")
        sb.Append("TAXRJ_ADDRESS,")
        sb.Append("TAXRJ_AMPENM,")
        sb.Append("TAXRJ_PROVNM,")
        sb.Append("TAXRJ_AGZIP,")
        sb.Append("TAXRJ_TAXTYPE,")
        sb.Append("TAXRJ_TAXITEM,")
        sb.Append("TAXRJ_TAXDATE,")
        sb.Append("TAXRJ_BASE_AMT,")
        sb.Append("TAXRJ_TAX_AMT,")
        sb.Append("TAXRJ_PAYEE,")
        sb.Append("TAXRJ_TAX_RATE,")
        sb.Append("TAXRJ_DESC,")
        sb.Append("TAXRJ_GL_ACCOUNT,")
        sb.Append("TAXRJ_REJECT_TYPE,")
        sb.Append("TAXRJ_REJECT_FUNC,")
        sb.Append("TAXRJ_BATCHTYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("SELECT  ")
        sb.Append("TAX_BATCHDATE, ")
        sb.Append("TAX_BATCH_NO, ")
        sb.Append("TAX_CREATEDATE, ")
        sb.Append("TAX_CORE_SYSTEM, ")
        sb.Append("TAX_TRANSREF, ")
        sb.Append("TAX_GPTREF_SEQNO, ")
        sb.Append("TAX_LINENO, ")
        sb.Append("TAX_TAXID, ")
        sb.Append("TAX_IDCARD, ")
        sb.Append("TAX_AP_TTL, ")
        sb.Append("TAX_AP_FNAME, ")
        sb.Append("TAX_AP_LNAME, ")
        sb.Append("TAX_ADDRESS, ")
        sb.Append("TAX_AMPENM, ")
        sb.Append("TAX_PROVNM, ")
        sb.Append("TAX_AGZIP, ")
        sb.Append("TAX_TAXTYPE, ")
        sb.Append("TAX_TAXITEM, ")
        sb.Append("TAX_TAXDATE, ")
        sb.Append("TAX_BASE_AMT, ")
        sb.Append("TAX_TAX_AMT, ")
        sb.Append("TAX_PAYEE, ")
        sb.Append("TAX_TAX_RATE, ")
        sb.Append("TAX_DESC, ")
        sb.Append("TAX_GL_ACCOUNT, ")
        sb.Append("TAX_REJECT_TYPE, ")
        sb.Append("'VALIDATE', ")
        sb.Append("TAX_BATCHTYPE, ")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'SYSTEM' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("FROM GPS_TMP_WHT WHERE  TAX_FLAG_VALIDATE='INCOMPLETE' ")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Function UpdateFlag(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        '--Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chkTranref, chkPayment, chkTranref_nonpay As Boolean

        chkPayment = UpdateFlagPayment_CR(oleTrans, systemdate)
        chkTranref = UpdateFlagTransRef(oleTrans, systemdate)
        chkTranref_nonpay = UpdateFlagTransRef_NONPAY(oleTrans, systemdate)

        'chkWHT = UpdateFlagWHT_CR(oleTrans, systemdate)
        'chk_gl = UpdateFlagGL_CR(oleTrans, systemdate)

        If chkTranref And chkPayment And chkTranref_nonpay Then
            oleTrans.Commit()
            Return True
        Else
            oleTrans.Rollback()
            Return False
        End If

    End Function
    Function UpdateFlag_GL(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk_gl As Boolean

        chk_gl = UpdateFlagGL_CR(systemdate, oleTrans)

        If chk_gl Then
            Return True
        Else
            Return False
        End If

    End Function
    Function UpdateFlag_TAX(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk, chknonpay As Boolean

        chk = UpdateFlagTAX_CR(systemdate, oleTrans)

        chknonpay = UpdateFlagTAX_CR_NONPAY(systemdate, oleTrans)

        If chk And chknonpay Then
            Return True
        Else
            Return False
        End If

    End Function

    Function UpdateFlagTransRef(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(")    ")
        sb.Append("WHEN MATCHED THEN UPDATE    ")
        sb.Append("SET A.TREF_BATCH_NO=T.GP_BATCH_NO, ")
        sb.Append("A.TREF_BATCHTYPE='A',   ")
        sb.Append("A.TREF_FLAG_BATCH='Y',   ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagTransRef_NONPAY(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_TRANSREF_REL A    ")
        sb.Append("USING     ")
        sb.Append("(    ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R  ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE  ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM  ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF  ")
        sb.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        sb.Append(") T ON (   ")
        sb.Append("A.TREF_CREATEDATE=T.TREF_CREATEDATE   ")
        sb.Append("AND A.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM   ")
        sb.Append("AND A.TREF_TRANSREF=T.TREF_TRANSREF   ")
        sb.Append(")     ")
        sb.Append("WHEN MATCHED THEN UPDATE     ")
        sb.Append("SET A.TREF_BATCH_NO=T.TAX_BATCH_NO,  ")
        sb.Append("A.TREF_BATCHTYPE='A',    ")
        sb.Append("A.TREF_FLAG_BATCH='Y',    ")
        sb.Append("A.TREF_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagPayment_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT_CREATION A   ")
        sb.Append("USING    ")
        sb.Append("(   ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.GPCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.GPCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.GPCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.GPCR_FLAG_BATCH='Y', ")
        sb.Append("A.GPCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function
    Function UpdateFlagWHT_CR(ByVal oleTrans As OleDbTransaction, ByVal systemdate As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_WHT_CREATION A ")
        sb.Append("USING ")
        sb.Append("( ")
        sb.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF ")
        'sb.Append("WHERE R.TREF_PAYCRETYP_ID='006' ")
        sb.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO ")
        sb.Append(") T ON (  ")
        sb.Append("A.TAXCR_CREATEDATE=T.TREF_CREATEDATE  ")
        sb.Append("AND A.TAXCR_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
        sb.Append("AND A.TAXCR_TRANSREF=T.TREF_TRANSREF  ")
        sb.Append(") ")
        sb.Append("WHEN MATCHED THEN UPDATE ")
        sb.Append("SET A.TAXCR_FLAG_BATCH='Y', ")
        sb.Append("A.TAXCR_BATCHDATE='" & systemdate & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
        Else
            Return False
            'oleTrans.Rollback()
        End If

    End Function

    Function UpdateFlagTAX_CR(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function
    Function UpdateFlagTAX_CR_NONPAY(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbChk As New StringBuilder()

        'sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        'sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        'sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        'sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        'sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        'sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        sbChk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO    ")
        sbChk.Append("FROM GPS_TMP_WHT T INNER JOIN GPS_TRANSREF_REL R    ")
        sbChk.Append("ON T.TAX_CREATEDATE=R.TREF_CREATEDATE    ")
        sbChk.Append("AND T.TAX_CORE_SYSTEM=R.TREF_CORE_SYSTEM    ")
        sbChk.Append("AND T.TAX_TRANSREF=R.TREF_TRANSREF AND T.TAX_BATCHDATE='" & systemdate & "'    ")
        sbChk.Append("AND R.TREF_PAYCRETYP_ID='006' ")
        sbChk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.TAX_BATCH_NO  ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbChk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_TAXCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function

    Public Function UPD_TAXCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_WHT_CREATION  ")
        sb.Append("SET TAXCR_FLAG_BATCH='Y', TAXCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE TAXCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND TAXCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND TAXCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Function UpdateFlagGL_CR(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction) As Boolean

        Dim r_chk As Integer
        Dim sbchk As New StringBuilder()

        sbchk.Append("SELECT R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO   ")
        sbchk.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R   ")
        sbchk.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE   ")
        sbchk.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM   ")
        sbchk.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF AND T.GP_BATCHDATE='" & systemdate & "'   ")
        sbchk.Append("GROUP BY R.TREF_CREATEDATE,R.TREF_CORE_SYSTEM,R.TREF_TRANSREF,T.GP_BATCH_NO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sbchk)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                r_chk = r_chk + UPD_GLCR(clsUtility.gConnGP, oleTrans, dr("TREF_CREATEDATE"), dr("TREF_CORE_SYSTEM"), dr("TREF_TRANSREF"), systemdate)
            Next

            If (r_chk = dt.Rows.Count) Then
                oleTrans.Commit()
                Return True
            Else
                oleTrans.Rollback()
                Return False
            End If

        End If

    End Function

    Function UpdatePaymentReject_CR(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_CREATION SET GPCR_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPCR_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPCR_CREATEDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPCR_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPCR_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPCR_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdatePaymentReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_PAYMENT WHERE GP_FLAG_VALIDATE='INCOMPLETE' AND GP_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_PAYMENT_LOAD SET GPLD_FLAG_VALIDATE= '" & dr("GP_FLAG_VALIDATE") & "'  ,")
                sb2.Append("GPLD_REJECT_TYPE= '" & dr("GP_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE GPLD_BATCHDATE = '" & dr("GP_CREATEDATE") & "' ")
                sb2.Append("AND GPLD_CORE_SYSTEM = '" & dr("GP_CORE_SYSTEM") & "' ")
                sb2.Append("AND GPLD_TRANSREF = '" & dr("GP_TRANSREF") & "' ")
                sb2.Append("AND GPLD_GPTREF_SEQNO = '" & dr("GP_GPTREF_SEQNO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_CR(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM <> 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            '--Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_CREATION SET TAXCR_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXCR_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXCR_CREATEDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXCR_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXCR_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXCR_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function
    Function UpdateWHTReject_LD() As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TMP_WHT WHERE TAX_FLAG_VALIDATE='INCOMPLETE' AND TAX_CORE_SYSTEM = 'PP'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count >= 0 Then
            Dim rec As Integer = 0
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                Dim sb2 As New StringBuilder

                sb2.Append("UPDATE GPS_WHT_LOAD SET TAXLD_FLAG_VALIDATE= '" & dr("TAX_FLAG_VALIDATE") & "'  ,")
                sb2.Append("TAXLD_REJECT_TYPE= '" & dr("TAX_REJECT_TYPE") & "'   ")
                sb2.Append("WHERE TAXLD_BATCHDATE = '" & dr("TAX_CREATEDATE") & "' ")
                sb2.Append("AND TAXLD_CORE_SYSTEM = '" & dr("TAX_CORE_SYSTEM") & "' ")
                sb2.Append("AND TAXLD_TRANSREF = '" & dr("TAX_TRANSREF") & "' ")
                sb2.Append("AND TAXLD_LINENO = '" & dr("TAX_LINENO") & "' ")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)


            Next

            If rec = dt.Rows.Count Then
                oleTrans.Commit()
            Else
                oleTrans.Rollback()
            End If

        End If
    End Function

    Function CallGL_REJ_PARTIAL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectpartial"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function
    Function CallGL_REJ_ALL(ByVal batchdate As String, ByVal batchno As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectall"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Function SendEmailSCBLife(ByVal mailfuction As String) As String
        Dim Email As New MailMessage()
        Try
            Dim SMTPServer As New SmtpClient

            'For Each Attachment As String In Attachments
            '    Email.Attachments.Add(New Attachment(Attachment))
            'Next
            'Email.From = New MailAddress("AutomaticValidateReject@scblife.com")
            'For Each Recipient As String In Recipients
            '    Email.To.Add(Recipient)
            'Next

            'For Each CC As String In CCs
            '    If Trim(CC) <> "" Then
            '        Email.CC.Add(CC)
            '    End If
            'Next

            Email.From = New MailAddress("AutomaticValidateReject@scblife.com")

            Dim dt As New DataTable
            dt = GetEmail(mailfuction)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

                For Each dr As DataRow In dt.Rows
                    Email.To.Add(dr("EMAIL_ADDRESS").ToString)
                Next

            End If
            Email.Subject = "Reject Payment Transaction by Validation  [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
            Email.Body = "����������¡�è������١��ͧ (Error by Validation) ú�ǹ��Ǩ�ͺ��� path : " & ValidationReportPath
            SMTPServer.Host = "mailsmtp.scnyl.local"
            SMTPServer.Port = 25
            ''SMTPServer.Credentials = New System.Net.NetworkCredential(UserName, Password)
            ''SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()
            Return "Complete"
        Catch ex As SmtpException
            Email.Dispose()
            Return "Sending Email Failed. Smtp Error."
        Catch ex As ArgumentOutOfRangeException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        Catch Ex As InvalidOperationException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        End Try
    End Function

    Function GetEmail(ByVal mailfuction As String) As DataTable
        Dim sb As New StringBuilder
        Dim email As String = ""
        sb.Append("SELECT EMAIL_ADDRESS FROM GPS_EMAIL_SETUP WHERE EMAIL_FUNC='" & mailfuction & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Return dt

    End Function

    Public Function UPD_GLCR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchdate As String, ByVal core_system As String, ByVal transref As String, ByVal systemdate As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_GL_CREATION  ")
        sb.Append("SET GLCR_FLAG_BATCH='Y', GLCR_BATCHDATE= '" & systemdate & "'  ")
        sb.Append("WHERE GLCR_CREATEDATE='" & batchdate & "'  ")
        sb.Append("AND GLCR_CORE_SYSTEM='" & core_system & "'   ")
        sb.Append("AND GLCR_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Function DeleteOldDataTemp(ByVal systemdate As String, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal transref As String) As Boolean
        Dim sb As New StringBuilder
        Dim d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14 As Boolean

        d7 = fnDelete(oleTrans, "delete from gps_tmp_payment ")

        d8 = fnDelete(oleTrans, "delete from gps_tmp_wht ")

        d9 = fnDelete(oleTrans, "delete from gps_payment_complete where gpcm_batchdate='" & systemdate & "' and gpcm_batchtype='A' and gpcm_batch_no = '" & batchno & "'")

        d10 = fnDelete(oleTrans, "delete from gps_wht_complete where taxcm_batchdate='" & systemdate & "' and taxcm_batchtype='A' and taxcm_batch_no = '" & batchno & "'")

        d11 = fnDelete(oleTrans, "delete from gps_payment_rej where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A' and (gprj_reject_type is null OR gprj_reject_type<>'BANK')  and gprj_batch_no = '" & batchno & "'")

        d12 = fnDelete(oleTrans, "delete from gps_wht_rej where taxrj_batchdate='" & systemdate & "' and taxrj_batchtype='A' and (taxrj_reject_type is null OR taxrj_reject_type<>'BANK')  and taxrj_batch_no = '" & batchno & "'")

        d13 = fnDelete(oleTrans, "delete from glm_gl_daily where gl_posting_date='" & systemdate & "' and gl_system_name='GPSA' and gl_transref = '" & transref & "' and gl_function = 'GP01' and upper(createdby) <> 'SYSTEM'")

        d14 = fnDelete(oleTrans, "delete from gps_aml where gprj_batchdate='" & systemdate & "' and gprj_batchtype='A'  and gprj_batch_no = '" & batchno & "'")

        If (d7 And d8 And d9 And d10 And d11 And d12 And d13 And d14) Then
            Return True
            'MsgBox("Update already")
        Else
            'MsgBox(clsBusiness.gLastErrMessage)
            Return False
        End If

    End Function

    Function fnDelete(ByVal oleTrans As OleDbTransaction, ByVal str As String) As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        sb.Append(str)

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function



    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        File.Move("d:\test.txt", "\\FAServe-1\Finance\Generate Payment\Sys Interface\Report\test.txt")
    End Sub
End Class