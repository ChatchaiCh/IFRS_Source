<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAgingPaymentReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpDate = New CustomControls.DatePicker()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.btnPrint = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtpDate
        '
        Me.dtpDate.Culture = New System.Globalization.CultureInfo("en-GB")
        Me.dtpDate.Location = New System.Drawing.Point(101, 15)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(105, 22)
        Me.dtpDate.TabIndex = 78
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(396, 38)
        Me.PanelH1.TabIndex = 101
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(3, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(384, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = " ��§ҹ Aging outstanding payment ����ѧ���֧ due ����"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(13, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "Business Date :"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.dtpDate)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(396, 54)
        Me.PanelD1.TabIndex = 104
        '
        'btnPrint
        '
        Me.btnPrint.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnPrint.Image = Nothing
        Me.btnPrint.ImageKey = ""
        Me.btnPrint.ImageList = Nothing
        Me.btnPrint.Location = New System.Drawing.Point(216, 116)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.Size = New System.Drawing.Size(92, 28)
        Me.btnPrint.TabIndex = 102
        Me.btnPrint.Text = "Print"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb2
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(314, 116)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(92, 28)
        Me.btnExit.TabIndex = 103
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmAgingPaymentReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 159)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.PanelH1)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.btnExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmAgingPaymentReport"
        Me.Text = "FrmAgingPaymentReport"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dtpDate As CustomControls.DatePicker
    Friend WithEvents btnPrint As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
