Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmSumWHTReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsWHT
    Private Sub FrmSumWHTReport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        txtPeriodFrom.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
        txtPeriodTo.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")

        txtWHTPeriodFrom.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
        txtWHTPeriodTo.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")

    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtPeriodFrom.Text.Trim = "" Or txtPeriodTo.Text.Trim = "" Then
            MsgBox("Please Enter Acc Period")
            Exit Sub
        End If

        If txtWHTPeriodFrom.Text.Trim = "" Or txtWHTPeriodTo.Text.Trim = "" Then
            MsgBox("Please Enter WHT Period")
            Exit Sub
        End If

        PrintReport()

    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryWHT.rpt")

        Dim pfrom, pto As String
        Dim whtpfrom, whtpto As String

        pfrom = txtPeriodFrom.Text.Trim.Substring(4, 4) & txtPeriodFrom.Text.Trim.Substring(0, 3)
        pto = txtPeriodTo.Text.Trim.Substring(4, 4) & txtPeriodTo.Text.Trim.Substring(0, 3)

        whtpfrom = txtWHTPeriodFrom.Text.Trim.Substring(4, 4) & txtWHTPeriodFrom.Text.Trim.Substring(0, 3)
        whtpto = txtWHTPeriodTo.Text.Trim.Substring(4, 4) & txtWHTPeriodTo.Text.Trim.Substring(0, 3)

        Dim dt As DataTable = New DataTable()

        'dt = cls.GetSummaryWHTReport(clsUtility.gConnGP, pfrom, pto)
        dt = cls.GetSummaryWHTReport(clsUtility.gConnGP, pfrom, pto, whtpfrom, whtpto)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)
      

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pHeader"
            'discrete1.Value = "��§ҹ Reject ��¡�è����Թ (Bankruptcy/CFT)"
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            param2.ParameterFieldName = "pTransDate"
            discrete2.Value = txtPeriodFrom.Text.Trim & " To " & txtPeriodTo.Text.Trim
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            Dim frm As New FrmSumWHTReport
            frm.TopLevel = False
            frm.Parent = FrmMainMenu.SplitContainer1.Panel2
            FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
            frm.Show()

            Me.Close()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
            ' dt = clsBusiness.DtEmptyRpt(clsUtility.gConnGP)
        End If

    End Sub

    Private Sub txtPeriodFrom_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPeriodFrom.KeyPress
        If e.KeyChar = "/"c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("/"c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
        'Dim i As Integer = txtPeriodFrom.Text.Length
        'If (i = 6) Then
        '    Try

        '        If InStr(1, txtPeriodFrom.Text, "/") = 0 Then
        '            Dim dateString As String = txtPeriodFrom.Text
        '            Dim formats As String = "MMyyyy"
        '            Dim dateValue As DateTime
        '            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
        '                txtPeriodFrom.Text = dateValue.ToString("MMM/yyyy").PadLeft(8, "0")
        '            Else
        '                MsgBox("Date Should Be Entered in Format MMM/yyyy")
        '                txtPeriodFrom.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
        '            End If
        '        End If
        '    Catch ex As Exception
        '        MsgBox(ex.Message & vbCrLf & "Date Should Be Entered in Format MMM/yyyy")
        '        txtPeriodFrom.Clear()
        '    End Try
        'End If
    End Sub

    Private Sub txtPeriodTo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPeriodTo.KeyPress
        If e.KeyChar = "/"c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("/"c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
        'Dim i As Integer = txtPeriodTo.Text.Length
        'If (i = 6) Then
        '    Try

        '        If InStr(1, txtPeriodTo.Text, "/") = 0 Then
        '            Dim dateString As String = txtPeriodTo.Text
        '            Dim formats As String = "MMyyyy"
        '            Dim dateValue As DateTime
        '            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
        '                txtPeriodTo.Text = dateValue.ToString("MMM/yyyy").PadLeft(8, "0")
        '            Else
        '                MsgBox("Date Should Be Entered in Format MMM/yyyy")
        '                txtPeriodTo.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
        '            End If
        '        End If
        '    Catch ex As Exception
        '        MsgBox(ex.Message & vbCrLf & "Date Should Be Entered in Format MMM/yyyy")
        '        txtPeriodTo.Clear()
        '    End Try
        'End If
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtWHTPeriodFrom_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtWHTPeriodFrom.KeyPress
        If e.KeyChar = "/"c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("/"c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub

    Private Sub txtWHTPeriodTo_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtWHTPeriodTo.KeyPress
        If e.KeyChar = "/"c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("/"c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub
End Class