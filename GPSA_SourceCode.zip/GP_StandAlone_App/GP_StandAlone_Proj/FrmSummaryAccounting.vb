Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmSummaryAccounting
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub FrmSummaryAccounting_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
        ControlStyle()

        ListSection()
    End Sub
    Private Sub ListSection()
        Dim sb As New StringBuilder()
        sb.Append("SELECT T.DTS_DEP_KEYIN,D.DEP_DEPNAME FROM GPS_TL_DATASOURCE T,GPS_TL_DEPARTMENT D  ")
        sb.Append("WHERE T.DTS_DEP_KEYIN = D.DEP_DEPCODE AND T.DTS_CORE_SYSTEM='ACC' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboSection
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
        cboSection.SelectedIndex = 0
    End Sub
    Private Sub CmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdOk.Click
        PrintReport()
    End Sub
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptSummaryAccounting.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pJournalType"
            'discrete1.Value = cboJournalType.Text
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            'param2.ParameterFieldName = "pTransdate"
            'discrete2.Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
            'param2.CurrentValues.Add(discrete2)
            'paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        End If
    End Sub
    Function GetDataGL() As DataTable
        Dim sb As New StringBuilder()

        'sb.Append("select * from gps_gl_creation t where t.glcr_duedate='" & dtpDueDate.Value.ToString("yyyyMMdd") & "'  ")

        'If cboSection.SelectedIndex <> 0 Then
        '    sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        'End If
        'If cboJournalType.SelectedIndex <> 0 Then
        '    sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        'End If

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    
End Class