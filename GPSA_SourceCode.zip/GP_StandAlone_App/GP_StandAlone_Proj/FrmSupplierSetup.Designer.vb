﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSupplierSetup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHead = New System.Windows.Forms.Label()
        Me.dgvSupplier = New System.Windows.Forms.DataGridView()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtsupp_code = New System.Windows.Forms.TextBox()
        Me.txtsupp_s_account = New System.Windows.Forms.TextBox()
        Me.txtsupp_name_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_name_tax = New System.Windows.Forms.TextBox()
        Me.txtsupp_taxid = New System.Windows.Forms.TextBox()
        Me.txtsupp_bnkcode_no_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_bnkaccno_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_address_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_address_tax = New System.Windows.Forms.TextBox()
        Me.txtsupp_tel_no = New System.Windows.Forms.TextBox()
        Me.txtsupp_date = New System.Windows.Forms.TextBox()
        Me.txtsupp_ampenm_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_provnm_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_agzip_gp = New System.Windows.Forms.TextBox()
        Me.txtsupp_ampenm_tax = New System.Windows.Forms.TextBox()
        Me.txtsupp_provnm_tax = New System.Windows.Forms.TextBox()
        Me.txtsupp_agzip_tax = New System.Windows.Forms.TextBox()
        Me.txtsupp_country = New System.Windows.Forms.TextBox()
        Me.txtsupp_fax_no = New System.Windows.Forms.TextBox()
        Me.txtsupp_status = New System.Windows.Forms.TextBox()
        CType(Me.dgvSupplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHead
        '
        Me.lblHead.AutoSize = True
        Me.lblHead.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblHead.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.lblHead.Location = New System.Drawing.Point(151, 9)
        Me.lblHead.Name = "lblHead"
        Me.lblHead.Size = New System.Drawing.Size(339, 17)
        Me.lblHead.TabIndex = 8
        Me.lblHead.Text = "Maintain ชื่อ-ที่อยู่ หนังสือรับรองภาษี (Master data)"
        Me.lblHead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dgvSupplier
        '
        Me.dgvSupplier.AllowUserToAddRows = False
        Me.dgvSupplier.AllowUserToDeleteRows = False
        Me.dgvSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSupplier.Location = New System.Drawing.Point(12, 37)
        Me.dgvSupplier.Name = "dgvSupplier"
        Me.dgvSupplier.ReadOnly = True
        Me.dgvSupplier.Size = New System.Drawing.Size(416, 372)
        Me.dgvSupplier.TabIndex = 9
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(820, 381)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 28)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(725, 381)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 28)
        Me.btnDelete.TabIndex = 12
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        Me.btnDelete.Visible = False
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(629, 381)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 28)
        Me.btnUpdate.TabIndex = 11
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(548, 381)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 28)
        Me.btnAdd.TabIndex = 10
        Me.btnAdd.Text = "&New"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(480, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "รหัส"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(480, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "S_Account"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(480, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "GP Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(480, 118)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "TAX Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(481, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "TAX ID"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(484, 170)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(101, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Bank Code(number)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(484, 196)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Bank Account"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(484, 222)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 13)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "GP Address"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(484, 248)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "TAX Address"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(484, 274)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Tel No"
        '
        'txtsupp_code
        '
        Me.txtsupp_code.Location = New System.Drawing.Point(587, 37)
        Me.txtsupp_code.MaxLength = 10
        Me.txtsupp_code.Name = "txtsupp_code"
        Me.txtsupp_code.Size = New System.Drawing.Size(117, 20)
        Me.txtsupp_code.TabIndex = 24
        '
        'txtsupp_s_account
        '
        Me.txtsupp_s_account.Location = New System.Drawing.Point(587, 63)
        Me.txtsupp_s_account.MaxLength = 10
        Me.txtsupp_s_account.Name = "txtsupp_s_account"
        Me.txtsupp_s_account.Size = New System.Drawing.Size(213, 20)
        Me.txtsupp_s_account.TabIndex = 25
        '
        'txtsupp_name_gp
        '
        Me.txtsupp_name_gp.Location = New System.Drawing.Point(587, 89)
        Me.txtsupp_name_gp.MaxLength = 100
        Me.txtsupp_name_gp.Name = "txtsupp_name_gp"
        Me.txtsupp_name_gp.Size = New System.Drawing.Size(213, 20)
        Me.txtsupp_name_gp.TabIndex = 26
        '
        'txtsupp_name_tax
        '
        Me.txtsupp_name_tax.Location = New System.Drawing.Point(587, 115)
        Me.txtsupp_name_tax.MaxLength = 100
        Me.txtsupp_name_tax.Name = "txtsupp_name_tax"
        Me.txtsupp_name_tax.Size = New System.Drawing.Size(213, 20)
        Me.txtsupp_name_tax.TabIndex = 27
        '
        'txtsupp_taxid
        '
        Me.txtsupp_taxid.Location = New System.Drawing.Point(587, 141)
        Me.txtsupp_taxid.MaxLength = 14
        Me.txtsupp_taxid.Name = "txtsupp_taxid"
        Me.txtsupp_taxid.Size = New System.Drawing.Size(117, 20)
        Me.txtsupp_taxid.TabIndex = 28
        '
        'txtsupp_bnkcode_no_gp
        '
        Me.txtsupp_bnkcode_no_gp.Location = New System.Drawing.Point(587, 167)
        Me.txtsupp_bnkcode_no_gp.MaxLength = 3
        Me.txtsupp_bnkcode_no_gp.Name = "txtsupp_bnkcode_no_gp"
        Me.txtsupp_bnkcode_no_gp.Size = New System.Drawing.Size(61, 20)
        Me.txtsupp_bnkcode_no_gp.TabIndex = 29
        '
        'txtsupp_bnkaccno_gp
        '
        Me.txtsupp_bnkaccno_gp.Location = New System.Drawing.Point(587, 193)
        Me.txtsupp_bnkaccno_gp.MaxLength = 20
        Me.txtsupp_bnkaccno_gp.Name = "txtsupp_bnkaccno_gp"
        Me.txtsupp_bnkaccno_gp.Size = New System.Drawing.Size(117, 20)
        Me.txtsupp_bnkaccno_gp.TabIndex = 30
        '
        'txtsupp_address_gp
        '
        Me.txtsupp_address_gp.Location = New System.Drawing.Point(587, 219)
        Me.txtsupp_address_gp.MaxLength = 255
        Me.txtsupp_address_gp.Name = "txtsupp_address_gp"
        Me.txtsupp_address_gp.Size = New System.Drawing.Size(308, 20)
        Me.txtsupp_address_gp.TabIndex = 31
        '
        'txtsupp_address_tax
        '
        Me.txtsupp_address_tax.Location = New System.Drawing.Point(587, 245)
        Me.txtsupp_address_tax.MaxLength = 255
        Me.txtsupp_address_tax.Name = "txtsupp_address_tax"
        Me.txtsupp_address_tax.Size = New System.Drawing.Size(308, 20)
        Me.txtsupp_address_tax.TabIndex = 32
        '
        'txtsupp_tel_no
        '
        Me.txtsupp_tel_no.Location = New System.Drawing.Point(587, 271)
        Me.txtsupp_tel_no.MaxLength = 25
        Me.txtsupp_tel_no.Name = "txtsupp_tel_no"
        Me.txtsupp_tel_no.Size = New System.Drawing.Size(117, 20)
        Me.txtsupp_tel_no.TabIndex = 33
        '
        'txtsupp_date
        '
        Me.txtsupp_date.Location = New System.Drawing.Point(434, 297)
        Me.txtsupp_date.MaxLength = 255
        Me.txtsupp_date.Name = "txtsupp_date"
        Me.txtsupp_date.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_date.TabIndex = 34
        Me.txtsupp_date.Visible = False
        '
        'txtsupp_ampenm_gp
        '
        Me.txtsupp_ampenm_gp.Location = New System.Drawing.Point(463, 297)
        Me.txtsupp_ampenm_gp.MaxLength = 255
        Me.txtsupp_ampenm_gp.Name = "txtsupp_ampenm_gp"
        Me.txtsupp_ampenm_gp.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_ampenm_gp.TabIndex = 35
        Me.txtsupp_ampenm_gp.Visible = False
        '
        'txtsupp_provnm_gp
        '
        Me.txtsupp_provnm_gp.Location = New System.Drawing.Point(496, 297)
        Me.txtsupp_provnm_gp.MaxLength = 255
        Me.txtsupp_provnm_gp.Name = "txtsupp_provnm_gp"
        Me.txtsupp_provnm_gp.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_provnm_gp.TabIndex = 36
        Me.txtsupp_provnm_gp.Visible = False
        '
        'txtsupp_agzip_gp
        '
        Me.txtsupp_agzip_gp.Location = New System.Drawing.Point(529, 297)
        Me.txtsupp_agzip_gp.MaxLength = 255
        Me.txtsupp_agzip_gp.Name = "txtsupp_agzip_gp"
        Me.txtsupp_agzip_gp.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_agzip_gp.TabIndex = 37
        Me.txtsupp_agzip_gp.Visible = False
        '
        'txtsupp_ampenm_tax
        '
        Me.txtsupp_ampenm_tax.Location = New System.Drawing.Point(562, 297)
        Me.txtsupp_ampenm_tax.MaxLength = 255
        Me.txtsupp_ampenm_tax.Name = "txtsupp_ampenm_tax"
        Me.txtsupp_ampenm_tax.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_ampenm_tax.TabIndex = 38
        Me.txtsupp_ampenm_tax.Visible = False
        '
        'txtsupp_provnm_tax
        '
        Me.txtsupp_provnm_tax.Location = New System.Drawing.Point(595, 297)
        Me.txtsupp_provnm_tax.MaxLength = 255
        Me.txtsupp_provnm_tax.Name = "txtsupp_provnm_tax"
        Me.txtsupp_provnm_tax.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_provnm_tax.TabIndex = 39
        Me.txtsupp_provnm_tax.Visible = False
        '
        'txtsupp_agzip_tax
        '
        Me.txtsupp_agzip_tax.Location = New System.Drawing.Point(629, 297)
        Me.txtsupp_agzip_tax.MaxLength = 255
        Me.txtsupp_agzip_tax.Name = "txtsupp_agzip_tax"
        Me.txtsupp_agzip_tax.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_agzip_tax.TabIndex = 40
        Me.txtsupp_agzip_tax.Visible = False
        '
        'txtsupp_country
        '
        Me.txtsupp_country.Location = New System.Drawing.Point(662, 297)
        Me.txtsupp_country.MaxLength = 255
        Me.txtsupp_country.Name = "txtsupp_country"
        Me.txtsupp_country.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_country.TabIndex = 41
        Me.txtsupp_country.Visible = False
        '
        'txtsupp_fax_no
        '
        Me.txtsupp_fax_no.Location = New System.Drawing.Point(695, 297)
        Me.txtsupp_fax_no.MaxLength = 255
        Me.txtsupp_fax_no.Name = "txtsupp_fax_no"
        Me.txtsupp_fax_no.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_fax_no.TabIndex = 42
        Me.txtsupp_fax_no.Visible = False
        '
        'txtsupp_status
        '
        Me.txtsupp_status.Location = New System.Drawing.Point(728, 297)
        Me.txtsupp_status.MaxLength = 255
        Me.txtsupp_status.Name = "txtsupp_status"
        Me.txtsupp_status.Size = New System.Drawing.Size(27, 20)
        Me.txtsupp_status.TabIndex = 43
        Me.txtsupp_status.Visible = False
        '
        'FrmSupplierSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(910, 421)
        Me.Controls.Add(Me.txtsupp_status)
        Me.Controls.Add(Me.txtsupp_fax_no)
        Me.Controls.Add(Me.txtsupp_country)
        Me.Controls.Add(Me.txtsupp_agzip_tax)
        Me.Controls.Add(Me.txtsupp_provnm_tax)
        Me.Controls.Add(Me.txtsupp_ampenm_tax)
        Me.Controls.Add(Me.txtsupp_agzip_gp)
        Me.Controls.Add(Me.txtsupp_provnm_gp)
        Me.Controls.Add(Me.txtsupp_ampenm_gp)
        Me.Controls.Add(Me.txtsupp_date)
        Me.Controls.Add(Me.txtsupp_tel_no)
        Me.Controls.Add(Me.txtsupp_address_tax)
        Me.Controls.Add(Me.txtsupp_address_gp)
        Me.Controls.Add(Me.txtsupp_bnkaccno_gp)
        Me.Controls.Add(Me.txtsupp_bnkcode_no_gp)
        Me.Controls.Add(Me.txtsupp_taxid)
        Me.Controls.Add(Me.txtsupp_name_tax)
        Me.Controls.Add(Me.txtsupp_name_gp)
        Me.Controls.Add(Me.txtsupp_s_account)
        Me.Controls.Add(Me.txtsupp_code)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.dgvSupplier)
        Me.Controls.Add(Me.lblHead)
        Me.Name = "FrmSupplierSetup"
        Me.Text = "FrmSupplierSetup"
        CType(Me.dgvSupplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHead As System.Windows.Forms.Label
    Friend WithEvents dgvSupplier As System.Windows.Forms.DataGridView
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtsupp_code As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_s_account As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_name_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_name_tax As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_taxid As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_bnkcode_no_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_bnkaccno_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_address_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_address_tax As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_tel_no As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_date As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_ampenm_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_provnm_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_agzip_gp As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_ampenm_tax As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_provnm_tax As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_agzip_tax As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_country As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_fax_no As System.Windows.Forms.TextBox
    Friend WithEvents txtsupp_status As System.Windows.Forms.TextBox
End Class
