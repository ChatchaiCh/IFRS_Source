Imports System.Text
Imports UtilityClassLibrary
Public Class FrmPaymentCreationReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub FrmPaymentCreationReport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListUser()
        ListDueDate()
        ListJournalType()

    End Sub
    Private Sub ListUser()
        Try

            Dim sb As New StringBuilder()
            sb.Append("SELECT T.CREATEDBY FROM GPS_GL_CREATION T WHERE T.GLCR_APPROVEDBY IS NULL GROUP BY T.CREATEDBY  ")
            sb.Append("UNION SELECT '" & gUserLogin & "' AS CREATEDBY FROM DUAL ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Dim dr As DataRow = dt.NewRow
                dr!CREATEDBY = 0
                dr!CREATEDBY = "All"
                dt.Rows.InsertAt(dr, 0)
                With cboUser
                    .DataSource = dt
                    .DisplayMember = "CREATEDBY"
                    .ValueMember = "CREATEDBY"
                End With
            End If

            Dim foundRows() As DataRow
            foundRows = dt.Select("CREATEDBY='" & gUserLogin & "'")

            If foundRows.Length > 0 Then
                cboUser.SelectedValue = gUserLogin
            Else
                cboUser.SelectedIndex = 0
            End If

        Catch ex As Exception
            cboUser.SelectedIndex = 0
        End Try

    End Sub
    Private Sub ListDueDate()
        Try
            Dim sb As New StringBuilder()

            sb.Append("SELECT T.GLCR_DUEDATE AS DUEDATE ,TO_CHAR(TO_DATE(T.GLCR_DUEDATE,'YYYYMMDD'),'DD/MM/YYYY') AS DUEDATE_TXT FROM GPS_GL_CREATION T ")
            sb.Append("WHERE T.GLCR_APPROVEDBY IS NULL ")

            If cboUser.SelectedIndex <> 0 Then
                sb.Append("AND T.CREATEDBY='" & cboUser.SelectedValue.ToString & "' ")
            End If

            sb.Append(" GROUP BY T.GLCR_DUEDATE ORDER BY T.GLCR_DUEDATE  ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
               
                With cboDueDate
                    .DataSource = dt
                    .DisplayMember = "DUEDATE_TXT"
                    .ValueMember = "DUEDATE"
                End With
            End If

            cboDueDate.SelectedIndex = 0
        Catch ex As Exception
            cboDueDate.SelectedIndex = 0
        End Try
    End Sub
    Private Sub ListJournalType()
        Try
            Dim sb As New StringBuilder()

            sb.Append("SELECT T.GLCR_JN_TYPE FROM GPS_GL_CREATION T WHERE T.GLCR_APPROVEDBY IS NULL  ")
            sb.Append("AND T.GLCR_DUEDATE='" & cboDueDate.SelectedValue.ToString & "' ")

            If cboUser.SelectedIndex <> 0 Then
                sb.Append("AND T.CREATEDBY='" & cboUser.SelectedValue.ToString & "' ")
            End If


            sb.Append(" GROUP BY T.GLCR_JN_TYPE ORDER BY T.GLCR_JN_TYPE   ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Dim dr As DataRow = dt.NewRow
                dr!GLCR_JN_TYPE = 0
                dr!GLCR_JN_TYPE = "All"
                dt.Rows.InsertAt(dr, 0)
                With cboJournalType
                    .DataSource = dt
                    .DisplayMember = "GLCR_JN_TYPE"
                    .ValueMember = "GLCR_JN_TYPE"
                End With
            End If

            cboJournalType.SelectedIndex = 0
        Catch ex As Exception
            'cboJournalType.SelectedIndex = 0
        End Try
    End Sub
    Function GetDataGL() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("select t.*,s.acnt_name_th as subaccname from gps_gl_creation t left join glm_account_setup s on t.glcr_sub_acct=s.acnt_s_code where t.glcr_duedate='" & cboDueDate.SelectedValue.ToString & "'  ")

        If cboJournalType.SelectedIndex <> 0 Then
            sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        End If
        If cboUser.SelectedIndex <> 0 Then
            sb.Append("and t.createdby='" & cboUser.SelectedValue.ToString & "' ")
        End If

        sb.Append("and t.glcr_approvedby is null ")
        sb.Append("order by t.GLCR_JN_HOLD, t.glcr_lineno ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetPayType_SubPayType() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("select gp.gpcr_paymth,gp.gpcr_sub_paymth ")
        sb.Append("from gps_payment_creation gp inner join ")
        sb.Append("(")
        sb.Append("select t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append("from gps_gl_creation t where t.glcr_duedate='" & cboDueDate.SelectedValue.ToString & "'  ")

        If cboJournalType.SelectedIndex <> 0 Then
            sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        End If
        If cboUser.SelectedIndex <> 0 Then
            sb.Append("and t.createdby='" & cboUser.SelectedValue.ToString & "' ")
        End If

        sb.Append("group by t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append(") a ")
        sb.Append("on gp.gpcr_createdate=a.glcr_createdate ")
        sb.Append("and gp.gpcr_core_system=a.glcr_core_system ")
        sb.Append("and gp.gpcr_transref=a.glcr_transref ")
        sb.Append("group by gp.gpcr_paymth,gp.gpcr_sub_paymth ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataGP(ByVal paytype As String, ByVal sub_paytype As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("select gp.* ")
        sb.Append("from gps_payment_creation gp inner join ")
        sb.Append("(")
        sb.Append("select t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append("from gps_gl_creation t where t.glcr_duedate='" & cboDueDate.SelectedValue.ToString & "'  ")

        If cboJournalType.SelectedIndex <> 0 Then
            sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        End If
        If cboUser.SelectedIndex <> 0 Then
            sb.Append("and t.createdby='" & cboUser.SelectedValue.ToString & "' ")
        End If

        sb.Append("group by t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append(") a ")
        sb.Append("on gp.gpcr_createdate=a.glcr_createdate ")
        sb.Append("and gp.gpcr_core_system=a.glcr_core_system ")
        sb.Append("and gp.gpcr_transref=a.glcr_transref ")
        sb.Append("and gp.gpcr_paymth='" & paytype & "' and gp.gpcr_sub_paymth='" & sub_paytype & "' ")
        sb.Append("where gp.gpcr_approvedby is null ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataTAX() As DataTable
        Dim sb As New StringBuilder()

        sb.Append("select taxcr_createdate, taxcr_core_system, taxcr_transref, taxcr_gptref_seqno, taxcr_lineno, taxcr_taxid, taxcr_idcard, taxcr_ap_ttl, taxcr_ap_fname, taxcr_ap_lname, taxcr_address, taxcr_ampenm, taxcr_provnm, taxcr_agzip, taxcr_taxtype, taxcr_taxitem, taxcr_taxdate, taxcr_base_amt, taxcr_tax_amt, taxcr_payee, taxcr_tax_rate, taxcr_desc, case when length(taxcr_gl_account) > 7 then taxcr_gl_account else taxcr_gl_account || taxcr_sub_acct end as taxcr_gl_account, taxcr_approvedby, taxcr_approveddate, taxcr_flag_validate, taxcr_flag_batch, taxcr_batchdate, taxcr_reject_type, createdby, createddate, updatedby, updateddate, taxcr_adjl_log_id, taxcr_remark, taxcr_sub_acct ")
        sb.Append("from gps_wht_creation t inner join ")
        sb.Append("(")
        sb.Append("select t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append("from gps_gl_creation t where t.glcr_duedate='" & cboDueDate.SelectedValue.ToString & "'  ")

        If cboJournalType.SelectedIndex <> 0 Then
            sb.Append("and t.glcr_jn_type='" & cboJournalType.SelectedValue.ToString & "' ")
        End If
        If cboUser.SelectedIndex <> 0 Then
            sb.Append("and t.createdby='" & cboUser.SelectedValue.ToString & "' ")
        End If

        sb.Append("group by t.glcr_createdate,t.glcr_core_system,t.glcr_transref ")
        sb.Append(") a ")
        sb.Append("on t.taxcr_createdate=a.glcr_createdate ")
        sb.Append("and t.taxcr_core_system=a.glcr_core_system ")
        sb.Append("and t.taxcr_transref=a.glcr_transref ")
        sb.Append("where t.taxcr_approvedby is null ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub PrintReport1()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        'frm1.CrDoc.Close()
        'frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then


            frm1.CrDoc.Close()
            frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()
            Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramHeader As New CrystalDecisions.Shared.ParameterField()


            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = cboDueDate.Text
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            paramHeader.ParameterFieldName = "pHeader"
            discreteHeader.Value = "Journal Entry Edit List"
            paramHeader.CurrentValues.Add(discreteHeader)
            paramFields.Add(paramHeader)


            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()
        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If
    End Sub
    Private Sub PrintReport2()

        Dim dttype As DataTable
        dttype = GetPayType_SubPayType()

        If Not IsNothing(dttype) AndAlso dttype.Rows.Count > 0 Then
            For Each dr As DataRow In dttype.Rows

                Dim payment_subpayment As String
                payment_subpayment = dr("gpcr_paymth") & ":" & dr("gpcr_sub_paymth")

                Dim reportname As String = ""
                Dim dt As DataTable = New DataTable()

                Select Case payment_subpayment
                    Case "D:D", "C:B"
                        reportname = "RptGP_M_Draft.rpt"
                    Case "M:M", "M:A"
                        reportname = "RptGP_Media_ATS.rpt"
                    Case "M:C"
                        reportname = "RptGP_CreditCard.rpt"
                    Case "C:C", "C:G", "C:T", "C:Q", "C:H"
                        reportname = "RptGP_M_Cheque_Gift_MoneyOrder.rpt"
                    Case "M:B"
                        reportname = "RptGP_OverSea.rpt"
                End Select

                dt = GetDataGP(dr("gpcr_paymth"), dr("gpcr_sub_paymth"))

                If Not IsNothing(dt) AndAlso dt.Rows.Count Then
                    CallReportGP(reportname, dt)
                End If

            Next

        End If

    End Sub
    Private Sub PrintReport3()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptTAX.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataTAX()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = cboDueDate.Text
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        End If
    End Sub
    Private Sub CallReportGP(ByVal reportname As String, ByVal dt As DataTable)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & reportname)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = cboDueDate.Text
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()
        End If
    End Sub
    Private Sub cboUser_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboUser.SelectedIndexChanged
        ListDueDate()
        ListJournalType()
    End Sub
    Private Sub cboDueDate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDueDate.SelectedIndexChanged
        ListJournalType()
    End Sub
    Private Sub CmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdOk.Click
        PrintReport1()
        PrintReport2()
        PrintReport3()

        Dim frm As New FrmPaymentCreationReport
        frm.TopLevel = False
        frm.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
        frm.Show()

        Me.Close()

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class