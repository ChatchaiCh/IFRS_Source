Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class FrmMaintainCHQNO
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub FrmMaintainCHQNO_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        BindData()
    End Sub
    Private Sub txtNumeric_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If e.KeyChar = "."c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("."c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub BindData()
        Dim sb As New StringBuilder()

        sb.Append("SELECT S.CHQS_PAY_GROUP,S.CHQS_BNKSCODE_NO,S.CHQS_S_CHQ1,S.CHQS_E_CHQ1, ")
        sb.Append("S.CHQS_S_CHQ2,S.CHQS_E_CHQ2,S1.BNKS_BNKSACC_NO,N.BACC_BNKACC_NAME, ")
        sb.Append("S.CHQS_S_CHQ1_FINISH, S.CHQS_S_CHQ2_FINISH ")
        sb.Append("FROM GPS_CHEQUE_SETUP S,GPS_TL_BANKSERVICE1 S1,GPS_TL_BANKACCT_NAME N ")
        sb.Append("WHERE S.CHQS_PAY_GROUP=S1.BNKS_PAY_GROUP ")
        sb.Append("AND S.CHQS_BNKSCODE_NO=S1.BNKS_BNKSCODE_NO ")
        sb.Append("AND S1.BNKS_BNKSCODE_NO=N.BACC_BNKCODE_NO ")
        sb.Append("AND S1.BNKS_BNKSACC_NO=N.BACC_BNKACC_NO")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
            txtPayGroup.Text = dt.Rows(0)("CHQS_PAY_GROUP").ToString
            txtServiceCode.Text = dt.Rows(0)("CHQS_BNKSCODE_NO").ToString
            txtServiceName.Text = dt.Rows(0)("BACC_BNKACC_NAME").ToString

            If dt.Rows(0)("CHQS_S_CHQ1_FINISH") = "Y" Then



            End If

            If (dt.Rows(0)("CHQS_S_CHQ1").ToString = dt.Rows(0)("CHQS_E_CHQ1").ToString) And dt.Rows(0)("CHQS_S_CHQ1_FINISH") = "N" Then
                txt_s_chq1.Text = dt.Rows(0)("CHQS_S_CHQ1").ToString
                txt_e_chq1.Text = dt.Rows(0)("CHQS_E_CHQ1").ToString
                txt_s_chq2.Text = dt.Rows(0)("CHQS_S_CHQ2").ToString
                txt_e_chq2.Text = dt.Rows(0)("CHQS_E_CHQ2").ToString

                If Not IsDBNull(dt.Rows(0)("CHQS_S_CHQ1_FINISH")) AndAlso dt.Rows(0)("CHQS_S_CHQ1_FINISH") = "Y" Then
                    ChkChq1.Checked = True
                Else
                    ChkChq1.Checked = False
                End If

                If Not IsDBNull(dt.Rows(0)("CHQS_S_CHQ2_FINISH")) AndAlso dt.Rows(0)("CHQS_S_CHQ2_FINISH") = "Y" Then
                    ChkChq2.Checked = True
                Else
                    ChkChq2.Checked = False
                End If

            ElseIf dt.Rows(0)("CHQS_S_CHQ1").ToString < dt.Rows(0)("CHQS_E_CHQ1").ToString Then
                txt_s_chq1.Text = dt.Rows(0)("CHQS_S_CHQ1").ToString
                txt_e_chq1.Text = dt.Rows(0)("CHQS_E_CHQ1").ToString
                txt_s_chq2.Text = dt.Rows(0)("CHQS_S_CHQ2").ToString
                txt_e_chq2.Text = dt.Rows(0)("CHQS_E_CHQ2").ToString

                If Not IsDBNull(dt.Rows(0)("CHQS_S_CHQ1_FINISH")) AndAlso dt.Rows(0)("CHQS_S_CHQ1_FINISH") = "Y" Then
                    ChkChq1.Checked = True
                Else
                    ChkChq1.Checked = False
                End If

                If Not IsDBNull(dt.Rows(0)("CHQS_S_CHQ2_FINISH")) AndAlso dt.Rows(0)("CHQS_S_CHQ2_FINISH") = "Y" Then
                    ChkChq2.Checked = True
                Else
                    ChkChq2.Checked = False
                End If

            Else
                txt_s_chq1.Text = dt.Rows(0)("CHQS_S_CHQ2").ToString
                txt_e_chq1.Text = dt.Rows(0)("CHQS_E_CHQ2").ToString
                txt_s_chq2.Text = ""
                txt_e_chq2.Text = ""

                
                If Not IsDBNull(dt.Rows(0)("CHQS_S_CHQ2_FINISH")) AndAlso dt.Rows(0)("CHQS_S_CHQ2_FINISH") = "Y" Then
                    ChkChq1.Checked = True
                Else
                    ChkChq1.Checked = False
                End If

                ChkChq2.Checked = False

            End If

           

            txtAccountCode.Text = dt.Rows(0)("BNKS_BNKSACC_NO").ToString

        End If

    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = True
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "CHQS_PAY_GROUP"
            .Name = "CHQS_PAY_GROUP"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "CHQS_BNKSCODE_NO"
            .Name = "CHQS_BNKSCODE_NO"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c2)
        End With

        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "BACC_BNKACC_NAME"
            .Name = "BACC_BNKACC_NAME"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With


        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "BNKS_BNKSACC_NO"
            .Name = "BNKS_BNKSACC_NO"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c4)
        End With

        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "CHQS_S_CHQ1"
            .Name = "CHQS_S_CHQ1"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c5)
        End With

        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "CHQS_E_CHQ1"
            .Name = "CHQS_E_CHQ1"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c6)
        End With

        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "CHQS_S_CHQ2"
            .Name = "CHQS_S_CHQ2"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c7)
        End With

        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .DataPropertyName = "CHQS_E_CHQ2"
            .Name = "CHQS_E_CHQ2"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c8)
        End With


        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)

        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

    

    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True

            txtPayGroup.Text = CStr(Me.DataGridView1.SelectedCells(0).Value.ToString)
            txtServiceCode.Text = CStr(Me.DataGridView1.SelectedCells(1).Value.ToString)
            txtServiceName.Text = CStr(Me.DataGridView1.SelectedCells(2).Value.ToString)
            txtAccountCode.Text = CStr(Me.DataGridView1.SelectedCells(3).Value.ToString)
            If CStr(Me.DataGridView1.SelectedCells(4).Value.ToString) = CStr(Me.DataGridView1.SelectedCells(5).Value.ToString) Then
                

                txt_s_chq1.Text = CStr(Me.DataGridView1.SelectedCells(6).Value.ToString)
                txt_e_chq1.Text = CStr(Me.DataGridView1.SelectedCells(7).Value.ToString)
                txt_s_chq2.Text = ""
                txt_e_chq2.Text = ""
                'txt_s_chq2.Enabled = True
                'txt_e_chq2.Enabled = True

            ElseIf CStr(Me.DataGridView1.SelectedCells(4).Value.ToString) < CStr(Me.DataGridView1.SelectedCells(5).Value.ToString) Then
                txt_s_chq1.Text = CStr(Me.DataGridView1.SelectedCells(4).Value.ToString)
                txt_e_chq1.Text = CStr(Me.DataGridView1.SelectedCells(5).Value.ToString)
                txt_s_chq2.Text = CStr(Me.DataGridView1.SelectedCells(6).Value.ToString)
                txt_e_chq2.Text = CStr(Me.DataGridView1.SelectedCells(7).Value.ToString)
                'txt_s_chq2.Enabled = False
                'txt_e_chq2.Enabled = False
            Else
                txt_s_chq1.Text = CStr(Me.DataGridView1.SelectedCells(6).Value.ToString)
                txt_e_chq1.Text = CStr(Me.DataGridView1.SelectedCells(7).Value.ToString)
                txt_s_chq2.Text = ""
                txt_e_chq2.Text = ""
                'txt_s_chq2.Enabled = False
                'txt_e_chq2.Enabled = False

            End If

        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtPayGroup.Text = ""
        txtServiceCode.Text = ""
        txtServiceName.Text = ""
        txt_s_chq1.Text = ""
        txt_e_chq1.Text = ""
        txt_s_chq2.Text = ""
        txt_e_chq2.Text = ""
        txtAccountCode.Text = ""
    End Sub
    Private Sub txt_s_chq1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_s_chq1.KeyPress
        AddHandler txt_s_chq1.KeyPress, AddressOf txtNumeric_KeyPress
    End Sub
    Private Sub txt_e_chq1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_e_chq1.KeyPress
        AddHandler txt_e_chq1.KeyPress, AddressOf txtNumeric_KeyPress
    End Sub
    Private Sub txt_s_chq2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_s_chq2.KeyPress
        AddHandler txt_s_chq2.KeyPress, AddressOf txtNumeric_KeyPress
    End Sub
    Private Sub txt_e_chq2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_e_chq2.KeyPress
        AddHandler txt_e_chq2.KeyPress, AddressOf txtNumeric_KeyPress
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If txt_e_chq1.Text.Trim <> "" And txt_s_chq1.Text.Trim <> "" Then
            If Convert.ToDouble(txt_e_chq1.Text) < Convert.ToDouble(txt_s_chq1.Text) Then
                MsgBox("Cheque No ��ǧ��� 1 ���١��ͧ", MsgBoxStyle.Information)
                Exit Sub
            End If
        Else
            MsgBox("��س��к� Cheque No ��ǧ��� 1", MsgBoxStyle.Information)
            Exit Sub
        End If

        If txt_e_chq2.Text.Trim <> "" And txt_s_chq2.Text.Trim <> "" Then
            If Convert.ToDouble(txt_e_chq2.Text) < Convert.ToDouble(txt_s_chq2.Text) Then
                MsgBox("Cheque No ��ǧ��� 2 ���١��ͧ", MsgBoxStyle.Information)
                Exit Sub
            End If
            'Else
            'MsgBox("��س��к� Cheque No ��ǧ��� 2", MsgBoxStyle.Information)
            'Exit Sub
        End If

        If Len(txt_s_chq1.Text.Trim) <> Len(txt_e_chq1.Text.Trim) Then
            MsgBox("Length ���١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If Len(txt_s_chq2.Text.Trim) <> Len(txt_e_chq2.Text.Trim) Then
            MsgBox("Length ���١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If txt_s_chq1.Text.Trim <> txt_e_chq1.Text.Trim And ChkChq1.Checked Then
            MsgBox("�к� ������� stock ��ǧ��� 1 ���١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If txt_s_chq2.Text.Trim <> txt_e_chq2.Text.Trim And ChkChq2.Checked Then
            MsgBox("�к� ������� stock ��ǧ��� 2 ���١��ͧ", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim s1 As Double = 0
        Dim e1 As Double = 0
        Dim s2 As Double = 0
        Dim e2 As Double = 0

        If txt_s_chq1.Text.Trim <> "" Then
            s1 = Convert.ToDouble(txt_s_chq1.Text.Trim)
        End If
        If txt_e_chq1.Text.Trim <> "" Then
            e1 = Convert.ToDouble(txt_e_chq1.Text.Trim)
        End If
        If txt_s_chq2.Text.Trim <> "" Then
            s2 = Convert.ToDouble(txt_s_chq2.Text.Trim)
        End If
        If txt_e_chq2.Text.Trim <> "" Then
            e2 = Convert.ToDouble(txt_e_chq2.Text.Trim)
        End If



        If (s2 >= s1) And (s2 <= e1) Then
            MsgBox("Maintain �Ţ��� Cheque ���١��ͧ ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If (e2 >= s1) And (e2 <= e1) Then
            MsgBox("Maintain �Ţ��� Cheque ���١��ͧ ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If (s1 >= s2) And (s1 <= e2) Then
            MsgBox("Maintain �Ţ��� Cheque ���١��ͧ ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
            Exit Sub
        End If

        If (e1 < s1) And (e1 < e2) Then
            MsgBox("Maintain �Ţ��� Cheque ���١��ͧ ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim chk1 As String
        If ChkChq1.Checked Then
            chk1 = "Y"
        Else
            chk1 = "N"
        End If

        Dim chk2 As String
        If ChkChq2.Checked Then
            chk2 = "Y"
        Else
            chk2 = "N"
        End If

        Dim sb As New StringBuilder()

        sb.Append("UPDATE GPS_CHEQUE_SETUP SET ")
        sb.Append("CHQS_S_CHQ1= '" & txt_s_chq1.Text & "',")
        sb.Append("CHQS_E_CHQ1= '" & txt_e_chq1.Text & "', ")
        sb.Append("CHQS_S_CHQ1_FINISH= '" & chk1 & "' , ")


        sb.Append("CHQS_S_CHQ2= '" & txt_s_chq2.Text & "',")
        sb.Append("CHQS_E_CHQ2= '" & txt_e_chq2.Text & "',")

        If txt_e_chq2.Text.Trim = "" Or txt_s_chq2.Text.Trim = "" Then
            sb.Append("CHQS_S_CHQ2_FINISH= '' , ")
        Else
            sb.Append("CHQS_S_CHQ2_FINISH= '" & chk2 & "' , ")
        End If

        sb.Append("UPDATEDBY='" & gUserLogin & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD') ")
        sb.Append("WHERE CHQS_PAY_GROUP='" & txtPayGroup.Text & "' ")
        sb.Append("AND CHQS_BNKSCODE_NO='" & txtServiceCode.Text & "'")

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec As Integer
        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)
        If rec > 0 Then
            oleTrans.Commit()

            BindData()
            MsgBox("Data updated successfully")
        Else
            oleTrans.Rollback()

            MsgBox("Cannot update data" & vbCrLf & clsUtility.ErrConnectDBMessage)
        End If

    End Sub
End Class