Imports UtilityClassLibrary
Public Class FrmRptPaymentResult
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub FrmRptPaymentResult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

    End Sub
    Private Sub PrintReport()
        'Dim fromdate As String
        'Dim todate As String
        'fromdate = CStr(dtpFromDate.Value.ToString("yyyyMMdd"))
        'todate = CStr(dtpToDate.Value.ToString("yyyyMMdd"))

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If


        Dim frm1 As New FrmRptViewer
        'frm1.TopLevel = False
        'frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        'FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPaymentResult.rpt")

        Dim condition As String = ""
        Dim dt As DataTable = New DataTable()

        'condition &= " AND STATUS='P' AND EVT_NO='0000' "
        'condition &= " AND PAYMENT_DATE BETWEEN '" & fromdate & "' AND '" & todate & "' "

        dt = clsBusiness.GetBankCode(clsUtility.gConnGP, condition)
        frm1.FillDataTableToReport(dt)

        'Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        'Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
        'Dim paramHeader As New CrystalDecisions.Shared.ParameterField()
        'Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        'Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        'paramHeader.ParameterFieldName = "trandate"
        'discreteHeader.Value = "Transaction date " & CStr(dtpFromDate.Value.ToString("dd/MM/yyyy")) & " to " & CStr(dtpToDate.Value.ToString("dd/MM/yyyy"))
        'paramHeader.CurrentValues.Add(discreteHeader)
        'paramFields.Add(paramHeader)

        'paramUser.ParameterFieldName = "username"
        'discreteUser.Value = gUserFullName
        'paramUser.CurrentValues.Add(discreteUser)
        'paramFields.Add(paramUser)

        'frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

        'gConnSPI.Close()
    End Sub
    Private Sub CmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdOk.Click
        PrintReport()
    End Sub
End Class