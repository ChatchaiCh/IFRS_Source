﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Imports System.Globalization

Public Class FrmCancelPaymentReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsReport

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnPrint_Click(sender As System.Object, e As System.EventArgs) Handles btnPrint.Click
        Dim oleConn As OleDbConnection
        Dim clsHashLO As New ClsHashTotalErrorLOCancel
        Dim pathReport As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")
        Dim result As String

        Me.Cursor = Cursors.WaitCursor

        oleConn = clsUtility.gConnGP

        result = clsHashLO.genReportErrorbyHashTotalGPS(oleConn _
                                                        , DateTimePicker1.Value.ToString("yyyyMMdd", New CultureInfo("en-GB")) _
                                                        , pathReport, sReportPath, gUserFullName)

        Me.Cursor = Cursors.Arrow

        If result.Trim <> "" Then
            MsgBox(result, MsgBoxStyle.Information)
        Else
            MsgBox("Can not generate report.", MsgBoxStyle.Critical)
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        DateTimePicker1.Value = Now
        DateTimePicker1.Enabled = True

    End Sub
End Class