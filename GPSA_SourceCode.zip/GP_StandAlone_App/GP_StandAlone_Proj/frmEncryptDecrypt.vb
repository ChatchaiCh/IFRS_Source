﻿Imports System.Configuration
Imports UtilityClassLibrary

Public Class frmEncryptDecrypt

    Private Sub btnEncrypt_Click(sender As System.Object, e As System.EventArgs) Handles btnEncrypt.Click
        Try
            txtForDecrypt.Text = UtilityClassLibrary.EncryptDecryptUtility.Encrypt(txtForEncrypt.Text)
        Catch ex As Exception
            MessageBox.Show("Encrypt Error : " & ex.Message, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


    Private Sub btnDecrypt_Click(sender As System.Object, e As System.EventArgs) Handles btnDecrypt.Click
        Try
            txtForEncrypt.Text = UtilityClassLibrary.EncryptDecryptUtility.Decrypt(txtForDecrypt.Text)
        Catch ex As Exception
            MessageBox.Show("Decrypt Error : " & ex.Message, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmEncryptDecrypt_KeyDown(sender As System.Object, e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If (e.KeyCode = Keys.Escape) Then
            ' When Alt + P is pressed, the Click event for the print
            ' button is raised.
            Me.Close()
        End If
    End Sub

    Private Sub btnCheckConnection_Click(sender As System.Object, e As System.EventArgs) Handles btnCheckConnection.Click
        Try
            Using clsREFID As New UtilityClassLibrary.clsREFIDEnquiry(txtForEncrypt.Text)
                Try
                    clsREFID.OpenConnecttion()
                    clsREFID.CloseConnection()
                    MessageBox.Show("Connection Success!!!", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                    MessageBox.Show("Cann't Connect to REFIDEnquiry Database because " & ex.Message, "Result", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        Catch ex As Exception
            MessageBox.Show("Cann't Connect to REFIDEnquiry Database because " & ex.Message, "Result", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnGetConfig_Click(sender As System.Object, e As System.EventArgs) Handles btnGetConfig.Click
        Try
            txtForDecrypt.Text = ConfigurationManager.ConnectionStrings("ConnStrRefId").ConnectionString
            txtForEncrypt.Text = EncryptDecryptUtility.Decrypt(txtForDecrypt.Text)
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message)
        End Try
    End Sub
End Class