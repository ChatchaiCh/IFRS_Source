<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTest))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.btnSave = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
        Me.btnAddNew = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.RipsWareImageButtonBase1 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button6 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
        Me.Button7 = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
        Me.txtTextURL = New GP_StandAlone_App.WaterMarkTextBox
        Me.TextBox1 = New GP_StandAlone_App.WaterMarkTextBox
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(37, 111)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(762, 451)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnSave)
        Me.TabPage1.Controls.Add(Me.btnAddNew)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(754, 425)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.Presses4
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Black
        Me.btnSave.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover4
        Me.btnSave.Image = Global.GP_StandAlone_App.My.Resources.Resources.Save_icon
        Me.btnSave.ImageKey = ""
        Me.btnSave.ImageList = Nothing
        Me.btnSave.Location = New System.Drawing.Point(104, 366)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.Presses4
        Me.btnSave.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover4
        Me.btnSave.Size = New System.Drawing.Size(92, 26)
        Me.btnSave.TabIndex = 19
        Me.btnSave.Text = "Save"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        '
        'btnAddNew
        '
        Me.btnAddNew.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.Presses4
        Me.btnAddNew.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAddNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnAddNew.ForeColor = System.Drawing.Color.Black
        Me.btnAddNew.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover4
        Me.btnAddNew.Image = Global.GP_StandAlone_App.My.Resources.Resources.add_icon
        Me.btnAddNew.ImageKey = ""
        Me.btnAddNew.ImageList = Nothing
        Me.btnAddNew.Location = New System.Drawing.Point(6, 366)
        Me.btnAddNew.Name = "btnAddNew"
        Me.btnAddNew.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.Presses4
        Me.btnAddNew.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover4
        Me.btnAddNew.Size = New System.Drawing.Size(92, 26)
        Me.btnAddNew.TabIndex = 18
        Me.btnAddNew.Text = "Add New"
        Me.btnAddNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnAddNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(748, 357)
        Me.Panel1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Controls.Add(Me.RipsWareImageButtonBase1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(754, 425)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(3, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(748, 350)
        Me.Panel2.TabIndex = 8
        '
        'RipsWareImageButtonBase1
        '
        Me.RipsWareImageButtonBase1.ActiveImage = Nothing
        Me.RipsWareImageButtonBase1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RipsWareImageButtonBase1.ForeColor = System.Drawing.Color.White
        Me.RipsWareImageButtonBase1.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover2
        Me.RipsWareImageButtonBase1.Image = Global.GP_StandAlone_App.My.Resources.Resources.Edit
        Me.RipsWareImageButtonBase1.ImageKey = ""
        Me.RipsWareImageButtonBase1.ImageList = Nothing
        Me.RipsWareImageButtonBase1.Location = New System.Drawing.Point(8, 373)
        Me.RipsWareImageButtonBase1.Name = "RipsWareImageButtonBase1"
        Me.RipsWareImageButtonBase1.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.Normal2
        Me.RipsWareImageButtonBase1.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.Presses2
        Me.RipsWareImageButtonBase1.Size = New System.Drawing.Size(188, 35)
        Me.RipsWareImageButtonBase1.TabIndex = 7
        Me.RipsWareImageButtonBase1.Text = "Preview"
        Me.RipsWareImageButtonBase1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RipsWareImageButtonBase1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(724, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Test"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(724, 41)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Send Email"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.Button3.Location = New System.Drawing.Point(724, 70)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Validate"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(37, 19)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(89, 47)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(263, 20)
        Me.TextBox2.TabIndex = 11
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "02Final.ico")
        Me.ImageList1.Images.SetKeyName(1, "02Work.ico")
        Me.ImageList1.Images.SetKeyName(2, "01Finalyello.ico")
        Me.ImageList1.Images.SetKeyName(3, "01WorkYello.ico")
        Me.ImageList1.Images.SetKeyName(4, "01Verify.ico")
        Me.ImageList1.Images.SetKeyName(5, "01Report.ico")
        Me.ImageList1.Images.SetKeyName(6, "run_green32.ico")
        Me.ImageList1.Images.SetKeyName(7, "home.png")
        Me.ImageList1.Images.SetKeyName(8, "folder.png")
        Me.ImageList1.Images.SetKeyName(9, "folder-document.png")
        Me.ImageList1.Images.SetKeyName(10, "printer.png")
        Me.ImageList1.Images.SetKeyName(11, "paper-box.png")
        Me.ImageList1.Images.SetKeyName(12, "office-building.png")
        '
        'Button11
        '
        Me.Button11.Enabled = False
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(35, 44)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(29, 24)
        Me.Button11.TabIndex = 15
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.Control
        Me.Button10.Image = Global.GP_StandAlone_App.My.Resources.Resources.last
        Me.Button10.Location = New System.Drawing.Point(379, 44)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(29, 24)
        Me.Button10.TabIndex = 14
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.Image = Global.GP_StandAlone_App.My.Resources.Resources.next1
        Me.Button9.Location = New System.Drawing.Point(355, 44)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(24, 24)
        Me.Button9.TabIndex = 10
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Enabled = False
        Me.Button8.Image = Global.GP_StandAlone_App.My.Resources.Resources.previous11
        Me.Button8.Location = New System.Drawing.Point(64, 44)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(24, 24)
        Me.Button8.TabIndex = 7
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.Pressed1
        Me.Button6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover
        Me.Button6.Image = Global.GP_StandAlone_App.My.Resources.Resources.file
        Me.Button6.ImageKey = ""
        Me.Button6.ImageList = Nothing
        Me.Button6.Location = New System.Drawing.Point(411, 77)
        Me.Button6.Name = "Button6"
        Me.Button6.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.Normal
        Me.Button6.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.Pressed
        Me.Button6.Size = New System.Drawing.Size(92, 26)
        Me.Button6.TabIndex = 17
        Me.Button6.Text = "Browse File"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        '
        'Button7
        '
        Me.Button7.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.Pressed1
        Me.Button7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.Hover
        Me.Button7.Image = Global.GP_StandAlone_App.My.Resources.Resources.import
        Me.Button7.ImageKey = ""
        Me.Button7.ImageList = Nothing
        Me.Button7.Location = New System.Drawing.Point(505, 77)
        Me.Button7.Name = "Button7"
        Me.Button7.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.Normal
        Me.Button7.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.Pressed
        Me.Button7.Size = New System.Drawing.Size(92, 26)
        Me.Button7.TabIndex = 16
        Me.Button7.Text = "Import File"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        '
        'txtTextURL
        '
        Me.txtTextURL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtTextURL.Location = New System.Drawing.Point(38, 83)
        Me.txtTextURL.Name = "txtTextURL"
        Me.txtTextURL.Size = New System.Drawing.Size(367, 20)
        Me.txtTextURL.TabIndex = 13
        Me.txtTextURL.WaterMarkColor = System.Drawing.Color.Gray
        Me.txtTextURL.WaterMarkText = "Choose File Import"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.TextBox1.Location = New System.Drawing.Point(243, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(162, 20)
        Me.TextBox1.TabIndex = 12
        Me.TextBox1.WaterMarkColor = System.Drawing.Color.Gray
        Me.TextBox1.WaterMarkText = "Enter Your Name"
        '
        'frmTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(833, 604)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.txtTextURL)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmTest"
        Me.Text = "frmTest"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents txtTextURL As GP_StandAlone_App.WaterMarkTextBox
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents RipsWareImageButtonBase1 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Button7 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Button6 As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnAddNew As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnSave As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
End Class
