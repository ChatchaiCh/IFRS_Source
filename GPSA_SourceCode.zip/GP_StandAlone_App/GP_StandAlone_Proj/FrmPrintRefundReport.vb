Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmPrintRefundReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsRefund
    Dim lblStatus As String

    Private Sub FrmPrintRefundReport_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If (e.Control AndAlso (e.KeyCode = Keys.S)) Then
            ' When Control + S is pressed, the Click event for the show encryptdecrypt form
            ' button is raised.
            frmEncryptDecrypt.ShowDialog()
        End If

    End Sub
    Private Sub FrmRptRefundCreditCard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        lblStatus = "ADD"
        ListBatchNo()
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtBatchNo.Text.Trim = "" Then
            MsgBox("Please select Batch No.")
            Exit Sub
        End If
        If txtName.Text.Trim = "" Then
            MsgBox("Please enter ���ͼ�����ӹҨŧ���")
            txtName.Focus()
            Exit Sub
        End If
        If txtPosition.Text.Trim = "" Then
            MsgBox("Please enter ���˹觼�����ӹҨŧ���")
            txtPosition.Focus()
            Exit Sub
        End If


        Dim systemyear As String
        systemyear = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 4)

        If lblStatus = "ADD" Then

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim c1, c2, c3 As Boolean
            c1 = SaveCreditCard(oleTrans)
            c2 = SaveLetterSetup(oleTrans, systemyear)
            c3 = UpdateFlag(oleTrans)

            If c1 And c2 And c3 Then
                oleTrans.Commit()

                PrintReport(txtBatchNo.Text.Trim)
                Me.Close()

            Else
                oleTrans.Rollback()
                MsgBox("Can not Print CreditCard!")
            End If

        Else

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim c1 As Boolean
            c1 = SaveCreditCard(oleTrans)

            If c1 Then
                oleTrans.Commit()

                PrintReport(txtBatchNo.Text.Trim)
                Me.Close()

            Else
                oleTrans.Rollback()
                MsgBox("Can not Print CreditCard!")
            End If

        End If
    End Sub
    Private Sub PrintReport(ByVal batchno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptRefundCreditCard.rpt")

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataRpt(clsUtility.gConnGP, batchno)

        Dim dtContract As DataTable = New DataTable()
        dtContract = clsBusiness.GetReportContract(clsUtility.gConnGP, "CREDIT")


        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            ' -----------------------------------------------------------
            ' Edit by adisak for masking credit card on 11/05/2016
            ' step 
            ' 1. send refid(gp_payee_bnkaccno) to refid database(refidenquiry) (sql server) for get masking for show in report if have data get field mask and end
            ' 2. if step 1 not found data masking data manual @ format -> 000000XXXXXX0000
            'Dim test As Boolean = clsUtility.OpenConnGP_3()
            Try
                Using clsREFID As New UtilityClassLibrary.clsREFIDEnquiry()
                    clsREFID.OpenConnecttion()
                    Dim dtRefID As DataTable
                    For Each dr As DataRow In dt.Rows
                        If (Not dr.IsNull("GP_PAYEE_BNKACCNO")) Then
                            If (dr("GP_PAYEE_BNKACCNO").ToString().Length >= 16) Then
                                dtRefID = Nothing
                                dtRefID = clsREFID.GetMaskingPan(dr("GP_PAYEE_BNKACCNO").ToString())
                                If (dtRefID Is Nothing) Then
                                    dr("GP_PAYEE_BNKACCNO") = MaskingPan(dr("GP_PAYEE_BNKACCNO").ToString())
                                Else
                                    If (dtRefID.Rows.Count > 0) Then
                                        dr("GP_PAYEE_BNKACCNO") = dtRefID.Rows(0)("Mask").ToString()
                                    Else
                                        dr("GP_PAYEE_BNKACCNO") = MaskingPan(dr("GP_PAYEE_BNKACCNO").ToString())
                                    End If
                                End If
                            End If
                        End If
                    Next
                    clsREFID.CloseConnection()
                End Using
            Catch ex As Exception
                'MsgBox(AcceptButton.DialogResult, Global.Microsoft.VisualBasic.MsgBoxStyle.Critical, "Error !!!")
                'MessageBox.Show(ex.Message, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Throw ex
                For Each dr As DataRow In dt.Rows
                    dr("GP_PAYEE_BNKACCNO") = MaskingPan(dr("GP_PAYEE_BNKACCNO").ToString())
                Next
            End Try

            ' -----------------------------------------------------------

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteTel As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramTel As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pContactName"
            discrete1.Value = dtContract.Rows(0)("CONT_NAME").ToString
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)



            paramTel.ParameterFieldName = "pContactTel"
            discreteTel.Value = dtContract.Rows(0)("CONT_TEL_NO").ToString
            paramTel.CurrentValues.Add(discreteTel)
            paramFields.Add(paramTel)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub

    Private Function MaskingPan(value As String) As String
        Try
            Return value.ToString().Substring(0, 6) & "XXXXXX" & value.Substring(12, 4)
        Catch ex As Exception
            Return value
        End Try
    End Function

    Function UpdateFlag(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chk As Boolean
        chk = cls.UPD_GP_FLAG_PRNRPTS_ByBatchNo(clsUtility.gConnGP, oleTrans, txtBatchNo.Text.Trim, gUserLogin)

        Return chk
    End Function
    Private Sub ListBatchNo()

        Dim dt As New DataTable
        dt = cls.GetBatchNo(clsUtility.gConnGP)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            txtBatchNo.Text = dt.Rows(0)("TREF_BATCH_NO").ToString
            BindData()
        Else
            txtBatchNo.Text = ""
        End If
    End Sub
    Private Sub BindData()
        Dim dt As New DataTable
        If lblStatus = "ADD" Then
            dt = cls.GetDataPayment_ByBatchNo(clsUtility.gConnGP, txtBatchNo.Text.Trim)
            txtLetterNo.Text = clsBusiness.GetMaxLetterNo(clsUtility.gConnGP)
            txtAmount.Text = Convert.ToDouble(dt.Rows(0)("AMT")).ToString("###,##0.00")
        Else
            dt = cls.GetDataPrintCreditCard(clsUtility.gConnGP, txtBatchNo.Text.Trim)

            txtLetterNo.Text = dt.Rows(0)("PCRE_LETTERNO")
            txtAmount.Text = Convert.ToDouble(dt.Rows(0)("AMT")).ToString("###,##0.00")
            txtName.Text = dt.Rows(0)("PCRE_AUTH_NAME")
            txtPosition.Text = dt.Rows(0)("PCRE_AUTH_POSI")
        End If

    End Sub
    Function SaveCreditCard(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim table As New DataTable
        table.Columns.Add("PCRE_BATCH_NO")
        table.Columns.Add("PCRE_LETTERNO")
        table.Columns.Add("PCRE_AUTH_NAME")
        table.Columns.Add("PCRE_AUTH_POSI")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        Dim row As DataRow
        row = table.NewRow()

        row("PCRE_BATCH_NO") = txtBatchNo.Text.Trim
        row("PCRE_LETTERNO") = txtLetterNo.Text.Trim
        row("PCRE_AUTH_NAME") = txtName.Text.Trim
        row("PCRE_AUTH_POSI") = txtPosition.Text.Trim
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim chk As Boolean
        If lblStatus = "ADD" Then
            chk = cls.INS_GPS_PRN_CREDITCARD(clsUtility.gConnGP, oleTrans, row)
        Else
            chk = cls.UPD_GPS_PRN_CREDITCARD(clsUtility.gConnGP, oleTrans, row)
        End If

        Return chk
    End Function
    Function SaveLetterSetup(ByVal oleTrans As OleDbTransaction, ByVal systemyear As String) As Boolean
        Dim table As New DataTable

        table.Columns.Add("LETT_YEAR")
        table.Columns.Add("LETT_NO")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        Dim row As DataRow
        row = table.NewRow()

        row("LETT_YEAR") = systemyear
        row("LETT_NO") = Microsoft.VisualBasic.Right(txtLetterNo.Text.Trim, 6)
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim chk As Boolean
        If Convert.ToDouble(Microsoft.VisualBasic.Right(txtLetterNo.Text.Trim, 6)) = 1 Then
            chk = clsBusiness.INS_GPS_LETTERNO_SETUP(clsUtility.gConnGP, oleTrans, row)
        Else
            chk = clsBusiness.UPD_GPS_LETTERNO_SETUP(clsUtility.gConnGP, oleTrans, row)
        End If

        Return chk
    End Function

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click

        retBatchNo = ""
        Dim f As New FrmFindCreditCard
        f.Owner = Me
        f.Text = Me.Text
        f.ShowDialog()

        If retBatchNo <> "" Then
            lblStatus = "EDIT"
            txtBatchNo.Text = retBatchNo
            BindData()
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click

        'PrintReport("GP20140926001")
        Me.Close()

    End Sub

    Private Sub FrmPrintRefundReport_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress

    End Sub
End Class