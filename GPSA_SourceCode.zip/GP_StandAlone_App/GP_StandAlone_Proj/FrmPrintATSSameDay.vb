Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary

Public Class FrmPrintATSSameDay
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsATS
    Dim lblStatus As String
    Private Sub FrmATSSameDay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        lblStatus = "ADD"
        ListBatchNo()

    End Sub
    Private Sub ListBatchNo()

        Dim dt As New DataTable
        dt = cls.GetBatchNo(clsUtility.gConnGP, False)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            With cboBatchNo
                .DataSource = dt
                .DisplayMember = "TREF_BATCH_NO"
                .ValueMember = "TREF_BATCH_NO"
            End With
        Else
            cboBatchNo.DataSource = Nothing
            cboBatchNo.Items.Clear()
            cboBatchNo.Text = ""
        End If

        BindData()
    End Sub
    Private Sub BindData()
        If cboBatchNo.Text.Trim <> "" Then
            Dim dt As New DataTable
            dt = cls.GetDataATS_ByBatchno(clsUtility.gConnGP, cboBatchNo.SelectedValue.ToString, False)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                txtPaymentDate.Text = Microsoft.VisualBasic.Right(dt.Rows(0)("TREF_PAIDDATE"), 2) & "/" & dt.Rows(0)("TREF_PAIDDATE").ToString.Substring(4, 2) & "/" & Microsoft.VisualBasic.Left(dt.Rows(0)("TREF_PAIDDATE"), 4)
                txtAmount.Text = Convert.ToDouble(dt.Rows(0)("AMT")).ToString("###,##0.00")
                lblRec.Text = dt.Rows(0)("REC")

                txtLetterNo.Text = clsBusiness.GetMaxLetterNo(clsUtility.gConnGP)
            Else
                txtPaymentDate.Text = ""
                txtAmount.Text = ""
                lblRec.Text = ""
                txtLetterNo.Text = ""
            End If
        Else
            txtPaymentDate.Text = ""
            txtAmount.Text = ""
            lblRec.Text = ""
            txtLetterNo.Text = ""
        End If
    End Sub
    Private Sub BindData_ATS(ByVal BatchNo As String)
        If BatchNo <> "" Then
            Dim dt As New DataTable
            dt = cls.GetDataPRNATS_ByBatchno(clsUtility.gConnGP, BatchNo)
            'ListVouchNo(dt)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                txtPaymentDate.Text = Microsoft.VisualBasic.Right(dt.Rows(0)("TREF_PAIDDATE"), 2) & "/" & dt.Rows(0)("TREF_PAIDDATE").ToString.Substring(4, 2) & "/" & Microsoft.VisualBasic.Left(dt.Rows(0)("TREF_PAIDDATE"), 4)
                txtAmount.Text = Convert.ToDouble(dt.Rows(0)("AMT")).ToString("###,##0.00")
                txtLetterNo.Text = dt.Rows(0)("PATS_LETTERNO")
                lblRec.Text = dt.Rows(0)("PATS_TOT_RECORD")
                txtHash.Text = dt.Rows(0)("PATS_HASH_TOT")
                txtName.Text = dt.Rows(0)("PATS_AUTH_NAME")
                txtPosition.Text = dt.Rows(0)("PATS_AUTH_POSI")
            Else
                txtPaymentDate.Text = ""
                txtAmount.Text = ""
                lblRec.Text = ""
                txtLetterNo.Text = ""

                txtHash.Text = ""
                txtName.Text = ""
                txtPosition.Text = ""
            End If
        Else
            txtPaymentDate.Text = ""
            txtAmount.Text = ""
            lblRec.Text = ""
            txtLetterNo.Text = ""
            txtHash.Text = ""
            txtName.Text = ""
            txtPosition.Text = ""
        End If
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If cboBatchNo.Text.Trim = "" And retBatchNo = "" Then
            MsgBox("Please select Batch No.")
            Exit Sub
        End If
        If txtHash.Text.Trim = "" Then
            MsgBox("Please enter Hash Total")
            txtHash.Focus()
            Exit Sub
        End If
        If txtName.Text.Trim = "" Then
            MsgBox("Please enter ���ͼ�����ӹҨŧ���")
            txtName.Focus()
            Exit Sub
        End If
        If txtPosition.Text.Trim = "" Then
            MsgBox("Please enter ���˹觼�����ӹҨŧ���")
            txtPosition.Focus()
            Exit Sub
        End If


        Dim systemyear As String
        systemyear = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 4)

        If lblStatus = "ADD" Then

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim c1, c2, c3 As Boolean
            c1 = SaveATS(oleTrans)
            c2 = SaveLetterSetup(oleTrans, systemyear)
            c3 = UpdateFlag(oleTrans)

            If c1 And c2 And c3 Then
                oleTrans.Commit()

                PrintReport(cboBatchNo.Text.Trim)
                Me.Close()

            Else
                oleTrans.Rollback()
                MsgBox("Can not Print ATS!")
            End If

        Else

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim c1 As Boolean
            c1 = SaveATS(oleTrans)

            If c1 Then
                oleTrans.Commit()

                PrintReport(retBatchNo)
                Me.Close()

            Else
                oleTrans.Rollback()
                MsgBox("Can not Print ATS!")
            End If

        End If
    End Sub
    Private Sub cboBatchNo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBatchNo.SelectedIndexChanged
        BindData()
    End Sub
    Function UpdateFlag(ByVal oleTrans As OleDbTransaction) As Boolean

        Dim chk As Boolean
        chk = cls.UPD_GP_FLAG_PRNRPTS(clsUtility.gConnGP, oleTrans, cboBatchNo.Text.Trim, gUserLogin, False)

        Return chk
    End Function
    Function SaveATS(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim table As New DataTable
        table.Columns.Add("PATS_BATCH_NO")
        table.Columns.Add("PATS_LETTERNO")
        table.Columns.Add("PATS_HASH_TOT")
        table.Columns.Add("PATS_AUTH_NAME")
        table.Columns.Add("PATS_AUTH_POSI")
        table.Columns.Add("PATS_TOT_RECORD")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        Dim row As DataRow
        row = table.NewRow()
        If lblStatus = "ADD" Then
            row("PATS_BATCH_NO") = cboBatchNo.Text.Trim
        Else
            row("PATS_BATCH_NO") = retBatchNo
        End If

        row("PATS_LETTERNO") = txtLetterNo.Text.Trim ' Microsoft.VisualBasic.Right(txtLetterNo.Text.Trim, 11)
        row("PATS_HASH_TOT") = txtHash.Text.Trim
        row("PATS_AUTH_NAME") = txtName.Text.Trim
        row("PATS_AUTH_POSI") = txtPosition.Text.Trim
        row("PATS_TOT_RECORD") = lblRec.Text
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim chk As Boolean
        If lblStatus = "ADD" Then
            chk = cls.INS_GPS_PRN_ATS(clsUtility.gConnGP, oleTrans, row)
        Else
            chk = cls.UPD_GPS_PRN_ATS(clsUtility.gConnGP, oleTrans, row)
        End If

        Return chk
    End Function
    Function SaveLetterSetup(ByVal oleTrans As OleDbTransaction, ByVal systemyear As String) As Boolean
        Dim table As New DataTable

        table.Columns.Add("LETT_YEAR")
        table.Columns.Add("LETT_NO")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        Dim row As DataRow
        row = table.NewRow()

        row("LETT_YEAR") = systemyear
        row("LETT_NO") = Microsoft.VisualBasic.Right(txtLetterNo.Text.Trim, 6)
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim chk As Boolean
        If Convert.ToDouble(Microsoft.VisualBasic.Right(txtLetterNo.Text.Trim, 6)) = 1 Then
            chk = clsBusiness.INS_GPS_LETTERNO_SETUP(clsUtility.gConnGP, oleTrans, row)
        Else
            chk = clsBusiness.UPD_GPS_LETTERNO_SETUP(clsUtility.gConnGP, oleTrans, row)
        End If

        Return chk
    End Function
    Private Sub PrintReport(ByVal batchno As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptATSSameDay.rpt")

        Dim dt As DataTable = New DataTable()
        dt = cls.GetATSRpt(clsUtility.gConnGP, batchno)

        Dim dtContract As DataTable = New DataTable()
        dtContract = clsBusiness.GetReportContract(clsUtility.gConnGP, "ATS-SD")

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()
            Dim discreteTel As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramTel As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pContactName"
            discrete1.Value = dtContract.Rows(0)("CONT_NAME").ToString
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = Now.ToString("dd/MM/yyyy")
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            paramTel.ParameterFieldName = "pContactTel"
            discreteTel.Value = dtContract.Rows(0)("CONT_TEL_NO").ToString
            paramTel.CurrentValues.Add(discreteTel)
            paramFields.Add(paramTel)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        'PrintReport("CD1400030")
        Me.Close()
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        retHR = False
        retBatchNo = ""
        Dim f As New FrmFindATS
        f.Owner = Me
        f.Text = Me.Text
        f.ShowDialog()

        If retBatchNo <> "" Then
            lblStatus = "EDIT"
            BindData_ATS(retBatchNo)
        End If
    End Sub
End Class