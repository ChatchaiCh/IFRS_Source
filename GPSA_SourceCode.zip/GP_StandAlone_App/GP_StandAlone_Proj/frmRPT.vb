﻿Imports System
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Imports System.Globalization
Imports System.Net.Mail

Public Class frmRPT

    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsValidateManualCloseBatch
    Dim timework As Integer = 1
    Dim systemdate As String '= Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
    Dim server_report_path As String
    Dim ValidationReportPath As String
    Dim UserFullName As String
    Private _cls_cn As System.Data.IDbConnection


    Private Sub GenValidationReport(ByVal systemdate As String, ByVal sReportPath As String, ByVal ValidationReportPath As String, ByVal gUserFullName As String)

        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & systemdate & "' and r.gprj_batchtype='A' and r.gprj_reject_func='VALIDATE' ")

        Dim dt As New DataTable
        Dim clsExportPDF As New clsCrystalToPDFConverter
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then

            Try


                clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByValidation.rpt")
                clsExportPDF.SetPdfDestinationFilePath(ValidationReportPath & "RptErrorByValidation_" & systemdate & "_" & Now.ToString("HHmmss") & "_TLMManualCloseBatch.pdf")

                Dim lstname As New ArrayList
                Dim lstvalue As New ArrayList

                lstname.Add("pTransdate")
                lstname.Add("pUser")

                lstvalue.Add(systemdate)
                lstvalue.Add(gUserFullName)

                clsExportPDF.ExportReport(dt, lstname, lstvalue)

            Catch ex As Exception

            End Try

        End If
    End Sub


    Private Sub frmRPT_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Environment.GetCommandLineArgs.Length = 4 Then

            If clsUtility.gConnGP.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP() = False Then
                    Cursor = Cursors.Default
                    MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                    Exit Sub
                End If
            End If

            If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
                If clsUtility.OpenConnGP_2() = False Then
                    Cursor = Cursors.Default
                    MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                    Exit Sub
                End If
            End If

            systemdate = Environment.GetCommandLineArgs(1).ToString
            server_report_path = Environment.GetCommandLineArgs(2).ToString
            ValidationReportPath = Environment.GetCommandLineArgs(3).ToString
            UserFullName = Environment.GetCommandLineArgs(4).ToString

            Call GenValidationReport(systemdate, server_report_path, ValidationReportPath, UserFullName)

        Else
        End If
    End Sub

    Private Sub btnPrint_Click(sender As System.Object, e As System.EventArgs) Handles btnPrint.Click
        systemdate = "20160125"
        server_report_path = "D:\Working\PBF-150011 SLA Payment (AP-2016-008)\DEV\206-GP Stand Alone\GP Stand Alone\GP_StandAlone_Proj\bin\Debug\Report\"
        ValidationReportPath = "D:\Temp\"
        UserFullName = "TEST_TEST"
        Dim clsManageFile As ManageFile.ClsManageFile

        ''clsManageFile.OpenConnection()

        Call GenValidationReport(systemdate, server_report_path, ValidationReportPath, UserFullName)
    End Sub

    Private Sub btnGLTest_Click(sender As System.Object, e As System.EventArgs) Handles btnGLTest.Click
        Dim dtGLTest As New DataTable
        Try
            dtGLTest = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, GenSQL())
            If dtGLTest.Rows.Count > 0 Then

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Function GenGL(ByRef dtTemp As DataTable) As Boolean
        Dim strBatchDate As String = "20160315"
        Dim strBatchNo As String = "GP2016031501"
        Dim intJN_NO As Integer = 0
        Dim strJN_NO As String = ""
        Dim strCurDate As String = "20160315"
        Dim strTransRefRunning As String = ""
        Dim strVchType As String = ""
        Dim strSQL As String
        Try
            For Each drTemp As DataRow In dtTemp.Rows
                If strTransRefRunning = "" Or strTransRefRunning <> drTemp("TRANSREF") Then
                    If strTransRefRunning <> "" Or strTransRefRunning <> drTemp("TRANSREF") Then
                        If strVchType.Trim.Substring(1, 1) = "P" Then
                            'strSQL = "UPDATE GENERATEPAYMENT.GPS_TRANSREF_REL SET GPS_TRANSREF_REL.TREF_VCH_NO_P = '''||trim(v_get_vch_no) ||''' , TREF_JN_NO_P = '''||trim(vp_Journal_no) ||'''  , TREF_JN_TYPE_P = '''||trim(vq_vch_type) ||''' WHERE GPS_TRANSREF_REL.TREF_TRANSREF = '''||trim(v_transref_running) ||'''  '" ;
                        Else
                            'strSQL = ' UPDATE GENERATEPAYMENT.GPS_TRANSREF_REL SET GPS_TRANSREF_REL.TREF_VCH_NO_J_TAX = '''||trim(v_get_vch_no) ||''' , TREF_JN_NO_J_TAX = '''||trim(vp_Journal_no) ||'''  , TREF_JN_TYPE_J_TAX = '''||trim(vq_vch_type) ||''' WHERE GPS_TRANSREF_REL.TREF_TRANSREF = '''||trim(v_transref_running) ||'''  ' ;
                        End If

                    End If
                End If
            Next
        Catch ex As Exception

        End Try
    End Function

    Private Function GenSQL() As StringBuilder

        Dim sbTemp As StringBuilder
        With sbTemp

            .Append("          SELECT *")
            .Append("          FROM  (")
            .Append("")
            .Append("SELECT *")
            .Append("          FROM  (")
            .Append("          SELECT max(GPS_GL_CREATION.rowid) as row_id, max('p1') as p, max(GPS_GL_CREATION.GLCR_CORE_SYSTEM) as CORE_SYSTEM")
            .Append("                , max(GPS_GL_CREATION.GLCR_JN_TYPE) as JN_TYPE")
            .Append("                , max(GPS_GL_CREATION.GLCR_JN_SOURCE) as JN_SOURCE")
            .Append("                , max(GPS_GL_CREATION.GLCR_GL_PERIOD) as  GL_PERIOD")
            .Append("                , max(GPS_GL_CREATION.GLCR_TRANSREF) as TRANSREF")
            .Append("                , max(GPS_GL_CREATION.GLCR_S_ACCOUNT) as S_ACCOUNT")
            .Append("                , max(GPS_GL_CREATION.GLCR_TRANSDATE) as TRANSDATE")
            .Append("                , max(GPS_GL_CREATION.GLCR_DUEDATE) as DUEDATE")
            .Append("                , max(GPS_GL_CREATION.GLCR_DESC) as DESCCRIPTN")
            .Append("                , sum(GPS_GL_CREATION.GLCR_AMOUNT) as AMOUNT")
            .Append("                , max('C') as DRCR")
            .Append("                , max(GPS_GL_CREATION.GLCR_S_DEP_BRN) as DEP_BRN")
            .Append("                , max(GPS_GL_CREATION.GLCR_S_PL_PT) as PL_PT")
            .Append("                , max(GPS_GL_CREATION.GLCR_S_MKT_EMP) as  MKT_EMP")
            .Append("                , max(GPS_GL_CREATION.GLCR_S_TT_TR) as  TT_TR")
            .Append("                , max(nvl(GPS_GL_CREATION.GLCR_S_PROJECT,'00000')) as T_PROJECT")
            .Append("                , max(nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))) as JN_TYPE_P")
            .Append("                , max(nvl(GPS_TL_DATASOURCE.DTS_DTSOURCE,GPS_GL_CREATION.GLCR_JN_SOURCE)) as DTSOURCE")
            .Append("                , max(nvl(GPS_TRANSREF_REL.TREF_GL_PERIOD,GPS_GL_CREATION.GLCR_GL_PERIOD)) as TREF_GL_PERIOD")
            .Append("                , max(GPS_GL_SETUP.GLS_S_ACCOUNT) as GLS_S_ACCOUNT")
            .Append("                , max(GPS_GL_SETUP.GLS_S_ACCNAME) as GLS_S_ACCNAME")
            .Append("                , max(GPS_GL_SETUP.GLS_S_DEP) as GLS_S_DEP")
            .Append("                , max(GPS_GL_SETUP.GLS_S_BRN) as GLS_S_BRN")
            .Append("                , max(GPS_GL_SETUP.GLS_S_PL) as GLS_S_PL")
            .Append("                , max(GPS_GL_SETUP.GLS_S_PT) as GLS_S_PT")
            .Append("                , max(GPS_GL_SETUP.GLS_S_MKT) as GLS_S_MKT")
            .Append("                , max(GPS_GL_SETUP.GLS_S_EMP) as GLS_S_EMP")
            .Append("                , max(GPS_GL_SETUP.GLS_S_PROJECT) as GLS_S_PROJECT")
            .Append("                , max(GPS_GL_SETUP.GLS_S_TT_TR) as GLS_S_TT_TR")
            .Append("            from(GPS_GL_CREATION)")
            .Append("")
            .Append("                left join GPS_TRANSREF_REL")
            .Append("                       on GPS_GL_CREATION.GLCR_BATCHDATE   = GPS_TRANSREF_REL.TREF_CREATEDATE")
            .Append("                      and GPS_GL_CREATION.GLCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM")
            .Append("                      and GPS_GL_CREATION.GLCR_TRANSREF    = GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("")
            .Append("                left join GPS_TL_DATASOURCE")
            .Append("                       on GPS_TRANSREF_REL.TREF_CORE_SYSTEM = GPS_TL_DATASOURCE.DTS_CORE_SYSTEM")
            .Append("                      and GPS_TRANSREF_REL.TREF_DTSOURCE    = GPS_TL_DATASOURCE.DTS_DTSOURCE")
            .Append("                      and GPS_TRANSREF_REL.TREF_DEP_KEYIN   = GPS_TL_DATASOURCE.DTS_DEP_KEYIN")
            .Append("")
            .Append("                left join GPS_GL_SETUP")
            .Append("                       on nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1)) = GPS_GL_SETUP.GLS_JN_TYPE")
            .Append("                      and GPS_GL_CREATION.GLCR_CORE_SYSTEM = GPS_GL_SETUP.GLS_CORE_SYSTEM")
            .Append("                      and GPS_GL_SETUP.GLS_TABLE = 'GLM_GL_DAILY'")
            .Append("                      and GPS_GL_SETUP.GLS_FUNCTION = 'PAY'")
            .Append("                      and GPS_GL_SETUP.GLS_DRCR = 'C'")
            .Append("                      and GPS_GL_SETUP.GLS_FLAG_WHT = 'N'")
            .Append("")
            .Append("                left join GLM_ACCOUNT_SETUP")
            .Append("                       on GPS_GL_CREATION.GLCR_S_ACCOUNT = GLM_ACCOUNT_SETUP.ACNT_S_CODE")
            .Append("")
            .Append("          where GPS_GL_CREATION.GLCR_TRANSREF in (")
            .Append("                                                   Select GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                                                     from GPS_TRANSREF_REL")
            .Append("                                                    where GPS_TRANSREF_REL.TREF_BATCH_NO = 'GP2016031502'")
            .Append("                                                      and GPS_TRANSREF_REL.TREF_BATCHDATE = '20160315'")
            .Append("                                                      and trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("                                                    group by GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                                                  )")
            .Append("")
            .Append("            ---- Begin Tran Ref not Reject All 20150326")
            .Append("            ---- ต้องตรวจสอบว่า Tran Ref นั่น จะต้องไม่ Reject All คือ Reject ทั้ง File")
            .Append("            and GPS_GL_CREATION.GLCR_TRANSREF not in (")
            .Append("                                                       select GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                                                         from GPS_PAYMENT_REJ")
            .Append("                                                        WHERE GPS_PAYMENT_REJ.GPRJ_BATCH_NO = 'GP2016031502'")
            .Append("                                                          and GPS_PAYMENT_REJ.GPRJ_BATCHDATE = '20160315'")
            .Append("                                                          and GPS_PAYMENT_REJ.GPRJ_REJECT_FUNC = 'VALIDATE'")
            .Append("                                                          and GPS_PAYMENT_REJ.GPRJ_BATCHTYPE = 'A'")
            .Append("                                                          and GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE  in ( 'PAMT_NOMAT' , 'PDTE_NOMAT' ,'DUPT_ERR' ,'TAMT_NOMAT' , 'PDTE_ERR' )")
            .Append("                                                        group by GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                                                      )")
            .Append("")
            .Append("            ---- End Tran Ref not Reject All 20150326")
            .Append("")
            .Append("            and GPS_GL_CREATION.GLCR_DRCR = 'C'")
            .Append("            and GPS_GL_CREATION.GLCR_S_TT_TR = '00000000'")
            .Append("            and GLM_ACCOUNT_SETUP.ACNT_FLAG_ACNTPAY = 'Y'")
            .Append("            -- and  trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("")
            .Append("          group by GPS_GL_CREATION.GLCR_TRANSREF")
            .Append("")
            .Append("          ) MasterDate_Payment_Cr")
            .Append("")
            .Append(" --         order by TRANSREF ;")
            .Append("union")
            .Append("SELECT *")
            .Append("          FROM  (")
            .Append("          SELECT GPS_GL_CREATION.rowid as row_id, ('p2') as p, GPS_GL_CREATION.GLCR_CORE_SYSTEM as CORE_SYSTEM")
            .Append("                , GPS_GL_CREATION.GLCR_JN_TYPE as JN_TYPE")
            .Append("                , GPS_GL_CREATION.GLCR_JN_SOURCE as JN_SOURCE")
            .Append("                , GPS_GL_CREATION.GLCR_GL_PERIOD as  GL_PERIOD")
            .Append("                , GPS_GL_CREATION.GLCR_TRANSREF as TRANSREF")
            .Append("                , GPS_GL_CREATION.GLCR_S_ACCOUNT as S_ACCOUNT")
            .Append("                , GPS_GL_CREATION.GLCR_TRANSDATE as TRANSDATE")
            .Append("                , GPS_GL_CREATION.GLCR_DUEDATE as DUEDATE")
            .Append("                , GPS_GL_CREATION.GLCR_DESC as DESCCRIPTN")
            .Append("                , GPS_GL_CREATION.GLCR_AMOUNT as AMOUNT")
            .Append("                , 'D' as DRCR")
            .Append("                , GPS_GL_CREATION.GLCR_S_DEP_BRN as DEP_BRN")
            .Append("                , GPS_GL_CREATION.GLCR_S_PL_PT as PL_PT")
            .Append("                , GPS_GL_CREATION.GLCR_S_MKT_EMP as  MKT_EMP")
            .Append("                , GPS_GL_CREATION.GLCR_S_TT_TR as  TT_TR")
            .Append("                , nvl(GPS_GL_CREATION.GLCR_S_PROJECT,'00000') as T_PROJECT")
            .Append("                , nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1)) as JN_TYPE_P")
            .Append("                , nvl(GPS_TL_DATASOURCE.DTS_DTSOURCE,GPS_GL_CREATION.GLCR_JN_SOURCE) as DTSOURCE")
            .Append("                , nvl(GPS_TRANSREF_REL.TREF_GL_PERIOD,GPS_GL_CREATION.GLCR_GL_PERIOD) as TREF_GL_PERIOD")
            .Append("                , GPS_GL_SETUP.GLS_S_ACCOUNT as GLS_S_ACCOUNT")
            .Append("                , GPS_GL_SETUP.GLS_S_ACCNAME as GLS_S_ACCNAME")
            .Append("                , GPS_GL_SETUP.GLS_S_DEP as GLS_S_DEP")
            .Append("                , GPS_GL_SETUP.GLS_S_BRN as GLS_S_BRN")
            .Append("                , GPS_GL_SETUP.GLS_S_PL as GLS_S_PL")
            .Append("                , GPS_GL_SETUP.GLS_S_PT as GLS_S_PT")
            .Append("                , GPS_GL_SETUP.GLS_S_MKT as GLS_S_MKT")
            .Append("                , GPS_GL_SETUP.GLS_S_EMP as GLS_S_EMP")
            .Append("                , GPS_GL_SETUP.GLS_S_PROJECT as GLS_S_PROJECT")
            .Append("                , GPS_GL_SETUP.GLS_S_TT_TR as GLS_S_TT_TR")
            .Append("            from(GPS_GL_CREATION)")
            .Append("")
            .Append("                 left join GPS_TRANSREF_REL")
            .Append("                        on GPS_GL_CREATION.GLCR_BATCHDATE = GPS_TRANSREF_REL.TREF_CREATEDATE")
            .Append("                       and GPS_GL_CREATION.GLCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM")
            .Append("                       and GPS_GL_CREATION.GLCR_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("")
            .Append("                 left join GPS_TL_DATASOURCE")
            .Append("                        on GPS_TRANSREF_REL.TREF_CORE_SYSTEM = GPS_TL_DATASOURCE.DTS_CORE_SYSTEM")
            .Append("                       and GPS_TRANSREF_REL.TREF_DTSOURCE = GPS_TL_DATASOURCE.DTS_DTSOURCE")
            .Append("                       and GPS_TRANSREF_REL.TREF_DEP_KEYIN = GPS_TL_DATASOURCE.DTS_DEP_KEYIN")
            .Append("")
            .Append("                 left join GPS_GL_SETUP")
            .Append("                        on GPS_TL_DATASOURCE.DTS_JN_TYPE_P = GPS_GL_SETUP.GLS_JN_TYPE")
            .Append("                       and GPS_GL_CREATION.GLCR_CORE_SYSTEM = GPS_GL_SETUP.GLS_CORE_SYSTEM")
            .Append("                       and GPS_GL_SETUP.GLS_TABLE = 'GLM_GL_DAILY'")
            .Append("                       and GPS_GL_SETUP.GLS_FUNCTION = 'PAY'")
            .Append("                       and GPS_GL_SETUP.GLS_DRCR = 'C'")
            .Append("                       and GPS_GL_SETUP.GLS_FLAG_WHT = 'N'")
            .Append("")
            .Append("                 left join GLM_ACCOUNT_SETUP")
            .Append("                        on GPS_GL_CREATION.GLCR_S_ACCOUNT = GLM_ACCOUNT_SETUP.ACNT_S_CODE")
            .Append("")
            .Append("        where GPS_GL_CREATION.GLCR_TRANSREF in (")
            .Append("                                                Select GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                                                  from GPS_TRANSREF_REL")
            .Append("                                                 where GPS_TRANSREF_REL.TREF_BATCH_NO = 'GP2016031502'")
            .Append("                                                   and GPS_TRANSREF_REL.TREF_BATCHDATE = '20160315'")
            .Append("                                                   and trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("                                                 group by GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                                                )")
            .Append("")
            .Append("                ---- Begin Tran Ref not Reject All 20150326")
            .Append("                ---- ต้องตรวจสอบว่า Tran Ref นั่น จะต้องไม่ Reject All คือ Reject ทั้ง File")
            .Append("          and GPS_GL_CREATION.GLCR_TRANSREF not in (")
            .Append("                                                     select GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                                                       from GPS_PAYMENT_REJ")
            .Append("                                                      WHERE   GPS_PAYMENT_REJ.GPRJ_BATCH_NO = 'GP2016031502'")
            .Append("                                                        and  GPS_PAYMENT_REJ.GPRJ_BATCHDATE = '20160315'")
            .Append("                                                        and  GPS_PAYMENT_REJ.GPRJ_REJECT_FUNC = 'VALIDATE'")
            .Append("                                                        and  GPS_PAYMENT_REJ.GPRJ_BATCHTYPE = 'A'")
            .Append("                                                        and  GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE  in ( 'PAMT_NOMAT' , 'PDTE_NOMAT' ,'DUPT_ERR' ,'TAMT_NOMAT' , 'PDTE_ERR' )")
            .Append("                                                      group by GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                                                     )")
            .Append("")
            .Append("                ---- End Tran Ref not Reject All 20150326")
            .Append("")
            .Append("           and GPS_GL_CREATION.GLCR_DRCR = 'C'")
            .Append("           and GPS_GL_CREATION.GLCR_S_TT_TR = '00000000'")
            .Append("           and GLM_ACCOUNT_SETUP.ACNT_FLAG_ACNTPAY = 'Y'")
            .Append("             --   and  trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("          ) MasterDate_Payment_Dr")
            .Append("     --     order by TRANSREF , TT_TR;")
            .Append("")
            .Append("union")
            .Append("SELECT *")
            .Append("          FROM  (")
            .Append("                SELECT GPS_GL_CREATION.rowid as row_id, ('p3') as p,  GPS_GL_CREATION.GLCR_CORE_SYSTEM as CORE_SYSTEM")
            .Append("                , GPS_GL_CREATION.GLCR_JN_TYPE as JN_TYPE")
            .Append("                , GPS_GL_CREATION.GLCR_JN_SOURCE as JN_SOURCE")
            .Append("                , GPS_GL_CREATION.GLCR_GL_PERIOD as  GL_PERIOD")
            .Append("                , GPS_GL_CREATION.GLCR_TRANSREF as TRANSREF")
            .Append("                , GPS_GL_CREATION.GLCR_S_ACCOUNT as S_ACCOUNT")
            .Append("                , GPS_GL_CREATION.GLCR_TRANSDATE as TRANSDATE")
            .Append("                , GPS_GL_CREATION.GLCR_DUEDATE as DUEDATE")
            .Append("                , GPS_GL_CREATION.GLCR_DESC as DESCCRIPTN")
            .Append("                , GPS_GL_CREATION.GLCR_AMOUNT as AMOUNT")
            .Append("                , 'D' as DRCR")
            .Append("                , GPS_GL_CREATION.GLCR_S_DEP_BRN as DEP_BRN")
            .Append("                , GPS_GL_CREATION.GLCR_S_PL_PT as PL_PT")
            .Append("                , GPS_GL_CREATION.GLCR_S_MKT_EMP as  MKT_EMP")
            .Append("                , GPS_GL_CREATION.GLCR_S_TT_TR as  TT_TR")
            .Append("                , nvl(GPS_GL_CREATION.GLCR_S_PROJECT,'00000') as T_PROJECT")
            .Append("               --, nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1)) as JN_TYPE_P")
            .Append("")
            .Append("               /* , case  when substr(GPS_GL_CREATION.GLCR_DUEDATE,1,7) > to_char(sysdate,'YYYY0MM') then")
            .Append("                nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                else")
            .Append("                  ('J'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                  end as JN_TYPE_P*/")
            .Append("")
            .Append("               /* , case  when substr(GPS_GL_CREATION.GLCR_DUEDATE,1,6) > (to_char(sysdate,'YYYYMM')) then")
            .Append("                nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                else")
            .Append("                  ('J'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                  end as JN_TYPE_P*/")
            .Append("                 , case  when substr(GPS_GL_CREATION.GLCR_DUEDATE,1,6) > (to_char(sysdate,'YYYYMM')) then")
            .Append("                    ('J'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                else")
            .Append("")
            .Append("                  nvl(GPS_TL_DATASOURCE.DTS_JN_TYPE_P,'P'||substr(GPS_GL_CREATION.GLCR_JN_TYPE,2,1))")
            .Append("                  end as JN_TYPE_P")
            .Append("")
            .Append("                , nvl(GPS_TL_DATASOURCE.DTS_DTSOURCE,GPS_GL_CREATION.GLCR_JN_SOURCE) as DTSOURCE")
            .Append("                , nvl(GPS_TRANSREF_REL.TREF_GL_PERIOD,GPS_GL_CREATION.GLCR_GL_PERIOD) as TREF_GL_PERIOD")
            .Append("                , '' as GLS_S_ACCOUNT")
            .Append("                , '' as GLS_S_ACCNAME")
            .Append("                , '' as GLS_S_DEP")
            .Append("                , '' as GLS_S_BRN")
            .Append("                , '' as GLS_S_PL")
            .Append("                , '' as GLS_S_PT")
            .Append("                , '' as GLS_S_MKT")
            .Append("                , '' as GLS_S_EMP")
            .Append("                , '' as GLS_S_PROJECT")
            .Append("                , '' as GLS_S_TT_TR")
            .Append("")
            .Append("            from(GPS_GL_CREATION)")
            .Append("")
            .Append("                left join GPS_TRANSREF_REL")
            .Append("         on GPS_GL_CREATION.GLCR_BATCHDATE = GPS_TRANSREF_REL.TREF_CREATEDATE")
            .Append("         and GPS_GL_CREATION.GLCR_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM")
            .Append("         and GPS_GL_CREATION.GLCR_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("")
            .Append("                left join GPS_TL_DATASOURCE")
            .Append("           on GPS_TRANSREF_REL.TREF_CORE_SYSTEM = GPS_TL_DATASOURCE.DTS_CORE_SYSTEM")
            .Append("          and GPS_TRANSREF_REL.TREF_DTSOURCE = GPS_TL_DATASOURCE.DTS_DTSOURCE")
            .Append("          and GPS_TRANSREF_REL.TREF_DEP_KEYIN = GPS_TL_DATASOURCE.DTS_DEP_KEYIN")
            .Append("")
            .Append("         left join GLM_ACCOUNT_SETUP")
            .Append("             on GPS_GL_CREATION.GLCR_S_ACCOUNT = GLM_ACCOUNT_SETUP.ACNT_S_CODE")
            .Append("")
            .Append("                where GPS_GL_CREATION.GLCR_TRANSREF in")
            .Append("                (")
            .Append("                Select GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                from GPS_TRANSREF_REL")
            .Append("                where GPS_TRANSREF_REL.TREF_BATCH_NO = 'GP2016031503'")
            .Append("                and GPS_TRANSREF_REL.TREF_BATCHDATE = '20160315'")
            .Append("                and  trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("                group by GPS_TRANSREF_REL.TREF_TRANSREF")
            .Append("                )")
            .Append("")
            .Append("                ---- Begin Tran Ref not Reject All 20150326")
            .Append("                ---- ต้องตรวจสอบว่า Tran Ref นั่น จะต้องไม่ Reject All คือ Reject ทั้ง File")
            .Append("                and GPS_GL_CREATION.GLCR_TRANSREF not in")
            .Append("                (")
            .Append("                select GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                from GPS_PAYMENT_REJ")
            .Append("                WHERE   GPS_PAYMENT_REJ.GPRJ_BATCH_NO = 'GP2016031502'")
            .Append("                   and  GPS_PAYMENT_REJ.GPRJ_BATCHDATE = '20160315'")
            .Append("                   and  GPS_PAYMENT_REJ.GPRJ_REJECT_FUNC = 'VALIDATE'")
            .Append("                   and  GPS_PAYMENT_REJ.GPRJ_BATCHTYPE = 'A'")
            .Append("                   and  GPS_PAYMENT_REJ.GPRJ_REJECT_TYPE  in ( 'PAMT_NOMAT' , 'PDTE_NOMAT' ,'DUPT_ERR' ,'TAMT_NOMAT' , 'PDTE_ERR' )")
            .Append("                group by GPS_PAYMENT_REJ.GPRJ_TRANSREF")
            .Append("                  )")
            .Append("")
            .Append("                ---- End Tran Ref not Reject All 20150326")
            .Append("")
            .Append("                and GPS_GL_CREATION.GLCR_DRCR = 'C'")
            .Append("             ---   and GPS_GL_CREATION.GLCR_S_TT_TR <> '00000000'")
            .Append("             and ( GPS_GL_CREATION.GLCR_S_TT_TR <> '00000000'")
            .Append("              or substr(GPS_GL_CREATION.GLCR_S_TT_TR,1,2) in (")
            .Append("                   select substr(GPS_GL_SETUP.GLS_S_TT_TR,1,2) as TAXTYPE")
            .Append("                     from GPS_GL_SETUP")
            .Append("                    where GPS_GL_SETUP.GLS_S_TT_TR <> '00000000'")
            .Append("                     group by substr(GPS_GL_SETUP.GLS_S_TT_TR,1,2)))")
            .Append("                     and  GPS_GL_CREATION.GLCR_S_TT_TR not like '%T%'")
            .Append("                     and GLM_ACCOUNT_SETUP.ACNT_FLAG_ACNTPAY = 'Y'")
            .Append("         --       and  trim(GPS_TRANSREF_REL.TREF_PAYCRETYP_ID) <> trim('006')")
            .Append("")
            .Append("          ) MasterDate_Tax")
            .Append(" ) MasterDate")
            .Append("   order by JN_TYPE_P , TRANSREF , TT_TR;")
            .Append("")
        End With

        Return sbTemp

    End Function

End Class
