﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEncryptDecrypt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtForEncrypt = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnEncrypt = New System.Windows.Forms.Button()
        Me.btnDecrypt = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtForDecrypt = New System.Windows.Forms.TextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnCheckConnection = New System.Windows.Forms.Button()
        Me.btnGetConfig = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtForEncrypt
        '
        Me.txtForEncrypt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtForEncrypt.Location = New System.Drawing.Point(12, 33)
        Me.txtForEncrypt.Multiline = True
        Me.txtForEncrypt.Name = "txtForEncrypt"
        Me.txtForEncrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtForEncrypt.Size = New System.Drawing.Size(502, 84)
        Me.txtForEncrypt.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Text for Encrypt"
        '
        'btnEncrypt
        '
        Me.btnEncrypt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnEncrypt.Location = New System.Drawing.Point(386, 123)
        Me.btnEncrypt.Name = "btnEncrypt"
        Me.btnEncrypt.Size = New System.Drawing.Size(128, 30)
        Me.btnEncrypt.TabIndex = 2
        Me.btnEncrypt.Text = "Encrypt"
        Me.btnEncrypt.UseVisualStyleBackColor = True
        '
        'btnDecrypt
        '
        Me.btnDecrypt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnDecrypt.Location = New System.Drawing.Point(386, 276)
        Me.btnDecrypt.Name = "btnDecrypt"
        Me.btnDecrypt.Size = New System.Drawing.Size(128, 29)
        Me.btnDecrypt.TabIndex = 5
        Me.btnDecrypt.Text = "Decrypt"
        Me.btnDecrypt.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 167)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Text for Decrypt"
        '
        'txtForDecrypt
        '
        Me.txtForDecrypt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtForDecrypt.Location = New System.Drawing.Point(15, 186)
        Me.txtForDecrypt.Multiline = True
        Me.txtForDecrypt.Name = "txtForDecrypt"
        Me.txtForDecrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtForDecrypt.Size = New System.Drawing.Size(499, 84)
        Me.txtForDecrypt.TabIndex = 3
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnClose.Location = New System.Drawing.Point(12, 354)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(502, 37)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnCheckConnection
        '
        Me.btnCheckConnection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnCheckConnection.Location = New System.Drawing.Point(12, 311)
        Me.btnCheckConnection.Name = "btnCheckConnection"
        Me.btnCheckConnection.Size = New System.Drawing.Size(502, 37)
        Me.btnCheckConnection.TabIndex = 7
        Me.btnCheckConnection.Text = "Check Connection"
        Me.btnCheckConnection.UseVisualStyleBackColor = True
        '
        'btnGetConfig
        '
        Me.btnGetConfig.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnGetConfig.Location = New System.Drawing.Point(15, 276)
        Me.btnGetConfig.Name = "btnGetConfig"
        Me.btnGetConfig.Size = New System.Drawing.Size(208, 29)
        Me.btnGetConfig.TabIndex = 8
        Me.btnGetConfig.Text = "Get Connection from Config"
        Me.btnGetConfig.UseVisualStyleBackColor = True
        '
        'frmEncryptDecrypt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(529, 400)
        Me.Controls.Add(Me.btnGetConfig)
        Me.Controls.Add(Me.btnCheckConnection)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDecrypt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtForDecrypt)
        Me.Controls.Add(Me.btnEncrypt)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtForEncrypt)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEncryptDecrypt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Encrypt Decrypt"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtForEncrypt As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnEncrypt As System.Windows.Forms.Button
    Friend WithEvents btnDecrypt As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtForDecrypt As System.Windows.Forms.TextBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnCheckConnection As System.Windows.Forms.Button
    Friend WithEvents btnGetConfig As System.Windows.Forms.Button
End Class
