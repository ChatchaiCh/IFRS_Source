﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFLWBILLReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtApproveDateTo = New System.Windows.Forms.TextBox()
        Me.txtApproveDateFrom = New System.Windows.Forms.TextBox()
        Me.txtPurPoseDateTo = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboCoreSystem = New System.Windows.Forms.ComboBox()
        Me.txtPurPoseDateFrom = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboType = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.CmdPreview = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(51, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Core System"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.Label8)
        Me.PanelD1.Controls.Add(Me.txtApproveDateTo)
        Me.PanelD1.Controls.Add(Me.txtApproveDateFrom)
        Me.PanelD1.Controls.Add(Me.txtPurPoseDateTo)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.Label11)
        Me.PanelD1.Controls.Add(Me.cboCoreSystem)
        Me.PanelD1.Controls.Add(Me.txtPurPoseDateFrom)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.Label4)
        Me.PanelD1.Controls.Add(Me.cboType)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Location = New System.Drawing.Point(12, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(496, 166)
        Me.PanelD1.TabIndex = 110
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(404, 77)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(85, 13)
        Me.Label8.TabIndex = 84
        Me.Label8.Text = "(DD/MM/CCYY)"
        '
        'txtApproveDateTo
        '
        Me.txtApproveDateTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtApproveDateTo.Location = New System.Drawing.Point(280, 74)
        Me.txtApproveDateTo.MaxLength = 10
        Me.txtApproveDateTo.Name = "txtApproveDateTo"
        Me.txtApproveDateTo.Size = New System.Drawing.Size(119, 20)
        Me.txtApproveDateTo.TabIndex = 83
        '
        'txtApproveDateFrom
        '
        Me.txtApproveDateFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtApproveDateFrom.Location = New System.Drawing.Point(119, 74)
        Me.txtApproveDateFrom.MaxLength = 10
        Me.txtApproveDateFrom.Name = "txtApproveDateFrom"
        Me.txtApproveDateFrom.Size = New System.Drawing.Size(119, 20)
        Me.txtApproveDateFrom.TabIndex = 82
        '
        'txtPurPoseDateTo
        '
        Me.txtPurPoseDateTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPurPoseDateTo.Location = New System.Drawing.Point(280, 49)
        Me.txtPurPoseDateTo.MaxLength = 10
        Me.txtPurPoseDateTo.Name = "txtPurPoseDateTo"
        Me.txtPurPoseDateTo.Size = New System.Drawing.Size(119, 20)
        Me.txtPurPoseDateTo.TabIndex = 81
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(404, 51)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 13)
        Me.Label11.TabIndex = 80
        Me.Label11.Text = "(DD/MM/CCYY)"
        '
        'cboCoreSystem
        '
        Me.cboCoreSystem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCoreSystem.FormattingEnabled = True
        Me.cboCoreSystem.Location = New System.Drawing.Point(119, 22)
        Me.cboCoreSystem.Name = "cboCoreSystem"
        Me.cboCoreSystem.Size = New System.Drawing.Size(119, 21)
        Me.cboCoreSystem.TabIndex = 47
        '
        'txtPurPoseDateFrom
        '
        Me.txtPurPoseDateFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPurPoseDateFrom.Location = New System.Drawing.Point(119, 49)
        Me.txtPurPoseDateFrom.MaxLength = 10
        Me.txtPurPoseDateFrom.Name = "txtPurPoseDateFrom"
        Me.txtPurPoseDateFrom.Size = New System.Drawing.Size(119, 20)
        Me.txtPurPoseDateFrom.TabIndex = 79
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(254, 74)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(20, 13)
        Me.Label7.TabIndex = 50
        Me.Label7.Text = "To"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(254, 47)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(20, 13)
        Me.Label6.TabIndex = 49
        Me.Label6.Text = "To"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 13)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Flag ติดตามใบเสร็จ"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 13)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Posting Date From"
        '
        'cboType
        '
        Me.cboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboType.FormattingEnabled = True
        Me.cboType.Location = New System.Drawing.Point(119, 100)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(119, 21)
        Me.cboType.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pre Posting Date From"
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(12, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(496, 38)
        Me.PanelH1.TabIndex = 109
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(143, 12)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(221, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "รายงานรายการใบเสร็จรับประจำวัน"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(427, 228)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(81, 28)
        Me.btnExit.TabIndex = 112
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'CmdPreview
        '
        Me.CmdPreview.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb1
        Me.CmdPreview.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.CmdPreview.DialogResult = System.Windows.Forms.DialogResult.None
        Me.CmdPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.CmdPreview.ForeColor = System.Drawing.Color.White
        Me.CmdPreview.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.CmdPreview.Image = Nothing
        Me.CmdPreview.ImageKey = ""
        Me.CmdPreview.ImageList = Nothing
        Me.CmdPreview.Location = New System.Drawing.Point(340, 228)
        Me.CmdPreview.Name = "CmdPreview"
        Me.CmdPreview.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.CmdPreview.Size = New System.Drawing.Size(81, 28)
        Me.CmdPreview.TabIndex = 111
        Me.CmdPreview.Text = "Print"
        Me.CmdPreview.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdPreview.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmFLWBILLReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(520, 268)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.CmdPreview)
        Me.Controls.Add(Me.PanelH1)
        Me.Name = "FrmFLWBILLReport"
        Me.Text = "FrmFlagGPReport"
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents cboType As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdPreview As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cboCoreSystem As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPurPoseDateTo As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtPurPoseDateFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtApproveDateTo As System.Windows.Forms.TextBox
    Friend WithEvents txtApproveDateFrom As System.Windows.Forms.TextBox
End Class
