<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrintCHQOtherBankProcess
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.cboBankCode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtChequeNo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPayeeName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.txtPaymentDate = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnPrint = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.PanelH1.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtBankName
        '
        Me.txtBankName.Enabled = False
        Me.txtBankName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBankName.Location = New System.Drawing.Point(201, 5)
        Me.txtBankName.MaxLength = 15
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(320, 20)
        Me.txtBankName.TabIndex = 66
        '
        'cboBankCode
        '
        Me.cboBankCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBankCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboBankCode.FormattingEnabled = True
        Me.cboBankCode.Location = New System.Drawing.Point(108, 5)
        Me.cboBankCode.Name = "cboBankCode"
        Me.cboBankCode.Size = New System.Drawing.Size(87, 21)
        Me.cboBankCode.TabIndex = 65
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(5, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 64
        Me.Label2.Text = "Bank Cheque :"
        '
        'PanelH1
        '
        Me.PanelH1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelH1.Controls.Add(Me.Label33)
        Me.PanelH1.Location = New System.Drawing.Point(7, 12)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(533, 38)
        Me.PanelH1.TabIndex = 67
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(65, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(409, 17)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "��������Թ�͹��Һѭ���ӹѡ�ҹ�˭� (Other bank----> SCB)"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtChequeNo
        '
        Me.txtChequeNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtChequeNo.Location = New System.Drawing.Point(108, 32)
        Me.txtChequeNo.MaxLength = 10
        Me.txtChequeNo.Name = "txtChequeNo"
        Me.txtChequeNo.Size = New System.Drawing.Size(140, 20)
        Me.txtChequeNo.TabIndex = 68
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(5, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "Cheque No :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(5, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 70
        Me.Label3.Text = "Payee Name :"
        '
        'txtPayeeName
        '
        Me.txtPayeeName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPayeeName.Location = New System.Drawing.Point(108, 63)
        Me.txtPayeeName.MaxLength = 100
        Me.txtPayeeName.Name = "txtPayeeName"
        Me.txtPayeeName.Size = New System.Drawing.Size(413, 20)
        Me.txtPayeeName.TabIndex = 71
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(5, 92)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 72
        Me.Label4.Text = "�ӹǹ�Թ :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(5, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 73
        Me.Label5.Text = "Payment Date :"
        '
        'txtAmount
        '
        Me.txtAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtAmount.Location = New System.Drawing.Point(108, 89)
        Me.txtAmount.MaxLength = 15
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(140, 20)
        Me.txtAmount.TabIndex = 74
        '
        'txtPaymentDate
        '
        Me.txtPaymentDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtPaymentDate.Location = New System.Drawing.Point(108, 118)
        Me.txtPaymentDate.MaxLength = 10
        Me.txtPaymentDate.Name = "txtPaymentDate"
        Me.txtPaymentDate.Size = New System.Drawing.Size(140, 20)
        Me.txtPaymentDate.TabIndex = 75
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(256, 92)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 13)
        Me.Label6.TabIndex = 76
        Me.Label6.Text = "�ҷ"
        '
        'PanelD1
        '
        Me.PanelD1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelD1.Controls.Add(Me.Label11)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.txtPaymentDate)
        Me.PanelD1.Controls.Add(Me.txtAmount)
        Me.PanelD1.Controls.Add(Me.Label5)
        Me.PanelD1.Controls.Add(Me.txtBankName)
        Me.PanelD1.Controls.Add(Me.Label4)
        Me.PanelD1.Controls.Add(Me.txtPayeeName)
        Me.PanelD1.Controls.Add(Me.Label3)
        Me.PanelD1.Controls.Add(Me.Label1)
        Me.PanelD1.Controls.Add(Me.txtChequeNo)
        Me.PanelD1.Controls.Add(Me.cboBankCode)
        Me.PanelD1.Controls.Add(Me.Label2)
        Me.PanelD1.Location = New System.Drawing.Point(7, 56)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(532, 151)
        Me.PanelD1.TabIndex = 79
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(254, 121)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 13)
        Me.Label11.TabIndex = 79
        Me.Label11.Text = "(DD/MM/CCYY)"
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(123, 213)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(92, 28)
        Me.btnExit.TabIndex = 78
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnPrint
        '
        Me.btnPrint.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(255, 235, 200)
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnPrint.Image = Nothing
        Me.btnPrint.ImageKey = ""
        Me.btnPrint.ImageList = Nothing
        Me.btnPrint.Location = New System.Drawing.Point(7, 213)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnPrint.Size = New System.Drawing.Size(110, 28)
        Me.btnPrint.TabIndex = 77
        Me.btnPrint.Text = "Save && Print"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'FrmPrintCHQOtherBankProcess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(557, 258)
        Me.Controls.Add(Me.PanelD1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.PanelH1)
        Me.Name = "FrmPrintCHQOtherBankProcess"
        Me.Text = "��������Թ�͹��Һѭ���ӹѡ�ҹ�˭� (Other bank----> SCB)"
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtBankName As System.Windows.Forms.TextBox
    Friend WithEvents cboBankCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtChequeNo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPayeeName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtPaymentDate As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnPrint As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
