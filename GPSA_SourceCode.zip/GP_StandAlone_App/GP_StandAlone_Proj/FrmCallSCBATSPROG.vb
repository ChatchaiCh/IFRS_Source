Public Class FrmCallSCBATSPROG

    Private Sub FrmCallSCBATSPROG_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Process.Start("EXCEL.EXE", """" & CALLSCBATSPROG & """")
        Catch ex As Exception
            Me.Close()
        End Try
        Me.Close()
    End Sub
End Class