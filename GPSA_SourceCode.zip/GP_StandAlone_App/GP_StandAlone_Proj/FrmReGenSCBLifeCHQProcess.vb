Imports UtilityClassLibrary
Imports System.Text
Imports System.Data.OleDb
Public Class FrmReGenSCBLifeCHQProcess
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub FrmCancelCheque_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()

        DisplayBankServiceCode()

    End Sub
    Private Sub DisplayBankServiceCode()

        Dim sb As New StringBuilder()
        sb.Append(" select GPS_TL_BANKMASTER.BKMST_BNKCODE as BKMST_BNKCODE , GPS_TL_BANKMASTER.BKMST_BNKNAME as BKMST_BNKNAME ")
        sb.Append(" from GPS_TL_BANKSERVICE1 , GPS_TL_BANKMASTER ")
        sb.Append(" where GPS_TL_BANKSERVICE1.BNKS_BNKSCODE_NO = GPS_TL_BANKMASTER.BKMST_BNKCODE_NO ")
        sb.Append(" and GPS_TL_BANKSERVICE1.BNKS_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" order by GPS_TL_BANKMASTER.BKMST_BNKCODE , GPS_TL_BANKMASTER.BKMST_BNKNAME ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count <> 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboBankCode
                .DataSource = dt
                .DisplayMember = "BKMST_BNKCODE"
                .ValueMember = "BKMST_BNKCODE"
            End With

            txtBankName.Text = dt.Rows(0)("BKMST_BNKNAME").ToString

        End If
        'cboType.SelectedValue = 0
    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "GP_CHQNO"
            .Name = "Cheque No"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "GP_CHQNO_NEW"
            .Name = "Cheque No (New)"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c2)
        End With
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "GP_PAIDDATE_SHOW"
            .Name = "Payment Date"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "GP_PAYEE_NAME"
            .Name = "Name"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "GP_AMOUNT"
            .Name = "Net Amount"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c5)
        End With
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "STS_DESC"
            .Name = "Status Print"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c6)
        End With


        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "GP_PRINTCHQ_STSDATE_SHOW"
            .Name = "Status Print Date "
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c7)
        End With


        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)
        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(4).DefaultCellStyle.Format = "#,###.00" 'AMOUNT Cheque
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

            retAccCode = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
            retAccName = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
            Me.Close()

        End If
    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        If (Trim(txtBegin.Text) <> "") And (Trim(txtEnd.Text) <> "") Then

            GetData()
            'btnLoad.Enabled = False
            'btnPrint.Enabled = True

        Else
            MsgBox("�ô��͡������㹪�ͧ Cheque No Begin ��� To ")
            Exit Sub
        End If
    End Sub

    Private Sub GetData()
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.WaitCursor
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim sb As New StringBuilder()

        sb.Append(" select GPS_PAYMENT.GP_PAYMTH , GPS_PAYMENT.GP_SUB_PAYMTH  , GPS_TL_PAYTYPE.PAYT_PAY_GROUP , GPS_PAYMENT.GP_BNKSCODE ")
        sb.Append(" , GPS_PAYMENT.GP_BNKCODE_NO , GPS_PAYMENT.GP_BNKNAME , GPS_PAYMENT.GP_CHQNO , '' as GP_CHQNO_NEW  ")
        sb.Append(" , GPS_PAYMENT.GP_PAIDDATE  ")
        sb.Append(" , substr(GPS_PAYMENT.GP_PAIDDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_PAIDDATE,1,4) as GP_PAIDDATE_SHOW  ")
        sb.Append("  , GPS_PAYMENT.GP_PAYEE_NAME , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_PRINTCHQ_STS  ")
        sb.Append(" ,NVL(GPS_TL_STATUS.STS_DESC,'') as STS_DESC , GPS_PAYMENT.GP_PRINTCHQ_STSDATE   ")
        sb.Append("  , substr(GPS_PAYMENT.GP_PRINTCHQ_STSDATE,7,2)||'/'||substr(GPS_PAYMENT.GP_PRINTCHQ_STSDATE,5,2)||'/'||substr(GPS_PAYMENT.GP_PRINTCHQ_STSDATE,1,4) as GP_PRINTCHQ_STSDATE_SHOW  ")


        sb.Append(" from GPS_PAYMENT ")
        '----- ���������ǹ�ͧ�������è��� �����͡੾�� Payment ��� Sub payment �ͧ SCBLIFE_CHQ ��ҹ�� 
        sb.Append(" left join GPS_TL_PAYTYPE ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '----- ���������ǹ�ͧʶҹС�þ����
        sb.Append(" left join GPS_TL_STATUS ")
        sb.Append(" on GPS_PAYMENT.GP_PRINTCHQ_STS = GPS_TL_STATUS.STS_STATUS ")
        sb.Append(" and GPS_TL_STATUS.STS_TYPE = 'PRN_SCBLIFE_CHQ' ")

        sb.Append(" where GPS_TL_PAYTYPE.PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_PAYMENT.GP_PRINTCHQ_STS <> 'I' ")
        sb.Append(" and ( GPS_PAYMENT.GP_CHQNO between '" & Trim(txtBegin.Text) & "' and '" & Trim(txtEnd.Text) & "' )")
        sb.Append(" order by GPS_PAYMENT.GP_CHQNO ")


        Dim dt As DataTable
        'dt.Clear()
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
            GetDataSummary()
            btnLoad.Enabled = False
            btnCancelChq.Enabled = True

        Else
            dt = Nothing
            MsgBox("��辺������ ������͹�")
        End If

    End Sub

    Private Sub GetDataSummary()
        Dim sb As New StringBuilder()

        sb.Append(" select COUNT(GPS_PAYMENT.GP_AMOUNT) as COUNT_AMOUNT  ")
        sb.Append(" , SUM(GPS_PAYMENT.GP_AMOUNT) as SUM_AMOUNT  ")
        sb.Append(" ,  MAX(GPS_PAYMENT.GP_BNKSCODE) as MAX_BNKSCODE  ")
        sb.Append(" , MAX(GPS_PAYMENT.GP_BNKNAME) as MAX_BKMST_BNKNAME  ")
        sb.Append(" from GPS_PAYMENT ")
        '----- ���������ǹ�ͧ�������è��� �����͡੾�� Payment ��� Sub payment �ͧ SCBLIFE_CHQ ��ҹ�� 
        sb.Append(" left join GPS_TL_PAYTYPE ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '----- ���������ǹ�ͧʶҹС�þ����
        sb.Append(" left join GPS_TL_STATUS ")
        sb.Append(" on GPS_PAYMENT.GP_PRINTCHQ_STS = GPS_TL_STATUS.STS_STATUS ")
        sb.Append(" and GPS_TL_STATUS.STS_TYPE = 'PRN_SCBLIFE_CHQ' ")

        sb.Append(" where GPS_TL_PAYTYPE.PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_PAYMENT.GP_PRINTCHQ_STS <> 'I' ")
        sb.Append(" and ( GPS_PAYMENT.GP_CHQNO between '" & Trim(txtBegin.Text) & "' and '" & Trim(txtEnd.Text) & "' )")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count <> 0 Then
            txtLine.Text = dt.Rows(0)("COUNT_AMOUNT").ToString
            'txtAmount.Text = dt.Rows(0)("SUM_AMOUNT").ToString
            txtAmount.Text = Format(CDbl(dt.Rows(0)("SUM_AMOUNT").ToString), "#,###.00")
            cboBankCode.Text = dt.Rows(0)("MAX_BNKSCODE").ToString
            txtBankName.Text = dt.Rows(0)("MAX_BKMST_BNKNAME").ToString

        End If

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        PrintReport()
        'Me.Close()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        btnLoad.Enabled = True
        ClearScreen()
    End Sub

    Private Sub btnCancelChq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelChq.Click
        If (Trim(txtReason.Text) <> "") Then
            ReGenChqNo()
            btnPrint.Enabled = True
        Else
            MsgBox("�ô��͡������㹪�ͧ Remark")
            Exit Sub
        End If
    End Sub

    Private Sub ReGenChqNo()

        Dim oleTrans As OleDbTransaction
        Dim StrChqNo As String
        Dim StrSQLChqNo As String
        Dim NumChqNo As Double
        Dim StrRang As String
        Dim TotalChq_Rang_1 As Integer
        Dim TotalChq_Rang_2 As Integer
        Dim StrChqNo1 As String
        Dim StrChqNo2 As String
        Dim TotalChq_CC As Integer
        Dim strRang1_Finish As String


        StrChqNo = ""
        StrSQLChqNo = ""
        NumChqNo = 0
        StrRang = "1"
        TotalChq_CC = 0
        strRang1_Finish = "N"

        Dim sb As New StringBuilder()

        'sb.Append(" select  ")
        'sb.Append(" case ")
        'sb.Append(" when GPS_CHEQUE_SETUP.CHQS_E_CHQ1 = GPS_CHEQUE_SETUP.CHQS_S_CHQ1 and GPS_CHEQUE_SETUP. then ")
        'sb.Append(" GPS_CHEQUE_SETUP.CHQS_S_CHQ2 ")
        'sb.Append(" else GPS_CHEQUE_SETUP.CHQS_S_CHQ1 end CHQS_S_CHQ1 ")
        'sb.Append(" , case  ")
        'sb.Append(" when GPS_CHEQUE_SETUP.CHQS_E_CHQ1 <= GPS_CHEQUE_SETUP.CHQS_S_CHQ1 then ")
        'sb.Append(" '2' ")
        'sb.Append(" else '1' end RENG_CHQS_S_CHQ ")
        'sb.Append(" from GPS_CHEQUE_SETUP  ")
        'sb.Append(" where GPS_CHEQUE_SETUP.CHQS_PAY_GROUP = 'SCBLIFE_CHQ' ")
        'sb.Append(" and GPS_CHEQUE_SETUP.CHQS_BNKSCODE_NO = '014' ")

        sb.Append(" select CHQS_S_CHQ1, ")
        sb.Append(" CHQS_E_CHQ1, ")
        sb.Append(" CHQS_S_CHQ1_FINISH, ")
        sb.Append(" DECODE(CHQS_S_CHQ1_FINISH,'Y',0,CHQS_E_CHQ1-CHQS_S_CHQ1+1) as TotalChq_Rang_1, ")
        sb.Append(" CHQS_S_CHQ2, ")
        sb.Append(" CHQS_E_CHQ2, ")
        sb.Append(" CHQS_S_CHQ2_FINISH, ")
        sb.Append(" DECODE(NVL(CHQS_S_CHQ2_FINISH,'Y'),'Y',0,CHQS_E_CHQ2-CHQS_S_CHQ2+1) as TotalChq_Rang_2 ")
        sb.Append(" from GPS_CHEQUE_SETUP ")
        sb.Append(" where GPS_CHEQUE_SETUP.CHQS_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_CHEQUE_SETUP.CHQS_BNKSCODE_NO = '014' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count <> 0 Then
            If dt.Rows(0)("TotalChq_Rang_1").ToString <> "0" Then
                StrSQLChqNo = dt.Rows(0)("CHQS_S_CHQ1").ToString
                NumChqNo = Convert.ToDouble(dt.Rows(0)("CHQS_S_CHQ1").ToString)
                'StrRang = dt.Rows(0)("RENG_CHQS_S_CHQ").ToString
            Else
                StrSQLChqNo = dt.Rows(0)("CHQS_S_CHQ2").ToString
                NumChqNo = Convert.ToDouble(dt.Rows(0)("CHQS_S_CHQ2").ToString)
            End If

            TotalChq_Rang_1 = dt.Rows(0)("TotalChq_Rang_1").ToString
            TotalChq_Rang_2 = dt.Rows(0)("TotalChq_Rang_2").ToString
            StrChqNo1 = dt.Rows(0)("CHQS_S_CHQ1").ToString
            StrChqNo2 = dt.Rows(0)("CHQS_S_CHQ2").ToString
        End If

        oleTrans = clsUtility.gConnGP.BeginTransaction

        If DataGridView1.RowCount > 0 Then
            Dim Rec As Integer

            txtBegin.Text = StrSQLChqNo.PadLeft(10, "0")

            For index As Integer = 0 To DataGridView1.RowCount - 1
                StrChqNo = Convert.ToString(NumChqNo)
                DataGridView1.Rows(index).Cells(1).Value = StrChqNo.PadLeft(10, "0")

                Dim sb2 As New StringBuilder()
                sb2.Append(" UPDATE GPS_PAYMENT ")
                sb2.Append(" SET GP_CHQNO = '" & DataGridView1.Rows(index).Cells(1).Value & "' ")
                sb2.Append(" , GP_CHQNO_OLD = '" & DataGridView1.Rows(index).Cells(0).Value & "' ")
                sb2.Append(" , GP_REMARK_REGENCHQ = '" & Trim(txtReason.Text) & "' ")
                sb2.Append(" , GP_PRINTCHQ_STS = 'C' ")
                sb2.Append(" , GP_PRINTCHQ_STSDATE = TO_CHAR(SYSDATE,'YYYYMMDD') ")
                sb2.Append(" , UPDATEDBY = '" & gUserLogin & "' , UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
                sb2.Append(" WHERE GP_CHQNO = '" & DataGridView1.Rows(index).Cells(0).Value & "' ")

                Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb2, oleTrans)

                NumChqNo = NumChqNo + 1

                TotalChq_CC = TotalChq_CC + 1

                If strRang1_Finish = "N" Then
                    If TotalChq_CC >= TotalChq_Rang_1 And TotalChq_Rang_1 <> 0 Then
                        NumChqNo = Convert.ToDouble(StrChqNo2)
                        strRang1_Finish = "Y"
                    End If
                End If

            Next

            StrChqNo = Convert.ToString(NumChqNo - 1)
            txtEnd.Text = StrChqNo.PadLeft(10, "0")

            If Rec = DataGridView1.RowCount Then
                oleTrans.Commit()
                MsgBox(" Update Records successfully")

                oleTrans = clsUtility.gConnGP.BeginTransaction
                StrChqNo = Convert.ToString(NumChqNo)

                Dim sb3 As New StringBuilder()

                sb3.Append(" UPDATE GPS_CHEQUE_SETUP ")
                sb3.Append(" SET ")
                If TotalChq_Rang_1 <> 0 Then
                    If TotalChq_CC > TotalChq_Rang_1 Then
                        sb3.Append(" GPS_CHEQUE_SETUP.CHQS_S_CHQ1 = GPS_CHEQUE_SETUP.CHQS_E_CHQ1 ")
                        sb3.Append(" , GPS_CHEQUE_SETUP.CHQS_S_CHQ1_FINISH = 'Y' ")
                        sb3.Append(" , GPS_CHEQUE_SETUP.CHQS_S_CHQ2 = '" & StrChqNo.PadLeft(StrSQLChqNo.Length, "0") & "' ")
                    ElseIf TotalChq_CC = TotalChq_Rang_1 Then
                        sb3.Append(" GPS_CHEQUE_SETUP.CHQS_S_CHQ1 = GPS_CHEQUE_SETUP.CHQS_E_CHQ1 ")
                        sb3.Append(" , GPS_CHEQUE_SETUP.CHQS_S_CHQ1_FINISH = 'Y' ")
                    Else
                        sb3.Append(" GPS_CHEQUE_SETUP.CHQS_S_CHQ1 = '" & StrChqNo.PadLeft(StrSQLChqNo.Length, "0") & "' ")
                    End If
                Else
                    sb3.Append(" GPS_CHEQUE_SETUP.CHQS_S_CHQ2 = '" & StrChqNo.PadLeft(StrSQLChqNo.Length, "0") & "' ")
                End If
                sb3.Append(" , UPDATEDBY = '" & gUserLogin & "' , UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD') ")

                'sb3.Append(" UPDATE GPS_CHEQUE_SETUP ")

                'If (StrRang = "1") Then
                '    sb3.Append(" SET CHQS_S_CHQ1 = '" & StrChqNo.PadLeft(StrSQLChqNo.Length, "0") & "' ")
                'Else
                '    sb3.Append(" SET GPS_CHEQUE_SETUP.CHQS_S_CHQ2 = '" & StrChqNo.PadLeft(StrSQLChqNo.Length, "0") & "' ")
                'End If
                'sb3.Append(" , UPDATEDBY = '" & gUserLogin & "' , UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD') ")


                Rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb3, oleTrans)
                oleTrans.Commit()

            Else
                oleTrans.Rollback()
                MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
            End If


        End If


    End Sub

    Private Sub PrintReport()

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptPrintSCBLifeCHQ.rpt")



        Dim dt As DataTable = New DataTable()

        dt = GetDataPrint()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()

            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()



            param1.ParameterFieldName = "pTransdate"
            discrete1.Value = "01/10/2014"
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            'discreteUser.Value = "SOA"
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

            'UpdateStatusPrintChq()

        Else
            MsgBox("��辺�����ŵ�����͹�")
        End If

        'gConnSPI.Close()
    End Sub

    Function GetDataPrint() As DataTable


        Dim sb As New StringBuilder()

        sb.Append(" select GPS_PAYMENT.GP_PAYMTH , GPS_PAYMENT.GP_SUB_PAYMTH  , GPS_TL_PAYTYPE.PAYT_PAY_GROUP , GPS_PAYMENT.GP_BNKSCODE ")
        sb.Append(" , GPS_PAYMENT.GP_BNKCODE_NO , GPS_PAYMENT.GP_BNKNAME , GPS_PAYMENT.GP_CHQNO , '' as GP_CHQNO_NEW  ")
        sb.Append(" , GPS_PAYMENT.GP_PAIDDATE  ")
        sb.Append("  , GPS_PAYMENT.GP_PAYEE_NAME , GPS_PAYMENT.GP_AMOUNT , GPS_PAYMENT.GP_PRINTCHQ_STS  ")
        sb.Append(" ,NVL(GPS_TL_STATUS.STS_DESC,'') as STS_DESC , GPS_PAYMENT.GP_PRINTCHQ_STSDATE   ")
        sb.Append(" from GPS_PAYMENT ")
        '----- ���������ǹ�ͧ�������è��� �����͡੾�� Payment ��� Sub payment �ͧ SCBLIFE_CHQ ��ҹ�� 
        sb.Append(" left join GPS_TL_PAYTYPE ")
        sb.Append(" on GPS_PAYMENT.GP_PAYMTH = GPS_TL_PAYTYPE.PAYT_PAYMTH ")
        sb.Append(" and GPS_PAYMENT.GP_SUB_PAYMTH = GPS_TL_PAYTYPE.PAYT_SUB_PAYMTH ")
        '----- ���������ǹ�ͧʶҹС�þ����
        sb.Append(" left join GPS_TL_STATUS ")
        sb.Append(" on GPS_PAYMENT.GP_PRINTCHQ_STS = GPS_TL_STATUS.STS_STATUS ")
        sb.Append(" and GPS_TL_STATUS.STS_TYPE = 'PRN_SCBLIFE_CHQ' ")

        sb.Append(" where GPS_TL_PAYTYPE.PAYT_PAY_GROUP = 'SCBLIFE_CHQ' ")
        sb.Append(" and GPS_PAYMENT.GP_PRINTCHQ_STS <> 'I' ")
        sb.Append(" and ( GPS_PAYMENT.GP_CHQNO between '" & Trim(txtBegin.Text) & "' and '" & Trim(txtEnd.Text) & "' )")
        sb.Append(" order by GPS_PAYMENT.GP_CHQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function


    Private Sub ClearScreen()

        txtBegin.Text = ""
        txtEnd.Text = ""
        txtReason.Text = ""
        txtLine.Text = "0"
        txtAmount.Text = "0.00"
        DataGridView1.DataSource = Nothing
        DataGridView1.Refresh()

    End Sub

End Class