Imports System.Net.Mail
Imports System.Globalization
Imports System.Globalization.CultureInfo
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports UtilityClassLibrary
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmTest
    Public dataTableExcelFile As DataTable = Nothing
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim clsTb As New WaterMarkTextBox
    Public retBank As String
    Dim space As Integer = 0
    Dim lineno As Integer = 0
    Dim x As Integer = 5
    Dim y As Integer = 30
    Private Sub TabStyle()

        TabControl1.ImageList = ImageList1

        TabPage1.ImageIndex = 12
        TabControl1.ItemSize = New Size(90, 30)


        TabControl1.DrawMode = TabDrawMode.OwnerDrawFixed
        'TabControl1.ForeColor = Color.LightGray 'Color.Blue

        For Each tp As TabPage In Me.TabControl1.TabPages
            tp.BackColor = Color.FromArgb(255, 240, 235)   'Color.LightSteelBlue 'LightBlue
        Next

        Panel1.BackColor = Color.FromArgb(255, 240, 235)
        Panel2.BackColor = Color.FromArgb(255, 240, 235)


    End Sub
    Private Function CheckFormatExcelGL(ByVal txtExcelURL As String) As Boolean
        Dim ret As Boolean = True
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            If myvalues(1, 1).ToString.Trim.ToUpper <> "Transaction Ref.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 1) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 2).ToString.Trim.ToUpper <> "Line No.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 2) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 3).ToString.Trim.ToUpper <> "Transaction Date".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 3) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 4).ToString.Trim.ToUpper <> "Due Date".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 4) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 5).ToString.Trim.ToUpper <> "Description".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 5) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 6).ToString.Trim.ToUpper <> "Account Code".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 6) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 7).ToString.Trim.ToUpper <> "Account Name".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 7) & " is not valid"
                Exit Function
            End If
            'If myvalues(1, 8).ToString.Trim.ToUpper <> "Amount".ToUpper Then
            '    ret = False
            '    clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 8) & " is not valid"
            '    Exit Function
            'End If
            If myvalues(1, 9).ToString.Trim.ToUpper <> "Dr / Cr".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 9) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 10).ToString.Trim.ToUpper <> "Transaction Analysis Code (T Code)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 10) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 17).ToString.Trim.ToUpper <> "Accounting Flexfield (Oracle)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 17) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 3).ToString.Trim.ToUpper <> "(DD/MM/YYYY)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 3) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 4).ToString.Trim.ToUpper <> "(DD/MM/YYYY)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 4) & " is not valid"
                Exit Function
            End If



            If myvalues(2, 9).ToString.Trim.ToUpper <> "(D / C)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 9) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 10).ToString.Trim.ToUpper <> "Dept. + Branch".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 10) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 11).ToString.Trim.ToUpper <> "PL+PT".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 11) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 12).ToString.Trim.ToUpper <> "MKT+EMP ID.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 12) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 13).ToString.Trim.ToUpper <> "Project".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 13) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 14).ToString.Trim.ToUpper <> "Tax Type+Tax Rate".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 14) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 15).ToString.Trim.ToUpper <> "Payment Type".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 15) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 16).ToString.Trim.ToUpper <> "Payment To".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 16) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 17).ToString.Trim.ToUpper <> "Account Code".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 17) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 18).ToString.Trim.ToUpper <> "Dept. + Branch".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 18) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 19).ToString.Trim.ToUpper <> "PL+PT".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 19) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 20).ToString.Trim.ToUpper <> "MKT+EMP ID.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 20) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 21).ToString.Trim.ToUpper <> "Project".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 21) & " is not valid"
                Exit Function
            End If
        Catch ex As Exception
            MsgBox("file format is not valid")
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    Private Sub TabControl1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles TabControl1.DrawItem
        Dim g As Graphics = e.Graphics
        Dim tp As TabPage = TabControl1.TabPages(e.Index)
        Dim br As Brush
        Dim sf As New StringFormat

        Dim r As New RectangleF(e.Bounds.X, e.Bounds.Y + 2, e.Bounds.Width, e.Bounds.Height - 2)

        sf.Alignment = StringAlignment.Center

        Dim strTitle As String = tp.Text

        'If the current index is the Selected Index, change the color 
        If TabControl1.SelectedIndex = e.Index Then

            'this is the background color of the tabpage header
            br = New SolidBrush(Color.FromArgb(232, 119, 34)) ' chnge to your choice

            g.FillRectangle(br, e.Bounds)

            'this is the foreground color of the text in the tab header
            br = New SolidBrush(Color.White) ' change to your choice
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        Else

            'these are the colors for the unselected tab pages 
            br = New SolidBrush(Color.FromArgb(255, 235, 220)) ' Change this to your preference
            g.FillRectangle(br, e.Bounds)
            br = New SolidBrush(Color.FromArgb(232, 119, 34))
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TabStyle()

        My.Application.ChangeCulture("en-GB")

        DateTimePicker1.Format = DateTimePickerFormat.Custom
        Dim format As String() = DateTimePicker1.Value.GetDateTimeFormats(Application.CurrentCulture)
        DateTimePicker1.CustomFormat = format(0)

        'If clsUtility.gConnGP.State <> ConnectionState.Open Then
        '    If clsUtility.OpenConnGP() = False Then
        '        Cursor = Cursors.Default
        '        MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
        '        Exit Sub
        '    End If
        'End If

        'AddTextDescription()
        'AddControl()

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'Dim pw As String
        'Dim objService As New wsClsUtility.clsUtility
        'pw = objService.Decrypt(gPasswordReport, "WhiteKnight").returnValue

    End Sub
    Function SendEmail(ByVal Recipients As List(Of String), _
                         ByVal FromAddress As String, _
                         ByVal Subject As String, _
                         ByVal Body As String, _
                         ByVal UserName As String, _
                         ByVal Password As String, _
                         Optional ByVal Server As String = "smtp.gmail.com", _
                         Optional ByVal Port As Integer = 587, _
                         Optional ByVal Attachments As List(Of String) = Nothing) As String
        Dim Email As New MailMessage()
        Try
            Dim SMTPServer As New SmtpClient
            For Each Attachment As String In Attachments
                Email.Attachments.Add(New Attachment(Attachment))
            Next
            Email.From = New MailAddress(FromAddress)
            For Each Recipient As String In Recipients
                Email.To.Add(Recipient)
            Next
            Email.Subject = Subject
            Email.Body = Body
            SMTPServer.Host = Server
            SMTPServer.Port = Port
            SMTPServer.Credentials = New System.Net.NetworkCredential(UserName, Password)
            SMTPServer.EnableSsl = True
            SMTPServer.Send(Email)
            Email.Dispose()
            Return "Email to " & Recipients(0) & " from " & FromAddress & " was sent."
        Catch ex As SmtpException
            Email.Dispose()
            Return "Sending Email Failed. Smtp Error."
        Catch ex As ArgumentOutOfRangeException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        Catch Ex As InvalidOperationException
            Email.Dispose()
            Return "Sending Email Failed. Check Port Number."
        End Try
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim Recipients As New List(Of String)
        Recipients.Add("pattamalin@hotmail.com")
        Dim FromEmailAddress As String = Recipients(0)
        Dim Subject As String = "Test From VB."
        Dim Body As String = "email body text, if you are reading this from your gmail account, the program worked."
        Dim UserName As String = "scnyl.local\pattamalin"
        Dim Password As String = ""
        Dim Port As Integer = 587
        Dim Server As String = "smtp.gmail.com"
        Dim Attachments As New List(Of String)
        MsgBox(SendEmail(Recipients, FromEmailAddress, Subject, Body, UserName, Password, Server, Port, Attachments))


        'Dim ESen As New Net.Mail.MailAddress("pattamalin@gmail.com", "rnd") 'Sender
        'Dim ERec As New Net.Mail.MailAddress("pattamalin@hotmail.com") 'Recipient

        'Dim stream As New Net.Mail.SmtpClient("smtp.gmail.com", 587) 'Host, port
        'Dim Credentials As New System.Net.NetworkCredential("scnyl.local\pattamalin", "p@ssw0rd") 'Username, Password

        'stream.Credentials = Credentials

        'Try

        '    Dim message As New Net.Mail.MailMessage(ESen, ERec) 'Email message
        '    message.Subject = "txtSubject.Text"
        '    message.Body = "txtMessages.Text"

        '    stream.Send(message)
        '    message.Dispose()

        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'Finally

        '    stream = Nothing
        '    Credentials = Nothing
        '    ESen = Nothing
        '    ERec = Nothing

        'End Try

    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Dim pattern As String
        'pattern = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        'If Regex.IsMatch(TextBox1.Text, pattern) Then
        '    MsgBox("Valid Email address ")
        'Else
        '    MsgBox("Not a valid Email address ")
        'End If
        'If Not Regex.Match(TextBox1.Text, "^[a-z]*$", RegexOptions.IgnoreCase).Success Then
        '    MsgBox("Please enter alpha text only.")
        '    TextBox1.Focus()
        'End If

        If CheckInStr(TextBox1.Text, New String() {"#", "@", "&"}) Then
            MsgBox("Please enter alpha text only.")
        End If
    End Sub
    Public Function CheckInStr(ByVal myString As String, ByVal array() As String) As Boolean
        For Each elem As String In array
            If myString.Contains(elem) Then Return True
        Next

        Return False
    End Function
    Private Sub AddTextDescription()
        Dim label1 As New Label
        label1.Name = "lblNo"
        label1.Text = "No."
        label1.Location = New Point(0, 0)
        Panel1.Controls.Add(label1)

        Dim label2 As New Label
        label2.Name = "lblID"
        label2.Text = "Id."
        label2.Location = New Point(105, 0)
        Panel1.Controls.Add(label2)

        Dim label3 As New Label
        label3.Name = "lblType"
        label3.Text = "Type"
        label3.Location = New Point(210, 0)
        Panel1.Controls.Add(label3)

        Dim label4 As New Label
        label4.Name = "lblBank"
        label4.Text = "Bank"
        label4.Location = New Point(315, 0)
        Panel1.Controls.Add(label4)
    End Sub
    Private Sub AddControl(ByVal param As String())
        Dim strData() As String
        Dim default_value As String = "CR|DR"
        Dim textbox1 As New WaterMarkTextBox ' TextBox
        Dim textbox2 As New TextBox
        Dim textbox3 As New TextBox
        Dim textbox4 As New TextBox
        Dim combobox1 As New ComboBox
        Dim button1 As New Button
        Dim btnDel As New Button

        btnDel.Name = "btnDel" & lineno
        btnDel.BackColor = Color.WhiteSmoke
        btnDel.Size = New Size(24, 20)
        btnDel.Location = New Point(x, y)
        btnDel.Image = My.Resources.delete
        btnDel.Tag = lineno
        AddHandler btnDel.Click, AddressOf Me.btnDel_Click
        Panel1.Controls.Add(btnDel)

        space = 25
        textbox1.Name = "txtNo" & lineno
        textbox1.WaterMarkText = "Enter No."
        textbox1.Text = param(0)
        textbox1.Size = New Size(100, 20)
        textbox1.Location = New Point(x + space, y)
        Panel1.Controls.Add(textbox1)

        space += 105
        textbox2.Name = "txtID" & lineno
        textbox2.Text = param(1)
        textbox2.Size = New Size(100, 20)
        textbox2.Location = New Point(x + space, y)
        Panel1.Controls.Add(textbox2)

        space += 105
        combobox1.Name = "cboType" & lineno
        combobox1.Size = New Size(100, 20)
        combobox1.Location = New Point(x + space, y)
        strData = default_value.Split("|")
        For i As Integer = 0 To UBound(strData)
            combobox1.Items.Add(strData(i))
        Next i
        combobox1.SelectedIndex = 0
        Panel1.Controls.Add(combobox1)

        space += 105
        textbox3.Name = "txtCompany" & lineno
        textbox3.Size = New Size(100, 20)
        textbox3.Location = New Point(x + space, y)
        Panel1.Controls.Add(textbox3)

        space += 105
        button1.Name = "btnCompany" & lineno
        button1.BackColor = Color.WhiteSmoke
        button1.Size = New Size(24, 24)
        button1.Location = New Point(x + space, y)
        button1.Image = My.Resources.search_icon
        button1.Tag = lineno
        AddHandler button1.Click, AddressOf Me.btnCompany_Click
        Panel1.Controls.Add(button1)

        space += 35
        textbox4.Name = "txtName" & lineno
        textbox4.Size = New Size(100, 20)
        textbox4.Location = New Point(x + space, y)
        Panel1.Controls.Add(textbox4)

        lineno += 1
        y += 30

    End Sub
    Private Sub GenDataTable()
        'If dataTableExcelFile Is Nothing Then
        dataTableExcelFile = New DataTable

        dataTableExcelFile.Columns.Add("c1")
        dataTableExcelFile.Columns.Add("c2")
        dataTableExcelFile.Columns.Add("c3")
        'End If

    End Sub
    Private Sub btnDel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim index As String = CType(sender, System.Windows.Forms.Button).Tag

        If dataTableExcelFile Is Nothing Then
            Exit Sub
        End If

        dataTableExcelFile.Rows(Convert.ToInt16(index)).Delete()
        dataTableExcelFile.AcceptChanges()


        If dataTableExcelFile.Rows.Count > 1 Then

            RemoveAllTextbox()
            AddTextDescription()

            Dim i As Integer
            For i = 0 To dataTableExcelFile.Rows.Count - 1
                Dim param(1) As String
                param(0) = dataTableExcelFile.Rows(i)("c1")
                param(1) = dataTableExcelFile.Rows(i)("c2")

                AddControl(param)

            Next i

        End If

    End Sub
    Private Sub btnCompany_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim f As New frmTestChild
        f.Owner = Me
        f.ShowDialog()

        Dim ObjNo As TextBox = Panel1.Controls.Item("txtCompany" & CType(sender, System.Windows.Forms.Button).Tag)
        ObjNo.Text = retBank

    End Sub
    Private Sub SaveData()
        Dim i As Integer
        Dim param(1) As String
        Dim sb As New StringBuilder()
        'Dim str As String

        For i = 0 To lineno - 1

            Dim ObjID As TextBox = Panel1.Controls.Item("txtID" & i)
            Dim ObjNo As TextBox = Panel1.Controls.Item("txtNo" & i)

            param(0) = ObjNo.Text
            param(1) = ObjID.Text

            sb.Append("insert into aa values (")
            sb.Append("'{0}','{1}')")

            Dim a As String
            a = String.Format(sb.ToString, param)

        Next i

    End Sub
    Function SetParam() As String()
        Dim param(1) As String
        param(0) = ""
        param(1) = ""

        Return param
    End Function
    Private Function readExcelFile(ByVal txtExcelURL As String) As DataTable
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            RemoveAllTextbox()
            GenDataTable()

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
                rowNew = dataTableExcelFile.NewRow
                firstColumnIsNothing = False
                For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
                    If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                        firstColumnIsNothing = True
                        Exit For
                    ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                        rowNew.Item(columnIndex - 1) = ""
                    Else
                        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                    End If
                Next
                If firstColumnIsNothing = False Then
                    dataTableExcelFile.Rows.Add(rowNew)
                End If
            Next
            dataTableExcelFile.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableExcelFile
    End Function
    Private Sub ClearTextbox()
        Dim X As Control
        For Each X In Panel1.Controls
            If TypeOf X Is TextBox Then
                X.Text = ""
                X.Enabled = True
            End If
        Next X
    End Sub
    Private Sub RemoveAllTextbox()

        lineno = 0
        x = 0
        y = 30

        For i As Integer = Panel1.Controls.Count - 1 To 0 Step -1
            Panel1.Controls.Remove(Panel1.Controls(i))
        Next i
    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        Dim format As String() = DateTimePicker1.Value.GetDateTimeFormats(Application.CurrentCulture)
        DateTimePicker1.CustomFormat = format(0)
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        Dim g As Graphics = e.Graphics
        Dim pen As New Pen(Color.Gray, 2)

        Dim txtBox As Control
        For Each txtBox In Me.Controls
            If TypeOf (txtBox) Is TextBox Then
                g.DrawRectangle(pen, New Rectangle(txtBox.Location, txtBox.Size))
            End If
        Next
        pen.Dispose()
    End Sub
    'Private Sub Panel1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles Panel1.Paint

    '    Dim g As Graphics = e.Graphics
    '    Dim pen As New Pen(Color.Gray, 2.0)

    '    Try
    '        For Each ctr As Control In Panel1.Controls
    '            'If ctr.Name = ControlsName Then
    '            g.DrawRectangle(pen, New Rectangle(ctr.Location, ctr.Size))
    '            'End If
    '        Next
    '    Catch ex As Exception
    '    End Try

    '    pen.Dispose()

    'End Sub
    Private Sub RipsWareImageButtonBase1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RipsWareImageButtonBase1.Click
        FrmDurationReport.Show()
    End Sub
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If txtTextURL.Text = "" Then
            MsgBox("��س��к� File ����ͧ������", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim dt As New DataTable
        dt = readExcelFile(txtTextURL.Text)
        If dt.Rows.Count > 1 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                Dim param(1) As String
                param(0) = dt.Rows(i)("c1")
                param(1) = dt.Rows(i)("c2")
                AddControl(param)
            Next i
        End If
    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            .Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.xls;*.xlsx)|*.xls;*.xlsx"
            .FilterIndex = 0
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURL.Text = OpenFileDialog1.FileName

                Dim dt As New DataTable
                If CheckFormatExcelGL(txtTextURL.Text) = False Then
                    MsgBox("file format is not valid")
                    dt = Nothing

                    Exit Sub
                End If

            End If
        End If
    End Sub
    Private Sub btnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNew.Click

        If lineno = 0 Then 'For First row
            AddTextDescription()
            Dim param(1) As String
            AddControl(param)
        Else

            If dataTableExcelFile Is Nothing Then
                GenDataTable()
            End If

            Dim ObjNo As TextBox = Panel1.Controls.Item("txtNo" & lineno - 1)
            Dim ObjID As TextBox = Panel1.Controls.Item("txtID" & lineno - 1)

            Dim rowNew As DataRow
            rowNew = dataTableExcelFile.NewRow

            rowNew.Item(0) = ObjNo.Text
            rowNew.Item(1) = ObjID.Text

            dataTableExcelFile.Rows.Add(rowNew)
            dataTableExcelFile.AcceptChanges()

            AddTextDescription()
            Dim param(1) As String
            AddControl(param)
        End If
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SaveData()
    End Sub
    Private Sub txtTextURL_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTextURL.TextChanged

    End Sub
End Class
