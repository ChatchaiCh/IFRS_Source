<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmConfirmBatchProcess
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboBatchNo = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PanelH3 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PanelH2 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PanelD3 = New System.Windows.Forms.Panel()
        Me.txtOverSea = New System.Windows.Forms.TextBox()
        Me.txtATS = New System.Windows.Forms.TextBox()
        Me.txtCreditCard = New System.Windows.Forms.TextBox()
        Me.txtBankDraft = New System.Windows.Forms.TextBox()
        Me.txtMoneyOrder = New System.Windows.Forms.TextBox()
        Me.txtGiftCheque = New System.Windows.Forms.TextBox()
        Me.txtCashierCheque = New System.Windows.Forms.TextBox()
        Me.txtCompanyCheque = New System.Windows.Forms.TextBox()
        Me.txtM_Cheque = New System.Windows.Forms.TextBox()
        Me.txtM_Draft = New System.Windows.Forms.TextBox()
        Me.txtMedia = New System.Windows.Forms.TextBox()
        Me.PanelD2 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PanelD1 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PanelH1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtNonPay = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.cboPayType = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.lblprogress = New System.Windows.Forms.Label()
        Me.btnConfirm = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.btnExit = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.ProgressBar1 = New GP_StandAlone_App.SmoothProgressBar()
        Me.btnLoad = New GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase()
        Me.chkNonPay = New System.Windows.Forms.CheckBox()
        Me.txtBatchNo = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.PanelH3.SuspendLayout()
        Me.PanelH2.SuspendLayout()
        Me.PanelD3.SuspendLayout()
        Me.PanelD2.SuspendLayout()
        Me.PanelD1.SuspendLayout()
        Me.PanelH1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(23, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "�Ţ��� Batch :"
        '
        'cboBatchNo
        '
        Me.cboBatchNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBatchNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboBatchNo.FormattingEnabled = True
        Me.cboBatchNo.Location = New System.Drawing.Point(108, 85)
        Me.cboBatchNo.Name = "cboBatchNo"
        Me.cboBatchNo.Size = New System.Drawing.Size(312, 21)
        Me.cboBatchNo.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.PanelH3)
        Me.GroupBox1.Controls.Add(Me.PanelH2)
        Me.GroupBox1.Controls.Add(Me.PanelD3)
        Me.GroupBox1.Controls.Add(Me.PanelD2)
        Me.GroupBox1.Controls.Add(Me.PanelD1)
        Me.GroupBox1.Controls.Add(Me.PanelH1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 135)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(561, 375)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "��������´������ GP"
        '
        'PanelH3
        '
        Me.PanelH3.Controls.Add(Me.Label5)
        Me.PanelH3.Location = New System.Drawing.Point(427, 20)
        Me.PanelH3.Name = "PanelH3"
        Me.PanelH3.Size = New System.Drawing.Size(127, 38)
        Me.PanelH3.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(12, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 17)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "�ӹǹ�Թ�ط��"
        '
        'PanelH2
        '
        Me.PanelH2.Controls.Add(Me.Label4)
        Me.PanelH2.Location = New System.Drawing.Point(140, 20)
        Me.PanelH2.Name = "PanelH2"
        Me.PanelH2.Size = New System.Drawing.Size(280, 38)
        Me.PanelH2.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(79, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 17)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Payment Type"
        '
        'PanelD3
        '
        Me.PanelD3.Controls.Add(Me.txtOverSea)
        Me.PanelD3.Controls.Add(Me.txtATS)
        Me.PanelD3.Controls.Add(Me.txtCreditCard)
        Me.PanelD3.Controls.Add(Me.txtBankDraft)
        Me.PanelD3.Controls.Add(Me.txtMoneyOrder)
        Me.PanelD3.Controls.Add(Me.txtGiftCheque)
        Me.PanelD3.Controls.Add(Me.txtCashierCheque)
        Me.PanelD3.Controls.Add(Me.txtCompanyCheque)
        Me.PanelD3.Controls.Add(Me.txtM_Cheque)
        Me.PanelD3.Controls.Add(Me.txtM_Draft)
        Me.PanelD3.Controls.Add(Me.txtMedia)
        Me.PanelD3.Location = New System.Drawing.Point(427, 64)
        Me.PanelD3.Name = "PanelD3"
        Me.PanelD3.Size = New System.Drawing.Size(128, 301)
        Me.PanelD3.TabIndex = 10
        '
        'txtOverSea
        '
        Me.txtOverSea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtOverSea.Location = New System.Drawing.Point(3, 60)
        Me.txtOverSea.Name = "txtOverSea"
        Me.txtOverSea.Size = New System.Drawing.Size(122, 20)
        Me.txtOverSea.TabIndex = 10
        Me.txtOverSea.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtATS
        '
        Me.txtATS.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtATS.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtATS.Location = New System.Drawing.Point(3, 11)
        Me.txtATS.Name = "txtATS"
        Me.txtATS.Size = New System.Drawing.Size(122, 20)
        Me.txtATS.TabIndex = 9
        Me.txtATS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtCreditCard
        '
        Me.txtCreditCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCreditCard.Location = New System.Drawing.Point(3, 37)
        Me.txtCreditCard.Name = "txtCreditCard"
        Me.txtCreditCard.Size = New System.Drawing.Size(122, 20)
        Me.txtCreditCard.TabIndex = 8
        Me.txtCreditCard.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBankDraft
        '
        Me.txtBankDraft.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtBankDraft.Location = New System.Drawing.Point(3, 164)
        Me.txtBankDraft.Name = "txtBankDraft"
        Me.txtBankDraft.Size = New System.Drawing.Size(122, 20)
        Me.txtBankDraft.TabIndex = 7
        Me.txtBankDraft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMoneyOrder
        '
        Me.txtMoneyOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtMoneyOrder.Location = New System.Drawing.Point(3, 268)
        Me.txtMoneyOrder.Name = "txtMoneyOrder"
        Me.txtMoneyOrder.Size = New System.Drawing.Size(122, 20)
        Me.txtMoneyOrder.TabIndex = 6
        Me.txtMoneyOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtGiftCheque
        '
        Me.txtGiftCheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtGiftCheque.Location = New System.Drawing.Point(3, 190)
        Me.txtGiftCheque.Name = "txtGiftCheque"
        Me.txtGiftCheque.Size = New System.Drawing.Size(122, 20)
        Me.txtGiftCheque.TabIndex = 5
        Me.txtGiftCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtCashierCheque
        '
        Me.txtCashierCheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCashierCheque.Location = New System.Drawing.Point(3, 216)
        Me.txtCashierCheque.Name = "txtCashierCheque"
        Me.txtCashierCheque.Size = New System.Drawing.Size(122, 20)
        Me.txtCashierCheque.TabIndex = 4
        Me.txtCashierCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtCompanyCheque
        '
        Me.txtCompanyCheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtCompanyCheque.Location = New System.Drawing.Point(3, 242)
        Me.txtCompanyCheque.Name = "txtCompanyCheque"
        Me.txtCompanyCheque.Size = New System.Drawing.Size(122, 20)
        Me.txtCompanyCheque.TabIndex = 3
        Me.txtCompanyCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtM_Cheque
        '
        Me.txtM_Cheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtM_Cheque.Location = New System.Drawing.Point(3, 86)
        Me.txtM_Cheque.Name = "txtM_Cheque"
        Me.txtM_Cheque.Size = New System.Drawing.Size(122, 20)
        Me.txtM_Cheque.TabIndex = 0
        Me.txtM_Cheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtM_Draft
        '
        Me.txtM_Draft.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtM_Draft.Location = New System.Drawing.Point(3, 112)
        Me.txtM_Draft.Name = "txtM_Draft"
        Me.txtM_Draft.Size = New System.Drawing.Size(122, 20)
        Me.txtM_Draft.TabIndex = 1
        Me.txtM_Draft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMedia
        '
        Me.txtMedia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtMedia.Location = New System.Drawing.Point(3, 138)
        Me.txtMedia.Name = "txtMedia"
        Me.txtMedia.Size = New System.Drawing.Size(122, 20)
        Me.txtMedia.TabIndex = 2
        Me.txtMedia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PanelD2
        '
        Me.PanelD2.Controls.Add(Me.Label26)
        Me.PanelD2.Controls.Add(Me.Label25)
        Me.PanelD2.Controls.Add(Me.Label24)
        Me.PanelD2.Controls.Add(Me.Label19)
        Me.PanelD2.Controls.Add(Me.Label20)
        Me.PanelD2.Controls.Add(Me.Label10)
        Me.PanelD2.Controls.Add(Me.Label3)
        Me.PanelD2.Controls.Add(Me.Label18)
        Me.PanelD2.Controls.Add(Me.Label17)
        Me.PanelD2.Controls.Add(Me.Label9)
        Me.PanelD2.Controls.Add(Me.Label16)
        Me.PanelD2.Location = New System.Drawing.Point(140, 64)
        Me.PanelD2.Name = "PanelD2"
        Me.PanelD2.Size = New System.Drawing.Size(280, 301)
        Me.PanelD2.TabIndex = 10
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(9, 63)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(99, 13)
        Me.Label26.TabIndex = 15
        Me.Label26.Text = "�͹�Թ��ҧ�����"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(9, 18)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(72, 13)
        Me.Label25.TabIndex = 14
        Me.Label25.Text = "ATS �ͧ SCB"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(9, 40)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(117, 13)
        Me.Label24.TabIndex = 13
        Me.Label24.Text = "Credit Card(�ѵ��ôԵ)"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(9, 271)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(107, 13)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "Money order(��ҳѵ�)"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(9, 167)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(58, 13)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "Bank Draft"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(9, 138)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 13)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "SCB Media Clearing"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(9, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "SCB Corporate Cheque"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(9, 193)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(150, 13)
        Me.Label18.TabIndex = 10
        Me.Label18.Text = "SCB Gift Cheque(�礢ͧ��ѭ)"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(9, 219)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(106, 13)
        Me.Label17.TabIndex = 9
        Me.Label17.Text = "SCB Cashier Cheque"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(9, 112)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(66, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "SCB M Draft"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(9, 245)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(91, 13)
        Me.Label16.TabIndex = 8
        Me.Label16.Text = "Company Cheque"
        '
        'PanelD1
        '
        Me.PanelD1.Controls.Add(Me.Label23)
        Me.PanelD1.Controls.Add(Me.Label22)
        Me.PanelD1.Controls.Add(Me.Label21)
        Me.PanelD1.Controls.Add(Me.Label15)
        Me.PanelD1.Controls.Add(Me.Label14)
        Me.PanelD1.Controls.Add(Me.Label13)
        Me.PanelD1.Controls.Add(Me.Label12)
        Me.PanelD1.Controls.Add(Me.Label11)
        Me.PanelD1.Controls.Add(Me.Label7)
        Me.PanelD1.Controls.Add(Me.Label6)
        Me.PanelD1.Controls.Add(Me.Label8)
        Me.PanelD1.Location = New System.Drawing.Point(6, 64)
        Me.PanelD1.Name = "PanelD1"
        Me.PanelD1.Size = New System.Drawing.Size(128, 301)
        Me.PanelD1.TabIndex = 9
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(6, 63)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(91, 13)
        Me.Label23.TabIndex = 15
        Me.Label23.Text = "Oversea Payment"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(6, 18)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(28, 13)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "ATS"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(6, 41)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(59, 13)
        Me.Label21.TabIndex = 13
        Me.Label21.Text = "Credit Card"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(6, 271)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(88, 13)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "SCB Life Cheque"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(6, 245)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(88, 13)
        Me.Label14.TabIndex = 11
        Me.Label14.Text = "SCB Life Cheque"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(6, 219)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(88, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "SCB Life Cheque"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(6, 193)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "SCB Life Cheque"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(6, 167)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "SCB Life Cheque"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(6, 86)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "SCB Business Net"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(6, 112)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "SCB Business Net"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(6, 138)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "SCB Business Net"
        '
        'PanelH1
        '
        Me.PanelH1.Controls.Add(Me.Label2)
        Me.PanelH1.Location = New System.Drawing.Point(7, 20)
        Me.PanelH1.Name = "PanelH1"
        Me.PanelH1.Size = New System.Drawing.Size(127, 38)
        Me.PanelH1.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(14, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "�������è���"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtNonPay)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 513)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(561, 77)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "��������´������"
        '
        'txtNonPay
        '
        Me.txtNonPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txtNonPay.Location = New System.Drawing.Point(430, 40)
        Me.txtNonPay.Name = "txtNonPay"
        Me.txtNonPay.Size = New System.Drawing.Size(122, 20)
        Me.txtNonPay.TabIndex = 11
        Me.txtNonPay.Text = "0.00"
        Me.txtNonPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(18, 41)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(85, 13)
        Me.Label28.TabIndex = 7
        Me.Label28.Text = "WHT non pay"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(456, 16)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(66, 13)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "�ӹǹ�Թ"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(20, 596)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(23, 13)
        Me.Label29.TabIndex = 12
        Me.Label29.Text = "0%"
        Me.Label29.Visible = False
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(331, 596)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(37, 13)
        Me.Label30.TabIndex = 18
        Me.Label30.Text = "100%"
        Me.Label30.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(458, 53)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(42, 13)
        Me.Label31.TabIndex = 20
        Me.Label31.Text = "Date :"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(564, 30)
        Me.Panel1.TabIndex = 35
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(177, 3)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(179, 24)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "CONFIRM BATCH"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cboPayType
        '
        Me.cboPayType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPayType.Enabled = False
        Me.cboPayType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.cboPayType.FormattingEnabled = True
        Me.cboPayType.Location = New System.Drawing.Point(108, 112)
        Me.cboPayType.Name = "cboPayType"
        Me.cboPayType.Size = New System.Drawing.Size(312, 21)
        Me.cboPayType.TabIndex = 37
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(24, 115)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(80, 13)
        Me.Label34.TabIndex = 38
        Me.Label34.Text = "�������è��� :"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.Black
        Me.lblDate.Location = New System.Drawing.Point(506, 53)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(47, 13)
        Me.lblDate.TabIndex = 39
        Me.lblDate.Text = "lblDate"
        '
        'BackgroundWorker1
        '
        Me.BackgroundWorker1.WorkerReportsProgress = True
        Me.BackgroundWorker1.WorkerSupportsCancellation = True
        '
        'lblprogress
        '
        Me.lblprogress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblprogress.ForeColor = System.Drawing.Color.Black
        Me.lblprogress.Location = New System.Drawing.Point(45, 619)
        Me.lblprogress.Name = "lblprogress"
        Me.lblprogress.Size = New System.Drawing.Size(284, 13)
        Me.lblprogress.TabIndex = 41
        Me.lblprogress.Text = "0%"
        Me.lblprogress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblprogress.Visible = False
        '
        'btnConfirm
        '
        Me.btnConfirm.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnConfirm.BackColor = System.Drawing.SystemColors.Control
        Me.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConfirm.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnConfirm.ForeColor = System.Drawing.Color.White
        Me.btnConfirm.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnConfirm.Image = Nothing
        Me.btnConfirm.ImageKey = ""
        Me.btnConfirm.ImageList = Nothing
        Me.btnConfirm.Location = New System.Drawing.Point(383, 600)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnConfirm.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnConfirm.Size = New System.Drawing.Size(92, 28)
        Me.btnConfirm.TabIndex = 66
        Me.btnConfirm.Text = "Confirm"
        Me.btnConfirm.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnConfirm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'btnExit
        '
        Me.btnExit.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.BackColor = System.Drawing.SystemColors.Control
        Me.btnExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Image = Nothing
        Me.btnExit.ImageKey = ""
        Me.btnExit.ImageList = Nothing
        Me.btnExit.Location = New System.Drawing.Point(481, 600)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnExit.Size = New System.Drawing.Size(92, 28)
        Me.btnExit.TabIndex = 67
        Me.btnExit.Text = "Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BarColor1 = System.Drawing.Color.DarkMagenta
        Me.ProgressBar1.BarSigmaFocus = 1
        Me.ProgressBar1.Location = New System.Drawing.Point(45, 596)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(284, 20)
        Me.ProgressBar1.TabIndex = 42
        Me.ProgressBar1.Visible = False
        '
        'btnLoad
        '
        Me.btnLoad.ActiveImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.BackColor = System.Drawing.Color.Transparent
        Me.btnLoad.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLoad.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLoad.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.btnLoad.ForeColor = System.Drawing.Color.White
        Me.btnLoad.HoverImage = Global.GP_StandAlone_App.My.Resources.Resources.scb11
        Me.btnLoad.Image = Nothing
        Me.btnLoad.ImageKey = ""
        Me.btnLoad.ImageList = Nothing
        Me.btnLoad.Location = New System.Drawing.Point(424, 85)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.NormalImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.PressedImage = Global.GP_StandAlone_App.My.Resources.Resources.scb3
        Me.btnLoad.Size = New System.Drawing.Size(72, 23)
        Me.btnLoad.TabIndex = 19
        Me.btnLoad.Text = "Load"
        Me.btnLoad.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'chkNonPay
        '
        Me.chkNonPay.AutoSize = True
        Me.chkNonPay.Location = New System.Drawing.Point(427, 115)
        Me.chkNonPay.Name = "chkNonPay"
        Me.chkNonPay.Size = New System.Drawing.Size(91, 17)
        Me.chkNonPay.TabIndex = 68
        Me.chkNonPay.Text = "Non Pay Only"
        Me.chkNonPay.UseVisualStyleBackColor = True
        '
        'txtBatchNo
        '
        Me.txtBatchNo.Location = New System.Drawing.Point(524, 113)
        Me.txtBatchNo.Name = "txtBatchNo"
        Me.txtBatchNo.Size = New System.Drawing.Size(100, 20)
        Me.txtBatchNo.TabIndex = 69
        Me.txtBatchNo.Text = "GP2021030101"
        '
        'FrmConfirmBatchProcess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(593, 640)
        Me.Controls.Add(Me.txtBatchNo)
        Me.Controls.Add(Me.chkNonPay)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.lblprogress)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.cboPayType)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.btnLoad)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.cboBatchNo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FrmConfirmBatchProcess"
        Me.Text = "Confirm Batch"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.PanelH3.ResumeLayout(False)
        Me.PanelH3.PerformLayout()
        Me.PanelH2.ResumeLayout(False)
        Me.PanelH2.PerformLayout()
        Me.PanelD3.ResumeLayout(False)
        Me.PanelD3.PerformLayout()
        Me.PanelD2.ResumeLayout(False)
        Me.PanelD2.PerformLayout()
        Me.PanelD1.ResumeLayout(False)
        Me.PanelD1.PerformLayout()
        Me.PanelH1.ResumeLayout(False)
        Me.PanelH1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboBatchNo As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PanelH1 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PanelD1 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PanelD3 As System.Windows.Forms.Panel
    Friend WithEvents PanelD2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtM_Draft As System.Windows.Forms.TextBox
    Friend WithEvents txtM_Cheque As System.Windows.Forms.TextBox
    Friend WithEvents PanelH3 As System.Windows.Forms.Panel
    Friend WithEvents PanelH2 As System.Windows.Forms.Panel
    Friend WithEvents txtMedia As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtBankDraft As System.Windows.Forms.TextBox
    Friend WithEvents txtMoneyOrder As System.Windows.Forms.TextBox
    Friend WithEvents txtGiftCheque As System.Windows.Forms.TextBox
    Friend WithEvents txtCashierCheque As System.Windows.Forms.TextBox
    Friend WithEvents txtCompanyCheque As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtCreditCard As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtOverSea As System.Windows.Forms.TextBox
    Friend WithEvents txtATS As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNonPay As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents btnLoad As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents cboPayType As System.Windows.Forms.ComboBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents lblprogress As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As GP_StandAlone_App.SmoothProgressBar
    Friend WithEvents btnExit As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents btnConfirm As GP_StandAlone_App.RipsWare.Controls.Base.Button.RipsWareImageButtonBase
    Friend WithEvents chkNonPay As System.Windows.Forms.CheckBox
    Friend WithEvents txtBatchNo As System.Windows.Forms.TextBox
End Class
