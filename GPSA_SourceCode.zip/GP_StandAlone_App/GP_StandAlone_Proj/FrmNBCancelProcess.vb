Imports System.Text
Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Globalization
Public Class FrmNBCancelProcess
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim PaymentMethod As String
    Dim SubPaymentMethod As String
    Dim PaidDate As String
    Dim fa_approve As String
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub FrmOperationNBCancelTLM_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()

        DisplayPaymentType()


        'Dim dt As DataTable
        'dt = Nothing
        'GetDataToGrid(dt)


    End Sub
    Private Sub DisplayPaymentType()

        Dim sb As New StringBuilder()
        sb.Append(" SELECT PAYT_PAYMTH, PAYT_SUB_PAYMTH , PAYT_PAYMTH||':'||PAYT_SUB_PAYMTH as PAYMTH_SUB , PAYT_PAYTYPE ")
        sb.Append(" FROM GPS_TL_PAYTYPE ")
        sb.Append(" WHERE PAYT_PAYMTH='M' ")
        sb.Append(" And (PAYT_SUB_PAYMTH='M' Or PAYT_SUB_PAYMTH='C') ")
        sb.Append(" order by PAYT_PAYTYPE ")

        PaymentMethod = ""
        SubPaymentMethod = ""

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count <> 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboPaymentType
                .DataSource = dt
                .DisplayMember = "PAYT_PAYTYPE"
                .ValueMember = "PAYMTH_SUB"
            End With
        End If
        'cboType.SelectedValue = 0
    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .ReadOnly = True
            '.DataPropertyName = "GPCR_CREATEDATE"
            .DataPropertyName = "GPCR_CREATEDATE_SHOW"
            .Name = "CREATEDATE"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .ReadOnly = True
            .DataPropertyName = "GPCR_CORE_SYSTEM"
            .Name = "CORE_SYS"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c2)
        End With
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .ReadOnly = True
            .DataPropertyName = "GPCR_TRANSREF"
            .Name = "TRANSREF"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c3)
        End With
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .ReadOnly = True
            .DataPropertyName = "GPCR_GPTREF_SEQNO"
            .Name = "SEQNO"
            .ReadOnly = True
            .Width = 50
            DataGridView1.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .ReadOnly = True
            '.DataPropertyName = "GPCR_PAIDDATE"
            .DataPropertyName = "GPCR_PAIDDATE_SHOW"
            .Name = "PAIDDATE"
            .ReadOnly = True
            .Width = 80
            DataGridView1.Columns.Add(c5)
        End With
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .ReadOnly = True
            .DataPropertyName = "GPCR_POLNO"
            .Name = "POLNO"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c6)
        End With
        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .ReadOnly = True
            .DataPropertyName = "GPCR_PAYEE_NAME"
            .Name = "PAYEE_NAME"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c7)
        End With
        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .ReadOnly = True
            .DataPropertyName = "GPCR_PAYEE_BNKACCNME"
            .Name = "PAYEE_BNKACCNME"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c8)
        End With
        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .ReadOnly = True
            .DataPropertyName = "GPCR_AMOUNT"
            .Name = "AMOUNT"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c9)
        End With
        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .ReadOnly = True
            .DataPropertyName = "GPCR_DESC"
            .Name = "DESC"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c10)
        End With
        Dim c11 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c11
            .ReadOnly = True
            .DataPropertyName = "GPCR_APPROVEDDATE"
            .Name = "FA APPROVEDATE"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c11)
        End With

        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)
        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(8).DefaultCellStyle.Format = "#,###.00" 'AMOUNT Cheque
        DataGridView1.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight


    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

            txtPayeeName.Text = CType(DataGridView1.Item(7, e.RowIndex).Value, String)
            txtPolNo.Text = CType(DataGridView1.Item(5, e.RowIndex).Value, String)
            txtAmount.Text = Format(CDbl(CType(DataGridView1.Item(8, e.RowIndex).Value, String)), "#,###.00")
            txtDesc.Text = CType(DataGridView1.Item(9, e.RowIndex).Value, String)

            txtCreateDate.Text = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
            txtCoreSystem.Text = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
            txtTransRef.Text = CType(DataGridView1.Item(2, e.RowIndex).Value, String)
            txtGPTREF_SEQNO.Text = CType(DataGridView1.Item(3, e.RowIndex).Value, String)
            fa_approve = CType(DataGridView1.Item(10, e.RowIndex).Value, String)

        End If
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

            txtPayeeName.Text = CType(DataGridView1.Item(7, e.RowIndex).Value, String)
            txtPolNo.Text = CType(DataGridView1.Item(5, e.RowIndex).Value, String)
            txtAmount.Text = Format(CDbl(CType(DataGridView1.Item(8, e.RowIndex).Value, String)), "#,###.00")
            txtDesc.Text = CType(DataGridView1.Item(9, e.RowIndex).Value, String)

            txtCreateDate.Text = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
            txtCoreSystem.Text = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
            txtTransRef.Text = CType(DataGridView1.Item(2, e.RowIndex).Value, String)
            txtGPTREF_SEQNO.Text = CType(DataGridView1.Item(3, e.RowIndex).Value, String)
            fa_approve = CType(DataGridView1.Item(10, e.RowIndex).Value, String)

        End If
    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub ClearTextBox()
        txtPayeeName.Text = ""
        'txtPolNo.Text = ""
        txtAmount.Text = ""
        txtDesc.Text = ""
        txtCreateDate.Text = ""
        txtCoreSystem.Text = ""
        txtTransRef.Text = ""
        txtGPTREF_SEQNO.Text = ""
        txtRemark.Text = ""
        txtPaidDate.Text = ""
        txtPolNo.Text = ""
        fa_approve = ""
    End Sub
    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click

        If (Trim(cboPaymentType.SelectedValue.ToString) <> "") And (Trim(txtPaidDate.Text) <> "") Then

            If txtPaidDate.Text.Trim <> "" Then
                Dim dateString As String = txtPaidDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Piad Date format is not valid")
                    txtPaidDate.Text = ""
                    txtPaidDate.Focus()
                    Exit Sub
                End If
            End If

            PaymentMethod = Trim(cboPaymentType.SelectedValue.ToString.Substring(0, 1))
            SubPaymentMethod = Trim(cboPaymentType.SelectedValue.ToString.Substring(2, 1))
            PaidDate = Trim(txtPaidDate.Text.Substring(6, 4)) + Trim(txtPaidDate.Text.Substring(3, 2)) + Trim(txtPaidDate.Text.Substring(0, 2))
            GetData()
        Else
            MsgBox("�ô��͡������㹪�ͧ Payment Type ��� Piad Date")
            Exit Sub
        End If
    End Sub

    Private Sub GetData()
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.WaitCursor
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        Dim sb As New StringBuilder()

        sb.Append(" SELECT GPCR_CREATEDATE, GPCR_CORE_SYSTEM, GPCR_TRANSREF, GPCR_GPTREF_SEQNO, GPCR_PAIDDATE, GPCR_POLNO, GPCR_PAYEE_NAME, GPCR_PAYEE_BNKACCNME, GPCR_AMOUNT, GPCR_DESC ")
        sb.Append(" , substr(GPCR_CREATEDATE,7,2)||'/'||substr(GPCR_CREATEDATE,5,2)||'/'||substr(GPCR_CREATEDATE,1,4) as GPCR_CREATEDATE_SHOW  ")
        sb.Append(" , substr(GPCR_PAIDDATE,7,2)||'/'||substr(GPCR_PAIDDATE,5,2)||'/'||substr(GPCR_PAIDDATE,1,4) as GPCR_PAIDDATE_SHOW , ")
        sb.Append(" CASE WHEN GPCR_APPROVEDDATE IS NULL THEN ' ' ELSE TO_CHAR(TO_DATE(GPCR_APPROVEDDATE,'YYYYMMDD'),'DD/MM/YYYY') END GPCR_APPROVEDDATE ")
        sb.Append(" FROM GPS_PAYMENT_CREATION ")
        sb.Append(" WHERE GPCR_CORE_SYSTEM='TLM' And GPCR_PAYMTH = '" & Trim(PaymentMethod) & "'  ")
        sb.Append(" And GPCR_SUB_PAYMTH = '" & Trim(SubPaymentMethod) & "' ")
        sb.Append(" And GPCR_PAIDDATE = '" & Trim(PaidDate) & "' ")
        ' - - Add Like Policy 
        If (txtPolNo.Text <> "") Then
            sb.Append(" And GPCR_POLNO like '%" & Trim(txtPolNo.Text) & "%' ")
        End If
        sb.Append(" And (GPCR_FLAG_CC='N' Or GPCR_CC_APPROVEDBY is null) And GPCR_FLAG_BATCH='N'  ")
        sb.Append(" ORDER BY GPCR_CREATEDATE, GPCR_TRANSREF, GPCR_POLNO ")

        Dim dt As DataTable
        'dt.Clear()
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            ClearTextBox()
            GetDataToGrid(dt)

            btnCancel.Enabled = True

        Else
            dt = Nothing
            ClearTextBox()
            GetDataToGrid(dt)
            MsgBox("��辺������ ������͹�")
            btnCancel.Enabled = False
        End If

    End Sub


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        'Dim sb As New StringBuilder()
        Dim oleTrans As OleDbTransaction
        Dim Rec As Integer
        Dim strCreateDate As String



        If txtPayeeName.Text = "" Or txtPolNo.Text = "" Or txtAmount.Text = "" Or txtDesc.Text = "" Then
            MsgBox("�ô��ԡ���͡��������¡�è��·���ͧ���¡��ԡ")
            Exit Sub
        ElseIf txtRemark.Text = "" Then
            MsgBox("�ô��͡������㹪�ͧ Remark ��͹������ Cancel ����")
            Exit Sub
        ElseIf fa_approve.Trim <> "" Then
            MsgBox("��ǹ�ҹ FA Approve ��è������� �������ö�ӡ�� Cancel ������")
            Exit Sub
        Else

            oleTrans = clsUtility.gConnGP.BeginTransaction()

            Dim sb As New StringBuilder()

            strCreateDate = Trim(txtCreateDate.Text.Substring(6, 4)) + Trim(txtCreateDate.Text.Substring(3, 2)) + Trim(txtCreateDate.Text.Substring(0, 2))



            sb.Append(" UPDATE GPS_PAYMENT_CREATION ")
            sb.Append(" SET GPCR_FLAG_CC='Y', GPCR_REMARK='" & Trim(txtRemark.Text) & "' ")
            sb.Append(" , UPDATEDBY = '" & gUserLogin & "' , UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')")
            sb.Append(" WHERE GPCR_PAYMTH = '" & Trim(PaymentMethod) & "' ")
            sb.Append(" AND GPCR_SUB_PAYMTH ='" & Trim(SubPaymentMethod) & "' ")
            sb.Append(" AND GPCR_PAIDDATE ='" & Trim(PaidDate) & "' ")
            sb.Append(" AND GPCR_CREATEDATE ='" & Trim(strCreateDate) & "' ")
            sb.Append(" And GPCR_CORE_SYSTEM='" & Trim(txtCoreSystem.Text) & "' ")
            sb.Append(" AND GPCR_TRANSREF ='" & Trim(txtTransRef.Text) & "' ")
            sb.Append(" AND GPCR_GPTREF_SEQNO ='" & Trim(txtGPTREF_SEQNO.Text) & "' ")

            Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


            If Rec >= 0 Then
                oleTrans.Commit()
                ClearTextBox()
             
                GetDataToGrid(Nothing)
                btnCancel.Enabled = False
                MsgBox(" Update Records successfully")
            Else
                oleTrans.Rollback()
                MsgBox("Cannot insert data : " & vbCrLf & clsUtility.ErrConnectDBMessage)
            End If


        End If



    End Sub


  
End Class