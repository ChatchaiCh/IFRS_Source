Imports GP_StandAlone_App
Imports SCBLife.Network
Imports SCBLife.Security
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Imports System.Net
Imports System.Net.Security
Imports System.Security.Cryptography.X509Certificates

Public Class FrmLogin
    Private Sub FrmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '--PJ0048-- Panel1.BackColor = Color.FromArgb(255, 235, 200)

        Me.Text = "GP Stand Alone " & Application.ProductVersion & " (" & gDSN_GPStandAlone & ")"


    End Sub
    Private Sub CmdOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdOk.Click

        Call FormLoginCmdOk_Click()


        ''If TxtUsername.Text = "" Then
        ''    MessageBox.Show("��س���� User", "Warnning")
        ''    TxtUsername.SelectAll()
        ''    TxtUsername.Focus()
        ''    Exit Sub
        ''End If

        ''Dim objService As New wsClsAuthentication.clsAuthentication

        ' '' Call Web Service
        ''ModDefination.dsUser = objService.Login("GPSA", TxtUsername.Text, TxtPassword.Text, "127.0.0.1")

        ''If IsDBNull(dsUser.Tables("VWUSER").Rows(0)("USERSCODE")) = False Then
        ''    gUserReport = TxtUsername.Text
        ''    gUserLogin = dsUser.Tables("VWUSER").Rows(0)("USERSCODE").ToString
        ''    gUserFullName = dsUser.Tables("VWUSER").Rows(0)("USERSNAME").ToString + " " + dsUser.Tables("VWUSER").Rows(0)("USERSSURNAME").ToString
        ''    gUserGroupCode = dsUser.Tables("VWAUTHORIZATION").Rows(0)("GROUPCODE").ToString
        ''    FrmMainMenu.Show()
        ''    'frmTest.Show()
        ''    Me.Hide()

        ''Else
        ''    MessageBox.Show("�������ö����к��� ��سҵԴ��� Admin" & vbCrLf & "* �к��� Windows User 㹡����ҹ", "��͹")
        ''End If

    End Sub

    Private Function GetTokenCAS() As String

        Dim dataList As New Dictionary(Of String, Object)()
        ' �к� App Name

        '-- Dim appName As String = System.Configuration.ConfigurationManager.AppSettings("AppName").ToString()
        'System.Configuration.ConfigurationManager.AppSettings["AppName"].ToString();
        '-- Dim appTitle As String = System.Configuration.ConfigurationManager.AppSettings("AppTitle").ToString()
        'System.Configuration.ConfigurationManager.AppSettings["AppTitle"].ToString();
        dataList.Add("AppName", CAS_AppName) '-- appName)
        dataList.Add("AppTitle", CAS_AppTitle) '-- appTitle)
        dataList.Add("PostTime", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"))
        Dim sValue As String = JsonConvert.SerializeObject(dataList, Formatting.Indented)
        sValue = Crypto.encryptString(sValue)
        Return sValue

    End Function


    Private Sub FormLoginCmdOk_Click()

        If TxtUsername.Text = "" Then
            MessageBox.Show("��س���� User", "Warnning")
            TxtUsername.SelectAll()
            TxtUsername.Focus()
            Exit Sub
        End If

        ServicePointManager.ServerCertificateValidationCallback = New RemoteCertificateValidationCallback(AddressOf AcceptAllCertifications)

        Dim data As New Dictionary(Of String, Object) '()
        data.Add("MethodName", "Login")
        data.Add("UserName", TxtUsername.Text.Trim)
        data.Add("Password", TxtPassword.Text)
        data.Add("Token", GetTokenCAS())

        Dim newJsonRequest As String = JsonConvert.SerializeObject(data)

        Dim Result As String = ""
        Dim ResultObj As Dictionary(Of String, Object) = Nothing

        Dim ResultDT As DataTable = Nothing
        Dim CASWS As String = CAS_CASWS

        Result = HttpUtil.Post(CASWS, newJsonRequest)

        'Result = HttpUtil.Post(ConfigurationManager.AppSettings("CASWS"), newJsonRequest)

        ' CASWS Dev    = "http://10.38.3.92/MyService/WebApi/CASService.aspx"
        ' CASWS UAT    = "http://casws/WebApi/CASService.aspx"
        ' CASWS PROD   = "http://casws/WebApi/CASService.aspx"

        ResultObj = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(Result)

        '--MsgBox(Result)

        If ResultObj("StatusCode").ToString() = "200" Then
            CAS_objSession = JObject.Parse(ResultObj("UserSession").ToString)
            Dim objParseResult As Object = JObject.Parse(JsonConvert.DeserializeObject(Of List(Of Object))(ResultObj("Result").ToString)(0).ToString)

            If ResultObj("StatusCode").ToString() = "200" Then
                gUserReport = TxtUsername.Text
                gUserLogin = objParseResult("UserName").ToString  '-- dsUser.Tables("VWUSER").Rows(0)("USERSCODE").ToString
                gUserFullName = objParseResult("FirstName").ToString & Space(1) & objParseResult("LastName").ToString '-- dsUser.Tables("VWUSER").Rows(0)("USERSNAME").ToString + " " + dsUser.Tables("VWUSER").Rows(0)("USERSSURNAME").ToString
                gUserGroupCode = "" '-- dsUser.Tables("VWAUTHORIZATION").Rows(0)("GROUPCODE").ToString
                FrmMainMenu.Show()
                Me.Hide()
            Else
                '--MessageBox.Show(ResultObj("Message").ToString())
                MessageBox.Show(ResultObj("StatusCode").ToString & vbCrLf & ResultObj("Message").ToString(), ResultObj("Status").ToString())
            End If
        Else
            If ResultObj.Count = 1 Then
                MessageBox.Show(ResultObj("StatusCode").ToString & vbCrLf & "���ʼ�ҹ���١��ͧ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            ElseIf ResultObj.Count = 3 Then
                MessageBox.Show(ResultObj("StatusCode").ToString & vbCrLf & ResultObj("Message").ToString(), ResultObj("Status").ToString(), MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                MessageBox.Show("�Դ��ͼԴ��Ҵ�����ҧ�к� GP Stand Alone �Ѻ�к� CAS" & vbCrLf & "��سҵԴ��ͼ������к�", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If

    End Sub

    Private Function CAS_GetUserInGroup(GroupCode As String) As DataTable
        Dim AppName As String = System.Configuration.ConfigurationManager.AppSettings("AppName").ToString()
        Dim Result As String = ""
        Dim ResultObj As Dictionary(Of String, Object) = Nothing
        Dim UserName As String = gUserLogin    '"user1@scblife.co.th"
        Dim UserInfo As List(Of Object)

        GroupCode = GroupCode.Replace("( '", "")
        GroupCode = GroupCode.Replace("')", "")
        GroupCode = GroupCode.Replace("','", "|")
        Dim arrGroup As String() = GroupCode.Split("|")


        Dim newJsonRequest As String = String.Empty
        Dim CASWS As String = System.Configuration.ConfigurationManager.AppSettings("CASWS").ToString()
        Dim dt As New DataTable

        dt.Columns.Add("row_num", Type.GetType("System.String"))
        dt.Columns.Add("GROUPCODE", Type.GetType("System.String"))
        dt.Columns.Add("USERSCODE", Type.GetType("System.String"))
        Dim dr As DataRow
        Dim i As Integer = 0
        For Each arr As String In arrGroup
            Dim data As New Dictionary(Of String, Object)()

            data.Add("MethodName", "GetUsersInRole")
            data.Add("ApplicationName", AppName)
            data.Add("RoleName", arr)
            data.Add("Token", GetTokenCAS())

            newJsonRequest = JsonConvert.SerializeObject(data)
            Result = HttpUtil.Post(CASWS, newJsonRequest)
            ResultObj = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(Result)

            If ResultObj("StatusCode").ToString() = "200" Then
                UserInfo = DirectCast(Newtonsoft.Json.JsonConvert.DeserializeObject(ResultObj("Message").ToString(), GetType(List(Of Object))), List(Of Object))

                For Each u As Object In UserInfo
                    i = i + 1
                    dr = dt.NewRow()
                    dr("row_num") = i.ToString("000")
                    dr("GROUPCODE") = arr
                    dr("USERSCODE") = u("UserName").ToString()
                    dt.Rows.Add(dr)
                Next

                UserInfo = Nothing
            End If

            newJsonRequest = String.Empty
            Result = Nothing
            data = Nothing
        Next
        Return dt

    End Function

    Private Function AcceptAllCertifications(sender As Object _
                                             , certification As System.Security.Cryptography.X509Certificates.X509Certificate _
                                             , chain As System.Security.Cryptography.X509Certificates.X509Chain _
                                             , sslPolicyErrors As SslPolicyErrors) As Boolean
        Return True
    End Function

End Class
