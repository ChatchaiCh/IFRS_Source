﻿Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports System.Net.Mail
Imports UtilityClassLibrary

Public Class FrmCancelPayment
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls_cr As New clsCreation
    Dim clsCancelPayment As New clsCancelPayment
    Private _IsSelectAllChecked As Boolean
    Dim timework As Integer = 1
    Dim ret_msg As String
    Dim paytype As String
    Dim countrow As Integer = 0
    Dim second As Integer
    Dim en As New System.Globalization.CultureInfo("en-GB")
    Dim strSQL As String
    Dim strJournalHold As String
    Dim strRemark As String
    Dim systemdate As String = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region

#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region

#Region "BackgroundWorker"


    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs)

        Approve()

        Dim X As Integer
        Dim i As Integer

        For i = 0 To timework Step +1
            'ถ้ามีการสั่ง Cancel ให้หยุดทันที
            If BackgroundWorker1.CancellationPending = True Then
                e.Cancel = True
                Exit For
            Else
                'รายงานว่ามี prgress เพิ่ม 1 progress
                'BackgroundWorker1.ReportProgress(i / countrow)

                X = i / countrow
                BackgroundWorker1.ReportProgress(X)
                System.Threading.Thread.Sleep(countrow)
            End If
        Next

    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs)
        ''เพิ่ม 1 progress      
        'Me.ProgressBar1.Value = e.ProgressPercentage
        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    End Sub
    Private Sub StopWorker()
        If BackgroundWorker1.WorkerSupportsCancellation = True Then
            'สั่งให้ BackgroundWorker หยุดทำงาน
            BackgroundWorker1.CancelAsync()
        End If
    End Sub
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs)
        If ret_msg <> "" Then
            MsgBox(ret_msg, MsgBoxStyle.Critical, "Validate")
        End If


        AutoBindData()
        'MsgBox(ret_msg)

    End Sub
#End Region

    Private Sub Approve()
        '1. check export to bank (export file)
        '2. check confirm batch (generate payment)
        '3. check approved payment
        '   3.1 payment
        '   3.2 non pay
        Dim chk As Integer = 0
        Dim countrow As Integer = 0
        Dim counttrans As Integer = 0
        Dim chk_tref, chk_gl, chk_gp, chk_tax As Boolean
        Dim chk_totemp, chk_complete, chk_rej, chk_aml As Boolean
        Dim blnInsertDataToTemp As Boolean
        Dim complete As Integer = 0
        Dim HJN As Integer = 0
        Dim count As Integer = 0
        Dim jnno As String = ""
        Dim REJECT_TYPE As String = "ACC_CANCEL"
        Dim REJECT_GROUP As String = "ACC_CAN"
        Dim ocallTrans As OleDbTransaction
        Dim jnho, CREATEDATE, CORE_SYSTEM, TRANSREF, confDate, batchNo, batchDate, trefapproveddate, paycretyp As String
        Dim chkGeneratePaymentFile, chkConfirmBatch, chkConfirmBatchNonPay, chkNonPay, chkApprovePayment, chkApproveNonPay As Boolean
        Dim strJournalNoCurrent, strVoucherNoCurrent, strJournalTypeOLD, strJournalTypeReverse As String
        Dim strVoucherNoCurrentJD As String


        For index As Integer = 0 To DataGridView1.RowCount - 1
            HJN = 0
            If DataGridView1.Rows(index).Cells(0).Value = True Then
                chk += 1
                Dim paymth As String
                paymth = DataGridView1.Rows(index).Cells(12).Value.ToString & ":" & DataGridView1.Rows(index).Cells(13).Value.ToString
                jnho = DataGridView1.Rows(index).Cells(1).Value.ToString
                strJournalTypeOLD = DataGridView1.Rows(index).Cells(17).Value.ToString.Substring(0, 2)
                CREATEDATE = DataGridView1.Rows(index).Cells(8).Value.ToString
                CORE_SYSTEM = DataGridView1.Rows(index).Cells(9).Value.ToString
                TRANSREF = DataGridView1.Rows(index).Cells(4).Value.ToString
                confDate = DataGridView1.Rows(index).Cells(15).Value.ToString
                batchNo = DataGridView1.Rows(index).Cells(16).Value.ToString
                batchDate = DataGridView1.Rows(index).Cells(15).Value.ToString
                trefapproveddate = DataGridView1.Rows(index).Cells(18).Value.ToString
                paycretyp = DataGridView1.Rows(index).Cells(11).Value.ToString

                chkGeneratePaymentFile = clsCancelPayment.Check_Export_to_Bank(clsUtility.gConnGP_2, jnho)
                chkConfirmBatch = clsCancelPayment.Check_Confirm_Batch(clsUtility.gConnGP_2, jnho)
                chkConfirmBatchNonPay = clsCancelPayment.Check_Confirm_Batch_NonPay(clsUtility.gConnGP_2, jnho)
                chkNonPay = clsCancelPayment.Check_Non_Pay(clsUtility.gConnGP_2, jnho)
                chkApprovePayment = clsCancelPayment.Check_Payment_Approved(clsUtility.gConnGP_2, jnho)
                chkApproveNonPay = clsCancelPayment.Check_WHT_NON_PAY_Approved(clsUtility.gConnGP_2, jnho)

                '-- mom: 20170411 ห้ามยกเลิกหลัง confirm batch และ หลัง generate payment file 
                If chkNonPay Then
                    If chkConfirmBatchNonPay Then
                        MsgBox("Journal Hold: '" & jnho & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
                        lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้")
                        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                        Continue For
                    End If
                Else
                    If chkConfirmBatch Then
                        MsgBox("Journal Hold: '" & jnho & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
                        lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้")
                        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                        Continue For
                    End If
                End If
                If chkGeneratePaymentFile Then
                    MsgBox("Journal Hold: '" & jnho & "' generatepayment file แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' generatepayment file แล้ว, ไม่สามารถยกเลิกได้")
                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                    Continue For
                End If
                '-- mom: 20170411 ห้ามยกเลิกหลัง confirm batch และ หลัง generate payment file 

                Dim oleTrans As OleDbTransaction

                oleTrans = clsUtility.gConnGP.BeginTransaction()

                If chkNonPay Then '--> non pay
                    If chkGeneratePaymentFile Then '--> generate payment file แล้ว
                        '0 get journal & voucher
                        strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                        If strJournalNoCurrent = "" Then
                            MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                            Exit Sub
                        Else
                            '--strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeOLD)
                            strJournalTypeReverse = "J" & strJournalTypeOLD.Substring(1, 1)
                            strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                        End If

                        '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Start Gen GL Reject Error by Account dept.")
                        '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

                        '1 move wht
                        complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True)
                        count = count + 1
                        '--- '5.1 บันทึกบัญชี
                        '--complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                        complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                        count = count + 1
                        '--- '5.2 update voucher
                        complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 1, oleTrans)
                        count = count + 1
                        '--- '5.3 update journal
                        complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 1, oleTrans)
                        count = count + 1

                        If complete.Equals(count) Then
                            oleTrans.Commit()
                            SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                            lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                        Else
                            oleTrans.Rollback()
                            SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                            lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Exit Sub
                        End If
                    Else '--> ยังไม่ generate payment file, confirm batch เรียบร้อยแล้ว
                        If chkConfirmBatchNonPay Then '-->confirm batch เรียบร้อยแล้ว
                            '0 get journal & voucher
                            strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                            If strJournalNoCurrent = "" Then
                                MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                                Exit Sub
                            Else
                                '--strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeOLD)
                                strJournalTypeReverse = "J" & strJournalTypeOLD.Substring(1, 1)
                                strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                            End If

                            '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Start Gen GL Reject Error by Account dept.")
                            '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

                            '1 move wht
                            complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True)
                            count = count + 1
                            '--- '5.1 บันทึกบัญชี
                            '--complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                            complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                            count = count + 1
                            '--- '5.2 update voucher
                            complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 1, oleTrans)
                            count = count + 1
                            '--- '5.3 update journal
                            complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 1, oleTrans)
                            count = count + 1

                            If complete.Equals(count) Then
                                oleTrans.Commit()
                                SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Else
                                oleTrans.Rollback()
                                SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Exit Sub
                            End If
                        Else '--> ยังไม่ confirm batch
                            If chkApprovePayment Then '--> approve payment แล้ว
                                '0 get journal & voucher
                                strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                                If strJournalNoCurrent = "" Then
                                    MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                                    Exit Sub
                                Else
                                    '--strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeOLD)
                                    strJournalTypeReverse = "J" & strJournalTypeOLD.Substring(1, 1)
                                    strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                                End If

                                '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Start Gen GL Reject Error by Account dept.")
                                '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

                                '1 move wht
                                complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim)
                                count = count + 1
                                '--- '5.1 บันทึกบัญชี
                                '--complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                                complete = complete + ReverseNonPayAfterPost(clsUtility.gConnGP, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeOLD & strVoucherNoCurrent + 1, oleTrans, "")
                                count = count + 1
                                '--- '5.2 update voucher
                                complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 1, oleTrans)
                                count = count + 1
                                '--- '5.3 update journal
                                complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 1, oleTrans)
                                count = count + 1

                                If complete.Equals(count) Then
                                    oleTrans.Commit()
                                    SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Else
                                    oleTrans.Rollback()
                                    SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                    Exit Sub
                                End If

                                '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Finish Gen GL Reject Error by Account dept. Total")
                                '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Else
                                '1. delete payment
                                complete = complete + DeletePayment(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '2. delete wht
                                complete = complete + DeleteWHT(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '3. delete gl
                                complete = complete + DeleteGL(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '4. delete relation
                                complete = complete + DeleteTransRef(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                If complete.Equals(count) Then
                                    oleTrans.Commit()
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Else
                                    oleTrans.Rollback()
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                    Exit Sub
                                End If
                            End If
                        End If
                    End If
                Else '--> pay scb net
                    If chkGeneratePaymentFile Then '--> generate payment file แล้ว, เกิด journal C* + P*
                        '-----------------------
                        '0 get journal & voucher
                        '-----------------------
                        strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                        If strJournalNoCurrent = "" Then
                            MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                            Exit Sub
                        Else
                            strJournalTypeReverse = "R" & strJournalTypeOLD.Substring(1, 1)
                            strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                            strVoucherNoCurrentJD = GetVoucherNo(clsUtility.gConnGP_2, "J" & strJournalTypeOLD.Substring(1, 1))
                        End If
                        '1 move payment
                        complete = complete + movePaymentcompleteToPaymentreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True, paymth)
                        count = count + 1
                        '2 move wht
                        complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True)
                        count = count + 1
                        '3 update status ข้อมูลในตาราง gps_payment เพื่อรองรับการ Gen ไฟล์จ่ายใหม่
                        complete = complete + updatePaymentByConfirmdate(clsUtility.gConnGP, confDate, oleTrans, batchNo)
                        count = count + 1
                        '4 ลบข้อมูลในตาราง GPS_GENPAYMENTFILE_LOG เพื่อรองรับการ Gen ไฟล์จ่ายใหม่
                        complete = complete + deleteGenpaymentFilelog(clsUtility.gConnGP, confDate, oleTrans, batchNo)
                        count = count + 1
                        '--- '5.1.1 บันทึกบัญชี กลับขา C*
                        complete = complete + ReverseGLAfterPostByJournalType(clsUtility.gConnGP, strJournalTypeOLD, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeReverse & strVoucherNoCurrent + 1, oleTrans, "")
                        count = count + 1
                        '--- '5.1.2 บันทึกบัญชี กลับขา P*
                        complete = complete + ReverseGLAfterPostByJournalType(clsUtility.gConnGP, "P" & strJournalTypeOLD.Substring(1, 1), jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 2, strJournalTypeReverse & strVoucherNoCurrent + 2, oleTrans, "")
                        count = count + 1
                        '--- '5.1.3 บันทึกบัญชี กลับขา J*
                        HJN = ReverseGLAfterPostByJournalType(clsUtility.gConnGP, "J" & strJournalTypeOLD.Substring(1, 1), jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 3, "J" & strJournalTypeOLD.Substring(1, 1) & strVoucherNoCurrentJD + 1, oleTrans, "")
                        complete = complete + HJN
                        If HJN < 0 Then
                            count = count + 1
                        Else
                            count = count + HJN
                        End If
                        '--- '5.2 update voucher
                        If HJN > 0 Then
                            complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 2, oleTrans)
                            count = count + 1
                            complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrentJD + 1, oleTrans)
                            count = count + 1
                        Else
                            complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 2, oleTrans)
                            count = count + 1
                        End If
                        '--- '5.3 update journal
                        If HJN > 0 Then
                            complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 3, oleTrans)
                        Else
                            complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 2, oleTrans)
                        End If
                        count = count + 1
                        '-----------------------
                        If complete.Equals(count) Then
                            oleTrans.Commit()
                            SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                            lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                        Else
                            oleTrans.Rollback()
                            SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                            lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Exit Sub
                        End If

                        '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Start Gen GL Reject Error by Account dept.")
                        '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

                        '5 บันทึกบัญชี
                        '' ''ocallTrans = clsUtility.gConnGP.BeginTransaction
                        '' ''Dim blnAccPass As Boolean = CALL_GPS_SP_GET_RejectHash(clsUtility.gConnGP, batchDate, batchNo, gUserLogin, ocallTrans)
                        '' ''If blnAccPass Then
                        '' ''    ocallTrans.Commit()
                        '' ''Else
                        '' ''    ocallTrans.Rollback()
                        '' ''    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Can not reverse GL!!")
                        '' ''    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                        '' ''    '** ต้อง manual gl หรือ insert payment, wht กลับจาก reject
                        '' ''    Exit Sub
                        '' ''End If
                        '--lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Finish Gen GL Reject Error by Account dept.")
                        '--lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                    Else '--> ยังไม่ generate payment file, confirm batch เรียบร้อยแล้ว
                        If chkConfirmBatch Then '-->confirm batch เรียบร้อยแล้ว, เกิด journal C* + P*
                            '-----------------------
                            '0 get journal & voucher
                            '-----------------------
                            strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                            If strJournalNoCurrent = "" Then
                                MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                                Exit Sub
                            Else
                                strJournalTypeReverse = "R" & strJournalTypeOLD.Substring(1, 1)
                                strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                                strVoucherNoCurrentJD = GetVoucherNo(clsUtility.gConnGP_2, "J" & strJournalTypeOLD.Substring(1, 1))
                            End If
                            '1 move payment
                            complete = complete + movePaymentcompleteToPaymentreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True, paymth)
                            count = count + 1
                            '2 move wht
                            complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True)
                            count = count + 1
                            '--- '5.1.1 บันทึกบัญชี กลับขา C*
                            complete = complete + ReverseGLAfterPostByJournalType(clsUtility.gConnGP, strJournalTypeOLD, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeReverse & strVoucherNoCurrent + 1, oleTrans, "")
                            count = count + 1
                            '--- '5.1.2 บันทึกบัญชี กลับขา P*
                            complete = complete + ReverseGLAfterPostByJournalType(clsUtility.gConnGP, "P" & strJournalTypeOLD.Substring(1, 1), jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 2, strJournalTypeReverse & strVoucherNoCurrent + 2, oleTrans, "")
                            count = count + 1
                            ' ''--- '5.1.3 บันทึกบัญชี กลับขา J*
                            ''HJN = ReverseGLAfterPostByJournalType(clsUtility.gConnGP, "J" & strJournalTypeOLD.Substring(1, 1), jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 3, strJournalTypeReverse & strVoucherNoCurrent + 3, oleTrans, "")
                            ''complete = complete + HJN
                            ''count = count + 1
                            ' ''--- '5.2 update voucher
                            ''If HJN > 0 Then
                            ''    complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 3, oleTrans)
                            ''Else
                            ''    complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 2, oleTrans)
                            ''End If
                            ''count = count + 1
                            ' ''--- '5.3 update journal
                            ''complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 2, oleTrans)
                            ''count = count + 1
                            '--- '5.1.3 บันทึกบัญชี กลับขา J*
                            HJN = ReverseGLAfterPostByJournalType(clsUtility.gConnGP, "J" & strJournalTypeOLD.Substring(1, 1), jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 3, "J" & strJournalTypeOLD.Substring(1, 1) & strVoucherNoCurrentJD + 1, oleTrans, "")
                            complete = complete + HJN
                            If HJN < 0 Then
                                count = count + 1
                            Else
                                count = count + HJN
                            End If
                            '--- '5.2 update voucher
                            If HJN > 0 Then
                                complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 2, oleTrans)
                                count = count + 1
                                complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrentJD + 1, oleTrans)
                                count = count + 1
                            Else
                                complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 2, oleTrans)
                                count = count + 1
                            End If
                            '--count = count + 1
                            '--- '5.3 update journal
                            If HJN > 0 Then
                                complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 3, oleTrans)
                            Else
                                complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 2, oleTrans)
                            End If
                            count = count + 1
                            '-----------------------
                            If complete.Equals(count) Then
                                oleTrans.Commit()
                                SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Else
                                oleTrans.Rollback()
                                SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Exit Sub
                            End If

                            '' ''ocallTrans = clsUtility.gConnGP.BeginTransaction
                            '' ''Dim blnAccPass As Boolean = CALL_GPS_SP_GET_RejectHash(clsUtility.gConnGP, batchDate, batchNo, gUserLogin, ocallTrans)
                            '' ''If blnAccPass Then
                            '' ''    ocallTrans.Commit()
                            '' ''Else
                            '' ''    ocallTrans.Rollback()
                            '' ''    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Can not reverse GL!!")
                            '' ''    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            '' ''    '** ต้อง manual gl หรือ insert payment, wht กลับจาก reject
                            '' ''    Exit Sub
                            '' ''End If

                        Else '--> ยังไม่ confirm batch
                            If chkApprovePayment Then '--> approve payment แล้ว, เกิด journal C*
                                '-----------------------
                                '0 get journal & voucher
                                '-----------------------
                                strJournalNoCurrent = GetJournalNo(clsUtility.gConnGP_2, "JN_NO", "STOP").ToString.Trim
                                If strJournalNoCurrent = "" Then
                                    MsgBox("มีผู้ใช้งานกำลังอนุมัติรายการ กรุณาลองใหม่อีกครั้ง", MsgBoxStyle.Information)
                                    Exit Sub
                                Else
                                    strJournalTypeReverse = "R" & strJournalTypeOLD.Substring(1, 1)
                                    strVoucherNoCurrent = GetVoucherNo(clsUtility.gConnGP_2, strJournalTypeReverse)
                                End If
                                '1 move payment
                                complete = complete + movePaymentcompleteToPaymentreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim, True, paymth)
                                count = count + 1
                                '2 move wht
                                complete = complete + moveWhtToWhtreject(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, "0", gUserLogin, oleTrans, REJECT_TYPE, REJECT_GROUP, txtRemark.Text.Trim)
                                count = count + 1
                                '--- '5.1 บันทึกบัญชี
                                complete = complete + ReverseGLAfterPostByJournalType(clsUtility.gConnGP, strJournalTypeOLD, jnno, TRANSREF, Now.ToString("yyyyMMdd", New CultureInfo("en-GB")), strJournalNoCurrent + 1, strJournalTypeReverse & strVoucherNoCurrent + 1, oleTrans, "")
                                count = count + 1
                                '--- '5.2 update voucher
                                complete = complete + UpdateVCHNo(clsUtility.gConnGP, strJournalTypeReverse, "START", strVoucherNoCurrent + 1, oleTrans)
                                count = count + 1
                                '--- '5.3 update journal
                                complete = complete + UpdateJournalNo(clsUtility.gConnGP, "JN_NO", "START", strJournalNoCurrent + 1, oleTrans)
                                count = count + 1
                                '-----------------------
                                If complete.Equals(count) Then
                                    oleTrans.Commit()
                                    SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Else
                                    oleTrans.Rollback()
                                    SetJournalNoStatus(clsUtility.gConnGP_2, "JN_NO", "STOP")
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                    Exit Sub
                                End If

                                '-- lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Start Gen GL Reject Error by Account dept. Total")
                                '-- lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                ''5 บันทึกบัญชี --> ไม่ต้องลงในขั้นตอนนี้ รอตอน confirm batch จะ reverse ให้เอง
                                'If batchNo.Trim <> "" Then
                                '    Dim blnAccPass As Boolean = CallGL_REJ_ALL_ACC(clsUtility.gConnGP, batchDate, batchNo, TRANSREF, gUserLogin)
                                '    If blnAccPass Then
                                '    Else
                                '        lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Can not reverse GL!!")
                                '        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                '        '** ต้อง manual gl หรือ insert payment, wht กลับจาก reject
                                '        Exit Sub
                                '    End If
                                'End If
                                '-- lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Finish Gen GL Reject Error by Account dept.")
                                '-- lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                            Else '--> ยังไม่ approve payment
                                '1. delete payment
                                complete = complete + DeletePayment(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '2. delete wht
                                complete = complete + DeleteWHT(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '3. delete gl
                                complete = complete + DeleteGL(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                '4. delete relation
                                complete = complete + DeleteTransRef(clsUtility.gConnGP, jnho, TRANSREF, oleTrans, batchNo)
                                count = count + 1
                                If complete.Equals(count) Then
                                    oleTrans.Commit()
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Reject Data completed")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                Else
                                    oleTrans.Rollback()
                                    lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & jnho & "' Fail Reject Data")
                                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                                    Exit Sub
                                End If
                            End If
                        End If
                        '----------------------------

                    End If


                End If
            End If
            ClearData()
        Next
    End Sub


    Private Sub FrmCancelPayment_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        ListSection()
        ListType()
        ListDataSource()
        ListPaymentMethod()
        ListJournalType()
        btnCancelPayment.Enabled = False

    End Sub

    Private Sub ListJournalType()
        Dim sb As New StringBuilder()


        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_C) AS ID,DTS_JN_TYPE_C AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_C <> ' ' ")
        sb.Append("UNION ALL ")
        sb.Append("SELECT DISTINCT(DTS_JN_TYPE_J_NOPAY) AS ID,DTS_JN_TYPE_J_NOPAY AS NAME FROM GPS_TL_DATASOURCE WHERE (DTS_CORE_SYSTEM='ACC' OR DTS_CORE_SYSTEM='TLM') AND DTS_JN_TYPE_J_NOPAY <> ' ' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboJournalType
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        ClearData()
    End Sub

    Private Sub ClearData()
        Dim cbx As CheckBox = DataGridView1.Controls("SelectAll")

        txtJnFrom.Text = ""
        txtRemark.Text = ""
        If Not cbx Is Nothing Then cbx.Checked = False
        '--lbStatusWork.TopIndex = 0
        '--lbStatusWork.Items.Clear()

        Dim dt As DataTable
        dt = Nothing
        GetDataToGrid(dt)
        btnCancelPayment.Enabled = False
    End Sub

    'Private Sub AutoBindData()
    '    txtJnTo.Text = ""
    '    txtRemark.Text = ""

    '    Dim dt As DataTable
    '    dt = Nothing
    '    GetDataToGrid(dt)
    '    btnCancelPayment.Enabled = False
    'End Sub

    Private Sub AutoBindData()

        'BindJournalHold()

        Dim dt As DataTable

        Dim chkGeneratePaymentFile As Boolean
        Dim chkConfirmBatch As Boolean
        Dim chkConfirmBatchNonPay As Boolean
        Dim chkNonPay As Boolean

        chkGeneratePaymentFile = clsCancelPayment.Check_Export_to_Bank(clsUtility.gConnGP_2, txtJnFrom.Text.Trim)
        chkConfirmBatch = clsCancelPayment.Check_Confirm_Batch(clsUtility.gConnGP_2, txtJnFrom.Text.Trim)
        chkConfirmBatchNonPay = clsCancelPayment.Check_Confirm_Batch_NonPay(clsUtility.gConnGP_2, txtJnFrom.Text.Trim)
        chkNonPay = clsCancelPayment.Check_Non_Pay(clsUtility.gConnGP_2, txtJnFrom.Text.Trim)

        '-- mom: 20170411 ห้ามยกเลิกหลัง confirm batch และ หลัง generate payment file 
        If chkNonPay Then
            If chkConfirmBatchNonPay Then
                MsgBox("Journal Hold: '" & txtJnFrom.Text.Trim & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & txtJnFrom.Text.Trim & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้")
                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                Call ClearData()
                Exit Sub
            End If
        Else
            If chkConfirmBatch Then
                MsgBox("Journal Hold: '" & txtJnFrom.Text.Trim & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
                lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & txtJnFrom.Text.Trim & "' confirm batch แล้ว, ไม่สามารถยกเลิกได้")
                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                Call ClearData()
                Exit Sub
            End If
        End If
        If chkGeneratePaymentFile Then
            MsgBox("Journal Hold: '" & txtJnFrom.Text.Trim & "' generatepayment file แล้ว, ไม่สามารถยกเลิกได้", MsgBoxStyle.Information)
            lbStatusWork.Items.Add(DateTime.Now.ToString("HH:mm:ss") & " Journal Hold: '" & txtJnFrom.Text.Trim & "' generatepayment file แล้ว, ไม่สามารถยกเลิกได้")
            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
            Call ClearData()
            Exit Sub
        End If
        '-- mom: 20170411 ห้ามยกเลิกหลัง confirm batch และ หลัง generate payment file 

        dt = GetData_By_JournalHold(txtJnFrom.Text.Trim)

        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            GetDataToGrid(dt)
            AddSelectAllCheckBox(DataGridView1)
            btnCancelPayment.Enabled = True

            txtJnFrom.Text = dt.Rows(0)("TREF_JN_HOLD").ToString
            txtJnTo.Text = dt.Rows(dt.Rows.Count - 1)("TREF_JN_HOLD").ToString

        Else

            If txtJnFrom.Text.Trim <> "" Then
                MsgBox("Journal Hold: '" & txtJnFrom.Text.Trim & "' ไม่มีในระบบ / ยกเลิกการจ่ายแล้ว", MsgBoxStyle.Exclamation)
            End If
            Call ClearData()

        End If
    End Sub

    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray



        End With


        'Dim colCheckbox As New DataGridViewCheckBoxColumn()

        'colCheckbox.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader

        'colCheckbox.ThreeState = False
        'colCheckbox.TrueValue = 1
        'colCheckbox.FalseValue = 0
        'colCheckbox.IndeterminateValue = System.DBNull.Value
        'colCheckbox.DataPropertyName = "Checkbox"
        'colCheckbox.HeaderText = "SelectAll"
        'colCheckbox.Name = "Checkbox"
        'colCheckbox.ReadOnly = False
        'DataGridView1.Columns.Add(colCheckbox)


        Dim chk As New DataGridViewCheckBoxColumn
        With chk
            DataGridView1.Columns.Add(chk)

        End With

        '-- COLUMN 1 : TREF_JN_HOLD
        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .ReadOnly = True
            .DataPropertyName = "TREF_JN_HOLD"
            .Name = "Journal Hold"
            .ReadOnly = True
            .Width = 100
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.Columns.Add(c1)

        End With

        '-- COLUMN 12 : TREF_JN_NO_C
        Dim c12 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c12
            .Visible = True
            .ReadOnly = True
            .DataPropertyName = "TREF_JN_NO_C"
            .Name = "Journal No"
            .ReadOnly = True
            .Width = 100
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.Columns.Add(c12)
        End With

        '-- COLUMN 13 : TREF_VCH_NO_C
        Dim c13 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c13
            .Visible = True
            .ReadOnly = True
            .DataPropertyName = "TREF_VCH_NO_C"
            .Name = "Voucher No"
            .ReadOnly = True
            .Width = 100
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.Columns.Add(c13)
        End With

        '-- COLUMN 14 : TREF_TRANSREF
        Dim c14 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c14
            .Visible = True
            .ReadOnly = True
            .DataPropertyName = "TREF_TRANSREF"
            .Name = "Transaction Reference"
            .ReadOnly = True
            .Width = 150
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.Columns.Add(c14)
        End With

        '-- COLUMN 2 : GL_AMT
        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .ReadOnly = True
            .DataPropertyName = "GL_AMT"
            .Name = "Total GL Amt (Cr)"
            .ReadOnly = True
            .Width = 150
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            DataGridView1.Columns.Add(c2)
        End With

        '-- COLUMN 3 : GP_AMT
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .ReadOnly = True
            .DataPropertyName = "GP_AMT"
            .Name = "Total GP Amt"
            .ReadOnly = True
            .Width = 150
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            DataGridView1.Columns.Add(c3)
        End With

        '-- COLUMN 4 : TAX_AMT
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .ReadOnly = True
            .DataPropertyName = "TAX_AMT"
            .Name = "Total WHT Amt"
            .ReadOnly = True
            .Width = 150
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            DataGridView1.Columns.Add(c4)
        End With

        '-- COLUMN 5 : TREF_CREATEDATE
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_CREATEDATE"
            .Name = "CreateDate"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c5)
        End With

        '-- COLUMN 6 : TREF_CORE_SYSTEM
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_CORE_SYSTEM"
            .Name = "CoreSystem"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c6)
        End With

        '-- COLUMN 7 : TREF_TRANSREF
        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_TRANSREF"
            .Name = "Transaction Reference"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c7)
        End With

        '-- COLUMN 8 : TREF_PAYCRETYP_ID
        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_PAYCRETYP_ID"
            .Name = "TREF_PAYCRETYP_ID"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c8)
        End With

        '-- COLUMN 9 : TREF_PAYMTH
        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_PAYMTH"
            .Name = "Payment Type"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c9)
        End With

        '-- COLUMN 10 : TREF_SUB_PAYMTH
        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_SUB_PAYMTH"
            .Name = "Sub Payment Type"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c10)
        End With

        '-- COLUMN 11 : TREF_DEP_KEYIN
        Dim c11 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c11
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_DEP_KEYIN"
            .Name = "TREF_DEP_KEYIN"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c11)
        End With

        '-- COLUMN 15 : TREF_BATCHDATE
        Dim c15 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c15
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_BATCHDATE"
            .Name = "BATCH DATE"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c15)
        End With

        '-- COLUMN 16 : TREF_BATCH_NO
        Dim c16 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c16
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_BATCH_NO"
            .Name = "BATCH NO"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c16)
        End With

        '-- COLUMN 17 : TREF_BATCH_NO
        Dim c17 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c17
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_JN_TYPE"
            .Name = "JN_TYPE"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c17)
        End With

        '-- COLUMN 18 : TREF_BATCH_NO
        Dim c18 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c18
            .Visible = False
            .ReadOnly = True
            .DataPropertyName = "TREF_APPROVEDDATE"
            .Name = "APPROVED_DATE"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c18)
        End With

        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)
        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(2).DefaultCellStyle.Format = "###,###.00" 'AMOUNT GL
        DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(3).DefaultCellStyle.Format = "###,###.00" 'AMOUNT GP
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(4).DefaultCellStyle.Format = "###,###.00" 'AMOUNT TAX
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub

    Private Sub DataGridView1_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)
        End If
    End Sub

    Private Sub DataGridView1_MouseUp(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub

    Private Sub ControlStyle()
        'PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        'Panel1.BackColor = Color.FromArgb(255, 245, 240)

        btnCancelPayment.BackColor = Color.FromArgb(255, 245, 230)
        'btnCancelPayment.Height = 25
        cboDataSource.Enabled = False
        btnCancelPayment.Enabled = False
    End Sub

    Private Sub ListSection()
        Dim sb As New StringBuilder()

        sb.Append("SELECT A.DTS_MERGE_DEP, B.DEP_DEPNAME  ")
        sb.Append("FROM GPS_TL_DATASOURCE A LEFT JOIN GPS_TL_DEPARTMENT B ON A.DTS_MERGE_DEP=B.DEP_DEPCODE  ")
        sb.Append("WHERE A.DTS_CORE_SYSTEM='ACC' GROUP BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ORDER BY A.DTS_MERGE_DEP, B.DEP_DEPNAME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboSection
                .DataSource = dt
                .DisplayMember = "DEP_DEPNAME"
                .ValueMember = "DTS_MERGE_DEP"
            End With
        End If
        cboSection.SelectedIndex = 0
    End Sub

    Private Sub ListType()
        CboType.Items.Add("case เร่งด่วน")
        CboType.Items.Add("normal approve")
        CboType.SelectedIndex = 1
    End Sub

    Private Sub ListDataSource()
        cboDataSource.Items.Add("All")
        cboDataSource.Items.Add("TLM")
        cboDataSource.Items.Add("Non TLM")
        cboDataSource.SelectedIndex = 0
    End Sub

    Private Sub ListPaymentMethod()
        cboPaymentMethod.Items.Add("C")
        cboPaymentMethod.Items.Add("D")
        cboPaymentMethod.Items.Add("M")
        cboPaymentMethod.Items.Add("WHT(non pay)")
        cboPaymentMethod.SelectedIndex = 0
    End Sub

    Private Sub AddSelectAllCheckBox(ByVal theDataGridView As DataGridView)
        Dim cbx As New CheckBox
        cbx.Name = "SelectAll"
        'The box size
        cbx.Size = New Size(14, 14)

        Dim rect As Rectangle
        rect = theDataGridView.GetCellDisplayRectangle(0, -1, True)
        'Put CheckBox in the middle-center of the column header.
        cbx.Location = New System.Drawing.Point(rect.Location.X + ((rect.Width - cbx.Width) / 2), rect.Location.Y + ((rect.Height - cbx.Height) / 2))
        cbx.BackColor = Color.White
        theDataGridView.Controls.Add(cbx)

        'Handle header CheckBox check/uncheck function
        AddHandler cbx.Click, AddressOf HeaderCheckBox_Click
        'When any CheckBox value in the DataGridViewRows changed,
        'check/uncheck the header CheckBox accordingly.
        AddHandler theDataGridView.CellValueChanged, AddressOf DataGridView_CellChecked
        'This event handler is necessary to commit new CheckBox cell value right after
        'user clicks the CheckBox.
        'Without it, CellValueChanged event occurs until the CheckBox cell lose focus
        'which means the header CheckBox won't display corresponding checked state instantly when user
        'clicks any one of the CheckBoxes.
        AddHandler theDataGridView.CurrentCellDirtyStateChanged, AddressOf DataGridView_CurrentCellDirtyStateChanged
    End Sub

    Private Sub HeaderCheckBox_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me._IsSelectAllChecked = True

        Dim cbx As CheckBox
        cbx = DirectCast(sender, CheckBox)
        Dim theDataGridView As DataGridView = cbx.Parent

        For Each row As DataGridViewRow In theDataGridView.Rows
            row.Cells(0).Value = cbx.Checked
        Next

        theDataGridView.EndEdit()

        Me._IsSelectAllChecked = False
    End Sub

    Private Sub DataGridView_CellChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If Not Me._IsSelectAllChecked Then
            If dataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = False Then
                'When any single CheckBox is unchecked, uncheck the header CheckBox.
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = False
            Else
                'When any single CheckBox is checked, loop through all CheckBoxes to determine
                'if the header CheckBox needs to be unchecked.
                Dim isAllChecked As Boolean = True
                For Each row As DataGridViewRow In dataGridView.Rows
                    If row.Cells(0).Value = False Then
                        isAllChecked = False
                        Exit For
                    End If
                Next
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = isAllChecked
            End If
        End If
    End Sub

    Private Sub DataGridView_CurrentCellDirtyStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If TypeOf dataGridView.CurrentCell Is DataGridViewCheckBoxCell Then
            'When the value changed cell is DataGridViewCheckBoxCell, commit the change
            'to invoke the CellValueChanged event.
            dataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Function GetDataNonPay() As DataTable
        Try

            Dim str As String

            str = fnSringMain.ToString
            strSQL = str

            Dim sb As New StringBuilder()

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,GL_AMT,GP_AMT,TAX_AMT ")
            '-- AP-2016-008
            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,GL_AMT,GP_AMT,TAX_AMT, GPCR_BNKCODE ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            'sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            'sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            'sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' AND SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID)L ")
            sb.Append("LEFT JOIN ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            '-- AP-2016-008
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE, SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            '-- AP-2016-008
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function fnSringMain() As StringBuilder
        Dim sb As New StringBuilder()

        sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH ")
        sb.Append("FROM GPS_TRANSREF_REL ")
        sb.Append("WHERE 1=1 ")

        If cboSection.SelectedValue.ToString = "DIS" Then
            sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
        Else
            sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
        End If

        If CboType.SelectedIndex = 0 Then
            sb.Append("AND TREF_PAYCRETYP_ID = '003' ")
        Else
            sb.Append("AND TREF_PAYCRETYP_ID <> '003' ")
        End If

        Select Case cboDataSource.SelectedIndex
            Case "1"
                sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
            Case "2"
                sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
        End Select

        If txtEntryDate.Text.Trim <> "" Then
            Dim entrydate As String
            entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
            sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
            'sb.Append("AND TREF_CREATEDATE='" & dtpEntryDate.Value.ToString("yyyyMMdd") & "'")
        End If


        If cboPaymentMethod.Text.ToUpper = "WHT(NON PAY)" Then
            sb.Append("AND TREF_PAYMTH IS NULL ")
        Else
            sb.Append("AND TREF_PAYMTH = '" & cboPaymentMethod.Text.Trim & "'   ")
        End If


        If txtDueDate.Text.Trim <> "" Then
            Dim duedate As String
            duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
            sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
            'sb.Append("AND TREF_PAIDDATE='" & dtpDueDate.Value.ToString("yyyyMMdd") & "'")
        End If

        sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

        sb.Append("AND TREF_APPROVEDBY IS NULL ")
        sb.Append("ORDER BY TREF_JN_HOLD) A ")

        Return sb

    End Function

    Function GetData() As DataTable
        Try

            Dim str As String

            str = fnSringMain.ToString
            strSQL = str

            Dim sb As New StringBuilder()

            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' OR SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53') ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH)L ")
            sb.Append("LEFT JOIN ")

            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function GetData_By_JournalHold(ByVal strJournalHold As String) As DataTable
        Try

            Dim sb As New StringBuilder()

            sb.Append("SELECT L.TREF_CREATEDATE, L.TREF_CORE_SYSTEM, L.TREF_JN_HOLD, L.TREF_JN_NO_C, L.TREF_VCH_NO_C, L.TREF_DEP_KEYIN, L.TREF_BATCHDATE, L.TREF_BATCH_NO, L.TREF_TRANSREF, L.TREF_PAYCRETYP_ID, L.TREF_PAYMTH, L.TREF_SUB_PAYMTH, L.TREF_APPROVEDDATE")
            sb.Append("     , GL_AMT, GP_AMT, TAX_AMT, L.TREF_JN_TYPE")
            sb.Append("  FROM (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_PAYCRETYP_ID, TREF_PAYMTH, TREF_SUB_PAYMTH, TREF_JN_TYPE, TREF_APPROVEDDATE,")
            sb.Append("               SUM(NVL(L.GLCR_AMOUNT, 0)) AS GL_AMT")
            sb.Append("          FROM GPS_GL_CREATION L")
            sb.Append("         INNER JOIN (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_PAYCRETYP_ID, TREF_PAYMTH,")
            sb.Append("                           TREF_SUB_PAYMTH, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("            FROM(GPS_TRANSREF_REL)")
            sb.Append("            WHERE(1 = 1)")
            sb.Append("                     ORDER BY TREF_JN_HOLD) A")
            sb.Append("            ON L.GLCR_CREATEDATE = A.TREF_CREATEDATE")
            sb.Append("           AND L.GLCR_CORE_SYSTEM = A.TREF_CORE_SYSTEM")
            sb.Append("           AND L.GLCR_TRANSREF = A.TREF_TRANSREF")
            sb.Append("         WHERE L.GLCR_DRCR = 'C'")
            sb.Append("         GROUP BY TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO")
            sb.Append("                , TREF_TRANSREF, TREF_PAYCRETYP_ID, TREF_PAYMTH, TREF_SUB_PAYMTH, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("        ) L")
            sb.Append("  LEFT JOIN (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, SUM(NVL(P.GPCR_AMOUNT, 0)) AS GP_AMT, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("               FROM GPS_PAYMENT_CREATION P")
            sb.Append("              INNER JOIN (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_PAYCRETYP_ID, TREF_PAYMTH,")
            sb.Append("                                TREF_SUB_PAYMTH, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("            FROM(GPS_TRANSREF_REL)")
            sb.Append("            WHERE(1 = 1)")
            sb.Append("                          ORDER BY TREF_JN_HOLD) A")
            sb.Append("                 ON P.GPCR_CREATEDATE = A.TREF_CREATEDATE")
            sb.Append("                AND P.GPCR_CORE_SYSTEM = A.TREF_CORE_SYSTEM")
            sb.Append("                AND P.GPCR_TRANSREF = A.TREF_TRANSREF")
            sb.Append("              GROUP BY TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("             ) P")
            sb.Append("    ON L.TREF_CREATEDATE = P.TREF_CREATEDATE")
            sb.Append("   AND L.TREF_CORE_SYSTEM = P.TREF_CORE_SYSTEM")
            sb.Append("   AND L.TREF_TRANSREF = P.TREF_TRANSREF")
            sb.Append("  LEFT JOIN (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, SUM(NVL(T.TAXCR_TAX_AMT, 0)) AS TAX_AMT, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("               FROM GPS_WHT_CREATION T")
            sb.Append("              INNER JOIN (SELECT TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_PAYCRETYP_ID,")
            sb.Append("                                TREF_PAYMTH, TREF_SUB_PAYMTH, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("             FROM(GPS_TRANSREF_REL)")
            sb.Append("            WHERE(1 = 1)")
            sb.Append("                          ORDER BY TREF_JN_HOLD) A")
            sb.Append("                 ON T.TAXCR_CREATEDATE = A.TREF_CREATEDATE")
            sb.Append("                AND T.TAXCR_CORE_SYSTEM = A.TREF_CORE_SYSTEM")
            sb.Append("                AND T.TAXCR_TRANSREF = A.TREF_TRANSREF")
            sb.Append("              GROUP BY TREF_CREATEDATE, TREF_CORE_SYSTEM, TREF_JN_HOLD, TREF_JN_NO_C, TREF_VCH_NO_C, TREF_DEP_KEYIN, TREF_BATCHDATE, TREF_BATCH_NO, TREF_TRANSREF, TREF_JN_TYPE, TREF_APPROVEDDATE")
            sb.Append("             ) T")
            sb.Append("    ON L.TREF_CREATEDATE = T.TREF_CREATEDATE")
            sb.Append("   AND L.TREF_CORE_SYSTEM = T.TREF_CORE_SYSTEM")
            sb.Append("   AND L.TREF_TRANSREF = T.TREF_TRANSREF")
            sb.Append(" WHERE L.TREF_JN_HOLD = '" & strJournalHold & "'") '1600384' --'1605595'
            sb.Append("   AND L.TREF_TRANSREF NOT IN (SELECT TAXCR_TRANSREF ")
            sb.Append("                                 FROM(GPS_WHT_CREATION)")
            sb.Append("                                  WHERE GPS_WHT_CREATION.TAXCR_FLAG_VALIDATE = 'INCOMPLETE'")
            sb.Append("                                    AND GPS_WHT_CREATION.TAXCR_TRANSREF = L.TREF_TRANSREF)")
            sb.Append("   AND L.TREF_TRANSREF NOT IN ")
            sb.Append("       (SELECT GPCR_TRANSREF")
            sb.Append("            FROM(GPS_PAYMENT_CREATION)")
            sb.Append("         WHERE GPS_PAYMENT_CREATION.GPCR_FLAG_VALIDATE = 'INCOMPLETE'")
            sb.Append("           AND GPS_PAYMENT_CREATION.GPCR_TRANSREF = L.TREF_TRANSREF)")
            '--sb.Append("   AND (L.TREF_TRANSREF NOT IN (SELECT GPRJ_TRANSREF FROM GPS_PAYMENT_REJ WHERE GPS_PAYMENT_REJ.GPRJ_CORE_SYSTEM = 'ACC' AND GPS_PAYMENT_REJ.GPRJ_TRANSREF = L.TREF_TRANSREF)")
            '--sb.Append("   OR (L.TREF_PAYMTH IS NULL AND L.TREF_SUB_PAYMTH IS NULL AND L.TREF_TRANSREF NOT IN ")
            '--sb.Append("         (SELECT TAXCR_TRANSREF")
            '--sb.Append("            FROM(GPS_WHT_CREATION)")
            '--sb.Append("           WHERE GPS_WHT_CREATION.TAXCR_FLAG_VALIDATE = 'INCOMPLETE'")
            '--sb.Append("             AND GPS_WHT_CREATION.TAXCR_TRANSREF = L.TREF_TRANSREF")
            '--sb.Append(" )))")
            sb.Append(" ORDER BY L.TREF_JN_HOLD")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function GetData_Validate(ByVal str As String, ByVal transref As String) As DataTable
        Try

            Dim sb As New StringBuilder()

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT ")
            '-- AP-2016-008
            sb.Append("SELECT L.TREF_CREATEDATE,L.TREF_CORE_SYSTEM,L.TREF_JN_HOLD,L.TREF_TRANSREF,L.TREF_PAYCRETYP_ID,L.TREF_PAYMTH,L.TREF_SUB_PAYMTH,GL_AMT,GP_AMT,TAX_AMT, NVL(GPCR_BNKCODE,' ') GPCR_BNKCODE ")
            sb.Append("FROM ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH,SUM(NVL(L.GLCR_AMOUNT,0)) AS GL_AMT ")
            sb.Append("FROM GPS_GL_CREATION L INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON L.GLCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND L.GLCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.GLCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON L.GLCR_S_ACCOUNT=GL2.ACNT_S_CODE   ")
            sb.Append("AND  GL2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("WHERE L.GLCR_DRCR='C' OR SUBSTR(L.GLCR_S_TT_TR,1,2) IN ('02','03','53') ")

            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,TREF_PAYCRETYP_ID,TREF_PAYMTH,TREF_SUB_PAYMTH)L ")
            sb.Append("LEFT JOIN ")

            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            '-- AP-2016-008
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE, SUM(NVL(P.GPCR_AMOUNT,0)) AS GP_AMT ")
            sb.Append("FROM GPS_PAYMENT_CREATION P INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON P.GPCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND P.GPCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND P.GPCR_TRANSREF=A.TREF_TRANSREF  ")
            '-- AP-2016-008
            '-- AP-2016-008 'sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)P ")
            '-- AP-2016-008 
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF, P.GPCR_BNKCODE)P ")
            sb.Append("ON L.TREF_CREATEDATE=P.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=P.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=P.TREF_TRANSREF  ")
            sb.Append("LEFT JOIN ")
            sb.Append("(SELECT TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF,SUM(NVL(T.TAXCR_TAX_AMT,0)) AS TAX_AMT ")
            sb.Append("FROM GPS_WHT_CREATION T INNER JOIN  ")
            sb.Append(str)

            sb.Append("ON T.TAXCR_CREATEDATE=A.TREF_CREATEDATE  ")
            sb.Append("AND T.TAXCR_CORE_SYSTEM=A.TREF_CORE_SYSTEM  ")
            sb.Append("AND T.TAXCR_TRANSREF=A.TREF_TRANSREF  ")
            sb.Append("GROUP BY TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_JN_HOLD,TREF_TRANSREF)T ")
            sb.Append("ON L.TREF_CREATEDATE=T.TREF_CREATEDATE  ")
            sb.Append("AND L.TREF_CORE_SYSTEM=T.TREF_CORE_SYSTEM  ")
            sb.Append("AND L.TREF_TRANSREF=T.TREF_TRANSREF ")
            sb.Append(" WHERE L.TREF_TRANSREF = '" & transref & "'")
            sb.Append("ORDER BY L.TREF_JN_HOLD  ")


            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Function fnGetJournalHold() As DataTable
        Try


            Dim sb As New StringBuilder()
            sb.Append("SELECT TREF_JN_HOLD,TREF_TRANSREF ")
            sb.Append("FROM GPS_TRANSREF_REL ")
            sb.Append("WHERE 1=1 ")

            If cboSection.SelectedValue.ToString = "DIS" Then
                sb.Append("AND (TREF_DEP_KEYIN = 'DIS' OR TREF_DEP_KEYIN = 'TLM') ")
            Else
                sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")
            End If

            ''sb.Append("AND TREF_DEP_KEYIN = '" & cboSection.SelectedValue & "'    ")

            'If cboDataSource.Text.ToUpper <> "ALL" Then
            '    sb.Append("AND TREF_DTSOURCE = '" & cboDataSource.Text & "' ")
            'End If
            Select Case cboDataSource.SelectedIndex
                Case "1"
                    sb.Append("AND TREF_CORE_SYSTEM = 'TLM' ")
                Case "2"
                    sb.Append("AND TREF_CORE_SYSTEM <> 'TLM' ")
            End Select

            If txtEntryDate.Text.Trim <> "" Then
                Dim entrydate As String
                entrydate = txtEntryDate.Text.Substring(6, 4) & txtEntryDate.Text.Substring(3, 2) & txtEntryDate.Text.Substring(0, 2)
                sb.Append("AND TREF_CREATEDATE='" & entrydate & "'")
                'sb.Append("AND TREF_CREATEDATE='" & dtpEntryDate.Value.ToString("yyyyMMdd") & "'")
            End If


            If cboPaymentMethod.Text.ToUpper = "WHT(NON PAY)" Then
                sb.Append("AND TREF_PAYMTH IS NULL ")
            Else
                sb.Append("AND TREF_PAYMTH = '" & cboPaymentMethod.Text.Trim & "'   ")
            End If

            If txtDueDate.Text.Trim <> "" Then
                Dim duedate As String
                duedate = txtDueDate.Text.Substring(6, 4) & txtDueDate.Text.Substring(3, 2) & txtDueDate.Text.Substring(0, 2)
                sb.Append("AND TREF_PAIDDATE='" & duedate & "'")
                'sb.Append("AND TREF_PAIDDATE='" & dtpDueDate.Value.ToString("yyyyMMdd") & "'")
            End If

            sb.Append("AND TREF_JN_TYPE = '" & cboJournalType.SelectedValue.ToString & "' ")

            sb.Append("AND TREF_APPROVEDBY IS NULL ")
            sb.Append("ORDER BY TREF_JN_HOLD ")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

            If dt.Rows.Count > 0 Then
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Sub txtJnFrom_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtJnFrom.KeyDown
        If e.KeyCode = Keys.Enter Then
            txtJnTo.Text = txtJnFrom.Text.Trim
            AutoBindData()
        End If
    End Sub

    Private Sub txtEntryDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtEntryDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtEntryDate.Text.Trim = "" Then
                AutoBindData()
            Else
                Dim dateString As String = txtEntryDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtEntryDate.Text = ""
                    txtEntryDate.Focus()
                    ClearData()
                End If
            End If

        End If
    End Sub
    Private Sub txtDueDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDueDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDueDate.Text.Trim = "" Then
                AutoBindData()
            Else
                Dim dateString As String = txtDueDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    AutoBindData()
                Else
                    MsgBox("Date format is not valid")
                    txtDueDate.Text = ""
                    txtDueDate.Focus()
                    ClearData()
                End If
            End If

        End If
    End Sub

    'Private Function jnno() As String
    '    Throw New NotImplementedException
    'End Function

    Private Sub CboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboType.SelectedIndexChanged
        AutoBindData()
    End Sub

    Private Sub btnCancelPayment_Click(sender As Object, e As System.EventArgs) Handles btnCancelPayment.Click

        If txtRemark.Text.Trim = "" Then
            MsgBox("กรุณาระบุเหตุผลในการยกเลิกรายการจ่ายในช่อง Remark", MsgBoxStyle.Exclamation)
            txtRemark.Focus()
            Exit Sub
        End If

        ret_msg = ""
        countrow = 0
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = True Then
                countrow += 1
            End If
        Next

        If countrow < 1 Then
            Exit Sub
        End If

        If MessageBox.Show("Do you want to cancle payment ? (Y/N)", "Confirm Cancel Payment", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            Me.Cursor = Cursors.WaitCursor

            paytype = cboPaymentMethod.Text.ToUpper
            Try
                Call Approve()
            Catch ex As Exception
                MsgBox(ex.ToString, MsgBoxStyle.Critical)
            End Try

            Me.Cursor = Cursors.Arrow

            'Try
            '    Dim frmwait As New frmProgresswait(Me.BackgroundWorker1)
            '    frmwait.ShowDialog()

            'Catch ex As Exception
            '    StopWorker()
            '    MsgBox("Process Error!")
            'End Try

            'strSQL = ""



        End If

    End Sub
    ' Move Data in GPS_PAYMENT_COMPLETE table GPS_PAYMENT_REJ
    Public Function movePaymentcompleteToPaymentreject(ByVal oleconn As OleDbConnection _
                                                     , ByVal createDate As String _
                                                     , ByVal coreSystem As String _
                                                     , ByVal transRef As String _
                                                     , ByVal gpLine As String _
                                                     , ByVal gUser As String _
                                                     , Optional ByVal oTrans As OleDbTransaction = Nothing _
                                                     , Optional ByVal REJECT_TYPE As String = "" _
                                                     , Optional ByVal REJECT_GROUP As String = "" _
                                                     , Optional ByVal Reject_Remark As String = "" _
                                                     , Optional ByVal ConfirmBatch As Boolean = False _
                                                     , Optional ByVal PaymentType As String = "")
        ' Create Transaction

        Try
            Dim sb As New StringBuilder
            Dim sysdate As String = Now.ToString("yyyyMMdd")
            Dim i, completeStr, count As Integer
            i = 0
            completeStr = 0
            count = 0
            '3.1 Remove data from GPS_Payment table
            ' Move complete to reject
            sb.Remove(0, sb.Length)
            sb.Append(" INSERT INTO GPS_PAYMENT_REJ PRJ ( ")
            sb.Append(" PRJ.GPRJ_BATCHDATE ,PRJ.GPRJ_BATCH_NO ,PRJ.GPRJ_CREATEDATE ,PRJ.GPRJ_CORE_SYSTEM ")
            sb.Append(" ,PRJ.GPRJ_TRANSREF ,PRJ.GPRJ_GPTREF_SEQNO ,PRJ.GPRJ_POLNO ,PRJ.GPRJ_BILLNO ")
            sb.Append(" ,PRJ.GPRJ_PAIDDATE ,PRJ.GPRJ_AMOUNT ,PRJ.GPRJ_DESC ,PRJ.GPRJ_PAYMTH ")
            sb.Append(" ,PRJ.GPRJ_PAYEE_NAME ,PRJ.GPRJ_BNKCODE ,PRJ.GPRJ_BNKCODE_NO ,PRJ.GPRJ_BNKBRN ")
            sb.Append(" ,PRJ.GPRJ_BNKNAME ,PRJ.GPRJ_PAYEE_BNKACCNO ,PRJ.GPRJ_PAYEE_BNKACCNME ,PRJ.GPRJ_COMMENT ")
            sb.Append(" ,PRJ.GPRJ_ADDRESS1 ,PRJ.GPRJ_DISTRICT ,PRJ.GPRJ_PROVINCE ,PRJ.GPRJ_INSURENAME ")
            sb.Append(" ,PRJ.GPRJ_DATASOURCE_NME ,PRJ.GPRJ_RESERVE6 ,PRJ.GPRJ_MERCHN_NO ,PRJ.GPRJ_CDCARD_DATE ")
            sb.Append(" ,PRJ.GPRJ_RESERVE9 ,PRJ.GPRJ_RESERVE10 ,PRJ.GPRJ_SYS_REF ,PRJ.GPRJ_SYS_GR ")
            sb.Append(" ,PRJ.GPRJ_SUB_PAYMTH ,PRJ.GPRJ_FLAG_FLWBILL ,PRJ.GPRJ_OSEA_LIST ,PRJ.GPRJ_PHONE ")
            sb.Append(" ,PRJ.GPRJ_FAX ,PRJ.GPRJ_SWIFT_CODE ,PRJ.GPRJ_BNKBRN_NAME ,PRJ.GPRJ_BNKADDR ")
            sb.Append(" ,PRJ.GPRJ_COUNTRY ,PRJ.GPRJ_CURRENCY ,PRJ.GPRJ_EXCHN_RATE ,PRJ.GPRJ_BNKCHARGES ")
            sb.Append(" ,PRJ.GPRJ_REJECT_TYPE ,PRJ.GPRJ_REJECT_FUNC ,PRJ.GPRJ_BATCHTYPE ")
            sb.Append(" ,PRJ.CREATEDBY ,PRJ.CREATEDDATE ,PRJ.UPDATEDBY ,PRJ.UPDATEDDATE) ")
            sb.Append(" SELECT  ")
            sb.Append(" COMP.GPCM_BATCHDATE ,COMP.GPCM_BATCH_NO ,COMP.GPCM_CREATEDATE ,COMP.GPCM_CORE_SYSTEM ")
            sb.Append(" ,COMP.GPCM_TRANSREF ,COMP.GPCM_GPTREF_SEQNO ,COMP.GPCM_POLNO ,COMP.GPCM_BILLNO ")
            sb.Append(" ,COMP.GPCM_PAIDDATE ,COMP.GPCM_AMOUNT ")

            If ConfirmBatch Then
                If PaymentType.Substring(0, 1) = "C" Then
                    If PaymentType = "C:C" Then
                        sb.Append(" , SUBSTR('CHEQUE:'||(SELECT NVL(GPS_PAYMENT.GP_CHQNO, '-') FROM GENERATEPAYMENT.GPS_PAYMENT WHERE GPS_PAYMENT.GP_CREATEDATE = COMP.GPCM_CREATEDATE AND GPS_PAYMENT.GP_CORE_SYSTEM = COMP.GPCM_CORE_SYSTEM AND GPS_PAYMENT.GP_TRANSREF = COMP.GPCM_TRANSREF AND GPS_PAYMENT.GP_GPTREF_SEQNO = COMP.GPCM_GPTREF_SEQNO) || ',' || COMP.GPCM_DESC, 1, 100) ")
                    Else
                        sb.Append(" , SUBSTR('CHEQUE:'||(SELECT NVL(GPS_PAYMENT.GP_CHQNO, '-') FROM GENERATEPAYMENT.GPS_PAYMENT WHERE GPS_PAYMENT.GP_CREATEDATE = COMP.GPCM_CREATEDATE AND GPS_PAYMENT.GP_CORE_SYSTEM = COMP.GPCM_CORE_SYSTEM AND GPS_PAYMENT.GP_TRANSREF = COMP.GPCM_TRANSREF ) || ',' || COMP.GPCM_DESC, 1, 100) ")
                    End If
                Else
                    sb.Append(" ,COMP.GPCM_DESC ")
                End If
            Else
                sb.Append(" ,COMP.GPCM_DESC ")
            End If

            sb.Append(" ,COMP.GPCM_PAYMTH ")
            sb.Append(" ,COMP.GPCM_PAYEE_NAME ,COMP.GPCM_BNKCODE ,COMP.GPCM_BNKCODE_NO ,COMP.GPCM_BNKBRN ")
            sb.Append(" ,COMP.GPCM_BNKNAME ,COMP.GPCM_PAYEE_BNKACCNO ,COMP.GPCM_PAYEE_BNKACCNME ,COMP.GPCM_COMMENT ")
            sb.Append(" ,COMP.GPCM_ADDRESS1 ,COMP.GPCM_DISTRICT ,COMP.GPCM_PROVINCE ,COMP.GPCM_INSURENAME ")
            sb.Append(" ,COMP.GPCM_DATASOURCE_NME ,COMP.GPCM_RESERVE6 ,COMP.GPCM_MERCHN_NO ,COMP.GPCM_CDCARD_DATE ")
            sb.Append(" ,COMP.GPCM_RESERVE9 ,COMP.GPCM_RESERVE10 ,COMP.GPCM_SYS_REF ,COMP.GPCM_SYS_GR ")
            sb.Append(" ,COMP.GPCM_SUB_PAYMTH ,COMP.GPCM_FLAG_FLWBILL ,COMP.GPCM_OSEA_LIST ,COMP.GPCM_PHONE ")
            sb.Append(" ,COMP.GPCM_FAX ,COMP.GPCM_SWIFT_CODE ,COMP.GPCM_BNKBRN_NAME ,COMP.GPCM_BNKADDR ")
            sb.Append(" ,COMP.GPCM_COUNTRY ,COMP.GPCM_CURRENCY ,COMP.GPCM_EXCHN_RATE ,COMP.GPCM_BNKCHARGES ")
            '--sb.Append(" ,'" & REJECT_TYPE & "' ,'" & REJECT_GROUP & "', 'M' ")
            sb.Append(" ,'" & REJECT_TYPE & "' ,'" & REJECT_GROUP & "', COMP.GPCM_BATCHTYPE ")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI')")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI')")
            sb.Append(" FROM ")
            sb.Append(" GPS_PAYMENT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.GPCM_TRANSREF = '" & transRef & "' ")
            '--sb.Append(" AND COMP.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_PAYMENT_COMPLETE COMP")
            sb.Append(" WHERE COMP.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.GPCM_TRANSREF = '" & transRef & "' ")
            '--sb.Append(" AND COMP.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            'End If
            ' Update 'INCOMPLETE' and 'Hash_err' on Paymet_creation or Payment_load
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_PAYMENT_CREATION T ")
            sb.Append(" SET T.GPCR_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.GPCR_REJECT_TYPE     = 'ACC_CANCEL', ")
            sb.Append("   T.GPCR_REMARK          = '" & Reject_Remark & "' ")
            sb.Append(" WHERE T.GPCR_CREATEDATE  = '" & createDate & "' ")
            sb.Append(" AND T.GPCR_CORE_SYSTEM   = '" & coreSystem & "' ")
            sb.Append(" AND T.GPCR_TRANSREF     = '" & transRef & "' ")
            '--sb.Append(" AND T.GPCR_GPTREF_SEQNO  = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_PAYMENT_LOAD T ")
            sb.Append(" SET T.GPLD_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.GPLD_REJECT_TYPE     = 'ACC_CANCEL' ")
            sb.Append(" WHERE T.GPLD_BATCHDATE  = '" & createDate & "' ")
            sb.Append(" AND T.GPLD_CORE_SYSTEM   = '" & coreSystem & "' ")
            sb.Append(" AND T.GPLD_TRANSREF      = '" & transRef & "' ")
            '--sb.Append(" AND T.GPLD_GPTREF_SEQNO  = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_PAYMENT T ")
            sb.Append(" WHERE T.GP_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.GP_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.GP_TRANSREF = '" & transRef & "' ")
            '--sb.Append(" AND T.GP_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            If count.Equals(i) Then
                Return 1
            Else
                Return 0
            End If

        Catch ex As Exception
            Return 0
        End Try
    End Function

    ' Move Data in GPS_WHT table to GPS_WHT_REJ
    Public Function moveWhtToWhtreject(ByVal oleconn As OleDbConnection _
                                       , ByVal createDate As String _
                                       , ByVal coreSystem As String _
                                       , ByVal transRef As String _
                                       , ByVal gpLine As String _
                                       , ByVal gUser As String _
                                       , Optional ByVal oTrans As OleDbTransaction = Nothing _
                                       , Optional ByVal REJECT_TYPE As String = "" _
                                       , Optional ByVal REJECT_GROUP As String = "" _
                                       , Optional ByVal Reject_Remark As String = "" _
                                       , Optional ByVal ConfirmBatch As Boolean = False)
        ' Create Transaction

        Try
            Dim sb As New StringBuilder
            Dim sysdate As String = Now.ToString("yyyyMMdd")
            Dim i, completeStr, count As Integer
            i = 0
            completeStr = 0
            count = 0
            'MOVE wht complete to wht reject
            sb.Remove(0, sb.Length)
            sb.Append(" INSERT INTO GPS_WHT_REJ REJ (REJ.TAXRJ_BATCHDATE, REJ.TAXRJ_BATCH_NO ,REJ.TAXRJ_CREATEDATE ")
            sb.Append(" ,REJ.TAXRJ_CORE_SYSTEM ,REJ.TAXRJ_TRANSREF ,REJ.TAXRJ_GPTREF_SEQNO ,REJ.TAXRJ_LINENO ")
            sb.Append(" ,REJ.TAXRJ_TAXID ,REJ.TAXRJ_IDCARD ,REJ.TAXRJ_AP_TTL ,REJ.TAXRJ_AP_FNAME ")
            sb.Append(" ,REJ.TAXRJ_AP_LNAME ,REJ.TAXRJ_ADDRESS ,REJ.TAXRJ_AMPENM ,REJ.TAXRJ_PROVNM ")
            sb.Append(" ,REJ.TAXRJ_AGZIP ,REJ.TAXRJ_TAXTYPE ,REJ.TAXRJ_TAXITEM ,REJ.TAXRJ_TAXDATE ")
            sb.Append(" ,REJ.TAXRJ_BASE_AMT ,REJ.TAXRJ_TAX_AMT ,REJ.TAXRJ_PAYEE ,REJ.TAXRJ_TAX_RATE ")
            sb.Append(" ,REJ.TAXRJ_DESC ,REJ.TAXRJ_GL_ACCOUNT ,REJ.TAXRJ_REJECT_TYPE ,REJ.TAXRJ_REJECT_FUNC ")
            sb.Append(" ,REJ.TAXRJ_BATCHTYPE ,REJ.CREATEDBY ,REJ.CREATEDDATE ,REJ.UPDATEDBY ")
            sb.Append(" ,REJ.UPDATEDDATE) ")
            sb.Append(" SELECT ")
            sb.Append(" COMP.TAXCM_BATCHDATE ,COMP.TAXCM_BATCH_NO ,COMP.TAXCM_CREATEDATE ,COMP.TAXCM_CORE_SYSTEM ")
            sb.Append(" ,COMP.TAXCM_TRANSREF ,COMP.TAXCM_GPTREF_SEQNO ,COMP.TAXCM_LINENO ,COMP.TAXCM_TAXID ")
            sb.Append(" ,COMP.TAXCM_IDCARD ,COMP.TAXCM_AP_TTL ,COMP.TAXCM_AP_FNAME ,COMP.TAXCM_AP_LNAME ")
            sb.Append(" ,COMP.TAXCM_ADDRESS ,COMP.TAXCM_AMPENM ,COMP.TAXCM_PROVNM ,COMP.TAXCM_AGZIP ")
            sb.Append(" ,COMP.TAXCM_TAXTYPE ,COMP.TAXCM_TAXITEM ,COMP.TAXCM_TAXDATE ,COMP.TAXCM_BASE_AMT ")
            sb.Append(" ,COMP.TAXCM_TAX_AMT ,COMP.TAXCM_PAYEE ,COMP.TAXCM_TAX_RATE ")

            If ConfirmBatch Then
                sb.Append(" , SUBSTR('WHTNO:'||(SELECT NVL(GPS_WHT.TAX_WHTNO, '-') FROM GENERATEPAYMENT.GPS_WHT WHERE GPS_WHT.TAX_CREATEDATE = COMP.TAXCM_CREATEDATE AND GPS_WHT.TAX_CORE_SYSTEM = COMP.TAXCM_CORE_SYSTEM AND GPS_WHT.TAX_TRANSREF = COMP.TAXCM_TRANSREF AND GPS_WHT.TAX_LINENO = COMP.TAXCM_LINENO) || ',' || COMP.TAXCM_DESC, 1, 30)")
            Else
                sb.Append(" , COMP.TAXCM_DESC ")
            End If

            sb.Append(" ,COMP.TAXCM_GL_ACCOUNT, '" & REJECT_TYPE & "' ,'" & REJECT_GROUP & "', COMP.TAXCM_BATCHTYPE ")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" ,'" & gUser & "' ")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" FROM GPS_WHT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.TAXCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.TAXCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.TAXCM_TRANSREF = '" & transRef & "' ")
            '--sb.Append(" AND COMP.TAXCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_WHT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.TAXCM_CREATEDATE = '" & createDate & "'  ")
            sb.Append(" AND COMP.TAXCM_CORE_SYSTEM = '" & coreSystem & "'  ")
            sb.Append(" AND COMP.TAXCM_TRANSREF = '" & transRef & "'  ")
            '--sb.Append(" AND COMP.TAXCM_GPTREF_SEQNO = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            ' Update 'INCOMPLETE' and 'Hash_err' on WHT_creation or WHT_load
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_WHT_CREATION T ")
            sb.Append(" SET T.TAXCR_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.TAXCR_REJECT_TYPE    = 'ACC_CANCEL', ")
            sb.Append("   T.TAXCR_REMARK    = '" & Reject_Remark & "' ")
            sb.Append(" WHERE T.TAXCR_CREATEDATE  = '" & createDate & "'  ")
            sb.Append(" AND T.TAXCR_CORE_SYSTEM   = '" & coreSystem & "'  ")
            sb.Append(" AND T.TAXCR_TRANSREF     = '" & transRef & "'  ")
            '--sb.Append(" AND T.TAXCR_GPTREF_SEQNO  = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_WHT_LOAD T ")
            sb.Append(" SET T.TAXLD_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("  T.TAXLD_REJECT_TYPE    = 'ACC_CANCEL' ")
            sb.Append(" WHERE T.TAXLD_BATCHDATE  = '" & createDate & "'  ")
            sb.Append(" AND T.TAXLD_CORE_SYSTEM   = '" & coreSystem & "'  ")
            sb.Append(" AND T.TAXLD_TRANSREF     = '" & transRef & "'  ")
            '--sb.Append(" AND T.TAXLD_GPTREF_SEQNO  = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If


            'Delete wht by key fied
            sb.Remove(0, sb.Length)
            sb.Append(" DELETE FROM GPS_WHT T ")
            sb.Append(" WHERE T.TAX_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.TAX_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.TAX_TRANSREF = '" & transRef & "' ")
            '--sb.Append(" AND T.TAX_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            If count.Equals(i) Then
                Return 1
            Else
                Return 0
            End If
        Catch ex As Exception
            Return -1
        End Try
    End Function

    ' Update Flag on GPS_PAYMENT for Re-Gen S1 file
    Public Function updatePaymentByConfirmdate(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("UPDATE GPS_PAYMENT T ")
        sb.Append("SET T.GP_FLAG_EXPTOBANK  = 'N', ")
        sb.Append("  T.GP_EXPTOBANK_DATE    = '', ")
        sb.Append("  T.GP_EXPTOBANK_FILENME = '', ")
        sb.Append("  T.GP_EXPTOBANK_SEQNO   = '', ")
        sb.Append("  T.GP_CUSTREFNO         = '' ")
        sb.Append("WHERE T.GP_CONFIRMDATE   = '" & confirmdate & "'")
        sb.Append(" AND T.GP_FLAG_EXPTOBANK  = 'Y' ")
        sb.Append(" AND T.GP_TRANSREF || TO_CHAR(T.GP_GPTREF_SEQNO) IN ( SELECT C.GPCM_TRANSREF || TO_CHAR(C.GPCM_GPTREF_SEQNO) ")
        sb.Append("                                                        FROM GENERATEPAYMENT.GPS_PAYMENT_COMPLETE C ")
        sb.Append("                                                       WHERE C.GPCM_BATCH_NO = '" & batchno & "') ")

        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    ' Romeve data from GPS_GENPAYMENTFILE_LOG table
    Public Function deleteGenpaymentFilelog(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_GENPAYMENTFILE_LOG T")
        sb.Append(" WHERE T.GFLOG_EXPTOBANK_DATE = '" & confirmdate & "' ")
        If batchno.Trim <> "" Then sb.Append(" AND T.GFLOG_BATCH_NO = '" & batchno & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Function CALL_GPS_SP_GET_RejectHash(ByVal oleConn As OleDbConnection, ByVal pBatchDate As String, ByVal pBatchno As String, ByVal user As String, Optional ByVal oTrans As OleDbTransaction = Nothing)

        Dim dbComm As OleDbCommand

        Dim sysdate As String = Now.ToString("yyyyMMdd")
        'p_Batch_Date IN VARCHAR2,
        '--- วันที่รับ Batch  รูปแบบ   YYYYMMDD
        'p_Batch_no IN VARCHAR2,
        '--- เลขที่ Batch
        'p_user IN VARCHAR2 ,
        'result_return OUT VARCHAR2,
        'result_msg OUT VARCHAR2
        dbComm = oleConn.CreateCommand
        dbComm.Parameters.Add("p_Batch_Date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_Date").Value = pBatchDate
        dbComm.Parameters.Add("p_Batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_no").Value = pBatchno
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.Transaction = oTrans
        dbComm.CommandText = "GPS_SP_GET_RejectHash"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()


        If dbComm.Parameters("result_return").Value = True Then
            Return True
        Else
            Return False
        End If
    End Function

    Function CallGL_REJ_PARTIAL_ACC(ByVal oleConn As OleDbConnection, ByVal batchdate As String, ByVal batchno As String, ByVal TRANSREF As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP_2.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("p_TransRef", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_TransRef").Value = TRANSREF ' "pattamalin"

        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectpartial_acc"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        'Return dbComm.Parameters("result_msg").Value

        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Function CallGL_REJ_ALL_ACC(ByVal oleConn As OleDbConnection, ByVal batchdate As String, ByVal batchno As String, ByVal TRANSREF As String, ByVal user As String) As Boolean
        Dim dbComm As OleDbCommand

        dbComm = clsUtility.gConnGP_2.CreateCommand

        dbComm.Parameters.Add("p_batch_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_date").Value = batchdate ' "20140926"
        dbComm.Parameters.Add("p_batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_batch_no").Value = batchno ' "GP20140926001"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user ' "pattamalin"
        dbComm.Parameters.Add("p_TransRef", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_TransRef").Value = TRANSREF ' "pattamalin"

        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.CommandText = "gps_sp_get_rejectall_acc"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()

        '--Dim x As String = dbComm.Parameters("result_msg").Value
        Return dbComm.Parameters("result_return").Value

        'MessageBox.Show(dbComm.Parameters("result_return").Value)
        'MessageBox.Show(dbComm.Parameters("result_msg").Value)
    End Function

    Public Function DeletePayment(ByVal oleconn As OleDbConnection, ByVal strJournalHold As String, ByVal strTransactionReference As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_PAYMENT_CREATION  T")
        sb.Append(" WHERE T.GPCR_CORE_SYSTEM = 'ACC' AND T.GPCR_TRANSREF = '" & strTransactionReference & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function DeleteWHT(ByVal oleconn As OleDbConnection, ByVal strJournalHold As String, ByVal strTransactionReference As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_WHT_CREATION  T")
        sb.Append(" WHERE T.TAXCR_CORE_SYSTEM = 'ACC' AND T.TAXCR_TRANSREF = '" & strTransactionReference & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function DeleteGL(ByVal oleconn As OleDbConnection, ByVal strJournalHold As String, ByVal strTransactionReference As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_GL_CREATION  T")
        sb.Append(" WHERE T.GLCR_CORE_SYSTEM = 'ACC' AND T.GLCR_TRANSREF = '" & strTransactionReference & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function DeleteTransRef(ByVal oleconn As OleDbConnection, ByVal strJournalHold As String, ByVal strTransactionReference As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_TRANSREF_REL  T")
        sb.Append(" WHERE T.TREF_CORE_SYSTEM = 'ACC' AND T.TREF_TRANSREF = '" & strTransactionReference & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function UpdateJournalNo(ByRef oleConn As OleDbConnection, ByVal int_function As String, ByVal int_status As String, ByVal GL_JN_NO As String, Optional ByVal oTrans As OleDbTransaction = Nothing)

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GLM_INTERFACE_CONTROL t SET t.int_gl_no = '" & GL_JN_NO & "', t.updatedby = '" & gUserLogin & "', t.updateddate = to_char(sysdate, 'yyyyMMdd') WHERE t.INT_FUNCTION = '" & int_function & "' and t.int_status = '" & int_status & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oTrans)

        If rec <= 0 Then
            Return rec
        Else
            Return 1
        End If

    End Function

    Public Function UpdateVCHNo(ByRef oleConn As OleDbConnection, ByVal int_function As String, ByVal int_status As String, ByVal GL_VCH_NO As String, Optional ByVal oTrans As OleDbTransaction = Nothing)

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GLM_VOUCHER_NO t SET t.vch_no = '" & GL_VCH_NO & "', t.updatedby = '" & gUserLogin & "', t.updateddate = to_char(sysdate, 'yyyyMMdd') WHERE t.vch_jn_type = '" & int_function & "'")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oTrans)

        If rec <= 0 Then
            Return rec
        Else
            Return 1
        End If

    End Function

    Public Function GetJournalNo(ByRef oleConn As OleDbConnection, ByVal int_function As String, ByVal int_status As String, Optional ByVal oTrans As OleDbTransaction = Nothing) As String
        Dim sb As New StringBuilder
        Try
            sb.Append("Select t.int_gl_no ")
            sb.Append("from GLM_INTERFACE_CONTROL t WHERE 1=1 ")

            If int_function <> "" Then
                sb.Append("and t.int_function = '" & int_function & "' ")
            End If
            If int_status <> "" Then
                sb.Append("and t.int_status = '" & int_status & "' ")
            End If

            Dim dt As DataTable
            Dim intStatus As Boolean = True
            Dim pJNNO As Integer
            Dim intLoop As Integer = 1

            While intStatus
                dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    Me.SetJournalNoStatus(oleConn, int_function, "START", oTrans)

                    Dim current_date As Date
                    current_date = Now.ToString(New CultureInfo("en-GB"))
                    If dt.Rows(0)(0).ToString.Substring(0, 2) <> current_date.ToString("yy") Then
                        MsgBox("ค่าของ Journal No. ไม่ถูกต้อง")
                        Return Nothing
                    End If

                    pJNNO = Convert.ToInt32(dt.Rows(0)(0))
                    Return pJNNO

                Else
                    System.Threading.Thread.Sleep(10000)
                    If intLoop = 2 Then
                        Return ""
                    Else
                        intLoop += 1
                    End If
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return Nothing

        End Try

        Return Nothing

    End Function

    Public Function GetVoucherNo(ByRef oleConn As OleDbConnection, ByVal vchjnType As String) As String
        Dim sb As New StringBuilder
        Try
            sb.Append("Select t.vch_no ")
            sb.Append("from GLM_VOUCHER_NO t WHERE 1=1 ")

            If vchjnType <> "" Then
                sb.Append("and t.vch_jn_type = '" & vchjnType & "' ")
            End If

            Dim dt As DataTable
            Dim intStatus As Boolean = True
            Dim pVCHNO As Integer

            dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 AndAlso vchjnType.Trim <> "" Then
                pVCHNO = Convert.ToInt32(dt.Rows(0)(0))
                Return pVCHNO
            Else
                Throw New Exception("ไม่พบข้อมูล VoucherNo")
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return Nothing
        End Try

        Return Nothing
    End Function

    Private Function SetJournalNoStatus(ByRef oleConn As OleDbConnection, ByVal int_function As String, ByVal status As String, Optional ByVal oTrans As OleDbTransaction = Nothing)
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GLM_INTERFACE_CONTROL t SET t.int_status = '" & status & "' WHERE t.INT_FUNCTION = '" & int_function & "'")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oTrans)

        If rec <= 0 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Private Function CheckJournalStatus(ByVal oleconn As OleDbConnection, Optional ByVal oTrans As OleDbTransaction = Nothing)
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("Select int_status")
        sb.Append("        from(glm_interface_control)")
        sb.Append(" where glm_interface_control.int_function = 'JN_NO'")

        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)

        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If


    End Function

    Private Function ReverseNonPayAfterPost(ByVal oleconn As OleDbConnection, ByVal strJournalHold As String, ByVal strTransactionReference As String, ByVal strPostDate As String, ByVal strJournalNew As String, ByVal strVoucherNew As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("insert into glm_gl_daily")
        sb.Append("  ( gl_posting_date, gl_system_name, gl_jn_type, gl_jn_source, gl_b_unit, gl_period, gl_jn_no, gl_vch_no, gl_transref")
        sb.Append("  , gl_s_account, gl_lineno, gl_glsts, gl_bookid, gl_source_nme, gl_category_nme, gl_currency_cde, gl_actual_flag")
        sb.Append("  , gl_company_cde, gl_rccode, gl_transdate, gl_duedate, gl_desc, gl_amount, gl_drcr, gl_s_dep_brn, gl_s_pl_pt")
        sb.Append("  , gl_s_mkt_emp, gl_s_tt_tr, gl_s_project, createdby, createddate, updatedby, updateddate, gl_function, gl_o_post_flag ) ")
        sb.Append("select '" & strPostDate & "' gl_posting_date, gl_system_name, '" & strVoucherNew.Substring(0, 2) & "', gl_jn_source, gl_b_unit, gl_period, '" & strJournalNew & "' gl_jn_no, '" & strVoucherNew & "' gl_vch_no, gl_transref")
        sb.Append("     , gl_s_account, gl_lineno, gl_glsts, gl_bookid, gl_source_nme, gl_category_nme, gl_currency_cde, gl_actual_flag")
        sb.Append("     , gl_company_cde, gl_rccode, gl_transdate, gl_duedate, gl_desc, gl_amount, case gl_drcr when 'D' then 'C' else 'D' end gl_drcr")
        sb.Append("     , gl_s_dep_brn, gl_s_pl_pt, gl_s_mkt_emp, gl_s_tt_tr, gl_s_project")
        sb.Append("     , '" & gUserLogin & "' createdby, to_char(sysdate, 'yyyyMMdd') createddate, '" & gUserLogin & "' updatedby, to_char(sysdate, 'yyyyMMdd') updateddate")
        sb.Append("     , 'GP07' gl_function, gl_o_post_flag ")
        sb.Append("        from(glm_gl_daily)")
        '--sb.Append(" where glm_gl_daily.gl_posting_date = '" & strPostDate & "'")
        sb.Append(" where 1=1")
        sb.Append("   and glm_gl_daily.gl_transref = '" & strTransactionReference & "'")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)

        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If

    End Function

    Private Function ReverseGLAfterPostByJournalType(ByVal oleconn As OleDbConnection _
                                        , ByVal strJournalType As String _
                                        , ByVal strJournalHold As String _
                                        , ByVal strTransactionReference As String _
                                        , ByVal strPostDate As String _
                                        , ByVal strJournalNew As String _
                                        , ByVal strVoucherNew As String _
                                        , Optional ByVal oTrans As OleDbTransaction = Nothing _
                                        , Optional ByVal batchno As String = "")

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("insert into glm_gl_daily")
        sb.Append("  ( gl_posting_date, gl_system_name, gl_jn_type, gl_jn_source, gl_b_unit, gl_period, gl_jn_no, gl_vch_no, gl_transref")
        sb.Append("  , gl_s_account, gl_lineno, gl_glsts, gl_bookid, gl_source_nme, gl_category_nme, gl_currency_cde, gl_actual_flag")
        sb.Append("  , gl_company_cde, gl_rccode, gl_transdate, gl_duedate, gl_desc, gl_amount, gl_drcr, gl_s_dep_brn, gl_s_pl_pt")
        sb.Append("  , gl_s_mkt_emp, gl_s_tt_tr, gl_s_project, createdby, createddate, updatedby, updateddate, gl_function, gl_o_post_flag ) ")
        sb.Append("select '" & strPostDate & "' gl_posting_date, gl_system_name, '" & strVoucherNew.Substring(0, 2) & "' gl_jn_type, gl_jn_source, gl_b_unit, gl_period, '" & strJournalNew & "' gl_jn_no, '" & strVoucherNew & "' gl_vch_no, gl_transref")
        sb.Append("     , gl_s_account, gl_lineno, gl_glsts, gl_bookid, gl_source_nme, gl_category_nme, gl_currency_cde, gl_actual_flag")
        sb.Append("     , gl_company_cde, gl_rccode, gl_transdate, gl_duedate, gl_desc, gl_amount, case gl_drcr when 'D' then 'C' else 'D' end gl_drcr")
        sb.Append("     , gl_s_dep_brn, gl_s_pl_pt, gl_s_mkt_emp, gl_s_tt_tr, gl_s_project")
        sb.Append("     , '" & gUserLogin & "' createdby, to_char(sysdate, 'yyyyMMdd') createddate, '" & gUserLogin & "' updatedby, to_char(sysdate, 'yyyyMMdd') updateddate")
        sb.Append("     , 'GP07' gl_function, gl_o_post_flag ")
        sb.Append("        from(glm_gl_daily)")
        '-- sb.Append(" where glm_gl_daily.gl_posting_date = '" & strPostDate & "'")
        sb.Append(" where glm_gl_daily.gl_transref = '" & strTransactionReference & "'")
        sb.Append("   and glm_gl_daily.gl_jn_type = '" & strJournalType & "'")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)

        If rec <= 0 Then
            Return rec
        Else
            Return 1
        End If

    End Function

    Private Sub txtRemark_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtRemark.KeyDown
        If e.KeyCode = Keys.Enter Then
            txtJnTo.Text = txtJnFrom.Text.Trim
            AutoBindData()
        End If
    End Sub
End Class