Imports System.IO
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmPrintCHQOtherBankProcess
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private Sub FrmPrintChequeOtherToSCB_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        txtPayeeName.Text = "����ѷ �Ϳ�Ѻ���Ǵ� ��Сѹ���Ե �ӡѴ (��Ҫ�)"
        txtPaymentDate.Text = Now.ToString("dd/MM/yyyy")
        BindBank()
    End Sub
    Private Sub BindBank()

        Dim dt As DataTable
        dt = clsBusiness.GetBankForPrtCheque(clsUtility.gConnGP)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!BKMST_BNKNAME = 0
            dr!BKMST_BNKCODE = "Select"
            dt.Rows.InsertAt(dr, 0)
            With cboBankCode
                .DataSource = dt
                .DisplayMember = "BKMST_BNKCODE"
                .ValueMember = "BKMST_BNKNAME"
            End With
        End If
        cboBankCode.SelectedIndex = 0
    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click

        If cboBankCode.SelectedIndex = 0 Then
            MsgBox("Please select Bank")
            Exit Sub
        End If

        If txtChequeNo.Text.Trim = "" Then
            MsgBox("Please enter Cheque No")
            txtChequeNo.Focus()
            Exit Sub
        End If

        If txtPayeeName.Text.Trim = "" Then
            MsgBox("Please enter Payee Name")
            txtPayeeName.Focus()
            Exit Sub
        End If

        If txtAmount.Text.Trim = "" Then
            MsgBox("Please enter Amount")
            txtAmount.Focus()
            Exit Sub
        End If

        If txtPaymentDate.Text.Trim = "" Then
            MsgBox("Please enter Pament Date")
            txtPaymentDate.Focus()
            Exit Sub
        Else
            Dim dateString As String = txtPaymentDate.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

            Else
                MsgBox("Date format is not valid")

                txtPaymentDate.Focus()
                Exit Sub
            End If
        End If

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        If InsertData(oleTrans) Then
            oleTrans.Commit()
            'MsgBox("Print Cheque Successfully")
            PrintReport()
        Else
            oleTrans.Rollback()
            MsgBox("Can not Print Cheque!")
        End If

    End Sub
    Function InsertData(ByVal oleTrans As OleDbTransaction) As Boolean
        Dim table As New DataTable
        table.Columns.Add("PCHQ_BNKCODE")
        table.Columns.Add("PCHQ_CHQNO")
        table.Columns.Add("PCHQ_PAYEE_NAME")
        table.Columns.Add("PCHQ_AMOUNT")
        table.Columns.Add("PCHQ_PAIDDATE")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        Dim row As DataRow
        row = table.NewRow()

        Dim paiddate As String
        paiddate = txtPaymentDate.Text.Substring(6, 4) & txtPaymentDate.Text.Substring(3, 2) & txtPaymentDate.Text.Substring(0, 2)

        row("PCHQ_BNKCODE") = cboBankCode.Text.Trim
        row("PCHQ_CHQNO") = txtChequeNo.Text.Trim
        row("PCHQ_PAYEE_NAME") = txtPayeeName.Text.Trim
        row("PCHQ_AMOUNT") = Convert.ToDouble(txtAmount.Text.Trim)
        row("PCHQ_PAIDDATE") = paiddate
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim rec As Double
        rec = clsBusiness.INS_GPS_PRNCHQ_OTHBNK(clsUtility.gConnGP, oleTrans, row)

        If rec > 0 Then
            Return True 
        Else
            Return False
        End If
    End Function
    Private Sub PrintReport()

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        Dim reportname As String
        reportname = "RptCheque_" & cboBankCode.Text.Trim & ".rpt"

        frm1.CrDoc.Load(sReportPath & reportname)

        Dim dt As DataTable = New DataTable()

        dt = clsBusiness.GetRptPrtCheque(clsUtility.gConnGP, cboBankCode.Text.Trim, txtChequeNo.Text.Trim)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            'Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            'Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            'Dim param1 As New CrystalDecisions.Shared.ParameterField()
            'Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            'Dim param2 As New CrystalDecisions.Shared.ParameterField()
            'Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            'Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            'param1.ParameterFieldName = "pHeader"
            'discrete1.Value = "��§ҹ��ػ��è��»�Ш��ѹ (��ǹ�ѭ��)(��觴�ǹ)"
            'param1.CurrentValues.Add(discrete1)
            'paramFields.Add(param1)

            'param2.ParameterFieldName = "pTransdate"
            'discrete2.Value = Now.ToString("ddMMyyyy")
            'param2.CurrentValues.Add(discrete2)
            'paramFields.Add(param2)

            'paramUser.ParameterFieldName = "pUser"
            'discreteUser.Value = gUserFullName
            'paramUser.CurrentValues.Add(discreteUser)
            'paramFields.Add(paramUser)

            'frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        End If
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
    Private Sub cboBankCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBankCode.SelectedIndexChanged
        If cboBankCode.SelectedIndex <> 0 Then
            txtBankName.Text = cboBankCode.SelectedValue.ToString
        Else
            txtBankName.Text = ""
        End If

    End Sub

    Private Sub txtAmount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAmount.KeyPress
        If e.KeyChar = "."c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("."c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub
    Private Sub txtPaymentDate_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtPaymentDate.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtPaymentDate.Text.Trim = "" Then

            Else
                Dim dateString As String = txtPaymentDate.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")
                   
                    txtPaymentDate.Focus()
                End If
            End If

        End If
    End Sub

   
End Class