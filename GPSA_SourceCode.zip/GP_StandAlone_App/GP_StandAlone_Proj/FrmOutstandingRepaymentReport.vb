﻿Imports System.Text
Imports System.IO
Imports System.Data.OleDb
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmOutstandingRepaymentReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsOutstandingRepayment
    Dim clsHashLo As New ClsHashTotalErrorLOCancel
    Dim timework As Integer = 1
    '' ''#Region "BackgroundWorker"
    '' ''    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
    '' ''        My.Application.ChangeCulture("en-GB")
    '' ''        'Run_Process()
    '' ''        Run_Report()
    '' ''        Dim i As Integer
    '' ''        For i = 0 To timework Step +1

    '' ''            'ถ้ามีการสั่ง Cancel ให้หยุดทันที
    '' ''            If BackgroundWorker1.CancellationPending = True Then
    '' ''                e.Cancel = True
    '' ''                Exit For
    '' ''            Else
    '' ''                'รายงานว่ามี prgress เพิ่ม 1 progress
    '' ''                BackgroundWorker1.ReportProgress(i)
    '' ''                System.Threading.Thread.Sleep(timework)
    '' ''            End If
    '' ''        Next



    '' ''    End Sub
    '' ''    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
    '' ''        ''เพิ่ม 1 progress      
    '' ''        'ProgressBar1.Value = e.ProgressPercentage
    '' ''        'lblprogress.Text = "processing... " & e.ProgressPercentage & " %"

    '' ''    End Sub
    '' ''    Private Sub StopWorker()
    '' ''        If BackgroundWorker1.WorkerSupportsCancellation = True Then
    '' ''            'สั่งให้ BackgroundWorker หยุดทำงาน
    '' ''            BackgroundWorker1.CancelAsync()
    '' ''        End If
    '' ''    End Sub
    '' ''    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
    '' ''        'MsgBox("Complete")
    '' ''        'btnConfirm.Enabled = False
    '' ''        'Me.Dispose()
    '' ''        'Cursor = Cursors.Default


    '' ''        'Run_Report()
    '' ''        Me.Close()

    '' ''    End Sub

    '' ''#End Region
    Private Sub FrmRptEDO_Reprint_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")

        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ComboReportType.Items.Add("GPS")
        ComboReportType.Items.Add("IL")
        ComboReportType.SelectedIndex = 0

        dtpEntryDate.Value = Now.ToString("dd/MM/yyyy")
        dtpEntryDateTo.Value = Now.ToString("dd/MM/yyyy")

    End Sub

    Private Sub PrintReportOutStandingRepayment(ByVal dt As DataTable)

        Dim frm1 As New FrmRptViewer
        Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param1 As New CrystalDecisions.Shared.ParameterField()
        Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param2 As New CrystalDecisions.Shared.ParameterField()
        Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RPTOutstandingRepayment.rpt")

        frm1.FillDataTableToReport(dt)

        param1.ParameterFieldName = "pTransdate"
        discrete1.Value = dtpEntryDate.Value.ToString("dd/MM/yyyy")
        param1.CurrentValues.Add(discrete1)
        paramFields.Add(param1)

        param2.ParameterFieldName = "pTransDateTo"
        discrete2.Value = dtpEntryDateTo.Value.ToString("dd/MM/yyyy")
        param2.CurrentValues.Add(discrete2)
        paramFields.Add(param2)

        paramUser.ParameterFieldName = "pUser"
        discreteUser.Value = gUserFullName
        paramUser.CurrentValues.Add(discreteUser)
        paramFields.Add(paramUser)

        frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

        Me.Close()


    End Sub

    Private Sub GenerateReport(ByVal dt As DataTable)

        PrintReportOutStandingRepayment(dt)


    End Sub

    Private Sub Run_Process()
        'Dim dt As New DataTable
        'dt = cls.GetBatchNoByExpDate(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"))

        'GenerateTextFile(dt)
    End Sub
    Private Sub Run_Report()

        Dim dt As New DataTable
        Me.Cursor = Cursors.WaitCursor
        dt = cls.GetDataForReport(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"), dtpEntryDateTo.Value.ToString("yyyyMMdd"))

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            GenerateReport(dt)
        Else
            MsgBox("Data not found!" & vbCrLf & cls.gLastErrorMessage, MsgBoxStyle.Exclamation, "Warning Message")
        End If

        Me.Cursor = Cursors.Default

    End Sub
    Private Sub CmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPreview.Click

        'Dim dt As New DataTable
        'dt = cls.GetBatchNoByExpDate(clsUtility.gConnGP, dtpEntryDate.Value.ToString("yyyyMMdd"))
        'If IsNothing(dt) Then
        '    MsgBox("Not found data for Re-Print")
        '    Exit Sub
        'End If

        'Run_Report()
        'Try
        '    timework = timework * 100
        '    Dim progress As New frmProgress(Me.BackgroundWorker1)
        '    progress.ShowDialog()

        'Catch ex As Exception
        '    MsgBox("Process Error!")
        'End Try
        Run_Report()

    End Sub

    Private Sub PrintReportLO(ByVal dt As DataTable, ByVal fn As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        If fn = "MNG" Then
            frm1.CrDoc.Load(sReportPath & "report_mng.rpt")
        ElseIf fn = "SUM" Then
            frm1.CrDoc.Load(sReportPath & "report_sum.rpt")
        End If

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        Else
            MsgBox("No Data", MsgBoxStyle.Information)
        End If

    End Sub

End Class