Imports UtilityClassLibrary
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class FrmUpdateInstrumentNo
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsUpdateInstrument
    Dim dataTableIns As DataTable
    Dim Extension As String
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub FrmUpdateInstrument_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        ListPaymentType()

        btnSave.Enabled = False
        btnUpdate.Enabled = False
        lblFileName.Text = ""

    End Sub
    Private Sub ListPaymentType()
        Dim dt As New DataTable
        dt = cls.GetPaymentType(clsUtility.gConnGP)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!id = 0
            dr!name = "ALL"
            dt.Rows.InsertAt(dr, 0)

            With cboPaymentType
                .DataSource = dt
                .DisplayMember = "name"
                .ValueMember = "id"
            End With

        End If
    End Sub
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        btnUpdate.BackColor = Color.FromArgb(255, 235, 220)
        btnUpdate.Height = 25
        btnUpdate.Enabled = False
        btnSave.BackColor = Color.FromArgb(255, 235, 220)
        btnSave.Height = 25
        btnSave.Enabled = False
    End Sub
    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        If txtChequeNo.Text.Trim = "" Then
            MsgBox("Please Enter Company Cheque")
            Exit Sub
        End If

        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            .Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.csv;*.xls;*.xlsx)|*.csv;*.xls;*.xlsx"
            .FilterIndex = 0
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURL.Text = OpenFileDialog1.FileName
                Extension = System.IO.Path.GetExtension(OpenFileDialog1.FileName)
                lblFileName.Text = System.IO.Path.GetFileName(OpenFileDialog1.FileName)
                If CheckFormatExcel(txtTextURL.Text) = False Then
                    MsgBox(clsBusiness.gLastErrMessage, MsgBoxStyle.Information)
                    Exit Sub
                Else

                    Dim dt As New DataTable
                    Dim chk_chqno As Boolean

                    'read row to datatable
                    dt = readExcel(txtTextURL.Text)
                    If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                        chk_chqno = Validate_CompanyCHQ(dt)
                        If chk_chqno Then
                            Dim dt_validate As New DataTable
                            dt_validate = cls.GetDataForValidate(clsUtility.gConnGP, txtChequeNo.Text.Trim)
                            If Not IsNothing(dt_validate) AndAlso dt_validate.Rows.Count > 0 Then
                                Dim chk_rec, chk_amt As Boolean
                                chk_rec = Validate_TotalReccord(dt, dt_validate.Rows(0)("REC"))
                                If chk_rec Then
                                    chk_amt = Validate_Amount(dt, dt_validate.Rows(0)("AMT"))
                                    If chk_amt Then
                                        Dim chk_instrumentno As Boolean
                                        chk_instrumentno = Validate_InstrumentNo(dt)
                                        If chk_instrumentno Then
                                            Dim chk_status As Boolean
                                            chk_status = cls.ChkStatus(clsUtility.gConnGP, txtChequeNo.Text.Trim)
                                            If chk_status Then
                                                txtChequeNo.Enabled = False

                                                GetDataToGrid(dt)

                                                Dim chk_find As Boolean
                                                chk_find = cls.ChkFindData(clsUtility.gConnGP, txtChequeNo.Text.Trim)
                                                If chk_find Then

                                                    btnUpdate.Enabled = True
                                                    btnSave.Enabled = False
                                                Else

                                                    btnSave.Enabled = True
                                                    btnUpdate.Enabled = False
                                                End If

                                            Else
                                                MsgBox("Status not valid")
                                            End If

                                        Else
                                            MsgBox("��سҡ�͡�Ţ Instrument No ���ú��ǹ")
                                        End If
                                    Else
                                        MsgBox("�ʹ�Թ�����ҡѺ�������к� ��سҵ�Ǩ�ͺ")
                                    End If
                                Else
                                    MsgBox("�ӹǹ��¡�������ҡѺ�������к� ��سҵ�Ǩ�ͺ")
                                End If
                            End If
                        Else
                            MsgBox("�Ţ��� Company Cheque � File Excel ���ç�Ѻ˹�Ҩ� ��سҵ�Ǩ�ͺ")
                            Exit Sub
                        End If

                    End If


                End If


            End If
        End If
    End Sub
    Private Function readExcel(ByVal txtExcelURL As String) As DataTable
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application

        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            dataTableIns = New DataTable

            dataTableIns.Columns.Add("No")
            dataTableIns.Columns.Add("Description")
            dataTableIns.Columns.Add("Branch_Name")
            dataTableIns.Columns.Add("Company_Cheque_No")
            dataTableIns.Columns.Add("Payment_Date")
            dataTableIns.Columns.Add("Amount", Type.GetType("System.Double"))
            dataTableIns.Columns.Add("Fee")
            dataTableIns.Columns.Add("Remark")
            dataTableIns.Columns.Add("Instrument_No")
            dataTableIns.Columns.Add("Ref_No")

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"


            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
                rowNew = dataTableIns.NewRow
                firstColumnIsNothing = False
                If myvalues(rowIndex, 1) Is Nothing Then
                    firstColumnIsNothing = True
                    Exit For
                End If
                For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
                    'If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                    '    firstColumnIsNothing = True
                    '    Exit For
                    If myvalues(rowIndex, columnIndex) Is Nothing Then
                        rowNew.Item(columnIndex - 1) = ""
                    Else
                        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                    End If
                Next
                If firstColumnIsNothing = False Then
                    dataTableIns.Rows.Add(rowNew)
                End If
            Next
            dataTableIns.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableIns
    End Function
    Private Function CheckFormatExcel(ByVal txtExcelURL As String) As Boolean
        Dim ret As Boolean = False
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            dataTableIns = New DataTable

            dataTableIns.Columns.Add("No")
            dataTableIns.Columns.Add("Description")
            dataTableIns.Columns.Add("Branch Name")
            dataTableIns.Columns.Add("Company Cheque No")
            dataTableIns.Columns.Add("Payment Date")
            dataTableIns.Columns.Add("Amount")
            dataTableIns.Columns.Add("Fee")
            dataTableIns.Columns.Add("Information IT[Key Field]")
            dataTableIns.Columns.Add("Instrument No")
            dataTableIns.Columns.Add("Ref No.")

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            'For rowIndex As Integer = 1 To oSheet.UsedRange.Rows.Count()
            Dim rowIndex As Integer = 1

            rowNew = dataTableIns.NewRow
            firstColumnIsNothing = False
            For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
                'If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                '    firstColumnIsNothing = True
                '    Exit For
                'ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                '    rowNew.Item(columnIndex - 1) = ""
                'Else
                '    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                'End If
                If myvalues(rowIndex, columnIndex) Is Nothing Then
                    Exit For
                Else
                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                End If
            Next
            If firstColumnIsNothing = False Then
                dataTableIns.Rows.Add(rowNew)
            End If

            dataTableIns.AcceptChanges()
            If dataTableIns.Rows.Count > 0 Then
                For Each row As DataRow In dataTableIns.Rows
                    For i As Integer = 0 To dataTableIns.Columns.Count - 1
                        Dim cname, rname As String
                        cname = dataTableIns.Columns(i).ColumnName()
                        rname = row.Item(i)
                        If cname.ToUpper = rname.ToUpper Then
                            ret = True
                        Else
                            ret = False
                            clsBusiness.gLastErrMessage = "Column name : " & rname & " is not valid"
                            Exit Function
                        End If
                    Next
                Next
            End If
            ret = True
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            .ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "No"
            .Name = "No"
            .ReadOnly = True
            .Width = 50
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "Description"
            .Name = "Description"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c2)
        End With

        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "Branch_Name"
            .Name = "Branch Name"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c3)
        End With

        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "Company_Cheque_No"
            .Name = "Company Cheque No"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c4)
        End With

        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "Payment_Date"
            .Name = "Payment Date"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c5)
        End With

        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "Amount"
            .Name = "Amount"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c6)
        End With

        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "Fee"
            .Name = "Fee"
            .ReadOnly = True
            .Width = 50
            DataGridView1.Columns.Add(c7)
        End With

        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .DataPropertyName = "Remark"
            .Name = "Information IT[Key Field]"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c8)
        End With

        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .DataPropertyName = "Instrument_No"
            .Name = "Instrument No"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c9)
        End With

        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .DataPropertyName = "Ref_No"
            .Name = "Ref No"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c10)
        End With


        'DataGridView1.RowHeadersWidth = 50
        'AutoNumberRowsForGridView(DataGridView1)

        'DataGridView Header Style
        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(5).DefaultCellStyle.Format = "###,###.00" 'AMOUNT
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Function Validate_CompanyCHQ(ByVal dt As DataTable) As Boolean
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim ret As Boolean
            For Each dr As DataRow In dt.Rows
                If dr("Company_Cheque_No") <> txtChequeNo.Text.Trim Then
                    ret = False
                    Exit For
                Else
                    ret = True
                End If
            Next
            Return ret
        End If

    End Function
    Function Validate_TotalReccord(ByVal dt As DataTable, ByVal rec As Integer) As Boolean
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim ret As Boolean

            If dt.Rows.Count <> rec Then
                ret = False
            Else
                ret = True
            End If

            Return ret
        End If
    End Function
    Function Validate_Amount(ByVal dt As DataTable, ByVal amt As Decimal) As Boolean
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim ret As Boolean
            Dim cAmt As Decimal
            For Each dr As DataRow In dt.Rows

                cAmt = cAmt + Convert.ToDecimal(dr("Amount"))

            Next

            If cAmt <> amt Then
                ret = False
            Else
                ret = True
            End If

            Return ret
        End If
    End Function
    Function Validate_InstrumentNo(ByVal dt As DataTable) As Boolean
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim ret As Boolean
            For Each dr As DataRow In dt.Rows
                If dr("Instrument_No") = "" Then
                    ret = False
                    Exit For
                Else
                    ret = True
                End If
            Next
            Return ret
        End If
    End Function
    Function SaveInstrument_UPD(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal systemdate As String) As Boolean
        Dim i As Integer

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction

        Dim table As New DataTable
        table.Columns.Add("GP_LOAD_DATE")
        table.Columns.Add("GP_FILENAME")
        table.Columns.Add("GP_NO")
        table.Columns.Add("GP_DESC")
        table.Columns.Add("GP_BNKBRN_NAME")
        table.Columns.Add("GP_CHQNO")
        table.Columns.Add("GP_PAIDDATE")
        table.Columns.Add("GP_AMOUNT")
        table.Columns.Add("GP_FEE")
        table.Columns.Add("GP_REMARK")
        table.Columns.Add("GP_SEQNO")
        table.Columns.Add("GP_GPTREF_SEQNO")
        table.Columns.Add("GP_INSTRUMENT_NO")
        table.Columns.Add("GP_REFNO")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")

        For Each dr As DataRow In dt.Rows

            Dim row As DataRow
            row = table.NewRow()

            row("GP_LOAD_DATE") = systemdate
            row("GP_FILENAME") = lblFileName.Text.Trim
            row("GP_NO") = dr("No")
            row("GP_DESC") = dr("Description")
            row("GP_BNKBRN_NAME") = dr("Branch_Name").ToString
            row("GP_CHQNO") = dr("Company_Cheque_No")
            row("GP_PAIDDATE") = dr("Payment_Date")
            row("GP_AMOUNT") = dr("Amount")
            row("GP_FEE") = dr("Fee")
            row("GP_REMARK") = dr("Remark")

            Dim s As String = dr("Remark")
            Dim parts As String() = s.Split(New Char() {"|"c})

            row("GP_SEQNO") = parts(0).ToString
            row("GP_GPTREF_SEQNO") = parts(1).ToString

            'Fixbug 20150316 by chutpoothon log#2 update Insrument 
            'add .ToString.PadLeft(10, "0").ToString
            'add .ToString.PadLeft(16, "0").ToString
            row("GP_INSTRUMENT_NO") = dr("Instrument_No").ToString.PadLeft(10, "0").ToString
            row("GP_REFNO") = dr("Ref_No").ToString.PadLeft(16, "0").ToString
            'end fixbug

            row("CREATEDBY") = gUserLogin
            row("UPDATEDBY") = gUserLogin

            table.Rows.Add(row)

            i = i + cls.INS_GPS_INSTRUMENTNO_UPDTE(clsUtility.gConnGP, oleTrans, row)

        Next

        If i = dt.Rows.Count Then
            Return True
        Else
            Return False
        End If


    End Function
    Function UpdateInstrument(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable) As Boolean
        Dim i As Integer

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction

        Dim table As New DataTable

        table.Columns.Add("GP_SEQNO")
        table.Columns.Add("GP_GPTREF_SEQNO")
        table.Columns.Add("GP_INSTRUMENT_NO")
        'Fixbug 20150316 by chutpoothon log#2 update Insrument 
        table.Columns.Add("GP_REFNO")
        'end fixbug
        table.Columns.Add("UPDATEDBY")

        For Each dr As DataRow In dt.Rows

            Dim row As DataRow
            row = table.NewRow()

            Dim s As String = dr("Remark")
            Dim parts As String() = s.Split(New Char() {"|"c})

            row("GP_SEQNO") = parts(0).ToString
            row("GP_GPTREF_SEQNO") = parts(1).ToString
            'row("GP_INSTRUMENT_NO") = dr("Instrument_No")

            'Fixbug 20150316 by chutpoothon log#2 update Insrument 
            'add .ToString.PadLeft(10, "0").ToString
            'add .ToString.PadLeft(16, "0").ToString
            row("GP_INSTRUMENT_NO") = dr("Instrument_No").ToString.PadLeft(10, "0").ToString
            row("GP_REFNO") = dr("Ref_No").ToString.PadLeft(16, "0").ToString
            'end fixbug

            row("UPDATEDBY") = gUserLogin

            table.Rows.Add(row)

            i = i + cls.UPD_GPS_INSTRUMENT(clsUtility.gConnGP, oleTrans, row)

        Next

        If i = dt.Rows.Count Then
            Return True
        Else
            Return False
        End If


    End Function
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim dt As New DataTable
        dt = GridToDT()

        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim chk_del, chk_save, chk_upd As Boolean
        Dim oleTrans As OleDbTransaction

        oleTrans = clsUtility.gConnGP.BeginTransaction

        chk_del = cls.DEL_GPS_INSTRUMENTNO_UPDTE(clsUtility.gConnGP, oleTrans, txtChequeNo.Text.Trim)

        If chk_del Then
            chk_save = SaveInstrument_UPD(oleTrans, dt, systemdate)

            chk_upd = UpdateInstrument(oleTrans, dt)

            If chk_save And chk_upd Then
                oleTrans.Commit()
                PrintReportXLS("")
                ' MsgBox("Update Instrument No. Successfully")
            Else
                oleTrans.Rollback()
                MsgBox("Can not update Instrument No.")
            End If

        Else
            oleTrans.Rollback()
            MsgBox(clsBusiness.gLastErrMessage)
        End If

        btnSave.Enabled = False
        btnUpdate.Enabled = False
        txtChequeNo.Enabled = True

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim dt As New DataTable
        dt = GridToDT()

        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim chk_save, chk_upd As Boolean
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction

        chk_save = SaveInstrument_UPD(oleTrans, dt, systemdate)

        chk_upd = UpdateInstrument(oleTrans, dt)


        If chk_save And chk_upd Then
            oleTrans.Commit()
            PrintReportXLS("")
            ' MsgBox("Update Instrument No. Successfully")
        Else
            oleTrans.Rollback()
            MsgBox("Can not update Instrument No.")
        End If

        btnSave.Enabled = False
        btnUpdate.Enabled = False
        txtChequeNo.Enabled = True

    End Sub
    Function GridToDT() As DataTable
        Dim Row As DataRow
        Dim dtTemp As New DataTable
        dtTemp = Nothing
        Try

            For index As Integer = 0 To DataGridView1.RowCount - 1
                Dim transdate As String = DataGridView1.Rows(index).Cells(4).Value.Substring(6, 4) & DataGridView1.Rows(index).Cells(4).Value.Substring(3, 2) & DataGridView1.Rows(index).Cells(4).Value.Substring(0, 2)

                If dtTemp Is Nothing Then
                    dtTemp = New DataTable("TempIns")


                    dtTemp.Columns.Add("No")
                    dtTemp.Columns.Add("Description")
                    dtTemp.Columns.Add("Branch_Name")
                    dtTemp.Columns.Add("Company_Cheque_No")
                    dtTemp.Columns.Add("Payment_Date")
                    dtTemp.Columns.Add("Amount", Type.GetType("System.Double"))
                    dtTemp.Columns.Add("Fee")
                    dtTemp.Columns.Add("Remark")
                    dtTemp.Columns.Add("Instrument_No")
                    dtTemp.Columns.Add("Ref_No")

                End If

                Row = dtTemp.NewRow

                Row.Item(0) = DataGridView1.Rows(index).Cells(0).Value
                Row.Item(1) = DataGridView1.Rows(index).Cells(1).Value
                Row.Item(2) = DataGridView1.Rows(index).Cells(2).Value
                Row.Item(3) = DataGridView1.Rows(index).Cells(3).Value
                Row.Item(4) = transdate 'DataGridView1.Rows(index).Cells(4).Value
                Row.Item(5) = DataGridView1.Rows(index).Cells(5).Value
                Row.Item(6) = DataGridView1.Rows(index).Cells(6).Value
                Row.Item(7) = DataGridView1.Rows(index).Cells(7).Value
                Row.Item(8) = DataGridView1.Rows(index).Cells(8).Value
                Row.Item(9) = DataGridView1.Rows(index).Cells(9).Value

                dtTemp.Rows.Add(Row)

            Next


            Return dtTemp

        Catch ex As Exception
            Return Nothing
        End Try

        'datagridview1.AllowUserToAddRows = True

    End Function

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtChequeNo.Enabled = True
        txtChequeNo.Text = ""
        txtTextURL.Text = ""

        GetDataToGrid(Nothing)

    End Sub
    Private Sub PrintReportXLS(ByVal paymenttype As String)

        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptInstrumentUPD.rpt")

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataForPrintReport(clsUtility.gConnGP, txtChequeNo.Text.Trim, paymenttype)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            frm1.FillDataTableToReport(dt)

            frm1.Text = Me.Text
            frm1.Show()

        End If

    End Sub
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtChequeNo.Text.Trim = "" Then
            MsgBox("Please Enter Company Cheque No.")
            txtChequeNo.Focus()
            Exit Sub
        End If

        Dim paymenttype As String

        If cboPaymentType.SelectedIndex <> 0 Then
            paymenttype = cboPaymentType.SelectedValue.ToString
        Else
            paymenttype = ""
        End If

        PrintReportXLS(paymenttype)

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class