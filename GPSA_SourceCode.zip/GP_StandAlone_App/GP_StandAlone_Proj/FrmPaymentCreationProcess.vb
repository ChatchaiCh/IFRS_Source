Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Imports System.Globalization
Imports System.IO
Imports System.Runtime.InteropServices
Imports Microsoft.Office.Interop

'Imports Excel = Microsoft.Office.Interop.Excel
Public Class FrmPaymentCreationProcess
    'Private mExcelApp As Excel.Application

    'Private WithEvents txtNumeric As New DataGridViewTextBoxEditingControl
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New clsCreation
    Dim dataTableTAX As DataTable
    Dim dataTableGL As DataTable
    Dim dataTableGP As DataTable
    Dim dtJournalHold As DataTable
    Dim en As New System.Globalization.CultureInfo("en-GB")
    Dim err_data As String
    Dim err_wl As String
    'Dim clsTb As New WaterMarkTextBox
    'Private Resolution As New ResolutionChanger
    'Private OldWidth As UInteger
    'Private OldHeight As UInteger
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "

    Private Property lineno As Object

    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub FrmPaymentCreation_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Resolution.SetResolution(OldWidth, OldHeight)
        ''On_Load
        ''OldHeight = CUInt(Screen.PrimaryScreen.Bounds.Height)
        ''OldWidth = CUInt(Screen.PrimaryScreen.Bounds.Width)

        ''Resolution.SetResolution(1000, 740)

        ''Select Case Resolution.SetResolution(1024, 768)
        ''    Case ResolutionChanger.ChangeResult.Success
        ''        MsgBox("The Resolution was changed", MsgBoxStyle.OkOnly)
        ''    Case ResolutionChanger.ChangeResult.Restart
        ''        MsgBox("Restart your system to activate the new resolution setting", MsgBoxStyle.OkOnly)
        ''    Case ResolutionChanger.ChangeResult.Fail
        ''        MsgBox("The resolution couldn't be changed", MsgBoxStyle.OkOnly)
        ''    Case ResolutionChanger.ChangeResult.ResolutionNotSupported
        ''        MsgBox("The requested resolution is not supported by your system", MsgBoxStyle.OkOnly)
        ''End Select
        'FrmMainMenu.SplitContainer1.Panel1Collapsed = False
        'FrmMainMenu.EXITToolStripMenuItem.Text = "Hide Menu"
        'Me.Dispose()
    End Sub
    Private Sub FrmPaymentCreation_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then

                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        'Fix MaskedTextBox mouse click problem
        'Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        retCreateDate = ""
        retCoreSystem = ""
        retTransRef = ""

        ControlStyle()
        TabStyle()
        BindDepartment()
        BindDataSetUp()
        ListGroup()
        ListPaymenType()
        ListJournalType()
        ListDataSource()
        ListOverSea()
        ListEntryType()
        ListEntryTypeGP()
        ListEntryTypeTAX()

        Dim dt As DataTable = New DataTable
        dt = Nothing
        GenGridGL(dt)
        GenGridGP(dt)
        GenGridTax(dt)

        txtEntryDate.Text = DateTime.Now.ToString("dd/MM/yyyy", en) 'Now.ToString("dd/MM/yyyy")
        txtAccPeriod.Text = DateTime.Now.ToString("MM/yyyy", en) 'Now.ToString("MM/yyyy")

        lblStatus.Text = "ADD"
        btnUpdate.Enabled = False
        btnDelete.Enabled = False

    End Sub
    Private Sub BindDataSetUp()
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_GL_HEAD_SETUP ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            txtStatus.Text = dt.Rows(0)("GLHS_GLSTS").ToString
            txtBookID.Text = dt.Rows(0)("GLHS_BOOKID").ToString
            txtSourceName.Text = dt.Rows(0)("GLHS_SOURCE_NME").ToString
            txtCategoryName.Text = dt.Rows(0)("GLHS_CATEGORY_NME").ToString
            txtCurrencyCode.Text = dt.Rows(0)("GLHS_CURRENCY_CDE").ToString
            txtActualFlag.Text = dt.Rows(0)("GLHS_ACTUAL_FLAG").ToString
            txtCompanyCode.Text = dt.Rows(0)("GLHS_COMPANY_CDE").ToString
            txtRCCode.Text = dt.Rows(0)("GLHS_RCCODE").ToString
        Else
            MsgBox("Can not load data GPS_GL_HEAD_SETUP")
        End If
    End Sub
    Private Sub BindDepartment()

        Dim sb As New StringBuilder()
        sb.Append("SELECT D.DEP_DEPCODE,D.DEP_DEPNAME FROM GPS_TL_DEPTUSER T,GPS_TL_DEPARTMENT D  ")
        sb.Append("WHERE T.USER_DEPCODE=D.DEP_DEPCODE ")
        sb.Append("AND T.USER_GROUPCODE='" & gUserGroupCode & "' ")

        ''MsgBox(sb.ToString)


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            txtSection.Text = dt.Rows(0)("DEP_DEPNAME").ToString
            lblDept.Text = dt.Rows(0)("DEP_DEPCODE").ToString
        Else
            MsgBox("Can not load data GPS_TL_DEPTUSER")
        End If
    End Sub
    Private Sub ListPaymenType(Optional ByVal condition As String = "")
        Dim sb As New StringBuilder()

        sb.Append("SELECT PAYT_PAYMTH ||':'|| PAYT_SUB_PAYMTH AS ID,PAYT_PAYTYPE AS NAME FROM GPS_TL_PAYTYPE ")

        If condition <> "" Then
            sb.Append("WHERE " & condition & " ")
        End If
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!ID = 0
            dr!NAME = ""
            dt.Rows.InsertAt(dr, 0)
            With cboPayMth
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
        cboPayMth.SelectedIndex = 1

    End Sub
    Private Sub ListJournalType(Optional ByVal tlm As Boolean = False)
        Dim sb As New StringBuilder()
        If tlm Then
            sb.Append("SELECT DISTINCT(DTS_JN_TYPE_C) AS ID,DTS_JN_TYPE_C AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='TLM' AND DTS_JN_TYPE_C <> ' ' ")
            sb.Append("UNION ALL ")
            sb.Append("SELECT DISTINCT(DTS_JN_TYPE_J_NOPAY) AS ID,DTS_JN_TYPE_J_NOPAY AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='TLM' AND DTS_JN_TYPE_J_NOPAY <> ' ' ")

        Else
            sb.Append("SELECT DISTINCT(DTS_JN_TYPE_C) AS ID,DTS_JN_TYPE_C AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='ACC' AND DTS_JN_TYPE_C <> ' ' ")
            sb.Append("UNION ALL ")
            sb.Append("SELECT DISTINCT(DTS_JN_TYPE_J_NOPAY) AS ID,DTS_JN_TYPE_J_NOPAY AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='ACC' AND DTS_JN_TYPE_J_NOPAY <> ' ' ")

        End If

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboJournalType
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
    End Sub
    Private Sub ListDataSource(Optional ByVal tlm As Boolean = False)
        Dim sb As New StringBuilder()
        If tlm Then
            sb.Append("SELECT DISTINCT(DTS_DTSOURCE) AS ID,DTS_DTSOURCE AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='TLM' ")

        Else
            sb.Append("SELECT DISTINCT(DTS_DTSOURCE) AS ID,DTS_DTSOURCE AS NAME FROM GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='ACC' ")
            sb.Append("AND DTS_DEP_KEYIN='" & lblDept.Text & "' ")

        End If

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboDataSource
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If

        cboDataSource.SelectedIndex = 0

        If lblStatus.Text = "ADD" Then
            txtTransRef.Text = cboDataSource.SelectedValue.ToString
        End If

    End Sub
    Private Sub ListGroup(Optional ByVal tlm As Boolean = False)
        Dim sb As New StringBuilder()
        If tlm Then
            sb.Append("SELECT PCRE_PAYCRETYP_ID AS ID,PCRE_PAYCRETYP_NAME AS NAME FROM GPS_TL_PAYCREATE_TYPE WHERE PCRE_PAYCRETYP_ID = '005' ")
        Else
            sb.Append("SELECT PCRE_PAYCRETYP_ID AS ID,PCRE_PAYCRETYP_NAME AS NAME FROM GPS_TL_PAYCREATE_TYPE WHERE PCRE_PAYCRETYP_ID <> '005' ")
        End If

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr!bank_code = 0
            'dr!bank_name = "-----(All)-----"
            'dt.Rows.InsertAt(dr, 0)
            With cboGroup
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If
        cboGroup.SelectedIndex = 0
    End Sub
    Private Sub ListOverSea()

        Dim sb As New StringBuilder()
        sb.Append("SELECT OSEA_LIST ID,OSEA_LISTNAME NAME FROM GPS_TL_OVERSEA_LIST")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr!ID = 0
            dr!NAME = ""
            dt.Rows.InsertAt(dr, 0)
            With cboOverSea
                .DataSource = dt
                .DisplayMember = "NAME"
                .ValueMember = "ID"
            End With
        End If


    End Sub
    Private Sub ListEntryType()

        cboEntryType.Items.Add("Manual")
        cboEntryType.Items.Add("Excel File")
        cboEntryType.Items.Add("Text File")
        cboEntryType.SelectedIndex = 0

    End Sub
    Private Sub ListEntryTypeGP()

        cboEntryTypeGP.Items.Add("Manual")
        cboEntryTypeGP.Items.Add("Excel File")
        cboEntryTypeGP.Items.Add("Text File")
        cboEntryTypeGP.SelectedIndex = 0

    End Sub
    Private Sub ListEntryTypeTAX()

        cboEntryTypeTAX.Items.Add("Manual")
        cboEntryTypeTAX.Items.Add("Excel File")
        cboEntryTypeTAX.SelectedIndex = 0

    End Sub
    Private Sub BindTransRef(ByVal transref As String)
        txtTransRef.Text = transref
    End Sub
    Private Sub BindAccountPeriod(ByVal account_period As String)
        txtAccPeriod.Text = account_period.Substring(5, 2) & "/" & account_period.Substring(0, 4)
    End Sub
    Private Sub ControlStyle()

        PanelH1.BackColor = Color.FromArgb(255, 235, 220)
        PanelD1.BackColor = Color.FromArgb(255, 235, 200)
        Panel1.BackColor = Color.FromArgb(255, 235, 200)
        Panel2.BackColor = Color.FromArgb(255, 235, 200)
        Panel3.BackColor = Color.FromArgb(255, 235, 200)

    End Sub
    Private Sub TabStyle()

        TabControl1.ImageList = ImageList1

        TabPage1.ImageIndex = 12
        ' Sizes the tabs of tabControl1. 
        Me.TabControl1.ItemSize = New Size(90, 30)
        ' Makes the tab width definable.  
        Me.TabControl1.SizeMode = TabSizeMode.Fixed

        TabControl1.DrawMode = TabDrawMode.OwnerDrawFixed
        'TabControl1.ForeColor = Color.LightGray 'Color.Blue

        For Each tp As TabPage In Me.TabControl1.TabPages
            tp.BackColor = Color.FromArgb(255, 235, 200)
        Next

    End Sub
    Private Sub TabControl1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles TabControl1.DrawItem
        Dim g As Graphics = e.Graphics
        Dim tp As TabPage = TabControl1.TabPages(e.Index)
        Dim br As Brush
        Dim sf As New StringFormat

        Dim r As New RectangleF(e.Bounds.X, e.Bounds.Y + 2, e.Bounds.Width, e.Bounds.Height - 2)

        sf.Alignment = StringAlignment.Center
        sf.LineAlignment = StringAlignment.Center

        Dim strTitle As String = tp.Text

        'If the current index is the Selected Index, change the color 
        If TabControl1.SelectedIndex = e.Index Then

            'this is the background color of the tabpage header
            br = New SolidBrush(Color.FromArgb(232, 119, 34)) ' change to your choice

            g.FillRectangle(br, e.Bounds)

            'this is the foreground color of the text in the tab header
            br = New SolidBrush(Color.White) ' change to your choice
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        Else

            'these are the colors for the unselected tab pages 
            br = New SolidBrush(Color.FromArgb(255, 235, 220)) ' Change this to your preference
            g.FillRectangle(br, e.Bounds)
            br = New SolidBrush(Color.FromArgb(232, 119, 34))
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        End If
    End Sub
    Private Sub dgvGP_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgvGP.KeyDown
        If e.KeyValue = Keys.Delete Then
            e.Handled = True

            btnClearGP_Click(sender, Nothing)

            Exit Sub
        End If
    End Sub
    Private Sub dgvGP_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvGP.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.dgvGP.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.dgvGP.ClearSelection()
            Me.dgvGP.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub dgvGP_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles dgvGP.CellPainting
        '' Only the Header Row (which Index is -1) is to be affected.
        'If e.RowIndex = -1 Then
        '    GridDrawCustomHeaderColumns(dgvGL, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)
        'End If
        'If e.ColumnIndex = 9 AndAlso e.RowIndex >= 0 Then
        '    e.Paint(e.CellBounds, DataGridViewPaintParts.All)

        '    Dim bmpFind As Bitmap = My.Resources.search_icon
        '    Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
        '    e.Graphics.DrawIcon(ico, e.CellBounds.Left + 3, e.CellBounds.Top + 3)
        '    e.Handled = True

        'End If
    End Sub

    Private Sub dgvTax_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvTax.CellEndEdit

        Try
            CalculateTAX()
            'Pattamalin 2015/01/29
            dgvTax.AllowUserToAddRows = False

            Dim iRow = dgvTax.CurrentCell.RowIndex

            If dgvGP.Rows.Count > 0 Then

                If Not IsNothing(dgvTax.Rows(iRow).Cells(0).Value) AndAlso dgvTax.Rows(iRow).Cells(0).Value.ToString <> "" Then
                    Dim keyline As String


                    If Not IsNothing(dgvTax.Rows(iRow).Cells(4).Value) AndAlso dgvTax.Rows(iRow).Cells(4).Value.ToString <> "" _
                           Or Not IsNothing(dgvTax.Rows(iRow).Cells(13).Value) AndAlso dgvTax.Rows(iRow).Cells(13).Value.ToString <> "" Then

                        If Not IsNothing(dgvTax.Rows(iRow).Cells(19).Value) AndAlso dgvTax.Rows(iRow).Cells(19).Value.ToString <> "" Then
                            keyline = dgvTax.Rows(iRow).Cells(19).Value
                        Else
                            keyline = ""
                        End If

                        dgvTax.Rows(iRow).Cells(19).Value = ""

                        Dim foundRows_link() As DataRow

                        Dim dtGP As New DataTable
                        dtGP = GPToTemp()

                        Dim taxname As String = ""
                        If Not IsNothing(dgvTax.Rows(iRow).Cells(3).Value) AndAlso dgvTax.Rows(iRow).Cells(3).Value.ToString <> "" Then
                            taxname = dgvTax.Rows(iRow).Cells(3).Value.ToString.Replace(" ", "")
                        End If
                        If Not IsNothing(dgvTax.Rows(iRow).Cells(4).Value) AndAlso dgvTax.Rows(iRow).Cells(4).Value.ToString <> "" Then
                            taxname = taxname & dgvTax.Rows(iRow).Cells(4).Value.ToString.Replace(" ", "")
                        End If
                        If Not IsNothing(dgvTax.Rows(iRow).Cells(5).Value) AndAlso dgvTax.Rows(iRow).Cells(5).Value.ToString <> "" Then
                            taxname = taxname & dgvTax.Rows(iRow).Cells(5).Value.ToString.Replace(" ", "")
                        End If


                        Dim baseamt, whtamt As Double
                        Dim amt As Double

                        If Not IsNothing(dgvTax.Rows(iRow).Cells(13).Value) AndAlso dgvTax.Rows(iRow).Cells(13).Value.ToString <> "" Then
                            baseamt = dgvTax.Rows(iRow).Cells(13).Value
                        Else
                            baseamt = 0
                        End If

                        If Not IsNothing(dgvTax.Rows(iRow).Cells(14).Value) AndAlso dgvTax.Rows(iRow).Cells(14).Value.ToString <> "" Then
                            whtamt = dgvTax.Rows(iRow).Cells(14).Value
                        Else
                            whtamt = 0
                        End If

                        amt = baseamt - whtamt

                        Dim ltax As String

                        ltax = GetLineTax()

                        foundRows_link = dtGP.Select("CheckName =  '" & taxname & "' and Amount=" & amt & " and FlagLine='N' " & ltax)



                        If foundRows_link.Length > 0 Then
                            If keyline <> "" Then
                                If keyline = foundRows_link(0)("GPLine").ToString() Then
                                    foundRows_link(0)("FlagLine") = "Y"
                                    dgvTax.Rows(iRow).Cells(19).Value = foundRows_link(0)("GPLine").ToString()
                                    dgvTax.Rows(iRow).Cells(19).Style.BackColor = Color.White
                                Else
                                    dgvTax.Rows(iRow).Cells(19).Value = keyline
                                    dgvTax.Rows(iRow).Cells(19).Style.BackColor = Color.Red
                                End If
                            Else
                                foundRows_link(0)("FlagLine") = "Y"
                                dgvTax.Rows(iRow).Cells(19).Value = foundRows_link(0)("GPLine").ToString()
                                dgvTax.Rows(iRow).Cells(19).Style.BackColor = Color.White

                            End If

                        Else
                            dgvTax.Rows(iRow).Cells(19).Value = keyline '""
                            dgvTax.Rows(iRow).Cells(19).Style.BackColor = Color.Red
                        End If
                    End If



                    '--------------Find GP Link---------------
                    ' If Not String.IsNullOrEmpty(dgvTax.Rows(iRow).Cells(13).Value) Then
                    If Not IsNothing(dgvTax.Rows(iRow).Cells(13).Value) AndAlso dgvTax.Rows(iRow).Cells(13).Value.ToString <> "" Then
                        Dim amt As Decimal
                        amt = Convert.ToDecimal(dgvTax.Rows(iRow).Cells(13).Value)
                        dgvTax.Rows(iRow).Cells(13).Value = amt.ToString("###,###.00")
                    End If
                    If Not IsNothing(dgvTax.Rows(iRow).Cells(14).Value) AndAlso dgvTax.Rows(iRow).Cells(14).Value.ToString <> "" Then
                        Dim amt As Decimal
                        amt = Convert.ToDecimal(dgvTax.Rows(iRow).Cells(14).Value)
                        dgvTax.Rows(iRow).Cells(14).Value = amt.ToString("###,###.00")
                    End If

                End If

            End If



            'If e.ColumnIndex = 19 Then
            '    btnAddRowTax_Click(Nothing, Nothing)
            'End If

        Catch ex As Exception

        End Try


    End Sub
    Private Sub dgvTax_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgvTax.KeyDown
        If e.KeyValue = Keys.Delete Then
            e.Handled = True

            btnClearTax_Click(sender, Nothing)

            Exit Sub
        End If
    End Sub
    Private Sub dgvTax_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvTax.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.dgvTax.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.dgvTax.ClearSelection()
            Me.dgvTax.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub dgvTax_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles dgvTax.CellPainting
        '' Only the Header Row (which Index is -1) is to be affected.
        'If e.RowIndex = -1 Then
        '    GridDrawCustomHeaderColumns(dgvTax, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)
        'End If
        'If e.ColumnIndex = 6 AndAlso e.RowIndex >= 0 Then
        '    e.Paint(e.CellBounds, DataGridViewPaintParts.All)
        '    Dim bmpFind As Bitmap = My.Resources.search_icon
        '    Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
        '    e.Graphics.DrawIcon(ico, e.CellBounds.Left + 3, e.CellBounds.Top + 3)
        '    e.Handled = True
        'End If
    End Sub
    Private Sub RemoveAllTextbox(ByVal pn As Panel)
        For i As Integer = pn.Controls.Count - 1 To 0 Step -1
            pn.Controls.Remove(Panel1.Controls(i))
        Next i
    End Sub
    Private Sub GenGridGL(ByVal dt As DataTable)
        With dgvGL
            .DataSource = dt
            .Columns.Clear()

            .ReadOnly = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            '.AutoGenerateColumns = True
            .AllowUserToAddRows = True
            .AllowUserToResizeColumns = True
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .RowsDefaultCellStyle.BackColor = Color.WhiteSmoke
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray
            '.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill


        End With
        'DataGridView Header Style
        With dgvGL.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            '.BackColor = Color.Indigo
            '.ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        '-- COLUMN 1 : LINE NO
        Dim cLineNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineNo
            '.ReadOnly = True
            .DataPropertyName = "LineNo"
            .Name = "Line No"
            .Width = 50
            dgvGL.Columns.Add(cLineNo)
        End With

        '-- COLUMN 2 : TRANS REF
        Dim cTransRef As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTransRef
            .ReadOnly = True
            .DataPropertyName = "TransRef"
            .Name = "Trans Ref"
            .Width = 100
            dgvGL.Columns.Add(cTransRef)
        End With

        '-- COLUMN 3 : TRANS DATE
        Dim cTranDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTranDate
            .DataPropertyName = "TransDate"
            .Name = "Trans Date"
            .Width = 80
            dgvGL.Columns.Add(cTranDate)
        End With

        '-- COLUMN 4 : DUE DATE
        Dim cDueDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDueDate
            .ReadOnly = True
            .DataPropertyName = "DueDate"
            .Name = "Due Date"
            .Width = 80
            dgvGL.Columns.Add(cDueDate)
        End With

        '-- COLUMN 5 : DESCRIPTION
        Dim cDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDesc
            .DataPropertyName = "Description"
            .Name = "Description"
            .Width = 80
            dgvGL.Columns.Add(cDesc)
        End With

        '-- COLUMN 6 : SUN ACC CODE
        Dim cAccCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAccCode
            .DataPropertyName = "SunAccCode"
            .Name = "Acc Code"
            .Width = 80
            dgvGL.Columns.Add(cAccCode)
        End With

        'Dim btn As New DataGridViewButtonColumn
        'With btn
        '    .UseColumnTextForButtonValue = True
        '    dgvGL.Columns.Add(btn)
        'End With

        '-- COLUMN 7 : SUN ACC NAME
        Dim cAccName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAccName
            .ReadOnly = True
            .DataPropertyName = "SunAccName"
            .Name = "Account Name"
            .Width = 80
            dgvGL.Columns.Add(cAccName)
        End With

        '-- COLUMN 8 : AMOUNT
        Dim cBaseAmount As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBaseAmount
            .DataPropertyName = "Amount"
            .Name = "Base Amount"
            .Width = 80
            dgvGL.Columns.Add(cBaseAmount)
        End With

        '-- COLUMN 9 : DEBIT / CREDIT
        Dim cDrAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDrAmt
            .DataPropertyName = "DC"
            .Name = "Dr/Cr"
            .Width = 80
            .DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            dgvGL.Columns.Add(cDrAmt)
        End With

        '-- COLUMN 10 : SUN DEPT
        Dim cDept As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDept
            .DataPropertyName = "SunDept"
            .Name = "Dept/Br"
            .Width = 80

            dgvGL.Columns.Add(cDept)
        End With

        '-- COLUMN 11 : SUN PL/PT
        Dim cPLPT As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPLPT
            .DataPropertyName = "SunPLPT"
            .Name = "PL/PT"
            .Width = 80
            dgvGL.Columns.Add(cPLPT)
        End With

        '-- COLUMN 12 : SUN MKTG
        Dim cMktg As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cMktg
            .DataPropertyName = "SunMktg"
            .Name = "Mktg/Emp"
            .Width = 80
            dgvGL.Columns.Add(cMktg)
        End With

        '-- COLUMN 13 : SUN PROJECT CODE
        Dim cPrj As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPrj
            .DataPropertyName = "SunProjectCode"
            .Name = "Project"
            .Width = 80
            dgvGL.Columns.Add(cPrj)
        End With

        '-- COLUMN 14 : SUN TT/TR
        Dim cTTRT As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTTRT
            .DataPropertyName = "SunTTTR"
            .Name = "TT-TR"
            .Width = 80
            dgvGL.Columns.Add(cTTRT)
        End With

        '-- COLUMN 15 : PAYMENT TYPE
        Dim cPaymentType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPaymentType
            .ReadOnly = True
            .DataPropertyName = "PaymentType"
            .Name = "PaymentType"
            .Width = 80
            dgvGL.Columns.Add(cPaymentType)
        End With

        '-- COLUMN 16 : PAYMENT NAME
        Dim cPaymentTo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPaymentTo
            .DataPropertyName = "PaymentName"
            .Name = "PaymentTo"
            .Width = 80
            dgvGL.Columns.Add(cPaymentTo)
        End With

        '-- COLUMN 17 : ORACLE ACC CODE
        Dim cAccCode_O As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAccCode_O
            .DataPropertyName = "OracleAccCode"
            .Name = "Acc Code"
            .Width = 80
            dgvGL.Columns.Add(cAccCode_O)
        End With

        '-- COLUMN 18 : ORACLE DEPT
        Dim cDept_O As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDept_O
            .DataPropertyName = "OracleDept"
            .Name = "Dept/Br"
            .Width = 80
            dgvGL.Columns.Add(cDept_O)
        End With

        '-- COLUMN 19 : ORACLE PL/PT
        Dim cPLPT_O As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPLPT_O
            .DataPropertyName = "OraclePLPT"
            .Name = "PL/PT"
            .Width = 80
            dgvGL.Columns.Add(cPLPT_O)
        End With

        '-- COLUMN 20 : ORACLE MKTG
        Dim cMktg_O As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cMktg_O
            .DataPropertyName = "OracleMktg"
            .Name = "Mktg/Emp"
            .Width = 80
            dgvGL.Columns.Add(cMktg_O)
        End With

        '-- COLUMN 21 : ORACLE PROJECT CODE
        Dim cPrj_O As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPrj_O
            .DataPropertyName = "OracleProjectCode"
            .Name = "Project"
            .Width = 80
            dgvGL.Columns.Add(cPrj_O)
        End With

        '-- COLUMN 22 : CONVERSION TYPE
        Dim cConversionType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cConversionType
            .DataPropertyName = "Conversion_type"
            .Name = "Conversion Type"
            .Width = 80
            dgvGL.Columns.Add(cConversionType)
        End With

        '-- COLUMN 23 : CONVERSION RATE
        Dim cConversionRate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cConversionRate
            .DataPropertyName = "Conversion_rate"
            .Name = "Conversion Rate"
            .Width = 80
            dgvGL.Columns.Add(cConversionRate)
        End With

        '-- COLUMN 24 : CONVERSION DATE
        Dim cConversionDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cConversionDate
            .DataPropertyName = "Conversion_date"
            .Name = "Conversion Date"
            .Width = 80
            dgvGL.Columns.Add(cConversionDate)
        End With

        '-- COLUMN 25 : LINE-REF 1
        Dim cLineTrxRef1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineTrxRef1
            .DataPropertyName = "Line_trx_ref1"
            .Name = "Line-Ref 1"
            .Width = 80
            dgvGL.Columns.Add(cLineTrxRef1)
        End With

        '-- COLUMN 26 :  LINE-REF 2
        Dim cLineTrxRef2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineTrxRef2
            .DataPropertyName = "Line_trx_ref2"
            .Name = "Line-Ref 2"
            .Width = 80
            dgvGL.Columns.Add(cLineTrxRef2)
        End With

        '-- COLUMN 27 :  LINE-REF 3
        Dim cLineTrxRef3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineTrxRef3
            .DataPropertyName = "Line_trx_ref3"
            .Name = "Line-Ref 3"
            .Width = 80
            dgvGL.Columns.Add(cLineTrxRef3)
        End With

        '-- COLUMN 28 : SUB-ACCOUNT
        Dim cSubAcct As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSubAcct
            .DataPropertyName = "Sub_acct"
            .Name = "Sub-Account"
            .Width = 85
            dgvGL.Columns.Add(cSubAcct)
        End With

        '-- COLUMN 29 : ANALYSIS
        Dim cAnalysis As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAnalysis
            .DataPropertyName = "Analysis"
            .Name = "Analysis"
            .Width = 80
            dgvGL.Columns.Add(cAnalysis)
        End With

        '-- COLUMN 30 : INTERCOMPANY
        Dim cIntercompany As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cIntercompany
            .DataPropertyName = "Intercompany"
            .Name = "Intercompany"
            .Width = 85
            dgvGL.Columns.Add(cIntercompany)
        End With

        '-- COLUMN 31 : SPARE 1
        Dim cSpare1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSpare1
            .DataPropertyName = "Spare1"
            .Name = "Spare 1"
            .Width = 80
            dgvGL.Columns.Add(cSpare1)
        End With

        '-- COLUMN 32 : TREATY CODE
        Dim cTreatyCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTreatyCode
            .DataPropertyName = "Treaty_code"
            .Name = "Treaty Code"
            .Width = 85
            dgvGL.Columns.Add(cTreatyCode)
        End With

        '-- COLUMN 33 : EVENT CODE
        Dim cEventCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cEventCode
            .DataPropertyName = "Event_code"
            .Name = "Event Code"
            .Width = 80
            dgvGL.Columns.Add(cEventCode)
        End With

        '-- COLUMN 34 : LOCAL 3
        Dim cLocal3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLocal3
            .DataPropertyName = "Local3"
            .Name = "Local 3"
            .Width = 80
            dgvGL.Columns.Add(cLocal3)
        End With

        '-- COLUMN 35 : LOCAL 4
        Dim cLocal4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLocal4
            .DataPropertyName = "Local4"
            .Name = "Local 4"
            .Width = 80
            dgvGL.Columns.Add(cLocal4)
        End With

        '-- COLUMN 36 : REF 1
        Dim cRef_1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_1
            .DataPropertyName = "Ref_1"
            .Name = "Ref 1"
            .Width = 80
            dgvGL.Columns.Add(cRef_1)
        End With

        '-- COLUMN 37 : REF 2
        Dim cRef_2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_2
            .DataPropertyName = "Ref_2"
            .Name = "Ref 2"
            .Width = 80
            dgvGL.Columns.Add(cRef_2)
        End With

        '-- COLUMN 38 : REF 3
        Dim cRef_3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_3
            .DataPropertyName = "Ref_3"
            .Name = "Ref 3"
            .Width = 80
            dgvGL.Columns.Add(cRef_3)
        End With

        '-- COLUMN 39 : REF 4
        Dim cRef_4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_4
            .DataPropertyName = "Ref_4"
            .Name = "Ref 4"
            .Width = 80
            dgvGL.Columns.Add(cRef_4)
        End With

        '-- COLUMN 40 : REF 5
        Dim cRef_5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_5
            .DataPropertyName = "Ref_5"
            .Name = "Ref 5"
            .Width = 80
            dgvGL.Columns.Add(cRef_5)
        End With

        '-- COLUMN 41 : REF 6
        Dim cRef_6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_6
            .DataPropertyName = "Ref_6"
            .Name = "Ref 6"
            .Width = 80
            dgvGL.Columns.Add(cRef_6)
        End With

        '-- COLUMN 42 : REF 7
        Dim cRef_7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_7
            .DataPropertyName = "Ref_7"
            .Name = "Ref 7"
            .Width = 80
            dgvGL.Columns.Add(cRef_7)
        End With

        '-- COLUMN 43 : REF 8
        Dim cRef_8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_8
            .DataPropertyName = "Ref_8"
            .Name = "Ref 8"
            .Width = 80
            dgvGL.Columns.Add(cRef_8)
        End With

        '-- COLUMN 44 : REF 9
        Dim cRef_9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_9
            .DataPropertyName = "Ref_9"
            .Name = "Ref 9"
            .Width = 80
            dgvGL.Columns.Add(cRef_9)
        End With

        '-- COLUMN 45 : REF 10
        Dim cRef_10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRef_10
            .DataPropertyName = "Ref_10"
            .Name = "Ref 10"
            .Width = 80
            dgvGL.Columns.Add(cRef_10)
        End With

        '-- COLUMN 46 : TO LEDGER
        Dim cToLedger As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cToLedger
            .DataPropertyName = "To_ledger"
            .Name = "To ledger"
            .Width = 80
            dgvGL.Columns.Add(cToLedger)
        End With

        'Dim cbo As New DataGridViewComboBoxColumn
        'With cbo
        '    .Items.Add("Debits")
        '    .Items.Add("Credits")
        '    .Name = "Debits/Credits"
        '    .Width = 120
        '    dgvGL.Columns.Add(cbo)
        'End With

        'dgvGL.Columns(6).Width = 24
        dgvGL.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight
        dgvGL.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        'dgvGL.ColumnHeadersHeight = dgvGL.ColumnHeadersHeight * 2
        dgvGL.ColumnHeadersHeight = 50
        dgvGL.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter

        dgvGL.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub GenGridGP(ByVal dt As DataTable)
        With dgvGP

            .DataSource = dt
            .Columns.Clear()

            .ReadOnly = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = True
            .AllowUserToResizeColumns = True
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .RowsDefaultCellStyle.BackColor = Color.WhiteSmoke
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray
            '.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill


        End With

        'DataGridView Header Style
        With dgvGP.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            '.BackColor = Color.Indigo
            '.ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        '-- COLUMN 1 : TRANS REF
        Dim cTransRef As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTransRef
            .ReadOnly = True
            .DataPropertyName = "TransRef"
            .Name = "Trans Ref"
            .Width = 100
            dgvGP.Columns.Add(cTransRef)
        End With

        '-- COLUMN 2 : POL NO
        Dim cPolNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPolNo
            .DataPropertyName = "PolNo"
            .Name = "Policy No"
            .Width = 100
            dgvGP.Columns.Add(cPolNo)
        End With

        '-- COLUMN 3 : BILL NO
        Dim cBillNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBillNo
            .DataPropertyName = "BillNo"
            .Name = "Bill No"
            .Width = 100
            dgvGP.Columns.Add(cBillNo)
        End With

        '-- COLUMN 4 : DUE DATE
        Dim cDueDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDueDate
            .ReadOnly = True
            .DataPropertyName = "DueDate"
            .Name = "Due Date"
            .Width = 100
            dgvGP.Columns.Add(cDueDate)
        End With

        '-- COLUMN 5 : AMOUNT
        Dim cAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmt
            .DataPropertyName = "Amount"
            .Name = "Amount"
            .Width = 100
            dgvGP.Columns.Add(cAmt)
        End With

        '-- COLUMN 6 : DESCRIPTION
        Dim cDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDesc
            .DataPropertyName = "Description"
            .Name = "Description"
            .Width = 100
            dgvGP.Columns.Add(cDesc)
        End With

        '-- COLUMN 7 : PAYMENT TYPE
        Dim cPaymentType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPaymentType
            .ReadOnly = True
            .DataPropertyName = "PaymentType"
            .Name = "PaymentType"
            .Width = 100
            dgvGP.Columns.Add(cPaymentType)
        End With

        '-- COLUMN 8 : PAYEE NAME
        Dim cPayeeName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayeeName
            .DataPropertyName = "PayeeName"
            .Name = "Payee Name"
            .Width = 100
            dgvGP.Columns.Add(cPayeeName)
        End With

        '-- COLUMN 9 : BANK CODE
        Dim cBankCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankCode
            .DataPropertyName = "BankCode"
            .Name = "Bank Code"
            .Width = 100
            dgvGP.Columns.Add(cBankCode)
        End With

        'Dim btn As New DataGridViewButtonColumn
        'With btn
        '    .UseColumnTextForButtonValue = True
        '    dgvGP.Columns.Add(btn)
        'End With

        '-- COLUMN 10 : BANK NUMBER
        Dim cBankNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankNo
            .DataPropertyName = "BankNumber"
            .Name = "Bank Number"
            .Width = 100
            dgvGP.Columns.Add(cBankNo)
        End With

        '-- COLUMN 11 : BANK BRANCH
        Dim cBankBranch As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankBranch
            .DataPropertyName = "BankBranch"
            .Name = "Bank Branch"
            .Width = 100
            dgvGP.Columns.Add(cBankBranch)
        End With

        '-- COLUMN 12 : BANK NAME
        Dim cBankName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankName
            .DataPropertyName = "BankName"
            .Name = "Bank Name"
            .Width = 100
            dgvGP.Columns.Add(cBankName)
        End With

        '-- COLUMN 13 : PAYEE BANK ACC NO
        Dim cPayeeBankAccount As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayeeBankAccount
            .DataPropertyName = "PayeeBankAccNo"
            .Name = "Payee Bank Account No"
            .Width = 100
            dgvGP.Columns.Add(cPayeeBankAccount)
        End With

        '-- COLUMN 14 : PAYEE BANK ACC NAME
        Dim cPayeeBankAccountP As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayeeBankAccountP
            .DataPropertyName = "PayeeBankAccName"
            .Name = "Payee Bank Accoount Name"
            .Width = 100
            dgvGP.Columns.Add(cPayeeBankAccountP)
        End With

        '-- COLUMN 15 : COMMENT
        Dim cComment As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cComment
            .DataPropertyName = "Comment"
            .Name = "Comment"
            .Width = 100
            dgvGP.Columns.Add(cComment)
        End With

        '-- COLUMN 16 : ADDRESS1
        Dim cAddress As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAddress
            .DataPropertyName = "Address1"
            .Name = "Address1"
            .Width = 100
            dgvGP.Columns.Add(cAddress)
        End With

        '-- COLUMN 17 : DISTRICT
        Dim cDistrict As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDistrict
            .DataPropertyName = "District"
            .Name = "District"
            .Width = 100
            dgvGP.Columns.Add(cDistrict)
        End With

        '-- COLUMN 18 : PROVINCE
        Dim cProvince As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cProvince
            .DataPropertyName = "Province"
            .Name = "Province"
            .Width = 100
            dgvGP.Columns.Add(cProvince)
        End With

        '-- COLUMN 19 : INSURENAME
        Dim cInsureName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cInsureName
            .DataPropertyName = "InsureName"
            .Name = "Insure Name"
            .Width = 100
            dgvGP.Columns.Add(cInsureName)
        End With

        '-- COLUMN 20 : DATA SOURCE
        Dim cDataSource As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDataSource
            .ReadOnly = True
            .DataPropertyName = "DataSource"
            .Name = "Data Source"
            .Width = 100
            dgvGP.Columns.Add(cDataSource)
        End With

        '-- COLUMN 21 : SUB PAYMENT TYPE
        Dim cSubPaymentType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSubPaymentType
            .ReadOnly = True
            .DataPropertyName = "SubPaymentType"
            .Name = "Sub PaymentType"
            .Width = 100
            dgvGP.Columns.Add(cSubPaymentType)
        End With

        '-- COLUMN 22 : MERCHANT NO
        Dim cMerchartNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cMerchartNo
            .DataPropertyName = "MerchartNo"
            .Name = "Merchart No"
            .Width = 100
            dgvGP.Columns.Add(cMerchartNo)
        End With

        '-- COLUMN 23 : TRANS CARD
        Dim cTransCard As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTransCard
            .DataPropertyName = "TransCard"
            .Name = "Trans.Card"
            .Width = 100
            dgvGP.Columns.Add(cTransCard)
        End With

        '-- COLUMN 24 : RESERVE9
        Dim cReserve9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cReserve9
            .DataPropertyName = "Reserve9"
            .Name = "Reserve9"
            .Width = 100
            dgvGP.Columns.Add(cReserve9)
        End With

        '-- COLUMN 25 : RESERVE10
        Dim cReserve10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cReserve10
            .DataPropertyName = "Reserve10"
            .Name = "Reserve10"
            .Width = 100
            dgvGP.Columns.Add(cReserve10)
        End With

        '-- COLUMN 26 : SYS_REF
        Dim cSection As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSection
            .DataPropertyName = "Sys_Ref"
            .Name = "SectionType"
            .Width = 100
            dgvGP.Columns.Add(cSection)
        End With

        '-- COLUMN 27 : SYS_GR
        Dim cPayType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayType
            .DataPropertyName = "Sys_Gr"
            .Name = "Pay Type"
            .Width = 100
            dgvGP.Columns.Add(cPayType)
        End With

        'Dim cFlag As DataGridViewColumn = New DataGridViewTextBoxColumn()
        'With cFlag
        '    .DataPropertyName = "Flag"
        '    .Name = "Flag"
        '    .Width = 100
        '    dgvGP.Columns.Add(cFlag)
        'End With

        '-- COLUMN 28 : FLAG
        Dim colCheckbox As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With colCheckbox
            .DataPropertyName = "Flag"
            .Name = "Flag"
            .Width = 100
            dgvGP.Columns.Add(colCheckbox)
        End With

        '�ͧ����� Checkbox
        'Dim colCheckbox As New DataGridViewCheckBoxColumn()
        'colCheckbox.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader
        'colCheckbox.ThreeState = False
        'colCheckbox.TrueValue = True
        'colCheckbox.FalseValue = False
        'colCheckbox.IndeterminateValue = System.DBNull.Value
        'colCheckbox.DataPropertyName = "Flag"
        'colCheckbox.HeaderText = "Flag �Դ��������"
        'colCheckbox.Name = "Checkbox"
        'colCheckbox.ReadOnly = False
        'dgvGP.Columns.Add(colCheckbox)

        '-- COLUMN 29 : PHONE
        Dim cPhone As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPhone
            .DataPropertyName = "Phone"
            .Name = "Phone"
            .Width = 100
            dgvGP.Columns.Add(cPhone)
        End With

        '-- COLUMN 30 : FAX
        Dim cFax As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cFax
            .DataPropertyName = "Fax"
            .Name = "Fax"
            .Width = 100
            dgvGP.Columns.Add(cFax)
        End With

        '-- COLUMN 31 : SWIFT CODE
        Dim cSwiftCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSwiftCode
            .DataPropertyName = "SwiftCode"
            .Name = "Swift Code"
            .Width = 100
            dgvGP.Columns.Add(cSwiftCode)
        End With

        '-- COLUMN 32 : BANK BRANCH NAME
        Dim cBankBranchName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankBranchName
            .DataPropertyName = "BankBranchName"
            .Name = "Bank Branch Name"
            .Width = 100
            dgvGP.Columns.Add(cBankBranchName)
        End With

        '-- COLUMN 33 : BANK ADDRESS
        Dim cBankAddress As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankAddress
            .DataPropertyName = "BankAddress"
            .Name = "Bank Address"
            .Width = 100
            dgvGP.Columns.Add(cBankAddress)
        End With

        '-- COLUMN 34 : COUNTRY
        Dim cReceive As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cReceive
            .DataPropertyName = "Country"
            .Name = "����ȼ���Ѻ�Թ"
            .Width = 100
            dgvGP.Columns.Add(cReceive)
        End With

        '-- COLUMN 35 : CURRENCY
        Dim cCurrency As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCurrency
            .DataPropertyName = "Currency"
            .Name = "ʡ���Թ"
            .Width = 100
            dgvGP.Columns.Add(cCurrency)
        End With

        '-- COLUMN 36 : EXCHANGE RATE
        Dim cExRate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cExRate
            .DataPropertyName = "ExchangeRate"
            .Name = "�ѵ���š����¹"
            .Width = 100
            dgvGP.Columns.Add(cExRate)
        End With

        '-- COLUMN 37 : BANK CHARGE
        Dim cFee As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cFee
            .DataPropertyName = "BankCharge"
            .Name = "��Ҹ�������㹡���͹�Թ �ѡ�ҡ (S=�鹷ҧ,D=���·ҧ)"
            .Width = 150
            dgvGP.Columns.Add(cFee)
        End With

        '-- COLUMN 38 : GP LINE
        Dim cLineNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineNo
            '.ReadOnly = True
            .DataPropertyName = "GPLine"
            .Name = "GP Line"
            .Width = 100
            dgvGP.Columns.Add(cLineNo)
        End With


        'Dim chk As New DataGridViewCheckBoxColumn
        'With chk
        '    dgvGP.Columns.Add(chk)
        'End With

        'Dim colCheckbox As New DataGridViewCheckBoxColumn()
        'colCheckbox.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader

        'colCheckbox.ThreeState = False
        'colCheckbox.TrueValue = True
        'colCheckbox.FalseValue = False
        'colCheckbox.IndeterminateValue = System.DBNull.Value
        'colCheckbox.DataPropertyName = "Flag"
        'colCheckbox.HeaderText = "Flag"
        'colCheckbox.Name = "Checkbox"
        'colCheckbox.ReadOnly = False
        'dgvGP.Columns.Add(colCheckbox)


        'dgvGP.Columns(9).Width = 24
        'dgvGP.Columns(3).DefaultCellStyle.Format = "dd/MM/yyyy"

        dgvGP.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight


    End Sub
    Private Sub GenGridTax(ByVal dt As DataTable)
        With dgvTax
            .DataSource = dt
            .Columns.Clear()
            .ReadOnly = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            '.AutoGenerateColumns = True
            .AllowUserToAddRows = True
            .AllowUserToResizeColumns = True
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .RowsDefaultCellStyle.BackColor = Color.WhiteSmoke
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray
            '.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

        End With

        'DataGridView Header Style
        With dgvTax.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            '.BackColor = Color.Indigo
            '.ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        '-- COLUMN 1 : LINE NO
        Dim cLineNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLineNo
            .DataPropertyName = "LineNo"
            .Name = "Line No"
            .Width = 80
            dgvTax.Columns.Add(cLineNo)
        End With

        '-- COLUMN 2 : TAX ID
        Dim cTaxID As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxID
            .DataPropertyName = "TaxID"
            .Name = "Tax ID"
            .Width = 80
            dgvTax.Columns.Add(cTaxID)
        End With

        '-- COLUMN 3 : ID CARD
        Dim cIDCard As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cIDCard
            .DataPropertyName = "IDCard"
            .Name = "ID Card"
            .Width = 80
            dgvTax.Columns.Add(cIDCard)
        End With

        '-- COLUMN 4 : AP TILTE
        Dim cAPTitle As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAPTitle
            .DataPropertyName = "APTitle"
            .Name = "AP Title"
            .Width = 80
            dgvTax.Columns.Add(cAPTitle)
        End With

        '-- COLUMN 5 : AP NAME
        Dim cAPName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAPName
            .DataPropertyName = "APName"
            .Name = "AP Name"
            .Width = 80
            dgvTax.Columns.Add(cAPName)
        End With

        '-- COLUMN 6 : AP LAST NAME
        Dim cAPLastName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAPLastName
            .DataPropertyName = "APLastName"
            .Name = "AP Last Name"
            .Width = 80
            dgvTax.Columns.Add(cAPLastName)
        End With

        '-- COLUMN 7 : ADDRESS
        Dim cAddress As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAddress
            .DataPropertyName = "Address"
            .Name = "Address"
            .Width = 80
            dgvTax.Columns.Add(cAddress)
        End With

        '-- COLUMN 8 : AMPE NM
        Dim cAMPENM As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAMPENM
            .DataPropertyName = "AMPENM"
            .Name = "AMPENM"
            .Width = 80
            dgvTax.Columns.Add(cAMPENM)
        End With

        '-- COLUMN 9 : PROV NM
        Dim cPROVNM As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPROVNM
            .DataPropertyName = "PROVNM"
            .Name = "PROVNM"
            .Width = 80
            dgvTax.Columns.Add(cPROVNM)
        End With

        '-- COLUMN 10 : AG ZIP
        Dim cAGZIP As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAGZIP
            .DataPropertyName = "AGZIP"
            .Name = "AGZIP"
            .Width = 80
            dgvTax.Columns.Add(cAGZIP)
        End With

        '-- COLUMN 11 : TAX TYPE
        Dim cTaxType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxType
            .DataPropertyName = "TaxType"
            .Name = "Tax Type"
            .Width = 80
            dgvTax.Columns.Add(cTaxType)
        End With

        '-- COLUMN 12 : TAX ITEM
        Dim cTaxItem As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxItem
            .DataPropertyName = "TaxItem"
            .Name = "Tax Item"
            .Width = 80
            dgvTax.Columns.Add(cTaxItem)
        End With

        '-- COLUMN 13 : TAX DATE
        Dim cTaxDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxDate
            .ReadOnly = True
            .DataPropertyName = "TaxDate"
            .Name = "Tax Date"
            .Width = 80
            dgvTax.Columns.Add(cTaxDate)
        End With

        '-- COLUMN 14 : BASE AMOUNT
        Dim cBaseAmount As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBaseAmount
            .DataPropertyName = "BaseAmount"
            .Name = "Base Amount"
            .Width = 80
            dgvTax.Columns.Add(cBaseAmount)
        End With

        '-- COLUMN 15 : WHT AMOUNT
        Dim cWHTAmount As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cWHTAmount
            .DataPropertyName = "WHTAmount"
            .Name = "WHT Amount"
            .Width = 80
            dgvTax.Columns.Add(cWHTAmount)
        End With

        '-- COLUMN 16 : PAYEE
        Dim cPayee As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayee
            .DataPropertyName = "Payee"
            .Name = "Payee"
            .Width = 80
            dgvTax.Columns.Add(cPayee)
        End With

        '-- COLUMN 17 : TAX RATE
        Dim cTaxRate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTaxRate
            .DataPropertyName = "TaxRate"
            .Name = "Tax Rate"
            .Width = 80
            dgvTax.Columns.Add(cTaxRate)
        End With

        '-- COLUMN 18 : DESCRIPTION
        Dim cDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cDesc
            .DataPropertyName = "Description"
            .Name = "Description"
            .Width = 80
            dgvTax.Columns.Add(cDesc)
        End With

        '-- COLUMN 19 : ACCOUNT CODE
        Dim cAccCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAccCode
            .DataPropertyName = "AccountCode"
            .Name = "Account Code"
            .Width = 80
            dgvTax.Columns.Add(cAccCode)
        End With

        '-- COLUMN 20 : GP LINE
        Dim cGPLine As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cGPLine
            '.ReadOnly = True
            .DataPropertyName = "GPLine"
            .Name = "GP Line"
            .Width = 100
            dgvTax.Columns.Add(cGPLine)
        End With

        '-- COLUMN 21 : SUB ACCOUNT CODE
        Dim cSubAccCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cSubAccCode
            .DataPropertyName = "SubAccountCode"
            .Name = "Sub-Account Code"
            .Width = 90
            dgvTax.Columns.Add(cSubAccCode)
        End With



        dgvTax.Columns(13).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight
        dgvTax.Columns(14).DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopRight


    End Sub

    Private Sub dgvGP_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgvGP.EditingControlShowing
        If Not e.Control Is Nothing Then
            Select Case dgvGP.CurrentCell.ColumnIndex
                Case 4 'Amount
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 6 'PaymentType
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    tb.MaxLength = 1
                Case Else
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
            End Select
        End If
    End Sub
    Private Sub dgvTax_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgvTax.EditingControlShowing
        If Not e.Control Is Nothing Then
            Select Case dgvTax.CurrentCell.ColumnIndex
                Case 1 'TaxID
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 13
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 2 'IDCard
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 13
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 5 'Desc
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 255
                Case 7 'Payeename
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 255
                Case 10 'TaxType
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                    tb.MaxLength = 1
                Case 11 'BankName
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 255
                Case 12 'BankAcc
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 20
                Case 13 'BaseAmount
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 14 'WhtAmount
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 34 'Currency
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 5
                Case 35 'BankChagre
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 1
                Case Else
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
            End Select
        End If
    End Sub
    Private Sub dgvGP_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvGP.CellEndEdit



        Try
            CalculateGP()

            dgvGP.AllowUserToAddRows = False

            Dim iRow = dgvGP.CurrentCell.RowIndex

            If Not String.IsNullOrEmpty(dgvGP.Rows(iRow).Cells(4).Value) Then
                Dim amt As Decimal
                amt = Convert.ToDecimal(dgvGP.Rows(iRow).Cells(4).Value)
                dgvGP.Rows(iRow).Cells(4).Value = amt.ToString("###,###.00")
            End If

            If Not String.IsNullOrEmpty(dgvGP.Rows(iRow).Cells(8).Value) Then

                dgvGP.Rows(iRow).Cells(8).Value = dgvGP.Rows(iRow).Cells(8).Value.ToString.ToUpper
                dgvGP.Rows(iRow).Cells(9).Value = cls.LookUp_BankCodeNo(clsUtility.gConnGP, dgvGP.Rows(iRow).Cells(8).Value.ToString)
                dgvGP.Rows(iRow).Cells(11).Value = cls.LookUp_BankName(clsUtility.gConnGP, dgvGP.Rows(iRow).Cells(8).Value.ToString)

            End If

            If cboPayMth.SelectedValue.ToString = "M:M" Then
                If Not IsNothing(dgvGP.Rows(iRow).Cells(12).Value) AndAlso dgvGP.Rows(iRow).Cells(12).Value.ToString <> "" Then
                    Dim bnkacc As String = dgvGP.Rows(iRow).Cells(12).Value.ToString
                    If bnkacc.Length < 3 Then
                        dgvGP.Rows(iRow).Cells(10).Value = ""
                    Else
                        If bnkacc.Length = 10 Or bnkacc.Length = 12 Then
                            dgvGP.Rows(iRow).Cells(10).Value = bnkacc.Substring(0, 3)
                        ElseIf bnkacc.Length = 15 Then
                            dgvGP.Rows(iRow).Cells(10).Value = bnkacc.Substring(0, 6)
                        ElseIf bnkacc.Length = 14 Then
                            dgvGP.Rows(iRow).Cells(10).Value = bnkacc.Substring(0, 4)
                        Else
                            dgvGP.Rows(iRow).Cells(10).Value = bnkacc.Substring(0, 3)

                        End If

                    End If

                Else
                    dgvGP.Rows(iRow).Cells(10).Value = ""
                End If
            End If

            'If e.ColumnIndex = 37 Then
            '    btnAddRowGP_Click(Nothing, Nothing)
            'End If

        Catch ex As Exception

        End Try


    End Sub
    Public Function CheckInStr(ByVal myString As String, ByVal array() As String) As Boolean
        For Each elem As String In array
            If myString.Contains(elem) Then Return True
        Next
        Return False
    End Function
    Private Sub txtValidate_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If CheckInStr(e.KeyChar.ToString, New String() {"~", "!", "#", "$", _
        "%", "^", "_", "*", "+", "=", "{", "}", "[", "]", ",", "|", "\", ";", """", "<", ">", "?"}) Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub
    Private Sub txtChar_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)

        e.Handled = False

    End Sub
    Private Sub txtNumeric_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If e.KeyChar = "."c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("."c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
    End Sub
    Function GET_SECTION_TYPE(ByVal jn As String) As String
        Dim sb As New StringBuilder()
        sb.Append("SELECT  DTS_DEP_REPAY From GPS_TL_DATASOURCE WHERE DTS_CORE_SYSTEM='ACC' AND DTS_DTSOURCE='" & jn & "'  ")
        sb.Append("AND DTS_JN_TYPE_C='" & cboJournalType.SelectedValue.ToString & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)("DTS_DEP_REPAY").ToString
        Else
            Return ""
        End If
    End Function
    Function GET_BANK_BY_PAYMTH(ByVal paymth As String, ByVal sub_paymth As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT B.BNKS_BNKSCODE_NO, B.BNKS_BNKSBRN_CD FROM GPS_TL_PAYTYPE A INNER JOIN GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP  ")
        sb.Append("WHERE A.PAYT_PAYMTH='" & paymth & "' AND A.PAYT_SUB_PAYMTH='" & sub_paymth & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GET_BANKCODE_BY_BANKNO(ByVal bank_no As String) As String

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE FROM GPS_TL_BANKMASTER WHERE BKMST_BNKCODE_NO='" & bank_no & "' And BKMST_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)("BKMST_BNKCODE").ToString
        Else
            Return ""
        End If
    End Function
    Function FindGPLink(ByVal dtTAX As DataTable, ByVal dtGL As DataTable, ByVal name As String) As String
        Dim foundRows_name() As DataRow
        'Dim name As String = ""
        For Each row As DataRow In dtGL.Rows
            foundRows_name = dtTAX.Select("CheckName='" & name & "' and CheckName = '" & row.Item("CheckName").ToString & "' ")
            If foundRows_name.Length > 0 Then
                name = row.Item("CheckName").ToString 'PayeeName
            End If
        Next
        Return name
    End Function
    Function FillDataGL(ByVal dt As DataTable, ByVal format As String) As DataTable
        Dim err As String = ""
        Dim d_err As Integer = 0
        For Each dr As DataRow In dt.Rows
            If format = ".xls" Then
                Try
                    Dim formatdate As String = "dd/MM/yyyy"
                    Dim sdate, tdate As Date

                    If TypeOf dr.Item("DueDate") Is Date Then
                        sdate = dr.Item("DueDate") 'Convert.ToDateTime(dr.Item("DueDate"))
                        dr.Item("DueDate") = sdate.ToString("dd/MM/yyyy")
                    Else
                        Dim d As Date
                        d = Convert.ToDateTime(dr.Item("DueDate"))
                        Try
                            sdate = Date.ParseExact(d.ToString("dd/MM/yyyy"), format, New Globalization.CultureInfo("en-US")) ' Convert.ToDateTime(dr.Item("DueDate"))
                            dr.Item("DueDate") = sdate.ToString("dd/MM/yyyy")
                        Catch ex As Exception
                            dr.Item("DueDate") = d.ToString("dd/MM/yyyy")
                        End Try

                    End If
                    If TypeOf dr.Item("TransDate") Is Date Then
                        tdate = dr.Item("TransDate") ' Convert.ToDateTime(dr.Item("TransDate"))
                        dr.Item("TransDate") = tdate.ToString("dd/MM/yyyy")
                    Else
                        Dim d As Date
                        d = Convert.ToDateTime(dr.Item("TransDate"))
                        Try
                            sdate = Date.ParseExact(d.ToString("dd/MM/yyyy"), format, New Globalization.CultureInfo("en-US")) ' Convert.ToDateTime(dr.Item("DueDate"))
                            dr.Item("TransDate") = sdate.ToString("dd/MM/yyyy")
                        Catch ex As Exception
                            dr.Item("TransDate") = d.ToString("dd/MM/yyyy")
                        End Try
                    End If

                Catch ex As Exception

                End Try

            Else
                'Text file

                cboJournalType.SelectedValue = dr.Item("JournalType").ToString

            End If


            'Fill SunAccName
            Try
                If dr.Item("SunAccCode") <> "" Then
                    dr.Item("SunAccName") = cls.LookUp_ACCName(clsUtility.gConnGP, dr.Item("SunAccCode").ToString)
                End If

            Catch ex As Exception
                dr.Item("SunAccName") = ""
            End Try

            If dr.Item("DueDate").ToString <> dtpDueDate.Value.ToString("dd/MM/yyyy") Then
                d_err = d_err + 1
            End If


            dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
            If dr.Item("Amount").ToString <> "" Then
                Dim amt As Decimal
                amt = Convert.ToDecimal(dr.Item("Amount"))
                dr.Item("Amount") = amt.ToString("###,###.00")
            End If


            cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)
            txtTransRef.Text = dr.Item("TransRef").ToString

            'Sun Dept/Branch
            Dim sDept As String = ""
            sDept = IIf(IsDBNull(dr.Item("SunDept")), "", dr.Item("SunDept"))
            If sDept <> "" Then
                dr.Item("SunDept") = cls.LookUp_SunCode(clsUtility.gConnGP, sDept, "and anl_type='DEPB'")
            End If

            'Sun PL/PT
            Dim sPLPT As String = ""
            sPLPT = IIf(IsDBNull(dr.Item("SunPLPT")), "", dr.Item("SunPLPT"))
            If sPLPT <> "" Then
                dr.Item("SunPLPT") = cls.LookUp_SunCode(clsUtility.gConnGP, sPLPT, "and anl_type='PLPT'")
            End If

            'Sun Mktg/Emp
            Dim sMKTG As String = ""
            sMKTG = IIf(IsDBNull(dr.Item("SunMktg")), "", dr.Item("SunMktg"))
            If sMKTG <> "" Then
                dr.Item("SunMktg") = cls.LookUp_SunCode(clsUtility.gConnGP, sMKTG, "and anl_type='MKTG'")
            End If

        Next


        If cboDataSource.SelectedValue = Nothing Then
            MsgBox("DataSource Not Match")
            dt = Nothing
            GenGridGL(dt)
            ListDataSource()
            txtTransRef.Text = ""
            Return dt

            Exit Function

        End If
        If cboJournalType.SelectedValue = Nothing Then
            MsgBox("Journal Type Not Match")
            dt = Nothing
            GenGridGL(dt)
            ListJournalType()
            txtTransRef.Text = ""
            Return dt

            Exit Function

        End If
        If d_err > 1 Then
            MsgBox("DueDate ���ç�Ѻ����� Load")
            txtTransRef.Text = ""
            dt = Nothing
            GenGridGL(dt)
            Return dt

            Exit Function
        End If

        If err <> "" Then
            MsgBox(err)
        End If

        Return dt

    End Function
    Function FillDataGP_TXT(ByVal dt As DataTable) As DataTable

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE,BKMST_BNKCODE_NO,BKMST_BNKNAME,BKMST_BNKNAME_ENG FROM GPS_TL_BANKMASTER WHERE BKMST_STATUS='ACTIVE' ")
        Dim newdt As DataTable
        Dim foundRows() As DataRow
        newdt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Dim err As String = ""


        For Each dr As DataRow In dt.Rows

            If newdt.Rows.Count > 0 Then

                dr.Item("GPLine") = dt.Rows.IndexOf(dr) + 1

                Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                Dim subpay As String = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)


                'Select Case cboPayMth.SelectedValue.ToString
                '"Media Clearing"
                'Case "M:M"

                If dt.Columns.Contains("TransRef") = False Then
                    dt.Columns.Add("TransRef")
                End If

                If dt.Columns.Contains("PaymentType") = False Then
                    dt.Columns.Add("PaymentType")
                End If

                If dt.Columns.Contains("BankNumber") = False Then
                    dt.Columns.Add("BankNumber")
                End If

                If dt.Columns.Contains("BankName") = False Then
                    dt.Columns.Add("BankName")
                End If

                If dt.Columns.Contains("PayeeBankAccName") = False Then
                    dt.Columns.Add("PayeeBankAccName")
                End If

                If dt.Columns.Contains("DataSource") = False Then
                    dt.Columns.Add("DataSource")
                End If

                If dt.Columns.Contains("BankBranch") = False Then
                    dt.Columns.Add("BankBranch")
                End If

                dr.Item("TransRef") = txtTransRef.Text.Trim
                dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)


                dr.Item("PayeeBankAccName") = dr.Item("PayeeName")

                If dt.Columns.Contains("BankCode") = True Then
                    foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                    If foundRows.Length > 0 Then
                        dr.Item("BankNumber") = foundRows(0)("BKMST_BNKCODE_NO").ToString()
                        dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                    Else
                        MsgBox("Bank Code Error")
                        dt = Nothing
                        Exit For
                    End If
                End If

                If dr.Item("PayeeBankAccNo").ToString.Length = 10 Or dr.Item("PayeeBankAccNo").ToString.Length = 12 Then
                    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 15 Then
                    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 6)
                ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 14 Then
                    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 4)
                Else
                    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                End If


                'End Select


                If dr.Item("Amount").ToString <> "" Then
                    Dim amt As Decimal
                    amt = Convert.ToDecimal(dr.Item("Amount"))
                    dr.Item("Amount") = amt.ToString("###,###.00")
                End If

            Else
                MsgBox("Bank Code Error")
                dt = Nothing
                Exit For
            End If
        Next

        If err <> "" Then
            MsgBox(err)
        End If

        Return dt
    End Function

    Function FillDataGP_DRAFT_TXT(ByVal dt As DataTable) As DataTable

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE,BKMST_BNKCODE_NO,BKMST_BNKNAME,BKMST_BNKNAME_ENG FROM GPS_TL_BANKMASTER WHERE BKMST_STATUS='ACTIVE' ")
        Dim newdt As DataTable
        Dim foundRows() As DataRow
        newdt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Dim err As String = ""


        For Each dr As DataRow In dt.Rows

            If newdt.Rows.Count > 0 Then

                dr.Item("GPLine") = dt.Rows.IndexOf(dr) + 1

                Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                Dim subpay As String = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)


                'Select Case cboPayMth.SelectedValue.ToString
                '"Media Clearing"
                'Case "M:M"

                If dt.Columns.Contains("TransRef") = False Then
                    dt.Columns.Add("TransRef")
                End If

                If dt.Columns.Contains("PaymentType") = False Then
                    dt.Columns.Add("PaymentType")
                End If

                If dt.Columns.Contains("BankNumber") = False Then
                    dt.Columns.Add("BankNumber")
                End If

                If dt.Columns.Contains("BankName") = False Then
                    dt.Columns.Add("BankName")
                End If

                If dt.Columns.Contains("PayeeBankAccName") = False Then
                    dt.Columns.Add("PayeeBankAccName")
                End If

                If dt.Columns.Contains("DataSource") = False Then
                    dt.Columns.Add("DataSource")
                End If

                If dt.Columns.Contains("BankBranch") = False Then
                    dt.Columns.Add("BankBranch")
                End If

                dr.Item("TransRef") = txtTransRef.Text.Trim
                dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)


                dr.Item("PayeeBankAccName") = dr.Item("PayeeName")

                If dt.Columns.Contains("BankCode") = True Then
                    dr.Item("BankCode") = "SCB"
                    foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                    If foundRows.Length > 0 Then
                        dr.Item("BankNumber") = foundRows(0)("BKMST_BNKCODE_NO").ToString()
                        dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                    Else
                        MsgBox("Bank Code Error")
                        dt = Nothing
                        Exit For
                    End If
                End If

                ' ''If dr.Item("PayeeBankAccNo").ToString.Length = 10 Or dr.Item("PayeeBankAccNo").ToString.Length = 12 Then
                ' ''    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                ' ''ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 15 Then
                ' ''    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 6)
                ' ''ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 14 Then
                ' ''    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 4)
                ' ''Else
                ' ''    dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                ' ''End If


                'End Select


                If dr.Item("Amount").ToString <> "" Then
                    Dim amt As Decimal
                    amt = Convert.ToDecimal(dr.Item("Amount"))
                    dr.Item("Amount") = amt.ToString("###,###.00")
                End If

            Else
                MsgBox("Bank Code Error")
                dt = Nothing
                Exit For
            End If
        Next

        If err <> "" Then
            MsgBox(err)
        End If

        Return dt
    End Function

    Function FillDataGP(ByVal dt As DataTable) As DataTable

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE,BKMST_BNKCODE_NO,BKMST_BNKNAME,BKMST_BNKNAME_ENG FROM GPS_TL_BANKMASTER WHERE BKMST_STATUS='ACTIVE' ")
        Dim newdt As DataTable
        Dim foundRows() As DataRow
        newdt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        Dim err As String = ""


        For Each dr As DataRow In dt.Rows

            If newdt.Rows.Count > 0 Then

                'Bind GP Line
                dr.Item("GPLine") = dt.Rows.IndexOf(dr) + 1


                Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                Dim subpay As String = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)


                Select Case cboPayMth.SelectedValue.ToString
                    '"Media Clearing", "ATS �ͧ SCB"
                    Case "M:M", "M:A"

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankNumber") = foundRows(0)("BKMST_BNKCODE_NO").ToString()
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If


                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) 'cboPaymentType.SelectedValue.ToString

                        'Pattamalin 2015/02/13
                        If dr.Item("PayeeBankAccNo").ToString <> "" Then
                            If dr.Item("PayeeBankAccNo").ToString.Length = 10 Or dr.Item("PayeeBankAccNo").ToString.Length = 12 Then
                                dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                            ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 15 Then
                                dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 6)
                            ElseIf dr.Item("PayeeBankAccNo").ToString.Length = 14 Then
                                dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 4)
                            Else
                                dr.Item("BankBranch") = dr.Item("PayeeBankAccNo").ToString.Substring(0, 3)
                            End If
                        Else
                            dr.Item("BankBranch") = ""
                        End If


                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) 'lblSubPayment.Text 'sub_paymth
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        '"Credit Card (�ѵ��ôԵ)"
                    Case "M:C"

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankNumber") = foundRows(0)("BKMST_BNKCODE_NO").ToString()
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If


                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) 'cboPaymentType.SelectedValue.ToString
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) 'lblSubPayment.Text 'sub_paymth
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")
                        dr.Item("TransCard") = Convert.ToDateTime(dr.Item("TransCard")).ToString("dd/MM/yyyy")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        '"SCB M Cheque", "Company Cheque", "SCB Cashier Cheque"
                    Case "C:C", "C:Q", "C:H"

                        Dim dtbank As DataTable
                        dtbank = GET_BANK_BY_PAYMTH(pay, subpay)

                        dr.Item("BankNumber") = dtbank.Rows(0)("BNKS_BNKSCODE_NO")
                        dr.Item("BankBranch") = dtbank.Rows(0)("BNKS_BNKSBRN_CD")
                        dr.Item("BankCode") = GET_BANKCODE_BY_BANKNO(dtbank.Rows(0)("BNKS_BNKSCODE_NO"))

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If
                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) 'cboPaymentType.SelectedValue.ToString
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) 'lblSubPayment.Text 'sub_paymth
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        '"SCB M Draft","Bank Draft"
                    Case "D:D", "C:B"


                        Dim dtbank As DataTable
                        dtbank = GET_BANK_BY_PAYMTH(pay, subpay)

                        dr.Item("BankNumber") = dtbank.Rows(0)("BNKS_BNKSCODE_NO")
                        dr.Item("BankBranch") = dtbank.Rows(0)("BNKS_BNKSBRN_CD")
                        dr.Item("BankCode") = GET_BANKCODE_BY_BANKNO(dtbank.Rows(0)("BNKS_BNKSCODE_NO"))

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If
                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        '"SCB Gift Cheque (�礢ͧ��ѭ)"
                    Case "C:G"
                        Dim dtbank As DataTable
                        dtbank = GET_BANK_BY_PAYMTH(pay, subpay)

                        dr.Item("BankNumber") = dtbank.Rows(0)("BNKS_BNKSCODE_NO")
                        dr.Item("BankBranch") = dtbank.Rows(0)("BNKS_BNKSBRN_CD")
                        dr.Item("BankCode") = GET_BANKCODE_BY_BANKNO(dtbank.Rows(0)("BNKS_BNKSCODE_NO"))

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If
                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                        '"Money Order (��ҳѵ�)"
                    Case "C:T"


                        Dim dtbank As DataTable
                        dtbank = GET_BANK_BY_PAYMTH(pay, subpay)

                        dr.Item("BankNumber") = dtbank.Rows(0)("BNKS_BNKSCODE_NO")
                        dr.Item("BankBranch") = dtbank.Rows(0)("BNKS_BNKSBRN_CD")
                        dr.Item("BankCode") = GET_BANKCODE_BY_BANKNO(dtbank.Rows(0)("BNKS_BNKSCODE_NO"))

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If
                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)
                        '"�͹�Թ��ҧ�����"
                    Case "M:B"

                        If dt.Columns.Contains("BankCode") = True Then
                            foundRows = newdt.Select("BKMST_BNKCODE='" & dr.Item("BankCode") & "'")
                            If foundRows.Length > 0 Then
                                dr.Item("BankNumber") = foundRows(0)("BKMST_BNKCODE_NO").ToString()
                                dr.Item("BankName") = foundRows(0)("BKMST_BNKNAME_ENG").ToString()
                            Else
                                MsgBox("Bank Code Error")
                                dt = Nothing
                                Exit For
                            End If
                        End If

                        dr.Item("PaymentType") = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("DataSource") = dr.Item("TransRef").ToString.Substring(0, 3)
                        dr.Item("SubPaymentType") = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
                        dr.Item("Sys_Ref") = GET_SECTION_TYPE(dr.Item("TransRef").ToString.Substring(0, 3))
                        dr.Item("Sys_Gr") = dr.Item("Description")

                        'Fill to main
                        cboDataSource.SelectedValue = dr.Item("TransRef").ToString.Substring(0, 3)

                End Select


                '��������� BankCode �������� 014
                If dr.Item("BankCode").ToString = "" Then
                    dr.Item("BankCode") = "014"
                End If

                If dr.Item("Amount").ToString <> "" Then
                    Dim amt As Decimal
                    amt = Convert.ToDecimal(dr.Item("Amount"))
                    dr.Item("Amount") = amt.ToString("###,###.00")
                End If

            Else
                MsgBox("Bank Code Error")
                dt = Nothing
                Exit For
            End If
        Next

        If err <> "" Then
            MsgBox(err)
        End If

        Return dt
    End Function
    Function FillDataTAX(ByVal dt As DataTable) As DataTable


        If dgvGP.RowCount > 0 Then

            Dim foundRows_link() As DataRow

            Dim dtGP As New DataTable
            dtGP = GPToTemp()

            For Each dr As DataRow In dt.Rows

                If cboGroup.SelectedValue.ToString <> "006" Then

                    dr.Item("CheckName") = Replace(dr.Item("APName").ToString.Trim & dr.Item("APLastName").ToString.Trim, " ", "")

                    Dim gpname As String
                    gpname = FindGPLink(dt, dtGP, dr.Item("CheckName"))

                    If gpname <> "" Then
                        Dim amt As Double
                        amt = dr("BaseAmount") - dr("WHTAmount")


                        foundRows_link = dtGP.Select("CheckName =  '" & gpname & "' and Amount=" & amt & " and FlagLine='N'  ")
                        If foundRows_link.Length > 0 Then
                            foundRows_link(0)("FlagLine") = "Y"
                            dr.Item("GPLine") = foundRows_link(0)("GPLine").ToString()
                        Else
                            dr.Item("GPLine") = ""
                        End If
                    End If

                End If

                If dr.Item("BaseAmount").ToString <> "" Then
                    Dim amt As Decimal
                    amt = Convert.ToDecimal(dr.Item("BaseAmount"))
                    dr.Item("BaseAmount") = amt.ToString("###,###.00")
                End If
                If dr.Item("WHTAmount").ToString <> "" Then
                    Dim amt As Decimal
                    amt = Convert.ToDecimal(dr.Item("WHTAmount"))
                    dr.Item("WHTAmount") = amt.ToString("###,###.00")
                End If

            Next

        End If


        Return dt
    End Function
    Private Sub CalculateGL(Optional ByVal skip As Boolean = True)
        'Calculate AmtDebits
        Dim glAmtCr As Decimal = 0
        Dim glAmtDr As Decimal = 0
        Dim glBalance As Decimal = 0
        Dim newlineno As Integer

        dgvGL.AllowUserToAddRows = False
        For index As Integer = 0 To dgvGL.RowCount - 1


            If IsDBNull(dgvGL.Rows(index).Cells(7).Value) Then
                dgvGL.Rows(index).Cells(7).Value = 0
            End If

            'pattamalin 2015/02/24
            'If skip Then
            '    If cboEntryType.SelectedIndex = 0 And index = 0 Then
            '        newlineno = index + 1
            '        dgvGL.Rows(index).Cells(0).Value = newlineno 'index + 1
            '        dgvGL.Rows(index).Cells(1).Value = txtTransRef.Text.Trim
            '        dgvGL.Rows(index).Cells(2).Value = DateTime.Now.ToString("dd/MM/yyyy", en) 'Now.ToString("dd/MM/yyyy")
            '        dgvGL.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy", en) 'dtpDueDate.Value.ToString("dd/MM/yyyy")

            '    End If
            'End If

            Try
                If dgvGL.Rows(index).Cells(8).Value = "C" Then
                    glAmtCr += Convert.ToDecimal(dgvGL.Rows(index).Cells(7).Value)
                ElseIf dgvGL.Rows(index).Cells(8).Value = "D" Then
                    glAmtDr += Convert.ToDecimal(dgvGL.Rows(index).Cells(7).Value)
                End If
            Catch ex As Exception

            End Try


        Next

        lbltxtTotalLine.Text = dgvGL.RowCount
        txtAmtDebits.Text = glAmtDr.ToString("###,##0.00")
        txtAmtCredits.Text = glAmtCr.ToString("###,##0.00")
        glBalance = glAmtDr - glAmtCr

        If glBalance < 0 Then
            txtOutOfBalance.Text = "(" & Math.Abs(glBalance).ToString("###,##0.00") & ")"
            txtOutOfBalance.ForeColor = Color.Red
        Else
            txtOutOfBalance.Text = glBalance.ToString("###,##0.00")
            txtOutOfBalance.ForeColor = Color.Black
        End If

        dgvGL.AllowUserToAddRows = True
    End Sub
    Private Sub CalculateGP(Optional ByVal skip As Boolean = True)
        'Calculate AmtDebits
        Dim glAmt As Decimal = 0

        For index As Integer = 0 To dgvGP.RowCount - 1

            If IsDBNull(dgvGP.Rows(index).Cells(4).Value) Then
                dgvGP.Rows(index).Cells(4).Value = 0
            End If

            glAmt += Convert.ToDecimal(dgvGP.Rows(index).Cells(4).Value)

            'Pattamalin 2015/02/24
            ''Default Data
            'If skip Then
            '    If cboEntryTypeGP.SelectedIndex = 0 And index = 0 Then
            '        dgvGP.Rows(index).Cells(0).Value = txtTransRef.Text.Trim
            '        Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)

            '        If IsNothing(dgvGP.Rows(index).Cells(8).Value) Then
            '            If (pay = "C" Or pay = "D") Then
            '                dgvGP.Rows(index).Cells(8).Value = "SCB"
            '            End If
            '        End If

            '        If IsNothing(dgvGP.Rows(index).Cells(9).Value) Then
            '            If pay = "C" Or pay = "D" Then
            '                dgvGP.Rows(index).Cells(9).Value = "014"
            '            End If
            '        End If

            '        dgvGP.Rows(index).Cells(20).Value = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
            '    End If
            'End If



        Next

        txtAmtCreditGP.Text = glAmt.ToString("###,##0.00")

    End Sub
    Private Sub FormatLoadTaxGPLine()
        '�ӵ͹��Ŵ��������
        For index As Integer = 0 To dgvTax.RowCount - 1
            'Pattamalin 2015/02/11

            If cboGroup.SelectedValue.ToString <> "006" Then

                If Not IsNothing(dgvTax.Rows(index).Cells(19).Value) AndAlso dgvTax.Rows(index).Cells(19).Value.ToString <> "" Then
                    dgvTax.Rows(index).Cells(19).Style.BackColor = Color.White
                Else
                    dgvTax.Rows(index).Cells(19).Style.BackColor = Color.Red
                End If

            End If

        Next
    End Sub
    Private Sub CalculateTAX(Optional ByVal skip As Boolean = True)
        dgvTax.AllowUserToAddRows = False
        Try

            'Calculate AmtDebits
            Dim BaseAmt As Decimal = 0
            Dim WHTAmt As Decimal = 0
            Dim newlineno As Integer

            For index As Integer = 0 To dgvTax.RowCount - 1

                If IsDBNull(dgvTax.Rows(index).Cells(13).Value) Then
                    dgvTax.Rows(index).Cells(13).Value = 0
                End If

                BaseAmt += Convert.ToDecimal(dgvTax.Rows(index).Cells(13).Value)


                If IsDBNull(dgvTax.Rows(index).Cells(14).Value) Then
                    dgvTax.Rows(index).Cells(14).Value = 0
                End If

                WHTAmt += Convert.ToDecimal(dgvTax.Rows(index).Cells(14).Value)

                'Pattamalin 2015/02/24
                'If skip Then
                '    If cboEntryTypeTAX.SelectedIndex = 0 And index = 0 Then
                '        'newlineno = index + 1
                '        'dgvTax.Rows(index).Cells(0).Value = newlineno 'index + 1
                '        dgvTax.Rows(index).Cells(12).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")

                '    End If
                'End If




            Next



            txtBaseAmt.Text = BaseAmt.ToString("###,##0.00")
            txtInputWHTAmt.Text = WHTAmt.ToString("###,##0.00")
        Catch ex As Exception

        End Try

        dgvTax.AllowUserToAddRows = True
    End Sub

    Function CheckIncludeWHT() As Boolean
        Dim ret As Boolean
        Dim dtGL As New DataTable
        dtGL = GLToTemp()

        Dim foundRows() As DataRow


        foundRows = dtGL.Select("substring(trim(SunTTTR),1,2) in ('02','03','53')")

        If foundRows.Length > 0 Then
            ret = True
        Else
            ret = False
        End If

        Return ret

    End Function
    Function SaveGL(ByVal oleTrans As OleDbTransaction, ByVal tb_name As String, ByVal CreateDate As String, ByVal CoreSystem As String, ByVal TransRef As String) As Boolean
        Dim ret As Boolean = True

        If dgvGL.RowCount > 0 Then

            Dim Rec As Integer

            For index As Integer = 0 To dgvGL.RowCount - 1

                If cboEntryType.SelectedIndex = 0 And IsNothing(dgvGL.Rows(index).Cells(2).Value) Then
                    dgvGL.Rows(index).Cells(2).Value = DateTime.Now.ToString("dd/MM/yyyy", en) 'Now.ToString("dd/MM/yyyy")
                Else
                    If IsNothing(dgvGL.Rows(index).Cells(2).Value) Then
                        MsgBox("Please enter Transaction Date")
                        clsBusiness.gLastErrMessage = "Please enter Transaction Date"
                        Exit Function
                    End If

                End If
                If cboEntryType.SelectedIndex = 0 And IsNothing(dgvGL.Rows(index).Cells(3).Value) Then
                    dgvGL.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
                Else
                    If IsNothing(dgvGL.Rows(index).Cells(3).Value) Then
                        MsgBox("Please enter Due Date")
                        clsBusiness.gLastErrMessage = "Please enter Due Date"
                        Exit Function
                    End If

                End If


                Dim period As String = txtAccPeriod.Text.Substring(3, 4) & txtAccPeriod.Text.Substring(0, 2).PadLeft(3, "0")
                Dim transdate As String = ""
                Dim duedate As String = ""

                If Not IsNothing(dgvGL.Rows(index).Cells(2).Value) AndAlso dgvGL.Rows(index).Cells(2).Value.ToString <> "" Then
                    Try
                        Dim format As String = "yyyyMMdd"
                        Dim StartDate As Date

                        transdate = dgvGL.Rows(index).Cells(2).Value.Substring(6, 4) & dgvGL.Rows(index).Cells(2).Value.Substring(3, 2) & dgvGL.Rows(index).Cells(2).Value.Substring(0, 2)
                        StartDate = Date.ParseExact(transdate, format, New Globalization.CultureInfo("en-US"))

                    Catch ex As Exception
                        MsgBox("Transaction Date not a valid")
                        clsBusiness.gLastErrMessage = "Transaction Date not a valid"
                        Exit Function
                    End Try
                End If


                Try
                    Dim format As String = "yyyyMMdd"
                    Dim StartDate As Date

                    duedate = dgvGL.Rows(index).Cells(3).Value.Substring(6, 4) & dgvGL.Rows(index).Cells(3).Value.Substring(3, 2) & dgvGL.Rows(index).Cells(3).Value.Substring(0, 2)
                    StartDate = Date.ParseExact(duedate, format, New Globalization.CultureInfo("en-US"))

                Catch ex As Exception
                    MsgBox("Due Date not a valid")
                    clsBusiness.gLastErrMessage = "Due Date not a valid"
                    Exit Function
                End Try

                Dim pay_mth As String
                If IsNothing(cboPayMth.SelectedItem) Then
                    pay_mth = ""
                Else
                    pay_mth = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                End If

                Dim amt As Decimal
                amt = Convert.ToDecimal(dgvGL.Rows(index).Cells(7).Value)

                Dim sDept As String
                Dim sPLPT As String
                Dim sMKTG As String

                Dim oDept As String
                Dim oPLPT As String
                Dim oMKTG As String

                If Not IsNothing(dgvGL.Rows(index).Cells(9).Value) AndAlso dgvGL.Rows(index).Cells(9).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(9).Value, "-", "")
                    'sDept = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 4))

                    sDept = dgvGL.Rows(index).Cells(9).Value.ToString()
                Else
                    sDept = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(10).Value) AndAlso dgvGL.Rows(index).Cells(10).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(10).Value, "-", "")
                    'sPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 3))

                    sPLPT = dgvGL.Rows(index).Cells(10).Value.ToString()
                Else
                    sPLPT = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(11).Value) AndAlso dgvGL.Rows(index).Cells(11).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(11).Value, "-", "")
                    'sMKTG = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))

                    sMKTG = dgvGL.Rows(index).Cells(11).Value.ToString()
                Else
                    sMKTG = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(17).Value) AndAlso dgvGL.Rows(index).Cells(17).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(17).Value, "-", "")
                    oDept = String.Format("{0}-{1}", a.Substring(0, 6), a.Substring(6, 3))
                Else
                    oDept = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(18).Value) AndAlso dgvGL.Rows(index).Cells(18).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(18).Value, "-", "")
                    oPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 2))
                Else
                    oPLPT = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(19).Value) AndAlso dgvGL.Rows(index).Cells(19).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(19).Value, "-", "")
                    oMKTG = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))
                Else
                    oMKTG = ""
                End If

                Dim Conversion_type As String
                Dim Conversion_rate As String
                Dim Conversion_date As String
                Dim Line_trx_ref1 As String
                Dim Line_trx_ref2 As String
                Dim Line_trx_ref3 As String
                Dim Sub_acct As String
                Dim Analysis As String
                Dim Intercompany As String
                Dim Spare1 As String
                Dim Treaty_code As String
                Dim Event_code As String
                Dim Local3 As String
                Dim Local4 As String
                Dim Ref_1 As String
                Dim Ref_2 As String
                Dim Ref_3 As String
                Dim Ref_4 As String
                Dim Ref_5 As String
                Dim Ref_6 As String
                Dim Ref_7 As String
                Dim Ref_8 As String
                Dim Ref_9 As String
                Dim Ref_10 As String
                Dim To_ledger As String

                If Not IsNothing(dgvGL.Rows(index).Cells(21).Value) AndAlso dgvGL.Rows(index).Cells(21).Value.ToString <> "" Then
                    Conversion_type = dgvGL.Rows(index).Cells(21).Value.ToString.Trim
                Else
                    Conversion_type = "User"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(22).Value) AndAlso dgvGL.Rows(index).Cells(22).Value.ToString <> "" Then
                    Conversion_rate = dgvGL.Rows(index).Cells(22).Value.ToString.Trim
                Else
                    Conversion_rate = "1.0000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(23).Value) AndAlso dgvGL.Rows(index).Cells(23).Value.ToString <> "" Then
                    Conversion_date = dgvGL.Rows(index).Cells(23).Value.ToString.Trim
                Else
                    Conversion_date = transdate
                End If
                If (Conversion_date.Length = 8) Then
                    Conversion_date = Conversion_date.Substring(0, 4) + "-" + Conversion_date.Substring(4, 2) + "-" + Conversion_date.Substring(6, 2)
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(24).Value) AndAlso dgvGL.Rows(index).Cells(24).Value.ToString <> "" Then
                    Line_trx_ref1 = dgvGL.Rows(index).Cells(24).Value.ToString.Trim
                Else
                    Line_trx_ref1 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(25).Value) AndAlso dgvGL.Rows(index).Cells(25).Value.ToString <> "" Then
                    Line_trx_ref2 = dgvGL.Rows(index).Cells(25).Value.ToString.Trim
                Else
                    Line_trx_ref2 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(26).Value) AndAlso dgvGL.Rows(index).Cells(26).Value.ToString <> "" Then
                    Line_trx_ref3 = dgvGL.Rows(index).Cells(26).Value.ToString.Trim
                Else
                    Line_trx_ref3 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(27).Value) AndAlso dgvGL.Rows(index).Cells(27).Value.ToString <> "" Then
                    Sub_acct = dgvGL.Rows(index).Cells(27).Value.ToString.Trim
                Else
                    Sub_acct = "0000000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(28).Value) AndAlso dgvGL.Rows(index).Cells(28).Value.ToString <> "" Then
                    Analysis = dgvGL.Rows(index).Cells(28).Value.ToString.Trim
                Else
                    Analysis = "0000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(29).Value) AndAlso dgvGL.Rows(index).Cells(29).Value.ToString <> "" Then
                    Intercompany = dgvGL.Rows(index).Cells(29).Value.ToString.Trim
                Else
                    Intercompany = "0000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(30).Value) AndAlso dgvGL.Rows(index).Cells(30).Value.ToString <> "" Then
                    Spare1 = dgvGL.Rows(index).Cells(30).Value.ToString.Trim
                Else
                    Spare1 = "0000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(31).Value) AndAlso dgvGL.Rows(index).Cells(31).Value.ToString <> "" Then
                    Treaty_code = dgvGL.Rows(index).Cells(31).Value.ToString.Trim
                Else
                    Treaty_code = "0000000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(32).Value) AndAlso dgvGL.Rows(index).Cells(32).Value.ToString <> "" Then
                    Event_code = dgvGL.Rows(index).Cells(32).Value.ToString.Trim
                Else
                    Event_code = "000000"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(33).Value) AndAlso dgvGL.Rows(index).Cells(33).Value.ToString <> "" Then
                    Local3 = dgvGL.Rows(index).Cells(33).Value.ToString.Trim
                Else
                    Local3 = "00"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(34).Value) AndAlso dgvGL.Rows(index).Cells(34).Value.ToString <> "" Then
                    Local4 = dgvGL.Rows(index).Cells(34).Value.ToString.Trim
                Else
                    Local4 = "00"
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(35).Value) AndAlso dgvGL.Rows(index).Cells(35).Value.ToString <> "" Then
                    Ref_1 = dgvGL.Rows(index).Cells(35).Value.ToString.Trim
                Else
                    Ref_1 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(36).Value) AndAlso dgvGL.Rows(index).Cells(36).Value.ToString <> "" Then
                    Ref_2 = dgvGL.Rows(index).Cells(36).Value.ToString.Trim
                Else
                    Ref_2 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(37).Value) AndAlso dgvGL.Rows(index).Cells(37).Value.ToString <> "" Then
                    Ref_3 = dgvGL.Rows(index).Cells(37).Value.ToString.Trim
                Else
                    Ref_3 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(38).Value) AndAlso dgvGL.Rows(index).Cells(38).Value.ToString <> "" Then
                    Ref_4 = dgvGL.Rows(index).Cells(38).Value.ToString.Trim
                Else
                    Ref_4 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(39).Value) AndAlso dgvGL.Rows(index).Cells(39).Value.ToString <> "" Then
                    Ref_5 = dgvGL.Rows(index).Cells(39).Value.ToString.Trim
                Else
                    Ref_5 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(40).Value) AndAlso dgvGL.Rows(index).Cells(40).Value.ToString <> "" Then
                    Ref_6 = dgvGL.Rows(index).Cells(40).Value.ToString.Trim
                Else
                    Ref_6 = oMKTG
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(41).Value) AndAlso dgvGL.Rows(index).Cells(41).Value.ToString <> "" Then
                    Ref_7 = dgvGL.Rows(index).Cells(41).Value.ToString.Trim
                Else
                    Ref_7 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(42).Value) AndAlso dgvGL.Rows(index).Cells(42).Value.ToString <> "" Then
                    Ref_8 = dgvGL.Rows(index).Cells(42).Value.ToString.Trim
                Else
                    Ref_8 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(43).Value) AndAlso dgvGL.Rows(index).Cells(43).Value.ToString <> "" Then
                    Ref_9 = dgvGL.Rows(index).Cells(43).Value.ToString.Trim
                Else
                    Ref_9 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(44).Value) AndAlso dgvGL.Rows(index).Cells(44).Value.ToString <> "" Then
                    Ref_10 = dgvGL.Rows(index).Cells(44).Value.ToString.Trim
                Else
                    Ref_10 = ""
                End If

                If Not IsNothing(dgvGL.Rows(index).Cells(45).Value) AndAlso dgvGL.Rows(index).Cells(45).Value.ToString <> "" Then
                    To_ledger = dgvGL.Rows(index).Cells(45).Value.ToString.Trim
                Else
                    To_ledger = "GCOMN"
                End If


                Dim sb As New StringBuilder()

                sb.Append("INSERT INTO " & tb_name & " (")
                sb.Append("GLCR_CREATEDATE,")
                sb.Append("GLCR_CORE_SYSTEM,")
                sb.Append("GLCR_JN_TYPE,")
                sb.Append("GLCR_JN_SOURCE,")
                sb.Append("GLCR_B_UNIT,")
                sb.Append("GLCR_GL_PERIOD,")
                sb.Append("GLCR_TRANSREF,")
                sb.Append("GLCR_LINENO,")
                sb.Append("GLCR_GLSTS,")
                sb.Append("GLCR_BOOKID,")
                sb.Append("GLCR_SOURCE_NME,")
                sb.Append("GLCR_CATEGORY_NME,")
                sb.Append("GLCR_CURRENCY_CDE,")
                sb.Append("GLCR_ACTUAL_FLAG,")
                sb.Append("GLCR_COMPANY_CDE,")
                sb.Append("GLCR_RCCODE,")
                sb.Append("GLCR_TRANSDATE,")
                sb.Append("GLCR_DUEDATE,")
                sb.Append("GLCR_DESC,")
                sb.Append("GLCR_O_ACCOUNT,")
                sb.Append("GLCR_AMOUNT,")
                sb.Append("GLCR_DRCR,")
                sb.Append("GLCR_O_DEP_BRN,")
                sb.Append("GLCR_O_PL_PT,")
                sb.Append("GLCR_O_MKT_EMP,")
                sb.Append("GLCR_O_PROJECT,")
                sb.Append("GLCR_PAYMTH,")
                sb.Append("GLCR_PAYEE,")
                sb.Append("GLCR_S_ACCOUNT,")
                sb.Append("GLCR_S_ACCNAME,")
                sb.Append("GLCR_S_DEP_BRN,")
                sb.Append("GLCR_S_PL_PT,")
                sb.Append("GLCR_S_MKT_EMP,")
                sb.Append("GLCR_S_TT_TR,")
                sb.Append("GLCR_S_PROJECT,")
                sb.Append("GLCR_JN_HOLD,")
                sb.Append("GLCR_APPROVEDBY,")
                sb.Append("GLCR_APPROVEDDATE,")
                sb.Append("GLCR_JN_NO_C,")
                sb.Append("GLCR_VCH_NO_C,")
                sb.Append("GLCR_FLAG_BATCH,")
                sb.Append("GLCR_BATCHDATE,")
                sb.Append("CREATEDBY,")
                sb.Append("CREATEDDATE,")
                sb.Append("UPDATEDBY,")
                sb.Append("UPDATEDDATE,")
                sb.Append("GLCR_CONVERSION_TYPE,")
                sb.Append("GLCR_CONVERSION_RATE,")
                sb.Append("GLCR_CONVERSION_DATE,")
                sb.Append("GLCR_LINE_TRX_REF1,")
                sb.Append("GLCR_LINE_TRX_REF2,")
                sb.Append("GLCR_LINE_TRX_REF3,")
                sb.Append("GLCR_SUB_ACCT,")
                sb.Append("GLCR_ANALYSIS,")
                sb.Append("GLCR_INTERCOMPANY,")
                sb.Append("GLCR_SPARE1,")
                sb.Append("GLCR_TREATY_CODE,")
                sb.Append("GLCR_EVENT_CODE,")
                sb.Append("GLCR_LOCAL3,")
                sb.Append("GLCR_LOCAL4,")
                sb.Append("GLCR_REF_1,")
                sb.Append("GLCR_REF_2,")
                sb.Append("GLCR_REF_3,")
                sb.Append("GLCR_REF_4,")
                sb.Append("GLCR_REF_5,")
                sb.Append("GLCR_REF_6,")
                sb.Append("GLCR_REF_7,")
                sb.Append("GLCR_REF_8,")
                sb.Append("GLCR_REF_9,")
                sb.Append("GLCR_REF_10,")
                sb.Append("GLCR_TO_lEDGER) ")
                sb.Append(" VALUES ( ")
                sb.Append("TRIM('" & CreateDate & "'),")
                sb.Append("TRIM('" & CoreSystem & "'),")
                sb.Append("TRIM('" & cboJournalType.SelectedValue.ToString & "'),")
                sb.Append("TRIM('" & CoreSystem & "'),")
                sb.Append("'SCB',")
                sb.Append("TRIM('" & period & "'),")
                sb.Append("TRIM('" & TransRef & "'),")
                sb.Append("TRIM('" & index + 1.ToString & "'),")
                sb.Append("TRIM('" & txtStatus.Text & "'),")
                sb.Append("TRIM('" & txtBookID.Text & "'),")
                sb.Append("TRIM('" & txtSourceName.Text & "'),")
                sb.Append("TRIM('" & txtCategoryName.Text & "'),")
                sb.Append("TRIM('" & txtCurrencyCode.Text & "'),")
                sb.Append("TRIM('" & txtActualFlag.Text & "'),")
                sb.Append("TRIM('" & txtCompanyCode.Text & "'),")
                sb.Append("TRIM('" & txtRCCode.Text & "'),")
                sb.Append("TRIM('" & transdate & "'),")
                sb.Append("TRIM('" & duedate & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(4).Value & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(16).Value & "'),")
                sb.Append("TRIM('" & amt & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(8).Value.ToString.Trim() & "'),")
                sb.Append("TRIM('" & oDept & "'),")
                sb.Append("TRIM('" & oPLPT & "'),")
                sb.Append("TRIM('" & oMKTG & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(12).Value & "'),")
                sb.Append("TRIM('" & pay_mth & "'),") 'cboPaymentType.SelectedValue.ToString
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(15).Value & "'),") 'Payee
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(5).Value & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(6).Value & "'),")
                sb.Append("TRIM('" & sDept & "'),")
                sb.Append("TRIM('" & sPLPT & "'),")
                sb.Append("TRIM('" & sMKTG & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(13).Value & "'),")
                sb.Append("TRIM('" & dgvGL.Rows(index).Cells(12).Value & "'),") 'Sun code old 20 date 20141118
                sb.Append("TRIM('" & txtJournalHold.Text & "'),")
                sb.Append("'',")
                sb.Append("'',")
                sb.Append("'',")
                sb.Append("'',")
                sb.Append("'N',")
                sb.Append("'',")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("TRIM('" & Conversion_type & "'),")
                sb.Append("TRIM('" & Conversion_rate & "'),")
                sb.Append("TRIM('" & Conversion_date & "'),")
                sb.Append("TRIM('" & Line_trx_ref1 & "'),")
                sb.Append("TRIM('" & Line_trx_ref2 & "'),")
                sb.Append("TRIM('" & Line_trx_ref3 & "'),")
                sb.Append("TRIM('" & Sub_acct & "'),")
                sb.Append("TRIM('" & Analysis & "'),")
                sb.Append("TRIM('" & Intercompany & "'),")
                sb.Append("TRIM('" & Spare1 & "'),")
                sb.Append("TRIM('" & Treaty_code & "'),")
                sb.Append("TRIM('" & Event_code & "'),")
                sb.Append("TRIM('" & Local3 & "'),")
                sb.Append("TRIM('" & Local4 & "'),")
                sb.Append("TRIM('" & Ref_1 & "'),")
                sb.Append("TRIM('" & Ref_2 & "'),")
                sb.Append("TRIM('" & Ref_3 & "'),")
                sb.Append("TRIM('" & Ref_4 & "'),")
                sb.Append("TRIM('" & Ref_5 & "'),")
                sb.Append("TRIM('" & Ref_6 & "'),")
                sb.Append("TRIM('" & Ref_7 & "'),")
                sb.Append("TRIM('" & Ref_8 & "'),")
                sb.Append("TRIM('" & Ref_9 & "'),")
                sb.Append("TRIM('" & Ref_10 & "'),")
                sb.Append("TRIM('" & To_ledger & "'))")

                Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

            Next

            If Rec = dgvGL.RowCount Then
                'oleTrans.Commit()
                ret = True
            Else
                'oleTrans.Rollback()
                ret = False
            End If

        End If


        Return ret

    End Function
    Function SaveGP(ByVal oleTrans As OleDbTransaction, ByVal tb_name As String, ByVal CreateDate As String _
                    , ByVal CoreSystem As String, ByVal TransRef As String _
                    , Optional ByVal bnkbrn As String = "", Optional ByVal bnkname As String = "") As Boolean
        Dim ret As Boolean = True

        If dgvGP.RowCount > 0 Then

            Dim duedate As String = ""
            Try
                Dim format As String = "yyyyMMdd"
                Dim StartDate As Date

                duedate = dgvGP.Rows(0).Cells(3).Value.Substring(6, 4) & dgvGP.Rows(0).Cells(3).Value.Substring(3, 2) & dgvGP.Rows(0).Cells(3).Value.Substring(0, 2)
                StartDate = Date.ParseExact(duedate, format, New Globalization.CultureInfo("en-US"))

            Catch ex As Exception
                MsgBox("Due Date not a valid")
                clsBusiness.gLastErrMessage = "Due Date not a valid"
                Exit Function
            End Try


            Dim Rec As Integer
            For index As Integer = 0 To dgvGP.RowCount - 1

                If bnkbrn = "" Then
                    If Not IsNothing(dgvGP.Rows(index).Cells(10).Value) AndAlso dgvGP.Rows(index).Cells(10).Value.ToString <> "" Then
                        bnkbrn = dgvGP.Rows(index).Cells(10).Value
                    End If
                End If

                If bnkname = "" Then
                    If Not IsNothing(dgvGP.Rows(index).Cells(11).Value) AndAlso dgvGP.Rows(index).Cells(11).Value.ToString <> "" Then
                        bnkname = dgvGP.Rows(index).Cells(11).Value
                    End If
                End If

                'If cboEntryTypeGP.SelectedIndex = 0 And IsNothing(dgvGP.Rows(index).Cells(3).Value) Then
                '    dgvGP.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
                'Else
                '    If IsNothing(dgvGP.Rows(index).Cells(3).Value) Then
                '        MsgBox("Please enter Due Date")
                '        Exit Function
                '    End If

                'End If



                Dim cdcarddate As String = ""

                If Not IsNothing(dgvGP.Rows(index).Cells(22).Value) Then
                    If dgvGP.Rows(index).Cells(22).Value.ToString <> "" Then
                        Try
                            Dim format As String = "yyyyMMdd"
                            Dim StartDate As Date

                            cdcarddate = dgvGP.Rows(index).Cells(22).Value.Substring(6, 4) & dgvGP.Rows(index).Cells(22).Value.Substring(3, 2) & dgvGP.Rows(index).Cells(22).Value.Substring(0, 2)
                            StartDate = Date.ParseExact(cdcarddate, format, New Globalization.CultureInfo("en-US"))

                        Catch ex As Exception
                            MsgBox("Card Date not a valid")
                            clsBusiness.gLastErrMessage = "Card Date not a valid"
                            Exit Function
                        End Try
                    End If

                End If

                '�礤�� Flag �Դ��������
                Dim flag As String
                If dgvGP.Rows(index).Cells(27).Value IsNot Nothing AndAlso dgvGP.Rows(index).Cells(27).Value.ToString.ToUpper = "Y" Then '38
                    flag = "Y"
                ElseIf dgvGP.Rows(index).Cells(27).Value IsNot Nothing AndAlso dgvGP.Rows(index).Cells(27).Value.ToString.ToUpper = "N" Then
                    flag = "N"
                Else 'Is unchecked and otherwise.
                    flag = " " 'Set to null value
                End If

                Dim amt As Decimal
                amt = Convert.ToDecimal(dgvGP.Rows(index).Cells(4).Value)

                Dim sb As New StringBuilder()

                sb.Append("INSERT INTO " & tb_name & " VALUES ( ")
                sb.Append("TRIM('" & CreateDate & "'),")
                sb.Append("TRIM('" & CoreSystem & "'),")

                sb.Append("TRIM('" & TransRef & "'),")
                sb.Append("TRIM('" & index + 1.ToString & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(1).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(2).Value & "'),")
                sb.Append("TRIM('" & duedate & "'),")
                sb.Append("TRIM('" & amt & "'),") 'dgvGP.Rows(index).Cells(4).Value 
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(5).Value & "'),")
                sb.Append("TRIM('" & Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) & "'),") 'GPCR_PAYMTH
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(7).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(8).Value & "'),")

                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(9).Value & "'),")
                sb.Append("TRIM('" & bnkbrn & "'),")
                sb.Append("TRIM('" & bnkname & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(12).Value & "'),")
                sb.Append("TRIM('" & Replace(dgvGP.Rows(index).Cells(13).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(14).Value & "'),")
                sb.Append("TRIM('" & Replace(dgvGP.Rows(index).Cells(15).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & Replace(dgvGP.Rows(index).Cells(16).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(17).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(18).Value & "'),")

                If CoreSystem = "ACC" Then
                    sb.Append("TRIM('" & Microsoft.VisualBasic.Left(TransRef, 3) & "'),") 'DatasourceName
                Else
                    sb.Append("TRIM('" & dgvGP.Rows(index).Cells(19).Value & "'),") 'DatasourceName
                End If

                sb.Append("'',")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(21).Value & "'),")
                sb.Append("TRIM('" & cdcarddate & "'),") 'carddate
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(23).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(24).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(25).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(26).Value & "'),")
                sb.Append("TRIM('" & Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) & "'),")
                sb.Append("TRIM('" & flag & "'),")

                sb.Append("TRIM('" & cboOverSea.SelectedValue.ToString & "'),")

                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(28).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(29).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(30).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(31).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(32).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(33).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(34).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(35).Value & "'),")
                sb.Append("TRIM('" & dgvGP.Rows(index).Cells(36).Value & "'),")
                sb.Append("'' ,")
                sb.Append("'',")
                sb.Append("'COMPLETE' ,")
                sb.Append("'N' ,")
                sb.Append("'',")
                sb.Append("'',")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

                Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

            Next

            If Rec = dgvGP.Rows.Count Then
                'oleTrans.Commit()
                ret = True

            Else
                'oleTrans.Rollback()
                ret = False

            End If


        End If


        Return ret

    End Function
    Function SaveTAX(ByVal oleTrans As OleDbTransaction, ByVal tb_name As String, ByVal CreateDate As String, ByVal CoreSystem As String, ByVal TransRef As String) As Boolean
        Dim ret As Boolean = True

        If dgvTax.RowCount > 0 Then
            Dim taxdate As String = ""
            Try
                Dim format As String = "yyyyMMdd"
                Dim StartDate As Date

                taxdate = dgvTax.Rows(0).Cells(12).Value.Substring(6, 4) & dgvTax.Rows(0).Cells(12).Value.Substring(3, 2) & dgvTax.Rows(0).Cells(12).Value.Substring(0, 2)
                StartDate = Date.ParseExact(taxdate, format, New Globalization.CultureInfo("en-US"))

            Catch ex As Exception
                MsgBox("Tax Date not a valid")
                clsBusiness.gLastErrMessage = "Tax Date not a valid"
                Exit Function
            End Try

            Dim Rec As Integer


            For index As Integer = 0 To dgvTax.RowCount - 1
                Dim sb As New StringBuilder()

                'If cboEntryTypeTAX.SelectedIndex = 0 And IsNothing(dgvTax.Rows(index).Cells(12).Value) Then
                '    dgvTax.Rows(index).Cells(12).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")

                'End If


                'If taxdate = "" Then
                '    MsgBox("Please enter Tax Date")
                '    Exit Function
                'End If

                Dim seqno As String

                If cboGroup.SelectedValue.ToString <> "006" Then
                    'If Not IsNothing(dgvTax.Rows(index).Cells(19).Value) AndAlso dgvTax.Rows(index).Cells(19).Value.ToString <> "" Then
                    '    'If String.IsNullOrEmpty(dgvTax.Rows(index).Cells(19).Value) Then
                    '    MsgBox("Please enter GP line in WHT Tab")
                    '    clsBusiness.gLastErrMessage = "Please enter GP line in WHT Tab"
                    '    Exit Function
                    'Else
                    '    'If IsNothing(dgvTax.Rows(index).Cells(19).Value.ToString) Then
                    '    If Not IsNothing(dgvTax.Rows(index).Cells(19).Value) AndAlso dgvTax.Rows(index).Cells(19).Value.ToString <> "" Then
                    '        MsgBox("Please enter GP line in WHT Tab")
                    '        clsBusiness.gLastErrMessage = "Please enter GP line in WHT Tab"
                    '        Exit Function
                    '    Else
                    '        seqno = dgvTax.Rows(index).Cells(19).Value
                    '    End If
                    'End If

                    If Not IsNothing(dgvTax.Rows(index).Cells(19).Value) AndAlso dgvTax.Rows(index).Cells(19).Value.ToString <> "" Then
                        seqno = dgvTax.Rows(index).Cells(19).Value
                    Else
                        MsgBox("Please enter GP line in WHT Tab")
                        clsBusiness.gLastErrMessage = "Please enter GP line in WHT Tab"
                        Exit Function
                    End If

                Else
                    seqno = "0"
                End If

                Dim baseamt As Decimal
                baseamt = Convert.ToDecimal(dgvTax.Rows(index).Cells(13).Value)

                Dim whtamt As Decimal
                whtamt = Convert.ToDecimal(dgvTax.Rows(index).Cells(14).Value)

                Dim idcard As String = ""
                Dim taxid As String = ""

                If Not IsNothing(dgvTax.Rows(index).Cells(1).Value) AndAlso dgvTax.Rows(index).Cells(1).Value.ToString <> "" Then
                    taxid = dgvTax.Rows(index).Cells(1).Value.ToString.Replace(" ", "").Trim
                End If
                If Not IsNothing(dgvTax.Rows(index).Cells(2).Value) AndAlso dgvTax.Rows(index).Cells(2).Value.ToString <> "" Then
                    idcard = dgvTax.Rows(index).Cells(2).Value.ToString.Replace(" ", "").Trim
                End If

                Dim subaccount As String = ""
                If Not IsNothing(dgvTax.Rows(index).Cells(20).Value) AndAlso dgvTax.Rows(index).Cells(20).Value.ToString <> "" Then
                    subaccount = dgvTax.Rows(index).Cells(20).Value
                Else
                    subaccount = "0000000"
                End If

                sb.Append("INSERT INTO " & tb_name & " (")
                sb.Append("TAXCR_CREATEDATE,")
                sb.Append("TAXCR_CORE_SYSTEM,")
                sb.Append("TAXCR_TRANSREF,")
                sb.Append("TAXCR_GPTREF_SEQNO,")
                sb.Append("TAXCR_LINENO,")
                sb.Append("TAXCR_TAXID,")
                sb.Append("TAXCR_IDCARD,")
                sb.Append("TAXCR_AP_TTL,")
                sb.Append("TAXCR_AP_FNAME,")
                sb.Append("TAXCR_AP_LNAME,")
                sb.Append("TAXCR_ADDRESS,")
                sb.Append("TAXCR_AMPENM,")
                sb.Append("TAXCR_PROVNM,")
                sb.Append("TAXCR_AGZIP,")
                sb.Append("TAXCR_TAXTYPE,")
                sb.Append("TAXCR_TAXITEM,")
                sb.Append("TAXCR_TAXDATE,")
                sb.Append("TAXCR_BASE_AMT,")
                sb.Append("TAXCR_TAX_AMT,")
                sb.Append("TAXCR_PAYEE,")
                sb.Append("TAXCR_TAX_RATE,")
                sb.Append("TAXCR_DESC,")
                sb.Append("TAXCR_GL_ACCOUNT,")
                sb.Append("TAXCR_APPROVEDBY,")
                sb.Append("TAXCR_APPROVEDDATE,")
                sb.Append("TAXCR_FLAG_VALIDATE,")
                sb.Append("TAXCR_FLAG_BATCH,")
                sb.Append("TAXCR_BATCHDATE,")
                sb.Append("TAXCR_REJECT_TYPE,")
                sb.Append("CREATEDBY,")
                sb.Append("CREATEDDATE,")
                sb.Append("UPDATEDBY,")
                sb.Append("UPDATEDDATE,")
                sb.Append("TAXCR_SUB_ACCT) ")
                sb.Append(" VALUES ( ")
                sb.Append("TRIM('" & CreateDate & "'),")
                sb.Append("TRIM('" & CoreSystem & "'),")
                sb.Append("TRIM('" & TransRef & "'),")
                sb.Append("TRIM('" & seqno & "'),") 'GPTREF_SEQNO
                sb.Append("TRIM('" & index + 1.ToString & "'),") 'LINE_NO
                sb.Append("TRIM('" & taxid & "'),")
                sb.Append("TRIM('" & idcard & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(3).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(4).Value & "'),")
                sb.Append("TRIM('" & Replace(dgvTax.Rows(index).Cells(5).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & Replace(dgvTax.Rows(index).Cells(6).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & Replace(dgvTax.Rows(index).Cells(7).Value, "'", "''") & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(8).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(9).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(10).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(11).Value & "'),")
                sb.Append("TRIM('" & taxdate & "'),") 'dgvTax.Rows(index).Cells(12).Value
                sb.Append("TRIM('" & baseamt & "'),") 'dgvTax.Rows(index).Cells(13).Value
                sb.Append("TRIM('" & whtamt & "'),") 'dgvTax.Rows(index).Cells(14).Value
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(15).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(16).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(17).Value & "'),")
                sb.Append("TRIM('" & dgvTax.Rows(index).Cells(18).Value & "'),")
                sb.Append("'' ,")
                sb.Append("'',")
                sb.Append("'COMPLETE' ,")
                sb.Append("'N' ,")
                sb.Append("'',")
                sb.Append("'',")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("TRIM('" & gUserLogin & "') ,")
                sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
                sb.Append("TRIM('" & subaccount & "'))")

                Rec = Rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

            Next

            If Rec = dgvTax.Rows.Count Then
                'oleTrans.Commit()
                ret = True

            Else
                'oleTrans.Rollback()
                ret = False

            End If


        End If

        Return ret
    End Function
    Function TempToTable(ByVal oleTrans As OleDbTransaction, ByVal tmptb As String, ByVal tb As String) As Boolean
        Dim ret As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        sb.Append("insert into " & tb & " ")
        sb.Append("select * from " & tmptb & " where createdby='" & gUserLogin & "'")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            ret = True
        Else
            ret = False
        End If
        Return ret
    End Function
    Private Sub btnClearGL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearGL.Click
        Try
            dgvGL.AllowUserToAddRows = False
            If dgvGL.RowCount > 0 Then
                If MessageBox.Show("Do you want to delete this record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    For Each row As DataGridViewRow In dgvGL.SelectedRows
                        dgvGL.Rows.Remove(row)
                    Next

                    CalculateGL()

                End If
            End If
        Catch ex As Exception

        End Try


        ' dgvGL.AllowUserToAddRows = False
    End Sub
    Private Sub btnLoadFileGL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        'Clear All dgvGL
        If MessageBox.Show("Do you want to delete all record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Dim dt As DataTable = Nothing
            Me.GenGridGL(dt)

            lbltxtTotalLine.Text = "0"
            txtAmtDebits.Text = "0.00"
            txtAmtCredits.Text = "0.00"
            txtOutOfBalance.Text = "0.00"
            txtOutOfBalance.ForeColor = Color.Black
        End If
    End Sub
    Private Sub GL_TextFile()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GLPATH_INPUT_ACC")

        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.txt)|*.txt"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLGL.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLGL.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim dt As New DataTable
                Try
                    Dim lineno As Integer
                    dgvGL.AllowUserToAddRows = False
                    If dgvGL.RowCount - 1 > 0 Then
                        lineno = dgvGL.Rows(dgvGL.RowCount - 1).Cells(0).Value
                    Else
                        lineno = 0
                    End If
                    dgvGL.AllowUserToAddRows = True

                    dt = clsBusiness.ReadTextGL(txtTextURLGL.Text, ",", cboJournalType.Text, cboDataSource.Text, dtpDueDate.Value.ToString("yyyyMMdd"), lineno, clsUtility.gConnGP)

                    If Not IsNothing(dt) Then
                        '��䢢������ grid ���ç�Ѻ˹�Ҩ�

                        Dim errSun As String
                        If ValidateSunCodeGL(dt, errSun) = False Then
                            MsgBox(errSun)
                            GenGridGL(Nothing)
                            Exit Sub
                        End If


                        Dim dtGL_TLM As New DataTable
                        dtGL_TLM = GLToTempTLM_TXT(dt)

                        BindTransRef(dt.Rows(0)("TransRef").ToString)
                        BindAccountPeriod(dt.Rows(0)("AccPeriod").ToString)

                        Dim newdt As DataTable
                        newdt = FillDataGL(dt, ".txt")

                        If Not IsNothing(newdt) AndAlso newdt.Rows.Count > 0 Then
                            Dim dataView As New DataView(newdt)

                            dataView.Sort = "LineNo ASC"

                            Dim newlinedt As DataTable
                            newlinedt = dataView.ToTable

                            GenGridGL(newlinedt) 'newdt

                            CalculateGL()
                            'ValidateGL()
                        End If

                    End If

                Catch ex As Exception
                    dt = Nothing
                    GenGridGL(dt)
                    MsgBox("file format is not valid")

                End Try

            End If
        End If

    End Sub
    Private Sub GL_ExcelFile()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GLPATH_INPUT_ACC")

        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Excel File Dialog"
            .Filter = "Text File (*.xls;*.xlsx)|*.xls;*.xlsx"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLGL.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLGL.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If


                Dim dt As New DataTable
                If CheckFormatExcelGL(txtTextURLGL.Text) = False Then
                    MsgBox("file format is not valid")
                    dt = Nothing
                    GenGridGL(dt)
                    Exit Sub
                End If

                Dim lineno As Integer
                dgvGL.AllowUserToAddRows = False
                If dgvGL.RowCount - 1 > 0 Then
                    lineno = dgvGL.Rows(dgvGL.RowCount - 1).Cells(0).Value
                Else
                    lineno = 0
                End If
                dgvGL.AllowUserToAddRows = True

                dt = readExcelGL(txtTextURLGL.Text, clsUtility.gConnGP)


                If dt.Rows.Count > 0 Then
                    Dim errSun As String
                    If ValidateSunCodeGL(dt, errSun) = False Then
                        MsgBox(errSun)
                        GenGridGL(Nothing)
                        Exit Sub
                    End If

                    For Each dr As DataRow In dt.Rows
                        lineno = lineno + 1
                        dr.Item("LineNo") = lineno
                    Next


                    Dim dtGL_Fill As New DataTable
                    dtGL_Fill = GLToTempFill_XLS(dt)

                    'Update Bank No
                    Dim newdt As DataTable
                    newdt = FillDataGL(dt, ".xls")

                    If Not IsNothing(newdt) AndAlso newdt.Rows.Count > 0 Then
                        Dim dataView As New DataView(newdt)

                        dataView.Sort = "LineNo ASC"

                        Dim newlinedt As DataTable
                        newlinedt = dataView.ToTable

                        GenGridGL(newlinedt) 'newdt

                        CalculateGL()
                        ''ValidateGP()
                    End If


                End If


            End If
        End If
    End Sub
    Function ValidateSunCodeGL(ByVal dt As DataTable, ByRef errSun As String) As Boolean
        errSun = ""
        For Each dr As DataRow In dt.Rows
            Dim ret As String
            Dim sAcc As String = ""
            sAcc = IIf(IsDBNull(dr.Item("SunAccCode")), "", dr.Item("SunAccCode"))
            If sAcc <> "" Then
                ret = cls.LookUp_SunAccount(clsUtility.gConnGP, sAcc)
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & " ��辺 Sun Code '" & sAcc & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim sSubAcc As String = ""
            sSubAcc = IIf(IsDBNull(dr.Item("Sub_acct")), "", dr.Item("Sub_acct"))
            If sSubAcc <> "" Then
                ret = cls.LookUp_SunAccount(clsUtility.gConnGP, sSubAcc)
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & " ��辺 Sun SubCode '" & sSubAcc & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim sDept As String = ""
            sDept = IIf(IsDBNull(dr.Item("SunDept")), "", dr.Item("SunDept"))
            If sDept <> "" Then
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sDept, "and anl_type='DEPB'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & " ��辺 Sun Dept/Branch '" & sDept & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim sPLPT As String = ""
            sPLPT = IIf(IsDBNull(dr.Item("SunPLPT")), "", dr.Item("SunPLPT"))
            If sPLPT <> "" Then
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sPLPT, "and anl_type='PLPT'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & "��辺 Sun PL/PT '" & sPLPT & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim sMKTG As String = ""
            sMKTG = IIf(IsDBNull(dr.Item("SunMktg")), "", dr.Item("SunMktg"))
            If sMKTG <> "" Then
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sMKTG, "and anl_type='MKTG'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & "��辺 Sun Mktg/Emp '" & sMKTG & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            '------------Oracle-----------
            Dim oAcc As String = ""
            oAcc = IIf(IsDBNull(dr.Item("OracleAccCode")), "", dr.Item("OracleAccCode"))
            If oAcc <> "" Then
                ret = cls.LookUp_OracleAccount(clsUtility.gConnGP, oAcc)
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & " ��辺 Account Code '" & oAcc & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim oDept As String = ""
            oDept = IIf(IsDBNull(dr.Item("OracleDept")), "", dr.Item("OracleDept"))
            If oDept <> "" Then
                ret = cls.LookUp_OracleCode(clsUtility.gConnGP, oDept, "and anl_type='DEPB'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & " ��辺 Oracle Dept/Branch '" & oDept & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim oPLPT As String = ""
            oPLPT = IIf(IsDBNull(dr.Item("OraclePLPT")), "", dr.Item("OraclePLPT"))
            If oPLPT <> "" Then
                ret = cls.LookUp_OracleCode(clsUtility.gConnGP, oPLPT, "and anl_type='PLPT'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & "��辺 Oracle PL/PT '" & oPLPT & "' ��� Config ��к�" & vbCrLf
                End If
            End If

            Dim oMKTG As String = ""
            oMKTG = IIf(IsDBNull(dr.Item("OracleMktg")), "", dr.Item("OracleMktg"))
            If oMKTG <> "" Then
                ret = cls.LookUp_OracleCode(clsUtility.gConnGP, oMKTG.Substring(0, 3), "and anl_type='MKTG'")
                If ret = "" Then
                    errSun &= "Line:" & dt.Rows.IndexOf(dr) + 1 & "��辺 Oracle Mktg/Emp '" & oMKTG & "' ��� Config ��к�" & vbCrLf
                End If
            End If


        Next

        If errSun = "" Then
            Return True
        Else
            Return False
        End If
    End Function
    Private Sub GP_TextFile()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GPPATH_INPUT_ACC")


        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.txt)|*.txt"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLGP.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLGP.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim dt As New DataTable

                Try
                    dt = clsBusiness.ReadTextGP_Fix(txtTextURLGP.Text, ",")

                    If dt.Rows.Count > 0 Then

                        'Check Duedate
                        Try
                            Dim foundRows() As DataRow
                            foundRows = dt.Select("duedate <> '" & dtpDueDate.Value.ToString("dd/MM/yyyy") & "' ")

                            If foundRows.Length > 0 Then
                                MsgBox("DueDate not match")
                                dt = Nothing
                                GenGridGP(dt)
                                Exit Sub
                            End If
                        Catch ex As Exception

                        End Try


                        If dt.Columns.Contains("GPLine") = False Then
                            dt.Columns.Add("GPLine")
                        End If

                        ''Update Amount Text
                        Dim newdt As DataTable
                        newdt = FillDataGP_TXT(dt)

                        'GenGridGP(dt)
                        GenGridGP(newdt)
                        CalculateGP()

                        'ValidateGP()
                    End If

                Catch ex As Exception
                    dt = Nothing
                    GenGridGP(dt)
                    MsgBox("file format is not valid")
                End Try

                'ValidateGP()

            End If
        End If
    End Sub

    Private Sub GP_TextFile_Draft()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GPPATH_INPUT_ACC")


        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.txt)|*.txt"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLGP.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLGP.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim dt As New DataTable

                Try
                    dt = clsBusiness.ReadTextGP_DRAFT_Fix(txtTextURLGP.Text, ",")

                    If dt.Rows.Count > 0 Then

                        'Check Duedate
                        Try
                            Dim foundRows() As DataRow
                            foundRows = dt.Select("duedate <> '" & dtpDueDate.Value.ToString("dd/MM/yyyy") & "' ")

                            If foundRows.Length > 0 Then
                                MsgBox("DueDate not match")
                                dt = Nothing
                                GenGridGP(dt)
                                Exit Sub
                            End If
                        Catch ex As Exception

                        End Try


                        If dt.Columns.Contains("GPLine") = False Then
                            dt.Columns.Add("GPLine")
                        End If

                        ''Update Amount Text
                        Dim newdt As DataTable
                        newdt = FillDataGP_DRAFT_TXT(dt)

                        'GenGridGP(dt)
                        GenGridGP(newdt)
                        CalculateGP()

                        'ValidateGP()
                    End If

                Catch ex As Exception
                    dt = Nothing
                    GenGridGP(dt)
                    MsgBox("file format is not valid")
                End Try

                'ValidateGP()

            End If
        End If
    End Sub

    Private Sub GP_ExcelFile()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GPPATH_INPUT_ACC")


        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Excel File Dialog"
            .Filter = "Text File (*.xls;*.xlsx)|*.xls;*.xlsx"
            '.Filter = "Text File (*.csv;*.xls;*.xlsx)|*.csv;*.xls;*.xlsx"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLGP.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLGP.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim dt As New DataTable
                clsBusiness.gLastErrMessage = ""
                If CheckFormatExcelGP(txtTextURLGP.Text, cboPayMth.SelectedValue.ToString) = False Then
                    MsgBox("�ٻẺ Format ����� Load ���ç�Ѻ Payment Type ����к� ��سҵ�Ǩ�ͺ" & vbCrLf & clsBusiness.gLastErrMessage)
                    dt = Nothing
                    GenGridGP(dt)
                    Exit Sub
                End If

                dt = readExcelGP(txtTextURLGP.Text, cboPayMth.SelectedValue.ToString)
                If dt.Rows.Count > 0 Then

                    For Each dr As DataRow In dt.Rows

                        Try
                            Dim format As String = "dd/MM/yyyy"
                            Dim sdate As Date

                            If TypeOf dr.Item("DueDate") Is Date Then
                                sdate = dr.Item("DueDate") 'Convert.ToDateTime(dr.Item("DueDate"))
                                dr.Item("DueDate") = sdate.ToString("dd/MM/yyyy")
                            Else
                                Dim d As Date
                                d = Convert.ToDateTime(dr.Item("DueDate"))
                                Try
                                    sdate = Date.ParseExact(d.ToString("dd/MM/yyyy"), format, New Globalization.CultureInfo("en-US")) ' Convert.ToDateTime(dr.Item("DueDate"))
                                    dr.Item("DueDate") = sdate.ToString("dd/MM/yyyy")
                                Catch ex As Exception
                                    dr.Item("DueDate") = d.ToString("dd/MM/yyyy")
                                End Try
                            End If

                        Catch ex As Exception

                        End Try
                    Next
                    Try
                        'Check Transref
                        Dim foundRows() As DataRow
                        foundRows = dt.Select("transref <> '" & txtTransRef.Text.Trim & "' ")

                        If foundRows.Length > 0 Then
                            MsgBox("Transref not match")
                            dt = Nothing
                            GenGridGP(dt)
                            Exit Sub
                        End If
                    Catch ex As Exception

                    End Try
                    Try
                        'Check Duedate
                        Dim foundRows() As DataRow
                        foundRows = dt.Select("duedate <> '" & dtpDueDate.Value.ToString("dd/MM/yyyy") & "' ")

                        If foundRows.Length > 0 Then
                            MsgBox("DueDate not match")
                            dt = Nothing
                            GenGridGP(dt)
                            Exit Sub
                        End If
                    Catch ex As Exception

                    End Try


                    'Add column to datatable prepare fill data to grid
                    If dt.Columns.Contains("BankCode") = False Then
                        dt.Columns.Add("BankCode")
                    End If
                    If dt.Columns.Contains("BankNumber") = False Then
                        dt.Columns.Add("BankNumber")
                    End If
                    If dt.Columns.Contains("BankName") = False Then
                        dt.Columns.Add("BankName")
                    End If
                    If dt.Columns.Contains("GPLine") = False Then
                        dt.Columns.Add("GPLine")
                    End If
                    If dt.Columns.Contains("PaymentType") = False Then
                        dt.Columns.Add("PaymentType")
                    End If
                    If dt.Columns.Contains("BankBranch") = False Then
                        dt.Columns.Add("BankBranch")
                    End If
                    If dt.Columns.Contains("DataSource") = False Then
                        dt.Columns.Add("DataSource")
                    End If
                    If dt.Columns.Contains("SubPaymentType") = False Then
                        dt.Columns.Add("SubPaymentType")
                    End If
                    If dt.Columns.Contains("Sys_Ref") = False Then
                        dt.Columns.Add("Sys_Ref")
                    End If
                    If dt.Columns.Contains("Sys_Gr") = False Then
                        dt.Columns.Add("Sys_Gr")
                    End If


                    'Update Bank No
                    Dim newdt As DataTable
                    newdt = FillDataGP(dt)

                    GenGridGP(newdt)
                    CalculateGP()
                    'ValidateGP()

                End If


            End If
        End If
    End Sub
    Private Sub TAX_ExcelFile()

        Dim descpath As String
        descpath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "WHTPATH_INPUT_ACC")


        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            '.Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Excel File Dialog"
            .Filter = "Text File (*.xls;*.xlsx)|*.xls;*.xlsx"
            .FilterIndex = 0
            .InitialDirectory = descpath
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURLTax.Text = OpenFileDialog1.FileName

                If IsFileOpen(txtTextURLTax.Text.Trim) Then
                    MsgBox("�������ö��Ŵ file �� ���ͧ�ҡ�ռ����ҹ���� ��سҵ�Ǩ�ͺ", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim dt As New DataTable

                If CheckFormatExcelTAX(txtTextURLTax.Text) = False Then
                    MsgBox("file format is not valid " & clsBusiness.gLastErrMessage)
                    dt = Nothing
                    GenGridTax(dt)
                    Exit Sub
                End If

                Try
                    'PATTAMALIN 1025/01/29
                    Dim lineno As Integer
                    dgvTax.AllowUserToAddRows = False
                    If dgvTax.RowCount > 0 Then
                        lineno = dgvTax.Rows(dgvTax.RowCount - 1).Cells(0).Value
                    Else
                        lineno = 0
                    End If
                    dgvTax.AllowUserToAddRows = True



                    dt = readExcelTAX(txtTextURLTax.Text, clsUtility.gConnGP)
                    If dt.Rows.Count > 0 Then

                        For Each dr As DataRow In dt.Rows

                            lineno = lineno + 1
                            dr.Item("LineNo") = lineno

                            'Bind DueDate
                            Dim txt_duedate As String '17062014
                            txt_duedate = dr.Item("TaxDate").ToString.Substring(6, 2) & "/" & dr.Item("TaxDate").ToString.Substring(4, 2) & "/" & dr.Item("TaxDate").ToString.Substring(0, 4)

                            dr.Item("TaxDate") = txt_duedate
                        Next

                        Try
                            'Check Transref
                            Dim foundRows() As DataRow
                            foundRows = dt.Select("TransRef <> '" & txtTransRef.Text.Trim & "' ")

                            If foundRows.Length > 0 Then
                                MsgBox("Transref not match")
                                dt = Nothing
                                GenGridTax(dt)
                                Exit Sub
                            End If
                        Catch ex As Exception

                        End Try

                        Try
                            Dim foundRows() As DataRow
                            foundRows = dt.Select("TaxDate <> '" & dtpDueDate.Value.ToString("dd/MM/yyyy") & "' ")

                            If foundRows.Length > 0 Then
                                MsgBox("Tax Date not match")
                                dt = Nothing
                                GenGridTax(dt)
                                Exit Sub
                            End If
                        Catch ex As Exception

                        End Try


                        If dt.Columns.Contains("GPLine") = False Then
                            dt.Columns.Add("GPLine")
                        End If

                        If dt.Columns.Contains("CheckName") = False Then
                            dt.Columns.Add("CheckName")
                        End If

                        Dim dtTAX_FILL As New DataTable
                        dtTAX_FILL = TAXToTempFill_XLS(dt)


                        'Update Bank No
                        Dim newdt As DataTable
                        newdt = FillDataTAX(dt)

                        'GenGridTax(newdt)
                        'CalculateTAX()

                        If Not IsNothing(newdt) AndAlso newdt.Rows.Count > 0 Then
                            Dim dataView As New DataView(newdt)

                            dataView.Sort = "LineNo ASC"

                            Dim newlinedt As DataTable
                            newlinedt = dataView.ToTable

                            GenGridTax(newlinedt) 'newdt

                            CalculateTAX()
                            FormatLoadTaxGPLine()
                        End If


                    End If

                Catch ex As Exception
                    dt = Nothing
                    GenGridTax(dt)
                    MsgBox(ex.ToString)
                End Try

                'ValidateGL()
            End If
        End If
    End Sub
    Private Sub btnBrowseGL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseGL.Click

        If cboEntryType.Text = "Text File" Then
            GL_TextFile()
        ElseIf cboEntryType.Text = "Excel File" Then
            GL_ExcelFile()
        End If

        'TabControl1.TabPages(2).Enabled = False
        'TabControl1.TabPages(2).BackColor = Color.LightGray

    End Sub
    Private Function CheckFormatExcelGL(ByVal txtExcelURL As String) As Boolean
        Dim ret As Boolean = True
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try


            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            If myvalues(1, 1).ToString.Trim.ToUpper <> "Transaction Ref.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 1) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 2).ToString.Trim.ToUpper <> "Line No.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 2) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 3).ToString.Trim.ToUpper <> "Transaction Date".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 3) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 4).ToString.Trim.ToUpper <> "Due Date".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 4) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 5).ToString.Trim.ToUpper <> "Description".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 5) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 6).ToString.Trim.ToUpper <> "Account Code".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 6) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 7).ToString.Trim.ToUpper <> "Account Name".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 7) & " is not valid"
                Exit Function
            End If
            'If myvalues(1, 8).ToString.Trim.ToUpper <> "Amount".ToUpper Then
            '    ret = False
            '    clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 8) & " is not valid"
            '    Exit Function
            'End If
            If myvalues(1, 9).ToString.Trim.ToUpper <> "Dr / Cr".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 9) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 10).ToString.Trim.ToUpper <> "Transaction Analysis Code (T Code)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 10) & " is not valid"
                Exit Function
            End If
            If myvalues(1, 17).ToString.Trim.ToUpper <> "Accounting Flexfield (Oracle)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(1, 17) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 3).ToString.Trim.ToUpper <> "(DD/MM/YYYY)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 3) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 4).ToString.Trim.ToUpper <> "(DD/MM/YYYY)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 4) & " is not valid"
                Exit Function
            End If



            If myvalues(2, 9).ToString.Trim.ToUpper <> "(D / C)".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 9) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 10).ToString.Trim.ToUpper <> "Dept. + Branch".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 10) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 11).ToString.Trim.ToUpper <> "PL+PT".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 11) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 12).ToString.Trim.ToUpper <> "MKT+EMP ID.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 12) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 13).ToString.Trim.ToUpper <> "Project".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 13) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 14).ToString.Trim.ToUpper <> "Tax Type+Tax Rate".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 14) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 15).ToString.Trim.ToUpper <> "Payment Type".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 15) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 16).ToString.Trim.ToUpper <> "Payment To".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 16) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 17).ToString.Trim.ToUpper <> "Account Code".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 17) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 18).ToString.Trim.ToUpper <> "Dept. + Branch".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 18) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 19).ToString.Trim.ToUpper <> "PL+PT".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 19) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 20).ToString.Trim.ToUpper <> "MKT+EMP ID.".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 20) & " is not valid"
                Exit Function
            End If
            If myvalues(2, 21).ToString.Trim.ToUpper <> "Project".ToUpper Then
                ret = False
                clsBusiness.gLastErrMessage = "Column name : " & myvalues(2, 21) & " is not valid"
                Exit Function
            End If
        Catch ex As Exception
            'MsgBox("file format is not valid")
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
            ret = False
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    Private Function CheckFormatExcelGP(ByVal txtExcelURL As String, ByVal payment_subpayment As String) As Boolean
        Dim ret As Boolean = False
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)
        Dim columncount As Integer
        Try

            dataTableGP = New DataTable
            Select Case payment_subpayment
                '"SCB M Cheque", "Company Cheque", "SCB Cashier Cheque"
                Case "C:C", "C:Q", "C:H"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"SCB M Draft", "Bank Draft"
                Case "D:D", "C:B"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("District")
                    dataTableGP.Columns.Add("Province")
                    columncount = 7
                    '"Media Clearing", "ATS �ͧ SCB"
                Case "M:M", "M:A"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("PayeeBank Account")
                    dataTableGP.Columns.Add("PayeeBank AccName")
                    columncount = 8
                    '"Credit Card (�ѵ��ôԵ)"
                Case "M:C"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("PayeeBank Account")
                    dataTableGP.Columns.Add("PayeeBank AccName")
                    dataTableGP.Columns.Add("Reserve7(������ҹ)")
                    dataTableGP.Columns.Add("Reserve8(DueDate)")
                    columncount = 10
                    '"SCB Gift Cheque (�礢ͧ��ѭ)"
                Case "C:G"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"Money Order (��ҳѵ�)"
                Case "C:T"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"�͹�Թ��ҧ�����"
                Case "M:B"
                    dataTableGP.Columns.Add("Transaction Reference")
                    dataTableGP.Columns.Add("PolicyNo")
                    dataTableGP.Columns.Add("BillNo")
                    dataTableGP.Columns.Add("DueDate(DD/MM/YYYY)")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PaymentType")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("BankNumber")
                    dataTableGP.Columns.Add("BankBranch")
                    dataTableGP.Columns.Add("BankName")
                    dataTableGP.Columns.Add("PayeeBank Account")
                    dataTableGP.Columns.Add("PayeeBank AccName")
                    dataTableGP.Columns.Add("Comment")
                    dataTableGP.Columns.Add("Address1")
                    dataTableGP.Columns.Add("District")
                    dataTableGP.Columns.Add("Province")
                    dataTableGP.Columns.Add("InsureName")
                    dataTableGP.Columns.Add("DataSource")
                    dataTableGP.Columns.Add("Reserve6")
                    dataTableGP.Columns.Add("Reserve7")
                    dataTableGP.Columns.Add("Reserve8")
                    dataTableGP.Columns.Add("Reserve9")
                    dataTableGP.Columns.Add("Reserve10")
                    dataTableGP.Columns.Add("Section")
                    dataTableGP.Columns.Add("Pay Type")

                    columncount = 27
            End Select


            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            'For rowIndex As Integer = 1 To oSheet.UsedRange.Rows.Count()
            Dim rowIndex As Integer = 1

            rowNew = dataTableGP.NewRow
            firstColumnIsNothing = False
            For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count() 'columncount
                'If myvalues(rowIndex, columnIndex) Is Nothing Then
                '    firstColumnIsNothing = False
                '    Exit For
                If myvalues(rowIndex, columnIndex) Is Nothing Then
                    'rowNew.Item(columnIndex - 1) = ""
                    Exit For
                Else
                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                End If
            Next
            If firstColumnIsNothing = False Then
                dataTableGP.Rows.Add(rowNew)
            End If

            dataTableGP.AcceptChanges()
            If dataTableGP.Rows.Count > 0 Then
                For Each row As DataRow In dataTableGP.Rows
                    For i As Integer = 0 To dataTableGP.Columns.Count - 1
                        Dim cname, rname As String
                        cname = dataTableGP.Columns(i).ColumnName()
                        rname = row.Item(i)
                        If cname.ToUpper = rname.ToUpper Then
                            ret = True
                        Else
                            ret = False
                            clsBusiness.gLastErrMessage = "Column name : " & rname & " <> " & cname
                            Exit Function
                        End If
                    Next
                Next
            End If
            ret = True
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
            ret = False
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    Private Function CheckFormatExcelTAX(ByVal txtExcelURL As String) As Boolean
        Dim ret As Boolean = False
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)
        Dim columncount As Integer
        Try

            dataTableTAX = New DataTable

            dataTableTAX.Columns.Add("LINE NO")
            dataTableTAX.Columns.Add("TAX ID")
            dataTableTAX.Columns.Add("ID CARD")
            dataTableTAX.Columns.Add("AP TITLE")
            dataTableTAX.Columns.Add("AP NAME")
            dataTableTAX.Columns.Add("AP LAST NAME")
            dataTableTAX.Columns.Add("ADDRESS")
            dataTableTAX.Columns.Add("AMPENM")
            dataTableTAX.Columns.Add("PROVNM")
            dataTableTAX.Columns.Add("AGZIP")
            dataTableTAX.Columns.Add("TAX TYPE")
            dataTableTAX.Columns.Add("TAX ITEM")
            dataTableTAX.Columns.Add("TAXDATE")
            dataTableTAX.Columns.Add("BASE AMOUNT")
            dataTableTAX.Columns.Add("WHT AMOUNT")
            dataTableTAX.Columns.Add("PAYEE")
            dataTableTAX.Columns.Add("TAX RATE")
            dataTableTAX.Columns.Add("DESCRIPTION")
            dataTableTAX.Columns.Add("ACOUNT CODE")
            dataTableTAX.Columns.Add("Transaction Reference")

            columncount = 20



            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            'For rowIndex As Integer = 1 To oSheet.UsedRange.Rows.Count()
            Dim rowIndex As Integer = 1

            rowNew = dataTableTAX.NewRow
            firstColumnIsNothing = False
            For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count() 'columncount
                'If myvalues(rowIndex, columnIndex) Is Nothing Then
                '    firstColumnIsNothing = False
                '    Exit For
                If myvalues(rowIndex, columnIndex) Is Nothing Then
                    'rowNew.Item(columnIndex - 1) = ""
                    Exit For
                Else
                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                End If
            Next
            If firstColumnIsNothing = False Then
                dataTableTAX.Rows.Add(rowNew)
            End If

            dataTableTAX.AcceptChanges()
            If dataTableTAX.Rows.Count > 0 Then
                For Each row As DataRow In dataTableTAX.Rows
                    For i As Integer = 0 To dataTableTAX.Columns.Count - 1
                        Dim cname, rname As String
                        cname = dataTableTAX.Columns(i).ColumnName()
                        rname = row.Item(i)
                        If cname.ToUpper = rname.ToUpper Then
                            ret = True
                        Else
                            ret = False
                            clsBusiness.gLastErrMessage = "Column name : " & rname & " <> " & cname
                            Exit Function
                        End If
                    Next
                Next
            End If
            ret = True
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
            ret = False
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return ret

    End Function
    Private Function readExcelGL(ByVal txtExcelURL As String, ByRef ConnDB As OleDbConnection) As DataTable
        '-- 1GL --
        Dim clsGLM_ACCOUNT_SETUP As New DataClass.clsGLM_ACCOUNT_SETUP
        Dim clsGLM_ANLCODE_SETUP As New DataClass.clsGLM_ANLCODE_SETUP
        clsGLM_ACCOUNT_SETUP.ConnDB = ConnDB
        clsGLM_ANLCODE_SETUP.ConnDB = ConnDB
        '-- 1GL --
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-GB")
        oXL = New Excel.Application

        oBook = oXL.Workbooks.Open(txtExcelURL)
        Dim columncount As Integer
        Try

            dataTableGL = New DataTable


            dataTableGL.Columns.Add("TransRef") '-- 0
            dataTableGL.Columns.Add("LineNo", GetType(Integer)) '-- 1
            dataTableGL.Columns.Add("TransDate") '-- 2
            dataTableGL.Columns.Add("DueDate") '-- 3
            dataTableGL.Columns.Add("Description") '-- 4
            dataTableGL.Columns.Add("SunAccCode") '-- 6
            dataTableGL.Columns.Add("SunAccName") '-- 5
            dataTableGL.Columns.Add("Amount") '-- 7
            dataTableGL.Columns.Add("DC") '-- 8
            'Sun Code
            dataTableGL.Columns.Add("SunDept") '-- 9
            dataTableGL.Columns.Add("SunPLPT") '-- 10
            dataTableGL.Columns.Add("SunMktg") '-- 11
            dataTableGL.Columns.Add("SunProjectCode") '-- 12
            dataTableGL.Columns.Add("SunTTTR") '-- 13
            dataTableGL.Columns.Add("PaymentType") '-- 14
            dataTableGL.Columns.Add("PayeeName") '-- 15
            'Oracle Code
            dataTableGL.Columns.Add("OracleAccCode") '-- 16
            dataTableGL.Columns.Add("OracleDept") '-- 17
            dataTableGL.Columns.Add("OraclePLPT") '-- 18
            dataTableGL.Columns.Add("OracleMktg") '-- 19
            dataTableGL.Columns.Add("OracleProjectCode") '-- 20

            dataTableGL.Columns.Add("Conversion_type") '-- 21
            dataTableGL.Columns.Add("Conversion_rate") '-- 22
            dataTableGL.Columns.Add("Conversion_date") '-- 23
            dataTableGL.Columns.Add("Line_trx_ref1") '-- 24
            dataTableGL.Columns.Add("Line_trx_ref2") '-- 25
            dataTableGL.Columns.Add("Line_trx_ref3") '-- 26
            dataTableGL.Columns.Add("Analysis") '-- 27
            dataTableGL.Columns.Add("Intercompany") '--28 
            dataTableGL.Columns.Add("Spare1") '-- 29
            dataTableGL.Columns.Add("Treaty_code") '-- 30
            dataTableGL.Columns.Add("Event_code") '-- 31
            dataTableGL.Columns.Add("Local3") '-- 32
            dataTableGL.Columns.Add("Local4") '-- 33
            dataTableGL.Columns.Add("Ref_1") '-- 34
            dataTableGL.Columns.Add("Ref_2") '-- 35
            dataTableGL.Columns.Add("Ref_3") '-- 36
            dataTableGL.Columns.Add("Ref_4") '-- 37
            dataTableGL.Columns.Add("Ref_5") '-- 38
            dataTableGL.Columns.Add("Ref_6") '-- 39
            dataTableGL.Columns.Add("Ref_7") '-- 40
            dataTableGL.Columns.Add("Ref_8") '-- 41
            dataTableGL.Columns.Add("Ref_9") '-- 42
            dataTableGL.Columns.Add("Ref_10") '-- 43
            dataTableGL.Columns.Add("To_ledger") '--44

            dataTableGL.Columns.Add("Sub_acct") '-- 45

            columncount = 45

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"

            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 3 To oSheet.UsedRange.Rows.Count()
                rowNew = dataTableGL.NewRow
                firstColumnIsNothing = False
                If myvalues(rowIndex, 1) Is Nothing Then
                    firstColumnIsNothing = True
                    Exit For
                End If

                For columnIndex As Integer = 1 To columncount 'oSheet.UsedRange.Columns.Count()
                    If myvalues(rowIndex, 2) Is Nothing Then
                        myvalues(rowIndex, 2) = 0
                    End If

                    '-- ONE GL --
                    Select Case columnIndex
                        Case 1 To 20
                            If myvalues(rowIndex, 1) Is Nothing Then
                                firstColumnIsNothing = True
                                Exit For
                            ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                                rowNew.Item(columnIndex - 1) = ""
                            Else
                                rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim
                            End If

                            'Split a Account Code
                            If columnIndex = 6 Then
                                '--If myvalues(rowIndex, columnIndex).ToString.Trim.Length > 7 Then
                                If myvalues(rowIndex, columnIndex).ToString.Trim.Length > 7 And myvalues(rowIndex, columnIndex).ToString.Trim.Length < 14 Then
                                    '--rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(0, 7) '-- SunAccCode
                                    '--rowNew.Item(columncount) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(7)  '-- Sub_acct
                                    rowNew.Item(columnIndex - 1) = clsGLM_ACCOUNT_SETUP.Get_1Gl_Account_By_S_CODE(myvalues(rowIndex, columnIndex).ToString.Trim) '-- SunAccCode
                                    rowNew.Item(45) = clsGLM_ACCOUNT_SETUP.Get_1Gl_SubAccount_By_S_CODE(myvalues(rowIndex, columnIndex).ToString.Trim) '-- Sub_acct
                                ElseIf myvalues(rowIndex, columnIndex).ToString.Trim.Length = 14 Then
                                    '-- 1GL code --
                                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(0, 7) '-- SunAccCode
                                    rowNew.Item(45) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(7, 7) '-- SunAccCode
                                Else
                                    rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim '-- SunAccCode
                                    rowNew.Item(45) = "" '-- Sub_acct
                                End If
                            End If
                            '-- sun marketing-emp
                            If columnIndex = 12 Then
                                rowNew.Item(40) = myvalues(rowIndex, columnIndex).ToString.Trim '-- SunMktg
                            End If
                            '-- sun project
                            If columnIndex = 13 Then
                                rowNew.Item(columnIndex - 1) = clsGLM_ANLCODE_SETUP.Get_1Gl_Project_By_PROJ(myvalues(rowIndex, columnIndex).ToString.Trim) '-- CurrentRow(24).ToString.Trim '-- SunProjectCode
                            End If
                            'Case 21 '-- Project : OracleProjectCode
                            '--rowNew.Item(columnIndex - 1) = clsGLM_ANLCODE_SETUP.Get_1Gl_Project_By_PROJ(myvalues(rowIndex, columnIndex).ToString.Trim) '-- CurrentRow(24).ToString.Trim '-- SunProjectCode
                        Case 22 '-- Conversion_type
                            rowNew.Item(columnIndex - 1) = "User"
                        Case 23 '-- Conversion_rate
                            rowNew.Item(columnIndex - 1) = "1.0000"
                        Case 24 '-- Conversion_date
                            rowNew.Item(columnIndex - 1) = Now.ToString("yyyyMMdd")
                        Case 28 '-- AnalysisCode
                            rowNew.Item(columnIndex - 1) = "0000"
                        Case 29 '-- Intercompany
                            rowNew.Item(columnIndex - 1) = "0000"
                        Case 30 '-- Spare1
                            rowNew.Item(columnIndex - 1) = "0000"
                        Case 31 '-- Treaty_code
                            rowNew.Item(columnIndex - 1) = "0000000"
                        Case 32 '-- Event_code
                            rowNew.Item(columnIndex - 1) = "000000"
                        Case 33 '-- Local3
                            rowNew.Item(columnIndex - 1) = "00"
                        Case 34 '-- Local4
                            rowNew.Item(columnIndex - 1) = "00"
                        Case 25 To 27, 35 To 39, 41 To 44 '-- Line_trx_ref1-Line_trx_ref3, Ref_1-Ref_10
                            rowNew.Item(columnIndex - 1) = ""

                        Case 40 '-- Ref_6
                            '-- Update ref_6 20201202
                            rowNew.Item(columnIndex - 1) = rowNew.Item(11) '-- Mktg-Emp 

                        Case 45 '-- To_ledger
                            rowNew.Item(columnIndex - 1) = "GCOMN"
                        Case Else
                            rowNew.Item(columnIndex - 1) = ""
                    End Select
                    '-- ONE GL --
                Next
                If firstColumnIsNothing = False Then
                    dataTableGL.Rows.Add(rowNew)
                End If
            Next
            dataTableGL.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableGL
    End Function
    Private Function readExcelGP(ByVal txtExcelURL As String, ByVal payment_subpayment As String) As DataTable
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application

        oBook = oXL.Workbooks.Open(txtExcelURL)
        Dim columncount As Integer
        Try

            dataTableGP = New DataTable

            Select Case payment_subpayment
                '"SCB M Cheque", "Company Cheque", "SCB Cashier Cheque"
                Case "C:C", "C:Q", "C:H"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"SCB M Draft", "Bank Draft"
                Case "D:D", "C:B"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("District")
                    dataTableGP.Columns.Add("Province")
                    columncount = 7
                    '"Media Clearing", "ATS �ͧ SCB"
                Case "M:M", "M:A"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("PayeeBankAccNo")
                    dataTableGP.Columns.Add("PayeeBankAccName")
                    columncount = 8
                    '"Credit Card (�ѵ��ôԵ)"
                Case "M:C"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("PayeeBankAccNo")
                    dataTableGP.Columns.Add("PayeeBankAccName")
                    dataTableGP.Columns.Add("MerchartNo")
                    dataTableGP.Columns.Add("TransCard")
                    columncount = 10
                    '"SCB Gift Cheque (�礢ͧ��ѭ)"
                Case "C:G"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"Money Order (��ҳѵ�)"
                Case "C:T"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PayeeName")
                    columncount = 5
                    '"�͹�Թ��ҧ�����"
                Case "M:B"
                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("PolNo")
                    dataTableGP.Columns.Add("BillNo")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount")
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PaymentType")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("BankNumber")
                    dataTableGP.Columns.Add("BankBranch")
                    dataTableGP.Columns.Add("BankName")
                    dataTableGP.Columns.Add("PayeeBankAccNo")
                    dataTableGP.Columns.Add("PayeeBankAccName")
                    dataTableGP.Columns.Add("Comment")
                    dataTableGP.Columns.Add("Address1")
                    dataTableGP.Columns.Add("District")
                    dataTableGP.Columns.Add("Province")
                    dataTableGP.Columns.Add("InsureName")
                    dataTableGP.Columns.Add("DataSource")
                    dataTableGP.Columns.Add("Reserve6")
                    dataTableGP.Columns.Add("Reserve7")
                    dataTableGP.Columns.Add("Reserve8")
                    dataTableGP.Columns.Add("Reserve9")
                    dataTableGP.Columns.Add("Reserve10")
                    dataTableGP.Columns.Add("Sys_Ref")
                    dataTableGP.Columns.Add("Sys_Gr")
                    columncount = 27

            End Select

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"


            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
                rowNew = dataTableGP.NewRow
                firstColumnIsNothing = False
                If myvalues(rowIndex, 1) Is Nothing Then
                    firstColumnIsNothing = True
                    Exit For
                End If

                For columnIndex As Integer = 1 To columncount 'oSheet.UsedRange.Columns.Count()
                    If myvalues(rowIndex, 1) Is Nothing Then
                        firstColumnIsNothing = True
                        Exit For
                    ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                        rowNew.Item(columnIndex - 1) = ""
                    Else
                        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim
                    End If
                Next
                If firstColumnIsNothing = False Then
                    dataTableGP.Rows.Add(rowNew)
                End If
            Next
            dataTableGP.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableGP
    End Function
    Private Sub btnConvert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConvert.Click
        Try


            dgvGL.AllowUserToAddRows = False
            For index As Integer = 0 To dgvGL.RowCount - 1
                Dim oDept As String
                Dim oPLPT As String
                Dim oMKTG As String
                Dim oAcc As String
                If Not IsNothing(dgvGL.Rows(index).Cells(17).Value) AndAlso dgvGL.Rows(index).Cells(17).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(17).Value, "-", "")
                    oDept = String.Format("{0}-{1}", a.Substring(0, 6), a.Substring(6, 3))
                Else
                    oDept = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(18).Value) AndAlso dgvGL.Rows(index).Cells(18).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(18).Value, "-", "")
                    oPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 2))
                Else
                    oPLPT = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(19).Value) AndAlso dgvGL.Rows(index).Cells(19).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(19).Value, "-", "")
                    oMKTG = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))
                Else
                    oMKTG = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(16).Value) AndAlso dgvGL.Rows(index).Cells(16).Value.ToString <> "" Then

                    oAcc = dgvGL.Rows(index).Cells(16).Value.ToString
                Else
                    oAcc = ""
                End If


                If dgvGL.Rows(index).Cells(5).Value.ToString = "" And oAcc <> "" Then
                    Dim ret As String
                    ret = cls.LookUp_ACCSetUp(clsUtility.gConnGP, oAcc)
                    If ret <> "" Then
                        dgvGL.Rows(index).Cells(5).Value = ret
                        dgvGL.Rows(index).Cells(6).Value = cls.LookUp_ACCName(clsUtility.gConnGP, dgvGL.Rows(index).Cells(5).Value.ToString)
                    Else
                        MsgBox("Line : " & index + 1 & " ��辺������ Account Code '" & ret & "' ��� Config ��к�")
                    End If

                End If
                If dgvGL.Rows(index).Cells(9).Value.ToString = "" And oDept <> "" Then
                    Dim ret As String
                    ret = cls.LookUp_ANLSetUp(clsUtility.gConnGP, oDept, "and anl_type='DEPB'")
                    If ret <> "" Then
                        dgvGL.Rows(index).Cells(9).Value = ret
                    Else
                        MsgBox("Line : " & index + 1 & " ��辺������ Dept/Br '" & oDept & "' ��� Config ��к�")
                    End If

                End If
                If dgvGL.Rows(index).Cells(10).Value.ToString = "" And oPLPT <> "" Then
                    Dim ret As String
                    ret = cls.LookUp_ANLSetUp(clsUtility.gConnGP, oPLPT, "and anl_type='PLPT'")
                    If ret <> "" Then
                        dgvGL.Rows(index).Cells(10).Value = ret
                    Else
                        MsgBox("Line : " & index + 1 & " ��辺������ PL/PT '" & oPLPT & "' ��� Config ��к�")
                    End If

                End If
                If dgvGL.Rows(index).Cells(11).Value.ToString = "" And oMKTG <> "" Then
                    Dim ret As String
                    ret = cls.LookUp_ANLSetUp(clsUtility.gConnGP, oMKTG.Substring(0, 3), "and anl_type='MKTG' and (anl_pd_Line like '%" & oPLPT.Substring(0, 1) & "%' or anl_pd_Line is null) ")
                    If ret <> "" Then
                        dgvGL.Rows(index).Cells(11).Value = ret
                    Else
                        MsgBox("Line : " & index + 1 & " ��辺������ Mktg/Emp '" & oMKTG & "' ��� Config ��к�")
                    End If

                End If


            Next

            dgvGL.AllowUserToAddRows = True
        Catch ex As Exception

        End Try
    End Sub
    Private Sub dgvGL_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvGL.CellEndEdit

        Try


            CalculateGL()

            dgvGL.AllowUserToAddRows = False

            Dim iRow = dgvGL.CurrentCell.RowIndex

            If Not IsNothing(dgvGL.Rows(iRow).Cells(5).Value) AndAlso dgvGL.Rows(iRow).Cells(5).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(5).Value.ToString.Length <> "7" Then
                    MsgBox("��سҡ�͡���ú 7 ��ѡ")
                    dgvGL.Rows(iRow).Cells(5).Value = ""
                    dgvGL.Rows(iRow).Cells(6).Value = ""
                    Exit Sub
                Else
                    Dim ret As String
                    ret = cls.LookUp_ACCName(clsUtility.gConnGP, dgvGL.Rows(iRow).Cells(5).Value.ToString)
                    If ret = "" Then
                        MsgBox("��辺 Account Code ��� Config ��к�")
                        dgvGL.Rows(iRow).Cells(5).Value = ""
                        dgvGL.Rows(iRow).Cells(6).Value = ""
                    Else
                        dgvGL.Rows(iRow).Cells(6).Value = ret
                    End If

                End If
            Else
                dgvGL.Rows(iRow).Cells(6).Value = ""
            End If
            'If Not String.IsNullOrEmpty(dgvGL.Rows(iRow).Cells(7).Value) Then
            If Not IsNothing(dgvGL.Rows(iRow).Cells(7).Value) AndAlso dgvGL.Rows(iRow).Cells(7).Value.ToString <> "" Then
                Dim amt As Decimal
                amt = Convert.ToDecimal(dgvGL.Rows(iRow).Cells(7).Value)
                dgvGL.Rows(iRow).Cells(7).Value = amt.ToString("###,###.00")
            End If

            'If Not String.IsNullOrEmpty(dgvGL.Rows(iRow).Cells(8).Value) Then
            If Not IsNothing(dgvGL.Rows(iRow).Cells(8).Value) AndAlso dgvGL.Rows(iRow).Cells(8).Value.ToString <> "" Then
                Dim dr As String = dgvGL.Rows(iRow).Cells(8).Value.ToString.ToUpper
                If (dr <> "D") And (dr <> "C") Then
                    MsgBox("��س� Dr/Cr��੾�� D ���� C ��ҹ��")
                    dgvGL.Rows(iRow).Cells(8).Value = ""
                    dgvGL.Rows(iRow).Cells(8).Selected = True
                Else
                    dgvGL.Rows(iRow).Cells(8).Value = dr
                End If
            ElseIf IsNothing(dgvGL.Rows(iRow).Cells(8).Value) AndAlso dgvGL.CurrentCell.ColumnIndex > 7 Then
                MsgBox("��س� Dr/Cr ���ú��ǹ�١��ͧ")
                dgvGL.Rows(iRow).Cells(8).Value = ""
                dgvGL.Rows(iRow).Cells(8).Selected = True
            End If

            'Dept Branch
            If Not IsNothing(dgvGL.Rows(iRow).Cells(9).Value) AndAlso dgvGL.Rows(iRow).Cells(9).Value.ToString <> "" Then
                'If dgvGL.Rows(iRow).Cells(9).Value.ToString.Length < "7" Then
                '    MsgBox("��سҡ�͡���ú 7 ��ѡ")
                '    dgvGL.Rows(iRow).Cells(9).Value = ""
                '    Exit Sub
                'Else

                Dim a, sDept As String

                'a = Replace(dgvGL.Rows(iRow).Cells(9).Value, "-", "")
                'sDept = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 4))

                sDept = dgvGL.Rows(iRow).Cells(9).Value.ToString()
                Dim ret As String
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sDept, "and anl_type='DEPB'")

                If ret = "" Then
                    MsgBox("��辺 Dept/Branch ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(9).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(9).Value = ret
                End If

                'End If
            End If
            'PLPT
            If Not IsNothing(dgvGL.Rows(iRow).Cells(10).Value) AndAlso dgvGL.Rows(iRow).Cells(10).Value.ToString <> "" Then
                'If dgvGL.Rows(iRow).Cells(10).Value.ToString.Length < "4" Then
                '    MsgBox("��سҡ�͡���ú 4 ��ѡ")
                '    dgvGL.Rows(iRow).Cells(10).Value = ""
                '    Exit Sub
                'Else
                Dim a, sPLPT As String

                'a = Replace(dgvGL.Rows(iRow).Cells(10).Value, "-", "")
                'sPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 3))

                sPLPT = dgvGL.Rows(iRow).Cells(10).Value.ToString()
                Dim ret As String
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sPLPT, "and anl_type='PLPT'")

                If ret = "" Then
                    MsgBox("��辺 PL/PT ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(10).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(10).Value = ret
                End If


                'End If
            End If
            'Mktg
            If Not IsNothing(dgvGL.Rows(iRow).Cells(11).Value) AndAlso dgvGL.Rows(iRow).Cells(11).Value.ToString <> "" Then
                'If dgvGL.Rows(iRow).Cells(11).Value.ToString.Length < "8" Then
                '    MsgBox("��سҡ�͡���ú 8 ��ѡ")
                '    dgvGL.Rows(iRow).Cells(11).Value = ""
                '    Exit Sub
                'Else
                Dim a, sMktg As String

                'a = Replace(dgvGL.Rows(iRow).Cells(11).Value, "-", "")
                'sMktg = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))

                sMktg = dgvGL.Rows(iRow).Cells(11).Value.ToString()
                Dim ret As String
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, sMktg, "and anl_type='MKTG'")

                If ret = "" Then
                    MsgBox("��辺 Mktg/Emp ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(11).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(11).Value = ret
                End If

                'End If
            End If

            'Project
            'If Not String.IsNullOrEmpty(dgvGL.Rows(iRow).Cells(12).Value) Then
            If Not IsNothing(dgvGL.Rows(iRow).Cells(12).Value) AndAlso dgvGL.Rows(iRow).Cells(12).Value.ToString <> "" Then
                'If dgvGL.Rows(iRow).Cells(12).Value.ToString.Length <> "5" Then
                '    MsgBox("��سҡ�͡���ú 5 ��ѡ")
                '    dgvGL.Rows(iRow).Cells(12).Value = ""
                '    Exit Sub
                'Else
                '��Ǩ�ͺ�����ŷ���͡����ҡѺ�ҹ������
                Dim strPROJ As String
                strPROJ = dgvGL.Rows(iRow).Cells(12).Value.ToString

                Dim ret As String
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, strPROJ, "and anl_type = 'PROJ'")

                If ret = "" Then
                    MsgBox("��辺 Project ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(12).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(12).Value = ret
                End If

                'End If
            End If

            'TT-TR
            ' If Not String.IsNullOrEmpty(dgvGL.Rows(iRow).Cells(13).Value) Then
            If Not IsNothing(dgvGL.Rows(iRow).Cells(13).Value) AndAlso dgvGL.Rows(iRow).Cells(13).Value.ToString <> "" Then
                'If dgvGL.Rows(iRow).Cells(13).Value.ToString.Length <> "8" Then
                '    MsgBox("��سҡ�͡���ú 8 ��ѡ")

                'If dgvGL.Rows(iRow).Cells(13).Value.ToString.Length < "3" Then '����������ö��͡������ 3-8 ��ѡ�� (�ҡ��� 8 ��ѡ��ҹ��)
                '    MsgBox("��سҡ�͡���ú 3 ��ѡ����")
                '    dgvGL.Rows(iRow).Cells(13).Value = ""
                '    Exit Sub
                'Else
                '��Ǩ�ͺ�����ŷ���͡����ҡѺ�ҹ������
                Dim strTTTR As String
                strTTTR = dgvGL.Rows(iRow).Cells(13).Value.ToString

                Dim ret As String
                ret = cls.LookUp_SunCode(clsUtility.gConnGP, strTTTR, "and anl_type = 'TTTR'")

                If ret = "" Then
                    MsgBox("��辺 TT-TR ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(13).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(13).Value = ret
                End If
                'End If
            End If

            'Account Code
            If Not IsNothing(dgvGL.Rows(iRow).Cells(16).Value) AndAlso dgvGL.Rows(iRow).Cells(16).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(16).Value.ToString.Length <> "7" Then
                    MsgBox("��سҡ�͡���ú 7 ��ѡ")
                    dgvGL.Rows(iRow).Cells(16).Value = ""
                    Exit Sub
                Else
                    Dim ret As String
                    ret = cls.LookUp_OracleAccount(clsUtility.gConnGP, dgvGL.Rows(iRow).Cells(16).Value.ToString)
                    If ret = "" Then
                        MsgBox("��辺 Account Code ��� Config ��к�")
                        dgvGL.Rows(iRow).Cells(16).Value = ""

                    End If

                End If
            End If
            'Oracle Dept
            If Not IsNothing(dgvGL.Rows(iRow).Cells(17).Value) AndAlso dgvGL.Rows(iRow).Cells(17).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(17).Value.ToString.Length < "9" Then
                    MsgBox("��سҡ�͡���ú 9 ��ѡ")
                    dgvGL.Rows(iRow).Cells(17).Value = ""
                    Exit Sub
                Else
                    Dim a, oDept As String
                    a = Replace(dgvGL.Rows(iRow).Cells(17).Value, "-", "")
                    oDept = String.Format("{0}-{1}", a.Substring(0, 6), a.Substring(6, 3))

                    Dim ret As String
                    ret = cls.LookUp_OracleCode(clsUtility.gConnGP, oDept, "and anl_type='DEPB'")

                    If ret = "" Then
                        MsgBox("��辺 Dept/Branch ��� Config ��к�")
                        dgvGL.Rows(iRow).Cells(17).Value = ""
                    End If
                End If
            End If
            ' Oracle PL/PT
            If Not IsNothing(dgvGL.Rows(iRow).Cells(18).Value) AndAlso dgvGL.Rows(iRow).Cells(18).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(18).Value.ToString.Length < "3" Then
                    MsgBox("��سҡ�͡���ú 3 ��ѡ")
                    dgvGL.Rows(iRow).Cells(18).Value = ""
                    Exit Sub
                Else
                    Dim a, sPLPT As String
                    a = Replace(dgvGL.Rows(iRow).Cells(18).Value, "-", "")
                    sPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 2))

                    Dim ret As String
                    ret = cls.LookUp_OracleCode(clsUtility.gConnGP, sPLPT, "and anl_type='PLPT'")

                    If ret = "" Then
                        MsgBox("��辺 PL/PT ��� Config ��к�")
                        dgvGL.Rows(iRow).Cells(18).Value = ""
                    End If
                End If

            End If
            ' Oracle Mktg
            If Not IsNothing(dgvGL.Rows(iRow).Cells(19).Value) AndAlso dgvGL.Rows(iRow).Cells(19).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(19).Value.ToString.Length < "8" Then
                    MsgBox("��سҡ�͡���ú 8 ��ѡ")
                    dgvGL.Rows(iRow).Cells(19).Value = ""
                    Exit Sub
                Else
                    Dim a, sMktg As String
                    a = Replace(dgvGL.Rows(iRow).Cells(19).Value, "-", "")
                    sMktg = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))

                    Dim ret As String
                    ret = cls.LookUp_OracleCode(clsUtility.gConnGP, sMktg.Substring(0, 3), "and anl_type='MKTG'")

                    If ret = "" Then
                        MsgBox("��辺 Mktg/Emp ��� Config ��к�")
                        dgvGL.Rows(iRow).Cells(19).Value = ""
                    End If
                End If
            End If
            'Project
            If Not IsNothing(dgvGL.Rows(iRow).Cells(20).Value) AndAlso dgvGL.Rows(iRow).Cells(20).Value.ToString <> "" Then
                If dgvGL.Rows(iRow).Cells(20).Value.ToString.Length <> "5" Then
                    MsgBox("��سҡ�͡���ú 5 ��ѡ")
                    dgvGL.Rows(iRow).Cells(20).Value = ""
                    Exit Sub
                End If
            End If

            'Sub Account
            If Not IsNothing(dgvGL.Rows(iRow).Cells(27).Value) AndAlso dgvGL.Rows(iRow).Cells(27).Value.ToString <> "" Then
                Dim ret As String
                ret = cls.LookUp_SunAccount(clsUtility.gConnGP, dgvGL.Rows(iRow).Cells(27).Value.ToString)
                If ret = "" Then
                    MsgBox("��辺 Sub Account Code ��� Config ��к�")
                    dgvGL.Rows(iRow).Cells(27).Value = ""
                Else
                    dgvGL.Rows(iRow).Cells(27).Value = ret
                End If
            End If


            'If e.ColumnIndex = 20 Then
            '    btnAddRowGL_Click(Nothing, Nothing)
            'End If

        Catch ex As Exception

        End Try

    End Sub
    Private Sub dgvGL_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgvGL.CellFormatting
        Try
            Dim o As Object = e.Value
            If Not (o Is Nothing) And e.ColumnIndex = 9 And
         e.Value.ToString().Length = 7 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 3),
                s.Substring(3, 4))
                e.FormattingApplied = True
            End If

            If Not (o Is Nothing) And e.ColumnIndex = 10 And
         e.Value.ToString().Length = 4 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 1),
                s.Substring(1, 3))
                e.FormattingApplied = True
            End If

            If Not (o Is Nothing) And e.ColumnIndex = 11 And
         e.Value.ToString().Length = 8 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 3),
                s.Substring(3, 5))
                e.FormattingApplied = True
            End If

            If Not (o Is Nothing) And e.ColumnIndex = 17 And
         e.Value.ToString().Length = 9 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 6),
                s.Substring(6, 3))
                e.FormattingApplied = True
            End If

            If Not (o Is Nothing) And e.ColumnIndex = 18 And
         e.Value.ToString().Length = 3 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 1),
                s.Substring(1, 2))
                e.FormattingApplied = True
            End If

            If Not (o Is Nothing) And e.ColumnIndex = 19 And
        e.Value.ToString().Length = 8 Then
                Dim s As String = o.ToString()
                e.Value = String.Format("{0}-{1}", s.Substring(0, 3),
                s.Substring(3, 5))
                e.FormattingApplied = True
            End If

        Catch ex As Exception

        End Try


    End Sub
    Private Sub dgvGL_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles dgvGL.CellPainting
        'Only the Header Row (which Index is -1) is to be affected.
        'If e.RowIndex = -1 Then
        '    GridDrawCustomHeaderColumns(dgvGL, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)
        'End If
        'If e.ColumnIndex = 6 AndAlso e.RowIndex >= 0 Then
        '    e.Paint(e.CellBounds, DataGridViewPaintParts.All)

        '    Dim bmpFind As Bitmap = My.Resources.search_icon
        '    Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
        '    e.Graphics.DrawIcon(ico, e.CellBounds.Left + 3, e.CellBounds.Top + 3)
        '    e.Handled = True

        'End If

        If e.RowIndex = -1 And e.ColumnIndex <> -1 Then
            e.PaintBackground(e.CellBounds, False)
            Dim rec As Rectangle = e.CellBounds
            rec.Y += e.CellBounds.Height / 2
            rec.Height = e.CellBounds.Height / 2
            e.PaintContent(rec)
            e.Handled = True

        End If

    End Sub
    Private Sub dgvGL_ColumnAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewColumnEventArgs) Handles dgvGL.ColumnAdded
        e.Column.SortMode = DataGridViewColumnSortMode.NotSortable
    End Sub
    Private Sub dgvGL_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgvGL.EditingControlShowing

        If Not e.Control Is Nothing Then

            Select Case dgvGL.CurrentCell.ColumnIndex
                Case 5 'Account Code
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 7
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 7
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.TextAlign = HorizontalAlignment.Right
                    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case 8 'DR/CR
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 1
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    'Case 9 'Sun Dept Branch
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 7
                    '    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    'Case 10 'Sun PLPT
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 4
                    '    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    'Case 11 'Sun MKT
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 8
                    '    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    'Case 12 'Sun Project
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 5
                    '    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                    'Case 13 'Sun TTTR
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 8
                    '    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 14 'Payment Type
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 1
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 16 'Oracle Account code
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 7
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 17 'Oracle Dept Branch
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 9
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 18 'Oracle PLPT
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 3
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 19 'Oracle MKT
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 8
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
                Case 20 'Oracle Project
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    tb.MaxLength = 5
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress

                    'Case 11
                    '    Dim tb As TextBox = CType(e.Control, TextBox)
                    '    tb.MaxLength = 13
                    '    AddHandler tb.KeyPress, AddressOf txtNumeric_KeyPress
                Case Else
                    Dim tb As TextBox = CType(e.Control, TextBox)
                    AddHandler tb.KeyPress, AddressOf txtChar_KeyPress
            End Select
        End If
    End Sub
    Private Sub dgvGL_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgvGL.KeyDown
        If e.KeyValue = Keys.Delete Then
            e.Handled = True

            btnClearGL_Click(sender, Nothing)

            Exit Sub
        End If



        'If e.KeyValue = Keys.Tab Then

        '    If dgvGL.CurrentCell.ColumnIndex = 20 Then
        '        dgvGL.AllowUserToAddRows = True
        '    Else
        '        dgvGL.AllowUserToAddRows = False
        '    End If

        'End If

        'If e.KeyValue = Keys.Enter Then

        '    If dgvGL.CurrentCell.ColumnIndex = 20 Then
        '        dgvGL.AllowUserToAddRows = True
        '    Else
        '        dgvGL.AllowUserToAddRows = False
        '    End If

        'End If

    End Sub
    Private Sub dgvGL_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvGL.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.dgvGL.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.dgvGL.ClearSelection()
            Me.dgvGL.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub dgvGL_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles dgvGL.Paint
        'Dim names() As String = {"", "", "", "", "", "", "Adobe", "SUN"}
        'For i As Integer = 13 To 16 Step 4
        '    Dim rec As Rectangle = dgvGL.GetCellDisplayRectangle(i, -1, True)
        '    rec.X += 1
        '    rec.Y += 1
        '    rec.Width = rec.Width * 4 - 2
        '    rec.Height = rec.Height / 2 - 2
        '    e.Graphics.FillRectangle(New SolidBrush(Me.dgvGL.ColumnHeadersDefaultCellStyle.BackColor), rec)
        '    Dim format As New StringFormat
        '    format.Alignment = StringAlignment.Center
        '    format.LineAlignment = StringAlignment.Center
        '    e.Graphics.DrawString(names(i / 2), dgvGL.ColumnHeadersDefaultCellStyle.Font, New SolidBrush(dgvGL.ColumnHeadersDefaultCellStyle.ForeColor), rec, format)
        'Next

        Dim names() As String = {"Transaction Analysis(SUN Code)", "Accounting Flex field(Oracle Code)"}
        Try
            Dim rec As Rectangle = dgvGL.GetCellDisplayRectangle(9, -1, True)
            rec.X += 1
            rec.Y += 1
            rec.Width = rec.Width * 5 ' - 2
            rec.Height = rec.Height / 2 - 2
            e.Graphics.FillRectangle(New SolidBrush(Me.dgvGL.ColumnHeadersDefaultCellStyle.BackColor), rec)
            Dim format As New StringFormat
            format.Alignment = StringAlignment.Center
            format.LineAlignment = StringAlignment.Center
            e.Graphics.DrawString(names(0), dgvGL.ColumnHeadersDefaultCellStyle.Font, New SolidBrush(dgvGL.ColumnHeadersDefaultCellStyle.ForeColor), rec, format)


            Dim rec1 As Rectangle = dgvGL.GetCellDisplayRectangle(16, -1, True)
            rec1.X += 1
            rec1.Y += 1
            rec1.Width = rec1.Width * 5 ' - 2
            rec1.Height = rec1.Height / 2 - 2
            e.Graphics.FillRectangle(New SolidBrush(Me.dgvGL.ColumnHeadersDefaultCellStyle.BackColor), rec1)
            Dim format1 As New StringFormat
            format1.Alignment = StringAlignment.Center
            format1.LineAlignment = StringAlignment.Center
            e.Graphics.DrawString(names(1), dgvGL.ColumnHeadersDefaultCellStyle.Font, New SolidBrush(dgvGL.ColumnHeadersDefaultCellStyle.ForeColor), rec1, format1)

        Catch ex As Exception

        End Try
    End Sub
    Private Sub FindItemByID(ByRef cbCombo As ComboBox, ByVal strID As String)
        ' This sub is used to find an Item in a combobox and set the selected index of the combo box to that item...
        'Dim bOrigLoading As Boolean = bLoading ' So I can restore the old value at the end...
        'bLoading = True ' Stops this trigger when loading the data into the ComboBox...
        Dim bFound As Boolean
        Dim iCount As Integer

        ' We are searching on the ValueMember of the ComboBox...
        For iCount = 0 To cbCombo.Items.Count - 1
            cbCombo.SelectedIndex = iCount ' Set the SelectedIndex to move items in the ComboBox...
            If cbCombo.SelectedValue = strID Then ' We have found what we are looking for...
                bFound = True ' Flag we have found what we are looking for...
                Exit For ' And exit the For..Next loop...
            End If
        Next

        ' Did we find it?...
        If bFound Then ' Yes...
            cbCombo.SelectedIndex = iCount
        Else ' Nope...
            ' Setting it to -1 once does not seem to work, have to do it a second time...
            cbCombo.SelectedIndex = -1
            cbCombo.SelectedIndex = -1
        End If
        'bLoading = bOrigLoading ' Restore my original Loading flag...
    End Sub
    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        Dim f As New FrmJournalHold
        f.Owner = Me
        f.Tdept = lblDept.Text
        f.ShowDialog()

        chkFlagAllGP.Checked = False


        If retJnHold <> "" Then

            lblStatus.Text = "UPDATE"
            txtJournalHold.Text = retJnHold
            txtTransRef.Text = retTransRef

            'dataTableGP.Clear()
            'dataTableGL.Clear()
            'dataTableTAX.Clear()

            BindDataGP(retCreateDate, retCoreSystem, retTransRef)
            BindDataGL(retCreateDate, retCoreSystem, retTransRef)
            BindDataTAX(retCreateDate, retCoreSystem, retTransRef)


            CalculateGP(False)
            CalculateGL(False)
            CalculateTAX(False)



            If retCoreSystem = "TLM" Then
                ListDataSource(True)
                ListJournalType(True)
                ListDataSource(True)
                ListGroup(True)
                ListOverSea()

                BindDataHeader(retCreateDate, retCoreSystem, retTransRef)
                EnableControl(False)

                chkFlagAllGP.Enabled = False
            Else

                ListDataSource()
                ListJournalType()
                ListDataSource()
                ListGroup()
                ListOverSea()

                BindDataHeader(retCreateDate, retCoreSystem, retTransRef)
                EnableControl(True)

                chkFlagAllGP.Enabled = True
            End If

            btnSave.Enabled = False
            btnUpdate.Enabled = True
            btnDelete.Enabled = True

            dataTableGL = Nothing
            dataTableTAX = Nothing
            dataTableGP = Nothing

        End If


    End Sub
    Private Sub EnableControl(ByVal status As Boolean)
        cboEntryTypeGP.Enabled = status
        btnSave.Enabled = status
        'Tab
        dgvGP.ReadOnly = Not status
        btnLoadFileGP.Enabled = status
        btnClearGP.Enabled = status
        btnClearAllGP.Enabled = status
        cboJournalType.Enabled = status
        cboGroup.Enabled = status
        cboPayMth.Enabled = status
        dtpDueDate.Enabled = status
        cboOverSea.Enabled = status
        'txtJournalHold.Enabled = status
        cboDataSource.Enabled = status
        txtTransRef.Enabled = status
        txtAccPeriod.Enabled = status


    End Sub
    Function GLToTempTLM_TXT(ByVal dtTLM As DataTable) As DataTable
        Dim Row As DataRow
        dgvGL.AllowUserToAddRows = False

        If dgvGL.RowCount - 1 > 0 Then

            Try

                For index As Integer = 0 To dgvGL.RowCount - 1

                    Row = dtTLM.NewRow

                    Row.Item(0) = cboJournalType.SelectedValue.ToString
                    Row.Item(1) = cboDataSource.SelectedValue.ToString
                    Row.Item(2) = "SCB"
                    Row.Item(3) = txtAccPeriod.Text.Trim.Substring(3, 4) & "0" & txtAccPeriod.Text.Trim.Substring(0, 2)
                    Row.Item(4) = dgvGL.Rows(index).Cells(1).Value ' Transref
                    Row.Item(5) = dgvGL.Rows(index).Cells(0).Value ' LineNo
                    Row.Item(6) = dgvGL.Rows(index).Cells(2).Value 'TransDate
                    Row.Item(7) = dgvGL.Rows(index).Cells(3).Value 'DueDate
                    Row.Item(8) = dgvGL.Rows(index).Cells(4).Value 'Description
                    Row.Item(9) = dgvGL.Rows(index).Cells(16).Value 'Oracle Code
                    Row.Item(10) = dgvGL.Rows(index).Cells(7).Value 'Amount
                    Row.Item(11) = dgvGL.Rows(index).Cells(8).Value 'DC
                    Row.Item(12) = dgvGL.Rows(index).Cells(17).Value
                    Row.Item(13) = dgvGL.Rows(index).Cells(18).Value
                    Row.Item(14) = dgvGL.Rows(index).Cells(19).Value
                    Row.Item(15) = dgvGL.Rows(index).Cells(20).Value '
                    Row.Item(16) = dgvGL.Rows(index).Cells(14).Value
                    Row.Item(17) = dgvGL.Rows(index).Cells(15).Value

                    Row.Item(18) = dgvGL.Rows(index).Cells(5).Value
                    Row.Item(19) = dgvGL.Rows(index).Cells(6).Value

                    Row.Item(20) = dgvGL.Rows(index).Cells(9).Value
                    Row.Item(21) = dgvGL.Rows(index).Cells(10).Value
                    Row.Item(22) = dgvGL.Rows(index).Cells(11).Value
                    Row.Item(23) = dgvGL.Rows(index).Cells(13).Value
                    Row.Item(24) = dgvGL.Rows(index).Cells(12).Value


                    dtTLM.Rows.Add(Row)

                Next


                Return dtTLM


            Catch ex As Exception
                Return Nothing
            End Try

            dgvGL.AllowUserToAddRows = True
        Else
            Return Nothing
        End If
    End Function
    Function GLToTempFill_XLS(ByVal dtTLM As DataTable) As DataTable
        Dim Row As DataRow
        dgvGL.AllowUserToAddRows = False
        Try

            For index As Integer = 0 To dgvGL.RowCount - 1

                Row = dtTLM.NewRow

                Row.Item(0) = dgvGL.Rows(index).Cells(1).Value ' Transref						
                Row.Item(1) = dgvGL.Rows(index).Cells(0).Value ' LineNo						
                Row.Item(2) = dgvGL.Rows(index).Cells(2).Value 'TransDate						
                Row.Item(3) = dgvGL.Rows(index).Cells(3).Value 'DueDate						
                Row.Item(4) = dgvGL.Rows(index).Cells(4).Value 'Description						
                Row.Item(5) = dgvGL.Rows(index).Cells(5).Value
                Row.Item(6) = dgvGL.Rows(index).Cells(6).Value
                Row.Item(7) = dgvGL.Rows(index).Cells(7).Value 'Amount						
                Row.Item(8) = dgvGL.Rows(index).Cells(8).Value 'DC						
                Row.Item(9) = dgvGL.Rows(index).Cells(9).Value
                Row.Item(10) = dgvGL.Rows(index).Cells(10).Value
                Row.Item(11) = dgvGL.Rows(index).Cells(11).Value
                Row.Item(12) = dgvGL.Rows(index).Cells(12).Value
                Row.Item(13) = dgvGL.Rows(index).Cells(13).Value
                Row.Item(14) = dgvGL.Rows(index).Cells(14).Value
                Row.Item(15) = dgvGL.Rows(index).Cells(15).Value
                Row.Item(16) = dgvGL.Rows(index).Cells(16).Value 'Oracle Code						
                Row.Item(17) = dgvGL.Rows(index).Cells(17).Value
                Row.Item(18) = dgvGL.Rows(index).Cells(18).Value
                Row.Item(19) = dgvGL.Rows(index).Cells(19).Value
                Row.Item(20) = dgvGL.Rows(index).Cells(20).Value '						


                dtTLM.Rows.Add(Row)

            Next


            Return dtTLM

        Catch ex As Exception
            Return Nothing
        End Try

        dgvGL.AllowUserToAddRows = True

    End Function
    Function TAXToTempFill_XLS(ByVal dtTLM As DataTable) As DataTable
        Dim Row As DataRow
        dgvTax.AllowUserToAddRows = False
        Try

            For index As Integer = 0 To dgvTax.RowCount - 1

                Row = dtTLM.NewRow

                Row.Item(0) = dgvTax.Rows(index).Cells(0).Value
                Row.Item(1) = dgvTax.Rows(index).Cells(1).Value
                Row.Item(2) = dgvTax.Rows(index).Cells(2).Value
                Row.Item(3) = dgvTax.Rows(index).Cells(3).Value
                Row.Item(4) = dgvTax.Rows(index).Cells(4).Value
                Row.Item(5) = dgvTax.Rows(index).Cells(5).Value
                Row.Item(6) = dgvTax.Rows(index).Cells(6).Value
                Row.Item(7) = dgvTax.Rows(index).Cells(7).Value
                Row.Item(8) = dgvTax.Rows(index).Cells(8).Value
                Row.Item(9) = dgvTax.Rows(index).Cells(9).Value
                Row.Item(10) = dgvTax.Rows(index).Cells(10).Value
                Row.Item(11) = dgvTax.Rows(index).Cells(11).Value
                Row.Item(12) = dgvTax.Rows(index).Cells(12).Value
                Row.Item(13) = dgvTax.Rows(index).Cells(13).Value
                Row.Item(14) = dgvTax.Rows(index).Cells(14).Value
                Row.Item(15) = dgvTax.Rows(index).Cells(15).Value
                Row.Item(16) = dgvTax.Rows(index).Cells(16).Value
                Row.Item(17) = dgvTax.Rows(index).Cells(17).Value
                Row.Item(18) = dgvTax.Rows(index).Cells(18).Value


                dtTLM.Rows.Add(Row)

            Next


            Return dtTLM

        Catch ex As Exception
            Return Nothing
        End Try

        dgvTax.AllowUserToAddRows = True

    End Function
    Function GLToTemp() As DataTable
        Dim Row As DataRow
        'dgvGL.AllowUserToAddRows = False
        dataTableGL = Nothing
        Try

            For index As Integer = 0 To dgvGL.RowCount - 1
                If dataTableGL Is Nothing Then
                    dataTableGL = New DataTable("TempGL")

                    dataTableGL.Columns.Add("LineNo")
                    dataTableGL.Columns.Add("TransRef")
                    dataTableGL.Columns.Add("TransDate")
                    dataTableGL.Columns.Add("DueDate")
                    dataTableGL.Columns.Add("Description")
                    dataTableGL.Columns.Add("SunAccCode")
                    dataTableGL.Columns.Add("SunAccName")
                    dataTableGL.Columns.Add("Amount")
                    dataTableGL.Columns.Add("DC")
                    dataTableGL.Columns.Add("SunDept")
                    dataTableGL.Columns.Add("SunPLPT")
                    dataTableGL.Columns.Add("SunMktg")
                    dataTableGL.Columns.Add("SunProjectCode")
                    dataTableGL.Columns.Add("SunTTTR")
                    dataTableGL.Columns.Add("PaymentType")
                    dataTableGL.Columns.Add("PayeeName")
                    dataTableGL.Columns.Add("OracleAccCode")
                    dataTableGL.Columns.Add("OracleDept")
                    dataTableGL.Columns.Add("OraclePLPT")
                    dataTableGL.Columns.Add("OracleMktg")
                    dataTableGL.Columns.Add("OracleProjectCode")


                End If

                Row = dataTableGL.NewRow

                Dim sDept As String
                Dim sPLPT As String
                Dim sMKTG As String

                Dim oDept As String
                Dim oPLPT As String
                Dim oMKTG As String

                If Not IsNothing(dgvGL.Rows(index).Cells(9).Value) AndAlso dgvGL.Rows(index).Cells(9).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(9).Value, "-", "")
                    'sDept = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 4))

                    sDept = dgvGL.Rows(index).Cells(9).Value.ToString()
                Else
                    sDept = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(10).Value) AndAlso dgvGL.Rows(index).Cells(10).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(10).Value, "-", "")
                    'sPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 3))

                    sPLPT = dgvGL.Rows(index).Cells(10).Value.ToString()
                Else
                    sPLPT = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(11).Value) AndAlso dgvGL.Rows(index).Cells(11).Value.ToString <> "" Then
                    'Dim a As String
                    'a = Replace(dgvGL.Rows(index).Cells(11).Value, "-", "")
                    'sMKTG = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))

                    sMKTG = dgvGL.Rows(index).Cells(11).Value.ToString()
                Else
                    sMKTG = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(17).Value) AndAlso dgvGL.Rows(index).Cells(17).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(17).Value, "-", "")
                    oDept = String.Format("{0}-{1}", a.Substring(0, 6), a.Substring(6, 3))
                Else
                    oDept = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(18).Value) AndAlso dgvGL.Rows(index).Cells(18).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(18).Value, "-", "")
                    oPLPT = String.Format("{0}-{1}", a.Substring(0, 1), a.Substring(1, 2))
                Else
                    oPLPT = ""
                End If
                If Not IsNothing(dgvGL.Rows(index).Cells(19).Value) AndAlso dgvGL.Rows(index).Cells(19).Value.ToString <> "" Then
                    Dim a As String
                    a = Replace(dgvGL.Rows(index).Cells(19).Value, "-", "")
                    oMKTG = String.Format("{0}-{1}", a.Substring(0, 3), a.Substring(3, 5))
                Else
                    oMKTG = ""
                End If


                Row.Item(0) = dgvGL.Rows(index).Cells(0).Value
                Row.Item(1) = dgvGL.Rows(index).Cells(1).Value
                Row.Item(2) = dgvGL.Rows(index).Cells(2).Value
                Row.Item(3) = dgvGL.Rows(index).Cells(3).Value
                Row.Item(4) = dgvGL.Rows(index).Cells(4).Value
                Row.Item(5) = dgvGL.Rows(index).Cells(5).Value
                Row.Item(6) = dgvGL.Rows(index).Cells(6).Value
                Row.Item(7) = dgvGL.Rows(index).Cells(7).Value
                Row.Item(8) = dgvGL.Rows(index).Cells(8).Value
                Row.Item(9) = sDept 'dgvGL.Rows(index).Cells(9).Value
                Row.Item(10) = sPLPT 'dgvGL.Rows(index).Cells(10).Value
                Row.Item(11) = sMKTG 'dgvGL.Rows(index).Cells(11).Value
                Row.Item(12) = dgvGL.Rows(index).Cells(12).Value
                Row.Item(13) = dgvGL.Rows(index).Cells(13).Value
                Row.Item(14) = dgvGL.Rows(index).Cells(14).Value
                Row.Item(15) = dgvGL.Rows(index).Cells(15).Value
                Row.Item(16) = dgvGL.Rows(index).Cells(16).Value
                Row.Item(17) = oDept 'dgvGL.Rows(index).Cells(17).Value
                Row.Item(18) = oPLPT 'dgvGL.Rows(index).Cells(18).Value
                Row.Item(19) = oMKTG 'dgvGL.Rows(index).Cells(19).Value
                Row.Item(20) = dgvGL.Rows(index).Cells(20).Value


                dataTableGL.Rows.Add(Row)

            Next


            Return dataTableGL

        Catch ex As Exception
            Return Nothing
        End Try

        'dgvGL.AllowUserToAddRows = True

    End Function
    Function GPToTemp() As DataTable
        Dim Row As DataRow
        dgvGP.AllowUserToAddRows = False
        dataTableGP = Nothing
        Try

            For index As Integer = 0 To dgvGP.RowCount - 1
                If dataTableGP Is Nothing Then
                    dataTableGP = New DataTable("TempGP")

                    dataTableGP.Columns.Add("TransRef")
                    dataTableGP.Columns.Add("PolNo")
                    dataTableGP.Columns.Add("BillNo")
                    dataTableGP.Columns.Add("DueDate")
                    dataTableGP.Columns.Add("Amount", GetType(Double))
                    dataTableGP.Columns.Add("Description")
                    dataTableGP.Columns.Add("PaymentType")
                    dataTableGP.Columns.Add("PayeeName")
                    dataTableGP.Columns.Add("BankCode")
                    dataTableGP.Columns.Add("BankNo")
                    dataTableGP.Columns.Add("BankBranch")
                    dataTableGP.Columns.Add("BankName")
                    dataTableGP.Columns.Add("PayeeBankAccNo")
                    dataTableGP.Columns.Add("PayeeBankAccName")
                    dataTableGP.Columns.Add("Comment")
                    dataTableGP.Columns.Add("Address1")
                    dataTableGP.Columns.Add("District")
                    dataTableGP.Columns.Add("Province")
                    dataTableGP.Columns.Add("InsureName")
                    dataTableGP.Columns.Add("DataSource")
                    dataTableGP.Columns.Add("SubPaymentType")
                    dataTableGP.Columns.Add("MerchartNo")
                    dataTableGP.Columns.Add("TransCard")
                    dataTableGP.Columns.Add("Reserve9")
                    dataTableGP.Columns.Add("Reserve10")
                    dataTableGP.Columns.Add("Sys_Ref")
                    dataTableGP.Columns.Add("Sys_Gr")
                    dataTableGP.Columns.Add("Flag")
                    dataTableGP.Columns.Add("Phone")
                    dataTableGP.Columns.Add("Fax")
                    dataTableGP.Columns.Add("SwiftCode")
                    dataTableGP.Columns.Add("BankBranchName")
                    dataTableGP.Columns.Add("BankAddress")
                    dataTableGP.Columns.Add("Receive")
                    dataTableGP.Columns.Add("Currency")
                    dataTableGP.Columns.Add("ExRate")
                    dataTableGP.Columns.Add("Fee")
                    dataTableGP.Columns.Add("GPLine")
                    dataTableGP.Columns.Add("CheckName")
                    dataTableGP.Columns.Add("FlagLine")

                End If

                Row = dataTableGP.NewRow

                Row.Item(0) = dgvGP.Rows(index).Cells(0).Value
                Row.Item(1) = dgvGP.Rows(index).Cells(1).Value
                Row.Item(2) = dgvGP.Rows(index).Cells(2).Value
                Row.Item(3) = dgvGP.Rows(index).Cells(3).Value
                Row.Item(4) = dgvGP.Rows(index).Cells(4).Value
                Row.Item(5) = dgvGP.Rows(index).Cells(5).Value
                Row.Item(6) = dgvGP.Rows(index).Cells(6).Value
                Row.Item(7) = dgvGP.Rows(index).Cells(7).Value
                Row.Item(8) = dgvGP.Rows(index).Cells(8).Value
                Row.Item(9) = dgvGP.Rows(index).Cells(9).Value
                Row.Item(10) = dgvGP.Rows(index).Cells(10).Value
                Row.Item(11) = dgvGP.Rows(index).Cells(11).Value
                Row.Item(12) = dgvGP.Rows(index).Cells(12).Value
                Row.Item(13) = dgvGP.Rows(index).Cells(13).Value
                Row.Item(14) = dgvGP.Rows(index).Cells(14).Value
                Row.Item(15) = dgvGP.Rows(index).Cells(15).Value
                Row.Item(16) = dgvGP.Rows(index).Cells(16).Value
                Row.Item(17) = dgvGP.Rows(index).Cells(17).Value
                Row.Item(18) = dgvGP.Rows(index).Cells(18).Value
                Row.Item(19) = dgvGP.Rows(index).Cells(19).Value
                Row.Item(20) = dgvGP.Rows(index).Cells(20).Value
                Row.Item(21) = dgvGP.Rows(index).Cells(21).Value
                Row.Item(22) = dgvGP.Rows(index).Cells(22).Value
                Row.Item(23) = dgvGP.Rows(index).Cells(23).Value
                Row.Item(24) = dgvGP.Rows(index).Cells(24).Value
                Row.Item(25) = dgvGP.Rows(index).Cells(25).Value
                Row.Item(26) = dgvGP.Rows(index).Cells(26).Value
                Row.Item(27) = dgvGP.Rows(index).Cells(27).Value
                Row.Item(28) = dgvGP.Rows(index).Cells(28).Value
                Row.Item(29) = dgvGP.Rows(index).Cells(29).Value
                Row.Item(30) = dgvGP.Rows(index).Cells(30).Value
                Row.Item(31) = dgvGP.Rows(index).Cells(31).Value
                Row.Item(32) = dgvGP.Rows(index).Cells(32).Value
                Row.Item(33) = dgvGP.Rows(index).Cells(33).Value
                Row.Item(34) = dgvGP.Rows(index).Cells(34).Value
                Row.Item(35) = dgvGP.Rows(index).Cells(35).Value
                Row.Item(36) = dgvGP.Rows(index).Cells(36).Value
                Row.Item(37) = dgvGP.Rows(index).Cells(37).Value
                If dgvGP.Rows(index).Cells(6).Value = "M" Then
                    Row.Item(38) = Replace(dgvGP.Rows(index).Cells(13).Value, " ", "")
                Else
                    Row.Item(38) = Replace(dgvGP.Rows(index).Cells(7).Value, " ", "")
                End If

                Row.Item(39) = "N"

                dataTableGP.Rows.Add(Row)

            Next
            Return dataTableGP

        Catch ex As Exception
            Return Nothing
        End Try

        dgvGP.AllowUserToAddRows = True

    End Function
    Function TAXToTemp() As DataTable
        Dim Row As DataRow
        dgvTax.AllowUserToAddRows = False

        Try

            For index As Integer = 0 To dgvTax.RowCount - 1
                If dataTableTAX Is Nothing Then
                    dataTableTAX = New DataTable("TempTAX")

                    dataTableTAX.Columns.Add("LineNo")
                    dataTableTAX.Columns.Add("TaxID")
                    dataTableTAX.Columns.Add("IDCard")
                    dataTableTAX.Columns.Add("APTitle")
                    dataTableTAX.Columns.Add("APName")
                    dataTableTAX.Columns.Add("APLastName")
                    dataTableTAX.Columns.Add("Address")
                    dataTableTAX.Columns.Add("AMPENM")
                    dataTableTAX.Columns.Add("PROVNM")
                    dataTableTAX.Columns.Add("AGZIP")
                    dataTableTAX.Columns.Add("TaxType")
                    dataTableTAX.Columns.Add("TaxItem")
                    dataTableTAX.Columns.Add("TaxDate")
                    dataTableTAX.Columns.Add("BaseAmount")
                    dataTableTAX.Columns.Add("WHTAmount")
                    dataTableTAX.Columns.Add("Payee")
                    dataTableTAX.Columns.Add("TaxRate")
                    dataTableTAX.Columns.Add("Description")
                    dataTableTAX.Columns.Add("AccCode")


                End If

                Row = dataTableTAX.NewRow

                Row.Item(0) = dgvTax.Rows(index).Cells(0).Value
                Row.Item(1) = dgvTax.Rows(index).Cells(1).Value
                Row.Item(2) = dgvTax.Rows(index).Cells(2).Value
                Row.Item(3) = dgvTax.Rows(index).Cells(3).Value
                Row.Item(4) = dgvTax.Rows(index).Cells(4).Value
                Row.Item(5) = dgvTax.Rows(index).Cells(5).Value
                Row.Item(6) = dgvTax.Rows(index).Cells(6).Value
                Row.Item(7) = dgvTax.Rows(index).Cells(7).Value
                Row.Item(8) = dgvTax.Rows(index).Cells(8).Value
                Row.Item(9) = dgvTax.Rows(index).Cells(9).Value
                Row.Item(10) = dgvTax.Rows(index).Cells(10).Value
                Row.Item(11) = dgvTax.Rows(index).Cells(11).Value
                Row.Item(12) = dgvTax.Rows(index).Cells(12).Value
                Row.Item(13) = dgvTax.Rows(index).Cells(13).Value
                Row.Item(14) = dgvTax.Rows(index).Cells(14).Value
                Row.Item(15) = dgvTax.Rows(index).Cells(15).Value
                Row.Item(16) = dgvTax.Rows(index).Cells(16).Value
                Row.Item(17) = dgvTax.Rows(index).Cells(17).Value
                Row.Item(18) = dgvTax.Rows(index).Cells(18).Value

                dataTableTAX.Rows.Add(Row)

            Next

            Return dataTableTAX

        Catch ex As Exception
            Return Nothing
        End Try

        dgvTax.AllowUserToAddRows = True

    End Function
    Private Function IsFileOpen(ByVal filename As String) As Boolean

        Try
            'CREATE A FILE STREAM FROM THE FILE, OPENING IT FOR READ ONLY EXCLUSIVE ACCESS
            Dim FS As IO.FileStream = IO.File.Open(FileName, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.None)
            'CLOSE AND CLEAN UP RIGHT AWAY, IF THE OPEN SUCCEEDED, WE HAVE OUR ANSWER ALREADY
            FS.Close()
            FS.Dispose()
            FS = Nothing
            Return False
            'MessageBox.Show("Yes, you are the only one using this file")
        Catch ex As IO.IOException
            'IF AN IO EXCEPTION IS THROWN, WE COULD NOT GET EXCLUSIVE ACCESS TO THE FILE
            'MessageBox.Show("No someone else has this file open" & Environment.NewLine & ex.Message)
            Return True
        Catch ex As Exception
            Return True
            'MessageBox.Show("Unknown error occured" & Environment.NewLine & ex.Message)
        End Try
    End Function
    Private Sub BackupFile(ByVal org As String, ByVal type As String)
        If org <> "" Then
            dgvGL.AllowUserToAddRows = False
            dgvGP.AllowUserToAddRows = False
            dgvTax.AllowUserToAddRows = False
            Select Case type
                Case "GL"
                    If dgvGL.RowCount <= 0 Then
                        Exit Sub
                    End If
                Case "GP"
                    If dgvGP.RowCount <= 0 Then
                        Exit Sub
                    End If
                Case "TAX"
                    If dgvTax.RowCount <= 0 Then
                        Exit Sub
                    End If
            End Select
            dgvGL.AllowUserToAddRows = True
            dgvGP.AllowUserToAddRows = True
            dgvTax.AllowUserToAddRows = True

            Dim filename As String
            filename = IO.Path.GetFileName(org)

            Dim path As String
            Dim despath As String

            If type = "GL" Then
                path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GLPATH_BACKUP_ACC")
                despath = path & filename
            ElseIf type = "GP" Then
                path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GPPATH_BACKUP_ACC")
                despath = path & filename
            ElseIf type = "TAX" Then
                path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "WHTPATH_BACKUP_ACC")
                despath = path & filename
            End If


            Try
                'Copy file to backup
                If System.IO.File.Exists(despath) Then
                    My.Computer.FileSystem.DeleteFile(despath)
                End If

                System.IO.File.Move(org, despath)

                'My.Computer.FileSystem.CopyFile(org, descpath, overwrite:=True)

                ''Delete Original file 
                'My.Computer.FileSystem.DeleteFile(org)
            Catch ex As Exception
                clsBusiness.gLastErrMessage = org & ":" & ex.ToString

            Finally
                'Delete Original file 
                'If controlName <> "" Then My.Computer.FileSystem.DeleteFile(controlName)
            End Try


        End If
    End Sub
    Function chkTransRef(ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_TRANSREF_REL L ")
        sb.Append("WHERE L.TREF_CREATEDATE='" & createdate & "' AND L.TREF_CORE_SYSTEM='" & core_system & "'  ")
        sb.Append("AND L.TREF_TRANSREF ='" & transref & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            Return False
        Else
            Return True
        End If

    End Function
    Function SaveData() As Boolean

        'Dim errSun As String = ""

        clsBusiness.gLastErrMessage = ""
        err_data = ""
        err_wl = ""
        Dim errGP As String = ""

        If txtTransRef.Text.Trim = "" Then
            MsgBox("Please enter Transaction Reference")
            Exit Function
        End If

        If txtTransRef.Text.Length > 15 Then
            MsgBox("Transaction Reference not a valid")


            Exit Function
        End If

        If cboDataSource.Text.Trim = "" Then
            MsgBox("Please select DataSource")


            Exit Function
        End If
        If txtAccPeriod.Text.Trim = "" Then
            MsgBox("Please enter Accounting Period")
            Exit Function
        Else
            If txtAccPeriod.Text.Length <> 7 Then
                MsgBox("Accounting Period not a valid")
                Exit Function
            End If
        End If
        If txtOutOfBalance.Text <> "0.00" Then
            MsgBox("�������ö�ѹ�֡�����������ͧ�ҡ Amount Debits <> Amount Credits")
            Exit Function
        End If


        If (cboPayMth.SelectedValue.ToString = "C:H" Or
            cboPayMth.SelectedValue.ToString = "C:G" Or
            cboPayMth.SelectedValue.ToString = "C:T" Or
            cboPayMth.SelectedValue.ToString = "C:B") And txtPurpose.Text.Trim = "" Then
            MsgBox("��س��к� Purpose of Purchase")
            Exit Function
        End If


        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        dgvGL.AllowUserToAddRows = False
        dgvGP.AllowUserToAddRows = False
        dgvTax.AllowUserToAddRows = False

        If lblStatus.Text = "ADD" Then
            retCreateDate = systemdate 'Now.ToString("yyyyMMdd")
            retCoreSystem = "ACC"
            retTransRef = txtTransRef.Text.Trim

            If chkTransRef(retCreateDate, retCoreSystem, retTransRef) = False Then
                MsgBox("Duplicate Transref", MsgBoxStyle.Critical, "Validate")
                Exit Function
            End If

        End If




        Select Case cboGroup.SelectedValue.ToString
            Case "001", "002", "003"
                If dgvGL.RowCount <= 0 Then
                    MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")
                    Exit Function
                End If
                If dgvGP.RowCount <= 0 Then
                    MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")
                    Exit Function
                End If

                If CheckIncludeWHT() Then
                    If dgvTax.RowCount <= 0 Then
                        MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")
                        Exit Function
                    End If

                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_ACC(True, True, True)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                                My.Computer.Clipboard.SetText(err.ToString)
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, True, True)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                My.Computer.Clipboard.SetText(err.ToString)
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                                MsgBox("Already copy message to clipboard.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If
                Else 'not tax
                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_ACC(True, True, False)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, True, False)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If

                End If


            Case "004"
                If dgvGL.RowCount <= 0 Then
                    MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")


                    Exit Function
                End If


                Dim processTemp As Boolean
                processTemp = ProcessDataToTemp_ACC(True, True, True)
                If processTemp Then

                    ValidateData_GP(errGP)

                    If ValidateData() Then
                        Dim err As String
                        err = """Validate Tab GP""" & vbCrLf & errGP
                        If errGP <> "" Or err_data <> "" Then
                            err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                        End If
                        If errGP <> "" Or err_data <> "" Then
                            MsgBox(err, MsgBoxStyle.Critical, "Validate")


                            Exit Function
                        End If
                        ProcessTempToTable(True, True, True)
                    Else
                        Dim err As String
                        err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                        If err_data <> "" Then
                            MsgBox(err, MsgBoxStyle.Critical, "Validate")
                        End If
                    End If

                Else
                    MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                End If

            Case "005"
                '005 LOAD �����á������� (TLM)
                If dgvGL.RowCount <= 0 Then
                    MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")


                    Exit Function
                End If

                If CheckIncludeWHT() Then
                    If dgvTax.RowCount <= 0 Then
                        MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")
                        Exit Function
                    End If

                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_TLM(True, True, True)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, True, True)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If
                Else 'not tax

                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_TLM(True, True, False)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, True, False)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If
                End If


            Case "006"
                If dgvGL.RowCount <= 0 Then
                    MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")


                    Exit Function
                End If
                If CheckIncludeWHT() Then
                    If dgvTax.RowCount <= 0 Then
                        MsgBox("�ѹ�֡���������ú��� Tab ����úѹ�֡ ��سҵ�Ǩ�ͺ!")


                        Exit Function
                    End If
                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_ACC(True, False, True)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, False, True)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If
                Else
                    Dim processTemp As Boolean
                    processTemp = ProcessDataToTemp_ACC(True, False, False)
                    If processTemp Then

                        ValidateData_GP(errGP)

                        If ValidateData() Then
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP
                            If err_data <> "" Then
                                err = err & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            End If
                            If errGP <> "" Or err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")


                                Exit Function
                            End If
                            ProcessTempToTable(True, False, False)
                        Else
                            Dim err As String
                            err = """Validate Tab GP""" & vbCrLf & errGP & vbCrLf & """Validate Data ��� BRD""" & vbCrLf & err_data
                            If err_data <> "" Then
                                MsgBox(err, MsgBoxStyle.Critical, "Validate")
                            End If
                        End If

                    Else
                        MsgBox("Can not update data" & vbCrLf & clsBusiness.gLastErrMessage)
                    End If
                End If

        End Select


        dgvGL.AllowUserToAddRows = True
        dgvGP.AllowUserToAddRows = True
        dgvTax.AllowUserToAddRows = True




    End Function
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        lblAlert.Visible = True
        Cursor = Cursors.WaitCursor

        SaveData()

        EnableControl(True)

        lblAlert.Visible = False
        Cursor = Cursors.Default
    End Sub
    Private Sub BindJournalHold(ByVal createdate As String, ByVal core_system As String, ByVal transref As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_TRANSREF_REL GPS_TRANSREF_REL WHERE TREF_CREATEDATE='" & createdate & "' AND TREF_CORE_SYSTEM='" & core_system & "'  AND TREF_TRANSREF='" & transref & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            txtJournalHold.Text = dt.Rows(0)("TREF_JN_HOLD").ToString

            retCreateDate = createdate
            retCoreSystem = core_system
            retTransRef = transref
        End If

    End Sub
    Private Sub ClearTemp()

        Dim c1, c2, c3 As Boolean

        c1 = True
        c2 = True
        c3 = True

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()


        c1 = cls.ClearTemp(clsUtility.gConnGP, oleTrans, "GPS_TMP_PAYMENT_CREATION", gUserLogin)
        c2 = cls.ClearTemp(clsUtility.gConnGP, oleTrans, "GPS_TMP_GL_CREATION", gUserLogin)
        c3 = cls.ClearTemp(clsUtility.gConnGP, oleTrans, "GPS_TMP_WHT_CREATION", gUserLogin)


        If c1 And c2 And c3 Then
            oleTrans.Commit()

        Else
            oleTrans.Rollback()

        End If



    End Sub
    Function GetBNKSCODE() As String
        Dim sb As New StringBuilder()

        sb.Append("select B.BNKS_BNKSCODE_NO, B.BNKS_BNKSBRN_CD from GPS_TL_PAYTYPE A inner join GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP ")
        sb.Append("WHERE A.PAYT_PAYMTH='" & Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) & "' And A.PAYT_SUB_PAYMTH='" & Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return ""
        End If

    End Function
    Function GetBNKSBRN_CD() As String
        Dim sb As New StringBuilder()

        sb.Append("select B.BNKS_BNKSCODE_NO, B.BNKS_BNKSBRN_CD from GPS_TL_PAYTYPE A inner join GPS_TL_BANKSERVICE1 B ON A.PAYT_PAY_GROUP=B.BNKS_PAY_GROUP ")
        sb.Append("WHERE A.PAYT_PAYMTH='" & Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) & "' And A.PAYT_SUB_PAYMTH='" & Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(1).ToString()
        Else
            Return ""
        End If

    End Function
    Function GetBNKNAME(ByVal bnkcode As String) As String
        Dim sb As New StringBuilder()

        sb.Append("select BKMST_BNKNAME from GPS_TL_BANKMASTER WHERE ")
        sb.Append("BKMST_BNKCODE_NO='" & bnkcode & "' And BKMST_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return ""
        End If

    End Function
    Function ProcessDataToTemp_ACC(ByVal gl As Boolean, ByVal gp As Boolean, ByVal tax As Boolean) As Boolean

        ClearTemp()

        Dim BNKSCODE As String = ""
        Dim BNKBRN As String = ""
        Dim bnkname As String = ""

        If cboPayMth.SelectedValue = "C:C" Or cboPayMth.SelectedValue = "D:D" Then
            BNKSCODE = GetBNKSCODE()
            bnkname = GetBNKNAME(BNKSCODE)
            BNKBRN = GetBNKSBRN_CD()
        End If

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk_gl As Boolean = True
        Dim chk_gp As Boolean = True
        Dim chk_tax As Boolean = True

        If gl Then
            chk_gl = SaveGL(oleTrans, "GPS_TMP_GL_CREATION", retCreateDate, "ACC", txtTransRef.Text.Trim)
        End If
        If gp Then
            chk_gp = SaveGP(oleTrans, "GPS_TMP_PAYMENT_CREATION", retCreateDate, "ACC", txtTransRef.Text.Trim, BNKBRN, bnkname)
        End If
        If tax Then
            chk_tax = SaveTAX(oleTrans, "GPS_TMP_WHT_CREATION", retCreateDate, "ACC", txtTransRef.Text.Trim)
        End If

        If (chk_gl And chk_gp And chk_tax) Then
            oleTrans.Commit()

            Return True
        Else
            oleTrans.Rollback()

            Return False
        End If

    End Function
    Function ProcessDataToTemp_TLM(ByVal gl As Boolean, ByVal gp As Boolean, ByVal tax As Boolean) As Boolean
        ClearTemp()

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim chk_gl As Boolean = True
        Dim chk_gp As Boolean = True
        Dim chk_tax As Boolean = True


        If gl Then
            chk_gl = SaveGL(oleTrans, "GPS_TMP_GL_CREATION", retCreateDate, retCoreSystem, retTransRef)
        End If
        If gp Then
            chk_gp = SaveGP(oleTrans, "GPS_TMP_PAYMENT_CREATION", retCreateDate, retCoreSystem, txtTransRef.Text.Trim)
        End If
        If tax Then
            chk_tax = SaveTAX(oleTrans, "GPS_TMP_WHT_CREATION", retCreateDate, retCoreSystem, txtTransRef.Text.Trim)
        End If

        If (chk_gl And chk_gp And chk_tax) Then
            oleTrans.Commit()

            Return True
        Else
            oleTrans.Rollback()

            Return False
        End If

    End Function
    Private Sub ProcessTempToTable(ByVal gl As Boolean, ByVal gp As Boolean, ByVal tax As Boolean)
        Dim systemdate As String
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim oleTrans As OleDbTransaction

        Dim chk_gl As Boolean = True
        Dim chk_gp As Boolean = True
        Dim chk_tax As Boolean = True

        If lblStatus.Text = "ADD" Then
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            If gl Then
                chk_gl = cls.TmpToTable_GL(clsUtility.gConnGP, oleTrans, gUserLogin)
            End If
            If gp Then
                chk_gp = cls.TmpToTable_GP(clsUtility.gConnGP, oleTrans, gUserLogin)
            End If
            If tax Then
                chk_tax = cls.TmpToTable_WHT(clsUtility.gConnGP, oleTrans, gUserLogin)
            End If

            If (chk_gl And chk_gp And chk_tax) Then
                oleTrans.Commit()

                GL_UpdateJournalHold(systemdate)
                INS_GPS_TRANSREF_REL(systemdate)

                BindJournalHold(systemdate, "ACC", txtTransRef.Text.Trim)
                lblStatus.Text = "UPDATE"

                dataTableGL = Nothing
                dataTableTAX = Nothing
                dataTableGP = Nothing

                btnSave.Enabled = False
                btnUpdate.Enabled = True
                btnDelete.Enabled = True

                BackupFile(txtTextURLGL.Text.Trim, "GL")
                BackupFile(txtTextURLGP.Text.Trim, "GP")
                BackupFile(txtTextURLTax.Text.Trim, "TAX")

                MsgBox("Data saved successfully" & vbCrLf & "Journal Hold : " & txtJournalHold.Text)

                ClearScreen()
            Else
                oleTrans.Rollback()
                MsgBox("Cannot save data" & vbCrLf & clsBusiness.gLastErrMessage)
            End If
        Else
            ClearTable()

            oleTrans = clsUtility.gConnGP.BeginTransaction()

            If gl Then
                chk_gl = cls.TmpToTable_GL(clsUtility.gConnGP, oleTrans, gUserLogin)
            End If
            If gp Then
                '--- Add by Arunya
                If Not (retCoreSystem = "TLM" And lblStatus.Text <> "ADD") Then
                    chk_gp = cls.TmpToTable_GP(clsUtility.gConnGP, oleTrans, gUserLogin)
                End If
            End If
            If tax Then
                chk_tax = cls.TmpToTable_WHT(clsUtility.gConnGP, oleTrans, gUserLogin)
            End If

            If (chk_gl And chk_gp And chk_tax) Then
                oleTrans.Commit()


                If retCoreSystem <> "TLM" Then
                    UPDATE_GPS_TRANSREF_REL(retCreateDate, retCoreSystem, retTransRef)
                End If

                retTransRef = txtTransRef.Text.Trim

                BindDataGP(retCreateDate, retCoreSystem, retTransRef)
                BindDataGL(retCreateDate, retCoreSystem, retTransRef)
                BindDataTAX(retCreateDate, retCoreSystem, retTransRef)

                If retCoreSystem = "TLM" Then
                    ListGroup(True)
                    BindDataHeader(retCreateDate, retCoreSystem, retTransRef)
                    EnableControl(False)
                Else
                    BindDataHeader(retCreateDate, retCoreSystem, retTransRef)
                    EnableControl(True)
                End If

                btnSave.Enabled = False
                btnUpdate.Enabled = True
                btnDelete.Enabled = True

                BackupFile(txtTextURLGL.Text.Trim, "GL")
                BackupFile(txtTextURLGP.Text.Trim, "GP")
                BackupFile(txtTextURLTax.Text.Trim, "TAX")

                MsgBox("Data updated successfully")
                'BackupFile(txtTextURLGL.Text.Trim, "")
                ClearScreen()
            Else
                oleTrans.Rollback()
                MsgBox("Cannot update data" & vbCrLf & clsBusiness.gLastErrMessage)
            End If

            End If

    End Sub
    Private Sub btnLoadFileGP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadFileGP.Click
        dgvGL.AllowUserToAddRows = False
        If dgvGL.RowCount <= 0 Then
            MsgBox("��سҺѹ�֡������ Tab GL")
            Exit Sub

        Else
            Select Case cboEntryTypeGP.Text
                Case "Text File"
                    '"Media Clearing","ATS �ͧ SCB"
                    If cboPayMth.SelectedValue.ToString = "M:M" Or cboPayMth.SelectedValue.ToString = "M:A" Then
                        GP_TextFile()
                    ElseIf cboPayMth.SelectedValue.ToString = "D:D" Or cboPayMth.SelectedValue.ToString = "C:B" Then
                        GP_TextFile_Draft()
                    Else
                        MsgBox("Payment Type not match")
                    End If
                Case "Excel File"
                    GP_ExcelFile()
                Case Else


            End Select
        End If
        dgvGL.AllowUserToAddRows = True
    End Sub
    Private Sub btnClearGP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearGP.Click
        Try
            dgvGP.AllowUserToAddRows = False
            If dgvGP.RowCount > 0 Then

                If MessageBox.Show("Do you want to delete this record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    For Each row As DataGridViewRow In dgvGP.SelectedRows
                        dgvGP.Rows.Remove(row)
                    Next


                    CalculateGP(False)
                End If
            End If
            dgvGP.AllowUserToAddRows = True
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnClearAllGP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAllGP.Click
        If MessageBox.Show("Do you want to delete all record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Dim dt As DataTable = Nothing
            Me.GenGridGP(dt)
            txtAmtCreditGP.Text = "0.00"
        End If
    End Sub
    Private Sub btnLoadFileTax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadFileTax.Click
        dgvGP.AllowUserToAddRows = False

        If cboGroup.SelectedValue.ToString.Trim <> "006" Then
            If dgvGP.RowCount <= 0 Then
                MsgBox("��سҺѹ�֡������ Tab GP")
                Exit Sub

            Else
                If cboEntryTypeTAX.Text = "Excel File" Then
                    TAX_ExcelFile()
                End If

            End If
        Else
            If cboEntryTypeTAX.Text = "Excel File" Then
                TAX_ExcelFile()
            End If
        End If


        dgvGP.AllowUserToAddRows = True

    End Sub
    Private Function readExcelTAX(ByVal txtExcelURL As String, ByRef ConnDB As OleDbConnection) As DataTable
        '-- 1GL --
        Dim clsGLM_ACCOUNT_SETUP As New DataClass.clsGLM_ACCOUNT_SETUP
        clsGLM_ACCOUNT_SETUP.ConnDB = ConnDB
        '-- 1GL --
        Dim oXL As Excel.Application, oBook As Excel.Workbook, oSheet As Excel.Worksheet, myvalues As Array = Nothing
        Dim INSERT As String = ""
        System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
        oXL = New Excel.Application
        oBook = oXL.Workbooks.Open(txtExcelURL)

        Try

            dataTableTAX = New DataTable

            dataTableTAX.Columns.Add("LineNo", GetType(Integer)) '-- 0
            dataTableTAX.Columns.Add("TaxID") '-- 1
            dataTableTAX.Columns.Add("IDCard") '-- 2
            dataTableTAX.Columns.Add("APTitle") '-- 3
            dataTableTAX.Columns.Add("APName") '-- 4
            dataTableTAX.Columns.Add("APLastName") '-- 5
            dataTableTAX.Columns.Add("Address") '-- 6
            dataTableTAX.Columns.Add("AMPENM") '-- 7
            dataTableTAX.Columns.Add("PROVNM") '-- 8
            dataTableTAX.Columns.Add("AGZIP") '-- 9
            dataTableTAX.Columns.Add("TaxType") '-- 10
            dataTableTAX.Columns.Add("TaxItem") '-- 11
            dataTableTAX.Columns.Add("TaxDate") '-- 12
            dataTableTAX.Columns.Add("BaseAmount") '-- 13
            dataTableTAX.Columns.Add("WHTAmount") '-- 14
            dataTableTAX.Columns.Add("Payee") '-- 15
            dataTableTAX.Columns.Add("TaxRate") '-- 16
            dataTableTAX.Columns.Add("Description") '-- 17
            dataTableTAX.Columns.Add("AccountCode") '-- 18
            dataTableTAX.Columns.Add("TransRef") '-- 19
            dataTableTAX.Columns.Add("SubAccountCode") '-- 20

            oSheet = oBook.Worksheets(1) 'ex. index="1,2" ,name ="Sheet1,Sheet2"
            myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()

            'If myvalues Is Nothing Then
            '    oSheet = oBook.Worksheets("Sheet1")
            '    myvalues = oSheet.Range("A1", oSheet.Cells(oSheet.UsedRange.Rows.Count(), oSheet.UsedRange.Columns.Count())).Rows.Value()
            'End If

            '�ŧ�ҡ Array 
            Dim rowNew As DataRow, firstColumnIsNothing As Boolean
            For rowIndex As Integer = 2 To oSheet.UsedRange.Rows.Count()
                'rowNew = dataTableTAX.NewRow
                'firstColumnIsNothing = False
                'For columnIndex As Integer = 1 To oSheet.UsedRange.Columns.Count()
                '    If myvalues(rowIndex, 1) Is Nothing And myvalues(rowIndex, 2) Is Nothing Then
                '        firstColumnIsNothing = True
                '        Exit For
                '    ElseIf myvalues(rowIndex, columnIndex) Is Nothing Then
                '        rowNew.Item(columnIndex - 1) = ""
                '    Else
                '        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString
                '    End If
                'Next
                rowNew = dataTableTAX.NewRow
                firstColumnIsNothing = False
                If myvalues(rowIndex, 1) Is Nothing Then
                    firstColumnIsNothing = True
                    Exit For
                End If
                For columnIndex As Integer = 1 To 20 'oSheet.UsedRange.Columns.Count()
                    'If myvalues(rowIndex, 1) Is Nothing Then
                    '    firstColumnIsNothing = True
                    '    Exit For
                    'Else
                    If myvalues(rowIndex, columnIndex) Is Nothing Then
                        rowNew.Item(columnIndex - 1) = ""
                    Else
                        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim
                    End If

                    'Split a Account Code
                    ''If columnIndex = 19 Then
                    ''    If myvalues(rowIndex, columnIndex).ToString.Trim.Length > 7 Then
                    ''        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(0, 7) '-- AccountCode
                    ''        rowNew.Item(20) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(7)  '-- SubAccountCode
                    ''    Else
                    ''        rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim '-- AccountCode
                    ''        rowNew.Item(20) = "" '-- SubAccountCode
                    ''    End If
                    ''End If
                    If columnIndex = 19 Then
                        '--If myvalues(rowIndex, columnIndex).ToString.Trim.Length > 7 Then
                        If myvalues(rowIndex, columnIndex).ToString.Trim.Length > 7 And myvalues(rowIndex, columnIndex).ToString.Trim.Length < 14 Then
                            '--rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(0, 7) '-- SunAccCode
                            '--rowNew.Item(columncount) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(7)  '-- Sub_acct
                            rowNew.Item(columnIndex - 1) = clsGLM_ACCOUNT_SETUP.Get_1Gl_Account_By_S_CODE(myvalues(rowIndex, columnIndex).ToString.Trim) '-- SunAccCode
                            rowNew.Item(20) = clsGLM_ACCOUNT_SETUP.Get_1Gl_SubAccount_By_S_CODE(myvalues(rowIndex, columnIndex).ToString.Trim) '-- Sub_acct
                        ElseIf myvalues(rowIndex, columnIndex).ToString.Trim.Length = 14 Then
                            '-- 1GL code --
                            rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(0, 7) '-- SunAccCode
                            rowNew.Item(20) = myvalues(rowIndex, columnIndex).ToString.Trim.Substring(7, 7) '-- SunAccCode
                        Else
                            rowNew.Item(columnIndex - 1) = myvalues(rowIndex, columnIndex).ToString.Trim '-- SunAccCode
                            rowNew.Item(20) = "" '-- Sub_acct
                        End If
                    End If

                Next
                If firstColumnIsNothing = False Then
                    dataTableTAX.Rows.Add(rowNew)
                End If
            Next
            dataTableTAX.AcceptChanges()
        Catch ex As Exception
            If ex.Message.IndexOf("BADINDEX") <> -1 Then
                Throw New Exception("Sheet name in excel file not correct")
            End If
        Finally
            oSheet = Nothing
            oBook.Close()
            oBook = Nothing
            oXL.Quit()
            oXL = Nothing
        End Try

        Return dataTableTAX
    End Function
    Private Sub ClearValidateGrid(ByVal grd As DataGridView)
        For Each tempRow As System.Windows.Forms.DataGridViewRow In grd.Rows
            For Each tempCell As Windows.Forms.DataGridViewCell In tempRow.Cells
                tempCell.Style.BackColor = Color.WhiteSmoke
            Next
        Next
    End Sub
    Private Sub SetDefaultDueDate_ORG(ByVal payment_subpayment As String)

        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim dateString As String ' = Now.ToString("yyyyMMdd")
        Dim format As String = "yyyyMMdd"
        Dim StartDate As Date
        Dim Duedate As Date
        Dim countworkdate As Integer
        Dim i_date As Integer

        dateString = DateTime.Now.ToString("yyyyMMdd", en)

        If lblStatus.Text = "ADD" Then
            StartDate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-US"))
            Duedate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-US"))


            Select Case payment_subpayment
                Case "C:C" '"SCB M Cheque"
                    i_date = 2
                Case "D:D" '"SCB M Draft"
                    i_date = 2
                Case "M:M" '"Media Clearing"
                    i_date = 3
                Case "C:Q" '"Company Cheque"
                    i_date = 1
                Case "C:H" '"SCB Cashier Cheque"
                    i_date = 2
                Case "M:A" '"ATS �ͧ SCB"
                    i_date = 3
                Case "C:G" '"SCB Gift Cheque (�礢ͧ��ѭ)"
                    i_date = 2
                Case "C:T" '"Money Order (��ҳѵ�)"
                    i_date = 2
                Case "C:B" '"Bank Draft"
                    i_date = 2
                Case "M:C" ' "Credit Card (�ѵ��ôԵ)"
                    i_date = 7
                Case "M:B" '"�͹�Թ��ҧ�����"
                    i_date = 2
            End Select


            Do While countworkdate <> i_date
                Duedate = DateAdd(DateInterval.Day, 1, Duedate)

                chkHoliday = LookUpHoliday(Duedate.ToString("yyyyMMdd"), Duedate.ToString("yyyyMMdd"))
                If chkHoliday > 0 Then
                    i_date = i_date + 1
                End If

                chkWorkDay = GetWorkDay(Duedate)
                If chkWorkDay Then
                    countworkdate += 1
                End If

            Loop


            dtpDueDate.Value = Date.ParseExact(Duedate.ToString("yyyyMMdd"), format, New Globalization.CultureInfo("en-US")) 'Duedate.ToString("dd/MM/yyyy")

        End If
    End Sub
    Private Sub SetDefaultDueDate(ByVal payment_subpayment As String)

        Dim chkHoliday As Integer
        Dim chkWorkDay As Boolean
        Dim dateString As String ' = Now.ToString("yyyyMMdd")
        Dim format As String = "yyyyMMdd"
        Dim StartDate As Date
        Dim Duedate As Date
        Dim countworkdate As Integer
        Dim i_date As Integer

        dateString = DateTime.Now.ToString("yyyyMMdd", en)

        If lblStatus.Text = "ADD" Then
            StartDate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-US"))
            Duedate = Date.ParseExact(dateString, format, New Globalization.CultureInfo("en-US"))


            Select Case payment_subpayment
                Case "C:C" '"SCB M Cheque"
                    '-- AP-2016-008 'i_date = 2
                    i_date = 1
                Case "D:D" '"SCB M Draft"
                    i_date = 1
                Case "M:M" '"Media Clearing"
                    i_date = 2
                Case "C:Q" '"Company Cheque"
                    i_date = 1
                Case "C:H" '"SCB Cashier Cheque"
                    i_date = 2
                Case "M:A" '"ATS �ͧ SCB"
                    i_date = 3
                Case "C:G" '"SCB Gift Cheque (�礢ͧ��ѭ)"
                    i_date = 2
                Case "C:T" '"Money Order (��ҳѵ�)"
                    i_date = 2
                Case "C:B" '"Bank Draft"
                    i_date = 2
                Case "M:C" ' "Credit Card (�ѵ��ôԵ)"
                    i_date = 7
                Case "M:B" '"�͹�Թ��ҧ�����"
                    i_date = 2
            End Select


            Do While countworkdate <> i_date
                Duedate = DateAdd(DateInterval.Day, 1, Duedate)

                chkHoliday = LookUpHoliday(Duedate.ToString("yyyyMMdd"), Duedate.ToString("yyyyMMdd"))
                If chkHoliday > 0 Then
                    i_date = i_date + 1
                End If

                chkWorkDay = GetWorkDay(Duedate)
                If chkWorkDay Then
                    countworkdate += 1
                End If

            Loop


            dtpDueDate.Value = Date.ParseExact(Duedate.ToString("yyyyMMdd"), format, New Globalization.CultureInfo("en-US")) 'Duedate.ToString("dd/MM/yyyy")

        End If
    End Sub
    Function LookUpHoliday(ByVal d_start As String, ByVal d_end As String) As Integer

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE BETWEEN '" & d_start & "'  AND '" & d_end & "'  AND HLDS_COMPANY_CODE='SCB' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString()
        Else
            Return 0
        End If

    End Function
    Public Function CountWorkDay(ByVal StartDate As Date, ByVal EndDate As Date)
        Dim count = 0
        Dim totalDays = (EndDate - StartDate).Days
        Dim i As Integer
        For i = 0 To totalDays
            Dim weekday As DayOfWeek = StartDate.AddDays(i).DayOfWeek
            If weekday <> DayOfWeek.Saturday AndAlso weekday <> DayOfWeek.Sunday Then
                count += 1
            End If
        Next
        Return count
    End Function
    Public Function GetWorkDay(ByVal CurrentDate As DateTime) As Boolean

        Select Case CurrentDate.DayOfWeek
            Case DayOfWeek.Saturday
                Return False
            Case DayOfWeek.Sunday
                Return False
            Case Else
                'handles sunday through thursday
                Return True
        End Select

    End Function

    Private Sub btnClearAllTax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAllTax.Click
        If MessageBox.Show("Do you want to delete all record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Dim dt As DataTable = Nothing
            Me.GenGridTax(dt)
            txtBaseAmt.Text = "0.00"
            txtInputWHTAmt.Text = "0.00"
        End If
    End Sub
    Private Sub btnClearTax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearTax.Click
        Try
            dgvTax.AllowUserToAddRows = False
            If dgvTax.RowCount > 0 Then

                If MessageBox.Show("Do you want to delete this record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    For Each row As DataGridViewRow In dgvTax.SelectedRows
                        dgvTax.Rows.Remove(row)
                    Next

                    CalculateTAX()
                End If
            End If
            dgvTax.AllowUserToAddRows = True
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        If MessageBox.Show("Do you want to clear all data ? (Y/N)", "Confirm Clear Data", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            ClearScreen()
        End If

    End Sub
    Private Sub ClearScreen()
        Dim dt As DataTable = Nothing

        ListGroup()
        ListDataSource()
        ListJournalType()

        txtJournalHold.Text = ""
        txtTransRef.Text = ""
        txtAccPeriod.Text = DateTime.Now.ToString("MM/yyyy", en) 'Now.ToString("MM/yyyy")
        dtpDueDate.Value = Now
        '----------GL------------
        'cboEntryType.SelectedIndex = 0
        Me.GenGridGL(dt)

        lbltxtTotalLine.Text = "0"
        txtAmtDebits.Text = "0.00"
        txtAmtCredits.Text = "0.00"
        txtOutOfBalance.Text = "0.00"
        txtOutOfBalance.ForeColor = Color.Black
        '----------GP------------
        Me.GenGridGP(dt)
        txtAmtCreditGP.Text = "0.00"
        '----------TAX------------
        Me.GenGridTax(dt)
        txtBaseAmt.Text = "0.00"
        txtInputWHTAmt.Text = "0.00"

        EnableControl(True)


        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False

        retCreateDate = ""
        retCoreSystem = ""
        retTransRef = ""
        retJnHold = ""

        txtTextURLGL.Text = ""
        txtTextURLGP.Text = ""
        txtTextURLTax.Text = ""

        cboEntryType.SelectedIndex = 0
        cboEntryTypeGP.SelectedIndex = 0
        cboEntryTypeTAX.SelectedIndex = 0

        chkFlagAllGP.Checked = False

        lblStatus.Text = "ADD"

        'btnSave.Enabled = False 

    End Sub
    Private Sub btnPrintGL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintGL.Click
        PrintGL()
        'PrintGP()
        'PrintTAX()
    End Sub
    Function GetDataGL() As DataTable
        Dim sb As New StringBuilder()

        'sb.Append("SELECT L.* FROM GPS_GL_CREATION L  ")
        sb.Append("SELECT L.*, S.ACNT_NAME_TH subaccname FROM GPS_GL_CREATION L left join GLM_ACCOUNT_SETUP S on L.Glcr_Sub_Acct = S.ACNT_S_CODE ")
        sb.Append("WHERE L.GLCR_JN_HOLD='" & txtJournalHold.Text.Trim & "' ")
        sb.Append("ORDER BY L.GLCR_LINENO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function GetDataTAX() As DataTable
        Dim sb As New StringBuilder()


        sb.Append("SELECT taxcr_createdate, taxcr_core_system, taxcr_transref, taxcr_gptref_seqno, taxcr_lineno, taxcr_taxid, taxcr_idcard, taxcr_ap_ttl, taxcr_ap_fname, taxcr_ap_lname, taxcr_address, taxcr_ampenm, taxcr_provnm, taxcr_agzip, taxcr_taxtype, taxcr_taxitem, taxcr_taxdate, taxcr_base_amt, taxcr_tax_amt, taxcr_payee, taxcr_tax_rate, taxcr_desc, case when length(taxcr_gl_account) > 7 then taxcr_gl_account else taxcr_gl_account || taxcr_sub_acct end as taxcr_gl_account, taxcr_approvedby, taxcr_approveddate, taxcr_flag_validate, taxcr_flag_batch, taxcr_batchdate, taxcr_reject_type, createdby, createddate, updatedby, updateddate, taxcr_adjl_log_id, taxcr_remark, taxcr_sub_acct FROM GPS_WHT_CREATION T ")
        sb.Append("WHERE T.TAXCR_TRANSREF='" & txtTransRef.Text.Trim & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub PrintGL()
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptJournalEntryEditList_GL.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataGL()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()
            Dim discreteHeader As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramHeader As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = txtEntryDate.Text
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            paramHeader.ParameterFieldName = "pHeader"
            discreteHeader.Value = "Journal Entry Edit List"
            paramHeader.CurrentValues.Add(discreteHeader)
            paramFields.Add(paramHeader)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()


        End If

    End Sub
    Private Sub PrintGP()


        Dim reportname As String = ""
        Dim dt As DataTable = New DataTable()

        Select Case cboPayMth.SelectedValue.ToString
            Case "D:D"
                reportname = "RptGP_M_Draft.rpt"
            Case "M:M", "M:A"
                reportname = "RptGP_Media_ATS.rpt"
            Case "M:C"
                reportname = "RptGP_CreditCard.rpt"
            Case "C:C", "C:G", "C:T"
                reportname = "RptGP_M_Cheque_Gift_MoneyOrder.rpt"
            Case "M:B"
                reportname = "RptGP_OverSea.rpt"
        End Select
        Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
        Dim subpay As String = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)


        dt = GetDataGP(pay, subpay)

        If Not IsNothing(dt) AndAlso dt.Rows.Count Then
            CallReportGP(reportname, dt)
        End If


    End Sub
    Function GetDataGP(ByVal paytype As String, ByVal sub_paytype As String) As DataTable
        Dim sb As New StringBuilder()

        sb.Append("SELECT P.* ")
        sb.Append("FROM GPS_PAYMENT_CREATION P  ")
        sb.Append("WHERE P.GPCR_TRANSREF='" & txtTransRef.Text.Trim & "' ")
        sb.Append("AND P.GPCR_PAYMTH='" & paytype & "' AND P.GPCR_SUB_PAYMTH='" & sub_paytype & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Private Sub CallReportGP(ByVal reportname As String, ByVal dt As DataTable)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)

        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & reportname)

        frm1.FillDataTableToReport(dt)

        Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
        Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param1 As New CrystalDecisions.Shared.ParameterField()
        Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim param2 As New CrystalDecisions.Shared.ParameterField()
        Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim paramUser As New CrystalDecisions.Shared.ParameterField()

        param1.ParameterFieldName = "pJournalType"
        discrete1.Value = cboJournalType.Text
        param1.CurrentValues.Add(discrete1)
        paramFields.Add(param1)

        param2.ParameterFieldName = "pTransdate"
        discrete2.Value = txtEntryDate.Text
        param2.CurrentValues.Add(discrete2)
        paramFields.Add(param2)

        paramUser.ParameterFieldName = "pUser"
        discreteUser.Value = gUserFullName
        paramUser.CurrentValues.Add(discreteUser)
        paramFields.Add(paramUser)

        frm1.CrViewer.ParameterFieldInfo = paramFields
        frm1.Text = Me.Text
        frm1.Show()

    End Sub
    Private Sub PrintTAX()
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()
        frm1.CrDoc.Load(sReportPath & "RptTAX.rpt")

        Dim dt As DataTable = New DataTable()

        dt = GetDataTAX()
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            frm1.FillDataTableToReport(dt)

            Dim paramFields As New CrystalDecisions.Shared.ParameterFields()
            Dim discrete1 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param1 As New CrystalDecisions.Shared.ParameterField()
            Dim discrete2 As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim param2 As New CrystalDecisions.Shared.ParameterField()
            Dim discreteUser As New CrystalDecisions.Shared.ParameterDiscreteValue()
            Dim paramUser As New CrystalDecisions.Shared.ParameterField()

            param1.ParameterFieldName = "pJournalType"
            discrete1.Value = cboJournalType.Text
            param1.CurrentValues.Add(discrete1)
            paramFields.Add(param1)

            param2.ParameterFieldName = "pTransdate"
            discrete2.Value = txtEntryDate.Text
            param2.CurrentValues.Add(discrete2)
            paramFields.Add(param2)

            paramUser.ParameterFieldName = "pUser"
            discreteUser.Value = gUserFullName
            paramUser.CurrentValues.Add(discreteUser)
            paramFields.Add(paramUser)

            frm1.CrViewer.ParameterFieldInfo = paramFields
            frm1.Text = Me.Text
            frm1.Show()

        End If
    End Sub
    Private Sub cboGroup_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGroup.SelectedIndexChanged
        '002=�ѹ�֡ GL, GP, WHT ����к�������ѹ (��¡�è��»���)
        Try

            dtpDueDate.Value = Now '.ToString("dd/MM/yyyy")


            If cboGroup.SelectedValue.ToString = "002" Then
                SetDefaultDueDate(cboPayMth.SelectedValue.ToString)
            End If

            If cboGroup.SelectedValue.ToString = "003" Then
                ListPaymenType(" (PAYT_PAYTYPE='Company Cheque' OR PAYT_PAYTYPE='�͹�Թ��ҧ�����') ")
                cboPayMth.SelectedIndex = 1
                cboPayMth.Enabled = True
            ElseIf cboGroup.SelectedValue.ToString = "006" Then
                ListOverSea()
                cboOverSea.SelectedIndex = 0
                cboOverSea.Enabled = False

                ListPaymenType()
                cboPayMth.SelectedIndex = 0
                cboPayMth.Enabled = False

            Else
                ListOverSea()
                cboOverSea.SelectedIndex = 1
                cboOverSea.Enabled = True

                ListPaymenType()
                cboPayMth.SelectedIndex = 1
                cboPayMth.Enabled = True

            End If

            'dtpDueDate.Value = Now.ToString("dd/MM/yyyy")

        Catch ex As Exception

        End Try

    End Sub
    Private Sub txtAccPeriod_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAccPeriod.KeyPress
        If e.KeyChar = "/"c Then
            e.Handled = (CType(sender, TextBox).Text.IndexOf("/"c) <> -1)
        ElseIf e.KeyChar <> ControlChars.Back Then
            e.Handled = ("0123456789".IndexOf(e.KeyChar) = -1)
        End If
        Dim i As Integer = txtAccPeriod.Text.Length
        If (i = 6) Then
            Try

                If InStr(1, txtAccPeriod.Text, "/") = 0 Then
                    Dim dateString As String = txtAccPeriod.Text
                    Dim formats As String = "MMyyyy"
                    Dim dateValue As DateTime
                    If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                        txtAccPeriod.Text = dateValue.ToString("MM/yyyy", en) 'dateValue.ToString("MM/yyyy")
                    Else
                        MsgBox("Date Should Be Entered in Format MM/yyyy")
                        txtAccPeriod.Text = DateTime.Now.ToString("MM/yyyy", en) 'Now.ToString("MM/yyyy")
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message & vbCrLf & "Date Should Be Entered in Format MM/yyyy")
                txtAccPeriod.Clear()
            End Try
        End If

    End Sub
    Private Sub txtAccPeriod_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAccPeriod.Validated

        Dim i As Integer = txtAccPeriod.Text.Length
        'If (i = 6) Then
        Try

            If InStr(1, txtAccPeriod.Text, "/") = 0 Then
                Dim dateString As String = txtAccPeriod.Text
                Dim formats As String = "MMyyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    txtAccPeriod.Text = dateValue.ToString("MM/yyyy", en) 'dateValue.ToString("MM/yyyy")
                Else
                    MsgBox("Date Should Be Entered in Format MM/yyyy")
                    txtAccPeriod.Text = DateTime.Now.ToString("MM/yyyy", en) 'Now.ToString("MM/yyyy")
                End If
            Else
                Dim dateString As String = txtAccPeriod.Text
                Dim formats As String = "MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                    txtAccPeriod.Text = dateValue.ToString("MM/yyyy", en) 'dateValue.ToString("MM/yyyy")
                Else
                    MsgBox("Date Should Be Entered in Format MM/yyyy")
                    txtAccPeriod.Text = DateTime.Now.ToString("MM/yyyy", en) 'Now.ToString("MM/yyyy")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & "Date Should Be Entered in Format MM/yyyy")
            txtAccPeriod.Clear()
        End Try
        ' End If
    End Sub
    Private Sub cboEntryType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEntryType.SelectedIndexChanged

        'If retCoreSystem <> "TLM" Then

        '    Dim dt As New DataTable
        '    dt = Nothing
        '    GenGridGL(dt)

        'End If

    End Sub
    Private Sub cboEntryTypeGP_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEntryTypeGP.SelectedIndexChanged

        'Dim dt As New DataTable
        'dt = Nothing
        'GenGridGP(dt)

    End Sub
    Private Sub cboEntryTypeTAX_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEntryTypeTAX.SelectedIndexChanged

        'Dim dt As New DataTable
        'dt = Nothing
        'GenGridTax(dt)

    End Sub
    Private Sub UPDATE_INTERFACE_CONTROL_STATUS(ByVal status As String)

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO", status, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()

            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            MsgBox(clsBusiness.gLastErrMessage)
        End If
    End Sub
    Private Sub UPDATE_INTERFACE_CONTROL_NO()

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        rec = clsBusiness.UPDATE_INTERFACE_CONTROL_NO(clsUtility.gConnGP, "JN_HO", oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()

            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Function GetJournalHold() As String

        Dim chk As Boolean
        Dim no As String
        chk = clsBusiness.CHECK_INTERFACE_CONTROL_STATUS(clsUtility.gConnGP, "JN_HO")

        If chk Then

            UPDATE_INTERFACE_CONTROL_STATUS("START")

            no = clsBusiness.GET_NO_INTERFACE_CONTROL(clsUtility.gConnGP, "JN_HO")

            UPDATE_INTERFACE_CONTROL_NO()

            UPDATE_INTERFACE_CONTROL_STATUS("STOP")
        Else
            no = ""
            GetJournalHold()
        End If

        Return no
    End Function
    Function GL_UpdateJournalHold(ByVal LoadDate As String) As Boolean
        Dim ret As Boolean = False

        Dim dt As DataTable
        dt = JournalHoldToTemp(LoadDate)

        If dt.Rows.Count > 0 Then

            Dim rec As Integer
            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows
                Dim sb1 As New StringBuilder

                'Update Journal Hold to txtJournalHold
                txtJournalHold.Text = dr("JournalHold")

                sb1.Append("UPDATE GPS_GL_CREATION SET ")
                sb1.Append("GLCR_JN_HOLD = '" & dr("JournalHold") & "' ")
                sb1.Append("WHERE GLCR_CREATEDATE='" & LoadDate & "' ")
                sb1.Append("AND GLCR_TRANSREF = '" & dr("Transref") & "' ")
                sb1.Append("AND GLCR_CORE_SYSTEM='ACC'")

                rec = rec + clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb1, oleTrans)
            Next


            If rec >= 0 Then
                oleTrans.Commit()

                ret = True
                'MsgBox("Update already")
            Else
                oleTrans.Rollback()

                ret = False
                'MsgBox(clsBusiness.gLastErrMessage)
            End If

        End If

        Return ret

    End Function
    Function JournalHoldToTemp(ByVal LoadDate As String) As DataTable

        dtJournalHold = Nothing

        If dtJournalHold Is Nothing Then
            dtJournalHold = New DataTable("TempJN")

            dtJournalHold.Columns.Add("Transref")
            dtJournalHold.Columns.Add("JournalHold")
        End If

        Dim Row As DataRow

        retJnHold = ""
        Do While retJnHold = ""
            retJnHold = GetJournalHold()
        Loop


        Row = dtJournalHold.NewRow

        Row.Item(0) = txtTransRef.Text.Trim
        Row.Item(1) = retJnHold 'jn_ho

        dtJournalHold.Rows.Add(Row)


        Return dtJournalHold
    End Function
    Function UPDATE_GPS_TRANSREF_REL(ByVal createdate As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean = False
        Dim oleTrans As OleDbTransaction
        Dim rec As Integer

        Dim sb As New StringBuilder
        Dim period As String = txtAccPeriod.Text.Substring(3, 4) & txtAccPeriod.Text.Substring(0, 2).PadLeft(3, "0")

        Dim deprepay As String
        deprepay = cls.LookUp_DepRepay(clsUtility.gConnGP, cboDataSource.SelectedValue.ToString, "ACC", lblDept.Text)


        oleTrans = clsUtility.gConnGP.BeginTransaction()

        sb.Append("UPDATE GPS_TRANSREF_REL SET TREF_TRANSREF='" & txtTransRef.Text.Trim & "',  ")
        sb.Append("TREF_JN_TYPE='" & cboJournalType.SelectedValue.ToString & "',")
        sb.Append("TREF_GL_PERIOD='" & period & "',")
        sb.Append("TREF_PAYCRETYP_ID='" & cboGroup.SelectedValue.ToString & "',")
        sb.Append("TREF_PAIDDATE='" & dtpDueDate.Value.ToString("yyyyMMdd") & "',")
        sb.Append("TREF_OSEA_LIST='" & cboOverSea.SelectedValue.ToString & "',")
        If cboGroup.SelectedValue <> "006" Then
            sb.Append("TREF_PAYMTH='" & Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) & "',")
            sb.Append("TREF_SUB_PAYMTH='" & Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) & "',")
        End If

        sb.Append("TREF_DTSOURCE='" & cboDataSource.SelectedValue.ToString & "',")
        sb.Append("TREF_DEP_KEYIN='" & lblDept.Text & "',")
        sb.Append("TREF_DEP_REPAY='" & deprepay & "',")
        sb.Append("TREF_JN_HOLD='" & txtJournalHold.Text & "',")
        sb.Append("TREF_PPOSE_PCHASE='" & txtPurpose.Text.Trim & "',")
        sb.Append("UPDATEDBY='" & gUserLogin & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")

        sb.Append("WHERE TREF_CREATEDATE='" & createdate & "' AND TREF_CORE_SYSTEM='" & core_system & "' AND TREF_TRANSREF='" & transref & "' ")

        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)

        If rec >= 0 Then
            oleTrans.Commit()

            ret = True
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            ret = False
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

        Return ret
    End Function
    Function INS_GPS_TRANSREF_REL(ByVal systemdate As String) As Boolean
        Dim ret As Boolean = False
        Dim period As String = txtAccPeriod.Text.Substring(3, 4) & txtAccPeriod.Text.Substring(0, 2).PadLeft(3, "0")

        Dim deprepay As String
        deprepay = cls.LookUp_DepRepay(clsUtility.gConnGP, cboDataSource.SelectedValue.ToString, "ACC", lblDept.Text)

        Dim oleTrans As OleDbTransaction
        Dim rec As Integer
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim sb As New StringBuilder


        sb.Append("INSERT INTO GPS_TRANSREF_REL ( ")
        sb.Append("TREF_CREATEDATE,TREF_CORE_SYSTEM,TREF_TRANSREF,")
        sb.Append("TREF_JN_TYPE,TREF_GL_PERIOD,TREF_PAYCRETYP_ID,")
        sb.Append("TREF_PAIDDATE,TREF_OSEA_LIST, ")

        If cboGroup.SelectedValue <> "006" Then
            sb.Append("TREF_PAYMTH,TREF_SUB_PAYMTH,")
        End If

        sb.Append("TREF_DTSOURCE,TREF_DEP_KEYIN,TREF_DEP_REPAY,")
        sb.Append("TREF_JN_HOLD,TREF_PPOSE_PCHASE,CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE)")
        sb.Append("VALUES (")
        sb.Append("'" & systemdate & "',")
        sb.Append("'ACC',")
        sb.Append("'" & txtTransRef.Text & "',")
        sb.Append("'" & cboJournalType.SelectedValue.ToString & "',")
        sb.Append("'" & period & "',")
        sb.Append("'" & cboGroup.SelectedValue.ToString & "',")
        sb.Append("'" & dtpDueDate.Value.ToString("yyyyMMdd") & "',")
        sb.Append("'" & cboOverSea.SelectedValue.ToString & "',")

        If cboGroup.SelectedValue <> "006" Then
            sb.Append("'" & Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1) & "',")
            sb.Append("'" & Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1) & "',")
        End If

        sb.Append("'" & cboDataSource.SelectedValue.ToString & "',") 'ACC
        sb.Append("'" & lblDept.Text & "',") 'ACC
        sb.Append("'" & deprepay & "',") 'ACC
        sb.Append("'" & txtJournalHold.Text & "',")
        sb.Append("'" & txtPurpose.Text.Trim & "',")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")


        rec = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb, oleTrans)


        If rec >= 0 Then
            oleTrans.Commit()

            ret = True
            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            ret = False
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

        Return ret

    End Function
    Private Sub BindDataGP(ByVal createdate As String, ByVal core_system As String, ByVal transref As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_PAYMENT_CREATION WHERE GPCR_CREATEDATE = '" & createdate & "' AND GPCR_CORE_SYSTEM='" & core_system & "' AND GPCR_TRANSREF='" & transref & "' AND GPCR_APPROVEDBY IS NULL ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            dataTableGP = Nothing
            Dim row As DataRow
            If dataTableGP Is Nothing Then

                dataTableGP = New DataTable("DtGP")

                dataTableGP.Columns.Add("TransRef")
                dataTableGP.Columns.Add("PolNo")
                dataTableGP.Columns.Add("BillNo")
                dataTableGP.Columns.Add("DueDate")
                dataTableGP.Columns.Add("Amount")
                dataTableGP.Columns.Add("Description")
                dataTableGP.Columns.Add("PaymentType")
                dataTableGP.Columns.Add("PayeeName")
                dataTableGP.Columns.Add("BankCode")
                dataTableGP.Columns.Add("BankNumber")
                dataTableGP.Columns.Add("BankBranch")
                dataTableGP.Columns.Add("BankName")
                dataTableGP.Columns.Add("PayeeBankAccNo")
                dataTableGP.Columns.Add("PayeeBankAccName")
                dataTableGP.Columns.Add("Comment")
                dataTableGP.Columns.Add("Address1")
                dataTableGP.Columns.Add("District")
                dataTableGP.Columns.Add("Province")
                dataTableGP.Columns.Add("InsureName")
                dataTableGP.Columns.Add("DataSource")
                dataTableGP.Columns.Add("Reserve6")
                dataTableGP.Columns.Add("TransCard") 'Reserve10
                dataTableGP.Columns.Add("Sys_Ref")
                dataTableGP.Columns.Add("Sys_Gr")
                dataTableGP.Columns.Add("SubPaymentType")
                dataTableGP.Columns.Add("Flag")
                dataTableGP.Columns.Add("OverSea")
                dataTableGP.Columns.Add("Phone")
                dataTableGP.Columns.Add("Fax")
                dataTableGP.Columns.Add("SwiftCode")
                dataTableGP.Columns.Add("BankBranchName")
                dataTableGP.Columns.Add("BankAddress")
                dataTableGP.Columns.Add("Country")
                dataTableGP.Columns.Add("Currency")
                dataTableGP.Columns.Add("ExchangeRate")
                dataTableGP.Columns.Add("BankCharge")
                dataTableGP.Columns.Add("GPLine")
                dataTableGP.Columns.Add("MerchartNo")
            End If


            For Each dr As DataRow In dt.Rows
                row = dataTableGP.NewRow
                Dim amt As Decimal
                amt = Convert.ToDecimal(dr("GPCR_AMOUNT"))

                row.Item(0) = dr("GPCR_TRANSREF").ToString.Trim
                row.Item(1) = dr("GPCR_POLNO").ToString.Trim
                row.Item(2) = dr("GPCR_BILLNO").ToString.Trim
                row.Item(3) = dr("GPCR_PAIDDATE").ToString.Substring(6, 2) & "/" & dr("GPCR_PAIDDATE").ToString.Substring(4, 2) & "/" & dr("GPCR_PAIDDATE").ToString.Substring(0, 4)
                row.Item(4) = amt.ToString("###,###.00") 'dr("GPCR_AMOUNT").ToString.Trim
                row.Item(5) = dr("GPCR_DESC").ToString.Trim
                row.Item(6) = dr("GPCR_PAYMTH").ToString.Trim
                row.Item(7) = dr("GPCR_PAYEE_NAME").ToString.Trim
                row.Item(8) = dr("GPCR_BNKCODE").ToString.Trim
                row.Item(9) = dr("GPCR_BNKCODE_NO").ToString.Trim
                row.Item(10) = dr("GPCR_BNKBRN").ToString.Trim
                row.Item(11) = dr("GPCR_BNKNAME").ToString.Trim
                row.Item(12) = dr("GPCR_PAYEE_BNKACCNO").ToString.Trim
                row.Item(13) = dr("GPCR_PAYEE_BNKACCNME").ToString.Trim
                row.Item(14) = dr("GPCR_COMMENT").ToString.Trim
                row.Item(15) = dr("GPCR_ADDRESS1").ToString.Trim
                row.Item(16) = dr("GPCR_DISTRICT").ToString.Trim
                row.Item(17) = dr("GPCR_PROVINCE").ToString.Trim
                row.Item(18) = dr("GPCR_INSURENAME").ToString.Trim
                row.Item(19) = dr("GPCR_DATASOURCE_NME").ToString.Trim
                row.Item(20) = dr("GPCR_RESERVE6").ToString.Trim

                If dr("GPCR_CDCARD_DATE").ToString <> "" Then
                    row.Item(21) = dr.Item("GPCR_CDCARD_DATE").ToString.Substring(6, 2) & "/" & dr.Item("GPCR_CDCARD_DATE").ToString.Substring(4, 2) & "/" & dr.Item("GPCR_CDCARD_DATE").ToString.Substring(0, 4)
                End If

                ' row.Item(21) = dr("GPCR_CDCARD_DATE").ToString.Trim 'GPCR_CDCARD_DATE'GPCR_RESERVE10
                row.Item(22) = dr("GPCR_SYS_REF").ToString.Trim
                row.Item(23) = dr("GPCR_SYS_GR").ToString.Trim
                row.Item(24) = dr("GPCR_SUB_PAYMTH").ToString.Trim
                row.Item(25) = dr("GPCR_FLAG_FLWBILL").ToString 'IIf(dr("GPCR_FLAG_FLWBILL").ToString.Trim = "Y", True, False)
                row.Item(26) = dr("GPCR_OSEA_LIST").ToString.Trim
                row.Item(27) = dr("GPCR_PHONE").ToString.Trim
                row.Item(28) = dr("GPCR_FAX").ToString.Trim
                row.Item(29) = dr("GPCR_SWIFT_CODE").ToString.Trim
                row.Item(30) = dr("GPCR_BNKBRN_NAME").ToString.Trim
                row.Item(31) = dr("GPCR_BNKADDR").ToString.Trim
                row.Item(32) = dr("GPCR_COUNTRY").ToString.Trim
                row.Item(33) = dr("GPCR_CURRENCY").ToString.Trim
                row.Item(34) = dr("GPCR_EXCHN_RATE").ToString.Trim
                row.Item(35) = dr("GPCR_BNKCHARGES").ToString.Trim
                row.Item(36) = dr("GPCR_GPTREF_SEQNO").ToString.Trim
                row.Item(37) = dr("GPCR_MERCHN_NO").ToString.Trim

                dataTableGP.Rows.Add(row)

            Next

            GenGridGP(dataTableGP)

        Else
            dataTableGP = Nothing
            GenGridGP(dataTableGP)
        End If

    End Sub
    Private Sub BindDataGL(ByVal createdate As String, ByVal core_system As String, ByVal transref As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_GL_CREATION WHERE GLCR_CREATEDATE = '" & createdate & "' AND GLCR_CORE_SYSTEM='" & core_system & "' AND GLCR_TRANSREF='" & transref & "' AND GLCR_APPROVEDBY IS NULL Order By GLCR_LINENO")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If dt.Rows.Count > 0 Then
            dataTableGL = Nothing
            Dim row As DataRow
            If dataTableGL Is Nothing Then

                dataTableGL = New DataTable("DtGL")

                dataTableGL.Columns.Add("TransRef")
                dataTableGL.Columns.Add("LineNo")
                dataTableGL.Columns.Add("TransDate")
                dataTableGL.Columns.Add("DueDate")
                dataTableGL.Columns.Add("Description")
                dataTableGL.Columns.Add("OracleAccCode")
                dataTableGL.Columns.Add("Amount")
                dataTableGL.Columns.Add("DC")
                dataTableGL.Columns.Add("OracleDept")
                dataTableGL.Columns.Add("OraclePLPT")
                dataTableGL.Columns.Add("OracleMktg")
                dataTableGL.Columns.Add("OracleProjectCode")
                dataTableGL.Columns.Add("PaymentType")
                dataTableGL.Columns.Add("PaymentName")
                dataTableGL.Columns.Add("SunAccCode")
                dataTableGL.Columns.Add("SunAccName")
                dataTableGL.Columns.Add("SunDept")
                dataTableGL.Columns.Add("SunPLPT")
                dataTableGL.Columns.Add("SunMktg")
                dataTableGL.Columns.Add("SunTTTR")
                dataTableGL.Columns.Add("SunProjectCode")


            End If


            For Each dr As DataRow In dt.Rows
                row = dataTableGL.NewRow
                Dim amt As Decimal
                amt = Convert.ToDecimal(dr("GLCR_AMOUNT"))

                row.Item(0) = dr("GLCR_TRANSREF").ToString.Trim
                row.Item(1) = dr("GLCR_LINENO").ToString.Trim
                row.Item(2) = dr("GLCR_TRANSDATE").ToString.Substring(6, 2) & "/" & dr("GLCR_TRANSDATE").ToString.Substring(4, 2) & "/" & dr("GLCR_TRANSDATE").ToString.Substring(0, 4) 'dr("GLCR_TRANSDATE").ToString.Trim
                row.Item(3) = dr("GLCR_DUEDATE").ToString.Substring(6, 2) & "/" & dr("GLCR_DUEDATE").ToString.Substring(4, 2) & "/" & dr("GLCR_DUEDATE").ToString.Substring(0, 4) 'dr("GLCR_DUEDATE").ToString.Trim
                row.Item(4) = dr("GLCR_DESC").ToString.Trim
                row.Item(5) = dr("GLCR_O_ACCOUNT").ToString.Trim
                row.Item(6) = amt.ToString("###,###.00") 'dr("GLCR_AMOUNT").ToString
                row.Item(7) = dr("GLCR_DRCR").ToString.Trim
                row.Item(8) = dr("GLCR_O_DEP_BRN").ToString.Trim
                row.Item(9) = dr("GLCR_O_PL_PT").ToString.Trim
                row.Item(10) = dr("GLCR_O_MKT_EMP").ToString.Trim
                row.Item(11) = dr("GLCR_O_PROJECT").ToString.Trim
                row.Item(12) = dr("GLCR_PAYMTH").ToString.Trim
                row.Item(13) = dr("GLCR_PAYEE").ToString.Trim
                row.Item(14) = dr("GLCR_S_ACCOUNT").ToString.Trim
                row.Item(15) = dr("GLCR_S_ACCNAME").ToString.Trim
                row.Item(16) = dr("GLCR_S_DEP_BRN").ToString.Trim
                row.Item(17) = dr("GLCR_S_PL_PT").ToString.Trim
                row.Item(18) = dr("GLCR_S_MKT_EMP").ToString.Trim
                row.Item(19) = dr("GLCR_S_TT_TR").ToString.Trim
                row.Item(20) = dr("GLCR_S_PROJECT").ToString.Trim


                dataTableGL.Rows.Add(row)

            Next

            GenGridGL(dataTableGL)
        Else
            dataTableGL = Nothing
            GenGridGL(dataTableGL)

        End If

    End Sub
    Private Sub BindDataTAX(ByVal createdate As String, ByVal core_system As String, ByVal transref As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_WHT_CREATION WHERE TAXCR_CREATEDATE = '" & createdate & "' AND TAXCR_CORE_SYSTEM='" & core_system & "' AND TAXCR_TRANSREF='" & transref & "' AND TAXCR_APPROVEDBY IS NULL ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)



        If dt.Rows.Count > 0 Then
            dataTableTAX = Nothing
            Dim row As DataRow
            If dataTableTAX Is Nothing Then

                dataTableTAX = New DataTable("DtTAX")

                dataTableTAX.Columns.Add("LineNo")
                dataTableTAX.Columns.Add("TaxID")
                dataTableTAX.Columns.Add("IDCard")
                dataTableTAX.Columns.Add("APTitle")
                dataTableTAX.Columns.Add("APName")
                dataTableTAX.Columns.Add("APLastName")
                dataTableTAX.Columns.Add("Address")
                dataTableTAX.Columns.Add("AMPENM")
                dataTableTAX.Columns.Add("PROVNM")
                dataTableTAX.Columns.Add("AGZIP")
                dataTableTAX.Columns.Add("TaxType")
                dataTableTAX.Columns.Add("TaxItem")
                dataTableTAX.Columns.Add("TaxDate")
                dataTableTAX.Columns.Add("BaseAmount")
                dataTableTAX.Columns.Add("WHTAmount")
                dataTableTAX.Columns.Add("Payee")
                dataTableTAX.Columns.Add("TaxRate")
                dataTableTAX.Columns.Add("Description")
                dataTableTAX.Columns.Add("AccountCode")
                'dataTableTAX.Columns.Add("TransRef")
                dataTableTAX.Columns.Add("GPLine")


            End If


            For Each dr As DataRow In dt.Rows
                row = dataTableTAX.NewRow
                Dim baseamt As Decimal
                baseamt = Convert.ToDecimal(dr("TAXCR_BASE_AMT"))

                Dim whtamt As Decimal
                whtamt = Convert.ToDecimal(dr("TAXCR_TAX_AMT"))


                row.Item(0) = dr("TAXCR_LINENO").ToString.Trim
                row.Item(1) = dr("TAXCR_TAXID").ToString.Trim
                row.Item(2) = dr("TAXCR_IDCARD").ToString.Trim
                row.Item(3) = dr("TAXCR_AP_TTL").ToString.Trim
                row.Item(4) = dr("TAXCR_AP_FNAME").ToString.Trim
                row.Item(5) = dr("TAXCR_AP_LNAME").ToString.Trim
                row.Item(6) = dr("TAXCR_ADDRESS").ToString.Trim
                row.Item(7) = dr("TAXCR_AMPENM").ToString.Trim
                row.Item(8) = dr("TAXCR_PROVNM").ToString.Trim
                row.Item(9) = dr("TAXCR_AGZIP").ToString.Trim
                row.Item(10) = dr("TAXCR_TAXTYPE").ToString.Trim
                row.Item(11) = dr("TAXCR_TAXITEM").ToString.Trim
                row.Item(12) = dr("TAXCR_TAXDATE").ToString.Substring(6, 2) & "/" & dr("TAXCR_TAXDATE").ToString.Substring(4, 2) & "/" & dr("TAXCR_TAXDATE").ToString.Substring(0, 4) ' dr("TAXCR_TAXDATE").ToString.Trim
                row.Item(13) = baseamt.ToString("###,###.00") 'dr("TAXCR_BASE_AMT").ToString.Trim
                row.Item(14) = whtamt.ToString("###,###.00") 'dr("TAXCR_TAX_AMT").ToString.Trim
                row.Item(15) = dr("TAXCR_PAYEE").ToString.Trim
                row.Item(16) = dr("TAXCR_TAX_RATE").ToString.Trim
                row.Item(17) = dr("TAXCR_DESC").ToString.Trim
                row.Item(18) = dr("TAXCR_GL_ACCOUNT").ToString.Trim
                row.Item(19) = dr("TAXCR_GPTREF_SEQNO").ToString.Trim

                dataTableTAX.Rows.Add(row)

            Next

            GenGridTax(dataTableTAX)

        Else
            dataTableTAX = Nothing
            GenGridTax(dataTableTAX)
        End If

    End Sub
    Private Sub BindDataHeader(ByVal createdate As String, ByVal core_system As String, ByVal transref As String)
        Dim sb As New StringBuilder()
        sb.Append("SELECT * FROM GPS_TRANSREF_REL WHERE TREF_CREATEDATE='" & createdate & "' AND TREF_CORE_SYSTEM='" & core_system & "' AND TREF_TRANSREF='" & transref & "' AND TREF_APPROVEDBY IS NULL ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
        If dt.Rows.Count > 0 Then


            Dim paiddate As String = dt.Rows(0)("TREF_PAIDDATE")
            Dim entrydate As String = dt.Rows(0)("TREF_CREATEDATE")
            Dim format As String = "yyyyMMdd"

            txtEntryDate.Text = Date.ParseExact(entrydate, format, New Globalization.CultureInfo("en-US")).ToString("dd/MM/yyyy")
            cboJournalType.SelectedValue = dt.Rows(0)("TREF_JN_TYPE").ToString.Trim

            cboGroup.SelectedValue = dt.Rows(0)("TREF_PAYCRETYP_ID").ToString.Trim

            dtpDueDate.Value = Date.ParseExact(paiddate, format, New Globalization.CultureInfo("en-US"))

            txtAccPeriod.Text = Microsoft.VisualBasic.Right(dt.Rows(0)("TREF_GL_PERIOD"), 2) & "/" & Microsoft.VisualBasic.Left(dt.Rows(0)("TREF_GL_PERIOD"), 4)
            cboDataSource.SelectedValue = dt.Rows(0)("TREF_DTSOURCE").ToString.Trim

            If dt.Rows(0)("TREF_PAYMTH") IsNot DBNull.Value Then
                'LookUp_PaymentType
                'cboPaymentType.SelectedValue = dt.Rows(0)("TREF_PAYMTH").ToString.Trim

                Dim payment As String
                payment = dt.Rows(0)("TREF_PAYMTH").ToString.Trim & ":" & dt.Rows(0)("TREF_SUB_PAYMTH").ToString.Trim
                cboPayMth.SelectedValue = payment

                'cboPayMth.Text = cls.LookUp_PaymentType(clsUtility.gConnGP, payment)
            End If

            If dt.Rows(0)("TREF_OSEA_LIST") IsNot DBNull.Value Then
                cboOverSea.SelectedValue = dt.Rows(0)("TREF_OSEA_LIST").ToString.Trim
            End If

            txtPurpose.Text = dt.Rows(0)("TREF_PPOSE_PCHASE").ToString.Trim

        End If
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        lblAlert.Visible = True
        Cursor = Cursors.WaitCursor

        SaveData()

        lblAlert.Visible = False
        Cursor = Cursors.Default

    End Sub
    Private Sub ClearTable()

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec_gp, rec_gl, rec_tax As Integer
        Dim sb_gp, sb_gl, sb_tax As New StringBuilder

        '--- Add by Arunya
        If Not (retCoreSystem = "TLM" And lblStatus.Text <> "ADD") Then
            sb_gp.Append("DELETE FROM GPS_PAYMENT_CREATION WHERE GPCR_CREATEDATE ='" & retCreateDate & "' AND GPCR_CORE_SYSTEM='" & retCoreSystem & "' AND GPCR_TRANSREF='" & retTransRef & "'")
        End If

        sb_gl.Append("DELETE FROM GPS_GL_CREATION WHERE GLCR_CREATEDATE ='" & retCreateDate & "' AND GLCR_CORE_SYSTEM='" & retCoreSystem & "' AND GLCR_TRANSREF='" & retTransRef & "'")
        sb_tax.Append("DELETE FROM GPS_WHT_CREATION WHERE TAXCR_CREATEDATE ='" & retCreateDate & "' AND TAXCR_CORE_SYSTEM='" & retCoreSystem & "' AND TAXCR_TRANSREF='" & retTransRef & "'")

        '--- Add by Arunya
        If Not (retCoreSystem = "TLM" And lblStatus.Text <> "ADD") Then
            rec_gp = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_gp, oleTrans)
        End If

        rec_gl = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_gl, oleTrans)
        rec_tax = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_tax, oleTrans)

        If rec_gp >= 0 And rec_gl >= 0 And rec_tax >= 0 Then
            oleTrans.Commit()

            'MsgBox("Update already")
        Else
            oleTrans.Rollback()

            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Do you want to delete data ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Delete()
        End If
    End Sub
    Private Sub Delete()
        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec_tref, rec_gp, rec_gl, rec_tax As Integer
        Dim sb_tref, sb_gp, sb_gl, sb_tax As New StringBuilder

        sb_tref.Append("DELETE FROM GPS_TRANSREF_REL WHERE TREF_CREATEDATE='" & retCreateDate & "' AND TREF_CORE_SYSTEM='" & retCoreSystem & "' AND TREF_TRANSREF='" & retTransRef & "' ")
        sb_gp.Append("DELETE FROM GPS_PAYMENT_CREATION WHERE GPCR_CREATEDATE ='" & retCreateDate & "' AND GPCR_CORE_SYSTEM='" & retCoreSystem & "' AND GPCR_TRANSREF='" & retTransRef & "'")
        sb_gl.Append("DELETE FROM GPS_GL_CREATION WHERE GLCR_CREATEDATE ='" & retCreateDate & "' AND GLCR_CORE_SYSTEM='" & retCoreSystem & "' AND GLCR_TRANSREF='" & retTransRef & "'")
        sb_tax.Append("DELETE FROM GPS_WHT_CREATION WHERE TAXCR_CREATEDATE ='" & retCreateDate & "' AND TAXCR_CORE_SYSTEM='" & retCoreSystem & "' AND TAXCR_TRANSREF='" & retTransRef & "'")

        rec_tref = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_tref, oleTrans)
        rec_gp = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_gp, oleTrans)
        rec_gl = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_gl, oleTrans)
        rec_tax = clsBusiness.ExecuteCommand(clsUtility.gConnGP, sb_tax, oleTrans)

        If rec_tref >= 0 And rec_gp >= 0 And rec_gl >= 0 And rec_tax >= 0 Then
            oleTrans.Commit()

            ClearScreen()
            MsgBox("Data deleted successfully")
        Else
            oleTrans.Rollback()

            MsgBox("Can not delete data")
        End If
    End Sub
    Public Function CheckDate(ByVal dateString As String, ByVal systemdate As String) As Boolean

        Dim formats As String = "yyyyMMdd"
        Dim dateValue As DateTime

        Select Case Convert.ToInt16(dateString.Substring(0, 4))
            Case Convert.ToInt16(systemdate.Substring(0, 4))
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Convert.ToInt16(systemdate.Substring(0, 4)) + 1
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-GB"), DateTimeStyles.None, dateValue) Then
                    Return True
                Else
                    Return False
                End If
            Case Else
                Return True
        End Select

    End Function
    Function ValidateData_GP(ByRef err_gp As String) As Boolean
        If retCoreSystem <> "TLM" Then

            Dim ret As Boolean = True
            Dim dt As New DataTable
            dt = cls.ChkGL_TransDate(clsUtility.gConnGP, gUserLogin)
            If dt.Rows.Count > 0 Then
                err_gp &= "��س��к� Transaction Date" & vbCrLf
                ret = False
            End If

            dt = Nothing
            dt = cls.ChkGP_Description(clsUtility.gConnGP, gUserLogin)
            If dt.Rows.Count > 0 Then
                err_gp &= "Description is not null/Description limit 240 characters" & vbCrLf
                ret = False
            End If

            If Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1) = "C" _
                Or Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1) = "D" Or _
                (Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1) = "M" And retCoreSystem <> "TLM") Then
                dt = Nothing
                dt = cls.ChkGP_PayeeName(clsUtility.gConnGP, gUserLogin)
                If dt.Rows.Count > 0 Then
                    err_gp &= "Payee Name is not null/ Payee Name limit 100 characters" & vbCrLf
                    ret = False
                End If
            End If


            dt = Nothing
            dt = cls.ChkGP_BankCode(clsUtility.gConnGP, gUserLogin)
            If dt.Rows.Count > 0 Then
                err_gp &= "Bank Code is not null" & vbCrLf
                ret = False
            End If

            dt = Nothing
            dt = cls.ChkGP_BankNo(clsUtility.gConnGP, gUserLogin)
            If dt.Rows.Count > 0 Then
                err_gp &= "Bank Number is not null" & vbCrLf
                ret = False
            End If

            dt = Nothing
            dt = cls.ChkGP_BankName(clsUtility.gConnGP, gUserLogin)
            If dt.Rows.Count > 0 Then
                err_gp &= "Bank Name is not null" & vbCrLf
                ret = False
            End If

            Select Case cboPayMth.SelectedValue.ToString
                Case "M:M"

                    dt = Nothing
                    dt = cls.ChkGP_BankAccount(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Payee Bank Account is not null/Payee Bank Account limit 20 characters" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankAccountName(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Payee Bank Account Name is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankBranch(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Bank Branch is not null" & vbCrLf
                        ret = False
                    End If

                Case "M:C"

                    dt = Nothing
                    dt = cls.ChkGP_BankAccount(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Payee Bank Account is not null/Payee Bank Account limit 20 characters" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankAccountName(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Payee Bank Account Name is not null" & vbCrLf
                        ret = False
                    End If


                    dt = Nothing
                    dt = cls.ChkGP_Merchn(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Merchant No is not null" & vbCrLf
                        ret = False
                    End If

                Case "C:B", "D:D" '"C:T" 2015/02/17 ������ Validate ��ҳѵ�

                    dt = Nothing
                    dt = cls.ChkGP_Address(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Address is not null" & vbCrLf
                        ret = False
                    End If

                Case "M:B"

                    dt = Nothing
                    dt = cls.ChkGP_Address(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Address is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankBranchName(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Bank Branch Name is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankAddress(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Bank Address is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_Phone(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Phone is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_SwiftCode(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "Swift Code is not null" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_Country(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "����ȼ���Ѻ�Թ�����繤����ҧ" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_Currency(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "ʡ���Թ is not null/ʡ���Թ limit 5 characters" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_Exchange(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "�ѵ���š����¹�����繤����ҧ" & vbCrLf
                        ret = False
                    End If

                    dt = Nothing
                    dt = cls.ChkGP_BankCharge(clsUtility.gConnGP, gUserLogin, cboPayMth.SelectedValue.ToString)
                    If dt.Rows.Count > 0 Then
                        err_gp &= "��Ҹ�������㹡���͹�Թ�����繤����ҧ" & vbCrLf
                        ret = False
                    End If

            End Select

        End If
    End Function
    Function ValidateData() As Boolean

        Dim ret As Boolean = True

        Dim PDTE_NOMAT As Boolean
        Dim DUPT_ERR As Boolean
        Dim TREF_ERR As Boolean
        Dim WLST_ERR As Boolean
        Dim CHAR_ERR As Boolean
        Dim PDTE_ERR As Boolean
        Dim PAMT_ERR As Boolean
        Dim BKCD_ERR As Boolean
        Dim BKAC_ERR As Boolean
        Dim ACNM_ERR As Boolean
        Dim PAYEE_ERR As Boolean
        Dim LENGT_ERR As Boolean
        Dim ADDR_ERR As Boolean
        Dim MCHN_ERR As Boolean
        Dim TLINK_ERR As Boolean
        Dim PAMT_NOMAT As Boolean
        Dim TAMT_NOMAT As Boolean

        If retCoreSystem <> "TLM" Then

            ''--------------ValidateTaxType--------------
            Dim ValidateTaxType As Boolean
            ValidateTaxType = Validate_TaxType(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
            If ValidateTaxType = False Then
                'MsgBox("��س��к� Tax Type", MsgBoxStyle.Critical, "Validate")
                err_data &= "��س��к� Tax Type" & vbCrLf
                ret = False
                'Exit Function
            End If

            ''--------------ValidateTaxID--------------
            Dim ValidateTAXID As Boolean
            ValidateTAXID = Validate_TaxID(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
            If ValidateTAXID = False Then
                'MsgBox("��س��к� Tax ID ���� ID Card", MsgBoxStyle.Critical, "Validate")
                err_data &= "��س��к� Tax ID ���� ID Card" & vbCrLf
                ret = False
                'Exit Function
            End If


            ' ''--------------ValidateDescriptionGP--------------
            'Dim ValidateDescGP As Boolean
            'ValidateDescGP = Validate_DescGP(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
            'If ValidateDescGP = False Then
            '    'MsgBox("��س��к� Description � Tab GP", MsgBoxStyle.Critical, "Validate")
            '    err_data &= "��س��к� Description � Tab GP" & vbCrLf
            '    ret = False
            '    'Exit Function
            'End If
            ''--------------ValidateAmount--------------

            Select Case cboGroup.SelectedValue
                Case "001", "002", "003"
                    PAMT_NOMAT = cls.fnNetAmountNotMatch_Creation(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
                    If PAMT_NOMAT = False Then
                        Dim msg As String
                        msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PAMT_NOMAT")
                        'MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                        err_data &= msg & vbCrLf
                        ret = False
                        'Exit Function
                    End If

                    TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
                    If TAMT_NOMAT = False Then
                        Dim msg As String
                        msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
                        err_data &= msg & vbCrLf
                        'MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                        ret = False
                        'Exit Function
                    End If

                Case "004"
                    dgvGP.AllowUserToAddRows = False
                    If dgvGP.Rows.Count > 0 Then
                        PAMT_NOMAT = cls.fnNetAmountNotMatch_Creation(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
                        If PAMT_NOMAT = False Then
                            Dim msg As String
                            msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PAMT_NOMAT")
                            ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                            err_data &= msg & vbCrLf
                            ret = False
                            'Exit Function
                        End If
                    End If
                    dgvGP.AllowUserToAddRows = True

                    dgvTax.AllowUserToAddRows = False
                    If dgvTax.Rows.Count > 0 Then
                        TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
                        If TAMT_NOMAT = False Then
                            Dim msg As String
                            msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
                            ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                            err_data &= msg & vbCrLf
                            ret = False
                            'Exit Function
                        End If
                    End If
                    dgvTax.AllowUserToAddRows = True

                Case "006"
                    dgvTax.AllowUserToAddRows = False
                    If dgvTax.Rows.Count > 0 Then
                        TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
                        If TAMT_NOMAT = False Then
                            Dim msg As String
                            msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
                            ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                            err_data &= msg & vbCrLf
                            ret = False
                            'Exit Function
                        End If
                    End If
                    dgvTax.AllowUserToAddRows = True

            End Select


            ''--------------fValidateTransrefError--------------
            DUPT_ERR = Validate_4(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
            If DUPT_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "DUPT_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            'End If

            ' ''--------------Date �������ç�ѹ--------------
            'PDTE_NOMAT = Validate_3(clsUtility.gConnGP)
            'If PDTE_NOMAT = False Then
            '    Dim msg As String
            '    msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_NOMAT")
            '    ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
            '    err_data &= msg & vbCrLf
            '    ret = False
            '    'Exit Function
            'End If

            ''--------------fValidateTransrefError--------------
            TREF_ERR = Validate_5(clsUtility.gConnGP)
            If TREF_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TREF_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidatWatchLists--------------
            WLST_ERR = Validate_6(clsUtility.gConnGP, retCreateDate)
            If WLST_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "WLST_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                err_data &= err_wl
                ret = False
                'Exit Function
            End If
            ' ''--------------fValidatSpecialCharacterError--------------
            CHAR_ERR = Validate_7(clsUtility.gConnGP, "CHAR_ERR")
            If CHAR_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "CHAR_ERR")
                'MsgBox(msg & vbCrLf & "�к��зӡ�� Over Write Data �繪�ͧ��ҧ", MsgBoxStyle.Information, "Validate")
                'err_data &= msg & " �к��зӡ�� Over Write Data �繪�ͧ��ҧ" & vbCrLf

            End If
            ''--------------fValidatePaidDateError--------------
            PDTE_ERR = Validate_8(clsUtility.gConnGP, retCreateDate)
            If PDTE_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PDTE_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidatePaidAmountError--------------
            PAMT_ERR = Validate_9(clsUtility.gConnGP)
            If PAMT_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PAMT_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If

            ''Pattamalin 2015/01/30 ��� Validate BKAC_ERR ��͹ BKCD_ERR

            ''--------------fValidateBankAccountError--------------
            BKAC_ERR = Validate_11(clsUtility.gConnGP)
            If BKAC_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "BKAC_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If


            ''--------------fValidateBankCodeError--------------
            BKCD_ERR = Validate_10(clsUtility.gConnGP)
            If BKCD_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "BKCD_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If



            ''--------------fValidateBankAccountNameError--------------
            ACNM_ERR = Validate_12(clsUtility.gConnGP)
            If ACNM_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "ACNM_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidatePayeeNameError--------------
            PAYEE_ERR = Validate_13(clsUtility.gConnGP)
            If PAYEE_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "PAYEE_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidatePayeeLengthFieldError--------------
            LENGT_ERR = Validate_14(clsUtility.gConnGP)
            If LENGT_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "LENGT_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidateAddressError--------------
            ADDR_ERR = Validate_15(clsUtility.gConnGP)
            If ADDR_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "ADDR_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''--------------fValidateMerchantError--------------
            MCHN_ERR = Validate_16(clsUtility.gConnGP)
            If MCHN_ERR = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "MCHN_ERR")
                ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                err_data &= msg & vbCrLf
                ret = False
                'Exit Function
            End If
            ''-------------------------fValidateGPtrefSeqNo-------------
            If cboGroup.SelectedValue.ToString <> "006" Then

                TLINK_ERR = Validate_17(clsUtility.gConnGP)
                If TLINK_ERR = False Then
                    Dim msg As String
                    msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TLINK_ERR")
                    ' MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                    err_data &= msg & vbCrLf
                    ret = False
                    'Exit Function
                End If

            End If

        Else

            TAMT_NOMAT = CHK_WHT_ERR(clsUtility.gConnGP, retCreateDate, retCoreSystem, retTransRef)
            If TAMT_NOMAT = False Then
                Dim msg As String
                msg = cls.LookUp_MassageErr(clsUtility.gConnGP, "TAMT_NOMAT")
                err_data &= msg & vbCrLf
                'MsgBox(msg, MsgBoxStyle.Critical, "Validate")
                ret = False
                'Exit Function
            End If

        End If


        Return ret

    End Function
    Function CHK_WHT_ERR(ByVal oConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True

        dt = cls.fnValidateWHTAmountNotMatch_CR(clsUtility.gConnGP, create_date, core_system, transref)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        End If

        Return ret

    End Function
    Public Function Validate_3(ByRef oleConn As OleDbConnection) As Boolean

        Dim dt_gp As New DataTable
        Dim dt_gl As New DataTable
        Dim dt_tax As New DataTable

        Dim ret As Boolean = True

        dt_gp = cls.fValidatePaymentDate(clsUtility.gConnGP, gUserLogin)
        dt_gl = cls.fValidateGLDate(clsUtility.gConnGP, gUserLogin)
        dt_tax = cls.fValidateTAXDate(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt_gp) AndAlso dt_gp.Rows.Count > 1 Then
            ret = False
        End If

        If Not IsNothing(dt_gl) AndAlso dt_gl.Rows.Count > 1 Then
            ret = False
        End If

        If Not IsNothing(dt_tax) AndAlso dt_tax.Rows.Count > 1 Then
            ret = False
        End If

        Return ret

    End Function
    Public Function Validate_TaxType(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean

        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidate_TaxType(clsUtility.gConnGP, create_date, core_system, txtTransRef.Text.Trim)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Public Function Validate_TaxID(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean

        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidate_TaxID(clsUtility.gConnGP, create_date, core_system, txtTransRef.Text.Trim)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Public Function Validate_4(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean

        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateDuplicateTransRef_2(clsUtility.gConnGP, create_date, core_system, txtTransRef.Text.Trim)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_5(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateTransrefError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_6(ByVal oConn As OleDbConnection, ByVal batchdate As String) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        Dim strErrList As New StringBuilder

        dt = cls.fValidatWatchLists(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            For Each dr As DataRow In dt.Rows

                'Data Reject 
                Dim dt_wl As New DataTable
                '-- ppk 2015-12-08 -- dt_wl = cls.CHECK_WATCHLIST_FOR_REJ(clsUtility.gConnGP, dr("GPCR_PAYEE_NAME").ToString.Replace(" ", ""))
                '-- ppk 2015-12-08 -- If Not IsNothing(dt_wl) AndAlso dt_wl.Rows.Count > 0 Then
                '-- ppk 2015-12-08 --     Dim chk_effdate As Boolean
                '-- ppk 2015-12-08 --     chk_effdate = cls.CHECK_WATCHLIST_EFFDATE(clsUtility.gConnGP, dr("GPCR_PAYEE_NAME").ToString.Replace(" ", ""), batchdate)
                '-- ppk 2015-12-08 --     If chk_effdate = False Then
                '-- ppk 2015-12-08 --         err_wl &= "- " & dr("GPCR_PAYEE_NAME").ToString & vbCrLf
                '-- ppk 2015-12-08 --         ret = False
                '-- ppk 2015-12-08 --     End If
                '-- ppk 2015-12-08 -- End If

                dt_wl = cls.CHECK_WATCHLIST_FOR_REJ_NEW(clsUtility.gConnGP _
                                                        , dr("GPCR_CORE_SYSTEM").ToString.Trim _
                                                        , dr("GPCR_CREATEDATE").ToString.Trim _
                                                        , dr("GPCR_POLNO").ToString.Trim _
                                                        , dr("GPCR_AMOUNT") _
                                                        , dr("GPCR_PAYMTH").ToString.Trim _
                                                        , dr("GPCR_PAYEE_NAME").ToString.Trim _
                                                        , dr("GPCR_PAYEE_BNKACCNME").ToString.Trim _
                                                            )
                If Not IsNothing(dt_wl) AndAlso dt_wl.Rows.Count > 0 Then

                    '-- ppk 2015-12-08 --     err_wl &= "- " & dr("GPCR_PAYEE_NAME").ToString & vbCrLf

                    ret = False

                    If strErrList.Length < 1 Then
                        strErrList.AppendLine("PAYEE_NAME" _
                                              & vbTab & "POLICY NO" _
                                              & vbTab & "AMOUNT" _
                                              & vbTab & "PAID_DATE" _
                                              )
                    End If
                    If dr("GPCR_PAYMTH").ToString.Trim = "M" Then
                        strErrList.AppendLine(dr("GPCR_PAYEE_BNKACCNME").ToString.Trim _
                                              & vbTab & dr("GPCR_POLNO").ToString.Trim _
                                              & vbTab & dr("GPCR_AMOUNT") _
                                              & vbTab & dr("GPCR_PAIDDATE").ToString.Trim _
                                              )
                    Else
                        strErrList.AppendLine(dr("GPCR_PAYEE_NAME").ToString.Trim _
                                              & vbTab & dr("GPCR_POLNO").ToString.Trim _
                                              & vbTab & dr("GPCR_AMOUNT") _
                                              & vbTab & dr("GPCR_PAIDDATE").ToString.Trim _
                                              )
                    End If
                End If
            Next

            If strErrList.Length > 1 Then
                err_wl &= "- " & strErrList.ToString
            End If

        End If

        Return ret

    End Function
    Function Validate_7(ByVal oConn As OleDbConnection, ByVal errtype As String) As Boolean
        Dim dt As New DataTable
        Dim dt_char As New DataTable
        Dim r_err As Integer
        Dim i_chk As Integer
        Dim ret As Boolean = True
        dt = cls.fValidatSpecialCharacterError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim oleTrans As OleDbTransaction
            oleTrans = clsUtility.gConnGP.BeginTransaction()

            For Each dr As DataRow In dt.Rows

                r_err = cls.UPD_SPE_CHAR(oConn, oleTrans, dr("spe_char"), errtype, dr("GPCR_CREATEDATE"), dr("GPCR_CORE_SYSTEM"), dr("GPCR_TRANSREF"), dr("GPCR_GPTREF_SEQNO"))
                i_chk = i_chk + 1

            Next


            If i_chk >= 1 Then
                oleTrans.Commit()

                ret = False
            Else
                oleTrans.Rollback()

                Return True
            End If

          

        End If

        Return ret

    End Function

   
    Function Validate_8(ByVal oConn As OleDbConnection, ByVal batchdate As String) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidatePaidDateError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim paidate As String
            paidate = dt.Rows(0)("GPCR_PAIDDATE").ToString
            'For Each dr As DataRow In dt.Rows
            If CheckDate(paidate, batchdate) Then
                Dim format As String = "yyyyMMdd"
                Dim DueDate As Date
                DueDate = Date.ParseExact(paidate, format, New Globalization.CultureInfo("en-US"))

                If GetWorkDay(DueDate) Then

                    Select Case dt.Rows(0)("PAYT_PAY_GROUP")
                        Case "SCB_NET"
                            If Convert.ToInt32(paidate) >= Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday(clsUtility.gConnGP, paidate)
                                If chk_holiday Then
                                    ret = False
                                    Exit Function
                                End If
                            Else
                                ret = False
                                Exit Function
                            End If
                        Case "SCBLIFE_CHQ"
                            If Convert.ToInt32(paidate) < Convert.ToInt32(batchdate) Then
                                ret = False
                                Exit Function
                            End If

                        Case "OVERSEA"
                            If Convert.ToInt32(paidate) >= Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday(clsUtility.gConnGP, paidate)
                                If chk_holiday Then
                                    ret = False
                                    Exit Function
                                End If
                            Else
                                ret = False
                                Exit Function
                            End If
                        Case "ATS", "CREDIT_CARD"
                            If Convert.ToInt32(paidate) > Convert.ToInt32(batchdate) Then
                                Dim chk_holiday As Boolean
                                chk_holiday = cls.LookUpHoliday(clsUtility.gConnGP, paidate)
                                If chk_holiday Then
                                    ret = False
                                    Exit Function
                                End If
                            Else
                                ret = False
                                Exit Function
                            End If

                    End Select
                Else 'Saturday Sunday
                    ret = False
                    Exit Function
                End If

            Else 'format <> "CCYYYMMDD" 
                ret = False
                Exit Function
            End If

            'Next

        End If

        Return ret

    End Function
    Function Validate_9(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True

        dt = cls.fValidatePaidAmountError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_10(ByVal oConn As OleDbConnection) As Integer
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateBankCodeError(clsUtility.gConnGP, gUserLogin, Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1))

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_11(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateBankAccountError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_12(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateBankAccountNameError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret
    End Function
    Function Validate_13(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        Select Case Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1)
            Case "C", "D"
                dt = cls.fValidatePayeeNameError(clsUtility.gConnGP, gUserLogin)
                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    ret = False
                Else
                    ret = True
                End If

        End Select

        Return ret

    End Function
    Function Validate_14(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidatePayeeLengthFieldError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_15(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
       
        Select Case cboPayMth.SelectedValue
            Case "D:D"
                dt = cls.fValidateAddressError(clsUtility.gConnGP, gUserLogin)
                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    ret = False
                Else
                    ret = True
                End If
        End Select

        Return ret

    End Function
    Function Validate_16(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateMerchantError(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function
    Function Validate_17(ByVal oConn As OleDbConnection) As Boolean
        Dim dt As New DataTable
        Dim ret As Boolean = True
        dt = cls.fValidateGPtrefSeqNo(clsUtility.gConnGP, gUserLogin)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            ret = False
        Else
            ret = True
        End If

        Return ret

    End Function

    Private Sub dtpDueDate_ValueChanged(ByVal sender As System.Object, ByVal e As CustomControls.CheckDateEventArgs) Handles dtpDueDate.ValueChanged
        'If retCreateDate <> "" Then
        Try
            Dim busdate As String
            Dim duedate As String

            busdate = DateTime.Now.ToString("yyyyMMdd", en)
            duedate = dtpDueDate.Value.ToString("yyyyMMdd", en)

            If lblStatus.Text = "ADD" Then

                If cboGroup.SelectedValue <> "006" Then
                    If duedate < busdate Then 'dtpDueDate.Value.ToString("yyyyMMdd") < Now.ToString("yyyyMMdd") 
                        dtpDueDate.Value = Now
                        MsgBox("�ѹ����ͧ�ҡ����������ҡѺ�ѹ���Ѩ�غѹ")
                        Exit Sub
                    End If
                End If

            End If
            BindDataDueDate()

        Catch ex As Exception

        End Try

        'End If

    End Sub

    Private Sub cboDataSource_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDataSource.SelectedIndexChanged
        Try
            If cboDataSource.SelectedValue.ToString <> "System.Data.DataRowView" Then
                If lblStatus.Text = "ADD" Then
                    txtTransRef.Focus()
                    txtTransRef.Text = cboDataSource.SelectedValue.ToString

                End If

            End If

        Catch ex As Exception
            txtTransRef.Text = ""
        End Try

    End Sub
    Private Sub cboPayMth_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPayMth.SelectedIndexChanged
        '002=�ѹ�֡ GL, GP, WHT ����к�������ѹ (��¡�è��»���)
        If cboGroup.SelectedValue.ToString = "002" Then
            SetDefaultDueDate(cboPayMth.SelectedValue.ToString)

        End If

        If cboPayMth.SelectedValue.ToString <> "M:B" Then
            ListOverSea()

            cboOverSea.SelectedIndex = 0
            cboOverSea.Enabled = False
        Else
            ListOverSea()
            cboOverSea.SelectedIndex = 1
            cboOverSea.Enabled = True
        End If
        '������ Draft ����ʴ� purpose
        Select Case cboPayMth.SelectedValue.ToString
            Case "C:H", "C:G", "C:T", "C:B"
                txtPurpose.Enabled = True
            Case Else
                txtPurpose.Enabled = False
                txtPurpose.Text = ""
        End Select

        BindDataPayMTH()
    End Sub
    Private Sub dgvGL_RowValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles dgvGL.RowValidating
        'Try

        '    Dim index = dgvGL.CurrentCell.RowIndex + 1
        '    Dim newlineno As Integer = 1

        '    If dgvGL.CurrentCell.ColumnIndex = 20 Then
        '        dgvGL.AllowUserToAddRows = True

        '        If cboEntryType.SelectedIndex = 0 Then

        '            newlineno = index + 1
        '            dgvGL.Rows(index).Cells(0).Value = newlineno 'index + 1
        '            dgvGL.Rows(index).Cells(1).Value = txtTransRef.Text.Trim
        '            dgvGL.Rows(index).Cells(2).Value = Now.ToString("dd/MM/yyyy")
        '            dgvGL.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
        '            dgvGL.Rows(index).Cells(14).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
        '        End If

        '    Else
        '        dgvGL.AllowUserToAddRows = False
        '    End If

        'Catch ex As Exception

        'End Try

    End Sub
    Private Sub dgvGP_RowValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles dgvGP.RowValidating
        'Try
        '    Dim index = dgvGP.CurrentCell.RowIndex + 1
        '    Dim newlineno As Integer = 1

        '    If dgvGP.CurrentCell.ColumnIndex = 37 Then
        '        dgvGP.AllowUserToAddRows = True

        '        If cboEntryTypeGP.SelectedIndex = 0 Then
        '            dgvGP.Rows(index).Cells(0).Value = txtTransRef.Text.Trim
        '            dgvGP.Rows(index).Cells(6).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
        '            dgvGP.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
        '            Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)

        '            If IsNothing(dgvGP.Rows(index).Cells(8).Value) Then
        '                If (pay = "C" Or pay = "D") Then
        '                    dgvGP.Rows(index).Cells(8).Value = "SCB"
        '                End If
        '            End If

        '            If IsNothing(dgvGP.Rows(index).Cells(9).Value) Then
        '                If pay = "C" Or pay = "D" Then
        '                    dgvGP.Rows(index).Cells(9).Value = "014"
        '                End If
        '            End If

        '        End If

        '    Else
        '        dgvGP.AllowUserToAddRows = False
        '    End If

        'Catch ex As Exception

        'End Try

    End Sub
    Function GetLineTax() As String
        Dim sb As New StringBuilder
        If dgvTax.Rows.Count > 0 Then
            dgvTax.AllowUserToAddRows = False
            For index As Integer = 0 To dgvTax.RowCount - 1
                sb.Append("and GPLine <> '" & dgvTax.Rows(index).Cells(19).Value & "' ")
            Next
            ' dgvTax.AllowUserToAddRows = True
        End If
        Return sb.ToString.TrimEnd(",")
    End Function
   
    Private Sub BindDataPayMTH()
        Try
            If dgvGL.Rows.Count > 0 Then
                dgvGL.AllowUserToAddRows = False
                For index As Integer = 0 To dgvGL.RowCount - 1
                    dgvGL.Rows(index).Cells(14).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                Next
                dgvGL.AllowUserToAddRows = True
            End If

            If dgvGP.Rows.Count > 0 Then
                dgvGP.AllowUserToAddRows = False
                For index As Integer = 0 To dgvGP.RowCount - 1
                    dgvGP.Rows(index).Cells(6).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
                    dgvGP.Rows(index).Cells(20).Value = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
                Next
                dgvGP.AllowUserToAddRows = True
            End If

        Catch ex As Exception

        End Try
    End Sub
    Private Sub BindDataDueDate()
        Try
            If dgvGL.Rows.Count > 0 Then
                dgvGL.AllowUserToAddRows = False
                For index As Integer = 0 To dgvGL.RowCount - 1
                    dgvGL.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
                Next
                dgvGL.AllowUserToAddRows = True
            End If

            If dgvGP.Rows.Count > 0 Then
                dgvGP.AllowUserToAddRows = False
                For index As Integer = 0 To dgvGP.RowCount - 1
                    dgvGP.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
                Next
                dgvGP.AllowUserToAddRows = True
            End If

            If dgvTax.Rows.Count > 0 Then
                dgvTax.AllowUserToAddRows = False
                For index As Integer = 0 To dgvTax.RowCount - 1
                    dgvTax.Rows(index).Cells(12).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
                Next
                dgvTax.AllowUserToAddRows = True
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtTransRef_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtTransRef.Validating
        dgvGL.AllowUserToAddRows = False
        If dgvGL.Rows.Count > 0 Then
            If txtTransRef.Text <> dgvGL.Rows(0).Cells(1).Value Then

                If MessageBox.Show("Do you want to change Transref ? (Y/N)", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    For index As Integer = 0 To dgvGL.RowCount - 1
                        dgvGL.Rows(index).Cells(1).Value = txtTransRef.Text.Trim
                    Next


                    If dgvGP.Rows.Count > 0 Then
                        dgvGP.AllowUserToAddRows = False
                        For index As Integer = 0 To dgvGP.RowCount - 1
                            dgvGP.Rows(index).Cells(0).Value = txtTransRef.Text.Trim
                        Next
                        dgvGP.AllowUserToAddRows = True
                    End If

                Else
                    txtTransRef.Text = dgvGL.Rows(0).Cells(1).Value()
                End If
            End If

        End If

        dgvGL.AllowUserToAddRows = True


    End Sub
    Private Sub btnAddRowGL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRowGL.Click
        Try

            dgvGL.AllowUserToAddRows = True
            Dim index = dgvGL.Rows.Count - 1
            Dim newlineno As Integer = 1

            dgvGL.CurrentCell = dgvGL.Item(4, index)

            Me.dgvGL.BeginEdit(False)
            Me.ActiveControl = dgvGL.EditingControl


            'If cboEntryType.SelectedIndex = 0 Then
            If dgvGL.Rows.Count > 1 Then
                newlineno = dgvGL.Rows(dgvGL.RowCount - 2).Cells(0).Value + 1 'index + 1
            Else
                newlineno = 1
            End If

            dgvGL.Rows(index).Cells(0).Value = newlineno
            dgvGL.Rows(index).Cells(1).Value = txtTransRef.Text.Trim
            dgvGL.Rows(index).Cells(2).Value = DateTime.Now.ToString("dd/MM/yyyy", en) '.ToString("dd/MM/yyyy")
            dgvGL.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy", en) 'dtpDueDate.Value.ToString("dd/MM/yyyy")
            dgvGL.Rows(index).Cells(14).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)

            'End If


        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnAddRowGP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRowGP.Click
        Try

            dgvGP.AllowUserToAddRows = True
            Dim index = dgvGP.Rows.Count - 1
            Dim newlineno As Integer = 1

            dgvGP.CurrentCell = dgvGP.Item(4, index)

            Me.dgvGP.BeginEdit(False)
            Me.ActiveControl = dgvGP.EditingControl


            dgvGP.Rows(index).Cells(0).Value = txtTransRef.Text.Trim
            dgvGP.Rows(index).Cells(6).Value = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)
            dgvGP.Rows(index).Cells(3).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")
            Dim pay As String = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue.ToString, 1)

            If IsNothing(dgvGP.Rows(index).Cells(8).Value) Then
                If (pay = "C" Or pay = "D") Then
                    dgvGP.Rows(index).Cells(8).Value = "SCB"
                End If
            End If

            If IsNothing(dgvGP.Rows(index).Cells(9).Value) Then
                If pay = "C" Or pay = "D" Then
                    dgvGP.Rows(index).Cells(9).Value = "014"
                End If
            End If

            dgvGP.Rows(index).Cells(19).Value = cboDataSource.SelectedValue
            dgvGP.Rows(index).Cells(20).Value = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue.ToString, 1)
            dgvGP.Rows(index).Cells(37).Value = index + 1

          
            'dgvGL.AllowUserToAddRows = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnAddRowTax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRowTax.Click
        Try

            dgvTax.AllowUserToAddRows = True
            Dim index = dgvTax.Rows.Count - 1
            Dim newlineno As Integer = 1

            dgvTax.CurrentCell = dgvTax.Item(1, index)

            Me.dgvTax.BeginEdit(False)
            Me.ActiveControl = dgvTax.EditingControl


            'If cboEntryTypeTAX.SelectedIndex = 0 Then
            If dgvTax.Rows.Count > 1 Then
                newlineno = dgvTax.Rows(dgvTax.RowCount - 2).Cells(0).Value + 1 ' index + 1
            Else
                newlineno = 1
            End If


            dgvTax.Rows(index).Cells(0).Value = newlineno 'index + 1
            dgvTax.Rows(index).Cells(12).Value = dtpDueDate.Value.ToString("dd/MM/yyyy")

            ' End If

            ' dgvTax.AllowUserToAddRows = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub chkFlagAllGP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFlagAllGP.CheckedChanged
        dgvGP.AllowUserToAddRows = False
        If dgvGP.Rows.Count > 0 Then

            If chkFlagAllGP.Checked Then

                For index As Integer = 0 To dgvGP.RowCount - 1
                    dgvGP.Rows(index).Cells(27).Value = "Y" 'Is checked set flag to 'Y'
                Next

            Else

                For index As Integer = 0 To dgvGP.RowCount - 1
                    dgvGP.Rows(index).Cells(27).Value = " " 'Is unchecked set flag to ' ' (Blank)
                Next

            End If

        End If
        dgvGP.AllowUserToAddRows = True
    End Sub
    Private Sub btnGetAPGP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetAPGP.Click
        dgvGL.AllowUserToAddRows = False
        If dgvGL.RowCount <= 0 Then
            MsgBox("��سҺѹ�֡������ Tab GL")
            Exit Sub

        Else
            Dim sb As New StringBuilder
            For index As Integer = 0 To dgvGL.RowCount - 1
                If Not (Not IsNothing(dgvGL.Rows(index).Cells(5).Value) AndAlso dgvGL.Rows(index).Cells(5).Value.ToString <> "") Then
                    MsgBox("��سҡ�͡ Account Code ��� Tab GL ���ú", MsgBoxStyle.Information)
                    Exit Sub
                End If
                If Not (Not IsNothing(dgvGL.Rows(index).Cells(8).Value) AndAlso dgvGL.Rows(index).Cells(8).Value.ToString <> "") Then
                    MsgBox("��سҡ�͡ DR/CR ��� Tab GL ���ú", MsgBoxStyle.Information)
                    Exit Sub
                End If
                If Not (Not IsNothing(dgvGL.Rows(index).Cells(13).Value) AndAlso dgvGL.Rows(index).Cells(13).Value.ToString <> "") Then
                    MsgBox("��سҡ�͡ TTTR ��� Tab GL ���ú", MsgBoxStyle.Information)
                    Exit Sub
                End If

                If dgvGL.Rows(index).Cells(8).Value.ToString.Trim = "C" _
                        And dgvGL.Rows(index).Cells(13).Value = "00000000" _
                        And Microsoft.VisualBasic.Right(dgvGL.Rows(index).Cells(5).Value, 5) <> "00000" Then
                    sb.Append("'" & dgvGL.Rows(index).Cells(5).Value & "',")
                End If

            Next

            If sb.ToString.TrimEnd(",").Length > 0 Then
                Dim scode As String
                scode = sb.ToString.TrimEnd(",")

                Dim dt As New DataTable
                dt = cls.fnGetAPMaster(clsUtility.gConnGP, scode)

                If dt.Rows.Count > 0 Then
                    GPAPMaster(dt)
                Else
                    MsgBox("��辺������� AP Master : account_s_code ���� config", MsgBoxStyle.Information)
                End If
               
            End If

        End If

        dgvGL.AllowUserToAddRows = True

    End Sub

    Private Sub btnGetAPTax_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetAPTax.Click
        dgvGL.AllowUserToAddRows = False
        dgvGP.AllowUserToAddRows = False
        If dgvGL.RowCount <= 0 Then
            MsgBox("��سҺѹ�֡������ Tab GL")
            Exit Sub
        End If
        If dgvGP.RowCount <= 0 Then
            MsgBox("��سҺѹ�֡������ Tab GP")
            Exit Sub
        End If

        Dim sb As New StringBuilder
        For index As Integer = 0 To dgvGL.RowCount - 1
            If Not (Not IsNothing(dgvGL.Rows(index).Cells(5).Value) AndAlso dgvGL.Rows(index).Cells(5).Value.ToString <> "") Then
                MsgBox("��سҡ�͡ Account Code ��� Tab GL ���ú", MsgBoxStyle.Information)
                Exit Sub
            End If

            If Not (Not IsNothing(dgvGL.Rows(index).Cells(8).Value) AndAlso dgvGL.Rows(index).Cells(8).Value.ToString <> "") Then
                MsgBox("��سҡ�͡ DR/CR ��� Tab GL ���ú", MsgBoxStyle.Information)
                Exit Sub
            End If
            If Not (Not IsNothing(dgvGL.Rows(index).Cells(13).Value) AndAlso dgvGL.Rows(index).Cells(13).Value.ToString <> "") Then
                MsgBox("��سҡ�͡ TTTR ��� Tab GL ���ú", MsgBoxStyle.Information)
                Exit Sub
            End If
            If dgvGL.Rows(index).Cells(8).Value.ToString.Trim = "C" _
                    And dgvGL.Rows(index).Cells(13).Value = "00000000" _
                    And Microsoft.VisualBasic.Right(dgvGL.Rows(index).Cells(5).Value, 5) <> "00000" Then
                sb.Append("'" & dgvGL.Rows(index).Cells(5).Value & "',")
            End If


        Next

        If sb.ToString.TrimEnd(",").Length > 0 Then
            Dim scode As String
            scode = sb.ToString.TrimEnd(",")

            Dim dt As New DataTable
            dt = cls.fnGetAPMaster(clsUtility.gConnGP, scode)

            If dt.Rows.Count > 0 Then
                TaxAPMaster(dt)
            Else
                MsgBox("��辺������� AP Master : account_s_code ���� config", MsgBoxStyle.Information)
            End If
        Else

            'AP Othor TAX
            Dim sbother As New StringBuilder
            Dim sb_err As New StringBuilder
            For index As Integer = 0 To dgvTax.RowCount - 1
                If Not IsNothing(dgvTax.Rows(index).Cells(1).Value) AndAlso dgvTax.Rows(index).Cells(1).Value.ToString.Trim <> "" Then

                    Dim scode As String
                    scode = dgvTax.Rows(index).Cells(1).Value

                    Dim dt As New DataTable
                    dt = cls.fnGetAPOther(clsUtility.gConnGP, scode)

                    If dt.Rows.Count > 0 Then
                        TaxAPOther(dt, index)
                    Else
                        sb_err.Append("Line No : " & index + 1 & " ��辺������� '" & scode & "' ���� config" & vbCrLf)
                    End If

                End If
            Next

            If sb_err.Length > 0 Then
                MsgBox(sb_err.ToString, MsgBoxStyle.Information)
            End If

        End If

            dgvGL.AllowUserToAddRows = True
            dgvGP.AllowUserToAddRows = True
    End Sub
    Private Sub GPAPMaster(ByVal dt As DataTable)
        Dim Row As DataRow
        Dim newdt As New DataTable

        newdt.Columns.Add("TransRef")
        newdt.Columns.Add("DueDate")
        newdt.Columns.Add("Amount")
        newdt.Columns.Add("PaymentType")
        newdt.Columns.Add("PayeeName")
        newdt.Columns.Add("BankCode")
        newdt.Columns.Add("BankNumber")
        newdt.Columns.Add("PayeeBankAccNo")
        newdt.Columns.Add("PayeeBankAccName")
        newdt.Columns.Add("Address1")
        newdt.Columns.Add("DataSource")
        newdt.Columns.Add("SubPaymentType")
        newdt.Columns.Add("GPLine")

        For Each dr As DataRow In dt.Rows

            Row = newdt.NewRow

            Row.Item(0) = txtTransRef.Text.Trim
            Row.Item(1) = dtpDueDate.Value.ToString("dd/MM/yyyy")
            For index As Integer = 0 To dgvGL.RowCount - 1
                If dgvGL.Rows(index).Cells(5).Value = dr("SUPP_S_ACCOUNT").ToString And dgvGL.Rows(index).Cells(13).Value = "00000000" Then
                    Row.Item(2) = dgvGL.Rows(index).Cells(7).Value
                    Exit For
                Else
                    Row.Item(2) = "0.00"
                End If
            Next

            Row.Item(3) = Microsoft.VisualBasic.Left(cboPayMth.SelectedValue, 1)
            Row.Item(4) = dr("SUPP_NAME_GP").ToString
            Row.Item(5) = GET_BANKCODE_BY_BANKNO(dr("SUPP_BNKCODE_NO_GP").ToString)
            Row.Item(6) = dr("SUPP_BNKCODE_NO_GP").ToString
            Row.Item(7) = dr("SUPP_BNKACCNO_GP").ToString
            Row.Item(8) = dr("SUPP_NAME_GP").ToString
            Row.Item(9) = dr("SUPP_ADDRESS_GP").ToString & " " & dr("SUPP_AMPENM_GP").ToString & " " & dr("SUPP_PROVNM_GP").ToString & " " & dr("SUPP_AGZIP_GP").ToString
            Row.Item(10) = cboDataSource.SelectedValue
            Row.Item(11) = Microsoft.VisualBasic.Right(cboPayMth.SelectedValue, 1)
            Row.Item(12) = dt.Rows.IndexOf(dr) + 1


            newdt.Rows.Add(Row)
        Next

        GenGridGP(newdt)
    End Sub
    Private Sub TaxAPMaster(ByVal dt As DataTable)
        Dim Row As DataRow
        Dim newdt As New DataTable

        newdt.Columns.Add("LineNo")
        newdt.Columns.Add("TaxID")
        newdt.Columns.Add("IDCard")
        newdt.Columns.Add("APTitle")
        newdt.Columns.Add("APName")
        newdt.Columns.Add("APLastName")
        newdt.Columns.Add("Address")
        newdt.Columns.Add("AMPENM")
        newdt.Columns.Add("PROVNM")
        newdt.Columns.Add("AGZIP")
        newdt.Columns.Add("TaxType")
        newdt.Columns.Add("TaxItem")
        newdt.Columns.Add("TaxDate")
        newdt.Columns.Add("BaseAmount")
        newdt.Columns.Add("WHTAmount")
        newdt.Columns.Add("Payee")
        newdt.Columns.Add("TaxRate")
        newdt.Columns.Add("Description")
        newdt.Columns.Add("AccountCode")
        newdt.Columns.Add("TransRef")
        newdt.Columns.Add("GPLine")

        For Each dr As DataRow In dt.Rows

            Row = newdt.NewRow

            Row.Item(0) = dt.Rows.IndexOf(dr) + 1
            Row.Item(1) = dr("SUPP_TAXID").ToString
            Row.Item(2) = ""
            Row.Item(3) = ""
            Row.Item(4) = dr("SUPP_NAME_TAX").ToString
            Row.Item(5) = ""
            Row.Item(6) = dr("SUPP_ADDRESS_TAX").ToString & " " & dr("SUPP_AMPENM_TAX").ToString & " " & dr("SUPP_PROVNM_TAX").ToString & " " & dr("SUPP_AGZIP_TAX").ToString
            Row.Item(7) = ""
            Row.Item(8) = ""
            Row.Item(9) = ""
            For index As Integer = 0 To dgvGL.RowCount - 1
                If dgvGL.Rows(index).Cells(5).Value = dr("SUPP_S_ACCOUNT").ToString And dgvGL.Rows(index).Cells(13).Value <> "00000000" Then
                    Dim pngd As String
                    pngd = dgvGL.Rows(index).Cells(13).Value.ToString.Substring(0, 2)
                    Row.Item(10) = cls.LookUp_Phorngordor(clsUtility.gConnGP, pngd)
                    Exit For
                Else
                    Row.Item(10) = ""
                End If
            Next
            Row.Item(11) = "600"
            Row.Item(12) = dtpDueDate.Value.ToString("dd/MM/yyyy")
            Row.Item(13) = ""
            For index As Integer = 0 To dgvGL.RowCount - 1
                If dgvGL.Rows(index).Cells(5).Value = dr("SUPP_S_ACCOUNT").ToString And dgvGL.Rows(index).Cells(13).Value <> "00000000" Then
                    Row.Item(14) = dgvGL.Rows(index).Cells(7).Value
                    Exit For
                Else
                    Row.Item(14) = "0.00"
                End If
            Next

            Row.Item(15) = ""
            For index As Integer = 0 To dgvGL.RowCount - 1
                If dgvGL.Rows(index).Cells(5).Value = dr("SUPP_S_ACCOUNT").ToString And dgvGL.Rows(index).Cells(13).Value <> "00000000" Then
                    Row.Item(16) = Convert.ToInt16(Microsoft.VisualBasic.Right(dgvGL.Rows(index).Cells(13).Value, 2))
                    Exit For
                Else
                    Row.Item(16) = ""
                End If
            Next
            Row.Item(17) = ""
            Row.Item(18) = dr("SUPP_S_ACCOUNT").ToString
            Row.Item(19) = txtTransRef.Text.Trim

            For index As Integer = 0 To dgvGP.RowCount - 1
                If dgvGP.Rows(index).Cells(7).Value = dr("SUPP_NAME_GP").ToString Then
                    Row.Item(20) = dgvGP.Rows(index).Cells(37).Value
                    Exit For
                Else
                    Row.Item(20) = ""
                End If
            Next

            newdt.Rows.Add(Row)
        Next

        GenGridTax(newdt)

    End Sub
    Private Sub TaxAPOther(ByVal dt As DataTable, ByVal index As Integer)
        Dim TTTR As String = ""
        Dim pngd As String
        Dim suncode As String
        dgvTax.Rows(index).Cells(4).Value = dt.Rows(0)("SUPP_NAME_TAX").ToString
        dgvTax.Rows(index).Cells(6).Value = dt.Rows(0)("SUPP_ADDRESS_TAX").ToString & " " & dt.Rows(0)("SUPP_AMPENM_GP").ToString & " " & dt.Rows(0)("SUPP_PROVNM_GP").ToString & " " & dt.Rows(0)("SUPP_AGZIP_GP").ToString

        For i As Integer = 0 To dgvGL.RowCount - 1
            If dgvGL.Rows(i).Cells(13).Value <> "00000000" Then

                TTTR = dgvGL.Rows(i).Cells(13).Value.ToString
                pngd = TTTR.Substring(0, 2)
                suncode = dgvGL.Rows(i).Cells(5).Value.ToString
                Exit For

            End If
        Next
        dgvTax.Rows(index).Cells(10).Value = cls.LookUp_Phorngordor(clsUtility.gConnGP, pngd)
        dgvTax.Rows(index).Cells(11).Value = "600"

        If TTTR <> "" Then
            Dim baseamt As Double
            baseamt = (Convert.ToDouble(dgvTax.Rows(index).Cells(13).Value) * Convert.ToInt16(Microsoft.VisualBasic.Right(TTTR, 2))) / 100
            dgvTax.Rows(index).Cells(14).Value = baseamt.ToString("###,###.00")
            dgvTax.Rows(index).Cells(16).Value = Convert.ToInt16(Microsoft.VisualBasic.Right(TTTR, 2))
        End If

        dgvTax.Rows(index).Cells(18).Value = suncode 'dt.Rows(0)("SUPP_S_ACCOUNT").ToString

        For i As Integer = 0 To dgvGP.RowCount - 1
            If dgvGP.Rows(i).Cells(7).Value = dt.Rows(0)("SUPP_NAME_TAX").ToString Then
                dgvTax.Rows(index).Cells(19).Value = dgvGP.Rows(i).Cells(37).Value
                Exit For
            Else
                dgvTax.Rows(index).Cells(19).Value = ""
            End If
        Next

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged

    End Sub
End Class
