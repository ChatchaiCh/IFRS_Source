Public Class FrmAccManualKeyIn
    Private Sub TabStyle()

        TabControl1.ImageList = ImageList1

        TabPage1.ImageIndex = 12
        ' Sizes the tabs of tabControl1. 
        Me.TabControl1.ItemSize = New Size(90, 30)
        ' Makes the tab width definable.  
        Me.TabControl1.SizeMode = TabSizeMode.Fixed

        TabControl1.DrawMode = TabDrawMode.OwnerDrawFixed
        'TabControl1.ForeColor = Color.LightGray 'Color.Blue

        For Each tp As TabPage In Me.TabControl1.TabPages
            tp.BackColor = Color.LightGray
        Next

        Panel1.BackColor = Color.FromArgb(255, 240, 235)
        Panel2.BackColor = Color.FromArgb(255, 240, 235)

    End Sub
    Private Sub TabControl1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles TabControl1.DrawItem
        Dim g As Graphics = e.Graphics
        Dim tp As TabPage = TabControl1.TabPages(e.Index)
        Dim br As Brush
        Dim sf As New StringFormat

        Dim r As New RectangleF(e.Bounds.X, e.Bounds.Y + 2, e.Bounds.Width, e.Bounds.Height - 2)

        sf.Alignment = StringAlignment.Center
        sf.LineAlignment = StringAlignment.Center

        Dim strTitle As String = tp.Text

        'If the current index is the Selected Index, change the color 
        If TabControl1.SelectedIndex = e.Index Then

            'this is the background color of the tabpage header
            br = New SolidBrush(Color.FromArgb(232, 119, 34)) ' chnge to your choice

            g.FillRectangle(br, e.Bounds)

            'this is the foreground color of the text in the tab header
            br = New SolidBrush(Color.White) ' change to your choice
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        Else

            'these are the colors for the unselected tab pages 
            br = New SolidBrush(Color.FromArgb(255, 235, 220)) ' Change this to your preference
            g.FillRectangle(br, e.Bounds)
            br = New SolidBrush(Color.FromArgb(232, 119, 34))
            g.DrawString(strTitle, TabControl1.Font, br, r, sf)

        End If
    End Sub
    Private Sub FrmAccManualKeyIn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TabStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .CheckPathExists = True
            .Multiselect = True
            .ShowHelp = False
            .ShowReadOnly = False
            .Title = "Text File Dialog"
            .Filter = "Text File (*.xls)|*.xlsx"
            .FilterIndex = 0
        End With

        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            If OpenFileDialog1.FileNames.Length <> 0 Then
                txtTextURL.Text = OpenFileDialog1.FileName
            End If
        End If
    End Sub
End Class