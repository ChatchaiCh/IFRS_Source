Imports System.Data
Imports System.Data.OleDb
Imports System.Text
Imports System.Globalization
Imports UtilityClassLibrary
Public Class FrmCancelWHT
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsWHT
    Dim clsCr As New clsCreation
    Private _IsSelectAllChecked As Boolean
#Region " Constants "
    Private Enum DGVHeaderImageAlignments As Int32
        [Default] = 0
        FillCell = 1
        SingleCentered = 2
        SingleLeft = 3
        SingleRight = 4
        Stretch = [Default]
        Tile = 5
    End Enum
#End Region
#Region " Methods "
    Private Sub GridDrawCustomHeaderColumns(ByVal dgv As DataGridView, _
     ByVal e As DataGridViewCellPaintingEventArgs, ByVal img As Image, _
     ByVal Style As DGVHeaderImageAlignments)
        ' All of the graphical Processing is done here.
        Dim gr As Graphics = e.Graphics
        ' Fill the BackGround with the BackGroud Color of Headers.
        ' This step is necessary, for transparent images, or what's behind
        ' would be painted instead.
        gr.FillRectangle( _
         New SolidBrush(dgv.ColumnHeadersDefaultCellStyle.BackColor), _
         e.CellBounds)
        If img IsNot Nothing Then
            Select Case Style
                Case DGVHeaderImageAlignments.FillCell
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.CellBounds.Width, e.CellBounds.Height)
                Case DGVHeaderImageAlignments.SingleCentered
                    gr.DrawImage(img, _
                     ((e.CellBounds.Width - img.Width) \ 2) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleLeft
                    gr.DrawImage(img, e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.SingleRight
                    gr.DrawImage(img, _
                     (e.CellBounds.Width - img.Width) + e.CellBounds.X, _
                     ((e.CellBounds.Height - img.Height) \ 2) + e.CellBounds.Y, _
                     img.Width, img.Height)
                Case DGVHeaderImageAlignments.Tile
                    ' ********************************************************
                    ' To correct: It sould display just a stripe of images,
                    ' long as the whole header, but centered in the header's
                    ' height.
                    ' This code WON'T WORK.
                    ' Any one got any better solution?
                    'Dim rect As New Rectangle(e.CellBounds.X, _
                    ' ((e.CellBounds.Height - img.Height) \ 2), _
                    ' e.ClipBounds.Width, _
                    ' ((e.CellBounds.Height \ 2 + img.Height \ 2)))
                    'Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile, _
                    ' rect)
                    ' ********************************************************
                    ' This one works... but poorly (the image is repeated
                    ' vertically, too).
                    Dim br As New TextureBrush(img, Drawing2D.WrapMode.Tile)
                    gr.FillRectangle(br, e.ClipBounds)
                Case Else
                    gr.DrawImage( _
                     img, e.CellBounds.X, e.CellBounds.Y, _
                     e.ClipBounds.Width, e.CellBounds.Height)
            End Select
        End If
        'e.PaintContent(e.CellBounds)
        If e.Value Is Nothing Then
            e.Handled = True
            Return
        End If
        Using sf As New StringFormat
            With sf
                Select Case dgv.ColumnHeadersDefaultCellStyle.Alignment
                    Case DataGridViewContentAlignment.BottomCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.BottomRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Far
                    Case DataGridViewContentAlignment.MiddleCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.MiddleRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Center
                    Case DataGridViewContentAlignment.TopCenter
                        .Alignment = StringAlignment.Center
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopLeft
                        .Alignment = StringAlignment.Near
                        .LineAlignment = StringAlignment.Near
                    Case DataGridViewContentAlignment.TopRight
                        .Alignment = StringAlignment.Far
                        .LineAlignment = StringAlignment.Near
                End Select
                ' This part could be handled...
                'Select Case dgv.ColumnHeadersDefaultCellStyle.WrapMode
                '	Case DataGridViewTriState.False
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.NotSet
                '		.FormatFlags = StringFormatFlags.NoWrap
                '	Case DataGridViewTriState.True
                '		.FormatFlags = StringFormatFlags.FitBlackBox
                'End Select
                .HotkeyPrefix = Drawing.Text.HotkeyPrefix.None
                .Trimming = StringTrimming.None
            End With
            With dgv.ColumnHeadersDefaultCellStyle
                gr.DrawString(e.Value.ToString, .Font, _
                 New SolidBrush(.ForeColor), e.CellBounds, sf)
            End With
        End Using
        e.Handled = True
    End Sub
#End Region
    Private Sub ControlStyle()
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)
        Panel1.BackColor = Color.FromArgb(255, 245, 240)
    End Sub
    Private Sub HeaderCheckBox_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me._IsSelectAllChecked = True

        Dim cbx As CheckBox
        cbx = DirectCast(sender, CheckBox)
        Dim theDataGridView As DataGridView = cbx.Parent

        For Each row As DataGridViewRow In theDataGridView.Rows
            row.Cells(0).Value = cbx.Checked
        Next

        theDataGridView.EndEdit()

        Me._IsSelectAllChecked = False
    End Sub
    Private Sub AddSelectAllCheckBox(ByVal theDataGridView As DataGridView)
        Dim cbx As New CheckBox
        cbx.Name = "SelectAll"
        'The box size
        cbx.Size = New Size(14, 14)

        Dim rect As Rectangle
        rect = theDataGridView.GetCellDisplayRectangle(0, -1, True)
        'Put CheckBox in the middle-center of the column header.
        cbx.Location = New System.Drawing.Point(rect.Location.X + ((rect.Width - cbx.Width) / 2), rect.Location.Y + ((rect.Height - cbx.Height) / 2))
        cbx.BackColor = Color.White
        theDataGridView.Controls.Add(cbx)

        'Handle header CheckBox check/uncheck function
        AddHandler cbx.Click, AddressOf HeaderCheckBox_Click
        'When any CheckBox value in the DataGridViewRows changed,
        'check/uncheck the header CheckBox accordingly.
        AddHandler theDataGridView.CellValueChanged, AddressOf DataGridView_CellChecked
        'This event handler is necessary to commit new CheckBox cell value right after
        'user clicks the CheckBox.
        'Without it, CellValueChanged event occurs until the CheckBox cell lose focus
        'which means the header CheckBox won't display corresponding checked state instantly when user
        'clicks any one of the CheckBoxes.
        AddHandler theDataGridView.CurrentCellDirtyStateChanged, AddressOf DataGridView_CurrentCellDirtyStateChanged
    End Sub
    Private Sub DataGridView_CellChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If Not Me._IsSelectAllChecked Then
            If dataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = False Then
                'When any single CheckBox is unchecked, uncheck the header CheckBox.
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = False
            Else
                'When any single CheckBox is checked, loop through all CheckBoxes to determine
                'if the header CheckBox needs to be unchecked.
                Dim isAllChecked As Boolean = True
                For Each row As DataGridViewRow In dataGridView.Rows
                    If row.Cells(0).Value = False Then
                        isAllChecked = False
                        Exit For
                    End If
                Next
                DirectCast(dataGridView.Controls.Item("SelectAll"), CheckBox).Checked = isAllChecked
            End If
        End If
    End Sub
    Private Sub DataGridView_CurrentCellDirtyStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dataGridView As DataGridView = DirectCast(sender, DataGridView)
        If TypeOf dataGridView.CurrentCell Is DataGridViewCheckBoxCell Then
            'When the value changed cell is DataGridViewCheckBoxCell, commit the change
            'to invoke the CellValueChanged event.
            dataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub
    Private Sub FrmCancelWHTaxCertificate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ControlStyle()
        ListCancel()

     
    End Sub
    Private Sub ListCancel()
        cboCancelType.Items.Add("¡��ԡ(����������)")
        cboCancelType.Items.Add("¡��ԡ(�������� Ẻ�� WHT)")
        cboCancelType.Items.Add("¡��ԡ(�������� Ẻ����� WHT)")
        cboCancelType.SelectedIndex = 0
    End Sub
    Private Sub GetDataToGrid(ByVal dt As DataTable)

        With DataGridView1

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim chk As New DataGridViewCheckBoxColumn
        With chk
            .Width = 20
            DataGridView1.Columns.Add(chk)

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "TAX_WHTNO"
            .Name = "�Ţ���˹ѧ����Ѻ�ͧ"
            .ReadOnly = True
            .Width = 200
            DataGridView1.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "TAX_DATE"
            .Name = "�ѹ ��͹ �� ���շ�����"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c2)
        End With
        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "TAX_PAYEE"
            .Name = "���ͼ��١�ѡ����"
            .ReadOnly = True
            .Width = 250
            DataGridView1.Columns.Add(c3)
        End With
        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "TAX_TAXID"
            .Name = "TAXID"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "TAX_IDCARD"
            .Name = "IDCARD"
            .ReadOnly = True
            .Width = 100
            DataGridView1.Columns.Add(c5)
        End With
        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "TAX_BASE_AMT"
            .Name = "�ӹǹ�Թ������"
            .ReadOnly = True
            .Width = 150
            DataGridView1.Columns.Add(c6)
        End With
        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "TAX_TAX_AMT"
            .Name = "���շ���ѡ��й������"
            .ReadOnly = True
            .Width = 120
            DataGridView1.Columns.Add(c7)
        End With

        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .DataPropertyName = "TAX_TRANSREF"
            .Name = "TAX_TRANSREF"
            .ReadOnly = True
            DataGridView1.Columns.Add(c8)
        End With

        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .DataPropertyName = "JN_TYPE"
            .Name = "JN_TYPE"
            .ReadOnly = True
            DataGridView1.Columns.Add(c9)
        End With

        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .DataPropertyName = "CORE_SYSTEM"
            .Name = "CORE_SYSTEM"
            .ReadOnly = True
            DataGridView1.Columns.Add(c10)
        End With

        With DataGridView1.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView1.Columns(6).DefaultCellStyle.Format = "###,###.00" 'AMOUNT BASE
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(7).DefaultCellStyle.Format = "###,###.00" 'AMOUNT WHT
        DataGridView1.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(8).Visible = False
        DataGridView1.Columns(9).Visible = False

    End Sub

    Private Sub GetDataToGrid2(ByVal dt As DataTable)

        With DataGridView2

            '.ReadOnly = True
            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray

        End With

        Dim chk2 As New DataGridViewCheckBoxColumn
        With chk2
            .Width = 20
            DataGridView2.Columns.Add(chk2)

        End With

        Dim c1 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c1
            .DataPropertyName = "TRANSREF"
            .Name = "TRANSREF"
            .ReadOnly = True
            .Width = 150
            DataGridView2.Columns.Add(c1)

        End With

        Dim c2 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c2
            .DataPropertyName = "S_ACCOUNT"
            .Name = "�Ţ���ѭ��"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c2)

        End With

        Dim c3 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c3
            .DataPropertyName = "GL_DESC"
            .Name = "��������´"
            '.ReadOnly = True
            .Width = 300
            DataGridView2.Columns.Add(c3)
        End With

        Dim c4 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c4
            .DataPropertyName = "AMOUNT"
            .Name = "�ӹǹ�Թ"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c4)
        End With
        Dim c5 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c5
            .DataPropertyName = "DRCR"
            .Name = "DRCR"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c5)

        End With

        Dim c6 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c6
            .DataPropertyName = "JN_TYPE"
            .Name = "JN_TYPE"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c6)

        End With

        Dim c7 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c7
            .DataPropertyName = "JN_SOURCE"
            .Name = "JN_SOURCE"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c7)

        End With

        Dim c8 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c8
            .DataPropertyName = "CORE_SYSTEM"
            .Name = "CORE_SYSTEM"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c8)

        End With

        Dim c9 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c9
            .DataPropertyName = "TRANSDATE"
            .Name = "TRANSDATE"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c9)
        End With

        Dim c10 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c10
            .DataPropertyName = "DUEDATE"
            .Name = "DUEDATE"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c10)
        End With

        Dim c11 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c11
            .DataPropertyName = "S_DEP_BRN"
            .Name = "S_DEP_BRN"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c11)

        End With

        Dim c12 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c12
            .DataPropertyName = "S_PL_PT"
            .Name = "S_PL_PT"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c12)

        End With

        Dim c13 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c13
            .DataPropertyName = "S_MKT_EMP"
            .Name = "S_MKT_EMP"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c13)
        End With

        Dim c14 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c14
            .DataPropertyName = "S_PROJECT"
            .Name = "S_PROJECT"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c14)
        End With

        Dim c15 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c15
            .DataPropertyName = "S_TT_TR"
            .Name = "S_TT_TR"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c15)
        End With

        Dim c16 As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With c16
            .DataPropertyName = "GL_PERIOD"
            .Name = "GL_PERIOD"
            '.ReadOnly = True
            .Width = 100
            DataGridView2.Columns.Add(c16)
        End With

        ''DataGridView1.RowHeadersWidth = 50
        ''AutoNumberRowsForGridView(DataGridView1)
        ''DataGridView Header Style

        With DataGridView2.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        DataGridView2.Columns(4).DefaultCellStyle.Format = "###,###.00" 'AMOUNT BASE
        DataGridView2.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        'DataGridView1.Columns(7).DefaultCellStyle.Format = "###,###.00" 'AMOUNT WHT
        'DataGridView1.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        Dim hit As DataGridView.HitTestInfo = Me.DataGridView1.HitTest(e.X, e.Y)
        If hit.Type = DataGridViewHitTestType.Cell Then
            Me.DataGridView1.ClearSelection()
            Me.DataGridView1.Rows(hit.RowIndex).Selected = True
        End If
    End Sub
    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        'If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then

        '    retAccCode = CType(DataGridView1.Item(0, e.RowIndex).Value, String)
        '    retAccName = CType(DataGridView1.Item(1, e.RowIndex).Value, String)
        '    Me.Close()

        'End If
    End Sub
    Private Sub DataGridView1_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        ' Only the Header Row (which Index is -1) is to be affected.
        If e.RowIndex = -1 Then
            GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.Button_Gray_Stripe_01_050, DGVHeaderImageAlignments.Stretch)

            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Stretch)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, _
            'DGVHeaderImageAlignments.SingleCentered)
            'GridDrawCustomHeaderColumns(dgvData, e, _
            'My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleLeft)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.SingleRight)
            'GridDrawCustomHeaderColumns(DataGridView1, e, My.Resources.AquaBall_Blue, DGVHeaderImageAlignments.Tile)
        End If
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim datefrom As String = ""
        Dim dateto As String = ""

        Dim systemdate As String

        'systemdate = "20140901" 'Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        If txtDateFrom.Text.Trim <> "" Then
            Dim dateString As String = txtDateFrom.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                datefrom = txtDateFrom.Text.Substring(6, 4) & txtDateFrom.Text.Substring(3, 2) & txtDateFrom.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateFrom.Text = ""
                txtDateFrom.Focus()

            End If
        Else
            datefrom = ""
        End If
        If txtDateTo.Text.Trim <> "" Then

            Dim dateString As String = txtDateTo.Text.Trim
            Dim formats As String = "dd/MM/yyyy"
            Dim dateValue As DateTime
            If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then
                dateto = txtDateTo.Text.Substring(6, 4) & txtDateTo.Text.Substring(3, 2) & txtDateTo.Text.Substring(0, 2)
            Else
                MsgBox("Date format is not valid")
                txtDateTo.Text = ""
                txtDateTo.Focus()

            End If
        Else
            dateto = ""
        End If



        dt = cls.GetDataForCancel(clsUtility.gConnGP, systemdate, txtBookNo.Text.Trim, datefrom, dateto, txtTaxID.Text.Trim, txtIDCard.Text.Trim, txtName.Text.Trim)
        GetDataToGrid(dt)
        AddSelectAllCheckBox(DataGridView1)

        'dt2 = cls.GetDataGLForCancel(clsUtility.gConnGP, systemdate, "CGYRT140918002", datefrom, dateto, txtTaxID.Text.Trim, txtIDCard.Text.Trim, txtName.Text.Trim)
        'GetDataToGrid2(dt2)


    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Dim sb As New StringBuilder
        Dim oleConn As OleDbConnection
        Dim oleTrans As OleDbTransaction
        Dim oleStart As OleDbTransaction

            Dim count1 As Integer = 0

            Dim strDrAccount As String
            Dim strDrAccountName As String
            Dim strDrDepBrn As String
            Dim strDrPlPt As String
            Dim strDrMktEmp As String
            Dim strDrProject As String
            Dim strDrTTTR As String
            Dim amountDr As Double
            Dim amountCr As Double

            Dim countrow As Integer = 0
            Dim i As Double
            Dim c1 As Double
            Dim c2 As Double
            Dim strTrans As String
            Dim amountGL As Double
            Dim LookNextRecord As Double

            Dim getTrans As String
            Dim getJNNOStatus As String
            Dim getJNNO As String
            Dim getVoucher As String
            Dim getJNType As String
            Dim getVoucherRun As Double
            Dim getJNTypeOld As String
            Dim getVoucherRunOld As Double
            Dim getLine As Double

            strTrans = ""
            amountDr = 0.0
            amountCr = 0.0
            getLine = 0
            strTrans = ""
            getJNNOStatus = "START"
            getJNNO = ""

            '<<<====================== Get Head Setup
            Dim dataSrcName As String = ""
            Dim dataGlsts As String = ""
            Dim dataBookId As String = ""
            Dim dataCatName As String = ""
            Dim dataCurCode As String = ""
            Dim dataActFlg As String = ""
            Dim dataComCode As String = ""
            Dim dataRcCode As String = ""
            Dim dtGps As DataTable

            '    /*������ GL
            '  "GP01" = ���˹��
            '  "GP02" = Err by Validation
            '  "GP03" = Err by Hash Total
            '  "GP04" = Reject by Bank
            '  "GP05" = ��Ѻ�� ( P , J )
            '  "GP06" = Cancel ��¡�� WHT*/

            Dim v_gl_function As String
            v_gl_function = "GP06"

            If DataGridView2.RowCount <> 0 Then

                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells(0).Value = True Then
                        count1 += 1
                    End If
                Next

            Try

                For index2 As Integer = 0 To DataGridView2.RowCount - 1

                    'S_ACCOUNT
                    Dim TRANSREF As String = DataGridView2.Rows(index2).Cells(1).Value
                    Dim S_ACCOUNT As String = DataGridView2.Rows(index2).Cells(2).Value
                    Dim GL_DESC As String = DataGridView2.Rows(index2).Cells(3).Value
                    Dim AMOUNT As String = DataGridView2.Rows(index2).Cells(4).Value
                    Dim DRCR As String = DataGridView2.Rows(index2).Cells(5).Value
                    Dim JN_TYPE As String = DataGridView2.Rows(index2).Cells(6).Value
                    Dim JN_SOURCE As String = DataGridView2.Rows(index2).Cells(7).Value
                    Dim CORE_SYSTEM As String = DataGridView2.Rows(index2).Cells(8).Value
                    Dim TRANSDATE As String = DataGridView2.Rows(index2).Cells(9).Value
                    Dim DUEDATE As String = DataGridView2.Rows(index2).Cells(10).Value
                    Dim S_DEP_BRN As String = DataGridView2.Rows(index2).Cells(11).Value
                    Dim S_PL_PT As String = DataGridView2.Rows(index2).Cells(12).Value
                    Dim S_MKT_EMP As String = DataGridView2.Rows(index2).Cells(13).Value
                    Dim S_PROJECT As String = DataGridView2.Rows(index2).Cells(14).Value
                    Dim S_TT_TR As String = DataGridView2.Rows(index2).Cells(15).Value
                    Dim GL_PERIOD As String = DataGridView2.Rows(index2).Cells(16).Value
                    If DRCR = "C" Then
                        amountCr = amountCr + AMOUNT
                    End If
                    If DRCR = "D" Then
                        amountDr = amountDr + AMOUNT
                    End If
                    Console.WriteLine(AMOUNT.ToString)
                Next


            Catch ex As Exception
                MsgBox("��¡�� GL ���١��ͧ!")
                Exit Sub
            End Try
            If amountCr = amountDr Then
                If count1 < 1 Then
                    Exit Sub
                End If
                If MessageBox.Show("Do you want to Cancel WHT ? (Y/N)", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    sb.Remove(0, sb.Length)
                    sb.Append("SELECT")
                    sb.Append("  GLM_INTERFACE_CONTROL.INT_GL_NO as int_gl_no ")
                    sb.Append(", GLM_INTERFACE_CONTROL.INT_STATUS as int_status ")
                    sb.Append("FROM GLM_INTERFACE_CONTROL ")
                    sb.Append("WHERE GLM_INTERFACE_CONTROL.INT_FUNCTION = 'JN_NO'")
                    Dim dtJN As DataTable
                    dtJN = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
                    If dtJN.Rows.Count <> 0 Then
                        getJNNOStatus = dtJN.Rows(0)("int_status").ToString
                        getJNNO = (CInt(dtJN.Rows(0)("int_gl_no").ToString) + 1).ToString
                    End If

                    oleConn = clsUtility.gConnGP
                    oleStart = oleConn.BeginTransaction()


                    sb.Remove(0, sb.Length)
                    sb.Append("  UPDATE GENERATEPAYMENT.GLM_INTERFACE_CONTROL SET INT_STATUS = 'START' ")
                    sb.Append(" WHERE INT_FUNCTION = 'JN_NO' ")
                    c2 = c2 + clsBusiness.ExecuteCommand(oleConn, sb, oleStart)
                    oleStart.Commit()

                    dtGps = cls.GetGpsGlHeadSetUp(oleConn)

                    If Not IsNothing(dtGps) AndAlso dtGps.Rows.Count > 0 Then
                        dataSrcName = dtGps.Rows(0)("SOURCE_NME").ToString()
                        dataGlsts = dtGps.Rows(0)("GLSTS").ToString()
                        dataBookId = dtGps.Rows(0)("BOOKID").ToString()
                        dataCatName = dtGps.Rows(0)("CATEGORY_NME").ToString()
                        dataCurCode = dtGps.Rows(0)("CURRENCY_CDE").ToString()
                        dataActFlg = dtGps.Rows(0)("ACTUAL_FLAG").ToString()
                        dataComCode = dtGps.Rows(0)("COMPANY_CDE").ToString()
                        dataRcCode = dtGps.Rows(0)("RCCODE").ToString()
                    End If
                    '<<<====================== END

                    getJNType = ""
                    getVoucherRun = 0
                    getJNTypeOld = ""
                    getVoucherRunOld = 0


                    oleConn = clsUtility.gConnGP

                    For index As Integer = 0 To DataGridView1.RowCount - 1
                        If DataGridView1.Rows(index).Cells(0).Value = True Then
                            Dim status As String
                            Select Case cboCancelType.SelectedIndex
                                Case 0
                                    status = "NOPAY"
                                Case 1
                                    status = "PAYTX"
                                Case 2
                                    status = "PAYNOTX"
                            End Select

                            getTrans = DataGridView1.Rows(index).Cells(8).Value

                            If (strTrans = "") Then

                                sb.Remove(0, sb.Length)
                                sb.Append(" select VCH_JN_TYPE , VCH_NO  ")
                                sb.Append(" from GENERATEPAYMENT.GLM_VOUCHER_NO  ")
                                sb.Append(" where GLM_VOUCHER_NO.VCH_JN_TYPE= '" & DataGridView1.Rows(index).Cells(9).Value & "'  ")

                                Dim dtVN As DataTable
                                dtVN = clsBusiness.ExecuteReaderCommand(oleConn, sb)
                                If dtVN.Rows.Count <> 0 Then
                                    getJNType = dtVN.Rows(0)("VCH_JN_TYPE").ToString

                                    getVoucherRun = (CInt(dtVN.Rows(0)("VCH_NO").ToString) + 1).ToString
                                    getVoucher = getJNType & getVoucherRun
                                    getJNTypeOld = getJNType

                                End If

                            End If

                            If (strTrans <> DataGridView1.Rows(index).Cells(8).Value) And (strTrans <> "") Then

                                '  Dr �����ŧ Bank
                                'getTrans = "R_" & strTrans
                                getTrans = strTrans
                                sb.Remove(0, sb.Length)

                                sb.Append(" select  GPS_GL_SETUP.GLS_S_ACCOUNT as S_ACCOUNT ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_ACCNAME as S_ACCNAME ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_DEP||'-'||GPS_GL_SETUP.GLS_S_BRN as DEPBRN ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_PL||'-'||GPS_GL_SETUP.GLS_S_PT as PLPT ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_MKT||'-'||GPS_GL_SETUP.GLS_S_EMP as MKTEMP ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_PROJECT as S_PROJECT ")
                                sb.Append(" , GPS_GL_SETUP.GLS_S_TT_TR as TTTR ")
                                sb.Append(" from GPS_GL_SETUP ")
                                sb.Append(" where GPS_GL_SETUP.GLS_FUNCTION = 'REJ' ")
                                sb.Append(" and GPS_GL_SETUP.GLS_FIELD ='GPRJ_AMOUNT' ")
                                sb.Append(" and GPS_GL_SETUP.GLS_TABLE = 'GPS_PAYMENT_REJ' ")
                                sb.Append(" and GPS_GL_SETUP.GLS_DRCR = 'D' ")
                                sb.Append(" and GPS_GL_SETUP.GLS_JN_TYPE = '" & DataGridView2.Rows(index).Cells(9).Value & "' ")
                                sb.Append(" and GPS_GL_SETUP.GLS_CORE_SYSTEM = '" & DataGridView2.Rows(index).Cells(10).Value & "' ")
                                'MsgBox(DataGridView1.Rows(index).Cells(10).Value & " " & DataGridView1.Rows(index).Cells(19).Value)
                                strDrAccount = ""
                                strDrAccountName = ""
                                strDrDepBrn = ""
                                strDrPlPt = ""
                                strDrMktEmp = ""
                                strDrProject = ""
                                strDrTTTR = ""

                                'dt.TableName.Clear()
                                Dim dt As DataTable
                                dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
                                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                                    strDrAccount = dt.Rows(0)("S_ACCOUNT").ToString
                                    strDrAccountName = dt.Rows(0)("S_ACCNAME").ToString
                                    strDrDepBrn = dt.Rows(0)("DEPBRN").ToString
                                    strDrPlPt = dt.Rows(0)("PLPT").ToString
                                    strDrMktEmp = dt.Rows(0)("MKTEMP").ToString
                                    strDrProject = dt.Rows(0)("S_PROJECT").ToString
                                    strDrTTTR = dt.Rows(0)("TTTR").ToString
                                End If

                            End If

                            '  Cr �����Ũҡ GL 
                            For index2 As Integer = 0 To DataGridView2.RowCount - 1
                                Dim TRANSREF As String = DataGridView2.Rows(index2).Cells(1).Value
                                Dim S_ACCOUNT As String = DataGridView2.Rows(index2).Cells(2).Value
                                Dim GL_DESC As String = DataGridView2.Rows(index2).Cells(3).Value
                                Dim AMOUNT As String = DataGridView2.Rows(index2).Cells(4).Value
                                Dim DRCR As String = DataGridView2.Rows(index2).Cells(5).Value
                                Dim JN_TYPE As String = DataGridView2.Rows(index2).Cells(6).Value
                                Dim JN_SOURCE As String = DataGridView2.Rows(index2).Cells(7).Value
                                Dim CORE_SYSTEM As String = DataGridView2.Rows(index2).Cells(8).Value
                                Dim TRANSDATE As String = DataGridView2.Rows(index2).Cells(9).Value
                                Dim DUEDATE As String = DataGridView2.Rows(index2).Cells(10).Value
                                Dim S_DEP_BRN As String = DataGridView2.Rows(index2).Cells(11).Value
                                Dim S_PL_PT As String = DataGridView2.Rows(index2).Cells(12).Value
                                Dim S_MKT_EMP As String = DataGridView2.Rows(index2).Cells(13).Value
                                Dim S_PROJECT As String = DataGridView2.Rows(index2).Cells(14).Value
                                Dim S_TT_TR As String = DataGridView2.Rows(index2).Cells(15).Value
                                Dim GL_PERIOD As String = DataGridView2.Rows(index2).Cells(16).Value

                                sb.Remove(0, sb.Length)
                                getLine = getLine + 1

                                sb.Append(" INSERT INTO GENERATEPAYMENT.GLM_GL_DAILY  ( ")
                                sb.Append(" GL_POSTING_DATE ")
                                sb.Append("  , GL_SYSTEM_NAME ")
                                sb.Append("  , GL_JN_TYPE ")
                                sb.Append("  , GL_JN_SOURCE")
                                sb.Append("  , GL_B_UNIT")
                                sb.Append("  , GL_PERIOD")
                                sb.Append("  , GL_JN_NO")
                                sb.Append("  , GL_VCH_NO")
                                sb.Append("  , GL_TRANSREF")
                                sb.Append("  , GL_S_ACCOUNT")
                                sb.Append("  , GL_LINENO")
                                sb.Append("  , GL_GLSTS")
                                sb.Append("  , GL_BOOKID")
                                sb.Append("  , GL_SOURCE_NME")
                                sb.Append("  , GL_CATEGORY_NME")
                                sb.Append("  , GL_CURRENCY_CDE")
                                sb.Append(" , GL_ACTUAL_FLAG")
                                sb.Append("  , GL_COMPANY_CDE")
                                sb.Append("  , GL_RCCODE")
                                sb.Append("  , GL_TRANSDATE")
                                sb.Append("  , GL_DUEDATE")
                                sb.Append("  , GL_DESC")
                                sb.Append("  , GL_AMOUNT")
                                sb.Append("  , GL_DRCR")
                                sb.Append("  , GL_S_DEP_BRN")
                                sb.Append("  , GL_S_PL_PT")
                                sb.Append("  , GL_S_MKT_EMP")
                                sb.Append("  , GL_S_TT_TR")
                                sb.Append("  , GL_S_PROJECT")
                                sb.Append("  , CREATEDBY")
                                sb.Append("  , CREATEDDATE")
                                sb.Append("  , UPDATEDBY ")
                                sb.Append("  , UPDATEDDATE")
                                sb.Append("  , GL_FUNCTION ")
                                sb.Append("  ) VALUES  ( ")
                                sb.Append(" TO_CHAR(SYSDATE,'YYYYMMDD') ")
                                sb.Append("  , 'GPSA' ")
                                sb.Append("  , '" & getJNType & "' ")
                                sb.Append("  , '" & JN_SOURCE & "' ")
                                sb.Append("  , 'SCB' ")
                                sb.Append("  ,  '" & GL_PERIOD & "' ")
                                sb.Append("  , '" & getJNNO & "' ")
                                sb.Append("  , '" & getVoucher & "' ")
                                sb.Append("  ,  '" & getTrans & "' ")
                                sb.Append("  , '" & S_ACCOUNT & "' ")
                                sb.Append("  , " & getLine & " ")
                                sb.Append("  , '" & dataGlsts & "' ")
                                sb.Append("  , '" & dataBookId & "' ")
                                sb.Append("  , '" & dataSrcName & "' ")
                                sb.Append("  , '" & dataCatName & "' ")
                                sb.Append("  , '" & dataCurCode & "' ")
                                sb.Append(" , '" & dataActFlg & "' ")
                                sb.Append("  , '" & dataComCode & "' ")
                                sb.Append("  , '" & dataRcCode & "' ")
                                sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') ")
                                sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') ")
                                sb.Append("  , '" & GL_DESC & "' ")
                                sb.Append("  , " & AMOUNT.ToString.Replace(",", "") & "")
                                sb.Append("  , '" & DRCR & "' ")
                                sb.Append("  , '" & S_DEP_BRN & "' ")
                                sb.Append("  , '" & S_PL_PT & "' ")
                                sb.Append("  , '" & S_MKT_EMP & "' ")
                                sb.Append("  , '" & S_TT_TR & "' ")
                                sb.Append("  , '" & S_PROJECT & "' ")
                                sb.Append("  , '" & gUserLogin & "' ")
                                sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
                                sb.Append("  , '" & gUserLogin & "' ")
                                sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
                                sb.Append("  , '" & v_gl_function & "' ")
                                sb.Append("  ) ")

                                c1 = c1 + clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
                                i = i + 1
                            Next

                            c1 = c1 + cls.CancelWHT(oleConn, oleTrans, DataGridView1.Rows(index).Cells(1).Value, status, gUserLogin)
                            i = i + 1
                        End If
                    Next


                    oleConn = clsUtility.gConnGP
                    oleTrans = oleConn.BeginTransaction()

                    If c1 = i Then

                        sb.Remove(0, sb.Length)
                        sb.Append("  UPDATE GENERATEPAYMENT.GLM_VOUCHER_NO ")
                        sb.Append(" SET GLM_VOUCHER_NO.VCH_NO = '" & getVoucherRun & "' ")
                        sb.Append(" WHERE GLM_VOUCHER_NO.VCH_JN_TYPE = '" & getJNType & "'")
                        c1 = c1 + clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
                        i = i + 1

                        sb.Remove(0, sb.Length)
                        sb.Append("  UPDATE GENERATEPAYMENT.GLM_INTERFACE_CONTROL  ")
                        sb.Append(" SET INT_STATUS = 'STOP' ")
                        sb.Append(" ,  INT_GL_NO = '" & getJNNO & "'  ")
                        sb.Append(" WHERE INT_FUNCTION = 'JN_NO' ")
                        c1 = c1 + clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

                        'sb.Remove(0, sb.Length)
                        'sb.Append(" EXECUTE GLM_SP_LOG_IMPORTGLMFEED('', ")
                        'sb.Append(" TO_CHAR(SYSDATE,'YYYYMMDD'), ")
                        'sb.Append(" 'GPS_SCREEN_CANCEL_TAX','SUCCESS','',  ")
                        'sb.Append(" TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'), ")
                        'sb.Append(" '" & getJNNO & "','','','GPSA', ")
                        'sb.Append("  '" & gUserLogin & "') ")
                        'c1 = c1 + clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

                        c1 = c1 + cls.CALL_GLM_SP_LOG_IMPORTGLMFEED(oleConn, getJNNO, gUserLogin, oleTrans)

                        oleTrans.Commit()
                        MsgBox("Cancel Seccessfully")

                        ClearForm()
                    Else
                        oleTrans.Rollback()
                        MsgBox("Can not cancel WHT!")
                    End If
                End If
            Else
                MsgBox("Amount Credit �����ҡѺ Amount Debit!")
            End If
        Else
            MsgBox("�������¡�� GL!")
        End If
    End Sub

    Private Sub txtDateFrom_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateFrom.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateFrom.Text.Trim = "" Then

            Else
                Dim dateString As String = txtDateFrom.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")
                    txtDateFrom.Text = ""
                    txtDateFrom.Focus()

                End If
            End If

        End If
    End Sub

    Private Sub txtDateTo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtDateTo.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtDateTo.Text.Trim = "" Then

            Else
                Dim dateString As String = txtDateTo.Text.Trim
                Dim formats As String = "dd/MM/yyyy"
                Dim dateValue As DateTime
                If DateTime.TryParseExact(dateString, formats, New Globalization.CultureInfo("en-US"), DateTimeStyles.None, dateValue) Then

                Else
                    MsgBox("Date format is not valid")
                    txtDateTo.Text = ""
                    txtDateTo.Focus()

                End If
            End If

        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnGLDr_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGLDr.Click
        Dim count1 As Integer = 0
        Dim strTrans As String
        Dim dt2 As DataTable
        

        Dim systemdate As String

        systemdate = Now.ToString("yyyyMMdd") 'Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = True Then
                count1 += 1
            End If
        Next

        If count1 < 1 Then
            Exit Sub
        End If

        Dim countrow As Integer = 0
        Dim sb As New StringBuilder
       
        strTrans = " ( '' "

        For index As Integer = 0 To DataGridView1.RowCount - 1
            If DataGridView1.Rows(index).Cells(0).Value = True Then
                strTrans = strTrans + " , '" + DataGridView1.Rows(index).Cells(8).Value + "'"
            End If
        Next
        strTrans = strTrans + " ) "

        dt2 = cls.GetDataGLForCancel(clsUtility.gConnGP, systemdate, strTrans, " ", " ", " ", " ", " ")
        GetDataToGrid2(dt2)
        TabControl1.SelectedIndex = 1

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ClearForm()
    End Sub

    Private Function ClearForm()
        'Clear TextBox Data
        txtBookNo.Clear()
        txtDateFrom.Clear()
        txtDateTo.Clear()
        txtTaxID.Clear()
        txtIDCard.Clear()
        txtName.Clear()

        'Clear Grid Data
        DataGridView1.Columns.Clear()
        DataGridView2.Columns.Clear()

        DataGridView1.Controls.Clear()
        DataGridView2.Controls.Clear()

        'Initial
        TabControl1.SelectedIndex = 0
        cboCancelType.SelectedIndex = 0
    End Function

    Private Sub AddGridRow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddGridRow.Click
        Try

            DataGridView2.AllowUserToAddRows = True
            Dim index = DataGridView2.Rows.Count - 1
            Dim newlineno As Integer = 1

            DataGridView2.CurrentCell = DataGridView2.Item(2, index)

            Me.DataGridView2.BeginEdit(False)
            Me.ActiveControl = DataGridView2.EditingControl


            'If cboEntryType.SelectedIndex = 0 Then
            If DataGridView2.Rows.Count > 1 Then
                newlineno = DataGridView2.Rows(DataGridView2.RowCount - 2).Cells(0).Value + 1  'index + 1
            Else
                newlineno = 1
            End If
            DataGridView2.Rows(index).Cells(1).Value = DataGridView2.Rows(index - 1).Cells(1).Value.ToString
            DataGridView2.Rows(index).Cells(9).Value = Now.ToString("yyyyMMdd")
            'DataGridView2.AllowUserToAddRows = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub DeleteGridRow_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DeleteGridRow.MouseClick
        Try
            Dim listRow As New ArrayList
            DataGridView2.AllowUserToAddRows = False
            If DataGridView2.RowCount > 0 Then
                If MessageBox.Show("Do you want to delete this record ? (Y/N)", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    For index2 As Integer = 0 To DataGridView2.RowCount - 1
                        If DataGridView2.Rows(index2).Cells(0).Value = True Then
                            listRow.Add(DataGridView2.Rows(index2))
                            'DataGridView2.Rows.Remove(row)
                            'DataGridView2.Rows().RemoveAt(index2)

                        End If
                    Next

                    For Each row As DataGridViewRow In listRow
                        DataGridView2.Rows.Remove(row)
                    Next
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

End Class