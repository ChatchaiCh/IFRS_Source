﻿Imports UtilityClassLibrary

Public Class FrmPhorNgorDor2_3_53Report_OutMth
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB
    Dim cls As New ClsWHT
    Private Sub FrmPhorNgorDor2_3_53_OutMthReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PanelH1.BackColor = Color.FromArgb(255, 235, 200)
        PanelD1.BackColor = Color.FromArgb(255, 245, 240)

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        ListPhorNgorDorOutMth()
        txtAccPeriod.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
        txtWHTPeriod.Text = Now.ToString("MM/yyyy").PadLeft(8, "0")
    End Sub

    Private Sub ListPhorNgorDorOutMth()
        cboPhorNgorDor.Items.Add("ภงด 2")
        cboPhorNgorDor.Items.Add("ภงด 3")
        cboPhorNgorDor.Items.Add("ภงด 53")
        cboPhorNgorDor.SelectedIndex = 0
    End Sub

    Private Sub PrintReport(ByVal reportname As String, ByVal period As String, ByVal accperiod As String, ByVal phorngordor As String)
        Dim frm1 As New FrmRptViewer
        frm1.TopLevel = False
        frm1.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm1)


        frm1.CrDoc.Close()

        frm1.CrDoc.Load(sReportPath & reportname)

        Dim dt As DataTable = New DataTable()

        dt = cls.GetDataPhorNgorDorOutMth_ByPeriod(clsUtility.gConnGP, period, accperiod, phorngordor)
        frm1.FillDataTableToReport(dt)
        frm1.Text = Me.Text
        frm1.Show()

        Dim frm As New FrmPhorNgorDor2_3_53Report_OutMth
        frm.TopLevel = False
        frm.Parent = FrmMainMenu.SplitContainer1.Panel2
        FrmMainMenu.SplitContainer1.Panel2.Controls.Add(frm)
        frm.Show()

        Me.Close()

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        If txtAccPeriod.Text.Trim = "" Then
            MsgBox("Plese Enter Account Period")
            Exit Sub
        End If

        If txtWHTPeriod.Text.Trim = "" Then
            MsgBox("Plese Enter WHT Period")
            Exit Sub
        End If

        Dim reportname As String = ""
        Dim phorngordor As String = ""
        Dim period As String = ""
        Dim accperiod As String = ""
        If txtWHTPeriod.Text <> "" And txtAccPeriod.Text <> "" Then
            period = txtWHTPeriod.Text.Substring(4, 4) & txtWHTPeriod.Text.Substring(1, 2)
            accperiod = txtAccPeriod.Text.Substring(4, 4) & txtAccPeriod.Text.Substring(1, 2)
            Select Case cboPhorNgorDor.Text.Trim
                Case "ภงด 2"
                    reportname = "RptPhorNgorDor2.rpt"
                    phorngordor = "02"
                Case "ภงด 3"
                    reportname = "RptPhorNgorDor3.rpt"
                    phorngordor = "03"
                Case "ภงด 53"
                    reportname = "RptPhorNgorDor53.rpt"
                    phorngordor = "53"
            End Select

            PrintReport(reportname, period, accperiod, phorngordor)
        End If
    End Sub

    Private Sub RipsWareImageButtonBase1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RipsWareImageButtonBase1.Click
        Me.Close()
    End Sub
End Class