﻿Imports UtilityClassLibrary
Imports System.Text
Imports System.Data.OleDb
Imports System.IO
Imports System.Globalization
Imports Microsoft.Office.Interop

Public Class FrmHashTotalError_IL

    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsHashTotalErrorLOCancel
    Dim clsGenPayment As New ClsGeneratePaymentFile
    Dim LO_Dup As New StringBuilder
    Dim sDataExist As New StringBuilder
    Dim clsGPS_PayoutGroupSetup As New ClsGPS_PayOutGroup_Setup

    Private Sub FrmHashTotalErrorIL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2 = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        InitializeOpenFileDialog()

        'Panel1.BackColor = Color.FromArgb(198, 170, 212)
        Label2.BackColor = Color.FromArgb(255, 235, 220)
        Panel1.BackColor = Color.FromArgb(233, 222, 238)
        Panel2.BackColor = Color.FromArgb(233, 222, 238)

    End Sub

    Private Sub InitializeOpenFileDialog()
        Dim pathLO As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "LOCANCELFILE_PATH")
        ' Set the file dialog to filter for graphics files.
        Me.OpenFileDialog1.Filter = _
                "Excel (*.xls;*.xlsx)|*.xls;*.xlsx|" + _
                "All files (*.*)|*.*"

        ' Allow the user to select multiple images.
        Me.OpenFileDialog1.Multiselect = True
        Me.OpenFileDialog1.Title = "My Excel Browser"
        Me.OpenFileDialog1.InitialDirectory = pathLO 'PRD Path
        'Me.OpenFileDialog1.InitialDirectory = "D:\Work_SCB\GPS\Work_201509\Test\"
    End Sub

    Private Sub GenGridHashTotalIL(ByVal dt As DataTable)

        With dgvFile

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(233, 222, 238)
            .DefaultCellStyle.SelectionForeColor = Color.Indigo
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvFile.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.Indigo
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cfileName
            .DataPropertyName = "PAYM_FILENAME_OUT_TOBANK"
            .Name = "ชื่อไฟล์"
            .Width = 250
            .ReadOnly = True
            dgvFile.Columns.Add(cfileName)

        End With

        Dim clineNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With clineNo
            .DataPropertyName = "payd_seqno"
            .Name = "Line No"
            .Width = 60
            .ReadOnly = True
            dgvFile.Columns.Add(clineNo)
        End With

        Dim cPayNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayNo
            .DataPropertyName = "payd_3_cust_ref"
            .Name = "Payment Number"
            .Width = 100
            .ReadOnly = True
            dgvFile.Columns.Add(cPayNo)

        End With

        Dim cPayMth As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayMth
            .DataPropertyName = "exp_paymth"
            .Name = "Payment Method"
            .Width = 100
            .ReadOnly = True
            dgvFile.Columns.Add(cPayMth)
        End With

        Dim cBnkCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkCode
            .DataPropertyName = "bnkcde"
            .Name = "Bank Code"
            .Width = 120
            .ReadOnly = True
            dgvFile.Columns.Add(cBnkCode)
        End With

        Dim cBnkAccNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkAccNo
            .DataPropertyName = "payd_3_c_acc_no"
            .Name = "Bank Account No"
            .Width = 120
            .ReadOnly = True
            dgvFile.Columns.Add(cBnkAccNo)
        End With

        Dim cAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmt
            .DataPropertyName = "payd_3_c_amt_num"
            .Name = "Amount"
            .Width = 100
            .ReadOnly = True
            dgvFile.Columns.Add(cAmt)
        End With

        Dim cPayDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayDate
            .DataPropertyName = "payment_date"
            .Name = "Payment Date"
            .Width = 120
            .ReadOnly = True
            dgvFile.Columns.Add(cPayDate)
        End With

        Dim cRejectType As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejectType
            .DataPropertyName = "rejt_rej_type"
            .Name = "Reject Type"
            .Width = 120
            .ReadOnly = True
            dgvFile.Columns.Add(cRejectType)
        End With

        Dim cRejDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejDesc
            .DataPropertyName = "rejt_remark"
            .Name = "Reject Desc"
            .Width = 180
            .ReadOnly = True
            dgvFile.Columns.Add(cRejDesc)
        End With

        Dim cOldFileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cOldFileName
            .DataPropertyName = "payd_file_name"
            .Name = "ชื่อไฟล์"
            .Width = 250
            .ReadOnly = True
            .Visible = False
            dgvFile.Columns.Add(cOldFileName)

        End With

    End Sub

    Private Sub GenGridLO(ByVal dt As DataTable)

        With dgvLo

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(233, 222, 238)
            .DefaultCellStyle.SelectionForeColor = Color.Indigo
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvLo.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.Indigo
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cfileName
            .DataPropertyName = "PAYM_FILENAME_OUT_TOBANK"
            .Name = "ชื่อไฟล์"
            .Width = 250
            .ReadOnly = True
            dgvLo.Columns.Add(cfileName)

        End With

        Dim cPayNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayNo
            .DataPropertyName = "rjil_cust_ref"
            .Name = "Payment Number"
            .Width = 100
            .ReadOnly = True
            dgvLo.Columns.Add(cPayNo)

        End With

        Dim cPayMth As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayMth
            .DataPropertyName = "rjil_paymth"
            .Name = "Payment Method"
            .Width = 100
            .ReadOnly = True
            dgvLo.Columns.Add(cPayMth)
        End With

        Dim cBnkCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkCode
            .DataPropertyName = "bnkcde"
            .Name = "Bank Code"
            .Width = 120
            .ReadOnly = True
            dgvLo.Columns.Add(cBnkCode)
        End With

        Dim cBnkAccNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkAccNo
            .DataPropertyName = "payd_3_c_acc_no"
            .Name = "Bank Account No"
            .Width = 120
            .ReadOnly = True
            dgvLo.Columns.Add(cBnkAccNo)
        End With

        Dim cAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmt
            .DataPropertyName = "payd_3_c_amt_num"
            .Name = "Amount"
            .Width = 100
            .ReadOnly = True
            dgvLo.Columns.Add(cAmt)
        End With

        Dim cPayDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayDate
            .DataPropertyName = "payment_date"
            .Name = "Payment Date"
            .Width = 120
            .ReadOnly = True
            dgvLo.Columns.Add(cPayDate)
        End With

        Dim cRejectTye As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejectTye
            .DataPropertyName = "rejt_rej_type"
            .Name = "Payment Type"
            .Width = 120
            .ReadOnly = True
            dgvLo.Columns.Add(cRejectTye)
        End With

        Dim cRejDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejDesc
            .DataPropertyName = "rejt_remark"
            .Name = "Reject Desc"
            .Width = 180
            .ReadOnly = True
            dgvLo.Columns.Add(cRejDesc)
        End With

        Dim cOldfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cOldfileName
            .DataPropertyName = "payd_file_name"
            .Name = "ชื่อไฟล์"
            .Width = 100
            .ReadOnly = True
            .Visible = False
            dgvLo.Columns.Add(cOldfileName)

        End With

    End Sub

    Private Sub btnAddFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddFile.Click

        Dim sysdate As String = cls.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")
        'ยกเลิกเงื่อนไข reject ได้ 1 ครั้งต่อ 1 วัน
        'If cls.checkRejectByDate(clsUtility.gConnGP, sysdate) Then
        Dim sumAmt As Double
        Dim f As New FrmFindFileHashTotalIL
        f.Owner = Me
        f.Text = Me.Text
        f.ShowDialog()

        If retFileNameIL <> "" And retPayNoIL <> "" Then
            Dim dt As DataTable
            dt = cls.generateDataForHashTotalIL(clsUtility.gConnGP, sysdate, retFileNameIL, retPayNoIL)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                GenGridHashTotalIL(dt)
                For Each rowSum As DataRow In dt.Rows
                    sumAmt = sumAmt + rowSum("payd_3_c_amt_num")
                Next

                txtTotalAmtIL.Text = sumAmt.ToString("F", CultureInfo.InvariantCulture)
            Else
                MsgBox("ไม่พบข้อมูล")
            End If
        End If
        'Else
        'MsgBox("มีการ Reject รายการจ่าย IL ในวันนี้แล้ว ไม่สามารถ Reject ซ้ำได้...")
        'End If
        retFileNameIL = CType("", String)
        retPayNoIL = CType("", String)
    End Sub

    Private Sub txtBrowseFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtBrowseFile.Click
        Dim sysdate As String = cls.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")

        Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
        'ยกเลิกเงื่อนไข reject ได้ 1 ครั้งต่อ 1 วัน
        'If cls.checkRejectByDate(clsUtility.gConnGP, sysdate) Then

        OpenFileDialog1.Filter = "Excel Files(*.xls)|*" & strCurrentDate & "*.xls"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Title = "เลือก LO Cancel ไฟล์"
        OpenFileDialog1.ShowDialog()

        'Else
        'MsgBox("มีการ Reject รายการจ่าย IL ในวันนี้แล้ว ไม่สามารถ Reject ซ้ำได้...")
        'End If
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        If (System.Windows.Forms.DialogResult.OK) Then
            ' If Files Identify Array
            Dim oleConn As OleDbConnection
            Dim oleTrans As OleDbTransaction
            Dim oleTransDelete1 As OleDbTransaction
            Dim oleTransDelete2 As OleDbTransaction
            Dim oleConnSelect As OleDbConnection
            Dim sysdate As String = cls.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")
            Dim sFileNameFrom As String
            Dim sFileNameTo As String

            oleConn = clsUtility.gConnGP

            oleConnSelect = clsUtility.gConnGP_2

            oleTransDelete1 = oleConn.BeginTransaction

            cls.deleteFromPayoutTempReject(oleConn, oleTransDelete1)
            oleTransDelete1.Commit()

            oleTrans = oleConn.BeginTransaction
            Dim file() As String
            Dim dt As DataTable
            Dim dtDup As DataTable
            file = OpenFileDialog1.FileNames
            Dim fullpathfile = String.Join(",", OpenFileDialog1.FileNames) 'fullpathfile2,fullpathfile2

            Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))

            Dim custOld, custNew As String
            Dim sb As New StringBuilder
            Dim custDup As New StringBuilder
            Dim intCheckPaymentAndAmount As Integer

            LO_Dup.Clear()
            LO_Dup.Append("File Name         |PaymentNo|Amount").AppendLine()
            LO_Dup.Append("-----------------------------------").AppendLine()

            ' Read excel file and insert into PAYOUT_TMP_REJECT
            Dim xlApp As Excel.Application
            Dim xlWorkBook As Excel.Workbook
            Dim xlWorkSheet As Excel.Worksheet

            Try
                Dim countFile, count, countInsert, countDup As Integer
                countFile = 0
                count = 0
                countInsert = 0
                countDup = 0
                Dim payNo, payMth, bnkCde, accNo, amt, payDate, reasonOfReverse, fileName, payDateInsert As String
                ' Split string based on spaces.
                Dim words As String() = fullpathfile.Split(New Char() {","c})
                ' Use For Each loop over words and display them.
                Dim word As String
                For Each word In words

                    fileName = Path.GetFileName(word)

                    If fileName.ToString.Contains(strCurrentDate) = False Then
                        Continue For
                    End If

                    xlApp = New Excel.Application
                    xlWorkBook = xlApp.Workbooks.Open(word)
                    xlWorkSheet = xlWorkBook.Worksheets(1)

                    'Check name
                    If Trim(xlWorkSheet.Cells(2, 1).value()).Equals("Payment Number") And _
                        Trim(xlWorkSheet.Cells(2, 2).value()).Equals("Payment Method " & vbLf & "(D/C/M)") And _
                        Trim(xlWorkSheet.Cells(2, 3).value()).Equals("Bank Code") And _
                        Trim(xlWorkSheet.Cells(2, 4).value()).Equals("Account Number") And _
                        Trim(xlWorkSheet.Cells(2, 5).value()).Equals("Amount") And _
                        Trim(xlWorkSheet.Cells(2, 6).value()).Equals("Payment Date" & vbLf & "(dd/mm/yyyy)" & vbLf & "(yyyy-คศ.)") And _
                        Trim(xlWorkSheet.Cells(2, 7).value()).Equals("Reason of Reverse") Then


                        '-----------------------
                        '-- Check file format --
                        '-----------------------
                        Dim row As Integer = 3
                        Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing
                            payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                            payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                            bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                            accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                            amt = xlWorkSheet.Cells(row, 5).value & "" 'column 5
                            payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                            reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7
                            If Not (payMth.ToString.Contains("C") Or payMth.ToString.Contains("D") Or payMth.ToString.Contains("M")) _
                                Or Not IsDate(payDate) _
                                Or Not IsNumeric(amt) _
                                Or payDate.Length <> 10 Then

                                xlWorkBook.Close()
                                'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".")(0).ToString & "_reject." & word.ToString.Split(".")(1).ToString)
                                sFileNameFrom = word.ToString
                                sFileNameTo = Path.GetDirectoryName(word.ToString) & "\" & Path.GetFileNameWithoutExtension(word.ToString) & "_FORMAT_ERROR" & Path.GetExtension(word.ToString)
                                '--If cls.RenameFile_RejectByFile(word.ToString) <> "-1" Then
                                If cls.RenameFileFormatError(oleConn, sFileNameFrom, Path.GetDirectoryName(word.ToString), Path.GetExtension(word.ToString).Replace(".", "")) Then
                                    LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                                Else
                                    xlApp.Quit()
                                    releaseObject(xlApp)
                                    releaseObject(xlWorkBook)
                                    releaseObject(xlWorkSheet)
                                    oleTrans.Rollback()
                                    MsgBox("ไม่สามารถ Rename Reject File, กรุณาติดต่อผู้ดูแลระบบ", MsgBoxStyle.Critical)
                                    Exit Try
                                End If
                                Continue For
                            End If
                            row = row + 1
                        Loop

                        '------------------------------
                        '-- Check duplicate same day --
                        '------------------------------
                        row = 3
                        Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing

                            'payNo = xlWorkSheet.Cells(row, 1).value 'column 1
                            'payMth = xlWorkSheet.Cells(row, 2).value 'column 2
                            'bnkCde = xlWorkSheet.Cells(row, 3).value 'column 3
                            'accNo = xlWorkSheet.Cells(row, 4).value 'column 4
                            'amt = xlWorkSheet.Cells(row, 5).value 'column 5
                            'payDate = xlWorkSheet.Cells(row, 6).value 'column 6
                            'reasonOfReverse = xlWorkSheet.Cells(row, 7).value 'column 7

                            payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                            payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                            bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                            accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                            amt = xlWorkSheet.Cells(row, 5).value 'column 5
                            payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                            reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7

                            payDateInsert = payDate.Substring(6, 4) & payDate.Substring(3, 2) & payDate.Substring(0, 2)

                            Dim rec As Integer = cls.insertIntoPayoutTempReject(oleConn, oleTrans, sysdate, fileName, reasonOfReverse, payMth, bnkCde, _
                                                           accNo, payNo, amt, "", payDateInsert)

                            If countDup > 0 Then
                                custDup.Append(",")
                            End If
                            If rec = -1 Then
                                custDup.Append(payNo)
                                LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Duplicated").AppendLine()
                                countDup = countDup + 1
                            Else

                                'cls.deletePayoutTempRejectByFileName(oleConn, oleTransDelete2, fileName)
                                'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".").ToString & "_reject." & word.ToString.Split(".").ToString)
                                'LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                                intCheckPaymentAndAmount = 0
                                intCheckPaymentAndAmount = cls.CheckLOInvalidPaymentAndAmount(oleConnSelect, strCurrentDate, payNo, payMth, CDbl(amt))
                                Select Case intCheckPaymentAndAmount
                                    Case 0 '-- valid
                                        '-- no action
                                    Case 1 '-- invalid payment number / Payment number not found      
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Payment number not found").AppendLine()
                                    Case 2 '-- invalid payment method      
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method").AppendLine()
                                    Case 3 '-- invalid payment amount
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment amount").AppendLine()
                                    Case 4 '-- invalid 1 & 2
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method and amount").AppendLine()
                                    Case Else '-- unknow error
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid other condition").AppendLine()
                                End Select
                            End If

                            count = count + 1
                            row += 1
                        Loop

                    Else
                        MsgBox("รูปแบบไฟล์ไม่ถูกต้อง")

                        xlWorkBook.Application.DisplayAlerts = False

                        xlWorkBook.Close()
                        xlApp.Quit()

                        releaseObject(xlApp)
                        releaseObject(xlWorkBook)
                        releaseObject(xlWorkSheet)

                        oleTrans.Rollback()

                        Exit Sub
                    End If

                    xlWorkBook.Application.DisplayAlerts = False

                    xlWorkBook.Close()
                    xlApp.Quit()

                    releaseObject(xlApp)
                    releaseObject(xlWorkBook)
                    releaseObject(xlWorkSheet)

                    countFile = countFile + 1
                Next

                oleTrans.Commit()

            Catch ex As Exception
                xlWorkBook.Close()
                xlApp.Quit()

                releaseObject(xlApp)
                releaseObject(xlWorkBook)
                releaseObject(xlWorkSheet)
                MsgBox(ex.ToString)
                oleTrans.Rollback()
                Exit Sub
            End Try

            'xxx Delete Dupicate payment no
            Dim iTemp As Integer

            dtDup = cls.CheckDuplicatePayoutRejLog(oleConn)
            sDataExist.Clear()
            If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Then
                For Each row As DataRow In dtDup.Rows
                    sb.Append("'")
                    sb.Append(row.Item(0))
                    sb.Append("'")
                    sDataExist.Append(row.Item(1).ToString & "" & "|" & row.Item(0).ToString & "" & "| Data exist!").AppendLine()
                Next
                oleTransDelete2 = oleConn.BeginTransaction
                Try
                    cls.deletePayoutTempRejectByCustref(oleConn, oleTransDelete2, custDup.ToString)
                    oleTransDelete2.Commit()
                Catch ex As Exception
                    oleTransDelete2.Rollback()
                End Try
                MsgBox("Duplicate old data!" & vbCrLf & vbCrLf & sDataExist.ToString)
            End If

            If LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
                MsgBox("Duplicate in excel file / Excel format error !!" & vbCrLf & vbCrLf & LO_Dup.ToString)
            End If


            'If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Or custDup.Length > 0 Then

            '    '---------------------------------------------------------------'
            '    '-- pongpipat -- ขั้นตอนก่อนหน้านี้ ไม่สามารถ insert ได้ ดังนั้นต้องไม่ delete  
            '    '---------------------------------------------------------------'
            '    'If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Then
            '    '    Dim i As Integer = 0
            '    '    For Each row As DataRow In dtDup.Rows
            '    '        sb.Append("'")
            '    '        sb.Append(row.Item(0))
            '    '        sb.Append("'")
            '    '        If i > 0 Then
            '    '            sb.Append(",")
            '    '        End If
            '    '        i = i + 1
            '    '    Next
            '    '    oleTransDelete2 = oleConn.BeginTransaction
            '    '    Try
            '    '        cls.deletePayoutTempRejectByCustref(oleConn, oleTransDelete2, custDup.ToString)
            '    '        oleTransDelete2.Commit()
            '    '    Catch ex As Exception
            '    '        oleTransDelete2.Rollback()
            '    '    End Try
            '    '    
            '    'End If
            '    '---------------------------------------------------------------'

            '    '-- MsgBox("มีข้อมูล Dup ในไฟล์ : " & custDup.ToString & vbLf & "มีข้อมูล Dup ตาราง" & sb.ToString)
            '    MsgBox("มีข้อมูลซ้ำ / Format error !!" & vbCrLf & LO_Dup.ToString)
            'ElseIf LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
            '    MsgBox("มีข้อมูลซ้ำ / Format error !!" & vbCrLf & LO_Dup.ToString)
            'End If

            dt = cls.generateDataForHashTotalLo(oleConn, sysdate)
            GenGridLO(dt)

            Dim sumAmt As Double
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                For Each rowSum As DataRow In dt.Rows
                    sumAmt = sumAmt + rowSum("payd_3_c_amt_num")
                Next
            End If

            txtTotalAmtLO.Text = sumAmt.ToString("F", CultureInfo.InvariantCulture)

        End If
    End Sub

    Private Sub btnRejectFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRejectFile.Click

        '-- Reject error start on 20190617
        Dim oFile As System.IO.StreamWriter
        oFile = My.Computer.FileSystem.OpenTextFileWriter("D:\" & Now.ToString("yyyyMMddHHMMss") & ".TXT", True)
        '-- Reject error start on 20190617

        Dim dtPayoutGroupSetup As DataTable
        dtPayoutGroupSetup = clsGPS_PayoutGroupSetup.GetGps_Payoutgroup_Setup()

        If IsNothing(dtPayoutGroupSetup) Then 'AndAlso dtPayoutGroupSetup.Rows.Count <= 0 Then
            'Throw New Exception("Gps_Payoutgroup_Setup or Some approvegroup is missing.")
            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Gps_Payoutgroup_Setup is missing.")
            oFile.Close()
            MsgBox("Gps_Payoutgroup_Setup is missing.", MsgBoxStyle.Information)
            Exit Sub
        End If

        If MessageBox.Show("Do you want to Reject ? (Y/N)", "Reject / Regen File", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            'ตรวจสอบว่าที่ Hash Total Error กับ LO Cancel มี payment no ซ้ำกันหรือไม่
            Dim payNoIL As String
            Dim payNoLO As String
            For indexIL As Integer = 0 To dgvFile.RowCount - 1
                payNoIL = dgvFile.Rows(indexIL).Cells(2).Value
                For indexLO As Integer = 0 To dgvLo.RowCount - 1
                    payNoLO = dgvLo.Rows(indexLO).Cells(1).Value
                    If payNoIL = payNoLO Then
                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "ไม่สามารถทำการ reject ได้ เพราะ Hash Total Error กับ LO Cancel มี payment no ซ้ำกัน")
                        oFile.Close()
                        MsgBox("ไม่สามารถทำการ reject ได้ เพราะ Hash Total Error กับ LO Cancel มี payment no ซ้ำกัน")
                        Exit Sub
                    End If
                Next
            Next

            Dim oleConn As OleDbConnection
            Dim oleQueryConn As OleDbConnection
            Dim oleTrans As OleDbTransaction
            Dim oleLog As OleDbConnection

            Dim sysdate As String = cls.getSysDate(clsUtility.gConnGP)
            Dim pathGenFile As String = cls.getPathGenFile(clsUtility.gConnGP)
            Dim pathLOReport As String = cls.getPathLOReport(clsUtility.gConnGP)
            Dim pathReport As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")
            Dim sb, sbInsert As New StringBuilder
            Dim i, rec As Integer
            Dim dtIL, dtOL As DataTable
            Dim drIL, drOL As DataRow
            Dim dr() As System.Data.DataRow
            Dim strList As New List(Of String)

            Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))

            oleConn = clsUtility.gConnGP
            oleLog = clsUtility.gConnGP_2


            If dgvFile.RowCount > 0 Or dgvLo.RowCount > 0 Then

                'ยกเลิกเงื่อนไข reject ได้ 1 ครั้งต่อ 1 วัน
                '3.3.1 ตรวจสอบว่ามีการ Reject ในวันแล้วหรือไม่ ?
                'If cls.checkRejectByDate(oleConn, sysdate) Then

                '3.3.2 นำข้อมูลในตารางที่ 1 และ ตารางที่ 2 ในหน้าจอ Insert ในตาราง PAYOUT_REJECT_LOG

                i = 0
                rec = 0
                strList.Clear()

                For indexIL As Integer = 0 To dgvFile.RowCount - 1
                    Dim cfileName As String = dgvFile.Rows(indexIL).Cells(10).Value
                    Dim clineNo As String = dgvFile.Rows(indexIL).Cells(1).Value
                    Dim cPayNo As String = dgvFile.Rows(indexIL).Cells(2).Value
                    Dim cPayMth As String = dgvFile.Rows(indexIL).Cells(3).Value
                    Dim cBnkCode As String = dgvFile.Rows(indexIL).Cells(4).Value
                    Dim cBnkAccNo As String = dgvFile.Rows(indexIL).Cells(5).Value
                    Dim cAmt As String = dgvFile.Rows(indexIL).Cells(6).Value
                    Dim cPayDate As String = dgvFile.Rows(indexIL).Cells(7).Value
                    Dim cRejType As String = dgvFile.Rows(indexIL).Cells(8).Value
                    Dim cRejDesc As String = dgvFile.Rows(indexIL).Cells(9).Value
                    Dim paydfilenames, paydseqno, bnkcde, rejtrejgroup, paydtranscode, paydpolno, payduserid, payd4payee1nmetha As String
                    If checkDuplicateList(strList, cfileName & cPayNo) = 0 Then

                        strList.Add(cfileName & cPayNo)

                        dtIL = cls.getPayoutRejectLogIL(oleConn, sysdate, cfileName, Trim(cPayNo))
                        If Not IsNothing(dtIL) Then
                            paydfilenames = dtIL.Rows(0)("payd_file_name_s").ToString
                            paydseqno = dtIL.Rows(0)("payd_seqno")
                            bnkcde = dtIL.Rows(0)("bnkcde").ToString
                            rejtrejgroup = dtIL.Rows(0)("rejt_rej_group").ToString
                            paydtranscode = dtIL.Rows(0)("payd_trans_code").ToString
                            paydpolno = dtIL.Rows(0)("payd_polno").ToString
                            payduserid = dtIL.Rows(0)("payd_user_id").ToString
                            payd4payee1nmetha = dtIL.Rows(0)("payd_4_payee1_nmetha").ToString
                        End If
                        sb.Append("INSERT INTO PAYOUT_REJECT_LOG ")
                        sb.Append("  ( ")
                        sb.Append("    RJIL_REJ_DATE, ")
                        sb.Append("    RJIL_CUST_REF, ")
                        sb.Append("    RJIL_SEQNO, ")
                        sb.Append("    RJIL_FILE_NAME, ")
                        sb.Append("    RJIL_PAYMTH_FILE, ")
                        sb.Append("    RJIL_BNKCODE_FILE, ")
                        sb.Append("    RJIL_BNKACC_NO_FILE, ")
                        sb.Append("    RJIL_AMOUNT_FILE, ")
                        sb.Append("    RJIL_PAIDDATE_FILE, ")
                        sb.Append("    RJIL_REJECT_REASON, ")
                        sb.Append("    RJIL_FILE_NAME_S1_S, ")
                        sb.Append("    RJIL_FILE_NAME_S1_D, ")
                        sb.Append("    RJIL_PAYMTH, ")
                        sb.Append("    RJIL_BNKCODE, ")
                        sb.Append("    RJIL_BNKACC_NO, ")
                        sb.Append("    RJIL_AMOUNT, ")
                        sb.Append("    RJIL_PAIDDATE, ")
                        sb.Append("    RJIL_REJECT_TYPE, ")
                        sb.Append("    RJIL_REJECT_FUNC, ")
                        sb.Append("    RJIL_TRANS_CODE, ")
                        sb.Append("    RJIL_POLNO, ")
                        sb.Append("    RJIL_USER_ID, ")
                        sb.Append("    RJIL_PAYEE_NME, ")
                        sb.Append("    CREATEDBY, ")
                        sb.Append("    UPDATEDBY, ")
                        sb.Append("    CREATEDDATE, ")
                        sb.Append("    UPDATEDDATE ")
                        sb.Append("  ) ")
                        sb.Append("  VALUES ")
                        sb.Append("  ( ")
                        sb.Append("    Trim('" & sysdate & "'), ")
                        sb.Append("    Trim('" & cPayNo & "'), ")
                        sb.Append("    " & paydseqno & ", ")
                        sb.Append("    Trim('" & cfileName & "'), ")
                        sb.Append("    '', ")
                        sb.Append("    '', ")
                        sb.Append("    '', ")
                        sb.Append("    null, ")
                        sb.Append("    '', ")
                        sb.Append("    Trim('" & cRejDesc & "'), ")
                        sb.Append("    '" & paydfilenames & "', ")
                        sb.Append("    Trim('" & cfileName & "'), ")
                        sb.Append("    Trim('" & cPayMth & "'), ")
                        sb.Append("    Trim('" & cBnkCode & "'), ")
                        sb.Append("    Trim('" & cBnkAccNo & "'), ")
                        sb.Append("    " & cAmt & ", ")
                        sb.Append("    Trim('" & cPayDate & "'), ")
                        sb.Append("    Trim('" & cRejType & "'), ")
                        sb.Append("    Trim('" & rejtrejgroup & "'), ")
                        sb.Append("    Trim('" & paydtranscode & "'), ")
                        sb.Append("    Trim('" & paydpolno & "'), ")
                        sb.Append("    Trim('" & payduserid & "'), ")
                        sb.Append("    Trim('" & payd4payee1nmetha & "'), ")
                        sb.Append("    '" & gUserLogin & "', ")
                        sb.Append("    '" & gUserLogin & "', ")
                        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
                        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
                        sb.Append("  );")
                    End If
                Next

                strList.Clear()
                For indexLO As Integer = 0 To dgvLo.RowCount - 1
                    Dim cfileName As String = dgvLo.Rows(indexLO).Cells(9).Value
                    Dim cPayNo As String = dgvLo.Rows(indexLO).Cells(1).Value
                    Dim cPayMth As String = dgvLo.Rows(indexLO).Cells(2).Value
                    Dim cBnkCode As String = dgvLo.Rows(indexLO).Cells(3).Value
                    Dim cBnkAccNo As String = dgvLo.Rows(indexLO).Cells(4).Value
                    Dim cAmt As String = dgvLo.Rows(indexLO).Cells(5).Value
                    Dim cPayDate As String = dgvLo.Rows(indexLO).Cells(6).Value
                    Dim cRejType As String = dgvLo.Rows(indexLO).Cells(7).Value
                    Dim cRejDesc As String = dgvLo.Rows(indexLO).Cells(8).Value
                    If checkDuplicateList(strList, cfileName & cPayNo) = 0 Then

                        strList.Add(cfileName & cPayNo)
                        dtOL = cls.getPayoutRejectLogLO(oleConn, sysdate, cfileName, Trim(cPayNo))

                        Dim paydfilenames, paydseqno, xlsfile, exppaymth, bnkcde, payd3caccno, _
                            paydtranscode, paydpolno, payduserid, payd4payee1nmetha, _
                            payd3camtnum, paymentdate, rejtrejgroup As String
                        If Not IsNothing(dtOL) Then
                            paydfilenames = dtOL.Rows(0)("payd_file_name_s").ToString
                            paydseqno = dtOL.Rows(0)("payd_seqno")
                            xlsfile = dtOL.Rows(0)("xls_file").ToString
                            exppaymth = dtOL.Rows(0)("exp_paymth").ToString
                            bnkcde = dtOL.Rows(0)("bnkcde").ToString
                            payd3caccno = dtOL.Rows(0)("payd_3_c_acc_no").ToString
                            payd3camtnum = dtOL.Rows(0)("payd_3_c_amt_num")
                            paymentdate = dtOL.Rows(0)("payment_date").ToString
                            rejtrejgroup = dtOL.Rows(0)("rejt_rej_group").ToString
                            paydtranscode = dtOL.Rows(0)("payd_trans_code").ToString
                            paydpolno = dtOL.Rows(0)("payd_polno").ToString
                            payduserid = dtOL.Rows(0)("payd_user_id").ToString
                            payd4payee1nmetha = dtOL.Rows(0)("payd_4_payee1_nmetha").ToString
                        End If
                        sb.Append("INSERT INTO PAYOUT_REJECT_LOG ")
                        sb.Append("  ( ")
                        sb.Append("    RJIL_REJ_DATE, ")
                        sb.Append("    RJIL_CUST_REF, ")
                        sb.Append("    RJIL_SEQNO, ")
                        sb.Append("    RJIL_FILE_NAME, ")
                        sb.Append("    RJIL_PAYMTH_FILE, ")
                        sb.Append("    RJIL_BNKCODE_FILE, ")
                        sb.Append("    RJIL_BNKACC_NO_FILE, ")
                        sb.Append("    RJIL_AMOUNT_FILE, ")
                        sb.Append("    RJIL_PAIDDATE_FILE, ")
                        sb.Append("    RJIL_REJECT_REASON, ")
                        sb.Append("    RJIL_FILE_NAME_S1_S, ")
                        sb.Append("    RJIL_FILE_NAME_S1_D, ")
                        sb.Append("    RJIL_PAYMTH, ")
                        sb.Append("    RJIL_BNKCODE, ")
                        sb.Append("    RJIL_BNKACC_NO, ")
                        sb.Append("    RJIL_AMOUNT, ")
                        sb.Append("    RJIL_PAIDDATE, ")
                        sb.Append("    RJIL_REJECT_TYPE, ")
                        sb.Append("    RJIL_REJECT_FUNC, ")
                        sb.Append("    RJIL_TRANS_CODE, ")
                        sb.Append("    RJIL_POLNO, ")
                        sb.Append("    RJIL_USER_ID, ")
                        sb.Append("    RJIL_PAYEE_NME, ")
                        sb.Append("    CREATEDBY, ")
                        sb.Append("    UPDATEDBY, ")
                        sb.Append("    CREATEDDATE, ")
                        sb.Append("    UPDATEDDATE ")
                        sb.Append("  ) ")
                        sb.Append("  VALUES ")
                        sb.Append("  ( ")
                        sb.Append("    Trim('" & sysdate & "'), ")
                        sb.Append("    Trim('" & cPayNo & "'), ")
                        sb.Append("    " & paydseqno & ", ")
                        sb.Append("    Trim('" & xlsfile & "'), ")
                        sb.Append("    Trim('" & cPayMth & "'), ")
                        sb.Append("    Trim('" & cBnkCode & "'), ")
                        sb.Append("    Trim('" & cBnkAccNo & "'), ")
                        sb.Append("    " & cAmt & ", ")
                        sb.Append("    Trim('" & cPayDate & "'), ")
                        sb.Append("    Trim('" & cRejDesc & "'), ")
                        sb.Append("    Trim('" & paydfilenames & "'), ")
                        sb.Append("    Trim('" & cfileName & "'), ")
                        sb.Append("    Trim('" & exppaymth & "'), ")
                        sb.Append("    Trim('" & bnkcde & "'), ")
                        sb.Append("    Trim('" & payd3caccno & "'), ")
                        sb.Append("    " & payd3camtnum & ", ")
                        sb.Append("    Trim('" & paymentdate & "'), ")
                        sb.Append("    Trim('" & cRejType & "'), ")
                        sb.Append("    Trim('" & rejtrejgroup & "'), ")
                        sb.Append("    Trim('" & paydtranscode & "'), ")
                        sb.Append("    Trim('" & paydpolno & "'), ")
                        sb.Append("    Trim('" & payduserid & "'), ")
                        sb.Append("    Trim('" & payd4payee1nmetha & "'), ")
                        sb.Append("    '" & gUserLogin & "', ")
                        sb.Append("    '" & gUserLogin & "', ")
                        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
                        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
                        sb.Append("  );")
                    End If
                Next

                oleTrans = oleConn.BeginTransaction
                i = 0
                rec = 0

                If sb.Length = 0 Then
                    Exit Sub
                End If

                sb.Remove(sb.Length - 1, 1)

                Try
                    If Not sb.ToString.IndexOf(";") = -1 Then
                        Dim words As String() = sb.ToString.Split(New Char() {";"c})
                        ' Use For Each loop over words and display them.
                        Dim word As String
                        For Each word In words
                            sbInsert.Remove(0, sbInsert.Length)
                            rec = rec + clsBusiness.ExecuteCommand(oleConn, sbInsert.Append(word), oleTrans)
                            '--MsgBox("Error insert reject log1: " & clsBusiness.gLastErrMessage)
                            i = i + 1
                        Next
                    Else
                        rec = rec + clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
                        '--MsgBox("Error insert reject log2: " & clsBusiness.gLastErrMessage)
                        i = i + 1
                    End If
                    If rec = i Then
                        oleTrans.Commit()
                    Else
                        If clsBusiness.gLastErrMessage.ToString.Substring(0, 9) = "ORA-00001" Then
                            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Customer Reference / Payment Number duplicate!")
                            MsgBox("Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Customer Reference / Payment Number duplicate!", MsgBoxStyle.Critical)
                        Else
                            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Customer Reference / Payment Number duplicate!")
                            MsgBox("Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & clsBusiness.gLastErrMessage.ToString, MsgBoxStyle.Critical)
                        End If
                        oleTrans.Rollback()
                        Exit Sub
                    End If
                Catch ex As Exception
                    '--MsgBox("Error1: " & ex.ToString)
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Error by Hash Total/LO Cancel Fail.(959)")
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & ex.ToString)
                    oFile.Close()
                    MsgBox("Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Error: " & ex.ToString)
                    oleTrans.Rollback()
                    Exit Sub
                End Try

                '3.3.3 Move ชื่อไฟล์ดังนี้ ไป Path Backup โดยใช้สิทธิ์กลาง
                Dim pathFrom As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")
                Dim pathTo As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH_BACKUP")
                If (System.IO.Directory.Exists(pathFrom)) Then
                    Dim fileMoveLI, fFile As String
                    Dim di As New IO.DirectoryInfo(pathFrom)
                    Dim diar1 As IO.FileInfo() = di.GetFiles()
                    Dim dra As IO.FileInfo
                    '-- move file normal
                    For Each dra In diar1
                        fileMoveLI = cls.getFileMoveIL(oleConn, sysdate, dra.ToString) 'ต้อง query file มาเช็ค
                        If fileMoveLI <> "" Then
                            fFile = fileMoveLI.Substring(0, fileMoveLI.Length - 4)
                            '--My.Computer.FileSystem.MoveFile(cls.pathFrom(oleConn, fFile, pathFrom, fileMoveLI.Substring(fileMoveLI.IndexOf("."))), cls.pathTo(oleConn, fFile, pathTo, fileMoveLI.Substring(fileMoveLI.IndexOf("."))))
                            clsUtility.BackupFile(cls.pathFrom(oleConn, fFile, pathFrom, fileMoveLI.Substring(fileMoveLI.IndexOf("."))) _
                                               , cls.pathTo(oleConn, fFile, pathTo, fileMoveLI.Substring(fileMoveLI.IndexOf("."))) _
                                               )

                            Dim newFileNameTxt As String = clsGenPayment.getNewFilename(oleConn, fileMoveLI)
                            If newFileNameTxt <> "" Then
                                Dim newFileName As String = newFileNameTxt.Substring(0, newFileNameTxt.Length - 4)
                                Dim newFileNameCtrl As String = newFileName & ".ctrl"
                                If System.IO.File.Exists(pathFrom & newFileNameTxt) Then
                                    clsUtility.BackupFile(cls.pathFrom(oleConn, newFileName, pathFrom, ".txt"), cls.pathTo(oleConn, newFileName, pathTo, ".txt"))
                                End If
                                If System.IO.File.Exists(pathFrom & newFileNameCtrl) Then
                                    clsUtility.BackupFile(cls.pathFrom(oleConn, newFileName, pathFrom, ".ctrl"), cls.pathTo(oleConn, newFileName, pathTo, ".ctrl"))
                                End If
                            End If

                        End If
                    Next
                Else
                    cls.deletePayoutRejectLogByDate(oleConn, sysdate)
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Directory backup IL not create!, delete payment out reject log completed.")
                    oFile.Close()
                    MsgBox("Directory backup IL not create!, delete payment out reject log completed.")
                    Exit Sub
                End If
                '3.3.4 ทำการ Move รายการจ่ายจากถังจ่าย ไป ถัง Reject และ Clear ข้อมูลปลายทาง เพื่อ Generate ไฟล์ใหม่
                Try
                    Dim logID, logFileID, logFileDetailID, logFileTransFromID, callPayTobnkRej As Integer
                    Dim dtCallFileM, dtGenFile As DataTable
                    logID = cls.insertIntoILTLog(oleLog, sysdate, "Hash Total Error", "", "Running")
                    logFileID = cls.insertIntoILTLogFile(oleLog, logID, "Hash Total Error", "Running", "", "")
                    logFileDetailID = cls.insertIntoILTLogFileDetail(oleLog, logFileID, "Hash Total Error", "", "Generate File", "Running", "", "")
                    logFileTransFromID = cls.insertIntoILTLogTransForm(oleLog, logFileID, "Hash Total Error", "", "Generate File", "Running", "", "")

                    callPayTobnkRej = cls.CALL_il_sp_payout_tobank_rej(oleConn, logID, logFileTransFromID, sysdate)
                    If callPayTobnkRej = 0 Then

                        dtCallFileM = cls.getil_sp_payout_tobank_filenm_rej(oleConn, sysdate)
                        For Each rowFileM As DataRow In dtCallFileM.Rows
                            Dim recGen As Integer
                            recGen = cls.CALL_il_sp_payout_tobank_genfilerej(oleConn, rowFileM("FILE_NAME"), rowFileM("RUN_DATE"))
                            If recGen = 1 Then
                                dtGenFile = cls.getDataGenFile(oleConn, rowFileM("FILE_NAME"), rowFileM("RUN_DATE"))
                                'Write File
                                Dim resource As New StringBuilder
                                For Each rowGenFile As DataRow In dtGenFile.Rows
                                    'DATA_ROW
                                    resource.AppendLine(rowGenFile("DATA_ROW"))
                                Next rowGenFile
                                'Write TXT file

                                '---MsgBox("path : " & pathGenFile & vbCrLf & System.IO.Directory.Exists(pathGenFile).ToString)
                                '-- ORG 20210324 --
                                '    If (System.IO.Directory.Exists(pathGenFile.Replace("\\", "\"))) Then
                                '        System.IO.File.Delete(pathGenFile.Replace("\\", "\") & rowFileM("FILE_NAME").ToString)
                                '        Using writer As StreamWriter = New StreamWriter(pathGenFile.Replace("\\", "\") & rowFileM("FILE_NAME").ToString, True, Encoding.Default)
                                '            writer.Write(resource.ToString())
                                '        End Using

                                '        Dim fileName As String = clsGenPayment.getNewFilename(oleConn, rowFileM("FILE_NAME"))
                                '        Dim newfileName As String
                                '        Dim newFilenameTxt As String
                                '        newfileName = clsGenPayment.getPrefixFilename(oleConn) & clsGenPayment.getCoperateId(oleConn) & clsGenPayment.getBankCode(oleConn) & clsGenPayment.getFileType(oleConn) & clsGenPayment.getSysDateTime(oleConn)
                                '        newFilenameTxt = newfileName & ".txt"
                                '        System.IO.File.Copy(pathGenFile.Replace("\\", "\") & rowFileM("FILE_NAME"), pathGenFile.Replace("\\", "\") & newFilenameTxt, True)
                                '        Dim fs As FileStream = File.Create(pathGenFile.Replace("\\", "\") & newfileName & ".ctrl")
                                '        Dim info As Byte() = New UTF8Encoding(True).GetBytes(newFilenameTxt & ".gpg")
                                '        fs.Write(info, 0, info.Length)
                                '        fs.Close()
                                '        Dim otran As OleDbTransaction
                                '        otran = oleConn.BeginTransaction
                                '        Dim recx As Integer
                                '        If fileName = "" Then
                                '            recx = clsGenPayment.InsertMap(oleConn, otran, rowFileM("FILE_NAME"), newFilenameTxt)
                                '        Else
                                '            System.IO.File.Delete(pathGenFile.Replace("\\", "\") & fileName)
                                '            System.IO.File.Delete(pathGenFile.Replace("\\", "\") & fileName.Substring(0, fileName.Length - 4) & ".ctrl")
                                '            recx = clsGenPayment.UpdateMap(oleConn, otran, rowFileM("FILE_NAME"), newFilenameTxt)
                                '        End If

                                '        If recx = 1 Then
                                '            otran.Commit()
                                '        Else
                                '            otran.Rollback()
                                '        End If

                                '        System.Threading.Thread.Sleep(1000)

                                '    Else
                                '        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Directory not create!, " & vbCrLf & pathGenFile & vbCrLf & System.IO.Directory.Exists(pathGenFile))
                                '        MsgBox("Directory not create!" & vbCrLf & pathGenFile)
                                '    End If
                                '    cls.deleteDataGenFile(oleConn, rowFileM("FILE_NAME"), rowFileM("RUN_DATE"))
                                'End If
                                '-- ORG 20210324 --

                                '-- 1. check exists
                                '-- 2. delete exists
                                '-- 3. write
                                Dim strPathGenFileTemp As String = "D:\"

                                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : strPathGenFileTemp - D:\")

                                If (System.IO.Directory.Exists(strPathGenFileTemp.Replace("\\", "\"))) Then
                                    System.IO.File.Delete(strPathGenFileTemp.Replace("\\", "\") & rowFileM("FILE_NAME").ToString)

                                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Delete : " & strPathGenFileTemp.Replace("\\", "\") & rowFileM("FILE_NAME").ToString)

                                    Using writer As StreamWriter = New StreamWriter(strPathGenFileTemp.Replace("\\", "\") & rowFileM("FILE_NAME").ToString, True, Encoding.Default)
                                        writer.Write(resource.ToString())
                                    End Using

                                    Dim fileName As String = clsGenPayment.getNewFilename(oleConn, rowFileM("FILE_NAME"))
                                    Dim newfileName As String
                                    Dim newFilenameTxt As String
                                    newfileName = clsGenPayment.getPrefixFilename(oleConn) & clsGenPayment.getCoperateId(oleConn) & clsGenPayment.getBankCode(oleConn) & clsGenPayment.getFileType(oleConn) & clsGenPayment.getSysDateTime(oleConn)
                                    newFilenameTxt = newfileName & ".txt"
                                    System.IO.File.Copy(strPathGenFileTemp.Replace("\\", "\") & rowFileM("FILE_NAME"), strPathGenFileTemp.Replace("\\", "\") & newFilenameTxt, True)

                                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Genrate payment file completed --> " & strPathGenFileTemp.Replace("\\", "\") & newFilenameTxt)

                                    Dim fs As FileStream = File.Create(strPathGenFileTemp.Replace("\\", "\") & newfileName & ".ctrl")
                                    Dim info As Byte() = New UTF8Encoding(True).GetBytes(newFilenameTxt & ".gpg")
                                    fs.Write(info, 0, info.Length)
                                    fs.Close()

                                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Genrate ctrl file completed --> " & strPathGenFileTemp.Replace("\\", "\") & newfileName & ".ctrl")

                                    Dim otran As OleDbTransaction
                                    otran = oleConn.BeginTransaction
                                    Dim recx As Integer
                                    If fileName = "" Then
                                        recx = clsGenPayment.InsertMap(oleConn, otran, rowFileM("FILE_NAME"), newFilenameTxt)
                                    Else
                                        System.IO.File.Delete(strPathGenFileTemp.Replace("\\", "\") & fileName)
                                        System.IO.File.Delete(strPathGenFileTemp.Replace("\\", "\") & fileName.Substring(0, fileName.Length - 4) & ".ctrl")
                                        recx = clsGenPayment.UpdateMap(oleConn, otran, rowFileM("FILE_NAME"), newFilenameTxt)
                                    End If

                                    If recx = 1 Then
                                        otran.Commit()
                                        '-- move with scnyl
                                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Check file --> " & strPathGenFileTemp & newFilenameTxt & ".txt")
                                        If System.IO.File.Exists(strPathGenFileTemp & newFilenameTxt) Then
                                            If clsUtility.BackupFile(strPathGenFileTemp & newfileName & ".txt", pathFrom & newfileName & ".txt") Then

                                                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Move file completed --> " & pathFrom.Replace("\\", "\") & newfileName & ".txt")

                                            End If
                                            If clsUtility.BackupFile(strPathGenFileTemp.Replace("\\", "\") & rowFileM("FILE_NAME"), pathFrom & rowFileM("FILE_NAME")) Then
                                            End If
                                        End If
                                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Check file --> " & strPathGenFileTemp & newfileName & ".ctrl")
                                        If System.IO.File.Exists(strPathGenFileTemp & newfileName & ".ctrl") Then
                                            If clsUtility.BackupFile(strPathGenFileTemp & newfileName & ".ctrl", pathFrom & newfileName & ".ctrl") Then

                                                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Move file completed --> " & pathFrom.Replace("\\", "\") & newfileName & ".ctrl")

                                            End If
                                        End If
                                        '--
                                    Else
                                        otran.Rollback()
                                    End If

                                    System.Threading.Thread.Sleep(1000)

                                Else
                                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Directory not create!, " & vbCrLf & strPathGenFileTemp & vbCrLf & System.IO.Directory.Exists(strPathGenFileTemp))
                                    MsgBox("Directory not create!" & vbCrLf & strPathGenFileTemp)
                                End If
                                cls.deleteDataGenFile(oleConn, rowFileM("FILE_NAME"), rowFileM("RUN_DATE"))
                            End If

                        Next rowFileM

                        cls.updateIntoILTLog(oleConn, logID, "Complete")
                        cls.updateIntoILTLogFile(oleConn, logFileID, "Complete")
                        cls.updateIntoILTLogFileDetail(oleConn, logFileDetailID, "Complete")
                        cls.updateIntoILTLogTransForm(oleConn, logFileTransFromID, "Complete")

                    Else
                        '--MsgBox("Error2: CALL_il_sp_payout_tobank_rej")
                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Error by Hash Total/LO Cancel Fail.(1085)" & vbCrLf & "Error: CALL_il_sp_payout_tobank_rej")
                        oFile.Close()
                        MsgBox("Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Error: CALL_il_sp_payout_tobank_rej") '& vbCrLf & cls.str_Error_Message)
                        cls.updateIntoILTLog(oleConn, logID, "Error")
                        cls.updateIntoILTLogFile(oleConn, logFileID, "Error")
                        cls.updateIntoILTLogFileDetail(oleConn, logFileDetailID, "Error")
                        cls.updateIntoILTLogTransForm(oleConn, logFileTransFromID, "Error")
                        cls.deletePayoutRejectLogByDate(oleConn, sysdate)
                        Exit Sub
                    End If
                Catch ex As Exception
                    '--MsgBox("Error1: " & ex.ToString)
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Error by Hash Total/LO Cancel Fail.(1097)")
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & ex.ToString)
                    oFile.Close()
                    MsgBox("Reject Error by Hash Total/LO Cancel Fail." & vbCrLf & "Error: " & ex.ToString)
                    Exit Sub
                End Try

                '3.3.5 Regen Report ไปวางที่ Server (Outbound)
                Dim tempDir As String = "temp\"
                Dim aa As Integer
                If System.IO.Directory.Exists(tempDir) Then
                    '--System.IO.Directory.Delete(tempDir, True)
                    For Each foundFile As String In My.Computer.FileSystem.GetFiles(tempDir, FileIO.SearchOption.SearchTopLevelOnly, "*.*")
                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Delete --> " & foundFile)
                        File.Delete(foundFile)
                    Next
                Else
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Create Directory --> " & tempDir)
                    System.IO.Directory.CreateDirectory(tempDir)
                    For aa = 1 To 1000
                        Console.WriteLine(aa.ToString)
                    Next
                End If
                '----System.IO.Directory.CreateDirectory(tempDir)
                cls.genReportMNG(oleConn, sysdate, tempDir, sReportPath, False, dtPayoutGroupSetup)
                cls.genReportSUM(oleConn, sysdate, tempDir, sReportPath, False)

                For Each reportFilename As String In System.IO.Directory.GetFiles(tempDir)

                    '--MsgBox("check1: " & reportFilename & vbCrLf & "check2: " & pathLOReport & System.IO.Path.GetFileName(reportFilename))

                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport)

                    clsUtility.BackupFile(reportFilename, pathLOReport & System.IO.Path.GetFileName(reportFilename))
                Next
                cls.CALL_il_sp_payout_tobank_upd_prnflg(clsUtility.gConnGP, sysdate)

                '3.3.6 Gen Report Reject and Save เป็นไฟล์ Pdf to FA 
                'cls.genReportErrorbyHashTotalLO(oleConn, sysdate, pathLOReport, sReportPath, gUserFullName)
                '' ''If System.IO.Directory.Exists(tempDir) Then
                '' ''    System.IO.Directory.Delete(tempDir, True)
                '' ''End If
                '' ''System.IO.Directory.CreateDirectory(tempDir)
                If System.IO.Directory.Exists(tempDir) Then
                    '--System.IO.Directory.Delete(tempDir, True)
                    For Each foundFile As String In My.Computer.FileSystem.GetFiles(tempDir, FileIO.SearchOption.SearchTopLevelOnly, "*.*")
                        oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Delete --> " & foundFile)
                        File.Delete(foundFile)
                    Next
                Else
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Create Directory --> " & tempDir)
                    System.IO.Directory.CreateDirectory(tempDir)
                    For aa = 1 To 1000
                        Console.WriteLine(aa.ToString)
                    Next
                End If
                '----System.IO.Directory.CreateDirectory(tempDir)
                cls.genReportErrorbyHashTotalLO(oleConn, sysdate, tempDir, sReportPath, gUserFullName)
                For Each reportFilename As String In System.IO.Directory.GetFiles(tempDir)

                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File From : " & reportFilename & vbCrLf & " To : " & pathLOReport)

                    clsUtility.BackupFile(reportFilename, pathReport & System.IO.Path.GetFileName(reportFilename))
                Next

                '-- Gen error log --
                If sDataExist.ToString.Split(vbCrLf).Length > 1 Or LO_Dup.ToString.Split(vbCrLf).Length > 3 Then

                    '--Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
                    System.IO.File.Create(pathReport & "Integral Life_LOCANCAL_CC" & strCurrentDate & "001.txt").Dispose()
                    Dim oFileError As New System.IO.StreamWriter(pathReport & "Integral Life_LOCANCAL_CC" & strCurrentDate & "001.txt", True)
                    '-- กรณีมีข้อมูล duplicate old data
                    If sDataExist.ToString.Split(vbCrLf).Length > 1 Then
                        oFileError.WriteLine("Duplicate Old data!!")
                        oFileError.WriteLine("====================")
                        oFileError.WriteLine(sDataExist.ToString.Replace(vbCrLf, " " & vbCrLf))
                        oFileError.WriteLine(" ")
                    End If
                    '--
                    '-- กรณีมีข้อมูล duplicate
                    If LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
                        oFileError.WriteLine("Duplicate in excel file / Excel format error !!")
                        oFileError.WriteLine("===============================================")
                        oFileError.WriteLine(LO_Dup.ToString.Replace(vbCrLf, " " & vbCrLf))
                    End If
                    oFileError.Close()
                End If
                '--


                '3.3.7 Move ไฟล์ LO Cancel ไป Backup โดยใช้สิทธิ์กลาง
                Dim pathFromLO As String = clsBusiness.fnGet_pathconfig(oleConn, "LOCANCELFILE_PATH")
                Dim pathToLO As String = clsBusiness.fnGet_pathconfig(oleConn, "CANCELPAYMTH_IL_PATH_BACKUP")
                If (System.IO.Directory.Exists(pathFromLO)) Then
                    Dim fileMoveLO, fFile As String
                    Dim diLO As New IO.DirectoryInfo(pathFromLO)
                    Dim diarLO As IO.FileInfo() = diLO.GetFiles()
                    Dim draLO As IO.FileInfo
                    '--Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
                    For Each draLO In diarLO
                        fileMoveLO = cls.getFileMoveLO(oleConn, sysdate, draLO.ToString)
                        If fileMoveLO <> "" Then
                            fFile = fileMoveLO.Substring(0, fileMoveLO.IndexOf(".")) ' only name not use ".xls"
                            '-- My.Computer.FileSystem.MoveFile(cls.pathFrom(oleConn, fFile, pathFromLO, fileMoveLO.Substring(fileMoveLO.IndexOf("."))), cls.pathTo(oleConn, fFile, pathToLO, fileMoveLO.Substring(fileMoveLO.IndexOf(".")))) 'Move file test 
                            '-- clsUtility.BackupFile(cls.pathFrom(oleConn, fFile, pathFromLO), cls.pathTo(oleConn, fFile, pathToLO))
                            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File (3.3.7 LO) --> " & fileMoveLO & vbCrLf & " To --> " & pathToLO)
                            clsUtility.BackupFile(cls.pathFrom(oleConn, fFile, pathFromLO, fileMoveLO.Substring(fileMoveLO.IndexOf("."))), cls.pathTo(oleConn, fFile, pathToLO, fileMoveLO.Substring(fileMoveLO.IndexOf("."))))
                        End If
                    Next
                    '-- move file format error
                    diarLO = diLO.GetFiles()
                    fFile = ""
                    For Each draLO In diarLO
                        fFile = draLO.Name
                        '--If fFile.Contains("_FORMAT_ERROR") Then
                        '--    clsUtility.BackupFile(pathFromLO & fFile, pathToLO & fFile)
                        '--End If
                        If fFile.Contains(strCurrentDate) Then
                            oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Backup File (3.3.7 format error) --> " & pathFromLO & fFile & vbCrLf & " To --> " & pathToLO)
                            clsUtility.BackupFile(pathFromLO & fFile, pathToLO & fFile)
                        End If
                    Next
                    '--
                Else
                    oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : Directory backup LO Cancle not create!, --> " & pathFromLO)
                    MsgBox("Directory backup LO Cancle not create!" & vbCrLf & pathFromLO)
                End If

                '3.3.8 Automatic Send Mail
                Dim dtMail As DataTable
                Dim smtp, subJect, bodyMail, Username, Password, mailResult As String
                Dim sbEmail As New StringBuilder

                bodyMail = "พบข้อมูลรายการจ่ายของ Integral Life ไม่ถูกต้อง (Error by Hash Total/LO Cancel) รบกวนตรวจสอบที่ path : " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                bodyMail = "GPSA : Integral Life payment transaction error by Hash total/LO Cancel. Please check report -> " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")

                If dgvFile.RowCount > 0 And dgvLo.RowCount > 0 Then '-- Hash + LO
                    '-- bodyMail = "มีการยกเลิกรายการจ่าย Hash Error และมีการยกเลิกรายการจ่ายจาก Integral Life กรุณาตรวจสอบที่ path : " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                    bodyMail = "GPSA : Integral Life payment transaction error by Hash total and LO Cancel. Please check report -> " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                ElseIf dgvFile.RowCount > 0 And dgvLo.RowCount = 0 Then '-- Hasd only
                    '-- bodyMail = "มีการยกเลิกรายการจ่าย Hash Error"
                    bodyMail = "GPSA : Integral Life payment transaction error by Hash total. Please check report -> " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                Else '-- LO only
                    '--bodyMail = "มีการยกเลิกรายการจ่ายจาก Integral Life กรุณาตรวจสอบที่ path : " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                    bodyMail = "GPSA : LO Cancel. Please check report -> " & pathLOReport.Replace("\\", "\") 'clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
                End If

                '-- กรณีมีข้อมูล duplicate old data
                If sDataExist.ToString.Split(vbCrLf).Length > 1 Then
                    bodyMail = bodyMail & vbCrLf & vbCrLf & vbCrLf & "Duplicate Old data!!"
                    bodyMail = bodyMail & vbCrLf & "===================="
                    bodyMail = bodyMail & vbCrLf & sDataExist.ToString.Replace(vbCrLf, " " & vbCrLf)
                End If
                '--
                '-- กรณีมีข้อมูล duplicate
                If LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
                    bodyMail = bodyMail & vbCrLf & vbCrLf & vbCrLf & "Duplicate in excel file / Excel format error !!"
                    bodyMail = bodyMail & vbCrLf & "==============================================="
                    bodyMail = bodyMail & vbCrLf & LO_Dup.ToString.Replace(vbCrLf, " " & vbCrLf)
                End If
                '--

                subJect = "Reject Payment Transaction (Integral Life) [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")

                '--------------------------------
                '--    Email subject & body    --
                '--------------------------------
                '-- Check LO cancel file exist --
                '--------------------------------
                subJect = ""
                bodyMail = ""
                If dgvFile.RowCount > 0 Then
                    If (sDataExist.ToString.Split(vbCrLf).Length <= 1) And (LO_Dup.ToString.Split(vbCrLf).Length <= 3) Then
                        subJect = "Complete: Integral Life cancel payment transaction (Hash Error & LO Cancel)"
                        bodyMail = "Please check complete report in path ==> " & pathReport.Replace("\\", "\")
                    Else
                        subJect = "Uncompleted: Integral Life cancel payment transaction (Hash Error & LO Cancel)"
                        bodyMail = "Please check uncomplete report in path ==> " & pathReport.Replace("\\", "\")
                    End If
                Else
                    subJect = "No data cancel : Integral Life cancel payment transaction (Hash Error & LO Cancel)"
                    bodyMail = "No data cancel"
                End If

                '-- Email to 
                smtp = cls.getMailSmtp(oleConn)
                dtMail = cls.getEmail(oleConn, "ERR_BY_HASH_IL")
                For Each rowMail As DataRow In dtMail.Rows
                    sbEmail.Append(rowMail("email_address"))
                    sbEmail.Append(";")
                Next
                mailResult = cls.SendEmail("SystemGPSA@scblife.com", sbEmail.ToString, subJect, bodyMail, Username, Password, smtp, 25, Nothing)

                clearScreen()
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : " & "Reject Completed.")
                oFile.Close()
                MsgBox("Reject Complete.")
            Else
                oFile.WriteLine(Now.ToString("yyyy-MM-dd HH:MM:ss") & " : มีการ Reject รายการจ่าย IL ในวันนี้แล้ว ไม่สามารถ Reject ซ้ำได้...")
                MsgBox("มีการ Reject รายการจ่าย IL ในวันนี้แล้ว ไม่สามารถ Reject ซ้ำได้...")
            End If
            'Else
            'MsgBox("ไม่มีข้อมูลสำหรับ Reject")
            'End If
        End If
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        clearScreen()

        'Dim strTemp As New StringBuilder
        'Dim strT As String
        'With strTemp
        '    .Append("Line 1").AppendLine()
        '    .Append("Line 2").AppendLine()
        '    .Append("Line 3").AppendLine()
        '    strT = strTemp.ToString
        '    MsgBox(strT)
        '    MsgBox(strTemp.ToString)
        '    .Append("Line 4" & vbCrLf)
        '    .Append("Line 5" & vbCrLf)
        '    .Append("Line 6" & vbCrLf)
        '    strT = strTemp.ToString
        '    MsgBox(strT)
        '    .Append("Line 7")
        '    .Append("Line 8")
        '    .Append("Line 9")
        '    strT = strTemp.ToString
        '    MsgBox(strT)
        '    MsgBox(strTemp.ToString)
        'End With

    End Sub

    Private Function checkDuplicateList(ByVal alist As List(Of String), ByVal compareStr As String) As Integer
        Dim i As Integer = 0
        Dim str As String
        For Each str In alist
            If str = compareStr Then
                i = 1
                Exit For
            End If
        Next

        checkDuplicateList = i

    End Function

    Sub clearScreen()
        TextBox2.Clear()
        txtTotalAmtIL.Clear()
        txtTotalAmtLO.Clear()
        dgvFile.Columns.Clear()
        dgvLo.Columns.Clear()
    End Sub

    Private Sub btnConfrim_Click(sender As System.Object, e As System.EventArgs) Handles btnConfirm.Click
        If MessageBox.Show("Confirm Auto FTP [y/n] ?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            Exit Sub
        Else
            Dim oleConn As OleDbConnection
            oleConn = clsUtility.gConnGP
            Dim path As String = cls.getFtpPath(oleConn)
            Dim outputPath As String = cls.getOutputPath(oleConn)
            Dim ctrlPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")
            Dim importDate As String = cls.getImportDate(oleConn)
            Dim importRound As String = cls.getImportRound(oleConn)
            Dim fileName As String = "ILAuto" & "_" & importDate & "_" & importRound.PadLeft(2, "0")
            Dim tempDir As String = "temp\"
            If System.IO.Directory.Exists(tempDir) Then
                System.IO.Directory.Delete(tempDir, True)
            End If
            System.IO.Directory.CreateDirectory(tempDir)
            Dim fs As FileStream = File.Create(tempDir & fileName & ".txt")
            Dim dt As DataTable
            dt = cls.getOutputFileName(oleConn)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim sb As New StringBuilder
                Dim outputFilename As String
                Dim outputFilenameCtrl As String
                For Each row As DataRow In dt.Rows
                    outputFilename = row("PAYM_FILENAME_OUT_TOBANK").ToString()
                    outputFilenameCtrl = outputFilename.Substring(0, outputFilename.IndexOf(".")) & ".ctrl"
                    sb.AppendLine(outputFilename)
                    sb.AppendLine(outputFilenameCtrl)
                    clsUtility.BackupFile(outputPath & outputFilename, path & outputFilename)
                    clsUtility.BackupFile(ctrlPath & outputFilenameCtrl, path & outputFilenameCtrl)
                Next
                Dim info As Byte() = New UTF8Encoding(True).GetBytes(sb.ToString())
                fs.Write(info, 0, info.Length)
                fs.Close()
                clsUtility.BackupFile(tempDir & fileName & ".txt", path & fileName & ".txt")
                btnConfirm.Enabled = False
                MsgBox("Confirm already.", MsgBoxStyle.Information)
            Else
                fs.Close()
                fs = Nothing
                dt = Nothing
                MsgBox("Payment file not found", MsgBoxStyle.Exclamation)
            End If

        End If
    End Sub

    Private Sub btnAuto_Click(sender As System.Object, e As System.EventArgs) Handles btnAuto.Click
        Dim oleConn As OleDbConnection
        Dim oleTrans As OleDbTransaction
        Dim oleTransDelete1 As OleDbTransaction
        Dim oleTransDelete2 As OleDbTransaction
        Dim oleConnSelect As OleDbConnection
        Dim sysdate As String = cls.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")
        Dim sFileNameFrom As String
        Dim sFileNameTo As String

        oleConn = clsUtility.gConnGP
        Dim pathLO As String = clsBusiness.fnGet_pathconfig(oleConn, "LOCANCELFILE_PATH")
        TextBox2.Text = pathLO

        oleConnSelect = clsUtility.gConnGP_2

        oleTransDelete1 = oleConn.BeginTransaction

        cls.deleteFromPayoutTempReject(oleConn, oleTransDelete1)
        oleTransDelete1.Commit()

        oleTrans = oleConn.BeginTransaction
        Dim file() As String
        Dim dt As DataTable
        Dim dtDup As DataTable

        Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
        Dim fullpathfile = String.Join(",", Directory.GetFiles(pathLO, "*" & strCurrentDate & "*.xls")) 'fullpathfile2,fullpathfile2

        Dim custOld, custNew As String
        Dim sb As New StringBuilder
        Dim custDup As New StringBuilder
        Dim intCheckPaymentAndAmount As Integer

        LO_Dup.Clear()
        LO_Dup.Append("File Name         |PaymentNo|Amount").AppendLine()
        LO_Dup.Append("-----------------------------------").AppendLine()

        ' Read excel file and insert into PAYOUT_TMP_REJECT
        Dim xlApp As Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet

        Try
            Dim countFile, count, countInsert, countDup As Integer
            countFile = 0
            count = 0
            countInsert = 0
            countDup = 0
            Dim payNo, payMth, bnkCde, accNo, amt, payDate, reasonOfReverse, fileName, payDateInsert As String
            ' Split string based on spaces.
            Dim words As String() = fullpathfile.Split(New Char() {","c})
            ' Use For Each loop over words and display them.
            Dim word As String
            For Each word In words

                fileName = Path.GetFileName(word)

                If fileName.ToString.Contains(strCurrentDate) = False Then
                    Continue For
                End If

                xlApp = New Excel.Application
                xlWorkBook = xlApp.Workbooks.Open(word)
                xlWorkSheet = xlWorkBook.Worksheets(1)

                'Check name
                If Trim(xlWorkSheet.Cells(2, 1).value()).Equals("Payment Number") And _
                    Trim(xlWorkSheet.Cells(2, 2).value()).Equals("Payment Method " & vbLf & "(D/C/M)") And _
                    Trim(xlWorkSheet.Cells(2, 3).value()).Equals("Bank Code") And _
                    Trim(xlWorkSheet.Cells(2, 4).value()).Equals("Account Number") And _
                    Trim(xlWorkSheet.Cells(2, 5).value()).Equals("Amount") And _
                    Trim(xlWorkSheet.Cells(2, 6).value()).Equals("Payment Date" & vbLf & "(dd/mm/yyyy)" & vbLf & "(yyyy-คศ.)") And _
                    Trim(xlWorkSheet.Cells(2, 7).value()).Equals("Reason of Reverse") Then


                    '-----------------------
                    '-- Check file format --
                    '-----------------------
                    Dim row As Integer = 3
                    Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing
                        payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                        payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                        bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                        accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                        amt = xlWorkSheet.Cells(row, 5).value & "" 'column 5
                        payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                        reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7
                        If Not (payMth.ToString.Contains("C") Or payMth.ToString.Contains("D") Or payMth.ToString.Contains("M")) _
                            Or Not IsDate(payDate) _
                            Or Not IsNumeric(amt) _
                            Or payDate.Length <> 10 Then

                            xlWorkBook.Close()
                            'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".")(0).ToString & "_reject." & word.ToString.Split(".")(1).ToString)
                            sFileNameFrom = word.ToString
                            sFileNameTo = Path.GetDirectoryName(word.ToString) & "\" & Path.GetFileNameWithoutExtension(word.ToString) & "_FORMAT_ERROR" & Path.GetExtension(word.ToString)
                            '--If cls.RenameFile_RejectByFile(word.ToString) <> "-1" Then
                            If cls.RenameFileFormatError(oleConn, sFileNameFrom, Path.GetDirectoryName(word.ToString), Path.GetExtension(word.ToString).Replace(".", "")) Then
                                LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                            Else
                                xlApp.Quit()
                                releaseObject(xlApp)
                                releaseObject(xlWorkBook)
                                releaseObject(xlWorkSheet)
                                oleTrans.Rollback()
                                MsgBox("ไม่สามารถ Rename Reject File, กรุณาติดต่อผู้ดูแลระบบ", MsgBoxStyle.Critical)
                                Exit Try
                            End If
                            Continue For
                        End If
                        row = row + 1
                    Loop

                    '------------------------------
                    '-- Check duplicate same day --
                    '------------------------------
                    row = 3
                    Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing

                        'payNo = xlWorkSheet.Cells(row, 1).value 'column 1
                        'payMth = xlWorkSheet.Cells(row, 2).value 'column 2
                        'bnkCde = xlWorkSheet.Cells(row, 3).value 'column 3
                        'accNo = xlWorkSheet.Cells(row, 4).value 'column 4
                        'amt = xlWorkSheet.Cells(row, 5).value 'column 5
                        'payDate = xlWorkSheet.Cells(row, 6).value 'column 6
                        'reasonOfReverse = xlWorkSheet.Cells(row, 7).value 'column 7

                        payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                        payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                        bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                        accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                        amt = xlWorkSheet.Cells(row, 5).value 'column 5
                        payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                        reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7

                        payDateInsert = payDate.Substring(6, 4) & payDate.Substring(3, 2) & payDate.Substring(0, 2)

                        Dim rec As Integer = cls.insertIntoPayoutTempReject(oleConn, oleTrans, sysdate, fileName, reasonOfReverse, payMth, bnkCde, _
                                                       accNo, payNo, amt, "", payDateInsert)

                        If countDup > 0 Then
                            custDup.Append(",")
                        End If
                        If rec = -1 Then
                            custDup.Append(payNo)
                            LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Duplicated").AppendLine()
                            countDup = countDup + 1
                        Else

                            'cls.deletePayoutTempRejectByFileName(oleConn, oleTransDelete2, fileName)
                            'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".").ToString & "_reject." & word.ToString.Split(".").ToString)
                            'LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                            intCheckPaymentAndAmount = 0
                            intCheckPaymentAndAmount = cls.CheckLOInvalidPaymentAndAmount(oleConnSelect, strCurrentDate, payNo, payMth, CDbl(amt))
                            Select Case intCheckPaymentAndAmount
                                Case 0 '-- valid
                                    '-- no action
                                Case 1 '-- invalid payment number / Payment number not found      
                                    LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Payment number not found").AppendLine()
                                Case 2 '-- invalid payment method      
                                    LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method").AppendLine()
                                Case 3 '-- invalid payment amount
                                    LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment amount").AppendLine()
                                Case 4 '-- invalid 1 & 2
                                    LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method and amount").AppendLine()
                                Case Else '-- unknow error
                                    LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid other condition").AppendLine()
                            End Select
                        End If

                        count = count + 1
                        row += 1
                    Loop

                Else
                    MsgBox("รูปแบบไฟล์ไม่ถูกต้อง")

                    xlWorkBook.Application.DisplayAlerts = False

                    xlWorkBook.Close()
                    xlApp.Quit()

                    releaseObject(xlApp)
                    releaseObject(xlWorkBook)
                    releaseObject(xlWorkSheet)

                    oleTrans.Rollback()

                    Exit Sub
                End If

                xlWorkBook.Application.DisplayAlerts = False

                xlWorkBook.Close()
                xlApp.Quit()

                releaseObject(xlApp)
                releaseObject(xlWorkBook)
                releaseObject(xlWorkSheet)

                countFile = countFile + 1
            Next

            oleTrans.Commit()

        Catch ex As Exception
            xlWorkBook.Close()
            xlApp.Quit()

            releaseObject(xlApp)
            releaseObject(xlWorkBook)
            releaseObject(xlWorkSheet)
            MsgBox(ex.ToString)
            oleTrans.Rollback()
            Exit Sub
        End Try

        'xxx Delete Dupicate payment no
        Dim iTemp As Integer

        dtDup = cls.CheckDuplicatePayoutRejLog(oleConn)
        sDataExist.Clear()
        If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Then
            For Each row As DataRow In dtDup.Rows
                sb.Append("'")
                sb.Append(row.Item(0))
                sb.Append("'")
                sDataExist.Append(row.Item(1).ToString & "" & "|" & row.Item(0).ToString & "" & "| Data exist!").AppendLine()
            Next
            oleTransDelete2 = oleConn.BeginTransaction
            Try
                cls.deletePayoutTempRejectByCustref(oleConn, oleTransDelete2, custDup.ToString)
                oleTransDelete2.Commit()
            Catch ex As Exception
                oleTransDelete2.Rollback()
            End Try
            MsgBox("Duplicate old data!" & vbCrLf & vbCrLf & sDataExist.ToString)
        End If

        If LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
            MsgBox("Duplicate in excel file / Excel format error !!" & vbCrLf & vbCrLf & LO_Dup.ToString)
        End If


        'If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Or custDup.Length > 0 Then

        '    '---------------------------------------------------------------'
        '    '-- pongpipat -- ขั้นตอนก่อนหน้านี้ ไม่สามารถ insert ได้ ดังนั้นต้องไม่ delete  
        '    '---------------------------------------------------------------'
        '    'If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Then
        '    '    Dim i As Integer = 0
        '    '    For Each row As DataRow In dtDup.Rows
        '    '        sb.Append("'")
        '    '        sb.Append(row.Item(0))
        '    '        sb.Append("'")
        '    '        If i > 0 Then
        '    '            sb.Append(",")
        '    '        End If
        '    '        i = i + 1
        '    '    Next
        '    '    oleTransDelete2 = oleConn.BeginTransaction
        '    '    Try
        '    '        cls.deletePayoutTempRejectByCustref(oleConn, oleTransDelete2, custDup.ToString)
        '    '        oleTransDelete2.Commit()
        '    '    Catch ex As Exception
        '    '        oleTransDelete2.Rollback()
        '    '    End Try
        '    '    
        '    'End If
        '    '---------------------------------------------------------------'

        '    '-- MsgBox("มีข้อมูล Dup ในไฟล์ : " & custDup.ToString & vbLf & "มีข้อมูล Dup ตาราง" & sb.ToString)
        '    MsgBox("มีข้อมูลซ้ำ / Format error !!" & vbCrLf & LO_Dup.ToString)
        'ElseIf LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
        '    MsgBox("มีข้อมูลซ้ำ / Format error !!" & vbCrLf & LO_Dup.ToString)
        'End If

        dt = cls.generateDataForHashTotalLo(oleConn, sysdate)
        GenGridLO(dt)

        Dim sumAmt As Double
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            For Each rowSum As DataRow In dt.Rows
                sumAmt = sumAmt + rowSum("payd_3_c_amt_num")
            Next
        End If

        txtTotalAmtLO.Text = sumAmt.ToString("F", CultureInfo.InvariantCulture)
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As System.EventArgs) Handles BtnCancel.Click
        If MessageBox.Show("Cancel Auto FTP [y/n] ?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            Exit Sub
        Else
            Dim oleConn As OleDbConnection
            oleConn = clsUtility.gConnGP
            Dim path As String = cls.getFtpPath(oleConn)
            Dim importDate As String = cls.getImportDate(oleConn)
            Dim importRound As String = cls.getImportRound(oleConn)
            Dim fileNameIL As String = "ILAuto" & "_" & importDate & "_" & importRound.PadLeft(2, "0")
            Dim pathTo As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH_BACKUP")
            Dim dt As DataTable
            dt = cls.getOutputFileName(oleConn)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim outputFilename As String
                For Each row As DataRow In dt.Rows
                    outputFilename = row("PAYM_FILENAME_OUT_TOBANK").ToString().Substring(0, row("PAYM_FILENAME_OUT_TOBANK").ToString().IndexOf("."))
                    clsUtility.BackupFile(cls.pathFrom(oleConn, outputFilename, path, ".txt"), cls.pathTo(oleConn, outputFilename, pathTo, ".tx_"))
                    clsUtility.BackupFile(cls.pathFrom(oleConn, outputFilename, path, ".ctrl"), cls.pathTo(oleConn, outputFilename, pathTo, ".ct_"))
                Next
            End If
            clsUtility.BackupFile(cls.pathFrom(oleConn, fileNameIL, path, ".txt"), cls.pathTo(oleConn, fileNameIL, pathTo, ".tx_"))
            MsgBox("Cancel Auto FTP Complete", MsgBoxStyle.Information)
        End If
    End Sub
End Class