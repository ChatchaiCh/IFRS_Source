﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.IO
Imports System.Globalization
Imports Microsoft.Office.Interop
Imports System.Configuration

Public Class FrmHashTotalError
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Dim cls As New ClsGeneratePaymentFile
    Dim clsRpt As New ClsReport
    Dim clsWht As New ClsWHT
    Dim clsLog As New ClsLog
    Dim clsHashLO As New ClsHashTotalErrorLOCancel
    Dim LO_Dup As New StringBuilder
    Dim sDataExist As New StringBuilder

    Private Sub FrmHashTotalError_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        My.Application.ChangeCulture("en-GB")
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        If clsUtility.gConnGP_2.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP_2 = False Then
                Cursor = Cursors.Default
                MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If

        'Dim sysdate As String = Now.ToString("yyMMdd")
        'Dim fPath, fFile As String
        'fPath = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")
        ''fPath = "\\10.21.213.1\temp\GPSA\Poom\Source_PC\Outbound\" 'test
        'Dim di As New IO.DirectoryInfo(fPath)
        'Dim diar1 As IO.FileInfo() = di.GetFiles()
        'Dim dra As IO.FileInfo

        ''list the names of all files in the specified directory 150615
        'ComboBoxFile.Items.Add("File Name")
        'For Each dra In diar1
        '    If dra.ToString.Substring(0, 1) = "S" And dra.ToString.Substring(1, 6) = sysdate Then
        '        fFile = dra.ToString.Substring(0, dra.ToString.Length - 4)
        '        ComboBoxFile.Items.Add(fFile)
        '    End If
        'Next

        refreshFilenameCombo()

        InitializeOpenFileDialog()

    End Sub

    Private Sub refreshFilenameCombo()
        Dim dt As DataTable = New DataTable()
        dt = clsHashLO.getFileNameCombo(clsUtility.gConnGP)
        ComboBoxFile.DisplayMember = "TEXT"
        ComboBoxFile.ValueMember = "VALUE"
        ComboBoxFile.DataSource = dt
    End Sub

    Private Sub GenGridFile()

        With dgvfile

            '.DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvfile.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cfileName
            .DataPropertyName = "fileName"
            .Name = "ชื่อไฟล์"
            .Width = 250
            .ReadOnly = True
            dgvfile.Columns.Add(cfileName)

        End With

        Dim clineNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With clineNo
            .DataPropertyName = "lineNo"
            .Name = "Line No"
            .Width = 75
            .ReadOnly = True
            dgvfile.Columns.Add(clineNo)
        End With

        Dim cBankacc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankacc
            .DataPropertyName = "bankacc"
            .Name = "Bank Account"
            .Width = 180
            .ReadOnly = True
            dgvfile.Columns.Add(cBankacc)
        End With

        Dim cCustRefNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCustRefNo
            .DataPropertyName = "custrefno"
            .Name = "Cust Ref No"
            .Width = 180
            .ReadOnly = True
            dgvfile.Columns.Add(cCustRefNo)
        End With

        Dim cOldFileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cOldFileName
            .DataPropertyName = "oldFileName"
            .Name = "ชื่อไฟล์"
            .Width = 250
            .ReadOnly = True
            .Visible = False
            dgvfile.Columns.Add(cOldFileName)

        End With

    End Sub

    Private Sub GenGridPayment(ByVal dt As DataTable)

        With dgvPayment

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvPayment.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cCreatedate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCreatedate
            .ReadOnly = True
            .DataPropertyName = "CREATEDATE"
            .Name = "GP_CREATEDATE"
            .Width = 120
            dgvPayment.Columns.Add(cCreatedate)

        End With

        Dim cCoreSystem As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCoreSystem
            .ReadOnly = True
            .DataPropertyName = "CORE_SYSTEM"
            .Name = "CORE_SYSTEM"
            .Width = 100
            dgvPayment.Columns.Add(cCoreSystem)
        End With

        Dim cTransref As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cTransref
            .ReadOnly = True
            .DataPropertyName = "TRANSREF"
            .Name = "GP_TRANSREF"
            .Width = 150
            dgvPayment.Columns.Add(cTransref)
        End With

        Dim cLine As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cLine
            .ReadOnly = True
            .DataPropertyName = "GP_LINE"
            .Name = "GP_LINE"
            .Width = 100
            dgvPayment.Columns.Add(cLine)
        End With

        Dim cPolno As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPolno
            .ReadOnly = True
            .DataPropertyName = "POLNO"
            .Name = "GP_POLNO"
            .Width = 100
            dgvPayment.Columns.Add(cPolno)
        End With

        Dim cPaydesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPaydesc
            .ReadOnly = True
            .DataPropertyName = "PAYDESC"
            .Name = "GP_PAYDESC"
            .Width = 100
            dgvPayment.Columns.Add(cPaydesc)
        End With

        Dim cBnkcode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkcode
            .ReadOnly = True
            .DataPropertyName = "BANKCODE"
            .Name = "GP_BNKCODE"
            .Width = 100
            dgvPayment.Columns.Add(cBnkcode)
        End With

        Dim cBankaccno As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankaccno
            .ReadOnly = True
            .DataPropertyName = "BANK_ACCNO"
            .Name = "BANK_ACCNO"
            .Width = 100
            dgvPayment.Columns.Add(cBankaccno)
        End With

        Dim cBankaccname As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBankaccname
            .ReadOnly = True
            .DataPropertyName = "BANK_ACCNAME"
            .Name = "BANK_ACCNAME"
            .Width = 150
            dgvPayment.Columns.Add(cBankaccname)
        End With

        Dim cAmount As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmount
            .ReadOnly = True
            .DataPropertyName = "AMOUNT"
            .Name = "GP_AMOUNT"
            .Width = 100
            dgvPayment.Columns.Add(cAmount)
        End With

        Dim cPaidate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPaidate
            .ReadOnly = True
            .DataPropertyName = "GP_PAIDDATE"
            .Name = "GP_PAIDATE"
            .Width = 100
            dgvPayment.Columns.Add(cPaidate)
        End With

        Dim cCONFIRMDATE As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cCONFIRMDATE
            .ReadOnly = True
            .DataPropertyName = "CONFIRMDATE"
            .Name = "CONFIRMDATE"
            .Width = 100
            dgvPayment.Columns.Add(cCONFIRMDATE)
        End With

        Dim cEXPORTFILENAME As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cEXPORTFILENAME
            .ReadOnly = True
            .DataPropertyName = "GP_EXPTOBANK_FILENME"
            .Name = "GP_EXPTOBANK_FILENME"
            .Width = 100
            dgvPayment.Columns.Add(cEXPORTFILENAME)
        End With

        Dim cREJECT_TYPE As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cREJECT_TYPE
            .ReadOnly = True
            .DataPropertyName = "REJECT_TYPE"
            .Name = "REJECT TYPE"
            .Width = 100
            dgvPayment.Columns.Add(cREJECT_TYPE)
        End With

        Dim cREJECT_REASON As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cREJECT_REASON
            .ReadOnly = True
            .DataPropertyName = "REJECT_REASON"
            .Name = "REJECT REASON"
            .Width = 100
            dgvPayment.Columns.Add(cREJECT_REASON)
        End With

        Dim cREJECT_GROUP As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cREJECT_GROUP
            .ReadOnly = True
            .DataPropertyName = "REJECT_GROUP"
            .Name = "REJECT GROUP"
            .Width = 100
            dgvPayment.Columns.Add(cREJECT_GROUP)
        End With

        dgvPayment.Columns(11).Visible = False

    End Sub

    Private Sub btnAddfile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddfile.Click

        If dgvfile.RowCount <= 0 Then
            GenGridFile()
        End If
        Try

            Dim path, filename, line, pathfilename, bankAcc, custRefno, oldFilename, filenameValue As String

            path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")
            'path = "\\10.21.213.1\temp\GPSA\Poom\Source_PC\Outbound\" 'test

            Dim strfrom, strto, newlineno As Integer
            newlineno = 1
            strfrom = 10
            strto = 34
            filenameValue = ComboBoxFile.SelectedValue.ToString()
            filename = filenameValue.Substring(filenameValue.IndexOf("|") + 1)
            oldFilename = filenameValue.Substring(0, filenameValue.IndexOf("|"))
            line = txtLine.Text
            pathfilename = path & oldFilename & ".txt"
            ' Split string based on spaces.
            Dim words As String() = line.Split(New Char() {","c})
            ' Use For Each loop over words and display them.
            Dim word As String
            For Each word In words
                'Read file string aray 
                Dim lines As String() = IO.File.ReadAllLines(pathfilename)
                Dim rs As String = lines(word - 1)
                bankAcc = rs.Substring(9, 24)
                custRefno = rs.Substring(259, 16)
                ''Add row
                Dim row As String() = New String() {filename, word, bankAcc, custRefno, oldFilename}
                dgvfile.Rows.Add(row)
            Next

            ComboBoxFile.SelectedIndex = 0
            txtLine.Clear()
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        Dim fileName, fileNameOld As String
        Dim accountNumber, accountNumber2, custref2, cusRefNo, cusRefNoOld As String
        Dim sbFilename, sbAcc, sCusRefNo, sbCusRefno As New StringBuilder
        Dim sbCustRef2, sbAcc2 As New StringBuilder
        Dim dt As DataTable

        If dgvfile.RowCount = 0 And dgvReject.RowCount = 0 Then
            MsgBox("กรุณาระบุรายการที่ต้องยกเลิก", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        For index As Integer = 0 To dgvfile.RowCount - 1

            Dim cfile As String = dgvfile.Rows(index).Cells(4).Value.ToString
            Dim cLine As String = dgvfile.Rows(index).Cells(1).Value.ToString
            Dim cBnkacc As String = dgvfile.Rows(index).Cells(2).Value.ToString
            Dim cCusRefNo As String = dgvfile.Rows(index).Cells(3).Value.ToString

            ' Format like file search in (^S15070201M52$|^S15070201M51$)
            If cfile <> fileNameOld Then
                sbFilename.Append("^")
                sbFilename.Append(cfile.Trim)
                sbFilename.Append("$")
                sbFilename.Append("|")

                fileNameOld = cfile
            End If

            If cCusRefNo <> cusRefNoOld Then
                sbCusRefno.Append("^")
                sbCusRefno.Append(cCusRefNo.Trim)
                sbCusRefno.Append("$")
                sbCusRefno.Append("|")

                cusRefNoOld = cCusRefNo
            End If

            ' Format like account search in ('1111111111','2222222222')
            sbAcc.Append("'")
            sbAcc.Append(cBnkacc.Trim)
            sbAcc.Append("',")

        Next
        If sbFilename.Length > 0 Then
            'Cut "|" in last string index
            fileName = sbFilename.ToString().Substring(0, sbFilename.ToString().Length - 1)
            'Cut "," in last string index
            accountNumber = sbAcc.ToString.Substring(0, sbAcc.ToString().Length - 1)
            cusRefNo = sbCusRefno.ToString.Substring(0, sbCusRefno.ToString().Length - 1)
        Else
            fileName = ""
            accountNumber = "'X'"
            cusRefNo = ""
        End If

        dt = generatePaymetReject(clsUtility.gConnGP, fileName, accountNumber, cusRefNo)

        '-- for account cancel (excel)
        'Dim CustRefOld As String
        'For index As Integer = 0 To dgvReject.RowCount - 1

        '    Dim cCustRef As String = dgvReject.Rows(index).Cells(1).Value.ToString

        '    ' Format like file search in (^S15070201M52$|^S15070201M51$)
        '    If cCustRef <> CustRefOld Then
        '        sbCustRef2.Append("^")
        '        sbCustRef2.Append(cCustRef.Trim)
        '        sbCustRef2.Append("$")
        '        sbCustRef2.Append("|")

        '        CustRefOld = cCustRef
        '    End If


        'Next
        'If sbCustRef2.Length > 0 Then
        '    custref2 = sbCustRef2.ToString().Substring(0, sbCustRef2.ToString().Length - 1)
        'Else
        '    custref2 = ""
        'End If
        ''--
        'dt = generatePaymetReject(clsUtility.gConnGP, fileName, accountNumber, custref2)
        GenGridPayment(dt)
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ComboBoxFile.SelectedIndex = 0
        txtLine.Clear()
        txtRejectFile.Clear()
        lbStatusWork.Items.Clear()
        dgvfile.Columns.Clear()
        dgvfile.Controls.Clear()
        dgvPayment.Columns.Clear()
        dgvPayment.Controls.Clear()
        dgvReject.Columns.Clear()
        dgvReject.Controls.Clear()
        refreshFilenameCombo()
    End Sub
    Public Function generatePaymetReject(ByRef oleConn As OleDbConnection, ByVal filename As String, ByVal accNo As String, ByVal CustRef As String)
        Dim sb As New StringBuilder

        sb.Append(" SELECT ")
        sb.Append(" T.GP_CREATEDATE AS CREATEDATE ")
        sb.Append(" ,T.GP_CORE_SYSTEM AS CORE_SYSTEM ")
        sb.Append(" ,T.GP_TRANSREF AS TRANSREF ")
        sb.Append(" ,T.GP_GPTREF_SEQNO AS GP_LINE ")
        sb.Append(" ,T.GP_POLNO AS POLNO ")
        sb.Append(" ,T.GP_PAYDESC AS PAYDESC ")
        sb.Append(" ,T.GP_BNKCODE AS BANKCODE ")
        sb.Append(" ,T.GP_PAYEE_BNKACCNO AS BANK_ACCNO ")
        sb.Append(" ,T.GP_PAYEE_BNKACCNME AS BANK_ACCNAME ")
        sb.Append(" ,T.GP_AMOUNT AS AMOUNT ")
        sb.Append(" ,T.GP_PAIDDATE ")
        sb.Append(" ,T.GP_CONFIRMDATE AS CONFIRMDATE ")
        sb.Append(" ,T.GP_EXPTOBANK_FILENME ")
        sb.Append(" ,DECODE(T.GP_PAYEE_BNKACCNO,NULL,'ACC_CANCEL','HASH_ERR') REJECT_TYPE ")
        sb.Append(" ,DECODE(T.GP_PAYEE_BNKACCNO,NULL,'Accounting dept. cancel transaction','Hash Total Error') REJECT_REASON ")
        sb.Append(" ,DECODE(T.GP_PAYEE_BNKACCNO,NULL,'ACC_CAN','HASH') REJECT_GROUP ")
        sb.Append(" FROM GPS_PAYMENT T ")
        sb.Append(" WHERE REGEXP_LIKE(T.GP_EXPTOBANK_FILENME , '" & filename & "*') ")
        sb.Append(" AND REGEXP_LIKE(T.GP_CUSTREFNO , '" & CustRef & "*') ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    'Public Function generatePaymetReject(ByRef oleConn As OleDbConnection, ByVal filename As String, ByVal accNo As String, ByVal CustRef As String)
    '    Dim sb As New StringBuilder

    '    sb.Append(" SELECT ")
    '    sb.Append(" T.GP_CREATEDATE AS CREATEDATE ")
    '    sb.Append(" ,T.GP_CORE_SYSTEM AS CORE_SYSTEM ")
    '    sb.Append(" ,T.GP_TRANSREF AS TRANSREF ")
    '    sb.Append(" ,T.GP_GPTREF_SEQNO AS GP_LINE ")
    '    sb.Append(" ,T.GP_POLNO AS POLNO ")
    '    sb.Append(" ,T.GP_PAYDESC AS PAYDESC ")
    '    sb.Append(" ,T.GP_BNKCODE AS BANKCODE ")
    '    sb.Append(" ,T.GP_PAYEE_BNKACCNO AS BANK_ACCNO ")
    '    sb.Append(" ,T.GP_PAYEE_BNKACCNME AS BANK_ACCNAME ")
    '    sb.Append(" ,T.GP_AMOUNT AS AMOUNT ")
    '    sb.Append(" ,T.GP_PAIDDATE ")
    '    sb.Append(" ,T.GP_CONFIRMDATE AS CONFIRMDATE ")
    '    sb.Append(" ,T.GP_EXPTOBANK_FILENME ")
    '    sb.Append(" ,'HASH_ERR' REJECT_TYPE ")
    '    sb.Append(" ,'Hash Total Error' REJECT_REASON ")
    '    sb.Append(" ,'HASH' REJECT_GROUP ")
    '    sb.Append(" FROM GPS_PAYMENT T ")
    '    '--        sb.Append(" WHERE REGEXP_LIKE(T.GP_EXPTOBANK_FILENME , '^S15072001M01$*') ") '" & filename & "*') ") '^S15070201M52$|^S15070201M51$
    '    '--        sb.Append(" AND T.GP_PAYEE_BNKACCNO IN ('8492226163') ORDER BY T.GP_SEQNO ") ' " & accNo & "
    '    sb.Append(" WHERE REGEXP_LIKE(T.GP_EXPTOBANK_FILENME , '" & filename & "*') ") '^S15070201M52$|^S15070201M51$
    '    sb.Append(" AND T.GP_PAYEE_BNKACCNO IN (" & accNo & ") ") '-- ORDER BY T.GP_SEQNO ") ' " & accNo & "

    '    If CustRef.Trim <> "" Then
    '        sb.Append(" UNION ")

    '        sb.Append(" SELECT ")
    '        sb.Append(" T.GP_CREATEDATE AS CREATEDATE ")
    '        sb.Append(" ,T.GP_CORE_SYSTEM AS CORE_SYSTEM ")
    '        sb.Append(" ,T.GP_TRANSREF AS TRANSREF ")
    '        sb.Append(" ,T.GP_GPTREF_SEQNO AS GP_LINE ")
    '        sb.Append(" ,T.GP_POLNO AS POLNO ")
    '        sb.Append(" ,T.GP_PAYDESC AS PAYDESC ")
    '        sb.Append(" ,T.GP_BNKCODE AS BANKCODE ")
    '        sb.Append(" ,T.GP_PAYEE_BNKACCNO AS BANK_ACCNO ")
    '        sb.Append(" ,T.GP_PAYEE_BNKACCNME AS BANK_ACCNAME ")
    '        sb.Append(" ,T.GP_AMOUNT AS AMOUNT ")
    '        sb.Append(" ,T.GP_PAIDDATE ")
    '        sb.Append(" ,T.GP_CONFIRMDATE AS CONFIRMDATE ")
    '        sb.Append(" ,T.GP_EXPTOBANK_FILENME ")
    '        sb.Append(" ,'ACC_CANCEL' REJECT_TYPE ")
    '        sb.Append(" ,'Accounting dept. cancel transaction' REJECT_REASON ")
    '        sb.Append(" ,'ACC_CAN' REJECT_GROUP ")
    '        sb.Append(" FROM GPS_PAYMENT T ")
    '        '--        sb.Append(" WHERE REGEXP_LIKE(T.GP_EXPTOBANK_FILENME , '^S15072001M01$*') ") '" & filename & "*') ") '^S15070201M52$|^S15070201M51$
    '        '--        sb.Append(" AND T.GP_PAYEE_BNKACCNO IN ('8492226163') ORDER BY T.GP_SEQNO ") ' " & accNo & "
    '        sb.Append(" WHERE REGEXP_LIKE(T.GP_CUSTREFNO , '" & CustRef & "*') ") '^S15070201M52$|^S15070201M51$
    '    End If

    '    Dim dt As DataTable
    '    dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

    '    If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
    '        Return dt
    '    Else
    '        Return Nothing
    '    End If
    'End Function

    Public Function fnCreateDate(ByRef oleConn As OleDbConnection, ByVal filename As String, ByVal accNo As String)
        Dim sb As New StringBuilder
        sb.Append(" SELECT ")
        sb.Append(" DISTINCT T.GP_CREATEDATE AS CREATEDATE ")
        sb.Append(" FROM GPS_PAYMENT T ")
        sb.Append(" WHERE REGEXP_LIKE(T.GP_EXPTOBANK_FILENME ,'" & filename & "*') ") '^S15070201M52$|^S15070201M51$
        sb.Append(" AND T.GP_PAYEE_BNKACCNO IN (" & accNo & ") ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function fnFileName(ByRef oleConn As OleDbConnection, ByVal firstFilename As String, ByVal createDate As String)
        Dim sb As New StringBuilder
        'select t.gp_exptobank_filenme FROM gps_payment t
        'where t.gp_exptobank_filenme like 'S%' and t.gp_createdate = '20150527'
        'group by  t.gp_createdate,t.gp_exptobank_filenme
        'order by t.gp_exptobank_filenme
        sb.Append(" select t.gp_exptobank_filenme FROM gps_payment t ")
        sb.Append(" where t.gp_exptobank_filenme like ")
        sb.Append(" '" & firstFilename & "%' and t.GP_EXPTOBANK_DATE = '" & createDate & "' ") 'S% , 20150527
        sb.Append(" group by t.gp_exptobank_filenme ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Private Sub btnReject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReject.Click
        lbStatusWork.Items.Clear()
        Dim oleConn As OleDbConnection
        Dim oTrans As OleDbTransaction
        Dim ocallTrans As OleDbTransaction
        Dim fileName, fileNameOld, accountNumber, filePath, filePathBK, _
            batchNo, batchDate, confDate, logTypeId, logType, logMaxid, CustRefOld As String
        Dim sb, sbFilename, sbAcc, sbCustRef, sbAcc2 As New StringBuilder
        Dim count, complete, logId, countRs, i As Integer
        Dim dt, dtFilename As DataTable
        Dim tableName As New ArrayList
        Dim strFileNameList As String
        Dim pathReport As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")
        Dim sysdate As String = clsHashLO.getSysDate(clsUtility.gConnGP)
        Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))

        If dgvfile.RowCount = 0 And dgvReject.RowCount = 0 Then
            MsgBox("กรุณาระบุรายการที่ต้องยกเลิก", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        logTypeId = "001"
        tableName.Add("GPS_PAYMENT_CREATION")
        tableName.Add("GPS_PAYMENT_LOAD")
        tableName.Add("GPS_PAYMENT_REJ")

        count = 0
        complete = 0

        For index As Integer = 0 To dgvfile.RowCount - 1

            Dim cfile As String = dgvfile.Rows(index).Cells(0).Value.ToString
            Dim cLine As String = dgvfile.Rows(index).Cells(1).Value.ToString
            Dim cBnkacc As String = dgvfile.Rows(index).Cells(2).Value.ToString

            If cfile <> fileNameOld Then
                If index > 0 Then
                    sbFilename.Append(",")
                End If
                sbFilename.Append(cfile.Trim)

                fileNameOld = cfile
            End If

            If index > 0 Then
                sbAcc.Append(",")
            End If
            sbAcc.Append(cBnkacc.Trim)
        Next
        fileName = sbFilename.ToString()
        accountNumber = sbAcc.ToString

        '-- for account cancel (excel)
        For index As Integer = 0 To dgvReject.RowCount - 1

            Dim cCustRef As String = dgvReject.Rows(index).Cells(1).Value.ToString
            Dim cAccNo As String = dgvReject.Rows(index).Cells(4).Value.ToString

            ' Format like file search in (^S15070201M52$|^S15070201M51$)
            If cCustRef <> CustRefOld Then
                If index > 0 Then
                    sbCustRef.Append(",")
                    sbAcc2.Append(",")
                End If
                sbCustRef.Append(cCustRef.Trim)
                sbAcc2.Append(cAccNo.Trim)

                CustRefOld = cCustRef
            End If


        Next
        '-- end for account cancel (excel)

        oleConn = clsUtility.gConnGP
        logMaxid = clsLog.fnGetAdjMaxId(oleConn, logTypeId)
        logType = clsLog.fnGetAdjType(oleConn, logTypeId)
        lbStatusWork.Items.Add("Start Reject Data  : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
        For index As Integer = 0 To dgvPayment.RowCount - 1
            Dim CREATEDATE As String = dgvPayment.Rows(index).Cells(0).Value
            Dim CORE_SYSTEM As String = dgvPayment.Rows(index).Cells(1).Value
            Dim TRANSREF As String = dgvPayment.Rows(index).Cells(2).Value
            Dim GP_LINE As String = dgvPayment.Rows(index).Cells(3).Value
            Dim CONFIRMDATE As String = dgvPayment.Rows(index).Cells(11).Value

            confDate = CONFIRMDATE
            If getBatchNo(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE) <> "" Then
                batchNo = getBatchNo(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE)
            End If
            If getBatchDate(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE) <> "" Then
                batchDate = getBatchDate(clsUtility.gConnGP, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE)
            End If

            countRs = countRs + 1

        Next

        '-- get list file for move to backup
        strFileNameList = getExportFileNameByBatchNo(oleConn, batchDate, batchNo)
        '--

        oTrans = oleConn.BeginTransaction()

        If (logMaxid > 0) Then
            If sbFilename.Length > 0 Then
                logId = logMaxid + 1
                clsLog.startAdjLog(oleConn, oTrans, logId, logTypeId, "null", "null", "null", "null", "null", sbFilename.ToString, sbAcc.ToString, logType, gUserLogin)
            End If
            If sbCustRef.Length > 0 Then
                If sbFilename.Length = 0 Then
                    logId = logMaxid + 1
                Else
                    logId = logId + 1
                End If

                clsLog.startAdjLog(oleConn, oTrans, logId, logTypeId, "null", "null", "null", "null", "null", sbCustRef.ToString, sbAcc2.ToString, logType, gUserLogin)
                'clsHashLO.insertIntoGPSRejectLog()
            End If
        Else
            logId = 1
            If sbFilename.Length > 0 Then
                clsLog.startAdjLog(oleConn, oTrans, logId, logTypeId, "null", "null", "null", "null", "null", sbFilename.ToString, sbAcc.ToString, logType, gUserLogin)
                logId = logId + 1
            End If
            If sbCustRef.Length > 0 Then
                clsLog.startAdjLog(oleConn, oTrans, logId, logTypeId, "null", "null", "null", "null", "null", sbCustRef.ToString, sbAcc2.ToString, logType, gUserLogin)
            End If
        End If

        Try
            For index As Integer = 0 To dgvPayment.RowCount - 1
                Dim CREATEDATE As String = dgvPayment.Rows(index).Cells(0).Value
                Dim CORE_SYSTEM As String = dgvPayment.Rows(index).Cells(1).Value
                Dim TRANSREF As String = dgvPayment.Rows(index).Cells(2).Value
                Dim GP_LINE As String = dgvPayment.Rows(index).Cells(3).Value
                Dim CONFIRMDATE As String = dgvPayment.Rows(index).Cells(11).Value
                Dim EXPORTFILENAME As String = dgvPayment.Rows(index).Cells(12).Value.ToString
                Dim BANK_ACCNO As String = dgvPayment.Rows(index).Cells(7).Value.ToString
                Dim REJECT_TYPE As String = dgvPayment.Rows(index).Cells(13).Value.ToString
                Dim REJECT_GROUP As String = dgvPayment.Rows(index).Cells(15).Value.ToString
                confDate = CONFIRMDATE
                'Step 1.1 Move ข้อมูลจากตาราง gps_payment_complete ไปตาราง gps_payment_reject
                'Step 1.2 update ข้อมูลในตาราง gps_payment_creation
                'Step 1.3 ลบข้อมูลในตาราง gps_payment
                complete = complete + movePaymentcompleteToPaymentreject(oleConn, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE, gUserLogin, oTrans, REJECT_TYPE, REJECT_GROUP)
                count = count + 1

                'ถ้าพบข้อมูล WHT ให้ทำ Step 2.1-2.4 ถ้าไม่พบ ไม่ต้องทำงาน Step 2.1-2.3
                'Step 2.1 Move ข้อมูลจากตาราง gps_wth_complete ไปตาราง gps_wht_rej
                'Step 2.2 update ข้อมูลในตาราง gps_wht_creation
                'Step 2.3 update ข้อมูลในตาราง gps_wht_load  
                'Step 2.4 ลบข้อมูลในตาราง gps_wht
                complete = complete + moveWhtToWhtreject(oleConn, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE, gUserLogin, oTrans, REJECT_TYPE, REJECT_GROUP)
                count = count + 1

                For i = 0 To tableName.Count - 1
                    complete = complete + clsLog.updateLogPayment(oleConn, oTrans, logId, CREATEDATE, CORE_SYSTEM, TRANSREF, GP_LINE, gUserLogin, tableName(i))
                    count = count + 1
                Next

            Next

            'Step 1.4 update ข้อมูลในตาราง gps_payment เพื่อรองรับการ Gen ไฟล์จ่ายใหม่
            complete = complete + updatePaymentByConfirmdate(oleConn, confDate, oTrans, batchNo)
            count = count + 1
            'Step 1.4 ลบข้อมูลในตาราง GPS_GENPAYMENTFILE_LOG เพื่อรองรับการ Gen ไฟล์จ่ายใหม่
            complete = complete + deleteGenpaymentFilelog(oleConn, confDate, oTrans, batchNo)
            count = count + 1

            If complete.Equals(count) Then
                oTrans.Commit()
            Else
                oTrans.Rollback()
                lbStatusWork.Items.Add("Fail Reject Data  : " & DateTime.Now.ToString("HH:mm:ss"))
                lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                Exit Sub
            End If
        Catch ex As Exception
            oTrans.Rollback()
            lbStatusWork.Items.Add("Fail Reject Data  : " & DateTime.Now.ToString("HH:mm:ss"))
            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
            Exit Sub
        End Try
        lbStatusWork.Items.Add("Finish Reject Data  : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1


        lbStatusWork.Items.Add("Start Move ไฟล์ ไป Path Backup โดยใช้สิทธิ์ User กลาง : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
        Dim fPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")
        Dim fDate, fFile As String

        ' make a reference to a directory
        Dim di As New IO.DirectoryInfo(fPath)
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo

        'list the names of all files in the specified directory 150615
        For Each dra In diar1
            '--PPK20160616 If dra.ToString.Substring(0, 1) = "S" And dra.ToString.Substring(1, 6) = batchDate.Substring(2, 6) Then
            If strFileNameList.ToString.Contains(dra.ToString.Substring(0, dra.ToString.Length - 4)) Then
                fFile = dra.ToString.Substring(0, dra.ToString.Length - 4)

                '--xxx--'
                'xxxMsgBox(fFile)
                'xxxMsgBox(pathFrom(oleConn, fFile))
                'xxxMsgBox(pathTo(oleConn, fFile))

                clsUtility.BackupFile(pathFrom(oleConn, fFile), pathTo(oleConn, fFile))
                Dim newFilename As String = cls.getNewFilename(oleConn, fFile & ".txt")
                newFilename = newFilename.Substring(0, newFilename.ToString.Length - 4)
                If System.IO.File.Exists(fPath & newFilename & ".txt") Then
                    clsUtility.BackupFile(pathFrom(oleConn, newFilename), pathTo(oleConn, newFilename))
                End If
                If System.IO.File.Exists(fPath & newFilename & ".ctrl") Then
                    clsUtility.BackupFile(pathFromCtrl(oleConn, newFilename), pathToCtrl(oleConn, newFilename))
                End If
            End If
        Next
        lbStatusWork.Items.Add("Finish Move ไฟล์ ไป Path Backup โดยใช้สิทธิ์ User กลาง : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        lbStatusWork.Items.Add("Start Re Generate ไฟล์จ่าย S1  : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        Run_ProcessReGenFile(batchNo)

        lbStatusWork.Items.Add("Finish Re Generate ไฟล์จ่าย S1  : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        lbStatusWork.Items.Add("Start Gen Report Error By Hash Total : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        genReportErrorbyHashTotal(confDate, batchNo)

        If dgvReject.RowCount > 0 Then
            lbStatusWork.Items.Add("Start generate cancel payment report : " & DateTime.Now.ToString("HH:mm:ss"))
            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
            clsHashLO.genReportErrorbyHashTotalGPS(oleConn, Format(Now, "yyyyMMdd"), pathReport, sReportPath, gUserFullName)
            lbStatusWork.Items.Add("Finish generate cancel payment report : " & DateTime.Now.ToString("HH:mm:ss"))
            lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
        End If

        lbStatusWork.Items.Add("Finish Gen Report Error By Hash Total : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        lbStatusWork.Items.Add("Start Gen GL Reject Error by Hash Total : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        ocallTrans = oleConn.BeginTransaction
        CALL_GPS_SP_GET_RejectHash(oleConn, batchDate, batchNo, gUserLogin, ocallTrans)

        lbStatusWork.Items.Add("Finish Gen GL Reject Error by Hash Total : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
        clsLog.endAdjLog(oleConn, ocallTrans, logId, logTypeId, countRs, gUserLogin)
        ocallTrans.Commit()

        lbStatusWork.Items.Add("Start Automatic Send Mail : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

        '3.3.7 Move ไฟล์ ACC Cancel ไป Backup โดยใช้สิทธิ์กลาง
        Dim pathFromACC As String = clsBusiness.fnGet_pathconfig(oleConn, "ACCCANCELFILE_PATH")
        Dim pathToLO As String = clsBusiness.fnGet_pathconfig(oleConn, "CANCELPAYMTH_IL_PATH_BACKUP")
        Dim fileMoveLO As String

        If (System.IO.Directory.Exists(pathFromACC)) Then
            Dim diLO As New IO.DirectoryInfo(pathFromACC)
            Dim diarLO As IO.FileInfo() = diLO.GetFiles("ACC*.xls")
            Dim draLO As IO.FileInfo
            '--Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
            For Each draLO In diarLO
                '--fileMoveLO = clsHashLO.getFileMoveLO(oleConn, sysdate, draLO.ToString)
                fileMoveLO = draLO.ToString
                If fileMoveLO <> "" Then
                    lbStatusWork.Items.Add("Start move file '" & fileMoveLO & "' : " & DateTime.Now.ToString("HH:mm:ss"))
                    lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1
                    fFile = fileMoveLO.Substring(0, fileMoveLO.IndexOf(".")) ' only name not use ".xls"
                    clsUtility.BackupFile(clsHashLO.pathFrom(oleConn, fFile, pathFromACC, fileMoveLO.Substring(fileMoveLO.IndexOf("."))), _
                                          clsHashLO.pathTo(oleConn, fFile, pathToLO, fileMoveLO.Substring(fileMoveLO.IndexOf("."))))
                    lbStatusWork.Items.Add("Finish move file '" & fileMoveLO & "' : " & DateTime.Now.ToString("HH:mm:ss"))
                End If
            Next
            '-- move file format error
            diarLO = diLO.GetFiles()
            fFile = ""
            For Each draLO In diarLO
                fFile = draLO.Name
                '--If fFile.Contains("_FORMAT_ERROR") Then
                '--    clsUtility.BackupFile(pathFromLO & fFile, pathToLO & fFile)
                '--End If
                If fFile.Contains(strCurrentDate) Then
                    clsUtility.BackupFile(pathFromACC & fFile, pathToLO & fFile)
                End If
            Next
            '--
        Else
            MsgBox("Directory backup LO Cancle not create!")
        End If


        '3.3.8 Automatic Send Mail
        Dim dtMail As DataTable
        Dim smtp, subJect, bodyMail, Username, Password, mailResult As String
        Dim sbEmail As New StringBuilder
        bodyMail = "พบข้อมูลรายการจ่ายของ Integral Life ไม่ถูกต้อง (Error by Hash Total/LO Cancel) รบกวนตรวจสอบที่ path : " & clsBusiness.fnGet_pathconfig(oleConn, "REJREPORT_PATH")
        subJect = "Reject Payment Transaction (Integral Life) [Automatic e-mail] as of : " & Now.ToString("dd/MM/yyyy")
        smtp = clsHashLO.getMailSmtp(oleConn)
        dtMail = clsHashLO.getEmail(oleConn, "ERR_BY_HASH")
        For Each rowMail As DataRow In dtMail.Rows
            sbEmail.Append(rowMail("email_address"))
            sbEmail.Append(";")
        Next
        mailResult = clsHashLO.SendEmail("SystemGPSA@scblife.com", sbEmail.ToString, subJect, bodyMail, Username, Password, smtp, 25, Nothing)

        lbStatusWork.Items.Add("Finish Automatic Send Mail : " & DateTime.Now.ToString("HH:mm:ss"))
        lbStatusWork.TopIndex = lbStatusWork.Items.Count - 1

    End Sub

    Public Function pathFrom(ByVal oleConn As OleDbConnection, ByVal fileName As String)
        'Create File
        'Source Path 
        Dim fPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = ".txt"
        'Name .End
        Dim fileRename, fileFrom, fileEnd As New StringBuilder

        Dim clsMNG_FILE As New clsManageFile
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        fileRename.Append(fileName)
        fileRename.Append(out)
        fileRename.Append(curDate)
        fileRename.Append(endFile)

        'Name .End
        fileFrom.Append(fPath)
        fileFrom.Append(fileName)
        fileFrom.Append(".txt")

        'xxxMsgBox("From: " & fileFrom.ToString & vbCrLf & "To: " & fileRename.ToString)

        'My.Computer.FileSystem.RenameFile(fileFrom.ToString, fileRename.ToString) '-- CR#530
        clsUtility.RenameFile(fileFrom.ToString, fileRename.ToString)
        'clsMNG_FILE.RenameFile(clsUtility.gConnGP _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
        '                       , system_code _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
        '                       , server_1 _
        '                       , fileFrom.ToString _
        '                       , fileRename.ToString _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
        '                       , 1 _
        '                       , server_2)

        fileEnd.Append(fPath)
        fileEnd.Append(fileRename.ToString)
        'fileEnd.Append(fileFrom.ToString) '-- CR#530

        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    Public Function pathTo(ByVal oleConn As OleDbConnection, ByVal fileName As String)
        'Destination Path 
        'filePathBK = 
        Dim fPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH_BACKUP")

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = ".txt"

        'Name .End
        Dim fileEnd As New StringBuilder
        fileEnd.Append(fPath)
        fileEnd.Append(fileName)
        fileEnd.Append(out)
        fileEnd.Append(curDate)
        fileEnd.Append(endFile)
        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    Public Function pathFromCtrl(ByVal oleConn As OleDbConnection, ByVal fileName As String)
        'Create File
        'Source Path 
        Dim fPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = ".ctrl"
        'Name .End
        Dim fileRename, fileFrom, fileEnd As New StringBuilder

        Dim clsMNG_FILE As New clsManageFile
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        fileRename.Append(fileName)
        fileRename.Append(out)
        fileRename.Append(curDate)
        fileRename.Append(endFile)

        'Name .End
        fileFrom.Append(fPath)
        fileFrom.Append(fileName)
        fileFrom.Append(".ctrl")

        'My.Computer.FileSystem.RenameFile(fileFrom.ToString, fileRename.ToString) '-- CR#530
        clsUtility.RenameFile(fileFrom.ToString, fileRename.ToString)
        'clsMNG_FILE.RenameFile(clsUtility.gConnGP _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
        '                       , system_code _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
        '                       , server_1 _
        '                       , fileFrom.ToString _
        '                       , fileRename.ToString _
        '                       , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
        '                       , 1 _
        '                       , server_2)


        fileEnd.Append(fPath)
        fileEnd.Append(fileRename.ToString)
        '--fileEnd.Append(fileFrom.ToString) '-- CR#530

        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    Public Function pathToCtrl(ByVal oleConn As OleDbConnection, ByVal fileName As String)
        'Destination Path 
        'filePathBK = 
        Dim fPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH_BACKUP")

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = ".ctrl"

        'Name .End
        Dim fileEnd As New StringBuilder
        fileEnd.Append(fPath)
        fileEnd.Append(fileName)
        fileEnd.Append(out)
        fileEnd.Append(curDate)
        fileEnd.Append(endFile)
        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    ' Romeve data from GPS_GENPAYMENTFILE_LOG table
    Public Function deleteGenpaymentFilelog(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_GENPAYMENTFILE_LOG T")
        sb.Append(" WHERE T.GFLOG_EXPTOBANK_DATE = '" & confirmdate & "' ")
        If batchno.Trim <> "" Then sb.Append(" AND T.GFLOG_BATCH_NO = '" & batchno & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function
    ' Romeve data from GPS_GENPAYMENTFILE_LOG table
    Public Function deleteGenpaymentFilelog_OLD(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append(" DELETE ")
        sb.Append(" FROM GPS_GENPAYMENTFILE_LOG T")
        sb.Append(" WHERE T.GFLOG_EXPTOBANK_DATE = '" & confirmdate & "' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function
    ' Update Flag on GPS_PAYMENT for Re-Gen S1 file
    Public Function updatePaymentByConfirmdate_old(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing) As Integer
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("UPDATE GPS_PAYMENT T ")
        sb.Append("SET T.GP_FLAG_EXPTOBANK  = 'N', ")
        sb.Append("  T.GP_EXPTOBANK_DATE    = '', ")
        sb.Append("  T.GP_EXPTOBANK_FILENME = '', ")
        sb.Append("  T.GP_EXPTOBANK_SEQNO   = '', ")
        sb.Append("  T.GP_CUSTREFNO         = '' ")
        sb.Append("WHERE T.GP_CONFIRMDATE   = '" & confirmdate & "'")
        sb.Append("AND T.GP_FLAG_EXPTOBANK  = 'Y' ")
        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function
    ' Update Flag on GPS_PAYMENT for Re-Gen S1 file
    Public Function updatePaymentByConfirmdate(ByVal oleconn As OleDbConnection, ByVal confirmdate As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional batchno As String = "")
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("UPDATE GPS_PAYMENT T ")
        sb.Append("SET T.GP_FLAG_EXPTOBANK  = 'N', ")
        sb.Append("  T.GP_EXPTOBANK_DATE    = '', ")
        'sb.Append("  T.GP_EXPTOBANK_FILENME = '', ")
        sb.Append("  T.GP_EXPTOBANK_SEQNO   = '', ")
        sb.Append("  T.GP_CUSTREFNO         = '' ")
        sb.Append("WHERE T.GP_CONFIRMDATE   = '" & confirmdate & "'")
        sb.Append(" AND T.GP_FLAG_EXPTOBANK  = 'Y' ")
        sb.Append(" AND T.GP_TRANSREF || TO_CHAR(T.GP_GPTREF_SEQNO) IN ( SELECT C.GPCM_TRANSREF || TO_CHAR(C.GPCM_GPTREF_SEQNO) ")
        sb.Append("                                                        FROM GENERATEPAYMENT.GPS_PAYMENT_COMPLETE C ")
        sb.Append("                                                       WHERE C.GPCM_BATCH_NO = '" & batchno & "') ")

        rec = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function
    ' Move Data in GPS_PAYMENT_COMPLETE table GPS_PAYMENT_REJ
    Public Function movePaymentcompleteToPaymentreject(ByVal oleconn As OleDbConnection, ByVal createDate As String, ByVal coreSystem As String, ByVal transRef As String, ByVal gpLine As String, ByVal gUser As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal REJECT_TYPE As String = "", Optional ByVal REJECT_GROUP As String = "")
        ' Create Transaction

        Try
            Dim sb As New StringBuilder
            Dim sysdate As String = Now.ToString("yyyyMMdd")
            Dim i, completeStr, count As Integer
            i = 0
            completeStr = 0
            count = 0
            '3.1 Remove data from GPS_Payment table
            ' Move complete to reject
            sb.Remove(0, sb.Length)
            sb.Append(" INSERT INTO GPS_PAYMENT_REJ PRJ ( ")
            sb.Append(" PRJ.GPRJ_BATCHDATE ,PRJ.GPRJ_BATCH_NO ,PRJ.GPRJ_CREATEDATE ,PRJ.GPRJ_CORE_SYSTEM ")
            sb.Append(" ,PRJ.GPRJ_TRANSREF ,PRJ.GPRJ_GPTREF_SEQNO ,PRJ.GPRJ_POLNO ,PRJ.GPRJ_BILLNO ")
            sb.Append(" ,PRJ.GPRJ_PAIDDATE ,PRJ.GPRJ_AMOUNT ,PRJ.GPRJ_DESC ,PRJ.GPRJ_PAYMTH ")
            sb.Append(" ,PRJ.GPRJ_PAYEE_NAME ,PRJ.GPRJ_BNKCODE ,PRJ.GPRJ_BNKCODE_NO ,PRJ.GPRJ_BNKBRN ")
            sb.Append(" ,PRJ.GPRJ_BNKNAME ,PRJ.GPRJ_PAYEE_BNKACCNO ,PRJ.GPRJ_PAYEE_BNKACCNME ,PRJ.GPRJ_COMMENT ")
            sb.Append(" ,PRJ.GPRJ_ADDRESS1 ,PRJ.GPRJ_DISTRICT ,PRJ.GPRJ_PROVINCE ,PRJ.GPRJ_INSURENAME ")
            sb.Append(" ,PRJ.GPRJ_DATASOURCE_NME ,PRJ.GPRJ_RESERVE6 ,PRJ.GPRJ_MERCHN_NO ,PRJ.GPRJ_CDCARD_DATE ")
            sb.Append(" ,PRJ.GPRJ_RESERVE9 ,PRJ.GPRJ_RESERVE10 ,PRJ.GPRJ_SYS_REF ,PRJ.GPRJ_SYS_GR ")
            sb.Append(" ,PRJ.GPRJ_SUB_PAYMTH ,PRJ.GPRJ_FLAG_FLWBILL ,PRJ.GPRJ_OSEA_LIST ,PRJ.GPRJ_PHONE ")
            sb.Append(" ,PRJ.GPRJ_FAX ,PRJ.GPRJ_SWIFT_CODE ,PRJ.GPRJ_BNKBRN_NAME ,PRJ.GPRJ_BNKADDR ")
            sb.Append(" ,PRJ.GPRJ_COUNTRY ,PRJ.GPRJ_CURRENCY ,PRJ.GPRJ_EXCHN_RATE ,PRJ.GPRJ_BNKCHARGES ")
            sb.Append(" ,PRJ.GPRJ_REJECT_TYPE ,PRJ.GPRJ_REJECT_FUNC ,PRJ.GPRJ_BATCHTYPE ")
            sb.Append(" ,PRJ.CREATEDBY ,PRJ.CREATEDDATE ,PRJ.UPDATEDBY ,PRJ.UPDATEDDATE) ")
            sb.Append(" SELECT  ")
            sb.Append(" COMP.GPCM_BATCHDATE ,COMP.GPCM_BATCH_NO ,COMP.GPCM_CREATEDATE ,COMP.GPCM_CORE_SYSTEM ")
            sb.Append(" ,COMP.GPCM_TRANSREF ,COMP.GPCM_GPTREF_SEQNO ,COMP.GPCM_POLNO ,COMP.GPCM_BILLNO ")
            sb.Append(" ,COMP.GPCM_PAIDDATE ,COMP.GPCM_AMOUNT ,COMP.GPCM_DESC ,COMP.GPCM_PAYMTH ")
            sb.Append(" ,COMP.GPCM_PAYEE_NAME ,COMP.GPCM_BNKCODE ,COMP.GPCM_BNKCODE_NO ,COMP.GPCM_BNKBRN ")
            sb.Append(" ,COMP.GPCM_BNKNAME ,COMP.GPCM_PAYEE_BNKACCNO ,COMP.GPCM_PAYEE_BNKACCNME ,COMP.GPCM_COMMENT ")
            sb.Append(" ,COMP.GPCM_ADDRESS1 ,COMP.GPCM_DISTRICT ,COMP.GPCM_PROVINCE ,COMP.GPCM_INSURENAME ")
            sb.Append(" ,COMP.GPCM_DATASOURCE_NME ,COMP.GPCM_RESERVE6 ,COMP.GPCM_MERCHN_NO ,COMP.GPCM_CDCARD_DATE ")
            sb.Append(" ,COMP.GPCM_RESERVE9 ,COMP.GPCM_RESERVE10 ,COMP.GPCM_SYS_REF ,COMP.GPCM_SYS_GR ")
            sb.Append(" ,COMP.GPCM_SUB_PAYMTH ,COMP.GPCM_FLAG_FLWBILL ,COMP.GPCM_OSEA_LIST ,COMP.GPCM_PHONE ")
            sb.Append(" ,COMP.GPCM_FAX ,COMP.GPCM_SWIFT_CODE ,COMP.GPCM_BNKBRN_NAME ,COMP.GPCM_BNKADDR ")
            sb.Append(" ,COMP.GPCM_COUNTRY ,COMP.GPCM_CURRENCY ,COMP.GPCM_EXCHN_RATE ,COMP.GPCM_BNKCHARGES ")
            sb.Append(" ,'" & REJECT_TYPE & "' ,'" & REJECT_GROUP & "', 'M' ")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI')")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI')")
            sb.Append(" FROM ")
            sb.Append(" GPS_PAYMENT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.GPCM_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND COMP.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_PAYMENT_COMPLETE COMP")
            sb.Append(" WHERE COMP.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.GPCM_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND COMP.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            'End If
            ' Update 'INCOMPLETE' and 'Hash_err' on Paymet_creation or Payment_load
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_PAYMENT_CREATION T ")
            sb.Append(" SET T.GPCR_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.GPCR_REJECT_TYPE     = 'HASH_ERR' ")
            sb.Append(" WHERE T.GPCR_CREATEDATE  = '" & createDate & "' ")
            sb.Append(" AND T.GPCR_CORE_SYSTEM   = '" & coreSystem & "' ")
            sb.Append(" AND T.GPCR_TRANSREF     = '" & transRef & "' ")
            sb.Append(" AND T.GPCR_GPTREF_SEQNO  = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_PAYMENT_LOAD T ")
            sb.Append(" SET T.GPLD_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.GPLD_REJECT_TYPE     = 'HASH_ERR' ")
            sb.Append(" WHERE T.GPLD_BATCHDATE  = '" & createDate & "' ")
            sb.Append(" AND T.GPLD_CORE_SYSTEM   = '" & coreSystem & "' ")
            sb.Append(" AND T.GPLD_TRANSREF      = '" & transRef & "' ")
            sb.Append(" AND T.GPLD_GPTREF_SEQNO  = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_PAYMENT T ")
            sb.Append(" WHERE T.GP_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.GP_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.GP_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND T.GP_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            If count.Equals(i) Then
                Return 1
            Else
                Return 0
            End If

        Catch ex As Exception
            Return 0
        End Try
    End Function

    ' Move Data in GPS_WHT table to GPS_WHT_REJ
    Public Function moveWhtToWhtreject(ByVal oleconn As OleDbConnection, ByVal createDate As String, ByVal coreSystem As String, ByVal transRef As String, ByVal gpLine As String, ByVal gUser As String, Optional ByVal oTrans As OleDbTransaction = Nothing, Optional ByVal REJECT_TYPE As String = "", Optional ByVal REJECT_GROUP As String = "")
        ' Create Transaction

        Try
            Dim sb As New StringBuilder
            Dim sysdate As String = Now.ToString("yyyyMMdd")
            Dim i, completeStr, count As Integer
            i = 0
            completeStr = 0
            count = 0
            'MOVE wht complete to wht reject
            sb.Remove(0, sb.Length)
            sb.Append(" INSERT INTO GPS_WHT_REJ REJ (REJ.TAXRJ_BATCHDATE, REJ.TAXRJ_BATCH_NO ,REJ.TAXRJ_CREATEDATE ")
            sb.Append(" ,REJ.TAXRJ_CORE_SYSTEM ,REJ.TAXRJ_TRANSREF ,REJ.TAXRJ_GPTREF_SEQNO ,REJ.TAXRJ_LINENO ")
            sb.Append(" ,REJ.TAXRJ_TAXID ,REJ.TAXRJ_IDCARD ,REJ.TAXRJ_AP_TTL ,REJ.TAXRJ_AP_FNAME ")
            sb.Append(" ,REJ.TAXRJ_AP_LNAME ,REJ.TAXRJ_ADDRESS ,REJ.TAXRJ_AMPENM ,REJ.TAXRJ_PROVNM ")
            sb.Append(" ,REJ.TAXRJ_AGZIP ,REJ.TAXRJ_TAXTYPE ,REJ.TAXRJ_TAXITEM ,REJ.TAXRJ_TAXDATE ")
            sb.Append(" ,REJ.TAXRJ_BASE_AMT ,REJ.TAXRJ_TAX_AMT ,REJ.TAXRJ_PAYEE ,REJ.TAXRJ_TAX_RATE ")
            sb.Append(" ,REJ.TAXRJ_DESC ,REJ.TAXRJ_GL_ACCOUNT ,REJ.TAXRJ_REJECT_TYPE ,REJ.TAXRJ_REJECT_FUNC ")
            sb.Append(" ,REJ.TAXRJ_BATCHTYPE ,REJ.CREATEDBY ,REJ.CREATEDDATE ,REJ.UPDATEDBY ")
            sb.Append(" ,REJ.UPDATEDDATE) ")
            sb.Append(" SELECT ")
            sb.Append(" COMP.TAXCM_BATCHDATE ,COMP.TAXCM_BATCH_NO ,COMP.TAXCM_CREATEDATE ,COMP.TAXCM_CORE_SYSTEM ")
            sb.Append(" ,COMP.TAXCM_TRANSREF ,COMP.TAXCM_GPTREF_SEQNO ,COMP.TAXCM_LINENO ,COMP.TAXCM_TAXID ")
            sb.Append(" ,COMP.TAXCM_IDCARD ,COMP.TAXCM_AP_TTL ,COMP.TAXCM_AP_FNAME ,COMP.TAXCM_AP_LNAME ")
            sb.Append(" ,COMP.TAXCM_ADDRESS ,COMP.TAXCM_AMPENM ,COMP.TAXCM_PROVNM ,COMP.TAXCM_AGZIP ")
            sb.Append(" ,COMP.TAXCM_TAXTYPE ,COMP.TAXCM_TAXITEM ,COMP.TAXCM_TAXDATE ,COMP.TAXCM_BASE_AMT ")
            sb.Append(" ,COMP.TAXCM_TAX_AMT ,COMP.TAXCM_PAYEE ,COMP.TAXCM_TAX_RATE ,COMP.TAXCM_DESC ")
            sb.Append(" ,COMP.TAXCM_GL_ACCOUNT, '" & REJECT_TYPE & "' ,'" & REJECT_GROUP & "', COMP.TAXCM_BATCHTYPE ")
            sb.Append(" ,'" & gUser & "'")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" ,'" & gUser & "' ")
            sb.Append(" ,TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" FROM GPS_WHT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.TAXCM_BATCHDATE = '" & createDate & "' ")
            sb.Append(" AND COMP.TAXCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND COMP.TAXCM_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND COMP.TAXCM_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" DELETE ")
            sb.Append(" FROM GPS_WHT_COMPLETE COMP ")
            sb.Append(" WHERE COMP.TAXCM_CREATEDATE = '" & createDate & "'  ")
            sb.Append(" AND COMP.TAXCM_CORE_SYSTEM = '" & coreSystem & "'  ")
            sb.Append(" AND COMP.TAXCM_TRANSREF = '" & transRef & "'  ")
            sb.Append(" AND COMP.TAXCM_GPTREF_SEQNO = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            ' Update 'INCOMPLETE' and 'Hash_err' on WHT_creation or WHT_load
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_WHT_CREATION T ")
            sb.Append(" SET T.TAXCR_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("   T.TAXCR_REJECT_TYPE    = 'HASH_ERR' ")
            sb.Append(" WHERE T.TAXCR_CREATEDATE  = '" & createDate & "'  ")
            sb.Append(" AND T.TAXCR_CORE_SYSTEM   = '" & coreSystem & "'  ")
            sb.Append(" AND T.TAXCR_TRANSREF     = '" & transRef & "'  ")
            sb.Append(" AND T.TAXCR_GPTREF_SEQNO  = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE GPS_WHT_LOAD T ")
            sb.Append(" SET T.TAXLD_FLAG_VALIDATE = 'INCOMPLETE', ")
            sb.Append("  T.TAXLD_REJECT_TYPE    = 'HASH_ERR' ")
            sb.Append(" WHERE T.TAXLD_BATCHDATE  = '" & createDate & "'  ")
            sb.Append(" AND T.TAXLD_CORE_SYSTEM   = '" & coreSystem & "'  ")
            sb.Append(" AND T.TAXLD_TRANSREF     = '" & transRef & "'  ")
            sb.Append(" AND T.TAXLD_GPTREF_SEQNO  = '" & gpLine & "'  ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            'Delete wht by key fied
            sb.Remove(0, sb.Length)
            sb.Append(" DELETE FROM GPS_WHT T ")
            sb.Append(" WHERE T.TAX_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.TAX_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.TAX_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND T.TAX_GPTREF_SEQNO = '" & gpLine & "' ")
            completeStr = clsBusiness.ExecuteCommand(oleconn, sb, oTrans)
            If completeStr = -1 Then
                count = count + completeStr
                i = i + 1
            Else
                count = count + 1
                i = i + 1
            End If

            If count.Equals(i) Then
                Return 1
            Else
                Return 0
            End If
        Catch ex As Exception
            Return -1
        End Try
    End Function

    Public Function getExportFileNameByBatchNo(ByVal oleconn As OleDbConnection, ByVal batchDate As String, ByVal batchno As String) As String
        Try
            Dim sb As New StringBuilder
            Dim Ds As New DataSet

            sb.Remove(0, sb.Length)
            sb.Append(" SELECT listagg( LF.gp_exptobank_filenme, '/') within group (ORDER BY LF.GPCM_BATCH_NO) filenamelist ")
            sb.Append("   FROM (SELECT C.GPCM_BATCH_NO, T.gp_exptobank_filenme FROM GENERATEPAYMENT.GPS_PAYMENT T ")
            sb.Append("        INNER JOIN GENERATEPAYMENT.GPS_PAYMENT_COMPLETE C ")
            sb.Append("           ON T.GP_TRANSREF = C.GPCM_TRANSREF ")
            sb.Append("          AND T.GP_GPTREF_SEQNO = C.GPCM_GPTREF_SEQNO ")
            sb.Append("             WHERE(1 = 1) ")
            sb.Append("    AND C.GPCM_BATCH_NO = '" & batchno & "' ")
            sb.Append("    AND C.GPCM_BATCHDATE = '" & batchDate & "' ")
            sb.Append("    and t.gp_exptobank_filenme is not null ")
            sb.Append("  group by C.GPCM_BATCH_NO, T.gp_exptobank_filenme) LF ")
            sb.Append("  GROUP BY LF.GPCM_BATCH_NO ")

            clsBusiness.ExecuteReader(oleconn, Ds, sb.ToString)
            getExportFileNameByBatchNo = Ds.Tables(0).Rows(0)("filenamelist")

        Catch ex As Exception
            getExportFileNameByBatchNo = ""
        End Try
    End Function

    Public Function getBatchNo(ByVal oleconn As OleDbConnection, ByVal createDate As String, ByVal coreSystem As String, ByVal transRef As String, ByVal gpLine As String) As String
        Try
            Dim sb As New StringBuilder
            Dim Ds As New DataSet

            sb.Remove(0, sb.Length)
            sb.Append(" SELECT T.GPCM_BATCH_NO  ")
            sb.Append(" FROM GPS_PAYMENT_COMPLETE T ")
            sb.Append(" WHERE T.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.GPCM_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND T.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")

            clsBusiness.ExecuteReader(oleconn, Ds, sb.ToString)
            getBatchNo = Ds.Tables(0).Rows(0)("GPCM_BATCH_NO")

        Catch ex As Exception
            getBatchNo = ""
        End Try
    End Function

    Public Function getBatchDate(ByVal oleconn As OleDbConnection, ByVal createDate As String, ByVal coreSystem As String, ByVal transRef As String, ByVal gpLine As String) As String
        Dim sb As New StringBuilder
        Dim Dt As New DataTable
        Try

            sb.Remove(0, sb.Length)
            sb.Append(" SELECT T.GPCM_BATCHDATE  ")
            sb.Append(" FROM GPS_PAYMENT_COMPLETE T ")
            sb.Append(" WHERE T.GPCM_CREATEDATE = '" & createDate & "' ")
            sb.Append(" AND T.GPCM_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND T.GPCM_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND T.GPCM_GPTREF_SEQNO = '" & gpLine & "' ")

            Dt = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)
            getBatchDate = Dt.Rows(0)("GPCM_BATCHDATE").ToString

        Catch ex As Exception
            getBatchDate = ""
        End Try
    End Function

    Function CALL_GPS_SP_GET_RejectHash(ByVal oleConn As OleDbConnection, ByVal pBatchDate As String, ByVal pBatchno As String, ByVal user As String, Optional ByVal oTrans As OleDbTransaction = Nothing)

        Dim dbComm As OleDbCommand

        Dim sysdate As String = Now.ToString("yyyyMMdd")
        'p_Batch_Date IN VARCHAR2,
        '--- วันที่รับ Batch  รูปแบบ   YYYYMMDD
        'p_Batch_no IN VARCHAR2,
        '--- เลขที่ Batch
        'p_user IN VARCHAR2 ,
        'result_return OUT VARCHAR2,
        'result_msg OUT VARCHAR2
        dbComm = oleConn.CreateCommand
        dbComm.Parameters.Add("p_Batch_Date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_Date").Value = pBatchDate
        dbComm.Parameters.Add("p_Batch_no", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Batch_no").Value = pBatchno
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.Transaction = oTrans
        dbComm.CommandText = "GPS_SP_GET_RejectHash"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()


        If dbComm.Parameters("result_return").Value = True Then
            Return 1
        Else
            Return -1
        End If
    End Function

    Private Sub Run_ProcessReGenFile(ByVal batchNo As String)
        Dim dt_data As New DataTable
        dt_data = cls.BindData(clsUtility.gConnGP, batchNo)

        Dim dt_filename As New DataTable
        dt_filename = BindFileName(batchNo)

        Dim dt_filename_M As New DataTable
        dt_filename_M = BindFileName_M(batchNo)

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim c1, c2, c3 As Boolean
        c1 = True
        c2 = True
        c3 = True

        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            c1 = UpdateData_CD(oleTrans, dt_filename, dt_data)
        End If

        If Not IsNothing(dt_filename_M) AndAlso dt_filename_M.Rows.Count > 0 Then
            c2 = UpdateData_M(oleTrans, dt_filename_M, dt_data)
        End If

        c3 = UpdateFlag(oleTrans, batchNo)

        If c1 And c2 And c3 Then
            oleTrans.Commit()

            GenerateTextFile(batchNo)

            'BindBatchNo()
            'MsgBox("Generate text file successfully")
        Else
            oleTrans.Rollback()

            MsgBox("Can not generate text file!")
        End If

    End Sub
    Private Sub GenerateTextFile(ByVal batchno As String)
        Dim dt_filename As New DataTable
        dt_filename = cls.GetTextFileForGen(clsUtility.gConnGP, batchno)
        fnGenTextFile(dt_filename, batchno)

        Dim dt_filename_M As New DataTable
        dt_filename_M = cls.GetTextFileForGen_M(clsUtility.gConnGP, batchno)
        fnGenTextFile(dt_filename_M, batchno)

    End Sub
    Private Sub fnGenTextFile(ByVal dt_filename As DataTable, ByVal batchno As String)
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then

            For Each dr As DataRow In dt_filename.Rows
                Dim dt As DataTable

                Dim filename As String
                Dim path As String
                Dim destination_path As String '-- CR#530
                Dim destination_filename As String '-- CR#530
                path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")
                destination_path = path '-- CR#530
                path = "D:\" '-- Cr#530

                filename = path & dr("GP_EXPTOBANK_FILENME") & ".txt"
                destination_filename = destination_path & dr("GP_EXPTOBANK_FILENME") & ".txt" '-- CR#530

                If dr("TREF_PAYMTH") = "M" Then
                    '-- get data (direct credit or media clearing) for re-generate payment file
                    dt = cls.GetDataForGenTextFile_M(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    '-- generate payment file
                    GenTextFile_M(dt, filename, batchno)
                Else
                    '-- get data (cheque or draft) for re-generate payment file
                    dt = cls.GetDataForGenTextFile(clsUtility.gConnGP, dr("GP_EXPTOBANK_FILENME"))
                    '-- generate payment file
                    GenTextFile(dt, filename, batchno)
                End If

                Dim newFilename As String
                Dim newFilenameTxt As String
                '-- generate new file name
                newFilename = cls.getPrefixFilename(clsUtility.gConnGP) & cls.getCoperateId(clsUtility.gConnGP) & cls.getBankCode(clsUtility.gConnGP) & cls.getFileType(clsUtility.gConnGP) & cls.getSysDateTime(clsUtility.gConnGP)
                '-- new file name include extension
                newFilenameTxt = newFilename & ".txt"
                '-- copy file from old file name format to new file name format
                System.IO.File.Copy(filename, System.IO.Path.GetDirectoryName(filename) & "/" & newFilenameTxt, True)
                '-- create control file (new file name format)
                Dim fs As FileStream = File.Create(System.IO.Path.GetDirectoryName(filename) & "/" & newFilename & ".ctrl")
                Dim info As Byte() = New UTF8Encoding(True).GetBytes(newFilenameTxt & ".gpg")
                fs.Write(info, 0, info.Length)
                fs.Close()
                '-- create control file (new file name format) completed

                '-- CR#530 start --
                '-- move file to destination path
                '-- 1. move file old name format to destination path
                clsUtility.BackupFile(filename, destination_filename)
                '-- 2. move file new name format to destination path
                clsUtility.BackupFile(path & newFilenameTxt, destination_path & newFilenameTxt)
                '-- 3. move ctrl file new name format to destination path
                clsUtility.BackupFile(path & newFilename & ".ctrl", destination_path & newFilename & ".ctrl")
                '-- CR#530 end --

                Dim oleTrans As OleDbTransaction
                oleTrans = clsUtility.gConnGP.BeginTransaction()
                Dim rec As Integer
                rec = cls.UpdateMap(clsUtility.gConnGP, oleTrans, dr("GP_EXPTOBANK_FILENME") & ".txt", newFilenameTxt)
                If rec = 1 Then
                    oleTrans.Commit()
                Else
                    oleTrans.Rollback()
                End If

                System.Threading.Thread.Sleep(1000)

            Next

        End If
    End Sub

    Private Sub genReportErrorbyHashTotal(ByVal confirmDate As String, ByVal batchno As String)

        Dim sysdate As String = Now.ToString("yyyyMMdd")
        Dim systemdate As String = confirmDate.Substring(6, 2) & "/" & confirmDate.Substring(4, 2) & "/" & confirmDate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()
        dt = clsBusiness.GetDataRptErrorByHash(clsUtility.gConnGP, confirmDate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim clsExportPDF As New clsCrystalToPDFConverter
            Dim path As String

            Dim tempDir As String = "temp\"
            If System.IO.Directory.Exists(tempDir) Then
                System.IO.Directory.Delete(tempDir, True)
            End If
            System.IO.Directory.CreateDirectory(tempDir)

            path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")

            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByHash.rpt")
            clsExportPDF.SetPdfDestinationFilePath(tempDir & "RptErrorByHash_" & sysdate & "_" & batchno & ".pdf")
            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")

            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)

            For Each reportFilename As String In System.IO.Directory.GetFiles(tempDir)
                clsUtility.BackupFile(reportFilename, path & System.IO.Path.GetFileName(reportFilename))
            Next

        End If

    End Sub
    Private Sub genReportErrorbyHashTotal_OLD(ByVal confirmDate As String)

        Dim sysdate As String = Now.ToString("yyyyMMdd")
        Dim systemdate As String = confirmDate.Substring(6, 2) & "/" & confirmDate.Substring(4, 2) & "/" & confirmDate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()
        dt = clsBusiness.GetDataRptErrorByHash(clsUtility.gConnGP, confirmDate)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim clsExportPDF As New clsCrystalToPDFConverter
            Dim path As String
            path = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "REJREPORT_PATH")

            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByHash.rpt")
            clsExportPDF.SetPdfDestinationFilePath(path & "RptErrorByHash_" & sysdate & ".pdf")
            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")

            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)

        End If

    End Sub
    Function BindFileName(ByVal batchNo As String) As DataTable
        Dim dt As New DataTable
        dt = cls.GroupDataByPaymentType(clsUtility.gConnGP, batchNo)

        Dim systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim idCC As Integer
            idCC = cls.GetMaxID(clsUtility.gConnGP, "C", systemdate)
            Dim idDD As Integer
            idDD = cls.GetMaxID(clsUtility.gConnGP, "D", systemdate)

            For Each dr As DataRow In dt.Rows

                Dim filename As String

                filename = "S" & Microsoft.VisualBasic.Right(systemdate, 6) & "01" & dr("TREF_PAYMTH")

                Select Case dr("TREF_PAYMTH")
                    Case "C"
                        dr("FILENAME") = filename & idCC.ToString.PadLeft(2, "0")
                        idCC = idCC + 1
                    Case "D"
                        dr("FILENAME") = filename & idDD.ToString.PadLeft(2, "0")
                        idDD = idDD + 1
                End Select

            Next

            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function BindFileName_M(ByVal batchNo As String) As DataTable
        Dim dt As New DataTable
        dt = cls.GroupDataByPaymentType_M(clsUtility.gConnGP, batchNo)
        Dim systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            Dim idM_SCB As Integer
            idM_SCB = cls.GetMaxID_M(clsUtility.gConnGP, True, systemdate)
            Dim idM As Integer
            idM = cls.GetMaxID_M(clsUtility.gConnGP, False, systemdate)

            For Each dr As DataRow In dt.Rows



                Dim filename As String
                filename = "S" & Microsoft.VisualBasic.Right(systemdate, 6) & "01" & dr("TREF_PAYMTH")

                If dr("GP_BNKCODE") = "SCB" Then

                    dr("FILENAME") = filename & idM_SCB.ToString.PadLeft(2, "0")
                    idM_SCB = idM_SCB + 1
                Else

                    If idM = 0 Then
                        idM = "50"
                    Else
                        idM = idM
                    End If
                    dr("FILENAME") = filename & idM.ToString.PadLeft(2, "0")
                    idM = idM + 1

                End If


            Next

            Return dt
        Else
            Return Nothing
        End If
    End Function
    Function UpdateFlag(ByVal oleTrans As OleDbTransaction, ByVal batchno As String) As Boolean
        Dim rec As Integer
        rec = cls.UpdateFlag(clsUtility.gConnGP, oleTrans, batchno, gUserLogin)

        If rec = 1 Then
            Return True
        Else
            Return False
        End If
    End Function
    Function UpdateData_CD(ByVal oleTrans As OleDbTransaction, ByVal dt_filename As DataTable, ByVal dt_data As DataTable) As Boolean
        Dim rec As Integer
        Dim rec2 As Integer
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            For Each dr As DataRow In dt_filename.Rows

                rec = rec + cls.UpdateFileName(clsUtility.gConnGP, oleTrans, dr, gUserLogin)
                rec2 = rec2 + UpdateData(oleTrans, dt_data, dr("FILENAME"), dr("TREF_PAYMTH"), dr("TREF_PAIDDATE"))

            Next

            If (rec = dt_filename.Rows.Count) And (rec2 = dt_filename.Rows.Count) Then
                Return True
            Else
                Return False
            End If

        End If


    End Function
    Function UpdateData_M(ByVal oleTrans As OleDbTransaction, ByVal dt_filename As DataTable, ByVal dt_data As DataTable) As Boolean
        Dim rec As Integer
        Dim rec2 As Integer
        If Not IsNothing(dt_filename) AndAlso dt_filename.Rows.Count > 0 Then
            For Each dr As DataRow In dt_filename.Rows

                rec = rec + cls.UpdateFileName_M(clsUtility.gConnGP, oleTrans, dr, gUserLogin)
                rec2 = rec2 + UpdateData_Media(oleTrans, dt_data, dr("FILENAME"), dr("TREF_PAYMTH"), dr("TREF_PAIDDATE"), dr("GP_BNKCODE"))

            Next

            If (rec = dt_filename.Rows.Count) And (rec2 = dt_filename.Rows.Count) Then
                Return True
            Else
                Return False
            End If

        Else
            Return True
        End If

    End Function
    Function UpdateData(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal filename As String, ByVal paymth As String, ByVal paiddate As String) As String
        Dim rec As Integer
        Dim result() As DataRow
        If dt.Rows.Count > 0 Then

            result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            Dim id As String
            id = 1
            For Each row As DataRow In result
                rec = rec + cls.UpdateData(clsUtility.gConnGP, oleTrans, row, id.PadLeft(4, "0"), filename, gUserLogin)
                id = id + 1

            Next

            If rec = result.Length Then
                Return 1
            Else
                Return 0
            End If
        Else
            Return 0
        End If

    End Function
    Function UpdateData_Media(ByVal oleTrans As OleDbTransaction, ByVal dt As DataTable, ByVal filename As String, ByVal paymth As String, ByVal paiddate As String, ByVal bankcode As String) As String
        Dim rec As Integer
        Dim result() As DataRow
        If dt.Rows.Count > 0 Then

            If bankcode = "SCB" Then  ''GP_BNKSCODE
                result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' AND GP_BNKCODE='SCB' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            Else
                result = dt.Select("GP_PAYMTH='" & paymth & "'  AND GP_PAIDDATE='" & paiddate & "' AND GP_BNKCODE<>'SCB' ", "GP_CORE_SYSTEM ASC,TREF_DEP_REPAY ASC,GP_TRANSREF ASC,GP_SEQNO ASC")
            End If

            Dim id As String
            id = 1
            For Each row As DataRow In result
                rec = rec + cls.UpdateData(clsUtility.gConnGP, oleTrans, row, id.PadLeft(4, "0"), filename, gUserLogin)
                id = id + 1

            Next

            If rec = result.Length Then
                Return 1
            Else
                Return 0
            End If
        Else
            Return 0
        End If

    End Function
    Public Sub GenTextFile(ByVal dt As DataTable, ByVal filename As String, ByVal batchNo As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If

        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)

        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        For Each dr As DataRow In dt.Rows

            GenDetail(sw, filename, dr, (dt.Rows.IndexOf(dr) + 1), dr("GP_AMOUNT2"))

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()

        InsertLog(IO.Path.GetFileName(filename), dt.Rows(0)("GP_PAIDDATE").ToString, dt.Rows.Count, Convert.ToInt16(l_NoOf9), dt.Rows(0)("GP_PAYMTH").ToString, dt.Rows(0)("GP_SUB_PAYMTH").ToString, Convert.ToDouble(l_DrAmount9), batchNo)

    End Sub
    Public Sub GenTextFile_M(ByVal dt As DataTable, ByVal filename As String, ByVal batchNo As String)

        If dt.Rows.Count < 1 Then
            Exit Sub
        End If
        If System.IO.File.Exists(filename) Then
            My.Computer.FileSystem.DeleteFile(filename)
        End If

        Dim systemdate As String
        Dim s_systemtime As String

        systemdate = Microsoft.VisualBasic.Left(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)
        s_systemtime = Microsoft.VisualBasic.Right(clsBusiness.GetSystemDate(clsUtility.gConnGP), 8)

        Dim sw As StreamWriter = New StreamWriter(filename, True, Encoding.Default)

        'Generate 001
        Dim l_RecordType = "001"
        sw.Write(l_RecordType)
        Dim l_CompanyID = dt.Rows(0)("EXP_COMPANY_ID").ToString.PadRight(12, " ")
        sw.Write(l_CompanyID)
        Dim l_CustomerRef = dt.Rows(0)("GP_EXPTOBANK_FILENME").ToString.PadRight(32, " ")
        sw.Write(l_CustomerRef)
        Dim l_FileDate = systemdate.PadRight(8, " ")
        sw.Write(l_FileDate)
        Dim l_FileTime = s_systemtime.Replace(":", "").PadRight(6, " ")
        sw.Write(l_FileTime)
        Dim l_ChannelID = "BCM"
        sw.Write(l_ChannelID)
        Dim l_BatchRef = "".PadRight(32, " ")
        sw.Write(l_BatchRef)
        sw.WriteLine()

        'Generate 002
        Dim l_RecordType2 = "002"
        sw.Write(l_RecordType2)
        Dim l_ProductCode = dt.Rows(0)("EXP_PRODUCT_CODE").ToString.PadRight(3, " ")
        sw.Write(l_ProductCode)
        Dim l_PaidDate = dt.Rows(0)("GP_PAIDDATE").ToString.PadRight(8, " ")
        sw.Write(l_PaidDate)
        'Dim l_DrAccNo = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        Dim l_DrAccNo = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(25, " ")
        sw.Write(l_DrAccNo)
        Dim l_DrAccType = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_DrAccType)
        Dim l_DrBranch = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_DrBranch)
        Dim l_Currency = "THB"
        sw.Write(l_Currency)
        Dim l_DrAmount
        l_DrAmount = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount)
        Dim l_IntenalRef = "00000001"
        sw.Write(l_IntenalRef)
        Dim l_NoOfCr = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadRight(6, "0")
        sw.Write(l_NoOfCr)
        'Dim l_FeeDrAcc = ("0" & dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        Dim l_FeeDrAcc = (dt.Rows(0)("GP_BNKSACC_NO")).PadRight(15, " ")
        sw.Write(l_FeeDrAcc)
        Dim l_Filter = "".PadRight(9, " ")
        sw.Write(l_Filter)
        Dim l_MediaClearingCycle = "".PadRight(1, " ")
        sw.Write(l_MediaClearingCycle)
        Dim l_AccTypeFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(3, 1)
        sw.Write(l_AccTypeFee)
        Dim l_BranchFee = "0" & dt.Rows(0)("GP_BNKSACC_NO").ToString.Substring(0, 3)
        sw.Write(l_BranchFee)
        sw.WriteLine()

        Dim line As Integer = 1
        Dim amt As Double
        Dim amt_split As Double = 2000000

        For Each dr As DataRow In dt.Rows

            amt = Convert.ToDecimal(dr("GP_AMOUNT2"))

            If amt > amt_split Then
                Dim c As Integer = 1
                Dim i As Integer
                i = Math.Ceiling(amt / amt_split)

                Do While c < i

                    GenDetail(sw, filename, dr, line, amt_split)

                    line = line + 1
                    c = c + 1
                Loop

                amt = amt - (amt_split * (c - 1))
                GenDetail(sw, filename, dr, line, amt.ToString("#############.000"))

                line = line + 1
            Else

                GenDetail(sw, filename, dr, line, amt.ToString("#############.000"))
                line = line + 1

            End If

        Next

        'Generate 999
        Dim l_RecordType9 = "999"
        sw.Write(l_RecordType9)
        Dim l_CrIntenalRef9 = "000001"
        sw.Write(l_CrIntenalRef9)
        Dim l_NoOf9 = cls.SumRowNo_M(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(6, "0") 'dt.Rows.Count.ToString.PadLeft(6, "0")
        sw.Write(l_NoOf9)
        Dim l_DrAmount9
        l_DrAmount9 = cls.SumAmountForGen(clsUtility.gConnGP, dt.Rows(0)("GP_EXPTOBANK_FILENME")).ToString.PadLeft(16, "0")
        sw.Write(l_DrAmount9)

        sw.WriteLine()
        sw.Close()

        InsertLog(IO.Path.GetFileName(filename), dt.Rows(0)("GP_PAIDDATE").ToString, dt.Rows.Count, Convert.ToInt16(l_NoOf9), dt.Rows(0)("GP_PAYMTH").ToString, dt.Rows(0)("GP_SUB_PAYMTH").ToString, Convert.ToDouble(l_DrAmount9), batchNo)
    End Sub
    Private Sub GenDetail(ByVal sw As StreamWriter, ByVal filename As String, ByVal dr As DataRow, ByVal line As Integer, ByVal amt As String)

        If InStr(amt.ToString, ".") Then
            amt = amt.Trim.Replace(".", "")
        Else
            amt = amt & "000"
        End If

        Dim l_RecordType3 = "003"
        sw.Write(l_RecordType3)
        Dim l_SeqOfCr = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr)

        Dim l_CrAccount
        If dr("GP_PAYMTH") = "M" Then
            l_CrAccount = dr("GP_PAYEE_BNKACCNO_NEW").ToString.PadRight(25, " ")
        Else
            l_CrAccount = "".PadRight(25, " ")
        End If
        sw.Write(l_CrAccount)
        Dim l_CrAmount = amt.ToString.PadLeft(16, "0")
        sw.Write(l_CrAmount)
        Dim l_CrCurrency = "THB"
        sw.Write(l_CrCurrency)
        Dim l_CrIntenalRef = "00000001"
        sw.Write(l_CrIntenalRef)
        Dim l_WHTPresent = "N"
        sw.Write(l_WHTPresent)
        Dim l_InvoicePresent = "N"
        sw.Write(l_InvoicePresent)
        Dim l_CrAdviceRequest = "N"
        sw.Write(l_CrAdviceRequest)
        Dim l_DeliveryMode = "P"
        sw.Write(l_DeliveryMode)
        Dim l_PicupLocation = "C002"
        sw.Write(l_PicupLocation)
        Dim l_WHTType = "00"
        sw.Write(l_WHTType)
        Dim l_WHTNo = "".PadRight(14, " ")
        sw.Write(l_WHTNo)
        Dim l_WHTAttNo = "000000"
        sw.Write(l_WHTAttNo)
        Dim l_WHTNoDetail = "00"
        sw.Write(l_WHTNoDetail)
        Dim l_WHTTotalAmt = "0000000000000000"
        sw.Write(l_WHTTotalAmt)
        Dim l_WHTNoInvoiceDetail = "000000"
        sw.Write(l_WHTNoInvoiceDetail)
        Dim l_WHTInvoiceAmt = "0000000000000000"
        sw.Write(l_WHTInvoiceAmt)
        Dim l_WHTPayType = "0"
        sw.Write(l_WHTPayType)
        Dim l_WHTRemark = "".PadRight(40, " ")
        sw.Write(l_WHTRemark)
        Dim l_WHTDeductDate = "".PadRight(8, " ")
        sw.Write(l_WHTDeductDate)
        Dim l_ReceiveBnkCode = dr("GP_BNKCODE_NO").ToString.PadRight(3, " ")
        sw.Write(l_ReceiveBnkCode)

        Dim l_ReceiveBnkName
        If dr("GP_BNKCODE") = "SCB" Then
            l_ReceiveBnkName = dr("BKMST_BNKNAME_ENG").ToString.PadRight(35, " ")
        Else
            l_ReceiveBnkName = dr("BKMST_BNKNAME").ToString.PadRight(35, " ")
        End If
        sw.Write(l_ReceiveBnkName.Substring(0, 35))

        Dim l_ReceiveBranchCode = dr("GP_BNKBRN_NEW").ToString.PadRight(4, " ")
        sw.Write(l_ReceiveBranchCode)

        Dim l_ReceiveBranchName
        If dr("GP_BNKCODE") = "SCB" Then
            l_ReceiveBranchName = "CHIDLOM BRANCH".PadRight(35, " ")
        Else
            l_ReceiveBranchName = "".PadRight(35, " ")
        End If
        sw.Write(l_ReceiveBranchName)

        Dim l_WHTSignatory = "".PadRight(1, " ")
        sw.Write(l_WHTSignatory)
        Dim l_ChqIssuance = "N"
        sw.Write(l_ChqIssuance)
        Dim l_ChqRefNo = dr("GP_CUSTREFNO").ToString.PadRight(20, " ")
        sw.Write(l_ChqRefNo)
        Dim l_ChqRefType = "3"
        sw.Write(l_ChqRefType)
        Dim l_PayTypeCode = "".PadRight(3, " ")
        sw.Write(l_PayTypeCode)

        Dim l_ServiceType
        If dr("GP_PAYMTH") = "M" Then
            l_ServiceType = "04"
        Else
            l_ServiceType = "".PadRight(2, " ")
        End If
        sw.Write(l_ServiceType)

        Dim l_002Remark = "".PadRight(68, " ")
        sw.Write(l_002Remark)
        Dim l_Bene_Flag = "".PadRight(2, " ")
        sw.Write(l_Bene_Flag)
        sw.WriteLine()


        'Generate 004
        Dim l_RecordType4 = "004"
        sw.Write(l_RecordType4)
        Dim l_CrIntenalRef4 = "00000001"
        sw.Write(l_CrIntenalRef4)
        Dim l_SeqOfCr4 = line.ToString.PadLeft(6, "0")
        sw.Write(l_SeqOfCr4)
        Dim l_PayeeIDCard = "".PadRight(15, " ")
        sw.Write(l_PayeeIDCard)

        Dim l_PayeeName
        If dr("GP_PAYMTH") = "M" Then
            l_PayeeName = dr("GP_PAYEE_BNKACCNME").ToString.PadRight(100, " ")
        Else
            l_PayeeName = dr("GP_PAYEE_NAME").ToString.PadRight(100, " ")
        End If
        sw.Write(l_PayeeName.ToString.Substring(0, 100))

        Dim l_Address1
        If dr("GP_PAYMTH") = "D" Then
            l_Address1 = dr("GP_ADDRESS1").ToString.PadRight(70, " ")
        Else
            l_Address1 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address1.ToString.Substring(0, 70))

        Dim l_Address2
        If dr("GP_PAYMTH") = "D" Then
            l_Address2 = dr("GP_DISTRICT").ToString.PadRight(70, " ")
        Else
            l_Address2 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address2)

        Dim l_Address3
        If dr("GP_PAYMTH") = "D" Then
            l_Address3 = dr("GP_PROVINCE").ToString.PadRight(70, " ")
        Else
            l_Address3 = "".PadRight(70, " ")
        End If
        sw.Write(l_Address3)

        Dim l_PayeeTaxId = "".PadRight(10, " ")
        sw.Write(l_PayeeTaxId)
        Dim l_PayeeNameEng = "".PadRight(70, " ")
        sw.Write(l_PayeeNameEng.ToString.Substring(0, 70))
        Dim l_PayeeFax = "".PadRight(10, " ")
        sw.Write(l_PayeeFax)
        Dim l_PayeeMobile = "".PadRight(10, " ")
        sw.Write(l_PayeeMobile)
        Dim l_PayeeEmail = "".PadRight(64, " ")
        sw.Write(l_PayeeEmail.ToString.Substring(0, 64))
        Dim l_PayeeNameThai = "".PadRight(100, " ")
        sw.Write(l_PayeeNameThai.ToString.Substring(0, 100))
        Dim l_Payee2Address1 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address1.ToString.Substring(0, 70))
        Dim l_Payee2Address2 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address2.ToString.Substring(0, 70))
        Dim l_Payee2Address3 = "".PadRight(70, " ")
        sw.Write(l_Payee2Address3.ToString.Substring(0, 70))

        sw.WriteLine()

    End Sub
    Private Sub InsertLog(ByVal filename As String, ByVal paiddate As String, ByVal tbrow As Integer, ByVal txtrow As Integer,
                          ByVal paymth As String, ByVal sub_paymth As String, ByVal amt As Double, ByVal batchNo As String)
        Dim table As New DataTable

        table.Columns.Add("GFLOG_BATCH_NO")
        table.Columns.Add("GFLOG_EXPTOBANK_DATE")
        table.Columns.Add("GFLOG_EXPTOBANK_FILENME")
        table.Columns.Add("GFLOG_PAYMTH")
        table.Columns.Add("GFLOG_SUB_PAYMTH")
        table.Columns.Add("GFLOG_PAIDDATE")
        table.Columns.Add("GFLOG_TOT_RECORD_TB")
        table.Columns.Add("GFLOG_TOT_RECORD_TXT")
        table.Columns.Add("GFLOG_TOT_AMOUNT")
        table.Columns.Add("CREATEDBY")
        table.Columns.Add("UPDATEDBY")


        Dim row As DataRow
        row = table.NewRow()

        row("GFLOG_BATCH_NO") = batchNo
        row("GFLOG_EXPTOBANK_DATE") = Now.ToString("yyyyMMdd")
        row("GFLOG_EXPTOBANK_FILENME") = filename.ToUpper.Replace(".TXT", "")
        row("GFLOG_PAYMTH") = paymth
        row("GFLOG_SUB_PAYMTH") = sub_paymth
        row("GFLOG_PAIDDATE") = paiddate
        row("GFLOG_TOT_RECORD_TB") = tbrow
        row("GFLOG_TOT_RECORD_TXT") = txtrow
        row("GFLOG_TOT_AMOUNT") = amt / 1000
        row("CREATEDBY") = gUserLogin
        row("UPDATEDBY") = gUserLogin

        table.Rows.Add(row)

        Dim oleTrans As OleDbTransaction
        oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec As Integer

        rec = cls.InsertLog(clsUtility.gConnGP, oleTrans, row)
        If rec = 1 Then
            oleTrans.Commit()
        Else
            oleTrans.Rollback()
        End If

    End Sub

    Private Sub GenGridReject(ByVal dt As DataTable)

        With dgvReject

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvReject.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cfileName
            .DataPropertyName = "payd_file_name"
            .Name = "ชื่อไฟล์"
            .Width = 160
            .ReadOnly = True
            dgvReject.Columns.Add(cfileName)

        End With

        Dim cPayNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayNo
            .DataPropertyName = "rjil_cust_ref"
            .Name = "Payment Number"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cPayNo)

        End With

        Dim cPayMth As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayMth
            .DataPropertyName = "rjil_paymth"
            .Name = "Payment Method"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cPayMth)
        End With

        Dim cBnkCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkCode
            .DataPropertyName = "bnkcde"
            .Name = "Bank Code"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cBnkCode)
        End With

        Dim cBnkAccNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkAccNo
            .DataPropertyName = "payd_3_c_acc_no"
            .Name = "Bank Account No"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cBnkAccNo)
        End With

        Dim cAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmt
            .DataPropertyName = "payd_3_c_amt_num"
            .Name = "Amount"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cAmt)
        End With

        Dim cPayDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayDate
            .DataPropertyName = "payment_date"
            .Name = "Payment Date"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cPayDate)
        End With

        Dim cRejectTye As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejectTye
            .DataPropertyName = "rejt_rej_type"
            .Name = "Payment Type"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cRejectTye)
        End With

        Dim cRejDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejDesc
            .DataPropertyName = "rejt_remark"
            .Name = "Reject Desc"
            .Width = 180
            .ReadOnly = True
            dgvReject.Columns.Add(cRejDesc)
        End With

    End Sub


    Private Sub btnBrowse_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowse.Click
        Dim sysdate As String = clsHashLO.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")

        Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))
        'If clsHashLO.checkRejectByDate(clsUtility.gConnGP, sysdate) Then

        OpenFileDialog1.Filter = "Excel Files(ACC*.xls)|ACC*" & strCurrentDate & "*.xls"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Title = "เลือกไฟล์ Reject"
        OpenFileDialog1.ShowDialog()

        'Else
        'MsgBox("มีการ Reject รายการจ่ายในวันนี้แล้ว ไม่สามารถ Reject ซ้ำได้...")
        'End If

    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        If (System.Windows.Forms.DialogResult.OK) Then
            ' If Files Identify Array
            Dim oleConn As OleDbConnection
            Dim oleTrans As OleDbTransaction
            Dim oleTransDelete1 As OleDbTransaction
            Dim oleTransDelete2 As OleDbTransaction
            Dim oleConnSelect As OleDbConnection
            Dim sysdate As String = clsHashLO.getSysDate(clsUtility.gConnGP) 'Now.ToString("yyyyMMdd")

            oleConn = clsUtility.gConnGP

            oleConnSelect = clsUtility.gConnGP_2
            oleTransDelete1 = oleConn.BeginTransaction
            clsHashLO.deleteFromGPSTempReject(oleConn, oleTransDelete1)
            oleTransDelete1.Commit()

            oleTrans = oleConn.BeginTransaction
            Dim file() As String
            Dim dt As DataTable
            Dim dtDup As DataTable
            file = OpenFileDialog1.FileNames
            Dim fullpathfile = String.Join(",", OpenFileDialog1.FileNames) 'fullpathfile2,fullpathfile2

            Dim strCurrentDate = sysdate.ToString(New CultureInfo("en-GB"))

            Dim custOld, custNew As String
            Dim sb As New StringBuilder
            Dim custDup As New StringBuilder
            Dim intCheckPaymentAndAmount As Integer

            LO_Dup.Clear()
            LO_Dup.Append("File Name         |PaymentNo|Amount").AppendLine()
            LO_Dup.Append("-----------------------------------").AppendLine()

            ' Read excel file and insert into PAYOUT_TMP_REJECT
            Dim xlApp As Excel.Application
            Dim xlWorkBook As Excel.Workbook
            Dim xlWorkSheet As Excel.Worksheet

            Try
                Dim countFile, count, countInsert, countDup As Integer
                countFile = 0
                count = 0
                countInsert = 0
                countDup = 0
                Dim payNo, payMth, bnkCde, accNo, amt, payDate, reasonOfReverse, fileName, payDateInsert, Core_System, TransRef, PaymentSeq, BillNo, PayeeName As String
                ' Split string based on spaces.
                Dim words As String() = fullpathfile.Split(New Char() {","c})
                ' Use For Each loop over words and display them.
                Dim word As String
                For Each word In words

                    fileName = Path.GetFileName(word)

                    If fileName.ToString.Contains(strCurrentDate) = False Then
                        Continue For
                    End If

                    xlApp = New Excel.Application
                    xlWorkBook = xlApp.Workbooks.Open(word)
                    xlWorkSheet = xlWorkBook.Worksheets(1)

                    'Check name
                    If Trim(xlWorkSheet.Cells(2, 1).value()).Equals("Payment Number") And _
                        Trim(xlWorkSheet.Cells(2, 2).value()).Equals("Payment Method " & vbLf & "(D/C/M)") And _
                        Trim(xlWorkSheet.Cells(2, 3).value()).Equals("Bank Code") And _
                        Trim(xlWorkSheet.Cells(2, 4).value()).Equals("Account Number") And _
                        Trim(xlWorkSheet.Cells(2, 5).value()).Equals("Amount") And _
                        Trim(xlWorkSheet.Cells(2, 6).value()).Equals("Payment Date" & vbLf & "(dd/mm/yyyy)" & vbLf & "(yyyy-คศ.)") And _
                        Trim(xlWorkSheet.Cells(2, 7).value()).Equals("Reason of Reverse") _
                        Then

                        'Trim(xlWorkSheet.Cells(2, 8).value()).Equals("System") And _
                        'Trim(xlWorkSheet.Cells(2, 9).value()).Equals("Transaction Reference") And _
                        'Trim(xlWorkSheet.Cells(2, 10).value()).Equals("Payment Seq") And _
                        'Trim(xlWorkSheet.Cells(2, 11).value()).Equals("Bill No") And _
                        'Trim(xlWorkSheet.Cells(2, 12).value()).Equals("Payee Name")

                        '-----------------------
                        '-- Check file format --
                        '-----------------------
                        Dim row As Integer = 3
                        Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing
                            payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                            payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                            bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                            accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                            amt = xlWorkSheet.Cells(row, 5).value & "" 'column 5
                            payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                            reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7

                            Core_System = "" '--xlWorkSheet.Cells(row, 8).value & "" 'column 8
                            TransRef = "" '--xlWorkSheet.Cells(row, 9).value & "" 'column 9
                            PaymentSeq = "" '--xlWorkSheet.Cells(row, 10).value & "" 'column 10
                            BillNo = "" '--xlWorkSheet.Cells(row, 11).value & "" 'column 11
                            PayeeName = "" '--xlWorkSheet.Cells(row, 12).value & "" 'column 12


                            If Not (payMth.ToString.Contains("C") Or payMth.ToString.Contains("D") Or payMth.ToString.Contains("M")) _
                                Or Not IsDate(payDate) _
                                Or Not IsNumeric(amt) _
                                Or payDate.Length <> 10 Then

                                xlWorkBook.Close()
                                'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".")(0).ToString & "_reject." & word.ToString.Split(".")(1).ToString)
                                If clsHashLO.RenameFile_RejectByFile(word.ToString) <> "-1" Then
                                    LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                                Else
                                    xlApp.Quit()
                                    releaseObject(xlApp)
                                    releaseObject(xlWorkBook)
                                    releaseObject(xlWorkSheet)
                                    oleTrans.Rollback()
                                    MsgBox("ไม่สามารถ Rename Reject File, กรุณาติดต่อผู้ดูแลระบบ", MsgBoxStyle.Critical)
                                    Exit Try
                                End If
                                Continue For
                            End If
                            row = row + 1
                        Loop

                        '------------------------------
                        '-- Check duplicate same day --
                        '------------------------------
                        row = 3
                        Do Until xlWorkSheet.Cells(row, 1).Value Is Nothing

                            'payNo = xlWorkSheet.Cells(row, 1).value 'column 1
                            'payMth = xlWorkSheet.Cells(row, 2).value 'column 2
                            'bnkCde = xlWorkSheet.Cells(row, 3).value 'column 3
                            'accNo = xlWorkSheet.Cells(row, 4).value 'column 4
                            'amt = xlWorkSheet.Cells(row, 5).value 'column 5
                            'payDate = xlWorkSheet.Cells(row, 6).value 'column 6
                            'reasonOfReverse = xlWorkSheet.Cells(row, 7).value 'column 7

                            payNo = xlWorkSheet.Cells(row, 1).value & "" 'column 1
                            payMth = xlWorkSheet.Cells(row, 2).value & "" 'column 2
                            bnkCde = xlWorkSheet.Cells(row, 3).value & ""  'column 3
                            accNo = xlWorkSheet.Cells(row, 4).value & "" 'column 4
                            amt = xlWorkSheet.Cells(row, 5).value 'column 5
                            payDate = xlWorkSheet.Cells(row, 6).value & "" 'column 6
                            reasonOfReverse = xlWorkSheet.Cells(row, 7).value & "" 'column 7

                            Core_System = "" '--xlWorkSheet.Cells(row, 8).value & "" 'column 8
                            TransRef = "" '--xlWorkSheet.Cells(row, 9).value & "" 'column 9
                            PaymentSeq = "" '--xlWorkSheet.Cells(row, 10).value & "" 'column 10
                            BillNo = "" '--xlWorkSheet.Cells(row, 11).value & "" 'column 11
                            PayeeName = "" '--xlWorkSheet.Cells(row, 12).value & "" 'column 12

                            payDateInsert = payDate.Substring(6, 4) & payDate.Substring(3, 2) & payDate.Substring(0, 2)

                            Dim rec As Integer = clsHashLO.insertIntoGPSTempReject(oleConn, oleTrans, sysdate, fileName, reasonOfReverse, payMth, bnkCde, _
                                                           accNo, payNo, amt, "", payDateInsert, Core_System, TransRef, Val(PaymentSeq), BillNo, PayeeName)

                            If countDup > 0 Then
                                custDup.Append(",")
                            End If
                            If rec = -1 Then
                                custDup.Append(payNo)
                                LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Duplicated").AppendLine()
                                countDup = countDup + 1
                            Else

                                'cls.deletePayoutTempRejectByFileName(oleConn, oleTransDelete2, fileName)
                                'My.Computer.FileSystem.RenameFile(word.ToString, word.ToString.Split(".").ToString & "_reject." & word.ToString.Split(".").ToString)
                                'LO_Dup.Append(fileName & "|File rejected (format error)").AppendLine()
                                intCheckPaymentAndAmount = 0
                                intCheckPaymentAndAmount = clsHashLO.CheckGPSInvalidPaymentAndAmount(oleConnSelect, strCurrentDate, payNo, payMth, CDbl(amt))
                                Select Case intCheckPaymentAndAmount
                                    Case 0 '-- valid
                                        '-- no action
                                    Case 1 '-- invalid payment number / Payment number not found      
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| Payment number not found").AppendLine()
                                    Case 2 '-- invalid payment method      
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method").AppendLine()
                                    Case 3 '-- invalid payment amount
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment amount").AppendLine()
                                    Case 4 '-- invalid 1 & 2
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid payment method and amount").AppendLine()
                                    Case Else '-- unknow error
                                        LO_Dup.Append(fileName & "|" & payNo & "|" & amt & "| System will be cancel transaction, but invalid other condition").AppendLine()
                                End Select
                            End If

                            count = count + 1
                            row += 1
                        Loop

                    Else
                        MsgBox("รูปแบบไฟล์ไม่ถูกต้อง")

                        xlWorkBook.Application.DisplayAlerts = False

                        xlWorkBook.Close()
                        xlApp.Quit()

                        releaseObject(xlApp)
                        releaseObject(xlWorkBook)
                        releaseObject(xlWorkSheet)

                        oleTrans.Rollback()

                        Exit Sub
                    End If

                    xlWorkBook.Application.DisplayAlerts = False

                    xlWorkBook.Close()
                    xlApp.Quit()

                    releaseObject(xlApp)
                    releaseObject(xlWorkBook)
                    releaseObject(xlWorkSheet)

                    countFile = countFile + 1
                Next

                oleTrans.Commit()

            Catch ex As Exception
                xlWorkBook.Close()
                xlApp.Quit()

                releaseObject(xlApp)
                releaseObject(xlWorkBook)
                releaseObject(xlWorkSheet)
                MsgBox(ex.ToString)
                oleTrans.Rollback()
                Exit Sub
            End Try

            'xxx Delete Dupicate payment no
            Dim iTemp As Integer
            'clsHashLO
            dtDup = clsHashLO.CheckDuplicateGPSRejLog(oleConn)
            sDataExist.Clear()
            If Not IsNothing(dtDup) AndAlso dtDup.Rows.Count > 0 Then
                For Each row As DataRow In dtDup.Rows
                    sb.Append("'")
                    sb.Append(row.Item(0))
                    sb.Append("'")
                    sDataExist.Append(row.Item(1).ToString & "" & "|" & row.Item(0).ToString & "" & "| Data exist!").AppendLine()
                Next
                oleTransDelete2 = oleConn.BeginTransaction
                Try
                    clsHashLO.deleteGPSTempRejectByCustref(oleConn, oleTransDelete2, custDup.ToString)
                    oleTransDelete2.Commit()
                Catch ex As Exception
                    oleTransDelete2.Rollback()
                End Try
                MsgBox("Duplicate old data!" & vbCrLf & vbCrLf & sDataExist.ToString)
            End If

            If LO_Dup.ToString.Split(vbCrLf).Length > 3 Then
                MsgBox("Duplicate in excel file / Excel format error !!" & vbCrLf & vbCrLf & LO_Dup.ToString)
            End If
            dt = clsHashLO.generateDataForHashTotalGPS(oleConn, sysdate)
            GenGrid_dgvReject(dt)

            Dim sumAmt As Double
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                For Each rowSum As DataRow In dt.Rows
                    sumAmt = sumAmt + rowSum("gp_amount")
                Next
            End If

            '--txtTotalAmtLO.Text = sumAmt.ToString("F", CultureInfo.InvariantCulture)

        End If

    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub GenGrid_dgvReject(ByVal dt As DataTable)

        With dgvReject

            .DataSource = dt
            .Columns.Clear()

            .RowHeadersVisible = False
            .DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 245, 240)
            .DefaultCellStyle.SelectionForeColor = Color.FromArgb(232, 119, 34)
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Regular)
            .AutoGenerateColumns = False
            .AllowUserToAddRows = False
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .AllowUserToResizeColumns = False
            .RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty
            .RowsDefaultCellStyle.BackColor = Color.White
            '.AlternatingRowsDefaultCellStyle.BackColor = Color.LemonChiffon
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
            .BackgroundColor = Color.LightGray


        End With
        'DataGridView Header Style
        With dgvReject.ColumnHeadersDefaultCellStyle
            .Alignment = DataGridViewContentAlignment.MiddleCenter
            .BackColor = Color.FromArgb(232, 119, 34)
            .ForeColor = Color.White
            .Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        End With

        Dim cfileName As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cfileName
            .DataPropertyName = "gp_exptobank_filenme"
            .Name = "ชื่อไฟล์"
            .Width = 160
            .ReadOnly = True
            dgvReject.Columns.Add(cfileName)

        End With

        Dim cPayNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayNo
            .DataPropertyName = "rj_cust_ref"
            .Name = "Payment Number"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cPayNo)

        End With

        Dim cPayMth As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayMth
            .DataPropertyName = "rj_paymth"
            .Name = "Payment Method"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cPayMth)
        End With

        Dim cBnkCode As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkCode
            .DataPropertyName = "bnkcde"
            .Name = "Bank Code"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cBnkCode)
        End With

        Dim cBnkAccNo As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cBnkAccNo
            .DataPropertyName = "gp_payee_bnkaccno"
            .Name = "Bank Account No"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cBnkAccNo)
        End With

        Dim cAmt As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cAmt
            .DataPropertyName = "gp_amount"
            .Name = "Amount"
            .Width = 100
            .ReadOnly = True
            dgvReject.Columns.Add(cAmt)
        End With

        Dim cPayDate As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cPayDate
            .DataPropertyName = "payment_date"
            .Name = "Payment Date"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cPayDate)
        End With

        Dim cRejectTye As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejectTye
            .DataPropertyName = "rejt_rej_type"
            .Name = "Payment Type"
            .Width = 120
            .ReadOnly = True
            dgvReject.Columns.Add(cRejectTye)
        End With

        Dim cRejDesc As DataGridViewColumn = New DataGridViewTextBoxColumn()
        With cRejDesc
            .DataPropertyName = "rejt_remark"
            .Name = "Reject Desc"
            .Width = 180
            .ReadOnly = True
            dgvReject.Columns.Add(cRejDesc)
        End With

    End Sub

    Private Sub InitializeOpenFileDialog()
        Dim pathLO As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "ACCCANCELFILE_PATH")
        ' Set the file dialog to filter for graphics files.
        Me.OpenFileDialog1.Filter = _
                "Excel (ACC*.xls)|ACC*.xls" '+ "All files (*.*)|*.*"

        ' Allow the user to select multiple images.
        Me.OpenFileDialog1.Multiselect = True
        Me.OpenFileDialog1.Title = "My Excel Browser"
        Me.OpenFileDialog1.InitialDirectory = pathLO 'PRD Path
        'Me.OpenFileDialog1.InitialDirectory = "D:\Work_SCB\GPS\Work_201509\Test\"
    End Sub

    Private Sub btnConfirm_Click(sender As System.Object, e As System.EventArgs) Handles btnConfirm.Click
        If MessageBox.Show("Confirm Auto FTP [y/n] ?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            Exit Sub
        Else
            Dim oleConn As OleDbConnection
            oleConn = clsUtility.gConnGP
            Dim path As String = clsHashLO.getFtpPath(oleConn)
            Dim outputPath As String = clsHashLO.getOutputPath(oleConn)
            Dim ctrlPath As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH")
            Dim importDate As String = clsHashLO.getImportDate(oleConn)
            Dim importRound As String = clsHashLO.getImportRound(oleConn)
            Dim fileName As String = "GPAuto" & "_" & importDate & "_" & importRound.PadLeft(2, "0")
            Dim tempDir As String = "temp\"
            If System.IO.Directory.Exists(tempDir) Then
                System.IO.Directory.Delete(tempDir, True)
            End If
            System.IO.Directory.CreateDirectory(tempDir)
            Dim fs As FileStream = File.Create(tempDir & fileName & ".txt")
            Dim dt As DataTable
            dt = cls.getOutputFileName(oleConn)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim sb As New StringBuilder
                Dim outputFilename As String
                Dim outputFilenameCtrl As String
                For Each row As DataRow In dt.Rows
                    outputFilename = row("PAYM_FILENAME_OUT_TOBANK").ToString()
                    outputFilenameCtrl = outputFilename.Substring(0, outputFilename.IndexOf(".")) & ".ctrl"
                    sb.AppendLine(outputFilename)
                    sb.AppendLine(outputFilenameCtrl)
                    clsUtility.BackupFile(outputPath & outputFilename, path & outputFilename)
                    clsUtility.BackupFile(ctrlPath & outputFilenameCtrl, path & outputFilenameCtrl)
                Next
                Dim info As Byte() = New UTF8Encoding(True).GetBytes(sb.ToString())
                fs.Write(info, 0, info.Length)
                fs.Close()
                clsUtility.BackupFile(tempDir & fileName & ".txt", path & fileName & ".txt")
                btnConfirm.Enabled = False
                MsgBox("Confirm already.", MsgBoxStyle.Information)
            Else
                fs.Close()
                fs = Nothing
                dt = Nothing
                MsgBox("Payment file not found", MsgBoxStyle.Exclamation)
            End If
        End If
    End Sub

    Private Sub BtnCancel_Click(sender As System.Object, e As System.EventArgs) Handles BtnCancel.Click
        If MessageBox.Show("Cancel Auto FTP [y/n] ?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            Exit Sub
        Else
            Dim oleConn As OleDbConnection
            oleConn = clsUtility.gConnGP
            Dim path As String = clsHashLO.getFtpPath(oleConn)
            Dim importDate As String = clsHashLO.getImportDate(oleConn)
            Dim importRound As String = clsHashLO.getImportRound(oleConn)
            Dim fileNameGP As String = "GPAuto" & "_" & importDate & "_" & importRound.PadLeft(2, "0")
            Dim pathTo As String = clsBusiness.fnGet_pathconfig(oleConn, "GENPAYMFILE_PATH_BACKUP")
            Dim dt As DataTable
            dt = cls.getOutputFileName(oleConn)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim outputFilename As String
                For Each row As DataRow In dt.Rows
                    outputFilename = row("PAYM_FILENAME_OUT_TOBANK").ToString().Substring(0, row("PAYM_FILENAME_OUT_TOBANK").ToString().IndexOf("."))
                    clsUtility.BackupFile(clsHashLO.pathFrom(oleConn, outputFilename, path, ".txt"), clsHashLO.pathTo(oleConn, outputFilename, pathTo, ".tx_"))
                    clsUtility.BackupFile(clsHashLO.pathFrom(oleConn, outputFilename, path, ".ctrl"), clsHashLO.pathTo(oleConn, outputFilename, pathTo, ".ct_"))
                Next
            End If
            clsUtility.BackupFile(clsHashLO.pathFrom(oleConn, fileNameGP, path, ".txt"), clsHashLO.pathTo(oleConn, fileNameGP, pathTo, ".tx_"))
            MsgBox("Cancel Auto FTP Complete", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        Dim clsMNG_FILE As New clsManageFile
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""


        With clsMNG_FILE
            .OpenConnection(clsUtility.gConnGP _
                                   , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
                                   , system_code _
                                   , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                                   , server_1 _
                                   , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
                                   , 1 _
                                   , server_2)

            MsgBox("RUNAS_DOMAIN_SCHEMA: " & .RUNAS_DOMAIN_SCHEMA & vbCrLf _
                   & "RUNAS_US: " & .RUNAS_US & vbCrLf _
                   & "RUNAS_PW: " & .RUNAS_PW & vbCrLf _
                   & "RUNAS_ENCYPT_YN: " & .RUNAS_ENCPWD & vbCrLf _
                   & "ConvertToSecureString: " & .ConvertToSecureString(.RUNAS_PW).ToString & vbCrLf _
                   )
        End With

        '-- test rename --
        '-----------------
        'Source Path 
        Dim fPath As String = clsBusiness.fnGet_pathconfig(clsUtility.gConnGP, "GENPAYMFILE_PATH")

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = ".txt"
        Dim btnRename, blnMoveOrBackup As Boolean

        'Name .End
        Dim fileRename, fileFrom, fileEnd As New StringBuilder
        fileFrom.Append(txtRejectFile.Text)
        fileRename.Append(txtToFile.Text)

        btnRename = clsUtility.RenameFile(fileFrom.ToString _
                              , fileRename.ToString _
                                )
        If MsgBox("Rename : " & btnRename.ToString, MsgBoxStyle.Information + MsgBoxStyle.YesNo, "Rename & Move") = MsgBoxResult.Yes Then
            blnMoveOrBackup = clsUtility.BackupFile("" & txtRejectFile.Text & "", "" & txtToFile.Text & "")
            MsgBox("blnMoveOrBackup : " & blnMoveOrBackup.ToString)
        Else
            'My.Computer.FileSystem.RenameFile(txtRejectFile.Text, txtToFile.Text)
            'clsMNG_FILE.RenameFile(clsUtility.gConnGP _
            '                       , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
            '                       , system_code _
            '                       , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
            '                       , server_1 _
            '                       , fileFrom.ToString _
            '                       , fileRename.ToString _
            '                       , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
            '                       , 1 _
            '                       , server_2)
            'MsgBox(btnRename)

            'clsMNG_FILE.MovFile(clsUtility.gConnGP _
            '                       , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
            '                       , system_code _
            '                       , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
            '                       , server_1 _
            '                       , fileFrom.ToString _
            '                       , fileRename.ToString)

        End If


        fileEnd.Append(fPath)
        fileEnd.Append(fileRename.ToString)
        'fileEnd.Append(fileFrom.ToString) '-- CR#530

        Dim fullPathEnd As String = fileEnd.ToString

    End Sub

End Class