﻿Public Class FrmCallCLOSEPRT
    Private Sub FrmCALLClosePRT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Process.Start("""" & CALLClosePRT & """")
        Catch ex As Exception
            Me.Close()
        End Try
        Me.Close()
    End Sub
End Class