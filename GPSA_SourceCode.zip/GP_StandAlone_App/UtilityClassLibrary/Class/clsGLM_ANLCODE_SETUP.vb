﻿Imports System.Data.OleDb
Imports System.Text
Imports System.Configuration

Namespace DataClass

    Public Class clsGLM_ANLCODE_SETUP
        Private _conndb As New System.Data.OleDb.OleDbConnection
        Private _scheme As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Private _tablename As String = "GLM_ANLCODE_SETUP"
        Private _anl_name_en As String
        Private _anl_name_th As String
        Private _anl_name_type As String
        Private _anl_o_code As String
        Private _anl_pd_line As String
        Private _anl_s_code As String
        Private _anl_type As String
        Private _createdby As String
        Private _createddate As String
        Private _updatedby As String
        Private _updateddate As String
        Private _anl_1gl_code As String
        Private _anl_1gl_desc As String

        Public Property ConnDB As System.Data.OleDb.OleDbConnection
            Get
                ConnDB = _conndb
            End Get
            Set(value As System.Data.OleDb.OleDbConnection)
                _conndb = value
            End Set
        End Property

        Public Property ANL_TYPE As String
            Get
                ANL_TYPE = _anl_type
            End Get
            Set(value As String)
                _anl_type = value
            End Set
        End Property

        Public Property ANL_S_CODE As String
            Get
                ANL_S_CODE = _anl_s_code
            End Get
            Set(value As String)
                _anl_s_code = value
            End Set
        End Property

        Public Property ANL_NAME_TYPE As String
            Get
                ANL_NAME_TYPE = _anl_name_type
            End Get
            Set(value As String)
                _anl_name_type = value
            End Set
        End Property

        Public Property ANL_NAME_TH As String
            Get
                ANL_NAME_TH = _anl_name_th
            End Get
            Set(value As String)
                _anl_name_th = value
            End Set
        End Property

        Public Property ANL_NAME_EN As String
            Get
                ANL_NAME_EN = _anl_name_en
            End Get
            Set(value As String)
                _anl_name_en = value
            End Set
        End Property

        Public Property ANL_O_CODE As String
            Get
                ANL_O_CODE = _anl_o_code
            End Get
            Set(value As String)
                _anl_o_code = value
            End Set
        End Property

        Public Property CREATEDBY As String
            Get
                CREATEDBY = _createdby
            End Get
            Set(value As String)
                _createdby = value
            End Set
        End Property

        Public Property CREATEDDATE As String
            Get
                CREATEDDATE = _createddate
            End Get
            Set(value As String)
                _createddate = value
            End Set
        End Property

        Public Property UPDATEDBY As String
            Get
                UPDATEDBY = _updatedby
            End Get
            Set(value As String)
                _updatedby = value
            End Set
        End Property

        Public Property UPDATEDDATE As String
            Get
                UPDATEDDATE = _updateddate
            End Get
            Set(value As String)
                _updateddate = value
            End Set
        End Property

        Public Property ANL_PD_LINE As String
            Get
                ANL_PD_LINE = _anl_pd_line
            End Get
            Set(value As String)
                _anl_pd_line = value
            End Set
        End Property

        Public Property ANL_1GL_CODE As String
            Get
                ANL_1GL_CODE = _anl_1gl_code
            End Get
            Set(value As String)
                _anl_1gl_code = value
            End Set
        End Property

        Public Property ANL_1GL_DESC As String
            Get
                ANL_1GL_DESC = _anl_1gl_desc
            End Get
            Set(value As String)
                _anl_1gl_desc = value
            End Set
        End Property

        Public Function Insert() As Boolean
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("INSERT INTO ")
                .Append(_scheme & "." & _tablename)
                .Append(" VALUES(")
                .Append(" '" & _anl_type.Replace("'", "''") & "'") '-- anl_type
                .Append(", '" & _anl_s_code.Replace("'", "''") & "'") '-- anl_s_code
                .Append(", '" & _anl_name_th.Replace("'", "''") & "'") '-- anl_name_th 
                .Append(", '" & _anl_name_en.Replace("'", "''") & "'") '-- anl_name_en
                .Append(", '" & _anl_o_code.Replace("'", "''") & "'") '-- anl_o_code
                .Append(", '" & _createdby & "'") '-- createdby
                .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
                .Append(", '" & _updatedby & "'") '-- updatedby
                .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
                .Append(", '" & _anl_pd_line & "'") '-- anl_pd_line
                .Append(", '" & _anl_1gl_code & "'") '-- anl_1gl_code
                .Append(", '" & _anl_1gl_desc & "'") '-- anl_1gl_desc
                .Append(")")
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function Update() As Boolean
            Dim strSQL As New StringBuilder
            Dim strFldUpd As New StringBuilder
            With strSQL
                .Append("UPDATE ")
                .Append(_scheme & "." & _tablename)
                .Append(" SET ")
                If _anl_s_code.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_s_code = '" & _anl_s_code.Replace("'", "''") & "'") '-- _anl_s_code
                End If
                If _anl_name_th.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_name_th = '" & _anl_name_th.Replace("'", "''") & "'") '-- _anl_name_th
                End If
                If _anl_name_en.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_name_en = '" & _anl_name_en.Replace("'", "''") & "'") '-- _anl_name_en
                End If
                If _anl_o_code.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_o_code = '" & _anl_o_code.Replace("'", "''") & "'") '-- _anl_o_code
                End If
                If _updatedby.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" updatedby = '" & _updatedby & "'") '-- updatedby
                End If
                If _anl_pd_line.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_pd_line = '" & _anl_pd_line.Replace("'", "''") & "'") '-- _anl_pd_line
                End If
                If _anl_1gl_code.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_1gl_code = '" & _anl_1gl_code.Replace("'", "''") & "'") '-- _anl_1gl_code
                End If
                If _anl_1gl_desc.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" anl_1gl_desc = '" & _anl_1gl_desc.Replace("'", "''") & "'") '-- _anl_1gl_desc
                End If
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
                .Append(strFldUpd.ToString)
                .Append(" WHERE ")
                .Append(" anl_type = '" & _anl_type.Replace("'", "''") & "'") '-- anl_type
                .Append(" and anl_s_code = '" & _anl_s_code.Replace("'", "''") & "'") '-- anl_s_code 
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function Delete() As Boolean
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("DELETE FROM ")
                .Append(_scheme & "." & _tablename)
                .Append(" WHERE ")
                .Append(" anl_type = '" & _anl_type.Replace("'", "''") & "'") '-- anl_type
                .Append(" and anl_s_code = '" & _anl_s_code.Replace("'", "''") & "'") '-- anl_s_code 
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function GetRecord(ByRef strWhereCondition As String) As DataTable
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT * ")
                .Append("  FROM " & _scheme & "." & _tablename)
                If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                Return _dataset.Tables(0)
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function GetTCodeTypeRecord() As DataTable
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT DISTINCT ANL_TYPE")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" ORDER BY ANL_TYPE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                Return _dataset.Tables(0)
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_CC_By_DepBrn(ByRef strDepBrn As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_1GL_CODE, ANL_1GL_DESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'DEPB' AND ANL_S_CODE = '" & strDepBrn & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_1gl_code = _dataset.Tables(0).Rows(0).Item(0).ToString
                _anl_1gl_desc = _dataset.Tables(0).Rows(0).Item(1).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_AnalysisDesc_By_Code(ByRef strCode As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_NAME_TH ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'ANLC' AND ANL_S_CODE = '" & strCode & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_s_code = strCode
                _anl_name_th = _dataset.Tables(0).Rows(0).Item(0).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_InterCompanyDesc_By_Code(ByRef strCode As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_NAME_TH ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'INCO' AND ANL_S_CODE = '" & strCode & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_s_code = strCode
                _anl_name_th = _dataset.Tables(0).Rows(0).Item(0).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_Channel_By_MKTG(ByRef strMKTG As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_1GL_CODE, ANL_1GL_DESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'MKTG' AND ANL_S_CODE = '" & strMKTG & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_1gl_code = _dataset.Tables(0).Rows(0).Item(0).ToString
                _anl_1gl_desc = _dataset.Tables(0).Rows(0).Item(1).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_Product_By_PLPT(ByRef strPLPT As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_1GL_CODE, ANL_1GL_DESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'PLPT' AND ANL_S_CODE = '" & strPLPT & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_1gl_code = _dataset.Tables(0).Rows(0).Item(0).ToString
                _anl_1gl_desc = _dataset.Tables(0).Rows(0).Item(1).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_Project_By_PROJ(ByRef strPROJ As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_1GL_CODE, ANL_1GL_DESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'PROJ' AND ANL_S_CODE = '" & strPROJ & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_1gl_code = _dataset.Tables(0).Rows(0).Item(0).ToString
                _anl_1gl_desc = _dataset.Tables(0).Rows(0).Item(1).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_TTTR_By_Code(ByRef strCode As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ANL_NAME_TH ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ANL_TYPE = 'TTTR' AND ANL_S_CODE = '" & strCode & "' ")
                .Append(" ORDER BY ANL_TYPE, ANL_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _anl_1gl_code = strCode
                _anl_1gl_desc = _dataset.Tables(0).Rows(0).Item(0).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

    End Class
End Namespace
