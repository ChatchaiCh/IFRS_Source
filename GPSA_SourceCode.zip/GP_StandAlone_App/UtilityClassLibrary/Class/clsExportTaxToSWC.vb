﻿Imports System.Data.OleDb
Imports System.Text
Imports UtilityClassLibrary

Public Class clsGPS_TAXSWC_TAXTYPE_SETUP

    Private _ConnDB As System.Data.OleDb.OleDbConnection
    Private _scheme As String = "GENERATEPAYMENT"
    Private _tablename As String = "GPS_TAXSWC_TAXTYPE_SETUP"
    Private _ID As Integer
    Private _TAX_TYPE_NAME As String
    Private _TAX_TYPE_NAME_TH As String
    Private _CREATEDBY As String
    Private _CREATEDDATE As String
    Private _UPDATEDBY As String
    Private _UPDATEDDATE As String
    Private clsBusiness As UtilityClassLibrary.BusinessLayer
    Private clsUtility As UtilityClassLibrary.ConnectDB
    Private _FLAG_ISYEARLY As String
    Private _FILE_START_NORMAL_SEQ As Integer
    Private _FILE_START_OUTMTH_SEQ As Integer

    Public Property ConnDB As System.Data.OleDb.OleDbConnection
        Get
            ConnDB = _ConnDB
        End Get
        Set(value As System.Data.OleDb.OleDbConnection)
            _ConnDB = value
        End Set
    End Property

    Public Property CREATEDBY As String
        Get
            CREATEDBY = _CREATEDBY

        End Get
        Set(value As String)
            _CREATEDBY = value

        End Set
    End Property

    Public Property CREATEDDATE As String
        Get
            CREATEDDATE = _CREATEDDATE

        End Get
        Set(value As String)
            _CREATEDDATE = value
        End Set
    End Property

    Public Property ID As Integer
        Get
            ID = _ID

        End Get
        Set(value As Integer)
            _ID = value

        End Set
    End Property

    Public Property TAX_TYPE_NAME As String
        Get
            TAX_TYPE_NAME = _TAX_TYPE_NAME
        End Get
        Set(value As String)
            _TAX_TYPE_NAME = value
        End Set
    End Property

    Public Property TAX_TYPE_NAME_TH As String
        Get
            TAX_TYPE_NAME_TH = _TAX_TYPE_NAME_TH
        End Get
        Set(value As String)
            _TAX_TYPE_NAME_TH = value
        End Set
    End Property

    Public Property UPDATEDBY As String
        Get
            UPDATEDBY = _UPDATEDBY
        End Get
        Set(value As String)
            _UPDATEDBY = value
        End Set
    End Property

    Public Property UPDATEDDATE As String
        Get
            UPDATEDDATE = _UPDATEDDATE
        End Get
        Set(value As String)
            _UPDATEDDATE = value
        End Set
    End Property

    Public Property FLAG_ISYEARLY As String
        Get
            FLAG_ISYEARLY = _FLAG_ISYEARLY
        End Get
        Set(value As String)
            _FLAG_ISYEARLY = value
        End Set
    End Property

    Public Property FILE_START_OUTMTH_SEQ As Integer
        Get
            FILE_START_OUTMTH_SEQ = _FILE_START_OUTMTH_SEQ
        End Get
        Set(value As Integer)
            _FILE_START_OUTMTH_SEQ = value
        End Set
    End Property

    Public Property FILE_START_NORMAL_SEQ As Integer
        Get
            FILE_START_NORMAL_SEQ = _FILE_START_NORMAL_SEQ
        End Get
        Set(value As Integer)
            _FILE_START_NORMAL_SEQ = value
        End Set
    End Property

    Public Function Insert() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("INSERT INTO ")
            .Append(_scheme & "." & _tablename)
            .Append(" VALUES(")
            .Append(" " & _ID.ToString & "") '-- 
            .Append(", '" & _TAX_TYPE_NAME.Replace("'", "''") & "'") '-- 
            .Append(", '" & _TAX_TYPE_NAME_TH.Replace("'", "''") & "'") '--  
            .Append(", " & _FILE_START_NORMAL_SEQ.ToString & "") '--  
            .Append(", " & _FILE_START_OUTMTH_SEQ.ToString & "") '--  
            .Append(", '" & _FLAG_ISYEARLY.Replace("'", "''") & "'") '--  
            .Append(", '" & _CREATEDBY & "'") '-- createdby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
            .Append(", '" & _UPDATEDBY & "'") '-- updatedby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(")")
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function Update() As Boolean

        Dim strSQL As New StringBuilder
        Dim strFldUpd As New StringBuilder
        With strSQL
            .Append("UPDATE ")
            .Append(_scheme & "." & _tablename)
            .Append(" SET ")
            strFldUpd.Append(" TAX_TYPE_NAME = '" & _TAX_TYPE_NAME.Replace("'", "''") & "'") '-- _TAX_TYPE_NAME
            strFldUpd.Append(", TAX_TYPE_NAME_TH = '" & _TAX_TYPE_NAME_TH.Replace("'", "''") & "'") '-- _TAX_TYPE_NAME_TH
            strFldUpd.Append(", FILE_START_NORMAL_SEQ = " & _FILE_START_NORMAL_SEQ & "") '-- _FILE_START_NORMAL_SEQ
            strFldUpd.Append(", FILE_START_OUTMTH_SEQ = " & _FILE_START_OUTMTH_SEQ & "") '-- _FILE_START_OUTMTH_SEQ
            strFldUpd.Append(", FLAG_ISYEARLY = '" & _FLAG_ISYEARLY & "'") '-- _FLAG_ISYEARLY
            strFldUpd.Append(" updatedby = '" & _UPDATEDBY & "'") '-- updatedby
            strFldUpd.Append(" UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(strFldUpd.ToString)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- ID
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function Delete() As Boolean

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("DELETE FROM ")
            .Append(_scheme & "." & _tablename)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function GetRecord(ByRef strWhereCondition As String) As DataTable

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
            .Append(" ORDER BY ID")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0)
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try

    End Function

    Public Function GetTaxTypeID(ByRef strTaxTypeCode As String) As Integer

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" WHERE tax_type_code = '" & strTaxTypeCode & "'")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0).Rows(0).Item("id")
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try

    End Function

    Public Function GetTaxTypeIsYearly(ByRef strTaxTypeCode As String) As String

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" WHERE tax_type_code = '" & strTaxTypeCode & "'")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0).Rows(0).Item("flag_isyearly").tostring
        Catch ex As Exception
            Throw ex
            Return String.Empty
        End Try

    End Function

End Class


Public Class clsGPS_TAXSWC_FORMAT_SETUP
    Private _ConnDB As System.Data.OleDb.OleDbConnection
    Private _scheme As String = "GENERATEPAYMENT"
    Private _tablename As String = "GPS_TAXSWC_FORMAT_SETUP"
    Private clsBusiness As UtilityClassLibrary.BusinessLayer
    Private clsUtility As UtilityClassLibrary.ConnectDB
    Private _ID As Integer
    Private _TAX_TYPE As Integer
    Private _LINE_TYPE As String
    Private _LINE_SEQ As Integer
    Private _FIELD_NAME As String
    Private _FIELD_DESC As String
    Private _DATA_TYPE As String
    Private _FIELD_LENGTH As Integer
    Private _FIELD_DECIMAL As Integer
    Private _REQUIRE As String
    Private _REQUIRE_MEDIA As String
    Private _REQUIRE_SWC_INTERNET As String
    Private _DEFAULT_VALUE As String
    Private _REMARK As String
    Private _CREATEDBY As String
    Private _CREATEDDATE As String
    Private _UPDATEDBY As String
    Private _UPDATEDDATE As String
    Private _FIELD_MAPPING As String
    Private _FIELD_FORMAT As String
    Private _FLAG_SUM As String
    Private _FLAG_LEN_ERROR_ISEMPTY As String

    Public Property ConnDB As System.Data.OleDb.OleDbConnection
        Get
            ConnDB = _ConnDB
        End Get
        Set(value As System.Data.OleDb.OleDbConnection)
            _ConnDB = value
        End Set
    End Property

    Public Property ID As Integer
        Get
            ID = _ID
        End Get
        Set(value As Integer)
            _ID = value
        End Set
    End Property

    Public Property TAX_TYPE As Integer
        Get
            TAX_TYPE = _TAX_TYPE
        End Get
        Set(value As Integer)
            _TAX_TYPE = value
        End Set
    End Property

    Public Property LINE_TYPE As String
        Get
            LINE_TYPE = _LINE_TYPE
        End Get
        Set(value As String)

        End Set
    End Property

    Public Property LINE_SEQ As Integer
        Get
            LINE_SEQ = _LINE_SEQ
        End Get
        Set(value As Integer)
            _LINE_SEQ = value
        End Set
    End Property

    Public Property FIELD_NAME As String
        Get
            FIELD_NAME = _FIELD_NAME
        End Get
        Set(value As String)
            _FIELD_NAME = value
        End Set
    End Property

    Public Property FIELD_DESC As String
        Get
            FIELD_DESC = _FIELD_DESC
        End Get
        Set(value As String)
            _FIELD_DESC = value
        End Set
    End Property

    Public Property DATA_TYPE As String
        Get
            DATA_TYPE = _DATA_TYPE
        End Get
        Set(value As String)
            _DATA_TYPE = value
        End Set
    End Property

    Public Property FIELD_LENGTH As Integer
        Get
            FIELD_LENGTH = _FIELD_LENGTH
        End Get
        Set(value As Integer)
            _FIELD_LENGTH = value
        End Set
    End Property

    Public Property FIELD_DECIMAL As Integer
        Get
            FIELD_DECIMAL = _FIELD_DECIMAL
        End Get
        Set(value As Integer)
            _FIELD_DECIMAL = value
        End Set
    End Property

    Public Property REQUIRE As String
        Get
            REQUIRE = _REQUIRE
        End Get
        Set(value As String)
            _REQUIRE = value
        End Set
    End Property

    Public Property REQUIRE_MEDIA As String
        Get
            REQUIRE_MEDIA = _REQUIRE_MEDIA
        End Get
        Set(value As String)
            _REQUIRE_MEDIA = value
        End Set
    End Property

    Public Property REQUIRE_SWC_INTERNET As String
        Get
            REQUIRE_SWC_INTERNET = _REQUIRE_SWC_INTERNET
        End Get
        Set(value As String)
            _REQUIRE_SWC_INTERNET = value
        End Set
    End Property

    Public Property DEFAULT_VALUE As String
        Get
            DEFAULT_VALUE = _DEFAULT_VALUE
        End Get
        Set(value As String)
            _DEFAULT_VALUE = value
        End Set
    End Property

    Public Property REMARK As String
        Get
            REMARK = _REMARK
        End Get
        Set(value As String)
            _REMARK = value
        End Set
    End Property

    Public Property CREATEDBY As String
        Get
            CREATEDBY = _CREATEDBY
        End Get
        Set(value As String)
            _CREATEDBY = value
        End Set
    End Property

    Public Property CREATEDDATE As String
        Get
            CREATEDDATE = _CREATEDDATE
        End Get
        Set(value As String)
            _CREATEDDATE = value
        End Set
    End Property

    Public Property UPDATEDBY As String
        Get
            UPDATEDBY = _UPDATEDBY
        End Get
        Set(value As String)
            _UPDATEDBY = value
        End Set
    End Property

    Public Property UPDATEDDATE As String
        Get
            UPDATEDDATE = _UPDATEDDATE
        End Get
        Set(value As String)
            _UPDATEDDATE = value
        End Set
    End Property

    Public Property FIELD_MAPPING As String
        Get
            FIELD_MAPPING = _FIELD_MAPPING
        End Get
        Set(value As String)
            _FIELD_MAPPING = value
        End Set
    End Property

    Public Property FIELD_FORMAT As String
        Get
            FIELD_FORMAT = _FIELD_FORMAT
        End Get
        Set(value As String)
            _FIELD_FORMAT = value
        End Set
    End Property

    Public Property FLAG_SUM As String
        Get
            FLAG_SUM = _FLAG_SUM
        End Get
        Set(value As String)
            _FLAG_SUM = value
        End Set
    End Property

    Public Property FLAG_LEN_ERROR_ISEMPTY As String
        Get
            FLAG_LEN_ERROR_ISEMPTY = _FLAG_LEN_ERROR_ISEMPTY
        End Get
        Set(value As String)
            _FLAG_LEN_ERROR_ISEMPTY = value
        End Set
    End Property


    Public Function Insert() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("INSERT INTO ")
            .Append(_scheme & "." & _tablename)
            .Append(" VALUES(")
            .Append(" " & _ID.ToString & "") '-- 
            .Append(", " & _TAX_TYPE.ToString & "") '-- 
            .Append(", '" & _LINE_TYPE.Replace("'", "''") & "'") '--  
            .Append(", " & _LINE_SEQ.ToString & "") '-- 
            .Append(", '" & _FIELD_NAME.Replace("'", "''") & "'") '-- 
            .Append(", '" & _FIELD_DESC.Replace("'", "''") & "'") '-- 
            .Append(", '" & _DATA_TYPE.Replace("'", "''") & "'") '-- 
            .Append(", " & _FIELD_LENGTH.ToString & "") '-- 
            .Append(", " & _FIELD_DECIMAL.ToString & "") '-- 
            .Append(", '" & _REQUIRE.Replace("'", "''") & "'") '-- 
            .Append(", '" & _REQUIRE_MEDIA.Replace("'", "''") & "'") '-- 
            .Append(", '" & _REQUIRE_SWC_INTERNET.Replace("'", "''") & "'") '-- 
            .Append(", '" & _DEFAULT_VALUE.Replace("'", "''") & "'") '-- 
            .Append(", '" & _FIELD_MAPPING.Replace("'", "''") & "'") '-- 
            .Append(", '" & _FIELD_FORMAT.Replace("'", "''") & "'") '-- 
            .Append(", '" & _FLAG_SUM.Replace("'", "''") & "'") '-- 
            .Append(", '" & _FLAG_LEN_ERROR_ISEMPTY.Replace("'", "''") & "'") '-- 
            .Append(", '" & _REMARK.Replace("'", "''") & "'") '-- 
            .Append(", '" & _CREATEDBY & "'") '-- createdby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
            .Append(", '" & _UPDATEDBY & "'") '-- updatedby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(")")
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function Update() As Boolean
        Dim strSQL As New StringBuilder
        Dim strFldUpd As New StringBuilder
        With strSQL
            .Append("UPDATE ")
            .Append(_scheme & "." & _tablename)
            .Append(" SET ")
            strFldUpd.Append(" TAX_TYPE = " & _TAX_TYPE.ToString & "") '-- _TAX_TYPE
            strFldUpd.Append(", LINE_TYPE = '" & _LINE_TYPE.Replace("'", "''") & "'") '-- _LINE_TYPE
            strFldUpd.Append(", LINE_SEQ = " & _LINE_SEQ.ToString & "") '-- _LINE_SEQ
            strFldUpd.Append(", FIELD_NAME = '" & _FIELD_NAME.Replace("'", "''") & "'") '-- _FIELD_NAME
            strFldUpd.Append(", FIELD_DESC = '" & _FIELD_DESC.Replace("'", "''") & "'") '-- _FIELD_DESC
            strFldUpd.Append(", DATA_TYPE = '" & _DATA_TYPE.Replace("'", "''") & "'") '-- _DATA_TYPE
            strFldUpd.Append(", FIELD_LENGTH =" & _FIELD_LENGTH.ToString & "") '-- _FIELD_LENGTH
            strFldUpd.Append(", FIELD_DECIMAL = '" & _FIELD_DECIMAL.ToString & "") '-- _FIELD_DECIMAL
            strFldUpd.Append(", REQUIRE = '" & _REQUIRE.Replace("'", "''") & "'") '-- _REQUIRE
            strFldUpd.Append(", REQUIRE_MEDIA = '" & _REQUIRE_MEDIA.Replace("'", "''") & "'") '-- _REQUIRE_MEDIA
            strFldUpd.Append(", REQUIRE_SWC_INTERNET = '" & _REQUIRE_SWC_INTERNET.Replace("'", "''") & "'") '-- _REQUIRE_SWC_INTERNET
            strFldUpd.Append(", DEFAULT_VALUE = '" & _DEFAULT_VALUE.Replace("'", "''") & "'") '-- _DEFAULT_VALUE
            strFldUpd.Append(", FIELD_MAPPING = '" & _FIELD_MAPPING.Replace("'", "''") & "'") '-- _FIELD_MAPPING
            strFldUpd.Append(", FIELD_FORMAT = '" & _FIELD_FORMAT.Replace("'", "''") & "'") '-- _FIELD_FORMAT
            strFldUpd.Append(", FLAG_SUM = '" & _FLAG_SUM.Replace("'", "''") & "'") '-- _FLAG_SUM
            strFldUpd.Append(", FLAG_LEN_ERROR_ISEMPTY = '" & _FLAG_LEN_ERROR_ISEMPTY.Replace("'", "''") & "'") '-- _FLAG_LEN_ERROR_ISEMPTY
            strFldUpd.Append(", REMARK = '" & _REMARK.Replace("'", "''") & "'") '-- _REMARK
            strFldUpd.Append(", UPDATEDBY = '" & _UPDATEDBY.Replace("'", "''") & "'") '-- _UPDATEDBY
            strFldUpd.Append(", UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- _UPDATEDDATE

            .Append(strFldUpd.ToString)
            .Append(" WHERE ")
            .Append(" ID = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function Delete() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("DELETE FROM ")
            .Append(_scheme & "." & _tablename)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function GetRecord(ByRef strWhereCondition As String) As DataTable
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
            .Append(" ORDER BY id")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0)
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try
    End Function

End Class


Public Class clsGPS_TAXSWC_CONFIG_SETUP
    Private clsBusiness As UtilityClassLibrary.BusinessLayer
    Private clsUtility As UtilityClassLibrary.ConnectDB
    Private _ConnDB As System.Data.OleDb.OleDbConnection
    Private _scheme As String = "GENERATEPAYMENT"
    Private _tablename As String = "GPS_TAXSWC_CONFIG_SETUP"
    Private _ID As Integer
    Private _CODE As String
    Private _PARAMETER_NAME As String
    Private _STRING_VALUE1 As String
    Private _STRING_VALUE2 As String
    Private _STRING_VALUE3 As String
    Private _STRING_VALUE4 As String
    Private _STRING_VALUE5 As String
    Private _STRING_VALUE6 As String
    Private _STRING_VALUE7 As String
    Private _STRING_VALUE8 As String
    Private _STRING_VALUE9 As String
    Private _STRING_VALUE10 As String
    Private _NUMERIC_VALUE1 As Integer
    Private _NUMERIC_VALUE2 As Integer
    Private _NUMERIC_VALUE3 As Integer
    Private _NUMERIC_VALUE4 As Integer
    Private _NUMERIC_VALUE5 As Integer
    Private _configFILENAME_TAX_TYPE As String
    Private _configFILENAME_NID As String
    Private _configFILENAME_BRANCH_NO As String
    Private _configFILENAME_TAX_YEAR As String
    Private _configFILENAME_TAX_MONTH As String
    Private _configFILENAME_ROUND As String
    Private _configFILENAME_EXTENSION As String
    Private _configFILE_TYPE As String
    Private _configFILE_ENCODE As String
    Private _configFIELD_SEPERATE As String
    Private _configLINE_SEPERATE As String
    Private _configSPECIAL_CHAR As String
    Private _configCORP_TAX_ID As String
    Private _configCORP_BRANCH_NO As String
    Private _configSENDER_ID As String
    Private _configSENDER_NID As String
    Private _configSENDER_BRANCH As String
    Private _configSENDER_ROLE As String
    Private _configNID As String
    Private _configLTO As String
    Private _configBRANCH_TYPE As String
    Private _configUSER_ID As String
    Private _Config_Value As New Collection


    Public Property ConnDB As System.Data.OleDb.OleDbConnection
        Get
            ConnDB = _ConnDB
        End Get
        Set(value As System.Data.OleDb.OleDbConnection)
            _ConnDB = value
        End Set
    End Property


    Public Property ID As Integer
        Get
            ID = _ID
        End Get
        Set(value As Integer)
            _ID = value
        End Set
    End Property

    Public Property CODE As String
        Get
            CODE = _CODE
        End Get
        Set(value As String)
            _CODE = value
        End Set
    End Property

    Public Property PARAMETER_NAME As String
        Get
            PARAMETER_NAME = _PARAMETER_NAME
        End Get
        Set(value As String)
            _PARAMETER_NAME = value
        End Set
    End Property

    Public Property STRING_VALUE1 As String
        Get
            STRING_VALUE1 = _STRING_VALUE1
        End Get
        Set(value As String)
            _STRING_VALUE1 = value
        End Set
    End Property

    Public Property STRING_VALUE2 As String
        Get
            STRING_VALUE2 = _STRING_VALUE2
        End Get
        Set(value As String)
            _STRING_VALUE2 = value
        End Set
    End Property

    Public Property STRING_VALUE3 As String
        Get
            STRING_VALUE3 = _STRING_VALUE3
        End Get
        Set(value As String)
            _STRING_VALUE3 = value
        End Set
    End Property

    Public Property STRING_VALUE4 As String
        Get
            STRING_VALUE4 = _STRING_VALUE4
        End Get
        Set(value As String)
            _STRING_VALUE4 = value
        End Set
    End Property

    Public Property STRING_VALUE5 As String
        Get
            STRING_VALUE5 = _STRING_VALUE5
        End Get
        Set(value As String)
            _STRING_VALUE5 = value
        End Set
    End Property

    Public Property STRING_VALUE6 As String
        Get
            STRING_VALUE6 = _STRING_VALUE6
        End Get
        Set(value As String)
            _STRING_VALUE6 = value
        End Set
    End Property

    Public Property STRING_VALUE7 As String
        Get
            STRING_VALUE7 = _STRING_VALUE7
        End Get
        Set(value As String)
            _STRING_VALUE7 = value
        End Set
    End Property

    Public Property STRING_VALUE8 As String
        Get
            STRING_VALUE8 = _STRING_VALUE8
        End Get
        Set(value As String)
            _STRING_VALUE8 = value
        End Set
    End Property

    Public Property STRING_VALUE9 As String
        Get
            STRING_VALUE9 = _STRING_VALUE8
        End Get
        Set(value As String)
            _STRING_VALUE5 = value
        End Set
    End Property

    Public Property STRING_VALUE10 As String
        Get
            STRING_VALUE10 = _STRING_VALUE10
        End Get
        Set(value As String)
            _STRING_VALUE10 = value
        End Set
    End Property

    Public Property NUMERIC_VALUE1 As Integer
        Get
            NUMERIC_VALUE1 = _NUMERIC_VALUE1
        End Get
        Set(value As Integer)
            _NUMERIC_VALUE1 = value
        End Set
    End Property

    Public Property NUMERIC_VALUE2 As Integer
        Get
            NUMERIC_VALUE2 = _NUMERIC_VALUE2
        End Get
        Set(value As Integer)
            _NUMERIC_VALUE2 = value
        End Set
    End Property

    Public Property NUMERIC_VALUE3 As Integer
        Get
            NUMERIC_VALUE3 = _NUMERIC_VALUE3
        End Get
        Set(value As Integer)
            _NUMERIC_VALUE3 = value
        End Set
    End Property

    Public Property NUMERIC_VALUE4 As Integer
        Get
            NUMERIC_VALUE4 = _NUMERIC_VALUE4
        End Get
        Set(value As Integer)
            _NUMERIC_VALUE4 = value
        End Set
    End Property

    Public Property NUMERIC_VALUE5 As Integer
        Get
            NUMERIC_VALUE5 = _NUMERIC_VALUE5
        End Get
        Set(value As Integer)
            _NUMERIC_VALUE5 = value
        End Set
    End Property

    Public Property configCORP_TAX_ID As String
        Get
            configCORP_TAX_ID = _configCORP_TAX_ID
        End Get
        Set(value As String)
            _configCORP_TAX_ID = value
        End Set
    End Property

    Public Property configCORP_BRANCH_NO As String
        Get
            configCORP_BRANCH_NO = _configCORP_BRANCH_NO
        End Get
        Set(value As String)
            _configCORP_BRANCH_NO = value
        End Set
    End Property

    Public Property configFILENAME_TAX_TYPE As String
        Get
            configFILENAME_TAX_TYPE = _configFILENAME_TAX_TYPE
        End Get
        Set(value As String)
            _configFILENAME_TAX_TYPE = value
        End Set
    End Property

    Public Property configFILENAME_NID As String
        Get
            configFILENAME_NID = _configFILENAME_NID
        End Get
        Set(value As String)
            _configFILENAME_NID = value
        End Set
    End Property

    Public Property configFILENAME_BRANCH_NO As String
        Get
            configFILENAME_BRANCH_NO = _configFILENAME_BRANCH_NO
        End Get
        Set(value As String)
            _configFILENAME_BRANCH_NO = value
        End Set
    End Property

    Public Property configFILENAME_TAX_YEAR As String
        Get
            configFILENAME_TAX_YEAR = _configFILENAME_TAX_YEAR
        End Get
        Set(value As String)
            _configFILENAME_TAX_YEAR = value
        End Set
    End Property

    Public Property configFILENAME_TAX_MONTH As String
        Get
            configFILENAME_TAX_MONTH = _configFILENAME_TAX_MONTH
        End Get
        Set(value As String)
            _configFILENAME_TAX_MONTH = value
        End Set
    End Property

    Public Property configFILENAME_ROUND As String
        Get
            configFILENAME_ROUND = _configFILENAME_ROUND
        End Get
        Set(value As String)
            _configFILENAME_ROUND = value
        End Set
    End Property

    Public Property configFILENAME_EXTENSION As String
        Get
            configFILENAME_EXTENSION = _configFILENAME_EXTENSION
        End Get
        Set(value As String)
            _configFILENAME_EXTENSION = value
        End Set
    End Property

    Public Property configFILE_TYPE As String
        Get
            configFILE_TYPE = _configFILE_TYPE
        End Get
        Set(value As String)
            _configFILE_TYPE = value
        End Set
    End Property

    Public Property configFILE_ENCODE As String
        Get
            configFILE_ENCODE = _configFILE_ENCODE
        End Get
        Set(value As String)
            _configFILE_ENCODE = value
        End Set
    End Property

    Public Property configFIELD_SEPERATE As String
        Get
            configFIELD_SEPERATE = _configFIELD_SEPERATE
        End Get
        Set(value As String)
            _configFIELD_SEPERATE = value
        End Set
    End Property

    Public Property configLINE_SEPERATE As String
        Get
            configLINE_SEPERATE = _configLINE_SEPERATE
        End Get
        Set(value As String)
            _configLINE_SEPERATE = value
        End Set
    End Property

    Public Property configSPECIAL_CHAR As String
        Get
            configSPECIAL_CHAR = _configSPECIAL_CHAR
        End Get
        Set(value As String)
            _configSPECIAL_CHAR = value
        End Set
    End Property

    Public Property configSENDER_ID As String
        Get
            configSENDER_ID = _configSENDER_ID
        End Get
        Set(value As String)
            _configSENDER_ID = value
        End Set
    End Property

    Public Property configSENDER_NID As String
        Get
            configSENDER_NID = _configSENDER_NID
        End Get
        Set(value As String)
            _configSENDER_NID = value
        End Set
    End Property

    Public Property configSENDER_BRANCH As String
        Get
            configSENDER_BRANCH = _configSENDER_BRANCH
        End Get
        Set(value As String)
            _configSENDER_BRANCH = value
        End Set
    End Property

    Public Property configSENDER_ROLE As String
        Get
            configSENDER_ROLE = _configSENDER_ROLE
        End Get
        Set(value As String)
            _configSENDER_ROLE = configSENDER_ROLE
        End Set
    End Property

    Public Property configNID As String
        Get
            configNID = _configNID
        End Get
        Set(value As String)
            _configNID = value
        End Set
    End Property

    Public Property configLTO As String
        Get
            configLTO = _configLTO
        End Get
        Set(value As String)
            _configLTO = value
        End Set
    End Property

    Public Property configBRANCH_TYPE As String
        Get
            configBRANCH_TYPE = _configBRANCH_TYPE
        End Get
        Set(value As String)
            _configBRANCH_TYPE = value
        End Set
    End Property

    Public Property configUSER_ID As String
        Get
            configUSER_ID = _configUSER_ID
        End Get
        Set(value As String)
            _configUSER_ID = value
        End Set
    End Property

    Public Property Config_Value As Collection
        Get
            Config_Value = _Config_Value
        End Get
        Set(value As Collection)
            _Config_Value = value
        End Set
    End Property

    Public Function Insert() As Boolean

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("INSERT INTO ")
            .Append(_scheme & "." & _tablename)
            .Append(" VALUES(")
            .Append(" " & _ID.ToString & "") '-- 
            .Append(", '" & _CODE.Replace("'", "''") & "'") '-- 
            .Append(", '" & _PARAMETER_NAME.Replace("'", "''") & "'") '--  
            .Append(", '" & _STRING_VALUE1.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE2.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE3.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE4.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE5.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE6.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE7.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE8.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE9.Replace("'", "''") & "'") '-- 
            .Append(", '" & _STRING_VALUE10.Replace("'", "''") & "'") '-- 
            .Append(", " & _NUMERIC_VALUE1.ToString & "") '-- 
            .Append(", " & _NUMERIC_VALUE2.ToString & "") '-- 
            .Append(", " & _NUMERIC_VALUE3.ToString & "") '-- 
            .Append(", " & _NUMERIC_VALUE4.ToString & "") '-- 
            .Append(", " & _NUMERIC_VALUE5.ToString & "") '-- 
            .Append(")")
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function Update() As Boolean

        Dim strSQL As New StringBuilder
        Dim strFldUpd As New StringBuilder
        With strSQL
            .Append("UPDATE ")
            .Append(_scheme & "." & _tablename)
            .Append(" SET ")
            If _CODE.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" CODE = '" & _CODE.Replace("'", "''") & "'") '-- _CODE
            End If
            If _PARAMETER_NAME.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" PARAMETER_NAME = '" & _PARAMETER_NAME.Replace("'", "''") & "'") '-- _supp_name_gp
            End If
            If _STRING_VALUE1.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE1 = '" & _STRING_VALUE1.Replace("'", "''") & "'") '-- _STRING_VALUE1
            End If
            If _STRING_VALUE2.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE2 = '" & _STRING_VALUE2.Replace("'", "''") & "'") '-- _STRING_VALUE2
            End If
            If _STRING_VALUE3.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE3 = '" & _STRING_VALUE3.Replace("'", "''") & "'") '-- _STRING_VALUE3
            End If
            If _STRING_VALUE4.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE4 = '" & _STRING_VALUE4.Replace("'", "''") & "'") '-- _STRING_VALUE4
            End If
            If _STRING_VALUE5.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE5 = '" & _STRING_VALUE5.Replace("'", "''") & "'") '-- _STRING_VALUE5
            End If
            If _STRING_VALUE6.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE6 = '" & _STRING_VALUE6.Replace("'", "''") & "'") '-- _STRING_VALUE6
            End If
            If _STRING_VALUE7.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE7 = '" & _STRING_VALUE7.Replace("'", "''") & "'") '-- _STRING_VALUE7
            End If
            If _STRING_VALUE8.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE8 = '" & _STRING_VALUE8.Replace("'", "''") & "'") '-- _STRING_VALUE8
            End If
            If _STRING_VALUE9.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE9 = '" & _STRING_VALUE9.Replace("'", "''") & "'") '-- _STRING_VALUE9
            End If
            If _STRING_VALUE10.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" STRING_VALUE10 = '" & _STRING_VALUE10.Replace("'", "''") & "'") '-- _STRING_VALUE10
            End If

            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" NUMERIC_VALUE1 = " & _NUMERIC_VALUE1.ToString & "") '-- _NUMERIC_VALUE1
            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" NUMERIC_VALUE2 = " & _NUMERIC_VALUE2.ToString & "") '-- _NUMERIC_VALUE2
            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" NUMERIC_VALUE3 = " & _NUMERIC_VALUE3.ToString & "") '-- _NUMERIC_VALUE3
            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" NUMERIC_VALUE4 = " & _NUMERIC_VALUE4.ToString & "") '-- _NUMERIC_VALUE4
            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" NUMERIC_VALUE5 = " & _NUMERIC_VALUE5.ToString & "") '-- _NUMERIC_VALUE5

            .Append(strFldUpd.ToString)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function Delete() As Boolean

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("DELETE FROM ")
            .Append(_scheme & "." & _tablename)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function GetRecord(ByRef strWhereCondition As String) As DataTable

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
            .Append(" ORDER BY id")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0)
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try

    End Function

    Public Function GetConfig() As Boolean

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" ORDER BY id")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            Dim _dt As New DataTable

            _dataadapter.Fill(_dataset)

            For Each rowD As DataRow In _dataset.Tables(0).Rows
                _Config_Value.Add(rowD.Item(3).ToString, rowD.Item(1).ToString)
            Next

            _configFILENAME_TAX_TYPE = _dataset.Tables(0).Rows(0).Item(3).ToString
            _configFILENAME_NID = _dataset.Tables(0).Rows(1).Item(3).ToString
            _configFILENAME_BRANCH_NO = _dataset.Tables(0).Rows(2).Item(3).ToString
            _configFILENAME_TAX_YEAR = _dataset.Tables(0).Rows(3).Item(3).ToString
            _configFILENAME_TAX_MONTH = _dataset.Tables(0).Rows(4).Item(3).ToString
            _configFILENAME_ROUND = _dataset.Tables(0).Rows(5).Item(3).ToString
            _configFILENAME_EXTENSION = _dataset.Tables(0).Rows(6).Item(3).ToString
            _configFILE_TYPE = _dataset.Tables(0).Rows(7).Item(3).ToString
            _configFILE_ENCODE = _dataset.Tables(0).Rows(8).Item(3).ToString
            _configFIELD_SEPERATE = _dataset.Tables(0).Rows(9).Item(3).ToString
            _configLINE_SEPERATE = _dataset.Tables(0).Rows(10).Item(3).ToString
            _configSPECIAL_CHAR = _dataset.Tables(0).Rows(11).Item(3).ToString
            _configCORP_TAX_ID = _dataset.Tables(0).Rows(12).Item(3).ToString
            _configCORP_BRANCH_NO = _dataset.Tables(0).Rows(13).Item(3).ToString
            _configSENDER_ID = _dataset.Tables(0).Rows(14).Item(3).ToString
            _configSENDER_NID = _dataset.Tables(0).Rows(15).Item(3).ToString
            _configSENDER_BRANCH = _dataset.Tables(0).Rows(16).Item(3).ToString
            _configSENDER_ROLE = _dataset.Tables(0).Rows(17).Item(3).ToString
            _configNID = _dataset.Tables(0).Rows(18).Item(3).ToString
            _configLTO = _dataset.Tables(0).Rows(19).Item(3).ToString
            _configBRANCH_TYPE = _dataset.Tables(0).Rows(20).Item(3).ToString
            _configUSER_ID = _dataset.Tables(0).Rows(21).Item(3).ToString

            Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function GetConfigFWD() As Boolean

        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" ORDER BY id")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            Dim _dt As New DataTable

            _dataadapter.Fill(_dataset)

            For Each rowD As DataRow In _dataset.Tables(0).Rows
                _Config_Value.Add(rowD.Item(3).ToString, rowD.Item(1).ToString)
            Next

            _configFILENAME_TAX_TYPE = _dataset.Tables(0).Rows(0).Item(3).ToString
            _configFILENAME_NID = _dataset.Tables(0).Rows(1).Item(4).ToString
            _configFILENAME_BRANCH_NO = _dataset.Tables(0).Rows(2).Item(3).ToString
            _configFILENAME_TAX_YEAR = _dataset.Tables(0).Rows(3).Item(3).ToString
            _configFILENAME_TAX_MONTH = _dataset.Tables(0).Rows(4).Item(3).ToString
            _configFILENAME_ROUND = _dataset.Tables(0).Rows(5).Item(3).ToString
            _configFILENAME_EXTENSION = _dataset.Tables(0).Rows(6).Item(3).ToString
            _configFILE_TYPE = _dataset.Tables(0).Rows(7).Item(3).ToString
            _configFILE_ENCODE = _dataset.Tables(0).Rows(8).Item(3).ToString
            _configFIELD_SEPERATE = _dataset.Tables(0).Rows(9).Item(3).ToString
            _configLINE_SEPERATE = _dataset.Tables(0).Rows(10).Item(3).ToString
            _configSPECIAL_CHAR = _dataset.Tables(0).Rows(11).Item(3).ToString
            _configCORP_TAX_ID = _dataset.Tables(0).Rows(12).Item(4).ToString
            _configCORP_BRANCH_NO = _dataset.Tables(0).Rows(13).Item(3).ToString
            _configSENDER_ID = _dataset.Tables(0).Rows(14).Item(3).ToString
            _configSENDER_NID = _dataset.Tables(0).Rows(15).Item(4).ToString
            _configSENDER_BRANCH = _dataset.Tables(0).Rows(16).Item(3).ToString
            _configSENDER_ROLE = _dataset.Tables(0).Rows(17).Item(3).ToString
            _configNID = _dataset.Tables(0).Rows(18).Item(3).ToString
            _configLTO = _dataset.Tables(0).Rows(19).Item(3).ToString
            _configBRANCH_TYPE = _dataset.Tables(0).Rows(20).Item(3).ToString
            _configUSER_ID = _dataset.Tables(0).Rows(21).Item(3).ToString

            Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function GetConfigByCode(ByRef strCode As String) As String

        Dim strSQL As New StringBuilder
        Dim strValue As String
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" WHERE code = '" & strCode & "'")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            Dim _dt As New DataTable

            _dataadapter.Fill(_dataset)

            strValue = _dataset.Tables(0).Rows(0).Item(3).ToString

            Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function GetConfigByCodeFWD(ByRef strCode As String) As String

        Dim strSQL As New StringBuilder
        Dim strValue As String
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            .Append(" WHERE code = '" & strCode & "'")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            Dim _dt As New DataTable

            _dataadapter.Fill(_dataset)

            strValue = _dataset.Tables(0).Rows(0).Item(4).ToString

            Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

End Class


Public Class clsGPS_TAXSWC_OUT

    Private clsBusiness As UtilityClassLibrary.BusinessLayer
    Private clsUtility As UtilityClassLibrary.ConnectDB
    Private _scheme As String = "GENERATEPAYMENT"
    Private _tablename As String = "GPS_TAXSWC_OUT"
    Private _ConnDB As System.Data.OleDb.OleDbConnection
    Private _CREATEDBY As String
    Private _CREATEDDATE As String
    Private _ID As Integer
    Private _TAX_TYPE As Integer
    Private _UPDATEDBY As String
    Private _UPDATEDDATE As String
    Private _TOTAL_LINE As Integer
    Private _TOTAL_AMT As Double
    Private _TOTAL_TAX_AMT As Double
    Private _GEN_TYPE As Integer
    Private _GEN_ROUND As Integer
    Private _GEN_DATE As String
    Private _TAX_PERIOD As String
    Private _ACC_PERIOD As String

    Public Property ConnDB As System.Data.OleDb.OleDbConnection
        Get
            ConnDB = _ConnDB
        End Get
        Set(value As System.Data.OleDb.OleDbConnection)
            _ConnDB = value
        End Set
    End Property


    Public Property CREATEDBY As String
        Get
            CREATEDBY = _CREATEDBY
        End Get
        Set(value As String)
            _CREATEDBY = value
        End Set
    End Property


    Public Property CREATEDDATE As String
        Get
            CREATEDDATE = _CREATEDDATE
        End Get
        Set(value As String)
            _CREATEDDATE = value
        End Set
    End Property


    Public Property ID As Integer
        Get
            ID = _ID
        End Get
        Set(value As Integer)
            _ID = value
        End Set
    End Property


    Public Property UPDATEDBY As String
        Get
            UPDATEDBY = _UPDATEDBY
        End Get
        Set(value As String)
            _UPDATEDBY = value
        End Set
    End Property


    Public Property UPDATEDDATE As String
        Get
            UPDATEDDATE = _UPDATEDDATE
        End Get
        Set(value As String)
            _UPDATEDDATE = value
        End Set
    End Property


    Public Property TAX_TYPE As Integer
        Get
            TAX_TYPE = _TAX_TYPE
        End Get
        Set(value As Integer)
            _TAX_TYPE = value
        End Set
    End Property

    Public Property TOTAL_LINE As Integer
        Get
            TOTAL_LINE = _TOTAL_LINE
        End Get
        Set(value As Integer)
            _TOTAL_LINE = value
        End Set
    End Property

    Public Property TOTAL_AMT As Double
        Get
            TOTAL_AMT = _TOTAL_AMT
        End Get
        Set(value As Double)
            _TOTAL_AMT = value
        End Set
    End Property

    Public Property TOTAL_TAX_AMT As Double
        Get
            TOTAL_TAX_AMT = _TOTAL_TAX_AMT
        End Get
        Set(value As Double)
            _TOTAL_TAX_AMT = value
        End Set
    End Property

    Public Property GEN_TYPE As Integer
        Get
            GEN_TYPE = _GEN_TYPE
        End Get
        Set(value As Integer)
            _GEN_TYPE = value
        End Set
    End Property

    Public Property GEN_ROUND As Integer
        Get
            GEN_ROUND = _GEN_ROUND
        End Get
        Set(value As Integer)
            _GEN_ROUND = value
        End Set
    End Property

    Public Property GEN_DATE As String
        Get
            GEN_DATE = _GEN_DATE
        End Get
        Set(value As String)
            _GEN_DATE = value
        End Set
    End Property

    Public Property TAX_PERIOD As String
        Get
            TAX_PERIOD = _TAX_PERIOD
        End Get
        Set(value As String)
            _TAX_PERIOD = value
        End Set
    End Property

    Public Property ACC_PERIOD As String
        Get
            ACC_PERIOD = _ACC_PERIOD
        End Get
        Set(value As String)
            _ACC_PERIOD = value
        End Set
    End Property


    Public Function Delete() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("DELETE FROM ")
            .Append(_scheme & "." & _tablename)
            .Append(" WHERE ")
            .Append(" id = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function


    Public Function GetRecord(ByRef strWhereCondition As String) As DataTable
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
            .Append(" ORDER BY id")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0)
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try
    End Function


    Public Function Insert() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("INSERT INTO ")
            .Append(_scheme & "." & _tablename)
            .Append(" VALUES(")
            .Append(" " & _ID.ToString & "") '-- 

            .Append(", '" & _GEN_DATE.ToString & "'") '-- 
            .Append(", '" & _TAX_PERIOD.ToString & "'") '-- 
            .Append(", '" & _ACC_PERIOD.ToString & "'") '-- 

            .Append(", " & _TAX_TYPE.ToString & "") '-- 
            .Append(", " & _TOTAL_LINE.ToString & "") '--  
            .Append(", " & _TOTAL_AMT.ToString & "") '-- 
            .Append(", " & _TOTAL_TAX_AMT.ToString & "") '-- 
            .Append(", " & _GEN_TYPE.ToString & "") '-- 
            .Append(", " & _GEN_ROUND.ToString & "") '-- 
            .Append(", '" & _CREATEDBY & "'") '-- createdby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
            .Append(", '" & _UPDATEDBY & "'") '-- updatedby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(")")
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function


    Public Function Update() As Boolean
        Dim strSQL As New StringBuilder
        Dim strFldUpd As New StringBuilder
        With strSQL
            .Append("UPDATE ")
            .Append(_scheme & "." & _tablename)
            .Append(" SET ")
            strFldUpd.Append("  GEN_DATE = '" & _GEN_DATE.Replace("'", "''") & "'") '-- GEN_DATE
            strFldUpd.Append(", TAX_PERIOD = '" & _TAX_PERIOD.Replace("'", "''") & "'") '-- TAX_PERIOD
            strFldUpd.Append(", ACC_PERIOD = '" & _ACC_PERIOD.Replace("'", "''") & "'") '-- ACC_PERIOD
            strFldUpd.Append(", TAX_TYPE = " & _TAX_TYPE.ToString & "") '-- TAX_TYPE
            strFldUpd.Append(", TOTAL_LINE = '" & _TOTAL_LINE.ToString & "'") '-- TOTAL_LINE
            strFldUpd.Append(", TOTAL_AMT = '" & _TOTAL_AMT.ToString & "'") '-- TOTAL_AMT
            strFldUpd.Append(", TOTAL_TAX_AMT = '" & _TOTAL_TAX_AMT.ToString & "'") '-- TOTAL_TAX_AMT
            strFldUpd.Append(", GEN_TYPE = " & _GEN_TYPE.ToString & "") '-- GEN_TYPE
            strFldUpd.Append(", GEN_ROUND = " & _GEN_ROUND.ToString & "") '-- GEN_ROUND
            strFldUpd.Append(", UPDATEDBY = '" & _UPDATEDBY.Replace("'", "''") & "'") '-- _UPDATEDBY
            strFldUpd.Append(", UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- _UPDATEDDATE

            .Append(strFldUpd.ToString)
            .Append(" WHERE ")
            .Append(" ID = " & _ID.ToString & "") '-- id
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _ConnDB)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function GetdMaxID() As Long
        Try
            Dim lngResult As Long
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT nvl(max(id),0) ")
                .Append("  FROM " & _scheme & "." & _tablename)
            End With
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            lngResult = _dataset.Tables(0).Rows(0).Item(0)
            Return lngResult
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try

    End Function

    Public Function GetdRoundByFormType(ByRef strTaxType As String _
                                           , ByRef strFormType As String _
                                           , ByRef strWHTPeriod As String _
                                           ) As Long
        Try
            Dim lngResult As Long
            Dim strSQL As New StringBuilder
            Dim clsTaxType As New clsGPS_TAXSWC_TAXTYPE_SETUP
            Dim dt As DataTable
            clsTaxType.ConnDB = _ConnDB
            dt = clsTaxType.GetRecord("tax_type_code = '" & strTaxType & "'")
            With strSQL
                .Append("SELECT max(gen_round) ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE TAX_TYPE = " & dt.Rows(0).Item("id") & "")
                .Append(" AND GEN_TYPE = '" & strFormType & "'")
                .Append(" AND TAX_PERIOD = '" & strWHTPeriod & "'")
            End With
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _ConnDB)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)

            If strFormType = "00" Then
                If _dataset.Tables(0).Rows(0).Item(0).ToString = "" Then
                    lngResult = CInt(dt.Rows(0).Item("file_start_normal_seq"))
                Else
                    If _dataset.Tables(0).Rows(0).Item(0) < CDec(dt.Rows(0).Item("file_start_normal_seq")) Then
                        lngResult = CInt(dt.Rows(0).Item("file_start_normal_seq"))
                    Else
                        lngResult = _dataset.Tables(0).Rows(0).Item(0) + 1
                    End If
                End If
            Else
                If _dataset.Tables(0).Rows(0).Item(0).ToString = "" Then
                    lngResult = CInt(dt.Rows(0).Item("file_start_outmth_seq"))
                Else
                    If _dataset.Tables(0).Rows(0).Item(0) < CInt(dt.Rows(0).Item("file_start_outmth_seq")) Then
                        lngResult = CInt(dt.Rows(0).Item("file_start_outmth_seq"))
                    Else
                        lngResult = _dataset.Tables(0).Rows(0).Item(0) + 1
                    End If
                End If
            End If

            Return lngResult
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try
    End Function

End Class
