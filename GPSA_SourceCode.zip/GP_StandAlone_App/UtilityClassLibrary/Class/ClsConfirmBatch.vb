Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsConfirmBatch
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetChequeNo(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT NVL(CHQS_S_CHQ1,0) AS CHQS_S_CHQ1, ")
        sb.Append("NVL(CHQS_E_CHQ1,0) AS CHQS_E_CHQ1  , ")
        sb.Append("NVL(CHQS_S_CHQ2,0) AS CHQS_S_CHQ2  , ")
        sb.Append("NVL(CHQS_E_CHQ2,0) AS CHQS_E_CHQ2,CHQS_S_CHQ1_FINISH ,CHQS_S_CHQ2_FINISH   ")
        sb.Append("FROM GPS_CHEQUE_SETUP ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetMaxID(ByRef oleConn As OleDbConnection, ByVal field As String, ByVal tbname As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT NVL(MAX(" & field & "),0) AS ID FROM " & tbname & "  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return Convert.ToInt32(dt.Rows(0)(0)) + 1
        Else
            Return 0
        End If
    End Function
    Public Function ListPayType(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("select t.payt_pay_group as id,g.payg_pay_groupname as name ")
        sb.Append("from gps_payment_complete a inner join gps_tl_paytype t ")
        sb.Append("on a.gpcm_paymth=t.payt_paymth ")
        sb.Append("and a.gpcm_sub_paymth=t.payt_sub_paymth ")
        sb.Append("inner join gps_tl_paygroup g ")
        sb.Append("on t.payt_pay_group=g.payg_pay_group ")
        sb.Append("where a.gpcm_flag_confirmpay='N' ")
        sb.Append("and a.gpcm_batch_no='" & batchno & "' ")
        sb.Append("group by t.payt_pay_group,g.payg_pay_groupname ")
        sb.Append("UNION ")
        sb.Append("SELECT 'zNON_PAY' AS ID ,'WHT non pay' AS NAME FROM DUAL")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function ListBatchNo(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select c.gpcm_batch_no ")
        sb.Append("from gps_payment_complete c ")
        sb.Append("where c.gpcm_flag_confirmpay='N' ")
        sb.Append("group by gpcm_batch_no ")
        sb.Append("order by gpcm_batch_no ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindData(ByRef oleConn As OleDbConnection, ByVal batchno As String, ByVal paytype As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT A.GPCM_PAYMTH,A.GPCM_SUB_PAYMTH,SUM(A.GPCM_AMOUNT) AS AMT ")
        sb.Append("FROM (GPS_PAYMENT_COMPLETE A INNER JOIN GPS_TL_PAYTYPE B ON A.GPCM_PAYMTH=B.PAYT_PAYMTH AND ")
        sb.Append("A.GPCM_SUB_PAYMTH=B.PAYT_SUB_PAYMTH)  ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE1 C ON B.PAYT_PAY_GROUP=C.BNKS_PAY_GROUP AND ")
        sb.Append("C.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 D ON B.PAYT_PAY_GROUP=D.BNKS_PAY_GROUP AND ")
        sb.Append("A.GPCM_MERCHN_NO=D.BNKS_MERCHN_NO AND         ")
        sb.Append("D.BNKS_STATUS='ACTIVE' ")
        sb.Append("WHERE A.GPCM_BATCH_NO='" & batchno & "'  ")

        If paytype <> "" Then
            sb.Append("AND B.PAYT_PAY_GROUP ='" & paytype & "' ")
        End If

        'sb.Append("AND NOT(A.GPCM_PAYMTH='C' AND (A.GPCM_SUB_PAYMTH='H' OR A.GPCM_SUB_PAYMTH='G' OR A.GPCM_SUB_PAYMTH='B' OR A.GPCM_SUB_PAYMTH='T')) ")
        sb.Append("GROUP BY A.GPCM_PAYMTH,A.GPCM_SUB_PAYMTH    ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindDataNonPay(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("select nvl(sum(c.taxcm_tax_amt),0) amt ")
        sb.Append("from gps_wht_complete c ")
        sb.Append("inner join gps_transref_rel t ")
        sb.Append("on c.taxcm_createdate=t.tref_createdate ")
        sb.Append("and c.taxcm_core_system=t.tref_core_system ")
        sb.Append("and trim(c.taxcm_transref) = trim(t.tref_transref) ")
        sb.Append("where t.tref_paycretyp_id='006' ")
        sb.Append("and c.taxcm_batch_no='" & batchno & "' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetPaymentMethod(ByRef oleConn As OleDbConnection, ByVal type As String) As String
        Dim sb As New StringBuilder()

        sb.Append("select payt_paymth||':'||payt_sub_paymth as pay_subpay from gps_tl_paytype where payt_pay_group='" & type & "'")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt.Rows(0)(0).ToString
        Else
            Return ""
        End If
    End Function
    Public Function UpdateChequeNo(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal chequeno1 As String, ByVal chequeno2 As String, ByVal status1 As String, ByVal status2 As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_CHEQUE_SETUP SET CHQS_S_CHQ1=LPAD('" & chequeno1 & "',LENGTH(CHQS_S_CHQ1),'0'), ")
        sb.Append("CHQS_S_CHQ2=LPAD('" & chequeno2 & "',LENGTH(CHQS_S_CHQ2),'0') ")
        If status1 <> "" Then
            sb.Append(",CHQS_S_CHQ1_FINISH='" & status1 & "' ")
        End If
        If status2 <> "" Then
            sb.Append(",CHQS_S_CHQ2_FINISH='" & status2 & "' ")
        End If
        sb.Append(",UPDATEDBY='" & guserlogin & "',UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD') ")
        sb.Append("WHERE CHQS_PAY_GROUP='SCBLIFE_CHQ' ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True

        Else
            Return False

        End If
    End Function
    Public Function UpdateConfirmPayment(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal pay_subpay As String, ByVal batchno As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_PAYMENT_COMPLETE SET GPCM_FLAG_CONFIRMPAY='Y', ")
        sb.Append("UPDATEDBY='" & guserlogin & "',UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE GPCM_BATCH_NO='" & batchno & "' ")

        If pay_subpay <> "" Then
            sb.Append("AND GPCM_PAYMTH='" & Microsoft.VisualBasic.Left(pay_subpay, 1) & "' AND GPCM_SUB_PAYMTH='" & Microsoft.VisualBasic.Right(pay_subpay, 1) & "' ")
        End If


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True

        Else
            Return False

        End If
    End Function
    Public Function UpdateConfirmWHT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_WHT_COMPLETE SET TAXCM_FLAG_CONFIRMPAY='Y', ")
        sb.Append("UPDATEDBY='" & guserlogin & "',UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE TAXCM_BATCH_NO='" & batchno & "' ")



        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True

        Else
            Return False

        End If
    End Function

    Public Function UpdateWHTPeriod(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal str_batchno As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_TRANSREF_REL SET TREF_WHT_PERIOD=substr(tref_paiddate,1,4)||'0'||substr(tref_paiddate,5,2), ")
        sb.Append("UPDATEDBY='" & guserlogin & "', UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE TREF_BATCH_NO='" & str_batchno & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True

        Else
            Return False

        End If
    End Function
    'Public Function UpdateConfirmWHT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal guserlogin As String) As Boolean

    '    Dim sb As New StringBuilder
    '    Dim rec As Integer


    '    sb.Append("MERGE INTO gps_wht_complete a   ")
    '    sb.Append("USING     ")
    '    sb.Append("(    ")
    '    sb.Append("select tref_createdate,tref_core_system,tref_transref ")
    '    sb.Append("from gps_wht_complete c  ")
    '    sb.Append("inner join gps_transref_rel t  ")
    '    sb.Append("on c.taxcm_createdate=t.tref_createdate  ")
    '    sb.Append("and c.taxcm_core_system=t.tref_core_system  ")
    '    sb.Append("and c.taxcm_transref=t.tref_transref  ")
    '    sb.Append("where t.tref_paycretyp_id='006'  ")
    '    sb.Append("and c.taxcm_batch_no='" & batchno & "'  ")
    '    sb.Append("group by tref_createdate,tref_core_system,tref_transref ")
    '    sb.Append(") t ON ( ")
    '    sb.Append("a.taxcm_createdate=t.tref_createdate  ")
    '    sb.Append("and a.taxcm_core_system=t.tref_core_system  ")
    '    sb.Append("and a.taxcm_transref=t.tref_transref ")
    '    sb.Append(")     ")
    '    sb.Append("WHEN MATCHED THEN UPDATE     ")
    '    sb.Append("SET a.taxcm_flag_confirmpay='Y',  ")
    '    sb.Append("a.updatedby='" & guserlogin & "',  ")
    '    sb.Append("a.updateddate=TO_CHAR(SYSDATE,'YYYYMMDD hh24miss')  ")
    '    sb.Append("where a.taxcm_batch_no='" & batchno & "'   ")


    '    rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

    '    If rec >= 0 Then
    '        Return True

    '    Else
    '        Return False

    '    End If
    'End Function
    Public Function fnCountCHQNO(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select c.gpcm_createdate,c.gpcm_core_system,c.gpcm_transref ")
        sb.Append("from GPS_PAYMENT_COMPLETE c inner join GPS_TL_PAYTYPE t ON c.GPCM_PAYMTH=t.PAYT_PAYMTH ")
        sb.Append("And c.GPCM_SUB_PAYMTH=t.PAYT_SUB_PAYMTH ")
        sb.Append("where c.gpcm_batch_no='" & batchno & "' ")
        sb.Append("and t.payt_pay_group='SCBLIFE_CHQ' ")
        sb.Append("and not(c.gpcm_paymth='C' and c.gpcm_sub_paymth='Q') ")
        sb.Append("group by c.gpcm_createdate,c.gpcm_core_system,c.gpcm_transref ")
        sb.Append("union all ")
        sb.Append("select c.gpcm_createdate,c.gpcm_core_system,c.gpcm_transref ")
        sb.Append("from GPS_PAYMENT_COMPLETE c inner join GPS_TL_PAYTYPE t ON c.GPCM_PAYMTH=t.PAYT_PAYMTH ")
        sb.Append("And c.GPCM_SUB_PAYMTH=t.PAYT_SUB_PAYMTH ")
        sb.Append("where c.gpcm_batch_no='" & batchno & "' ")
        sb.Append("and t.payt_pay_group='SCBLIFE_CHQ' ")
        sb.Append("and c.gpcm_paymth='C' and c.gpcm_sub_paymth='Q' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function GetDataForINS(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select A.GPCM_CREATEDATE, A.GPCM_CORE_SYSTEM, A.GPCM_TRANSREF,A.GPCM_GPTREF_SEQNO,A.GPCM_POLNO, A.GPCM_BILLNO, ")
        sb.Append("A.GPCM_PAIDDATE, A.GPCM_DESC, A.GPCM_PAYMTH, A.GPCM_PAYEE_NAME, B.PAYT_PAYTYPE, B.PAYT_PAY_GROUP, ")
        sb.Append("C.BNKS_BNKSCODE_NO AS BNKS1_BNKSCODE_NO, F.BKMST_BNKCODE AS BNKS1_BNKSCODE, C.BNKS_BNKSACC_NO AS BNKS1_BNKSACC_NO, ")
        sb.Append("D.BNKS_BNKSCODE_NO AS BNKS2_BNKSCODE_NO, G.BKMST_BNKCODE AS BNKS2_BNKSCODE, D.BNKS_BNKSACC_NO AS BNKS2_BNKSACC_NO, ")
        sb.Append("A.GPCM_BNKCODE, A.GPCM_BNKCODE_NO, A.GPCM_BNKBRN, A.GPCM_BNKNAME, A.GPCM_PAYEE_BNKACCNO, A.GPCM_PAYEE_BNKACCNME, ")
        sb.Append("A.GPCM_COMMENT, A.GPCM_ADDRESS1, A.GPCM_DISTRICT, A.GPCM_PROVINCE, A.GPCM_INSURENAME, A.GPCM_DATASOURCE_NME, ")
        sb.Append("A.GPCM_Reserve6, A.GPCM_MERCHN_NO, A.GPCM_CDCARD_DATE, A.GPCM_Reserve9, A.GPCM_Reserve10, A.GPCM_SYS_REF, ")
        sb.Append("A.GPCM_SYS_GR, A.GPCM_SUB_PAYMTH, A.GPCM_FLAG_FLWBILL, A.GPCM_OSEA_LIST, A.GPCM_PHONE, A.GPCM_FAX, A.GPCM_SWIFT_CODE, ")
        sb.Append("A.GPCM_BNKBRN_NAME, A.GPCM_BNKADDR, A.GPCM_COUNTRY, A.GPCM_CURRENCY, A.GPCM_EXCHN_RATE, A.GPCM_BNKCHARGES, ")
        sb.Append("E.TREF_DEP_REPAY, A.GPCM_AMOUNT ")
        sb.Append("from (GPS_PAYMENT_COMPLETE A INNER JOIN GPS_TL_PAYTYPE B ON A.GPCM_PAYMTH=B.PAYT_PAYMTH And ")
        sb.Append("A.GPCM_SUB_PAYMTH=B.PAYT_SUB_PAYMTH) ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE1 C ON B.PAYT_PAY_GROUP=C.BNKS_PAY_GROUP And ")
        sb.Append("C.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 D ON B.PAYT_PAY_GROUP=D.BNKS_PAY_GROUP And ")
        sb.Append("A.GPCM_MERCHN_NO=D.BNKS_MERCHN_NO And ")
        sb.Append("D.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TRANSREF_REL E ON A.GPCM_CREATEDATE=E.TREF_CREATEDATE And ")
        sb.Append("A.GPCM_CORE_SYSTEM=E.TREF_CORE_SYSTEM And ")
        sb.Append("A.GPCM_TRANSREF=E.TREF_TRANSREF ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER F ON C.BNKS_BNKSCODE_NO=F.BKMST_BNKCODE_NO And ")
        sb.Append("F.BKMST_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER G ON D.BNKS_BNKSCODE_NO=G.BKMST_BNKCODE_NO And ")
        sb.Append("G.BKMST_STATUS='ACTIVE' ")
        sb.Append("where A.gpcm_batch_no='" & batchno & "' And B.PAYT_PAY_GROUP like '%' ")
        sb.Append("And not(A.GPCM_PAYMTH='C' And (A.GPCM_SUB_PAYMTH='H' Or A.GPCM_SUB_PAYMTH='G' Or A.GPCM_SUB_PAYMTH='B' Or A.GPCM_SUB_PAYMTH='T')) ")
        sb.Append("union ")
        sb.Append("select A.GPCM_CREATEDATE, A.GPCM_CORE_SYSTEM, A.GPCM_TRANSREF, 0 AS GPCM_GPTREF_SEQNO, null As GPCM_POLNO, null As GPCM_BILLNO, ")
        sb.Append("A.GPCM_PAIDDATE, E.TREF_PPOSE_PCHASE AS GPCM_DESC, A.GPCM_PAYMTH, H.PAYEE_NAME AS GPCM_PAYEE_NAME, B.PAYT_PAYTYPE, B.PAYT_PAY_GROUP, ")
        sb.Append("C.BNKS_BNKSCODE_NO AS BNKS1_BNKSCODE_NO, F.BKMST_BNKCODE AS BNKS1_BNKSCODE, C.BNKS_BNKSACC_NO AS BNKS1_BNKSACC_NO, ")
        sb.Append("D.BNKS_BNKSCODE_NO AS BNKS2_BNKSCODE_NO, G.BKMST_BNKCODE AS BNKS2_BNKSCODE, D.BNKS_BNKSACC_NO AS BNKS2_BNKSACC_NO, ")
        sb.Append("A.GPCM_BNKCODE, A.GPCM_BNKCODE_NO, A.GPCM_BNKBRN, A.GPCM_BNKNAME, null AS GPCM_PAYEE_BNKACCNO, null AS GPCM_PAYEE_BNKACCNME, ")
        sb.Append("null AS GPCM_COMMENT, null AS GPCM_ADDRESS1, null AS GPCM_DISTRICT, null AS GPCM_PROVINCE, null AS GPCM_INSURENAME, null AS GPCM_DATASOURCE_NME, ")
        sb.Append("null AS GPCM_Reserve6, null AS GPCM_MERCHN_NO, null AS GPCM_CDCARD_DATE, null AS GPCM_Reserve9, null AS GPCM_Reserve10, null AS GPCM_SYS_REF, ")
        sb.Append("null AS GPCM_SYS_GR, A.GPCM_SUB_PAYMTH, null AS GPCM_FLAG_FLWBILL, null AS GPCM_OSEA_LIST, null AS GPCM_PHONE, null AS GPCM_FAX, null AS GPCM_SWIFT_CODE, ")
        sb.Append("null AS GPCM_BNKBRN_NAME, null AS GPCM_BNKADDR, null AS GPCM_COUNTRY, null AS GPCM_CURRENCY, null AS GPCM_EXCHN_RATE, null AS GPCM_BNKCHARGES, ")
        sb.Append("E.TREF_DEP_REPAY, SUM(A.GPCM_AMOUNT) AS GPCM_AMOUNT ")
        sb.Append("from (GPS_PAYMENT_COMPLETE A INNER JOIN GPS_TL_PAYTYPE B ON A.GPCM_PAYMTH=B.PAYT_PAYMTH And ")
        sb.Append("A.GPCM_SUB_PAYMTH=B.PAYT_SUB_PAYMTH) ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE1 C ON B.PAYT_PAY_GROUP=C.BNKS_PAY_GROUP And ")
        sb.Append("C.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 D ON B.PAYT_PAY_GROUP=D.BNKS_PAY_GROUP And  ")
        sb.Append("A.GPCM_MERCHN_NO=D.BNKS_MERCHN_NO And ")
        sb.Append("D.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TRANSREF_REL E ON A.GPCM_CREATEDATE=E.TREF_CREATEDATE And ")
        sb.Append("A.GPCM_CORE_SYSTEM=E.TREF_CORE_SYSTEM And ")
        sb.Append("A.GPCM_TRANSREF=E.TREF_TRANSREF ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER F ON C.BNKS_BNKSCODE_NO=F.BKMST_BNKCODE_NO And ")
        sb.Append("F.BKMST_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER G ON D.BNKS_BNKSCODE_NO=G.BKMST_BNKCODE_NO And ")
        sb.Append("G.BKMST_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_PAYEE_DEFAULT H ON A.GPCM_PAYMTH=H.PAYEE_PAYMTH And ")
        sb.Append("A.GPCM_SUB_PAYMTH=H.PAYEE_SUB_PAYMTH ")
        sb.Append("where A.gpcm_batch_no='" & batchno & "' And B.PAYT_PAY_GROUP like '%' ")
        sb.Append("And (A.GPCM_PAYMTH='C' And (A.GPCM_SUB_PAYMTH='H' Or A.GPCM_SUB_PAYMTH='G' Or A.GPCM_SUB_PAYMTH='B' Or A.GPCM_SUB_PAYMTH='T')) ")
        sb.Append("group by A.GPCM_CREATEDATE, A.GPCM_CORE_SYSTEM, A.GPCM_TRANSREF, A.GPCM_PAIDDATE, E.TREF_PPOSE_PCHASE, A.GPCM_PAYMTH, H.PAYEE_NAME, B.PAYT_PAYTYPE, B.PAYT_PAY_GROUP, ")
        sb.Append("C.BNKS_BNKSCODE_NO, F.BKMST_BNKCODE, C.BNKS_BNKSACC_NO, D.BNKS_BNKSCODE_NO, G.BKMST_BNKCODE, D.BNKS_BNKSACC_NO, ")
        sb.Append("A.GPCM_BNKCODE, A.GPCM_BNKCODE_NO, A.GPCM_BNKBRN, A.GPCM_BNKNAME, ")
        sb.Append("A.GPCM_SUB_PAYMTH, E.TREF_DEP_REPAY ")
        sb.Append("order by PAYT_PAY_GROUP, GPCM_PAYMTH,GPCM_SUB_PAYMTH, GPCM_PAIDDATE, GPCM_CORE_SYSTEM, TREF_DEP_REPAY, GPCM_TRANSREF, GPCM_GPTREF_SEQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataForInstrument(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select A.*  ")
        sb.Append("from (GPS_PAYMENT_COMPLETE A INNER JOIN GPS_TL_PAYTYPE B ON A.GPCM_PAYMTH=B.PAYT_PAYMTH And ")
        sb.Append("A.GPCM_SUB_PAYMTH=B.PAYT_SUB_PAYMTH) ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE1 C ON B.PAYT_PAY_GROUP=C.BNKS_PAY_GROUP And ")
        sb.Append("C.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 D ON B.PAYT_PAY_GROUP=D.BNKS_PAY_GROUP And  ")
        sb.Append("A.GPCM_MERCHN_NO=D.BNKS_MERCHN_NO And ")
        sb.Append("D.BNKS_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TRANSREF_REL E ON A.GPCM_CREATEDATE=E.TREF_CREATEDATE And ")
        sb.Append("A.GPCM_CORE_SYSTEM=E.TREF_CORE_SYSTEM And ")
        sb.Append("A.GPCM_TRANSREF=E.TREF_TRANSREF ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER F ON C.BNKS_BNKSCODE_NO=F.BKMST_BNKCODE_NO And ")
        sb.Append("F.BKMST_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER G ON D.BNKS_BNKSCODE_NO=G.BKMST_BNKCODE_NO And ")
        sb.Append("G.BKMST_STATUS='ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_PAYEE_DEFAULT H ON A.GPCM_PAYMTH=H.PAYEE_PAYMTH And ")
        sb.Append("A.GPCM_SUB_PAYMTH=H.PAYEE_SUB_PAYMTH ")
        sb.Append("where A.gpcm_batch_no='" & batchno & "' And B.PAYT_PAY_GROUP like '%' ")
        sb.Append("And (A.GPCM_PAYMTH='C' And (A.GPCM_SUB_PAYMTH='H' Or A.GPCM_SUB_PAYMTH='G' Or A.GPCM_SUB_PAYMTH='B' Or A.GPCM_SUB_PAYMTH='T')) ")
        sb.Append("order by PAYT_PAY_GROUP, GPCM_PAYMTH,GPCM_SUB_PAYMTH, GPCM_PAIDDATE, GPCM_CORE_SYSTEM, TREF_DEP_REPAY, GPCM_TRANSREF ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataRptPaymentRegistrationByBatch(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        '-- NOT SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft "
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX,NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND NOT ((P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T') ")
        sb.Append("OR P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' )) ")

        sb.Append("UNION ALL ")
        'Direct Credit
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M1Direct Credit' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX,NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)='SCB' ")

        sb.Append("UNION ALL ")
        'Media Clearing
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M2Media Clearing' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX,NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)<>'SCB' ")


        sb.Append("UNION ALL ")
        'SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft
        sb.Append("SELECT P.GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT ,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX ,NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W LEFT JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON W.TAX_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=I.GP_TRANSREF ")
        sb.Append("AND W.TAX_GPTREF_SEQNO=I.GP_GPTREF_SEQNO ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO      ")
        sb.Append(") W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_SEQNO=W.GP_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%' ")
        sb.Append("AND (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        'sb.Append("ORDER BY PAYG_PAY_GROUPNAME,GP_PAYMTH,GP_SUB_PAYMTH,TREF_PAIDDATE,GP_SEQNO") 'TREF_VCH_NO_C 

        'Detail Data
        sb.Append("UNION ALL ")
        sb.Append("SELECT I.GP_SEQNO,I.GP_GPTREF_SEQNO AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE, ")
        sb.Append("G.PAYG_PAY_GROUPNAME,I.GP_PAYMTH||I.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE, ")
        sb.Append("L.TREF_TRANSREF,L.TREF_VCH_NO_C, ")
        sb.Append("I.GP_INSTRUMENT_NO AS CHQNO,I.GP_BNKCODE,I.GP_PAYEE_NAME AS PAYEENAME,    ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) as TAX_AMOUNT,    ")
        sb.Append("nvl(I.GP_AMOUNT,0) AS BASE_AMOUNT , ")
        sb.Append("I.GP_AMOUNT,I.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS, ")
        sb.Append("I.GP_LASTUPD_STSDATE,I.GP_PAYMTH,I.GP_SUB_PAYMTH,   ")
        sb.Append("W.MINTAX,W.MAXTAX,0 as DETAIL ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF )  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF, ")
        sb.Append("MIN(W.TAX_WHTNO) AS MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE    ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM    ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF    ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO    ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T    ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH    ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH    ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G    ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP    ")
        sb.Append("LEFT JOIN    ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S    ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH    ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS    ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'  ")
        sb.Append(" ORDER BY PAYG_PAY_GROUPNAME,GP_PAYMTH,GP_SUB_PAYMTH,TREF_PAIDDATE,GP_SEQNO,SEQNO ")



        Dim Ds As New DataSet
        Dim dt As DataTable = New DataTable
        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtHead")

        Return Ds.Tables("dtHead")

    End Function
    Public Function GetDataRptPaymentRegistrationByBatch_OLD(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("-- NOT SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        'sb.Append("AND NOT (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        sb.Append("AND NOT ((P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T') ")
        sb.Append("OR P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' )) ")

        sb.Append("UNION ALL ")
        'Direct Credit
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M1Direct Credit' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)='SCB' ")

        sb.Append("UNION ALL ")
        'Media Clearing
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M2Media Clearing' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) as MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)<>'SCB' ")


        sb.Append("UNION ALL ")
        'SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft
        sb.Append("SELECT P.GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT ,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W LEFT JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON W.TAX_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=I.GP_TRANSREF ")
        sb.Append("AND W.TAX_GPTREF_SEQNO=I.GP_GPTREF_SEQNO ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO      ")
        sb.Append(") W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_SEQNO=W.GP_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%' ")
        sb.Append("AND (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        sb.Append("ORDER BY PAYG_PAY_GROUPNAME,GP_PAYMTH,GP_SUB_PAYMTH,TREF_PAIDDATE,GP_SEQNO") 'TREF_VCH_NO_C 

        Dim Ds As New DataSet
        Dim dt As DataTable = New DataTable
        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtHead")

        Return Ds.Tables("dtHead")

    End Function
    Public Function GetDataRptPaymentRegistrationByBatch(ByRef oleConn As OleDbConnection, _
   ByVal batchfrom As String, ByVal batchto As String, ByVal datefrom As String, ByVal dateto As String, _
   ByVal paymentgroup As String, ByVal paymentstatus As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("-- NOT SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        'sb.Append("AND NOT (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        sb.Append("AND NOT ((P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T') ")
        sb.Append("OR P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' )) ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If
        sb.Append("UNION ALL ")
        'Direct Credit
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M1Direct Credit' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)='SCB' ")


        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If

        sb.Append("UNION ALL ")
        'Media Clearing
        sb.Append("SELECT GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M2Media Clearing' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)<>'SCB' ")


        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If


        sb.Append("UNION ALL ")
        '-- SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT P.GP_SEQNO,0 AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W LEFT JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON W.TAX_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=I.GP_TRANSREF ")
        sb.Append("AND W.TAX_GPTREF_SEQNO=I.GP_GPTREF_SEQNO ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO      ")
        sb.Append(") W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_SEQNO=W.GP_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")


        sb.Append("WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%' ")
        sb.Append("AND (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If

        '--------Detaildata

        sb.Append("UNION ALL ")
        sb.Append("SELECT I.GP_SEQNO,I.GP_GPTREF_SEQNO AS SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE, ")
        sb.Append("G.PAYG_PAY_GROUPNAME,I.GP_PAYMTH||I.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE, ")
        sb.Append("L.TREF_TRANSREF,L.TREF_VCH_NO_C, ")
        sb.Append("I.GP_INSTRUMENT_NO AS CHQNO,I.GP_BNKCODE,I.GP_PAYEE_NAME AS PAYEENAME,    ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) as TAX_AMOUNT,    ")
        sb.Append("nvl(I.GP_AMOUNT,0) AS BASE_AMOUNT , ")
        sb.Append("I.GP_AMOUNT,I.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS, ")
        sb.Append("I.GP_LASTUPD_STSDATE,I.GP_PAYMTH,I.GP_SUB_PAYMTH,   ")
        sb.Append("W.MINTAX,W.MAXTAX,0 as DETAIL ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF )  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF, ")
        sb.Append("MIN(W.TAX_WHTNO) AS MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE    ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM    ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF    ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO    ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T    ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH    ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH    ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G    ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP    ")
        sb.Append("LEFT JOIN    ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S    ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH    ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS    ")
        sb.Append("WHERE 1=1 ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND L.TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (L.TREF_BATCHDATE = '" & datefrom & "' OR L.TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND L.TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( L.TREF_BATCH_NO = '" & batchfrom & "' OR L.TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND G.PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND I.GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If



        sb.Append(" ORDER BY PAYG_PAY_GROUPNAME,GP_PAYMTH,GP_SUB_PAYMTH,TREF_PAIDDATE,GP_SEQNO,SEQNO ")



        Dim Ds As New DataSet
        Dim dt As DataTable = New DataTable
        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtHead")

        Return Ds.Tables("dtHead")

    End Function

    Public Function GetDataRptPaymentRegistrationByBatch_OLD(ByRef oleConn As OleDbConnection, _
    ByVal batchfrom As String, ByVal batchto As String, ByVal datefrom As String, ByVal dateto As String, _
    ByVal paymentgroup As String, ByVal paymentstatus As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("-- NOT SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        'sb.Append("AND NOT (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        sb.Append("AND NOT ((P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T') ")
        sb.Append("OR P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' )) ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If
        sb.Append("UNION ALL ")
        'Direct Credit
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M1Direct Credit' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)='SCB' ")


        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If

        sb.Append("UNION ALL ")
        'Media Clearing
        sb.Append("SELECT GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,'M2Media Clearing' as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")

        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)<>'SCB' ")


        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If


        sb.Append("UNION ALL ")
        '-- SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT P.GP_SEQNO,L.TREF_BATCH_NO,L.TREF_PAIDDATE,G.PAYG_PAY_GROUPNAME,P.GP_PAYMTH||P.GP_SUB_PAYMTH||T.PAYT_PAYTYPE as PAYT_PAYTYPE,L.TREF_TRANSREF,L.TREF_VCH_NO_C,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END CHQNO,P.GP_BNKCODE,  ")
        sb.Append("CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END PAYEENAME,  ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) AS TAX_AMOUNT,  ")
        sb.Append("nvl(W.TAX_BASE_AMT,0) AS BASE_AMOUNT,  ")
        sb.Append("nvl(P.GP_AMOUNT,0) as GP_AMOUNT,P.GP_PAYDESC,S.STS_DESC AS GP_LASTUPD_STS,P.GP_LASTUPD_STSDATE,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
        sb.Append("nvl(W.MINTAX,'0') as MINTAX,nvl(W.MAXTAX,0) as MAXTAX , ")
        sb.Append("NVL(I.DETAIL,0) AS DETAIL  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W LEFT JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON W.TAX_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=I.GP_TRANSREF ")
        sb.Append("AND W.TAX_GPTREF_SEQNO=I.GP_GPTREF_SEQNO ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO      ")
        sb.Append(") W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_SEQNO=W.GP_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")


        sb.Append("WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%' ")
        sb.Append("AND (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (TREF_BATCHDATE = '" & datefrom & "' OR TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( TREF_BATCH_NO = '" & batchfrom & "' OR TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If


        sb.Append("ORDER BY PAYG_PAY_GROUPNAME,PAYT_PAYTYPE,GP_SUB_PAYMTH,TREF_PAIDDATE,GP_SEQNO ") 'TREF_VCH_NO_C

        Dim Ds As New DataSet
        Dim dt As DataTable = New DataTable
        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtHead")

        Return Ds.Tables("dtHead")

    End Function
    Public Function GetDataRptPaymentRegistrationByBatch_Detail(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder


        sb.Append("SELECT I.GP_SEQNO,I.GP_INSTRUMENT_NO,W.MINTAX,W.MAXTAX,I.GP_PAYEE_NAME AS PAYEENAME,   ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) as TAX_AMOUNT,   ")
        sb.Append("nvl(I.GP_AMOUNT,0) AS BASE_AMOUNT ,i.gp_gptref_seqno,i.gp_paydesc ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I   ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF ) ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,  ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT  ")
        sb.Append("FROM  GPS_WHT W  ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF   ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO   ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")


        Dim dt As DataTable = New DataTable("dtDetail")
        Dim Ds As New DataSet

        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtDetail")

        Return Ds.Tables("dtDetail")

    End Function
    Public Function GetDataRptPaymentRegistrationByBatch_Detail_OLD(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder


        sb.Append("SELECT I.GP_SEQNO,I.GP_INSTRUMENT_NO,W.MINTAX,W.MAXTAX,I.GP_PAYEE_NAME AS PAYEENAME,   ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) as TAX_AMOUNT,   ")
        sb.Append("nvl(I.GP_AMOUNT,0) AS BASE_AMOUNT ,i.gp_gptref_seqno,i.gp_paydesc ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I   ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF ) ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,  ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT  ")
        sb.Append("FROM  GPS_WHT W  ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF   ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO   ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")


        Dim dt As DataTable = New DataTable("dtDetail")
        Dim Ds As New DataSet

        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtDetail")

        Return Ds.Tables("dtDetail")

    End Function
    Public Function GetDataRptPaymentRegistrationByBatch_Detail(ByRef oleConn As OleDbConnection, _
     ByVal batchfrom As String, ByVal batchto As String, ByVal datefrom As String, ByVal dateto As String, _
    ByVal paymentgroup As String, ByVal paymentstatus As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT I.GP_SEQNO,I.GP_INSTRUMENT_NO,W.MINTAX,W.MAXTAX,I.GP_PAYEE_NAME AS PAYEENAME,   ")
        sb.Append("nvl(W.TAX_TAX_AMT,0) as TAX_AMOUNT,   ")
        sb.Append("nvl(I.GP_AMOUNT,0) AS BASE_AMOUNT ,i.gp_gptref_seqno,i.gp_paydesc ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I   ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF ) ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX,  ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT  ")
        sb.Append("FROM  GPS_WHT W  ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF   ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO   ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("WHERE 1=1 ")

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND L.TREF_BATCHDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" Or dateto <> "" Then
            sb.Append("AND (L.TREF_BATCHDATE = '" & datefrom & "' OR L.TREF_BATCHDATE = '" & dateto & "') ")
        End If

        If batchfrom <> "" And batchto <> "" Then
            sb.Append("AND L.TREF_BATCH_NO BETWEEN '" & batchfrom & "' AND '" & batchto & "' ")
        ElseIf batchfrom <> "" Or batchto <> "" Then
            sb.Append("AND ( L.TREF_BATCH_NO = '" & batchfrom & "' OR L.TREF_BATCH_NO = '" & batchto & "' ) ")
        End If

        If paymentgroup <> "" Then
            sb.Append("AND G.PAYG_PAY_GROUP = '" & paymentgroup & "' ")
        End If

        If paymentstatus <> "" Then
            sb.Append("AND I.GP_LASTUPD_STS = '" & paymentstatus & "'  ")
        End If

        Dim dt As DataTable = New DataTable("dtDetail")
        Dim Ds As New DataSet

        clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString, "dtDetail")

        Return Ds.Tables("dtDetail")

    End Function
    Public Function GetDataWHT(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select A.*, B.TREF_PAYMTH, B.TREF_SUB_PAYMTH, C.PAYT_PAY_GROUP, D.PNGD_PHORNGORDOR ")
        sb.Append("from (GPS_WHT_COMPLETE A INNER JOIN GPS_TRANSREF_REL B ON A.TAXCM_CREATEDATE=B.TREF_CREATEDATE And ")
        sb.Append("A.TAXCM_CORE_SYSTEM=B.TREF_CORE_SYSTEM And           ")
        sb.Append("A.TAXCM_TRANSREF=B.TREF_TRANSREF) ")
        sb.Append("LEFT JOIN GPS_TL_PAYTYPE C ON B.TREF_PAYMTH=C.PAYT_PAYMTH And ")
        sb.Append("B.TREF_SUB_PAYMTH=C.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PAYGROUP G ON C.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP ")
        sb.Append("LEFT JOIN GPS_TL_PHORNGORDOR D ON A.TAXCM_TAXTYPE=D.PNGD_TAXTYPE ")
        sb.Append("where A.TAXCM_BATCH_NO='" & batchno & "' And (C.PAYT_PAY_GROUP like '%' Or C.PAYT_PAY_GROUP is null) ")
        sb.Append("order by G.PAYG_PAY_GROUPNAME,  B.TREF_PAYMTH,B.TREF_SUB_PAYMTH, B.TREF_PAIDDATE, A.TAXCM_CORE_SYSTEM, B.TREF_DEP_REPAY, A.TAXCM_TRANSREF, D.PNGD_PHORNGORDOR,A.TAXCM_LINENO    ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataCertificateReport(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL || W.TAX_AP_FNAME || ' ' || W.TAX_AP_LNAME AS FNAME, ")
        sb.Append("W.TAX_ADDRESS || ' ' || W.TAX_AMPENM || ' ' || W.TAX_PROVNM || ' ' || W.TAX_AGZIP AS ADDRESS, ")
        sb.Append("NVL(W.TAX_TAXID,TAX_IDCARD) AS TAX_TAXID,W.TAX_IDCARD,W.TAX_TAXTYPE,TO_CHAR(TO_DATE(W.TAX_TAXDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_TAXDATE,W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_DESC,W.TAX_PRINTWHT_STS AS STATUS, W.tax_payee ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_6.COMP_NMO1 ELSE COM_SETUP_1.COMP_NAME END COMP_NAME ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_7.COMP_ADO2 ELSE COM_SETUP_2.COMP_ADDR END COMP_ADDR ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_4.COMP_TAXO1 ELSE COM_SETUP_3.COMP_TAXID END COMP_TAXID ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_WHT W ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_NAME FROM GPS_COMPANY_SETUP WHERE CODE = 'NAME') COM_SETUP_1 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_ADDR FROM GPS_COMPANY_SETUP WHERE CODE = 'ADDR') COM_SETUP_2 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXID FROM GPS_COMPANY_SETUP WHERE CODE = 'TAXI') COM_SETUP_3 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'TAO1') COM_SETUP_4 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXEF FROM GPS_COMPANY_SETUP WHERE CODE = 'TAEF') COM_SETUP_5 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_NMO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'NMO1') COM_SETUP_6 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_ADO2 FROM GPS_COMPANY_SETUP WHERE CODE = 'ADO2') COM_SETUP_7 ON 1=1 ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("ORDER BY W.TAX_SEQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataWHTSeqNo(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT A.TAXCM_TAXTYPE,A.TAXDATE,NVL(MAX(SUBSTR(T.TAX_WHTNO,9,4)),0) CHQNO  ")
        sb.Append("from  ")
        sb.Append("( ")
        sb.Append("select A.TAXCM_TAXTYPE,SUBSTR(A.TAXCM_TAXDATE,1,6) TAXDATE ")
        sb.Append("from (GPS_WHT_COMPLETE A INNER JOIN GPS_TRANSREF_REL B ON A.TAXCM_CREATEDATE=B.TREF_CREATEDATE And ")
        sb.Append("A.TAXCM_CORE_SYSTEM=B.TREF_CORE_SYSTEM And ")
        sb.Append("A.TAXCM_TRANSREF=B.TREF_TRANSREF) ")
        sb.Append("LEFT JOIN GPS_TL_PAYTYPE C ON B.TREF_PAYMTH=C.PAYT_PAYMTH And ")
        sb.Append("B.TREF_SUB_PAYMTH=C.PAYT_SUB_PAYMTH ")
        sb.Append("LEFT JOIN GPS_TL_PHORNGORDOR D ON A.TAXCM_TAXTYPE=D.PNGD_TAXTYPE ")
        sb.Append("where A.TAXCM_BATCH_NO='" & batchno & "' And (C.PAYT_PAY_GROUP like '%' Or C.PAYT_PAY_GROUP is null) ")
        sb.Append("GROUP BY A.TAXCM_TAXTYPE,SUBSTR(A.TAXCM_TAXDATE,1,6)  )A ")
        sb.Append("LEFT JOIN GPS_WHT T  ")
        sb.Append("ON T.TAX_TAXTYPE=A.TAXCM_TAXTYPE ")
        sb.Append("AND SUBSTR(T.TAX_TAXDATE,1,6)=TAXDATE   ")
        sb.Append("GROUP BY A.TAXCM_TAXTYPE,A.TAXDATE ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function InsertInstrument(ByVal dr As DataRow, ByVal id As Integer, ByVal systemdate As String, ByVal gUserLogin As String) As String
        Dim sb As New System.Text.StringBuilder

        sb.Append("INSERT INTO GPS_INSTRUMENT (")
        sb.Append("GP_SEQNO,")
        sb.Append("GP_CONFIRMDATE,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_PAYDESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_INSTRUMENT_NO,")
        sb.Append("GP_LASTUPD_STS,")
        sb.Append("GP_LASTUPD_STSDATE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & id & "',")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & dr("GPCM_CREATEDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_CORE_SYSTEM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_TRANSREF").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_GPTREF_SEQNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_POLNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BILLNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAIDDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_AMOUNT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DESC").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYMTH").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYEE_NAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKCODE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKCODE_NO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKBRN").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKNAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_COMMENT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_ADDRESS1").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DISTRICT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PROVINCE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_INSURENAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DATASOURCE_NME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve6").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_MERCHN_NO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_CDCARD_DATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve9").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve10").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SYS_REF").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SYS_GR").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SUB_PAYMTH").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_FLAG_FLWBILL").ToString.Replace("'", "''") & "',")
        sb.Append("'',")
        sb.Append("'O',")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")
        Return sb.ToString
    End Function
    Public Function InsertPayment(ByVal dr As DataRow, ByVal id As Integer, ByVal systemdate As String, ByVal chqno As String, ByVal gUserLogin As String) As String
        Dim sb As New System.Text.StringBuilder
        sb.Append("INSERT INTO GPS_PAYMENT ( ")
        sb.Append("GP_SEQNO,")
        sb.Append("GP_CONFIRMDATE,")
        sb.Append("GP_CREATEDATE,")
        sb.Append("GP_CORE_SYSTEM,")
        sb.Append("GP_TRANSREF,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_POLNO,")
        sb.Append("GP_BILLNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_PAYDESC,")
        sb.Append("GP_PAYMTH,")
        sb.Append("GP_PAYEE_NAME,")
        sb.Append("GP_BNKSCODE,")
        sb.Append("GP_BNKSCODE_NO,")
        sb.Append("GP_BNKSACC_NO,")
        sb.Append("GP_BNKCODE,")
        sb.Append("GP_BNKCODE_NO,")
        sb.Append("GP_BNKBRN,")
        sb.Append("GP_BNKBRN_NEW,")
        sb.Append("GP_BNKNAME,")
        sb.Append("GP_PAYEE_BNKACCNO,")
        sb.Append("GP_PAYEE_BNKACCNO_NEW,")
        sb.Append("GP_PAYEE_BNKACCNME,")
        sb.Append("GP_COMMENT,")
        sb.Append("GP_ADDRESS1,")
        sb.Append("GP_DISTRICT,")
        sb.Append("GP_PROVINCE,")
        sb.Append("GP_INSURENAME,")
        sb.Append("GP_DATASOURCE_NME,")
        sb.Append("GP_RESERVE6,")
        sb.Append("GP_MERCHN_NO,")
        sb.Append("GP_CDCARD_DATE,")
        sb.Append("GP_RESERVE9,")
        sb.Append("GP_RESERVE10,")
        sb.Append("GP_SYS_REF,")
        sb.Append("GP_SYS_GR,")
        sb.Append("GP_SUB_PAYMTH,")
        sb.Append("GP_FLAG_FLWBILL,")
        sb.Append("GP_OSEA_LIST,")
        sb.Append("GP_PHONE,")
        sb.Append("GP_FAX,")
        sb.Append("GP_SWIFT_CODE,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_BNKADDR,")
        sb.Append("GP_COUNTRY,")
        sb.Append("GP_CURRENCY,")
        sb.Append("GP_EXCHN_RATE,")
        sb.Append("GP_BNKCHARGES,")
        sb.Append("GP_CHQNO,")
        sb.Append("GP_LASTUPD_STS,")
        sb.Append("GP_LASTUPD_STSDATE,")
        sb.Append("GP_PRINTCHQ_STS,")
        sb.Append("GP_PRINTCHQ_STSDATE,")
        sb.Append("GP_FLAG_EXPTOBANK,")
        sb.Append("GP_EXPTOBANK_DATE,")
        sb.Append("GP_EXPTOBANK_FILENME,")
        sb.Append("GP_EXPTOBANK_SEQNO,")
        sb.Append("GP_CUSTREFNO,")
        sb.Append("GP_FLAG_GET_RESULT,")
        sb.Append("GP_GET_RESULT_DATE,")
        sb.Append("GP_FLAG_EXPTOOTHSYS,")
        sb.Append("GP_EXPTOOTHSYS_DATE, ")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & id & "',")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & dr("GPCM_CREATEDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_CORE_SYSTEM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_TRANSREF").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_GPTREF_SEQNO").ToString.ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_POLNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BILLNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAIDDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_AMOUNT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DESC").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYMTH").ToString.Replace("'", "''") & "',")
        'sb.Append("'" & dr("GPCM_PAYEE_NAME") & "' ,")

        If dr("GPCM_PAYMTH") = "C" And dr("GPCM_SUB_PAYMTH") = "H" Then
            sb.Append("'" & dr("GPCM_PAYEE_NAME").ToString.Replace("'", "''") & "' || ' ' || (select gpcm_payee_name from gps_payment_complete where  gpcm_createdate='" & dr("GPCM_CREATEDATE").ToString.Replace("'", "''") & "' and gpcm_core_system='" & dr("GPCM_CORE_SYSTEM").ToString.Replace("'", "''") & "' and gpcm_transref='" & dr("GPCM_TRANSREF").ToString.Replace("'", "''") & "') ,")
        Else
            sb.Append("'" & dr("GPCM_PAYEE_NAME").ToString.Replace("'", "''") & "' ,")
        End If

        'Get GP_BNKSCODE 
        sb.Append("(SELECT BKMST_BNKCODE FROM GPS_TL_BANKMASTER WHERE BKMST_BNKCODE_NO ='" & dr("BNKS1_BNKSCODE_NO").ToString.Replace("'", "''") & "'),") 'GPCM_BNKCODE_NO
        Select Case dr("PAYT_PAY_GROUP")
            Case "SCB_NET", "OVERSEA", "ATS", "SCBLIFE_CHQ"
                sb.Append("'" & dr("BNKS1_BNKSCODE_NO").ToString.Replace("'", "''") & "',")
                sb.Append("'" & dr("BNKS1_BNKSACC_NO").ToString.Replace("'", "''") & "',")
            Case Else
                sb.Append("'" & dr("BNKS2_BNKSCODE_NO").ToString.Replace("'", "''") & "',")
                sb.Append("'" & dr("BNKS2_BNKSACC_NO").ToString.Replace("'", "''") & "',")
        End Select
        sb.Append("'" & dr("GPCM_BNKCODE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKCODE_NO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKBRN").ToString.Replace("'", "''") & "',")

        ''BNKBRN new
        '�� Confirm 20141123
        If dr("GPCM_PAYMTH") = "M" And (dr("GPCM_SUB_PAYMTH") = "M" Or dr("GPCM_SUB_PAYMTH") = "A") Then
            sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 3) & "',")
        Else
            sb.Append("'" & dr("GPCM_BNKBRN").ToString.Replace("'", "''") & "',")
        End If


        'If dr("GPCM_PAYMTH") = "M" And (dr("GPCM_SUB_PAYMTH") = "M" Or dr("GPCM_SUB_PAYMTH") = "A") Then
        '    If dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 10 Then
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 3) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 12 And dr("GPCM_BNKCODE_NO") = "030" Then
        '        sb.Append("'999" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 1) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 12 And dr("GPCM_BNKCODE_NO") = "033" Then
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 3) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 14 Then
        '        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 4) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 15 Then
        '        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 4) & "',")
        '    Else
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(0, 3) & "',")
        '    End If
        'Else
        '    sb.Append("'" & dr("GPCM_BNKBRN") & "',")
        'End If

        sb.Append("'" & dr("GPCM_BNKNAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Replace("'", "''") & "',")


        '�� Confirm 20141123
        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Replace("'", "''") & "',")

        'If dr("PAYT_PAY_GROUP") = "SCB_NET" Then
        '    If dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 10 Then
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO") & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 12 And dr("GPCM_BNKCODE_NO") = "030" Then
        '        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(1, 11) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 12 And dr("GPCM_BNKCODE_NO") = "033" Then
        '        sb.Append("'00" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(3, 9) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 14 Then
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(4, 10) & "',")
        '    ElseIf dr("GPCM_PAYEE_BNKACCNO").ToString.Length = 15 Then
        '        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString.Substring(4, 11) & "',")
        '    Else
        '        sb.Append("'0" & dr("GPCM_PAYEE_BNKACCNO").ToString & "',")
        '    End If
        'Else
        '    sb.Append("'" & dr("GPCM_PAYEE_BNKACCNO").ToString & "',")
        'End If

        sb.Append("'" & dr("GPCM_PAYEE_BNKACCNME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_COMMENT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_ADDRESS1").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DISTRICT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PROVINCE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_INSURENAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_DATASOURCE_NME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve6").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_MERCHN_NO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_CDCARD_DATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve9").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_Reserve10").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SYS_REF").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SYS_GR").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SUB_PAYMTH").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_FLAG_FLWBILL").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_OSEA_LIST").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_PHONE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_FAX").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_SWIFT_CODE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKBRN_NAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKADDR").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_COUNTRY").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_CURRENCY").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_EXCHN_RATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("GPCM_BNKCHARGES").ToString.Replace("'", "''") & "',")

        'If start1 <= end1 Then
        '    sb.Append("'" & start1 & "',")
        'Else
        '    sb.Append("'" & start2 & "',")
        'End If
        If dr("PAYT_PAY_GROUP") = "SCBLIFE_CHQ" Then
            sb.Append("'" & chqno.PadLeft(10, "0") & "',")
        Else
            sb.Append("'" & chqno & "',")
        End If

        If dr("PAYT_PAY_GROUP") = "SCBLIFE_CHQ" Then
            sb.Append("'O',")
        ElseIf dr("PAYT_PAY_GROUP") = "SCB_NET" Then
            sb.Append("'W',")
        Else
            sb.Append("'S',")
        End If
        sb.Append("'" & systemdate & "',")
        If dr("PAYT_PAY_GROUP") = "SCBLIFE_CHQ" Then
            sb.Append("'I',")
        Else
            sb.Append("'',")
        End If
        If dr("PAYT_PAY_GROUP") = "SCBLIFE_CHQ" Then
            sb.Append("'" & systemdate & "',")
        Else
            sb.Append("'',")
        End If
        sb.Append("'N',")
        sb.Append("'',")
        sb.Append("'',")
        sb.Append("'',")
        sb.Append("'',")
        If dr("PAYT_PAY_GROUP") = "SCB_NET" Then
            sb.Append("'N',")
        Else
            sb.Append("'Y',")
        End If
        If dr("PAYT_PAY_GROUP") = "SCB_NET" Then
            sb.Append("'',")
        Else
            sb.Append("'" & systemdate & "',")
        End If
        sb.Append("'N',")
        sb.Append("'',")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

        Return sb.ToString
    End Function
    Public Function InsertWHT(ByVal dr As DataRow, ByVal id As Integer, ByVal whtno As String, ByVal systemdate As String, ByVal gUserLogin As String) As String
        Dim sb As New System.Text.StringBuilder

        sb.Append("INSERT INTO GPS_WHT ( ")
        sb.Append("TAX_SEQNO,")
        sb.Append("TAX_WHTNO,")
        sb.Append("TAX_CONFIRMDATE,")
        sb.Append("TAX_CREATEDATE,")
        sb.Append("TAX_CORE_SYSTEM,")
        sb.Append("TAX_TRANSREF,")
        sb.Append("TAX_GPTREF_SEQNO,")
        sb.Append("TAX_LINENO,")
        sb.Append("TAX_TAXID,")
        sb.Append("TAX_IDCARD,")
        sb.Append("TAX_AP_TTL,")
        sb.Append("TAX_AP_FNAME,")
        sb.Append("TAX_AP_LNAME,")
        sb.Append("TAX_ADDRESS,")
        sb.Append("TAX_AMPENM,")
        sb.Append("TAX_PROVNM,")
        sb.Append("TAX_AGZIP,")
        sb.Append("TAX_TAXTYPE,")
        sb.Append("TAX_PHORNGORDOR,")
        sb.Append("TAX_TAXITEM,")
        sb.Append("TAX_TAXDATE,")
        sb.Append("TAX_BASE_AMT,")
        sb.Append("TAX_TAX_AMT,")
        sb.Append("TAX_PAYEE,")
        sb.Append("TAX_TAX_RATE,")
        sb.Append("TAX_DESC,")
        sb.Append("TAX_GL_ACCOUNT,")
        sb.Append("TAX_PRINTWHT_STS,")
        sb.Append("TAX_PRINTWHT_STSDATE,")
        sb.Append("TAX_FLAG_CC,")
        sb.Append("TAX_CC_DATE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE)")
        sb.Append("VALUES ( ")
        sb.Append("'" & id & "',")
        sb.Append("'" & whtno & "',")
        sb.Append("'" & systemdate & "',")
        sb.Append("'" & dr("TAXCM_CREATEDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_CORE_SYSTEM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TRANSREF").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_GPTREF_SEQNO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_LINENO").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAXID").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_IDCARD").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_AP_TTL").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_AP_FNAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_AP_LNAME").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_ADDRESS").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_AMPENM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_PROVNM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_AGZIP").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAXTYPE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("PNGD_PHORNGORDOR").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAXITEM").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAXDATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_BASE_AMT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAX_AMT").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_PAYEE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_TAX_RATE").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_DESC").ToString.Replace("'", "''") & "',")
        sb.Append("'" & dr("TAXCM_GL_ACCOUNT").ToString.Replace("'", "''") & "',")
        sb.Append("'P',")
        sb.Append("'" & systemdate & "',")
        sb.Append("'N',")
        sb.Append("'',")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & gUserLogin & "' ,")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")
        Return sb.ToString
    End Function
End Class
