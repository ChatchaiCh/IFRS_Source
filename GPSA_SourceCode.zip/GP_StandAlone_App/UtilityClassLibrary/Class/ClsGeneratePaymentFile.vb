Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsGeneratePaymentFile
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetMaxID(ByRef oleConn As OleDbConnection, ByVal paymth As String, ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT NVL(MAX(SUBSTR(GP_EXPTOBANK_FILENME,-2)),0) FROM GPS_PAYMENT ")
        sb.Append("WHERE GP_PAYMTH='" & paymth & "' AND GP_EXPTOBANK_DATE='" & systemdate & "'   ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return Convert.ToInt16(dt.Rows(0)(0)) + 1
        Else
            Return 0
        End If
    End Function
    Public Function GetMaxID_M(ByRef oleConn As OleDbConnection, ByVal direc As Boolean, ByVal systemdate As String) As Integer
        Dim sb As New StringBuilder

        sb.Append("SELECT NVL(MAX(SUBSTR(GP_EXPTOBANK_FILENME,-2)),0) FROM GPS_PAYMENT ")
        sb.Append("WHERE GP_PAYMTH='M' AND  GP_EXPTOBANK_DATE='" & systemdate & "'    ")

        If direc Then
            sb.Append("AND GP_BNKCODE='SCB' ") 'GP_BNKSCODE
        Else
            sb.Append("AND GP_BNKCODE<>'SCB' ") 'GP_BNKSCODE
        End If

        'GP_BNKSCODE

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)(0) = 0 Then
                If direc Then
                    Return 1
                Else
                    Return 50
                End If
            Else
                Return Convert.ToInt16(dt.Rows(0)(0)) + 1
            End If

        Else
            If direc Then
                Return 1
            Else
                Return 50
            End If

        End If
    End Function
    Public Function BindBatchNo(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO ")
        sb.Append("ORDER BY L.TREF_BATCH_NO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindData(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.*,L.TREF_DEP_REPAY  ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N'  ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "'  ")
        sb.Append("ORDER BY L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_CORE_SYSTEM,L.TREF_DEP_REPAY,P.GP_TRANSREF,P.GP_SEQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function SumAmountForGen(ByRef oleConn As OleDbConnection, ByVal filename As String) As String
        Dim sb As New StringBuilder

        sb.Append("SELECT TO_CHAR(SUM(GP_AMOUNT),'9999999999999.000') AS AMOUNT ") 'SUM(GP_AMOUNT)
        sb.Append("FROM GPS_PAYMENT  ")
        sb.Append("WHERE GP_EXPTOBANK_FILENME='" & filename & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If InStr(dt.Rows(0)("AMOUNT").ToString, ".") Then
                Return Replace(dt.Rows(0)("AMOUNT").ToString.Trim, ".", "")
            Else
                Return dt.Rows(0)("AMOUNT") & "000"
            End If

        Else
            Return Nothing
        End If
    End Function
    Public Function SumRowNo_M(ByRef oleConn As OleDbConnection, ByVal filename As String) As String
        Dim sb As New StringBuilder

        'sb.Append("SELECT CEIL(SUM(GP_AMOUNT) / 2000000) AS rNo  ")
        'sb.Append("FROM GPS_PAYMENT  ")
        'sb.Append("WHERE GP_EXPTOBANK_FILENME='" & filename & "' ")

        sb.Append("SELECT SUM(A.RNO) RNO FROM ( ")
        sb.Append("SELECT CEIL(GP_AMOUNT / 2000000) AS RNO   ")
        sb.Append("FROM GPS_PAYMENT   ")
        sb.Append("WHERE GP_EXPTOBANK_FILENME='" & filename & "' ) A ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt.Rows(0)("rNo")
        Else
            Return 0
        End If
    End Function
    Public Function GetDataForGenTextFile(ByRef oleConn As OleDbConnection, ByVal filename As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.*,TO_CHAR(P.GP_AMOUNT,'9999999999999.000') AS GP_AMOUNT2,B.EXP_COMPANY_ID,B.EXP_PRODUCT_CODE,M.BKMST_BNKNAME_ENG,M.BKMST_BNKNAME ")
        sb.Append("FROM GPS_PAYMENT P INNER JOIN GPS_TL_EXPTOBNK_SETUP B ")
        sb.Append("ON P.GP_PAYMTH=B.EXP_PAYMTH AND P.GP_SUB_PAYMTH=B.EXP_SUB_PAYMTH ")
        sb.Append("INNER JOIN GPS_TL_BANKMASTER M ")
        sb.Append("ON P.GP_BNKSCODE=M.BKMST_BNKCODE ")
        sb.Append("WHERE GP_EXPTOBANK_FILENME='" & filename & "' ")
        sb.Append("ORDER BY GP_EXPTOBANK_SEQNO ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataForGenTextFile_M(ByRef oleConn As OleDbConnection, ByVal filename As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.*,TO_CHAR(P.GP_AMOUNT,'9999999999999.000') AS GP_AMOUNT2,B.EXP_COMPANY_ID,B.EXP_PRODUCT_CODE,M.BKMST_BNKNAME_ENG,M.BKMST_BNKNAME ")
        sb.Append("FROM GPS_PAYMENT P INNER JOIN ")

        If Convert.ToInt16(Right(filename, 2)) < 50 Then
            sb.Append("(SELECT * FROM  GPS_TL_EXPTOBNK_SETUP WHERE EXP_PAYMTH='M' AND EXP_BNKCODE='SCB') B  ")
        Else
            sb.Append("(SELECT * FROM  GPS_TL_EXPTOBNK_SETUP WHERE EXP_PAYMTH='M' AND EXP_BNKCODE='NONSCB') B  ")
        End If

        sb.Append("ON P.GP_PAYMTH=B.EXP_PAYMTH AND P.GP_SUB_PAYMTH=B.EXP_SUB_PAYMTH ")
        sb.Append("INNER JOIN GPS_TL_BANKMASTER M ")
        sb.Append("ON P.GP_BNKCODE=M.BKMST_BNKCODE ")
        sb.Append("WHERE GP_EXPTOBANK_FILENME='" & filename & "' ")
        sb.Append("ORDER BY GP_EXPTOBANK_SEQNO ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetTextFileForGen(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' AND P.GP_PAYMTH<>'M' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")
        sb.Append("ORDER BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetTextFileForGen_M(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' AND P.GP_PAYMTH='M' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")
        sb.Append("ORDER BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,L.TREF_BATCHDATE,P.GP_EXPTOBANK_FILENME ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GroupDataByPaymentType(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,'' as FILENAME ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND L.TREF_PAYMTH <>'M' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE ")
        sb.Append("ORDER BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GroupDataByPaymentType_M(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder
        'pattamalin 20141117
        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,CASE WHEN P.GP_BNKCODE='SCB' THEN 'SCB' ELSE 'NONSCB' END GP_BNKCODE,'' as FILENAME ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND L.TREF_PAYMTH = 'M' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,CASE WHEN P.GP_BNKCODE='SCB' THEN 'SCB' ELSE 'NONSCB' END ")
        sb.Append("ORDER BY L.TREF_BATCH_NO,L.TREF_PAYMTH,L.TREF_PAIDDATE,CASE WHEN P.GP_BNKCODE='SCB' THEN 'SCB' ELSE 'NONSCB' END ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetComapanyID(ByRef oleConn As OleDbConnection, ByVal paymth As String, ByVal sub_paymth As String) As String
        Dim sb As New StringBuilder
        sb.Append("SELECT EXP_COMPANY_ID FROM GPS_TL_EXPTOBNK_SETUP WHERE EXP_PAYMTH='" & paymth & "' AND EXP_SUB_PAYMTH='" & sub_paymth & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt.Rows(0)("EXP_COMPANY_ID")
        Else
            Return ""
        End If

    End Function
    Public Function UpdateFileName(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow, ByVal userlogin As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT A ")
        sb.Append("USING      ")
        sb.Append("(     ")
        sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_SEQNO ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & dr("TREF_BATCH_NO") & "' ")
        sb.Append(") B ON ( ")
        sb.Append("A.GP_SEQNO=B.GP_SEQNO) ")
        sb.Append("WHEN MATCHED THEN UPDATE      ")
        sb.Append("SET GP_EXPTOBANK_FILENME=NVL(GP_EXPTOBANK_FILENME,'" & dr("FILENAME") & "'), ")
        sb.Append("UPDATEDBY = '" & userlogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE A.GP_PAYMTH='" & dr("TREF_PAYMTH") & "' ")
        sb.Append("AND A.GP_PAIDDATE='" & dr("TREF_PAIDDATE") & "' ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UpdateFileName_M(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow, ByVal userlogin As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT A ")
        sb.Append("USING      ")
        sb.Append("(     ")
        sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_SEQNO ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & dr("TREF_BATCH_NO") & "' ")
        sb.Append(") B ON ( ")
        sb.Append("A.GP_SEQNO=B.GP_SEQNO) ")
        sb.Append("WHEN MATCHED THEN UPDATE      ")
        sb.Append("SET GP_EXPTOBANK_FILENME=NVL(GP_EXPTOBANK_FILENME,'" & dr("FILENAME") & "'), ")
        sb.Append("UPDATEDBY = '" & userlogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE A.GP_PAYMTH='" & dr("TREF_PAYMTH") & "' ")
        sb.Append("AND A.GP_PAIDDATE='" & dr("TREF_PAIDDATE") & "' ")
        'Pattamalin 20141117
        If dr("GP_BNKCODE") = "SCB" Then
            sb.Append("AND A.GP_BNKCODE='SCB'")
        Else
            sb.Append("AND A.GP_BNKCODE<>'SCB'")
        End If



        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UpdateData(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow, ByVal seq As String, ByVal filename As String, ByVal userlogin As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_PAYMENT SET GP_EXPTOBANK_SEQNO='" & seq & "', ")
        sb.Append("GP_CUSTREFNO='" & filename & seq & "', ")
        sb.Append("UPDATEDBY = '" & userlogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE GP_SEQNO='" & dr("GP_SEQNO") & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function InsertLog(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_GENPAYMENTFILE_LOG ")
        sb.Append("(GFLOG_BATCH_NO, ")
        sb.Append("GFLOG_EXPTOBANK_DATE, ")
        sb.Append("GFLOG_EXPTOBANK_FILENME, ")
        sb.Append("GFLOG_PAYMTH, ")
        sb.Append("GFLOG_SUB_PAYMTH, ")
        sb.Append("GFLOG_PAIDDATE, ")
        sb.Append("GFLOG_TOT_RECORD_TB, ")
        sb.Append("GFLOG_TOT_RECORD_TXT, ")
        sb.Append("GFLOG_TOT_AMOUNT, ")
        sb.Append("CREATEDBY, ")
        sb.Append("CREATEDDATE, ")
        sb.Append("UPDATEDBY, ")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ")
        sb.Append("( ")
        sb.Append("'" & dr("GFLOG_BATCH_NO") & "', ")
        sb.Append("'" & dr("GFLOG_EXPTOBANK_DATE") & "', ")
        sb.Append("'" & dr("GFLOG_EXPTOBANK_FILENME") & "', ")
        sb.Append("'" & dr("GFLOG_PAYMTH") & "', ")
        sb.Append("'" & dr("GFLOG_SUB_PAYMTH") & "', ")
        sb.Append("'" & dr("GFLOG_PAIDDATE") & "', ")
        sb.Append("'" & dr("GFLOG_TOT_RECORD_TB") & "', ")
        sb.Append("'" & dr("GFLOG_TOT_RECORD_TXT") & "', ")
        sb.Append("'" & dr("GFLOG_TOT_AMOUNT") & "', ")
        sb.Append("'" & dr("CREATEDBY") & "', ")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("'" & dr("UPDATEDBY") & "', ")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append(") ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UpdateFlag(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal userlogin As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("MERGE INTO GPS_PAYMENT A ")
        sb.Append("USING      ")
        sb.Append("(     ")
        sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_SEQNO ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("WHERE P.GP_FLAG_EXPTOBANK ='N' ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append(") B ON ( ")
        sb.Append("A.GP_SEQNO=B.GP_SEQNO) ")
        sb.Append("WHEN MATCHED THEN UPDATE      ")
        sb.Append("SET A.GP_FLAG_EXPTOBANK='Y',A.GP_EXPTOBANK_DATE=TO_CHAR(SYSDATE,'YYYYMMDD') , ")
        sb.Append("UPDATEDBY = '" & userlogin & "' ,")
        sb.Append("UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If

    End Function
    Public Function GetBatchNoByExpDate(ByRef oleConn As OleDbConnection, ByVal exportdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_EXPTOBANK_DATE,L.TREF_BATCH_NO ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("WHERE P.GP_EXPTOBANK_DATE = '" & exportdate & "' ")
        sb.Append("GROUP BY P.GP_EXPTOBANK_DATE,L.TREF_BATCH_NO ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataPaymentSummaryReport(ByRef oleConn As OleDbConnection, ByVal batchno As String, ByVal condition As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT T.PAYT_PAY_GROUP,'1' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,COUNT(*) RNO, SUM(P.GP_AMOUNT) AMT, M.PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_MAP M ON P.GP_EXPTOBANK_FILENME || '.txt' = M.PAYM_FILENAME_OUT ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'  ")
        sb.Append("AND P.GP_PAYMTH='C' ")
        sb.Append("GROUP BY T.PAYT_PAY_GROUP,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,M.PAYM_FILENAME_OUT_TOBANK ")
        If condition <> "" Then
            sb.Append(condition)
        End If
        sb.Append("UNION ")
        sb.Append("SELECT T.PAYT_PAY_GROUP,'2' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,COUNT(*) RNO, SUM(P.GP_AMOUNT) AMT, M.PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_MAP M ON P.GP_EXPTOBANK_FILENME || '.txt' = M.PAYM_FILENAME_OUT ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'   ")
        sb.Append("AND P.GP_PAYMTH='D' ")
        sb.Append("GROUP BY T.PAYT_PAY_GROUP,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,M.PAYM_FILENAME_OUT_TOBANK ")
        If condition <> "" Then
            sb.Append(condition)
        End If
        sb.Append("UNION ")

        '--- Begin Old Code 27/01/2015
        'sb.Append("SELECT T.PAYT_PAY_GROUP,'3' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,COUNT(*) RNO, SUM(P.GP_AMOUNT) AMT ")
        'sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        'sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        'sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        'sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        'sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        'sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        'sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'   ")
        'sb.Append("AND P.GP_PAYMTH='M' AND SUBSTR(P.GP_EXPTOBANK_FILENME,-2) < 50 ")
        'sb.Append("GROUP BY T.PAYT_PAY_GROUP,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME,P.GP_BNKSCODE ")

        '--- End Old Code 27/01/2015

        '--- Begin Update By Songpol 27/01/2015
        '--- Adjust transaction match hash total because split amount more 2,000,000

        sb.Append(" SELECT PAYT_PAY_GROUP , '3' as PAYTYPE ,GP_EXPTOBANK_DATE ,GP_PAIDDATE , GP_EXPTOBANK_FILENME , GP_BNKSCODE  ")
        sb.Append(" , sum(trn) as RNO , SUM(GP_AMOUNT) AMT, PAYM_FILENAME_OUT_TOBANK  ")
        sb.Append(" FROM (  ")
        sb.Append(" SELECT T.PAYT_PAY_GROUP,'3' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE ")
        sb.Append(" , ceil((P.GP_AMOUNT/2000000))  as trn , P.GP_AMOUNT, M.PAYM_FILENAME_OUT_TOBANK   ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_MAP M ON P.GP_EXPTOBANK_FILENME || '.txt' = M.PAYM_FILENAME_OUT ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'   ")
        sb.Append("AND P.GP_PAYMTH='M' AND SUBSTR(P.GP_EXPTOBANK_FILENME,-2) < 50 ")
        sb.Append(" ) P ")
        sb.Append(" GROUP BY PAYT_PAY_GROUP,GP_EXPTOBANK_DATE,GP_PAIDDATE,GP_EXPTOBANK_FILENME,GP_BNKSCODE,PAYM_FILENAME_OUT_TOBANK ")
        '--- End Update By Songpol 27/01/2015


        If condition <> "" Then
            sb.Append(condition)
        End If
        sb.Append("UNION ")
        '--- Begin Old Code 27/01/2015
        'sb.Append("SELECT T.PAYT_PAY_GROUP,'4' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE,COUNT(*) RNO, SUM(P.GP_AMOUNT) AMT ")
        'sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        'sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        'sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        'sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        'sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        'sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        'sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'   ")
        'sb.Append("AND P.GP_PAYMTH='M' AND SUBSTR(P.GP_EXPTOBANK_FILENME,-2) >= 50 ")
        'sb.Append("GROUP BY T.PAYT_PAY_GROUP,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME,P.GP_BNKSCODE ")
        '--- End Old Code 27/01/2015

        '--- Begin Update By Songpol 27/01/2015
        '--- Adjust transaction match hash total because split amount more 2,000,000

        sb.Append(" SELECT PAYT_PAY_GROUP , '4' as PAYTYPE ,GP_EXPTOBANK_DATE ,GP_PAIDDATE , GP_EXPTOBANK_FILENME , GP_BNKSCODE  ")
        sb.Append(" , sum(trn) as RNO , SUM(GP_AMOUNT) AMT, PAYM_FILENAME_OUT_TOBANK  ")
        sb.Append(" FROM (  ")
        sb.Append("SELECT T.PAYT_PAY_GROUP,'4' AS PAYTYPE,P.GP_EXPTOBANK_DATE,P.GP_PAIDDATE,P.GP_EXPTOBANK_FILENME||'.txt' as GP_EXPTOBANK_FILENME,P.GP_BNKSCODE ")
        sb.Append(" , ceil((P.GP_AMOUNT/2000000))  as trn , P.GP_AMOUNT, M.PAYM_FILENAME_OUT_TOBANK   ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P   ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF ) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCB_NET'  ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_MAP M ON P.GP_EXPTOBANK_FILENME || '.txt' = M.PAYM_FILENAME_OUT ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'   ")
        sb.Append("AND P.GP_PAYMTH='M' AND SUBSTR(P.GP_EXPTOBANK_FILENME,-2) >= 50 ")
        sb.Append(" ) P ")
        sb.Append(" GROUP BY PAYT_PAY_GROUP,GP_EXPTOBANK_DATE,GP_PAIDDATE,GP_EXPTOBANK_FILENME,GP_BNKSCODE,PAYM_FILENAME_OUT_TOBANK ")

        '--- End Update By Songpol 27/01/2015

        If condition <> "" Then
            sb.Append(condition)
        End If
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDummyForReport(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("SELECT '' as PAYT_PAY_GROUP,'' as PAYTYPE,'' as GP_EXPTOBANK_DATE,'' as GP_PAIDDATE  FROM DUAL ")
        sb.Append("select ")
        sb.Append("'' AS GP_BNKSCODE, ")
        sb.Append("'' AS PAYT_PAY_GROUP, ")
        sb.Append("'' as PAYTYPE, ")
        sb.Append("'' as GP_EXPTOBANK_DATE, ")
        sb.Append("'' as GP_PAIDDATE, ")
        sb.Append("'' as GP_EXPTOBANK_FILENME, ")
        sb.Append("0 as RNO, ")
        sb.Append("0 as AMT ")
        sb.Append("from dual ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function getSysDateTime(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" select TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') as systemdate from dual ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSysDateTime = Ds.Tables(0).Rows(0)("systemdate")
        Catch ex As Exception
            getSysDateTime = ""
        End Try
    End Function

    Public Function getPrefixFilename(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'PREN' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getPrefixFilename = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getPrefixFilename = ""
        End Try
    End Function

    Public Function getCoperateId(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'COID' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getCoperateId = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getCoperateId = ""
        End Try
    End Function

    Public Function getBankCode(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'BKCD' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getBankCode = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getBankCode = ""
        End Try
    End Function

    Public Function getFileType(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'FITY' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getFileType = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getFileType = ""
        End Try
    End Function

    Public Function InsertMap(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal oldFilename As String, ByVal newFilename As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO PAYOUT_TOBANK_MAP ")
        sb.Append("(paym_trans_date, paym_filename_out, paym_filename_out_tobank, createdby, createddate, updatedby, updateddate) ")
        sb.Append("VALUES ( TO_CHAR(sysdate, 'yyyymmdd'), ")
        sb.Append("'" & oldFilename & "', ")
        sb.Append("'" & newFilename & "', ")
        sb.Append("'GPS', TO_CHAR(sysdate, 'yyyymmdd'), NULL, NULL) ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If

    End Function

    Public Function InsertRound(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal oldFilename As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO PAYOUT_ROUND ")
        sb.Append("(PAYRD_TRANS_DATE, PAYRD_ROUND, PAYRD_FILENAME_S, PAYRD_IMPORT_DATE, PAYRD_IMPORT_TIME, CREATEDBY, CREATEDDATE, UPDATEDBY, UPDATEDDATE) ")
        sb.Append("VALUES ")
        sb.Append("(   (SELECT CASE WHEN STRING_VALUE1 = 'A' THEN to_char(sysdate, 'YYYYMMDD') ")
        sb.Append("                 WHEN STRING_VALUE1 = 'M' THEN STRING_VALUE2 END ")
        sb.Append("    FROM  IL_T_PO_CONFIG_PARAMETER ")
        sb.Append("    WHERE CODE = 'BUSC') ")
        sb.Append("    , (SELECT STRING_VALUE2 FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND') ")
        sb.Append("    , '" & oldFilename & "' ")
        sb.Append("    , to_char(sysdate, 'YYYYMMDD') ")
        sb.Append("    , to_char(sysdate, 'HH24MISS') ")
        sb.Append("    , 'GPS' ")
        sb.Append("    , to_char(sysdate, 'YYYYMMDD') ")
        sb.Append("    , 'GPS' ")
        sb.Append("    , to_char(sysdate, 'YYYYMMDD')) ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If

    End Function

    Public Function UpdateMap(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal oldFilename As String, ByVal newFilename As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE PAYOUT_TOBANK_MAP ")
        sb.Append("SET PAYM_FILENAME_OUT_TOBANK = '" & newFilename & "' ")
        sb.Append("WHERE PAYM_FILENAME_OUT = '" & oldFilename & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If

    End Function

    Public Function getNewFilename(ByVal oleConn As OleDbConnection, ByVal oldFilename As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT paym_filename_out_tobank FROM payout_tobank_map WHERE paym_filename_out = '" & oldFilename & "' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getNewFilename = Ds.Tables(0).Rows(0)("paym_filename_out_tobank")
        Catch ex As Exception
            getNewFilename = ""
        End Try
    End Function

    Public Function getOutputFileName(ByVal oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT DISTINCT ")
        sb.Append("        PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM    PAYOUT_ROUND ")
        sb.Append("        INNER JOIN GPS_PAYMENT ")
        sb.Append("            ON UPPER(PAYRD_FILENAME_S) = UPPER(GP_EXPTOBANK_FILENME) || '.TXT' ")
        sb.Append("        INNER JOIN PAYOUT_TOBANK_MAP ON PAYM_FILENAME_OUT = PAYRD_FILENAME_S ")
        sb.Append("WHERE   PAYRD_ROUND = (SELECT STRING_VALUE2 FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND') ")
        sb.Append("AND     PAYRD_TRANS_DATE = ( ")
        sb.Append("            SELECT CASE WHEN STRING_VALUE1 = 'A' THEN to_char(sysdate, 'YYYYMMDD') ")
        sb.Append("                        WHEN STRING_VALUE1 = 'M' THEN STRING_VALUE2 END ")
        sb.Append("            FROM  IL_T_PO_CONFIG_PARAMETER ")
        sb.Append("            WHERE CODE = 'BUSC') ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
End Class
