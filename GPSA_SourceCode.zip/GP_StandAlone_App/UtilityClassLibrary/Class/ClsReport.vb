Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function DtJournalListingRpt(ByRef oleConn As OleDbConnection, ByVal postdate As String, ByVal fn As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT D.GL_JN_TYPE,D.GL_PERIOD,D.GL_JN_NO,D.GL_LINENO,D.GL_DESC,D.GL_TRANSDATE,D.GL_DUEDATE,D.GL_S_ACCOUNT AS ACC,nvl(A.ACNT_NAME_TH, ' ' ) AS ACCNAME, ")
        sb.Append("D.GL_VCH_NO  AS SEQNO,D.GL_S_DEP_BRN AS DEPT_BR,D.GL_S_PL_PT AS PL_PT,D.GL_S_MKT_EMP AS MKT_EMP, ")
        sb.Append("D.GL_S_PROJECT AS PROJECT,D.GL_S_TT_TR AS TT_TR,D.GL_DRCR AS DR_CR,D.GL_AMOUNT AS AMOUNT, ")

        sb.Append("D.GL_SUB_ACCT AS SUBACCOUNTCODE, nvl( S.ACNT_NAME_TH, ' ' ) AS SUBACCOUNTNAME,D.GL_ANALYSIS AS ANALYSIS,D.GL_INTERCOMPANY AS INTERCOMPANY, ")
        sb.Append("D.GL_SPARE1 AS SPARE,D.GL_TREATY_CODE AS TREATYCODE,D.GL_EVENT_CODE AS EVENTCODE,D.GL_LOCAL3 AS LOCAL1,D.GL_LOCAL4 AS LOCAL2, ")
        sb.Append("D.GL_REF_2 AS INVESTSECUR,D.GL_REF_3 AS PARTNER,D.GL_REF_4 AS BROKER,D.GL_CURRENCY_CDE AS CURRENCY ")

        sb.Append("FROM GLM_GL_DAILY D LEFT JOIN GLM_ACCOUNT_SETUP A  ON D.GL_S_ACCOUNT=A.ACNT_S_CODE  ")
        sb.Append("LEFT JOIN GLM_ACCOUNT_SETUP S  ON D.GL_SUB_ACCT=S.ACNT_S_CODE  ")
        sb.Append("WHERE D.GL_POSTING_DATE='" & postdate & "' ")
        If fn <> "0" Then
            Select Case fn
                Case "1"
                    sb.Append("AND D.GL_FUNCTION = 'GP01' ")
                Case "2"
                    sb.Append("AND D.GL_FUNCTION = 'GP02' ")
                Case "3"
                    sb.Append("AND D.GL_FUNCTION = 'GP03' ")
                Case "4"
                    sb.Append("AND D.GL_FUNCTION = 'GP04' ")
                Case "5"
                    sb.Append("AND D.GL_FUNCTION = 'GP05' ")
                Case "6"
                    sb.Append("AND D.GL_FUNCTION = 'GP06' ")
            End Select

        End If

        sb.Append("ORDER BY D.GL_TRANSDATE, D.GL_JN_NO,D.GL_VCH_NO ,D.GL_LINENO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function DtRptAgingOutStandingPayment(ByRef oleConn As OleDbConnection, ByVal business_date As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("select diff,case when diff >=1 and diff <=7 then 'G1'  ")
        'sb.Append("when diff >=8 and diff <=14 then 'G2'  ")
        'sb.Append("when diff >=15 and diff <=21 then 'G3'     ")
        'sb.Append("when diff >=22 and diff <=28 then 'G4' ")
        'sb.Append("when diff >=29 and diff <=35 then 'G5' ")
        'sb.Append("when diff >=36 then 'G6'  end diffgroup, ")
        'sb.Append("jn_vch,tref_paiddate,tref_transref,gl_amt,gp_amt,tax_amt ")
        'sb.Append("from ")
        'sb.Append("(select  ")
        'sb.Append("to_date(t.tref_paiddate,'YYYYMMDD')-to_date('" & business_date & "','YYYYMMDD') as diff,t.tref_transref,t.tref_paiddate, ")
        'sb.Append("case when t.tref_approveddate is null then t.tref_jn_hold else t.tref_vch_no_c end as jn_vch, ")
        'sb.Append("sum(gl.glcr_amount) as gl_amt,sum(gp.gpcr_amount) as gp_amt,sum(w.taxcr_tax_amt) as tax_amt ")
        'sb.Append("from (((gps_transref_rel t inner join gps_gl_creation gl ")
        'sb.Append("on t.tref_createdate=gl.glcr_createdate ")
        'sb.Append("and t.tref_core_system=gl.glcr_core_system ")
        'sb.Append("and t.tref_transref=gl.glcr_transref)  ")
        'sb.Append("inner join  ")
        'sb.Append("gps_payment_creation gp ")
        'sb.Append("on t.tref_createdate=gp.gpcr_createdate ")
        'sb.Append("and t.tref_core_system=gp.gpcr_core_system ")
        'sb.Append("and t.tref_transref=gp.gpcr_transref) ")
        'sb.Append("left join ")
        'sb.Append("gps_wht_creation w ")
        'sb.Append("on t.tref_createdate=w.taxcr_createdate ")
        'sb.Append("and t.tref_core_system=w.taxcr_core_system ")
        'sb.Append("and t.tref_transref=w.taxcr_transref) ")
        'sb.Append("where t.tref_paiddate > '" & business_date & "' ")
        'sb.Append("and gl.glcr_drcr='C' ")
        'sb.Append("and t.tref_paycretyp_id='001' ")
        'sb.Append("and t.tref_createdate <= '" & business_date & "' ")
        'sb.Append("and (t.tref_approvedby is null or t.tref_approveddate < '" & business_date & "' ) ")
        'sb.Append("and t.tref_core_system='ACC' ")
        'sb.Append("group by  t.tref_paiddate,case when t.tref_approveddate is null then t.tref_jn_hold else t.tref_vch_no_c end,t.tref_transref)  ")

        sb.Append("select diff,case when diff >=1 and diff <=7 then 'G1'  ")
        sb.Append("when diff >=8 and diff <=14 then 'G2'  ")
        sb.Append("when diff >=15 and diff <=21 then 'G3'     ")
        sb.Append("when diff >=22 and diff <=28 then 'G4' ")
        sb.Append("when diff >=29 and diff <=35 then 'G5' ")
        sb.Append("when diff >=36 then 'G6'  end diffgroup, ")
        sb.Append("jn_vch,tref_paiddate,tref_transref,gl_amt,gp_amt,tax_amt ")
        sb.Append("from ")
        sb.Append("(select   ")
        sb.Append("to_date(t.tref_paiddate,'YYYYMMDD')-to_date('" & business_date & "','YYYYMMDD') as diff,t.tref_transref,t.tref_paiddate,  ")
        sb.Append("case when t.tref_approveddate is null then t.tref_jn_hold else t.tref_vch_no_c end as jn_vch,  ")
        sb.Append("gl.glcr_amount as gl_amt,gp.gpcr_amount as gp_amt,w.taxcr_tax_amt as tax_amt  ")
        sb.Append("from (((gps_transref_rel t inner join  ")
        sb.Append("(select glcr.glcr_createdate,glcr.glcr_core_system,glcr.glcr_transref,sum(glcr.glcr_amount)as glcr_amount from gps_gl_creation glcr ")
        sb.Append(" inner join GLM_ACCOUNT_SETUP glacc ON glcr.glcr_s_account=glacc.acnt_s_code ")
        sb.Append("where glcr.glcr_drcr='C' and glacc.acnt_flag_acntpay='Y' and glcr.glcr_s_tt_tr='00000000' ")
        sb.Append("group by glcr.glcr_createdate,glcr.glcr_core_system,glcr.glcr_transref ")
        sb.Append(") gl  ")
        sb.Append("on t.tref_createdate=gl.glcr_createdate  ")
        sb.Append("and t.tref_core_system=gl.glcr_core_system  ")
        sb.Append("and t.tref_transref=gl.glcr_transref)   ")
        sb.Append("inner join  ")
        sb.Append("(select gpcr_createdate,gpcr_core_system,gpcr_transref,sum(gpcr_amount) as gpcr_amount from gps_payment_creation  ")
        sb.Append("group by gpcr_createdate,gpcr_core_system,gpcr_transref) gp ")
        sb.Append("on t.tref_createdate=gp.gpcr_createdate  ")
        sb.Append("and t.tref_core_system=gp.gpcr_core_system  ")
        sb.Append("and t.tref_transref=gp.gpcr_transref)  ")
        sb.Append("left join  ")
        sb.Append("(select taxcr_createdate,taxcr_core_system,taxcr_transref,sum(taxcr_tax_amt) as taxcr_tax_amt from gps_wht_creation  ")
        sb.Append("group by taxcr_createdate,taxcr_core_system,taxcr_transref) w ")
        sb.Append("on t.tref_createdate=w.taxcr_createdate  ")
        sb.Append("and t.tref_core_system=w.taxcr_core_system  ")
        sb.Append("and t.tref_transref=w.taxcr_transref)  ")
        'sb.Append("where t.tref_paiddate > '" & business_date & "'  ")
        sb.Append("where t.tref_paycretyp_id='001' ")
        sb.Append("and t.tref_createdate <= '" & business_date & "'  ")
        sb.Append("and (t.tref_approvedby is null or t.tref_approveddate > '" & business_date & "' )  ")
        sb.Append("and t.tref_core_system='ACC' ) ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function DtRptPendingReceipt(ByRef oleConn As OleDbConnection, ByVal datefrom As String, ByVal dateto As String, ByVal core_system As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select g.payg_pay_groupname,r.tref_batch_no,r.tref_vch_no_c,p.gp_paiddate, ")
        sb.Append("case when p.gp_paymth='C' or p.gp_paymth='D' then p.gp_chqno else p.gp_payee_bnkaccno end chqno, ")
        sb.Append("case when p.gp_paymth='C' or p.gp_paymth='D' then p.gp_payee_name else p.gp_payee_bnkaccnme end payeename,   ")
        sb.Append("p.gp_amount,NVL(w.tax_tax_amt,0) as tax_amt, ")
        sb.Append("p.gp_paymth,p.gp_sub_paymth ")
        sb.Append("from ((((gps_payment p inner join gps_transref_rel r ")
        sb.Append("on p.gp_createdate=r.tref_createdate ")
        sb.Append("and p.gp_core_system=r.tref_core_system ")
        sb.Append("and p.gp_transref=r.tref_transref) ")
        sb.Append("left join gps_wht w ")
        'sb.Append("(select w.tax_createdate,w.tax_core_system,w.tax_transref,sum(w.tax_tax_amt) as tax_amt ")
        'sb.Append("(select w.tax_createdate,w.tax_core_system,w.tax_transref,w.tax_gptref_seqno,sum(w.tax_tax_amt) as tax_amt ")
        'sb.Append("from gps_wht w ")
        'sb.Append("group by w.tax_createdate,w.tax_core_system,w.tax_transref,w.tax_gptref_seqno ")
        'sb.Append(")w ")
        sb.Append("on p.gp_createdate=w.tax_createdate ")
        sb.Append("and p.gp_core_system=w.tax_core_system ")
        sb.Append("and p.gp_transref=w.tax_transref ")
        sb.Append("and p.gp_gptref_seqno=w.tax_gptref_seqno) ")
        sb.Append("inner join gps_tl_paytype t ")
        sb.Append("on p.gp_paymth=t.payt_paymth and p.gp_sub_paymth=t.payt_sub_paymth) ")
        sb.Append("inner join gps_tl_paygroup g on t.payt_pay_group=g.payg_pay_group) ")
        sb.Append("where p.gp_flag_flwbill='Y' ")
        sb.Append("and p.gp_lastupd_sts<>'W' and not(p.gp_paymth='M' and p.gp_lastupd_sts='R') ")
        sb.Append("and p.gp_lastupd_stsdate between '" & datefrom & "' and '" & dateto & "' ")
        sb.Append("and p.gp_core_system='" & core_system & "' ")
        sb.Append("order by g.payg_pay_groupname,p.gp_paiddate,r.tref_batch_no ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function DtRptRejectHis(ByRef oleConn As OleDbConnection, ByVal datefrom As String, ByVal dateto As String, ByVal rejtype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ,t.tref_vch_no_c as voucher_no,r.gprj_batchdate ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate between '" & datefrom & "' and '" & dateto & "'  ")

        If rejtype <> "0" Then
            Select Case rejtype
                Case "1"
                    sb.Append("and r.gprj_reject_func='VALIDATE' ")
                Case "2"
                    sb.Append("and r.gprj_reject_func='HASH' ")
                Case "3"
                    sb.Append("and r.gprj_reject_func='BANK' ")
                Case "4"
                    sb.Append("and r.gprj_reject_func='ACC_CAN' ")
            End Select
        End If



        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function GetDataGL(ByRef oleConn As OleDbConnection, ByVal strFromDate As String, ByVal strToDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT  COUNT(*) OVER (ORDER BY t.gl_posting_date, t.gl_jn_no, t.gl_vch_no, t.gl_lineno) ")
        sb.Append("        || ',' || '""' || t.gl_posting_date || '""' ")
        sb.Append("        || ',' || '""' || t.gl_system_name || '""' ")
        sb.Append("        || ',' || '""' || t.gl_jn_type || '""' ")
        sb.Append("        || ',' || '""' || t.gl_jn_source || '""' ")
        sb.Append("        || ',' || '""' || t.gl_b_unit || '""' ")
        sb.Append("        || ',' || '""' || t.gl_period || '""' ")
        sb.Append("        || ',' || '""' || t.gl_jn_no || '""' ")
        sb.Append("        || ',' || '""' || t.gl_vch_no || '""' ")
        sb.Append("        || ',' || '""' || t.gl_transref || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_account || '""' ")
        sb.Append("        || ',' || t.gl_lineno ")
        sb.Append("        || ',' || '""' || t.gl_glsts || '""' ")
        sb.Append("        || ',' || '""' || t.gl_bookid || '""' ")
        sb.Append("        || ',' || '""' || t.gl_source_nme || '""' ")
        sb.Append("        || ',' || '""' || t.gl_category_nme || '""' ")
        sb.Append("        || ',' || '""' || t.gl_currency_cde || '""' ")
        sb.Append("        || ',' || '""' || t.gl_actual_flag || '""' ")
        sb.Append("        || ',' || '""' || t.gl_company_cde || '""' ")
        sb.Append("        || ',' || '""' || t.gl_rccode || '""' ")
        sb.Append("        || ',' || '""' || t.gl_transdate || '""' ")
        sb.Append("        || ',' || '""' || t.gl_duedate || '""' ")
        sb.Append("        || ',' || '""' || t.gl_desc || '""' ")
        sb.Append("        || ',' || t.gl_amount ")
        sb.Append("        || ',' || '""' || t.gl_drcr || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_dep_brn || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_pl_pt || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_mkt_emp || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_tt_tr || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_project || '""' ")
        sb.Append("        || ',' || '""' || t.createdby || '""' ")
        sb.Append("        || ',' || '""' || t.createddate || '""' ")
        sb.Append("        || ',' || '""' || t.updatedby || '""' ")
        sb.Append("        || ',' || '""' || t.updateddate || '""' ")
        sb.Append("        || ',' || '""' || t.gl_function || '""' ")
        sb.Append("        || ',' || '""' || t.gl_o_post_flag || '""' ")
        'Add New Field
        sb.Append("        || ',' || '""' || t.gl_sub_acct || '""' ")
        sb.Append("        || ',' || '""' || t.gl_analysis || '""' ")
        sb.Append("        || ',' || '""' || t.gl_intercompany || '""' ")
        sb.Append("        || ',' || '""' || t.gl_spare1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_treaty_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_event_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_2 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_currency_cde || '""' ")

        sb.Append("FROM    generatepayment.glm_gl_daily t ")
        sb.Append("WHERE   1 = 1 ")
        sb.Append("AND     t.gl_posting_date BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")
        sb.Append("ORDER BY ")
        sb.Append("        t.gl_posting_date, t.gl_jn_no, t.gl_vch_no, t.gl_lineno ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataPayment(ByRef oleConn As OleDbConnection, ByVal strFromDate As String, ByVal strToDate As String) As DataTable
        Dim sb As New StringBuilder
        'NOT SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft
        sb.Append("SELECT   '""' || L.TREF_BATCH_NO || '""'")
        sb.Append("         || ',' || '""' || G.PAYG_PAY_GROUPNAME || '""' ")
        '--sb.Append("         || ',' || '""' || P.GP_PAYMTH || P.GP_SUB_PAYMTH || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || P.GP_SEQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CONFIRMDATE || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_VCH_NO_C || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_TRANSREF || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CHQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_BNKCODE || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END || '""' ")
        sb.Append("         || ',' || nvl(W.TAX_BASE_AMT,0) ")
        sb.Append("         || ',' || nvl(W.TAX_TAX_AMT,0) ")
        sb.Append("         || ',' || nvl(P.GP_AMOUNT,0) ")
        sb.Append("         || ',' || '""' || W.MINTAX || '""' ")
        sb.Append("         || ',' || '""' || P.GP_PAYDESC || '""' ")
        sb.Append("         || ',' || '""' || S.STS_DESC || '""' ")
        sb.Append("         || ',' || '""' || P.GP_LASTUPD_STSDATE || '""' ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND NOT ((P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T') ")
        sb.Append("OR P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' )) ")
        sb.Append("AND P.GP_CONFIRMDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")

        sb.Append("UNION ALL ")

        'Direct Credit
        sb.Append("SELECT   '""' || L.TREF_BATCH_NO || '""'")
        sb.Append("         || ',' || '""' || G.PAYG_PAY_GROUPNAME || '""' ")
        '--sb.Append("         || ',' || '""' || P.GP_PAYMTH || P.GP_SUB_PAYMTH || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || P.GP_SEQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CONFIRMDATE || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_VCH_NO_C || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_TRANSREF || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CHQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_BNKCODE || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END || '""' ")
        sb.Append("         || ',' || nvl(W.TAX_BASE_AMT,0) ")
        sb.Append("         || ',' || nvl(W.TAX_TAX_AMT,0) ")
        sb.Append("         || ',' || nvl(P.GP_AMOUNT,0) ")
        sb.Append("         || ',' || '""' || W.MINTAX || '""' ")
        sb.Append("         || ',' || '""' || P.GP_PAYDESC || '""' ")
        sb.Append("         || ',' || '""' || S.STS_DESC || '""' ")
        sb.Append("         || ',' || '""' || P.GP_LASTUPD_STSDATE || '""' ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)='SCB' ")
        sb.Append("AND P.GP_CONFIRMDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")

        sb.Append("UNION ALL ")

        'Media Clearing
        sb.Append("SELECT   '""' || L.TREF_BATCH_NO || '""'")
        sb.Append("         || ',' || '""' || G.PAYG_PAY_GROUPNAME || '""' ")
        '--sb.Append("         || ',' || '""' || P.GP_PAYMTH || P.GP_SUB_PAYMTH || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || P.GP_SEQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CONFIRMDATE || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_VCH_NO_C || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_TRANSREF || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CHQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_BNKCODE || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END || '""' ")
        sb.Append("         || ',' || nvl(W.TAX_BASE_AMT,0) ")
        sb.Append("         || ',' || nvl(W.TAX_TAX_AMT,0) ")
        sb.Append("         || ',' || nvl(P.GP_AMOUNT,0) ")
        sb.Append("         || ',' || '""' || W.MINTAX || '""' ")
        sb.Append("         || ',' || '""' || P.GP_PAYDESC || '""' ")
        sb.Append("         || ',' || '""' || S.STS_DESC || '""' ")
        sb.Append("         || ',' || '""' || P.GP_LASTUPD_STSDATE || '""' ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF  ")
        sb.Append(" WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%'          ")
        sb.Append("AND P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='M' AND UPPER(P.GP_BNKCODE)<>'SCB' ")
        sb.Append("AND P.GP_CONFIRMDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")

        sb.Append("UNION ALL ")

        '-- SCB Cashier Cheque, SCB Gift Cheque, Money Order, Bank Draft ")
        sb.Append("SELECT   '""' || L.TREF_BATCH_NO || '""'")
        sb.Append("         || ',' || '""' || G.PAYG_PAY_GROUPNAME || '""' ")
        '--sb.Append("         || ',' || '""' || P.GP_PAYMTH || P.GP_SUB_PAYMTH || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || P.GP_SEQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CONFIRMDATE || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_VCH_NO_C || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_TRANSREF || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_CHQNO ELSE P.GP_PAYEE_BNKACCNO END || '""' ")
        sb.Append("         || ',' || '""' || P.GP_CHQNO || '""' ")
        sb.Append("         || ',' || '""' || P.GP_BNKCODE || '""' ")
        sb.Append("         || ',' || '""' || CASE WHEN (L.TREF_PAYMTH='C' OR L.TREF_PAYMTH='D') THEN P.GP_PAYEE_NAME ELSE P.GP_PAYEE_BNKACCNME END || '""' ")
        sb.Append("         || ',' || nvl(W.TAX_BASE_AMT,0) ")
        sb.Append("         || ',' || nvl(W.TAX_TAX_AMT,0) ")
        sb.Append("         || ',' || nvl(P.GP_AMOUNT,0) ")
        sb.Append("         || ',' || '""' || W.MINTAX || '""' ")
        sb.Append("         || ',' || '""' || P.GP_PAYDESC || '""' ")
        sb.Append("         || ',' || '""' || S.STS_DESC || '""' ")
        sb.Append("         || ',' || '""' || P.GP_LASTUPD_STSDATE || '""' ")
        sb.Append("FROM GPS_TRANSREF_REL L INNER JOIN GPS_PAYMENT P  ")
        sb.Append("ON L.TREF_CREATEDATE=P.GP_CREATEDATE  ")
        sb.Append("AND L.TREF_CORE_SYSTEM=P.GP_CORE_SYSTEM  ")
        sb.Append("AND L.TREF_TRANSREF=P.GP_TRANSREF  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH  ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G  ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S  ")
        sb.Append("ON P.GP_PAYMTH=S.STS_PAYMTH AND P.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH  ")
        sb.Append("AND P.GP_LASTUPD_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO,MIN(W.TAX_WHTNO) AS MINTAX,MAX(W.TAX_WHTNO) AS MAXTAX, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W LEFT JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON W.TAX_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=I.GP_TRANSREF ")
        sb.Append("AND W.TAX_GPTREF_SEQNO=I.GP_GPTREF_SEQNO ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_TRANSREF,I.GP_SEQNO      ")
        sb.Append(") W  ")
        sb.Append("ON L.TREF_CREATEDATE=W.TAX_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=W.TAX_TRANSREF  ")
        sb.Append("AND P.GP_SEQNO=W.GP_SEQNO ")
        sb.Append("LEFT JOIN   ")
        sb.Append("( SELECT I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF, COUNT(*) detail   ")
        sb.Append("FROM GPS_INSTRUMENT I   ")
        sb.Append("GROUP BY I.GP_CREATEDATE,I.GP_CORE_SYSTEM,I.GP_TRANSREF) I   ")
        sb.Append("ON L.TREF_CREATEDATE = I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM =I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF = I.GP_TRANSREF ")
        sb.Append("WHERE 1=1 ")
        sb.Append("AND T.PAYT_PAY_GROUP LIKE '%' ")
        sb.Append("AND (P.GP_PAYMTH='C' AND (P.GP_SUB_PAYMTH='H' OR P.GP_SUB_PAYMTH='G' OR P.GP_SUB_PAYMTH='B' OR P.GP_SUB_PAYMTH='T')) ")
        sb.Append("AND P.GP_CONFIRMDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")

        sb.Append("UNION ALL ")

        '--------Detaildata

        sb.Append("SELECT   '""' || L.TREF_BATCH_NO || '""'")
        sb.Append("         || ',' || '""' || G.PAYG_PAY_GROUPNAME || '""' ")
        '--sb.Append("         || ',' || '""' || I.GP_PAYMTH || I.GP_SUB_PAYMTH || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || T.PAYT_PAYTYPE || '""' ")
        sb.Append("         || ',' || '""' || I.GP_SEQNO || '""' ")
        sb.Append("         || ',' || '""' || I.GP_CONFIRMDATE || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_VCH_NO_C || '""' ")
        sb.Append("         || ',' || '""' || L.TREF_TRANSREF || '""' ")
        sb.Append("         || ',' || '""' || I.GP_INSTRUMENT_NO || '""' ")
        sb.Append("         || ',' || '""' || I.GP_INSTRUMENT_NO || '""' ")
        sb.Append("         || ',' || '""' || I.GP_BNKCODE || '""' ")
        sb.Append("         || ',' || '""' || I.GP_PAYEE_NAME || '""' ")
        sb.Append("         || ',' || nvl(W.TAX_BASE_AMT,0) ")
        sb.Append("         || ',' || nvl(W.TAX_TAX_AMT,0) ")
        sb.Append("         || ',' || nvl(I.GP_AMOUNT,0) ")
        sb.Append("         || ',' || '""' || W.MINTAX || '""' ")
        sb.Append("         || ',' || '""' || I.GP_PAYDESC || '""' ")
        sb.Append("         || ',' || '""' || S.STS_DESC || '""' ")
        sb.Append("         || ',' || '""' || I.GP_LASTUPD_STSDATE || '""' ")
        sb.Append("FROM (GPS_TRANSREF_REL L INNER JOIN GPS_INSTRUMENT I    ")
        sb.Append("ON L.TREF_CREATEDATE=I.GP_CREATEDATE   ")
        sb.Append("AND L.TREF_CORE_SYSTEM=I.GP_CORE_SYSTEM   ")
        sb.Append("AND L.TREF_TRANSREF=I.GP_TRANSREF )  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH   ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G   ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP  ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S   ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH   ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS   ")
        sb.Append("LEFT JOIN   ")
        sb.Append("(SELECT W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF, ")
        sb.Append("MIN(W.TAX_WHTNO) AS MINTAX, MAX(W.TAX_WHTNO) AS MAXTAX,   ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT   ")
        sb.Append("FROM  GPS_WHT W   ")
        sb.Append("GROUP BY W.TAX_CREATEDATE,W.TAX_CORE_SYSTEM,W.TAX_GPTREF_SEQNO,W.TAX_TRANSREF) W  ")
        sb.Append("ON I.GP_CREATEDATE=W.TAX_CREATEDATE    ")
        sb.Append("AND I.GP_CORE_SYSTEM=W.TAX_CORE_SYSTEM    ")
        sb.Append("AND I.GP_TRANSREF=W.TAX_TRANSREF    ")
        sb.Append("AND I.GP_GPTREF_SEQNO=W.TAX_GPTREF_SEQNO    ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T    ")
        sb.Append("ON I.GP_PAYMTH=T.PAYT_PAYMTH    ")
        sb.Append("AND I.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH    ")
        sb.Append("INNER JOIN GPS_TL_PAYGROUP G    ")
        sb.Append("ON T.PAYT_PAY_GROUP=G.PAYG_PAY_GROUP    ")
        sb.Append("LEFT JOIN    ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='LSTUPD_STS')S    ")
        sb.Append("ON I.GP_PAYMTH=S.STS_PAYMTH AND I.GP_SUB_PAYMTH=S.STS_SUB_PAYMTH    ")
        sb.Append("AND I.GP_LASTUPD_STS=S.STS_STATUS    ")
        sb.Append("WHERE 1=1 ")
        sb.Append("AND I.GP_CONFIRMDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataPaymentReject(ByRef oleConn As OleDbConnection, ByVal strFromDate As String, ByVal strToDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select '""' || c.csys_core_systemname || '""'")
        sb.Append("       || ',' || '""' || d.dep_depname || '""'")
        sb.Append("       || ',' || '""' || r.gprj_paiddate || '""'")
        sb.Append("       || ',' || '""' || payt_paytype || '""'")
        sb.Append("       || ',' || '""' || s.dts_business || '""'")
        sb.Append("       || ',' || '""' || t.tref_vch_no_c || '""'")
        sb.Append("       || ',' || '""' || r.gprj_desc || '""'")
        sb.Append("       || ',' || '""' || r.gprj_polno || '""'")
        sb.Append("       || ',' || '""' || r.gprj_bnkcode || '""'")
        sb.Append("       || ',' || '""' || r.gprj_payee_bnkaccno || '""'")
        sb.Append("       || ',' || '""' || case")
        sb.Append("         when r.gprj_paymth = 'M' then")
        sb.Append("        r.gprj_payee_bnkaccnme")
        sb.Append("         else")
        sb.Append("        r.gprj_payee_name")
        sb.Append("       end || '""'")
        sb.Append("       || ',' || '""' || r.gprj_amount || '""'")
        sb.Append("       || ',' || '""' || r.gprj_reject_type || '""'")
        sb.Append("       || ',' || '""' || rt.rejt_rej_group || '""'")
        sb.Append("       || ',' || '""' || rt.rejt_rej_massage || '""'")
        sb.Append("       || ',' || '""' || r.gprj_batchdate || '""'")
        sb.Append("  from gps_payment_rej r")
        sb.Append(" inner join gps_transref_rel t")
        sb.Append("    on r.gprj_createdate = t.tref_createdate")
        sb.Append("   and r.gprj_core_system = t.tref_core_system")
        sb.Append("   and r.gprj_transref = t.tref_transref")
        sb.Append(" inner join gps_tl_paytype p")
        sb.Append("    on r.gprj_paymth = p.payt_paymth")
        sb.Append("   and r.gprj_sub_paymth = p.payt_sub_paymth")
        sb.Append(" inner join gps_tl_core_system c")
        sb.Append("    on r.gprj_core_system = c.csys_core_system")
        sb.Append(" inner join gps_tl_datasource s")
        sb.Append("    on r.gprj_core_system = s.dts_core_system")
        sb.Append("   and t.tref_dtsource = s.dts_dtsource")
        sb.Append("   and t.tref_dep_repay = s.dts_dep_repay")
        sb.Append(" inner join gps_tl_reject_type rt")
        sb.Append("    on r.gprj_reject_type = rt.rejt_rej_type")
        sb.Append(" inner join gps_tl_department d")
        sb.Append("    on t.tref_dep_repay = d.dep_depcode")
        sb.Append(" where r.gprj_batchdate between '" & strFromDate & "' and '" & strToDate & "'")
        sb.Append("")
        sb.Append("        Union ")
        sb.Append("")
        sb.Append("select '""' || 'IL'  || '""'")
        sb.Append("     || ',' || '""' || tr.tltrans_department || '""'")
        sb.Append("     || ',' || '""' || r.payrj_2_value_date || '""'")
        sb.Append("     || ',' || '""' || case r.payrj_prod_code")
        sb.Append("         when 'CCP' then 'SCB Corporate Cheque'")
        sb.Append("         when 'MCP' then 'SCB M Draft'")
        sb.Append("         when 'DDP' then 'Draft'")
        sb.Append("         when 'DCP' then 'Direct Credit'")
        sb.Append("         when 'MCL' then 'Media Clearing'")
        sb.Append("         else r.payrj_prod_code")
        sb.Append("       end || '""'")
        sb.Append("     || ',' || '""' || tr.tltrans_name || '""'")
        sb.Append("      || ',' || '""' || '' || '""'") '-- voucher no
        sb.Append("      || ',' || '""' || '' || '""'") '-- desc
        sb.Append("      || ',' || '""' || r.payrj_polno || '""'") '-- policy
        sb.Append("      || ',' || '""' || b.bkmst_bnkcode || '""'") '-- bank code
        sb.Append("      || ',' || '""' || r.payrj_3_c_acc_no || '""'") '-- bank a/c no
        sb.Append("      || ',' || '""' || t.rjil_payee_nme || '""'") '-- payee name
        sb.Append("      || ',' || '""' || r.payrj_3_c_amt_num || '""'") '-- amount
        sb.Append("      || ',' || '""' || t.rjil_reject_func || '""'") '-- reject function
        sb.Append("      || ',' || '""' || t.rjil_reject_type || '""'") '-- reject type
        sb.Append("      || ',' || '""' || t.rjil_reject_reason || '""'") '-- reject reason
        sb.Append("      || ',' || '""' || t.rjil_rej_date || '""'") '-- status date

        sb.Append("  from (select * from generatepayment.payout_reject_log) t")
        sb.Append("       left join (select payrj_trans_date, payrj_file_name, payrj_rec_type, payrj_prod_code, payrj_seqno, payrj_2_value_date, payrj_2_prod_code, payrj_2_d_acc_no, payrj_2_d_acc_type, payrj_2_d_brncde, payrj_2_d_currency, payrj_2_d_amt, payrj_2_d_amt_num, payrj_2_internal_ref, payrj_2_noof_c, payrj_2_free_d_acc, payrj_2_filler, payrj_2_media_cycle, payrj_2_free_acc_type, payrj_2_free_d_brncde, payrj_3_c_seqno, payrj_3_c_acc_no, payrj_3_c_amt, payrj_3_c_amt_num, payrj_3_c_currency, payrj_3_internal_ref, payrj_3_wht_pre, payrj_3_inv_pre, payrj_3_c_advice, payrj_3_deli_mode, payrj_3_pickup, payrj_3_wht_frmtyp, payrj_3_wht_runno, payrj_3_wht_attno, payrj_3_noof_wht, payrj_3_tot_wht_amt, payrj_3_noof_inv, payrj_3_tot_inv_amt, payrj_3_wht_paytyp, payrj_3_wht_remark, payrj_3_wht_de_date, payrj_3_rec_bnkcde, payrj_3_rec_bnknme, payrj_3_rec_brncde, payrj_3_rec_brnnme, payrj_3_wht_sign, payrj_3_bene_noti, trim(payrj_3_cust_ref) payrj_3_cust_ref, payrj_3_chq_ref, payrj_3_paytyp_cde, payrj_3_servtyp, payrj_3_remark, payrj_3_scb_remark, payrj_3_bene_charge, payrj_4_internal_ref, payrj_4_c_seqno, payrj_4_payee1_idcard, payrj_4_payee1_nmetha, payrj_4_payee1_addr1, payrj_4_payee1_addr2, payrj_4_payee1_addr3, payrj_4_payee1_taxid, payrj_4_payee1_nmeeng, payrj_4_payee1_faxno, payrj_4_payee1_phone, payrj_4_payee1_email, payrj_4_payee2_nmetha, payrj_4_payee2_addr1, payrj_4_payee2_addr2, payrj_4_payee2_addr3, payrj_flg_transform, payrj_trans_code, payrj_polno, payrj_user_id, payrj_dept_id, source, payrj_reject_type, payrj_reject_func, createdby, updatedby, createddate, updateddate from generatepayment.payout_tobank_detail_il_rej where payrj_rec_type = '003') r")
        sb.Append("         on t.rjil_cust_ref = r.payrj_3_cust_ref")
        sb.Append("       left join (select payrj_trans_date, payrj_file_name, payrj_rec_type, payrj_prod_code, payrj_seqno, payrj_2_value_date, payrj_2_prod_code, payrj_2_d_acc_no, payrj_2_d_acc_type, payrj_2_d_brncde, payrj_2_d_currency, payrj_2_d_amt, payrj_2_d_amt_num, payrj_2_internal_ref, payrj_2_noof_c, payrj_2_free_d_acc, payrj_2_filler, payrj_2_media_cycle, payrj_2_free_acc_type, payrj_2_free_d_brncde, payrj_3_c_seqno, payrj_3_c_acc_no, payrj_3_c_amt, payrj_3_c_amt_num, payrj_3_c_currency, payrj_3_internal_ref, payrj_3_wht_pre, payrj_3_inv_pre, payrj_3_c_advice, payrj_3_deli_mode, payrj_3_pickup, payrj_3_wht_frmtyp, payrj_3_wht_runno, payrj_3_wht_attno, payrj_3_noof_wht, payrj_3_tot_wht_amt, payrj_3_noof_inv, payrj_3_tot_inv_amt, payrj_3_wht_paytyp, payrj_3_wht_remark, payrj_3_wht_de_date, payrj_3_rec_bnkcde, payrj_3_rec_bnknme, payrj_3_rec_brncde, payrj_3_rec_brnnme, payrj_3_wht_sign, payrj_3_bene_noti, trim(payrj_3_cust_ref) payrj_3_cust_ref, payrj_3_chq_ref, payrj_3_paytyp_cde, payrj_3_servtyp, payrj_3_remark, payrj_3_scb_remark, payrj_3_bene_charge, payrj_4_internal_ref, payrj_4_c_seqno, payrj_4_payee1_idcard, payrj_4_payee1_nmetha, payrj_4_payee1_addr1, payrj_4_payee1_addr2, payrj_4_payee1_addr3, payrj_4_payee1_taxid, payrj_4_payee1_nmeeng, payrj_4_payee1_faxno, payrj_4_payee1_phone, payrj_4_payee1_email, payrj_4_payee2_nmetha, payrj_4_payee2_addr1, payrj_4_payee2_addr2, payrj_4_payee2_addr3, payrj_flg_transform, payrj_trans_code, payrj_polno, payrj_user_id, payrj_dept_id, source, payrj_reject_type, payrj_reject_func, createdby, updatedby, createddate, updateddate from generatepayment.payout_tobank_detail_il_rej where payrj_rec_type = '004') r4")
        sb.Append("         on r4.payrj_3_cust_ref = r.payrj_3_cust_ref")
        sb.Append("        and r4.payrj_seqno = r.payrj_seqno")
        sb.Append("       left join (select * from generatepayment.payout_tl_transcode_il) tr")
        sb.Append("         on r.payrj_trans_code = tr.tltrans_code")
        sb.Append("       left join (select * from generatepayment.payout_tl_dept) d")
        sb.Append("         on r.payrj_dept_id = d.dept_id")
        sb.Append("       left join (select * from generatepayment.gps_tl_bankmaster ) b")
        sb.Append("         on r.payrj_3_rec_bnkcde = b.bkmst_bnkcode_no")
        sb.Append(" where t.rjil_rej_date between '" & strFromDate & "' and '" & strToDate & "'")
        sb.Append("")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataReconcileSummaryGL(ByRef oleConn As OleDbConnection, ByVal strFromTransDate As String, ByVal strToTransDate As String, ByVal strFromGlDate As String, ByVal strToGlDate As String, ByVal StartAccount As String, ByVal ToAccount As String, ByVal StartSubAccount As String, ByVal ToSubAccount As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select '""' || substr(trim(GL_TRANSDATE),7,2) || '-' | | substr(trim(GL_TRANSDATE),5,2) || '-'  || substr(trim(GL_TRANSDATE),1,4) || '""'") 'Transaction Date
        sb.Append("        || ',' || '""' || substr(trim(GL_POSTING_DATE),7,2) || '-' | | substr(trim(GL_POSTING_DATE),5,2) || '-'  || substr(trim(GL_POSTING_DATE),1,4) || '""' ") 'Accounting Date
        sb.Append("        || ',' || '""' || t.gl_source_nme || '""' ")
        sb.Append("        || ',' || '""' || 'DAP' || '""' ") 'File Propose 
        sb.Append("        || ',' || '""' || t.gl_company_cde || '""' ")
        sb.Append("        || ',' || '""' || t.gl_rccode || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_account || '""' ")
        sb.Append("        || ',' || '""' || t.gl_sub_acct || '""' ")
        sb.Append("        || ',' || '""' || '' || '""' ") 'Account (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'SubAccount (Group)
        sb.Append("        || ',' || '""' || t.gl_s_pl_pt || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_dep_brn || '""' ")
        sb.Append("        || ',' || '""' || t.gl_analysis || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_mkt_emp || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_project || '""' ")
        sb.Append("        || ',' || '""' || t.gl_intercompany || '""' ")
        sb.Append("        || ',' || '""' || t.gl_spare1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_treaty_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_event_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_2 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_5 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_6 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_7 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_8 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_9 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_10 || '""' ")
        sb.Append("        || ',' || '""' || '' || '""' ") 'Product (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Cost Centre (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Analysis (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Channel (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Project (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Intercompany (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'SPARE1 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Treaty Code (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Event Code (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Local 3 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'Local 4 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_1 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_2 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_3 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_4 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_5 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_6 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_7 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_8 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_9 (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'REF_10 (Group)
        sb.Append("        || ',' || '""' || t.gl_currency_cde || '""' ")
        sb.Append("        || ',' || '""' || '' || '""' ") 'Charge code
        sb.Append("        || ',' || '""' || trim(to_char(nvl(GL_AMOUNT,0.00),'99999999999990.99')) || '""' ") 'Accounting Amount 
        sb.Append("        || ',' || '""' || case upper(substr(gl_drcr,1,1)) when 'D' then trim(to_char(nvl(GL_AMOUNT,0.00),'99999999999990.99')) else trim(to_char(nvl(GL_AMOUNT,0.00) * -1,'99999999999990.99')) end || '""' ")
        sb.Append("        || ',' || '""' || t.gl_drcr || '""' ")

        sb.Append("FROM    generatepayment.glm_gl_daily t ")
        sb.Append("WHERE   1 = 1 ")
        sb.Append("AND     t.gl_o_post_flag = 'Y' ")
        sb.Append("AND     t.gl_transdate BETWEEN '" & strFromTransDate & "' AND '" & strToTransDate & "'")
        sb.Append("AND     t.gl_posting_date BETWEEN '" & strFromGlDate & "' AND '" & strToGlDate & "'")
        sb.Append("AND     t.gl_s_account BETWEEN '" & StartAccount & "' AND '" & ToAccount & "' ")
        sb.Append("AND     t.gl_sub_acct BETWEEN '" & StartSubAccount & "' AND '" & ToSubAccount & "' ")
        sb.Append("ORDER BY ")
        sb.Append("        t.gl_transdate, t.gl_s_account||t.gl_sub_acct ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataReconcileDetailGL(ByRef oleConn As OleDbConnection, ByVal strFromTransDate As String, ByVal strToTransDate As String, ByVal strFromGlDate As String, ByVal strToGlDate As String, ByVal StartAccount As String, ByVal ToAccount As String, ByVal StartSubAccount As String, ByVal ToSubAccount As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select '""' || substr(trim(GL_POSTING_DATE),7,2) || '-' | | substr(trim(GL_POSTING_DATE),5,2) || '-'  || substr(trim(GL_POSTING_DATE),1,4) || '""'") 'Accounting Date
        sb.Append("        || ',' || '""' || '' || '""' ") 'Effective Date
        sb.Append("        || ',' || '""' || '' || '""' ") 'Transaction Date
        sb.Append("        || ',' || '""' || '' || '""' ") 'TranNo
        sb.Append("        || ',' || '""' || '' || '""' ") 'TranNo_Reverse
        sb.Append("        || ',' || '""' || '' || '""' ") 'Contract No.
        sb.Append("        || ',' || '""' || '' || '""' ") 'Reference No.
        sb.Append("        || ',' || '""' || '' || '""' ") 'OWNERNAME
        sb.Append("        || ',' || '""' || '' || '""' ") 'BATCTRCDE
        sb.Append("        || ',' || '""' || '' || '""' ") 'BATCBATCH
        sb.Append("        || ',' || '""' || '' || '""' ") 'RDOCNUM
        sb.Append("        || ',' || '""' || '' || '""' ") 'Contract type
        sb.Append("        || ',' || '""' || '' || '""' ") 'Receive Date
        sb.Append("        || ',' || '""' || t.gl_s_account || '""' ") 'ACCT (Local)
        sb.Append("        || ',' || '""' || t.gl_sub_acct || '""' ") 'SUB_ACCT (Local)
        sb.Append("        || ',' || '""' || t.gl_s_account || '""' ") 'ACCT  (Group)
        sb.Append("        || ',' || '""' || t.gl_sub_acct || '""' ") 'SUB_ACCT (Group)
        sb.Append("        || ',' || '""' || '' || '""' ") 'SACSCODE
        sb.Append("        || ',' || '""' || '' || '""' ") 'SACSTYP
        sb.Append("        || ',' || '""' || '' || '""' ") 'GLCODE
        sb.Append("        || ',' || '""' || t.gl_s_mkt_emp || '""' ") 'Source of Business
        sb.Append("        || ',' || '""' || '' || '""' ") 'RLDGACCT
        sb.Append("        || ',' || '""' || '' || '""' ") 'YRSINF
        sb.Append("        || ',' || '""' || '' || '""' ") 'BANKCODE
        sb.Append("        || ',' || '""' || '' || '""' ") 'BNKDSC
        sb.Append("        || ',' || '""' || '' || '""' ") 'Charge code
        sb.Append("        || ',' || '""' || '' || '""' ") 'Agent code
        sb.Append("        || ',' || '""' || '' || '""' ") 'Pay to Agent
        sb.Append("        || ',' || '""' || trim(to_char(nvl(GL_AMOUNT,0.00),'99999999999990.99')) || '""' ") 'DEFAULT_AMOUNT
        sb.Append("        || ',' || '""' || case upper(substr(gl_drcr,1,1)) when 'D' then trim(to_char(nvl(GL_AMOUNT,0.00),'99999999999990.99')) else trim(to_char(nvl(GL_AMOUNT,0.00)*-1,'99999999999990.99')) end || '""' ") 'DEFAULT_AMOUNT_WITH_SIGN
        sb.Append("        || ',' || '""' || t.gl_currency_cde || '""' ")
        sb.Append("        || ',' || '""' || t.gl_conversion_type || '""' ")
        sb.Append("        || ',' || '""' || trim(to_char(nvl(gl_conversion_rate,1.0000),'99999999999990.9999')) || '""' ")
        sb.Append("        || ',' || '""' || case when length(gl_conversion_date)=10 then substr(trim(gl_conversion_date),9,2) || '-' | | substr(trim(gl_conversion_date),6,2) || '-'  || substr(trim(gl_conversion_date),1,4) else '' end || '""' ") 'CONVERSION_DATE
        sb.Append("        || ',' || '""' || trim(to_char(nvl( nvl(GL_AMOUNT,0.00)*nvl(GL_CONVERSION_RATE,1.0000),0.00),'99999999999990.99')) || '""' ") 'ACCOUNTED_AMOUNT
        sb.Append("        || ',' || '""' || case upper(substr(gl_drcr,1,1)) when 'D' then trim(to_char(nvl( nvl(GL_AMOUNT,0.00)*nvl(GL_CONVERSION_RATE,1.0000),0.00),'99999999999990.99')) else trim(to_char(nvl( nvl(GL_AMOUNT,0.00)*nvl(GL_CONVERSION_RATE,1.0000),0.00)*-1,'99999999999990.99')) end || '""' ") 'ACCOUNTED_AMOUNT_WITH_SIGN
        sb.Append("        || ',' || '""' || t.gl_drcr || '""' ")
        '--        sb.Append("        || ',' || '""' || '' || '""' ") 'LINE_DESCRIPTION
        sb.Append("        || ',' || '""' || t.gl_desc || '""' ") 'LINE_DESCRIPTION
        sb.Append("        || ',' || '""' || t.gl_line_trx_ref1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_line_trx_ref2 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_line_trx_ref3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_company_cde || '""' ") 'COMPANY (Local)
        sb.Append("        || ',' || '""' || t.gl_rccode || '""' ") 'LOB (Local)
        sb.Append("        || ',' || '""' || t.gl_s_pl_pt || '""' ") 'PRODUCT (Local)
        sb.Append("        || ',' || '""' || t.gl_s_dep_brn || '""' ") 'CC (Local)
        sb.Append("        || ',' || '""' || t.gl_analysis || '""' ") 'ANALYSIS (Local)
        sb.Append("        || ',' || '""' || t.gl_s_mkt_emp || '""' ") 'CHANNEL (Local)
        sb.Append("        || ',' || '""' || t.gl_s_project || '""' ") 'PROJECT (Local)
        sb.Append("        || ',' || '""' || t.gl_intercompany || '""' ") 'INTERCOMPANY (Local)
        sb.Append("        || ',' || '""' || t.gl_spare1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_treaty_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_event_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_2 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_5 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_6 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_7 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_8 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_9 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_10 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_s_pl_pt || '""' ") 'PRODUCT (Group)
        sb.Append("        || ',' || '""' || t.gl_s_dep_brn || '""' ") 'CC  (Group)
        sb.Append("        || ',' || '""' || t.gl_analysis || '""' ") 'ANALYSIS  (Group)
        sb.Append("        || ',' || '""' || t.gl_s_mkt_emp || '""' ") 'CHANNEL  (Group)
        sb.Append("        || ',' || '""' || t.gl_s_project || '""' ") 'PROJECT  (Group)
        sb.Append("        || ',' || '""' || t.gl_intercompany || '""' ") 'INTERCOMPANY  (Group)
        sb.Append("        || ',' || '""' || t.gl_spare1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_treaty_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_event_code || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_local4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_1 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_2 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_3 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_4 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_5 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_6 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_7 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_8 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_9 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_ref_10 || '""' ")
        sb.Append("        || ',' || '""' || t.gl_source_nme || '""' ") 'SourceSystem

        sb.Append("FROM    generatepayment.glm_gl_daily t ")
        sb.Append("WHERE   1 = 1 ")
        sb.Append("AND     t.gl_o_post_flag = 'Y' ")
        sb.Append("AND     t.gl_transdate BETWEEN '" & strFromTransDate & "' AND '" & strToTransDate & "'")
        sb.Append("AND     t.gl_posting_date BETWEEN '" & strFromGlDate & "' AND '" & strToGlDate & "'")
        sb.Append("AND     t.gl_s_account BETWEEN '" & StartAccount & "' AND '" & ToAccount & "' ")
        sb.Append("AND     t.gl_sub_acct BETWEEN '" & StartSubAccount & "' AND '" & ToSubAccount & "' ")
        sb.Append("ORDER BY ")
        sb.Append("        t.gl_transdate, t.gl_s_account||t.gl_sub_acct ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetRunningDataGL(ByRef oleConn As OleDbConnection) As Integer
        Dim running = -1
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("SELECT VALUE FROM GPS_COMPANY_SETUP ")
        sb.Append("WHERE ID=801 AND CODE='GLED' ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If IsDBNull(dt.Rows(0)(0)) OrElse String.IsNullOrEmpty(dt.Rows(0)(0)) OrElse dt.Rows(0)(0).ToString <> DateTime.Now.ToString("yyyyMMdd") Then
                Dim oleTrans As OleDbTransaction
                oleTrans = oleConn.BeginTransaction()
                sb = New StringBuilder
                sb.Append("UPDATE GPS_COMPANY_SETUP SET VALUE='" & DateTime.Now.ToString("yyyyMMdd") & "' ")
                sb.Append("WHERE ID=801 AND CODE='GLED' ")
                rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
                If rec <= 0 Then
                    oleTrans.Rollback()
                    Throw New Exception("Update Running Data Error..!")
                End If
                sb = New StringBuilder
                sb.Append("UPDATE GPS_COMPANY_SETUP SET VALUE='0' ")
                sb.Append("WHERE ID=802 AND CODE='GLER' ")
                rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
                If rec <= 0 Then
                    oleTrans.Rollback()
                    Throw New Exception("Update Running Number Error..!")
                End If
                oleTrans.Commit()
            End If
        Else
            Throw New Exception("Running Data not found..!")
        End If

        sb = New StringBuilder
        sb.Append("SELECT VALUE FROM GPS_COMPANY_SETUP ")
        sb.Append("WHERE ID=802 AND CODE='GLER' ")
        dt = New DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            running = Convert.ToInt16(dt.Rows(0)(0).ToString) + 1
        Else
            Throw New Exception("Running Number not found..!")
        End If

        sb = New StringBuilder
        sb.Append("UPDATE GPS_COMPANY_SETUP SET VALUE='" & running.ToString & "' ")
        sb.Append("WHERE ID=802 AND CODE='GLER' ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb)
        If rec <= 0 Then
            Throw New Exception("Update Running Number Error..!")
        End If

        Return running
    End Function


End Class
