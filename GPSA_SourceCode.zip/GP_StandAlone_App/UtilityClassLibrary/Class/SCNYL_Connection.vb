Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports System.Threading
Public Class SCNYL_Connection

    ' For development team
    'Private Const INI_FILENAME = "\\devserve-1\SCNYL_Connection\Connection.ini"

    ' For production
    'Private Const INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"
    Private INI_FILENAME As String
    'key for encrypt and decrypt database password
    Private Shared InitVector As String = "encryptionVector" 'fix InitVector
    Private Shared Keysize As Integer = 256 'fix Keysize
    'Private Shared PassPhrase As String = "Z1X2C3V4B5N6M7a0s9d8f7g6h5j4k3l2Q1W2E3R4T5y0u9i8o7p6" 'fixPassPhrase
    Private Shared PassPhrase As String = "LZ=V!Nv-UyPJMfg%x8!Z" 'fixPassPhrase

    Private SYSNAME As String
    Private USERNAME As String
    Private SCHEMA As String
    Private SEQ As Integer
    Private logID As Integer
    Private scn As System.Data.IDbConnection = Nothing

    Private RUNAS_PW As String
    Private RUNAS_US As String

    Private RUNAS_DOMAIN_SCHEMA As String
    'Private Const INI_FILENAME = "D:\WebServices\Connection.ini"
    Declare Auto Function CloseHandle Lib "kernel32.dll" (ByVal hObject As Int32) As Int32

    Public Declare Auto Function ShowWindow Lib "user32" (ByVal hwnd As Long, ByVal nCmdShow As Long) As Long


    Public Sub New()
        'If System.Configuration.ConfigurationManager.AppSettings("SCNYL_Connection2005_ini") Is Nothing Then
        '    'INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"
        '    INI_FILENAME = "\\devserve-1\SCNYL_Connection\Connection_New.ini"
        'Else
        '    INI_FILENAME = System.Configuration.ConfigurationManager.AppSettings("SCNYL_Connection2005_ini").ToString.ToUpper & "\Connection.ini"
        'End If

        ''Production
        'INI_FILENAME = "\\Oraback\SCNYL_Connection\SCBLConnection.ini"
        'INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"

        'Test
        'INI_FILENAME = "\\devserve-1\SCNYL_Connection\SCBLConnection.ini"
        'INI_FILENAME = "D:\SCNYL_Connection\SCBLConnection.ini"
        INI_FILENAME = "D:\SCNYL_Connection\Connection2.ini"

        'INI_FILENAME = "\\devserve-1\SCNYL_Connection\Connection2.ini"
        'INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection2.ini" 'production

        'INI_FILENAME = "D:\SCBLConnection.ini"

    End Sub

    ' �������ͧ�ҹ������ Security_conn **���Ԩ��� Oracle
    Public Enum EnumAccessLocationType
        ALT_ORACLE = 0
        ALT_SQLSERVER = 1
    End Enum

    ' �������ͧ�ҹ�����ŷ������ҧ connection
    Public Enum EnumLocationType
        LT_ORACLE = 0
        LT_SQLSERVER = 1
        LT_AS400 = 2
    End Enum

    ' �������ͧ connection ����ͧ���������ҧ���
    Public Enum EnumConnectionType
        ORACLE_PROVIDER_FOR_OLEDB = 0       ' Oracle Provider for OLE DB
        MS_OLEDB_PROVIDER_FOR_ORACLE        ' Microsoft OLE DB Provider for Oracle
        MS_OLEDB_PROVIDER_FOR_SQLSERVER     ' Microsoft OLE DB Provider for SQL Server
        SQLSERVER_PROVIDER                  ' Microsoft SQL Server : SqlClient
        MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE   ' Microsoft OLE DB provider for ODBC Sybase Drivers 
        IBM_AS400_OLEDB_PROVIDER
    End Enum
    Public Function EncryptString(ByVal plainText As String, ByVal InitVector As String, ByVal Keysize As Integer, ByVal PassPhrase As String) As String
        EncryptString = EncryptStringFromBytes(plainText, InitVector, Keysize, PassPhrase)
        Console.WriteLine(EncryptString)
        Return EncryptString

    End Function
    Public Shared Function GetAuthorize(
      ByVal pAccessLocationType As Integer,
      ByVal pServiceName As String,
      ByVal pSystemName As String,
      ByVal pLocationType As Integer,
      ByVal pSeqID As Integer) As String
        ' ��ҹ initial file

        ''Production
        'Dim INI_FILENAME = "\\Oraback\SCNYL_Connection\SCBLConnection.ini"
        'Dim INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"

        'Test
        'Dim INI_FILENAME = "\\devserve-1\SCNYL_Connection\SCBLConnection.ini"
        'Dim INI_FILENAME = "D:\SCNYL_Connection\SCBLConnection.ini" 'path of config file

        'Dim INI_FILENAME = "\\devserve-1\SCNYL_Connection\Connection2.ini" 'develop
        'Dim INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection2.ini" 'production
        Dim INI_FILENAME = "D:\SCNYL_Connection\Connection2.ini" 'path of config file

        Dim USERNAME As String
        Dim SCHEMA As String

        Dim _accessConnectionConfig As New AccessConnectionConfig(INI_FILENAME)
        Dim InitVector As String
        Dim Keysize As Integer
        Dim PassPhrase As String
        'SYSNAME = pSystemName
        'SEQ = pSeqID
        Dim _secretKeyEnc As String
        Dim _encpwd As String
        Dim _authFlag As String
        Dim scn As System.Data.IDbConnection = Nothing

        ' �Դ��Ͱҹ���������͢����ʼ�ҹ
        Dim cn As System.Data.IDbConnection = Nothing
        Dim da As System.Data.IDbDataAdapter = Nothing
        Dim cm As System.Data.IDbCommand = Nothing
        Dim ds As New DataSet
        Dim dt As DataTable = Nothing
        Dim connString As String = ""
        Dim strBuilder As System.Text.StringBuilder

        Select Case pAccessLocationType
            Case EnumAccessLocationType.ALT_ORACLE
                connString = CreateConnString(EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, _accessConnectionConfig.Oracle_userName, _accessConnectionConfig.Oracle_password, pServiceName)
                scn = New System.Data.OracleClient.OracleConnection
                da = New System.Data.OracleClient.OracleDataAdapter
                cm = New System.Data.OracleClient.OracleCommand
            Case EnumAccessLocationType.ALT_SQLSERVER
                connString = CreateConnString(EnumConnectionType.SQLSERVER_PROVIDER, _accessConnectionConfig.Sqlserver_username, _accessConnectionConfig.Sqlserver_password, pServiceName)
                scn = New System.Data.SqlClient.SqlConnection
                da = New System.Data.SqlClient.SqlDataAdapter
                cm = New System.Data.SqlClient.SqlCommand
        End Select

        If scn Is Nothing Then
            Throw New Exception("Error occured in GetSystemConfig, can not found Location Type")
        End If

        scn.ConnectionString = connString
        scn.Open()
        ' ���Ң����� password
        strBuilder = New System.Text.StringBuilder
        strBuilder.Append(" Select * ")
        strBuilder.Append(" From T_SystemConnection a ")
        strBuilder.Append("     left join T_CONNECTIONKEY b on a.VER_KEY = b.VERSION_KEY")
        strBuilder.Append(" Where UPPER(SystemName) = UPPER('" & pSystemName & "') ")
        strBuilder.Append("     And LocationType = '" & pLocationType & "' ")
        strBuilder.Append("     And SeqID = '" & pSeqID & "' ")
        'strBuilder.Append(" And RecStatus = 'A' ")
        cm.CommandText = strBuilder.ToString

        cm.Connection = scn
        da.SelectCommand = cm
        da.Fill(ds)
        dt = ds.Tables(0)

        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            USERNAME = dt.Rows(0)("UserID").ToString
            SCHEMA = dt.Rows(0)("SC_Schema").ToString

            _secretKeyEnc = dt.Rows(0).Item(4).ToString 'item 4 is column name PASSWORD
            _encpwd = dt.Rows(0)("ENCPWD").ToString
            _authFlag = dt.Rows(0)("AUTH_FLAG").ToString
            InitVector = dt.Rows(0)("INITVECTOR").ToString
            Int32.TryParse(dt.Rows(0)("KEYSIZE").ToString, Keysize)
            PassPhrase = dt.Rows(0)("PASSPHRASE").ToString

            If _authFlag = "Y" Then 'If AUTH_FLAG = Y then continue return password
                If _encpwd = "Y" Then 'If field ENCPWD is "Y" then decryp password string, If not return field password
                    Using myRijndael As New RijndaelManaged()

                        myRijndael.GenerateKey()
                        myRijndael.GenerateIV()

                        Dim encrypted As Byte()
                        encrypted = ConvertBase64String(_secretKeyEnc, scn, pSystemName, SCHEMA, pSeqID, USERNAME)
                        If encrypted Is Nothing Then
                            If scn.State = ConnectionState.Open Then
                                scn.Close()
                            End If

                            Throw New Exception("Error occured in decrypt string(function Convert.FromBase64String). See detail log in T_SYSTEMCONNECTION_LOG ")
                        End If

                        Dim roundtrip As String = DecryptStringFromBytes(encrypted, InitVector, Keysize, PassPhrase)
                        GetAuthorize = roundtrip
                        'Display the original data and the decrypted data.
                        'Console.WriteLine("Original:   {0}", _passwordEnc)
                        'Console.WriteLine("Round Trip: {0}", roundtrip)
                    End Using
                Else
                    GetAuthorize = _secretKeyEnc
                End If
            Else
                GetAuthorize = "NOT AUTHORIZED"
            End If


        Else
            GetAuthorize = "RECORD NOT FOUND"
        End If

        Return GetAuthorize

    End Function
    Public Function OpenConnection(
      ByRef pYourConnectionName As System.Data.IDbConnection,
      ByVal pAccessLocationType As EnumAccessLocationType,
      ByVal pSystemName As String,
      ByVal pConnectionType As EnumConnectionType,
      ByVal pServiceName As String,
      Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE,
      Optional ByVal pSeqID As Integer = 1,
      Optional ByVal pServiceName2 As String = "") As Boolean
        ' ��ҹ initial file
        Dim _accessConnectionConfig As New AccessConnectionConfig(INI_FILENAME)
        InitVector = _accessConnectionConfig.InitVector
        Keysize = _accessConnectionConfig.Keysize
        PassPhrase = _accessConnectionConfig.PassPhrase
        SYSNAME = pSystemName
        SEQ = pSeqID

        Dim _systemConfig As SystemConfig
        Dim connString As String = ""
        Dim datasource As String = ""
        Dim cn As System.Data.IDbConnection = Nothing

        _systemConfig = GetSystemConfig(_accessConnectionConfig, pAccessLocationType, pSystemName, pServiceName, pLocationType, pSeqID)

        If _systemConfig Is Nothing Then
            OpenConnection = False
            Throw New Exception("Error occured in OpenConnection, can not get System Configuration data.")
        Else
            RUNAS_US = _systemConfig.UserID
            RUNAS_PW = _systemConfig.Password
            RUNAS_DOMAIN_SCHEMA = _systemConfig.Schema

        End If

        If pServiceName2.Trim = "" Then
            datasource = pServiceName
        Else
            datasource = pServiceName2
        End If

        ' �ó� Sybase ��� AS400
        ' �����������ͧ��� ServiceName ��� ServiceName2
        ' ����� Data source ������� column ���� SC_SCHEMA ���

        If RUNAS_DOMAIN_SCHEMA <> "SCNYL-DOMAIN" Then
            pYourConnectionName = OpenConn(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Initial_Catalog, _systemConfig.Schema, datasource)
            If scn.State = ConnectionState.Open Then
                scn.Close()
            End If

            If pYourConnectionName Is Nothing Then
                OpenConnection = False
                Throw New Exception("Error occured in OpenConnection, Open Connection error. See detail log in T_SYSTEMCONNECTION_LOG")
            End If
        End If

        'Select Case pConnectionType
        '    Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource)
        '        cn = New System.Data.OracleClient.OracleConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource)
        '        cn = New System.Data.OleDb.OleDbConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource, _systemConfig.Initial_Catalog)
        '        cn = New System.Data.OleDb.OleDbConnection
        '    Case EnumConnectionType.SQLSERVER_PROVIDER
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource, _systemConfig.Initial_Catalog)
        '        cn = New System.Data.SqlClient.SqlConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
        '        ' Data source �Ѻ catalog ������� ����������ǡѹ ��� SC_SCHEMA �¢�鹴��� ����ͧ���� | �� delimiter �� 192.168.18.4,5050|tmthasd1dev01
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Schema) ' _systemConfig.Schema.Split("|")(0).Trim, _systemConfig.Schema.Split("|")(1).Trim)
        '        cn = New System.Data.Odbc.OdbcConnection
        '    Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
        '        ' ** �ѧ����� test 5/6/2551
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Schema)
        '        cn = New System.Data.OleDb.OleDbConnection
        'End Select

        'If cn Is Nothing Then
        '    Throw New Exception("Error occured in OpenConnection, can not found Location Type")
        'End If

        'cn.ConnectionString = connString
        'cn.Open()

        'pYourConnectionName = cn

        OpenConnection = True

    End Function

    Public Function OpenConnectionExecBatch(
  ByRef pYourConnectionName As System.Data.IDbConnection,
  ByVal pAccessLocationType As EnumAccessLocationType,
  ByVal pSystemName As String,
  ByVal pConnectionType As EnumConnectionType,
  ByVal pServiceName As String,
  Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE,
  Optional ByVal pSeqID As Integer = 1,
  Optional ByVal pServiceName2 As String = "", Optional ByVal batScript As String = "",
  Optional ByVal batPath As String = "") As Boolean
        ' ��ҹ initial file
        Dim _accessConnectionConfig As New AccessConnectionConfig(INI_FILENAME)
        InitVector = _accessConnectionConfig.InitVector
        Keysize = _accessConnectionConfig.Keysize
        PassPhrase = _accessConnectionConfig.PassPhrase
        SYSNAME = pSystemName
        SEQ = pSeqID

        Dim _systemConfig As SystemConfig
        Dim connString As String = ""
        Dim datasource As String = ""
        Dim cn As System.Data.IDbConnection = Nothing

        _systemConfig = GetSystemConfig(_accessConnectionConfig, pAccessLocationType, pSystemName, pServiceName, pLocationType, pSeqID)

        If _systemConfig Is Nothing Then
            OpenConnectionExecBatch = False
            Throw New Exception("Error occured in OpenConnection, can not get System Configuration data.")
        Else
            RUNAS_US = _systemConfig.UserID
            RUNAS_PW = _systemConfig.Password
            RUNAS_DOMAIN_SCHEMA = pServiceName2 '_systemConfig.Schema
            If batScript <> "" Then
                Dim objWriter As New System.IO.StreamWriter(batPath, False)

                batScript = batScript.Replace("PUSER/PPASSWORD@PSCHEMA", Chr(34) & "PUSER/PPASSWORD@PSCHEMA" & Chr(34)) 'replace section with double quotes before execute batch
                batScript = batScript.Replace("PUSER", RUNAS_US)
                batScript = (batScript.Replace("PPASSWORD", RUNAS_PW)).Replace("%", "%%") 'replace % with %% before write to batch
                batScript = batScript.Replace("PSCHEMA", RUNAS_DOMAIN_SCHEMA)
                objWriter.Write(batScript)
                objWriter.Close()

                Dim execRes As String
                execRes = ExecuteBatchFile(batPath)
                If System.IO.File.Exists(batPath) = True Then

                    System.IO.File.Delete(batPath)
                End If
                ' Environment.Exit(execRes)

            End If
        End If

        If pServiceName2.Trim = "" Then
            datasource = pServiceName
        Else
            datasource = pServiceName2
        End If

        ' �ó� Sybase ��� AS400
        ' �����������ͧ��� ServiceName ��� ServiceName2
        ' ����� Data source ������� column ���� SC_SCHEMA ���

        If RUNAS_DOMAIN_SCHEMA <> "SCNYL-DOMAIN" Then
            pYourConnectionName = OpenConn(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Initial_Catalog, _systemConfig.Schema, datasource)
            If scn.State = ConnectionState.Open Then
                scn.Close()
            End If

            If pYourConnectionName Is Nothing Then
                OpenConnectionExecBatch = False
                Throw New Exception("Error occured in OpenConnection, Open Connection error. See detail log in T_SYSTEMCONNECTION_LOG")
            End If
        End If

        'Select Case pConnectionType
        '    Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource)
        '        cn = New System.Data.OracleClient.OracleConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource)
        '        cn = New System.Data.OleDb.OleDbConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource, _systemConfig.Initial_Catalog)
        '        cn = New System.Data.OleDb.OleDbConnection
        '    Case EnumConnectionType.SQLSERVER_PROVIDER
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, datasource, _systemConfig.Initial_Catalog)
        '        cn = New System.Data.SqlClient.SqlConnection
        '    Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
        '        ' Data source �Ѻ catalog ������� ����������ǡѹ ��� SC_SCHEMA �¢�鹴��� ����ͧ���� | �� delimiter �� 192.168.18.4,5050|tmthasd1dev01
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Schema) ' _systemConfig.Schema.Split("|")(0).Trim, _systemConfig.Schema.Split("|")(1).Trim)
        '        cn = New System.Data.Odbc.OdbcConnection
        '    Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
        '        ' ** �ѧ����� test 5/6/2551
        '        connString = CreateConnectionString(pConnectionType, _systemConfig.UserID, _systemConfig.Password, _systemConfig.Schema)
        '        cn = New System.Data.OleDb.OleDbConnection
        'End Select

        'If cn Is Nothing Then
        '    Throw New Exception("Error occured in OpenConnection, can not found Location Type")
        'End If

        'cn.ConnectionString = connString
        'cn.Open()

        'pYourConnectionName = cn

        OpenConnectionExecBatch = True

    End Function

    Private Function OpenConn(ByVal pConnectionType As EnumConnectionType, ByVal UserID As String, ByVal Password As String, ByVal Initial_Catalog As String, ByVal Schema As String, ByVal datasource As String) As System.Data.IDbConnection
        Dim cn As System.Data.IDbConnection = Nothing
        Dim connString As String = ""

        Try
            Select Case pConnectionType
                Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
                    connString = CreateConnectionString(pConnectionType, UserID, Password, datasource)
                    cn = New System.Data.OracleClient.OracleConnection
                Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
                    connString = CreateConnectionString(pConnectionType, UserID, Password, datasource)
                    cn = New System.Data.OleDb.OleDbConnection
                Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
                    connString = CreateConnectionString(pConnectionType, UserID, Password, datasource, Initial_Catalog)
                    cn = New System.Data.OleDb.OleDbConnection
                Case EnumConnectionType.SQLSERVER_PROVIDER
                    connString = CreateConnectionString(pConnectionType, UserID, Password, datasource, Initial_Catalog)
                    cn = New System.Data.SqlClient.SqlConnection
                Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
                    ' Data source �Ѻ catalog ������� ����������ǡѹ ��� SC_SCHEMA �¢�鹴��� ����ͧ���� | �� delimiter �� 192.168.18.4,5050|tmthasd1dev01
                    connString = CreateConnectionString(pConnectionType, UserID, Password, Schema) ' Schema.Split("|")(0).Trim, Schema.Split("|")(1).Trim)
                    cn = New System.Data.Odbc.OdbcConnection
                Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
                    ' ** �ѧ����� test 5/6/2551
                    connString = CreateConnectionString(pConnectionType, UserID, Password, Schema)
                    cn = New System.Data.OleDb.OleDbConnection
            End Select

            If cn Is Nothing Then
                Throw New Exception("Error occured in OpenConnection, can not found Location Type")
            End If

            cn.ConnectionString = connString
            cn.Open()
            OpenConn = cn
        Catch ex As Exception
            WriteLog2DB(scn, ex.Message)
        End Try
    End Function

    Private Function GetSystemConfig(
      ByVal pAccessConnectionConfig As AccessConnectionConfig,
      ByVal pAccessLocationType As EnumAccessLocationType,
      ByVal pSystemName As String,
      ByVal pServiceName As String,
      ByVal pLocationType As EnumLocationType,
      ByVal pSeqID As Integer) As SystemConfig

        ' �Դ��Ͱҹ���������͢͢���������ҧ ConnectionString ����

        Dim _systemConfig As SystemConfig = Nothing

        Dim cn As System.Data.IDbConnection = Nothing
        Dim da As System.Data.IDbDataAdapter = Nothing
        Dim cm As System.Data.IDbCommand = Nothing
        Dim ds As New DataSet
        Dim dt As DataTable = Nothing
        Dim connString As String = ""
        Dim _encpwd As String
        Dim strBuilder As System.Text.StringBuilder

        Dim InitVector As String
        Dim Keysize As Integer
        Dim PassPhrase As String

        Select Case pAccessLocationType
            Case EnumAccessLocationType.ALT_ORACLE
                connString = CreateConnectionString(EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, pAccessConnectionConfig.Oracle_userName, pAccessConnectionConfig.Oracle_password, pServiceName)
                scn = New System.Data.OracleClient.OracleConnection
                da = New System.Data.OracleClient.OracleDataAdapter
                cm = New System.Data.OracleClient.OracleCommand
            Case EnumAccessLocationType.ALT_SQLSERVER
                connString = CreateConnectionString(EnumConnectionType.SQLSERVER_PROVIDER, pAccessConnectionConfig.Sqlserver_username, pAccessConnectionConfig.Sqlserver_password, pServiceName)
                scn = New System.Data.SqlClient.SqlConnection
                da = New System.Data.SqlClient.SqlDataAdapter
                cm = New System.Data.SqlClient.SqlCommand
        End Select

        If scn Is Nothing Then
            Throw New Exception("Error occured in GetSystemConfig, can not found Location Type")
        End If

        scn.ConnectionString = connString
        scn.Open()
        ' ���Ң����� System configuration
        strBuilder = New System.Text.StringBuilder
        strBuilder.Append(" Select * ")
        strBuilder.Append(" From T_SystemConnection a ")
        strBuilder.Append("     left join T_CONNECTIONKEY b on a.VER_KEY = b.VERSION_KEY")
        strBuilder.Append(" Where UPPER(a.SystemName) = UPPER('" & pSystemName & "') ")
        strBuilder.Append(" And a.LocationType = '" & pLocationType & "' ")
        strBuilder.Append(" And a.SeqID = '" & pSeqID & "' ")
        strBuilder.Append(" And a.RecStatus = 'A' ")
        cm.CommandText = strBuilder.ToString

        cm.Connection = scn
        da.SelectCommand = cm
        da.Fill(ds)
        dt = ds.Tables(0)

        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            _systemConfig = New SystemConfig
            USERNAME = dt.Rows(0).Item(3).ToString 'UserID
            SCHEMA = dt.Rows(0).Item(5).ToString 'SC_Schema
            _encpwd = dt.Rows(0).Item(15).ToString 'ENCPWD

            InitVector = dt.Rows(0)("INITVECTOR").ToString
            Int32.TryParse(dt.Rows(0)("KEYSIZE").ToString, Keysize)
            PassPhrase = dt.Rows(0)("PASSPHRASE").ToString

            With _systemConfig
                .UserID = dt.Rows(0).Item(3).ToString 'UserID
                .Password = dt.Rows(0).Item(4).ToString 'Password
                .Schema = dt.Rows(0).Item(5).ToString 'SC_Schema
                .Initial_Catalog = dt.Rows(0).Item(14).ToString 'Initial_Catalog
            End With

            If _encpwd = "Y" Then
                Using myRijndael As New RijndaelManaged()

                    myRijndael.GenerateKey()
                    myRijndael.GenerateIV()

                    Dim encrypted As Byte()
                    encrypted = ConvertFromBase64String(_systemConfig.Password)
                    If encrypted Is Nothing Then
                        If scn.State = ConnectionState.Open Then
                            scn.Close()
                        End If

                        Throw New Exception("Error occured in decrypt string(function Convert.FromBase64String). See detail log in T_SYSTEMCONNECTION_LOG ")
                    End If

                    Dim roundtrip As String = DecryptStringFromBytes(encrypted, InitVector, Keysize, PassPhrase)
                    _systemConfig.Password = roundtrip
                    'Display the original data and the decrypted data.
                    'Console.WriteLine("Original:   {0}", _systemConfig.Password)
                    'Console.WriteLine("Round Trip: {0}", roundtrip)
                End Using
            End If

        Else
            _systemConfig = Nothing
        End If

        Return _systemConfig

    End Function
    Private Function ConvertFromBase64String(ByVal strInp As String) As Byte()
        Try
            ConvertFromBase64String = Convert.FromBase64String(strInp)
            Return ConvertFromBase64String
        Catch ex As Exception
            WriteLog2DB(scn, ex.Message)
            Return Nothing
        End Try
    End Function

    Private Shared Function ConvertBase64String(
            ByVal strInp As String,
            ByRef scn As IDbConnection,
            ByVal SYSNAME As String,
            ByVal SCHEMA As String,
            ByVal SEQ As Integer,
            ByVal USERNAME As String) As Byte()
        Try
            ConvertBase64String = Convert.FromBase64String(strInp)
            Return ConvertBase64String
        Catch ex As Exception
            WriteLog2DBStaticFunction(scn, ex.Message, SYSNAME, SCHEMA, SEQ, USERNAME)
            Return Nothing
        End Try
    End Function

    Public Shared Sub WriteLog(ByVal systemNme As String, ByVal seq As String, ByVal userNme As String, ByVal msg As String, ByVal LOG_FILE_PATH As String)
        Try
            Dim DateTimeVal As String
            DateTimeVal = System.DateTime.Now.ToString("dd/MM/yyyy:HH:mm:ss")

            Dim LOG_FILE_NAME As String = LOG_FILE_PATH & systemNme & ".log"

            Dim strmsg As String

            strmsg = DateTimeVal & "|SYSTEM:" & systemNme & "|" & seq & "|" & userNme & "|ERR_MSG:" & msg

            If (Not System.IO.Directory.Exists(LOG_FILE_PATH)) Then
                System.IO.Directory.CreateDirectory(LOG_FILE_PATH)
            End If

            If Not System.IO.File.Exists(LOG_FILE_NAME) Then
                System.IO.File.Create(LOG_FILE_NAME).Dispose()
            End If

            Dim objWriter As New System.IO.StreamWriter(LOG_FILE_NAME, True)

            objWriter.WriteLine(strmsg)
            objWriter.Close()

        Catch ex As Exception
            Throw New Exception("Error occured in WriteLogToDatabase")
        End Try
    End Sub
    Private Function CreateConnectionString(ByVal pConnectionType As EnumConnectionType,
        ByVal pUserName As String, ByVal pPassword As String, ByVal pDataSource As String, Optional ByVal pCatalog As String = "") As String

        Dim connString As String = ""

        ' ����� Oracle connection ����ͧ��˹� Catalog
        Select Case pConnectionType
            Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Data Source={2}", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
                connString = String.Format("Provider=MSDAORA.1;Password={0};User ID={1};Data Source={2};Persist Security Info=False", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
                connString = String.Format("Provider=SQLOLEDB.1;Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.SQLSERVER_PROVIDER
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
                'connString = String.Format("DRIVER=Sybase ASE ODBC Driver;password={0};uid={1};DB={2};NA={3};NLN=Winsock;charset=utf8", pPassword, pUserName, pCatalog, pDataSource)
                connString = String.Format("Driver=Adaptive Server Enterprise;app=myAppName;pwd={0};uid={1};db={2};port={3};server={4};charset=utf8", pPassword, pUserName, pDataSource.Split("|")(2), pDataSource.Split("|")(1), pDataSource.Split("|")(0))

            Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
                connString = String.Format("Provider=IBMDA400;Password={0};User ID={1};Data Source={2};Transport Product=Client Access;SSL=DEFAULT", pPassword, pUserName, pDataSource)
        End Select

        Return connString
    End Function

    'static function used in GetAuthorize
    Private Shared Function CreateConnString(ByVal pConnectionType As EnumConnectionType,
        ByVal pUserName As String, ByVal pPassword As String, ByVal pDataSource As String, Optional ByVal pCatalog As String = "") As String

        Dim connString As String = ""

        ' ����� Oracle connection ����ͧ��˹� Catalog
        Select Case pConnectionType
            Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Data Source={2}", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
                connString = String.Format("Provider=MSDAORA.1;Password={0};User ID={1};Data Source={2};Persist Security Info=False", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
                connString = String.Format("Provider=SQLOLEDB.1;Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.SQLSERVER_PROVIDER
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
                'connString = String.Format("DRIVER=Sybase ASE ODBC Driver;password={0};uid={1};DB={2};NA={3};NLN=Winsock;charset=utf8", pPassword, pUserName, pCatalog, pDataSource)
                connString = String.Format("Driver=Adaptive Server Enterprise;app=myAppName;pwd={0};uid={1};db={2};port={3};server={4};charset=utf8", pPassword, pUserName, pDataSource.Split("|")(2), pDataSource.Split("|")(1), pDataSource.Split("|")(0))

            Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
                connString = String.Format("Provider=IBMDA400;Password={0};User ID={1};Data Source={2};Transport Product=Client Access;SSL=DEFAULT", pPassword, pUserName, pDataSource)
        End Select

        Return connString
    End Function

    Public Sub WriteLog2DB(ByVal gConn As OracleClient.OracleConnection, ByVal logDetail As String)
        Try
            Thread.CurrentThread.CurrentUICulture = New Globalization.CultureInfo("th-TH")
            Dim dateVal As String = System.DateTime.Now.ToString("yyyyMMdd")
            Dim timeVal As String = System.DateTime.Now.ToString("HHmmss")




            Dim sqlval As String


            Dim da As OracleClient.OracleDataAdapter = Nothing
            Dim dt As DataTable = Nothing
            Dim ds As DataSet = Nothing

            Dim cmd As OracleClient.OracleCommand
            cmd = New OracleClient.OracleCommand("Select NVL(Max(Log_ID),0) + 1 as logID From SECURITY_CONN.t_systemconnection_log", gConn)
            da = New OracleClient.OracleDataAdapter
            dt = New DataTable
            da.SelectCommand = cmd
            da.Fill(dt)


            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    logID = dt.Rows(i)("logID").ToString()
                Next
            End If

            sqlval = "'" & Me.logID & "'"
            sqlval = sqlval & ",'" & dateVal & "'"
            sqlval = sqlval & ",'" & timeVal & "'"
            sqlval = sqlval & ",'" & Me.SYSNAME & "'"
            sqlval = sqlval & ",'" & Me.SCHEMA & "'"
            sqlval = sqlval & ",'" & Me.SEQ & "'"
            sqlval = sqlval & ",'" & Me.USERNAME & "'"
            sqlval = sqlval & ",'" & logDetail & "'"

            Dim strsql As String
            strsql = "INSERT INTO SECURITY_CONN.t_systemconnection_log(log_id, log_date, log_time, log_sysname,log_schema, log_seq, log_username, log_detail)" &
                     "VALUES(" & sqlval & ")"
            cmd = New OracleClient.OracleCommand(strsql)
            cmd.Connection = gConn
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try

    End Sub

    Private Shared Sub WriteLog2DBStaticFunction(
            ByVal gConn As OracleClient.OracleConnection,
            ByVal logDetail As String,
            ByVal SYSNAME As String,
            ByVal SCHEMA As String,
            ByVal SEQ As Integer,
            ByVal USERNAME As String)
        Try
            Thread.CurrentThread.CurrentUICulture = New Globalization.CultureInfo("th-TH")
            Dim dateVal As String = System.DateTime.Now.ToString("yyyyMMdd")
            Dim timeVal As String = System.DateTime.Now.ToString("HHmmss")




            Dim sqlval As String
            Dim logID As Integer


            Dim da As OracleClient.OracleDataAdapter = Nothing
            Dim dt As DataTable = Nothing
            Dim ds As DataSet = Nothing

            Dim cmd As OracleClient.OracleCommand
            cmd = New OracleClient.OracleCommand("Select NVL(Max(Log_ID),0) + 1 as logID From SECURITY_CONN.t_systemconnection_log", gConn)
            da = New OracleClient.OracleDataAdapter
            dt = New DataTable
            da.SelectCommand = cmd
            da.Fill(dt)


            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    logID = dt.Rows(i)("logID").ToString()
                Next
            End If

            sqlval = "'" & logID & "'"
            sqlval = sqlval & ",'" & dateVal & "'"
            sqlval = sqlval & ",'" & timeVal & "'"
            sqlval = sqlval & ",'" & SYSNAME & "'"
            sqlval = sqlval & ",'" & SCHEMA & "'"
            sqlval = sqlval & ",'" & SEQ & "'"
            sqlval = sqlval & ",'" & USERNAME & "'"
            sqlval = sqlval & ",'" & logDetail & "'"

            Dim strsql As String
            strsql = "INSERT INTO SECURITY_CONN.t_systemconnection_log(log_id, log_date, log_time, log_sysname,log_schema, log_seq, log_username, log_detail)" &
                     "VALUES(" & sqlval & ")"
            cmd = New OracleClient.OracleCommand(strsql)
            cmd.Connection = gConn
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try

    End Sub

    Public Function ConvertToSecureString(ByVal str As String) As Security.SecureString
        Dim password As New Security.SecureString
        For Each c As Char In str.ToCharArray
            password.AppendChar(c)
        Next
        Return password
    End Function
    Public Function MovFile(
     ByRef pYourConnectionName As System.Data.IDbConnection,
     ByVal pAccessLocationType As EnumAccessLocationType,
     ByVal pSystemName As String,
     ByVal pConnectionType As EnumConnectionType,
     ByVal pServiceName As String,
     ByVal pPathFrom As String, ByVal pPathTo As String,
     Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE,
     Optional ByVal pSeqID As Integer = 1,
     Optional ByVal pServiceName2 As String = "") As Boolean
        Try

            MovFile = OpenConnection(pYourConnectionName, pAccessLocationType,
                           pSystemName, pConnectionType,
                           pServiceName, pLocationType,
                           pSeqID, pServiceName2)

            Dim result As Integer
            If MovFile = True Then
                result = CopyFile(pPathFrom, pPathTo)
                If result = 0 Then
                    result = DeleteFile(pPathFrom)
                    If result = 0 Then
                        MovFile = True
                    Else
                        MovFile = False
                    End If
                Else
                    MovFile = False
                End If
            Else
                WriteLog2DB(scn, "Open Connection Fail")
                Exit Function
            End If

            If MovFile = False Then
                WriteLog2DB(scn, "Move File Failed, please check file")
            End If

            If scn.State = ConnectionState.Open Then
                scn.Close()
            End If

        Catch ex As Exception
            WriteLog2DB(scn, ex.Message)
            MovFile = False
        End Try

    End Function
    Private Function CopyFile(ByVal pPathFrom As String, ByVal pPathTo As String) As Integer
        Dim foo As New System.Diagnostics.Process
        'foo.StartInfo.WorkingDirectory = ""

        foo.StartInfo.RedirectStandardOutput = True
        foo.StartInfo.RedirectStandardInput = True
        foo.StartInfo.RedirectStandardError = True

        '--foo.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

        foo.StartInfo.FileName = "cmd.exe"
        'foo.StartInfo.Arguments = "/K copy " & pPathFrom & " " & pPathTo & " && del " & pPathFrom
        '--foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " && del " & Chr(34) & pPathFrom
        foo.StartInfo.UseShellExecute = False
        foo.StartInfo.CreateNoWindow = True

        foo.StartInfo.Domain = RUNAS_DOMAIN_SCHEMA

        foo.StartInfo.UserName = RUNAS_US
        foo.StartInfo.Password = ConvertToSecureString(RUNAS_PW)

        foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " & exit"

        foo.Start()
        foo.WaitForExit()
        CopyFile = foo.ExitCode
        foo.Dispose()
        foo.Close()

    End Function
    Private Function DeleteFile(ByVal pPathFrom As String) As Integer
        Dim foo As New System.Diagnostics.Process
        'foo.StartInfo.WorkingDirectory = ""

        foo.StartInfo.RedirectStandardOutput = True
        foo.StartInfo.RedirectStandardInput = True
        foo.StartInfo.RedirectStandardError = True

        '--foo.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

        foo.StartInfo.FileName = "cmd.exe"
        'foo.StartInfo.Arguments = "/K copy " & pPathFrom & " " & pPathTo & " && del " & pPathFrom
        '--foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " && del " & Chr(34) & pPathFrom
        foo.StartInfo.UseShellExecute = False
        foo.StartInfo.CreateNoWindow = True

        foo.StartInfo.Domain = RUNAS_DOMAIN_SCHEMA

        foo.StartInfo.UserName = RUNAS_US
        foo.StartInfo.Password = ConvertToSecureString(RUNAS_PW)

        foo.StartInfo.Arguments = " /K del " & Chr(34) & pPathFrom & Chr(34) & " & exit"

        foo.Start()
        foo.WaitForExit()
        DeleteFile = foo.ExitCode
        foo.Dispose()
        foo.Close()

    End Function
    Public Function RenameFile(
      ByRef pYourConnectionName As System.Data.IDbConnection,
      ByVal pAccessLocationType As EnumAccessLocationType,
      ByVal pSystemName As String,
      ByVal pConnectionType As EnumConnectionType,
      ByVal pServiceName As String,
      ByVal pPathFrom As String, ByVal pPathToNoPath As String,
      Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE,
      Optional ByVal pSeqID As Integer = 1,
      Optional ByVal pServiceName2 As String = "") As Boolean
        Try

            OpenConnection(pYourConnectionName, pAccessLocationType,
                           pSystemName, pConnectionType,
                           pServiceName, pLocationType,
                           pSeqID, pServiceName2)

            Dim foo As New System.Diagnostics.Process
            'foo.StartInfo.WorkingDirectory = ""

            foo.StartInfo.RedirectStandardOutput = True
            foo.StartInfo.RedirectStandardInput = True
            foo.StartInfo.RedirectStandardError = True

            '--foo.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

            foo.StartInfo.FileName = "cmd.exe"
            'foo.StartInfo.Arguments = "/K copy " & pPathFrom & " " & pPathTo & " && del " & pPathFrom
            '--foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " && del " & Chr(34) & pPathFrom
            foo.StartInfo.UseShellExecute = False
            foo.StartInfo.CreateNoWindow = True

            foo.StartInfo.Domain = RUNAS_DOMAIN_SCHEMA

            foo.StartInfo.UserName = RUNAS_US
            foo.StartInfo.Password = ConvertToSecureString(RUNAS_PW)

            foo.StartInfo.Arguments = " /K rename " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathToNoPath & Chr(34) & " & exit"

            Dim result As Integer
            foo.Start()
            foo.WaitForExit()
            result = foo.ExitCode
            foo.Dispose()
            foo.Close()

            If result = 0 Then
                RenameFile = True
            Else
                RenameFile = False
                WriteLog2DB(scn, "Rename File Failed, please check file")
            End If

            If scn.State = ConnectionState.Open Then
                scn.Close()
            End If

        Catch ex As Exception
            WriteLog2DB(scn, ex.Message)
            RenameFile = False
        End Try

    End Function
    Public Shared Function ExecuteBatchFile(ByVal batFileName As String) As String

        Dim objProcess As System.Diagnostics.Process
        Try
            objProcess = New System.Diagnostics.Process()
            objProcess.StartInfo.FileName = batFileName
            objProcess.StartInfo.WindowStyle = ProcessWindowStyle.Normal
            objProcess.StartInfo.UseShellExecute = False
            objProcess.StartInfo.RedirectStandardOutput = True
            objProcess.Start()
            Dim sOutput As String
            sOutput = objProcess.StandardOutput.ReadToEnd()
            'Wait until the process passes back an exit code 
            objProcess.WaitForExit()

            Dim ExitCode As String
            ExitCode = objProcess.ExitCode
            If ExitCode <> 0 Then
                Console.WriteLine(sOutput)
            End If

            objProcess.Close()
            Return ExitCode
        Catch ex As Exception
            Return ex.Message.ToString
        End Try
    End Function
    Private Class SystemConfig
        Private _userID As String
        Public Property UserID() As String
            Get
                Return _userID
            End Get
            Set(ByVal value As String)
                _userID = value
            End Set
        End Property

        Private _password As String
        Public Property Password() As String
            Get
                Return _password
            End Get
            Set(ByVal value As String)
                _password = value
            End Set
        End Property

        Private _schema As String
        Public Property Schema() As String
            Get
                Return _schema
            End Get
            Set(ByVal value As String)
                _schema = value
            End Set
        End Property

        Private _initial_catalog As String
        Public Property Initial_Catalog() As String
            Get
                Return _initial_catalog
            End Get
            Set(ByVal value As String)
                _initial_catalog = value
            End Set
        End Property


    End Class

    Private Class AccessConnectionConfig

        Private _oracle_userName As String
        Public Property Oracle_userName() As String
            Get
                Return _oracle_userName
            End Get
            Set(ByVal value As String)
                _oracle_userName = value
            End Set
        End Property

        Private _oracle_password As String
        Public Property Oracle_password() As String
            Get
                Return _oracle_password
            End Get
            Set(ByVal value As String)
                _oracle_password = value
            End Set
        End Property

        Private _sqlserver_userName As String
        Public Property Sqlserver_username() As String
            Get
                Return _sqlserver_userName
            End Get
            Set(ByVal value As String)
                _sqlserver_userName = value
            End Set
        End Property

        Private _sqlserver_password As String
        Public Property Sqlserver_password() As String
            Get
                Return _sqlserver_password
            End Get
            Set(ByVal value As String)
                _sqlserver_password = value
            End Set
        End Property

        Private _InitVector As String
        Public Property InitVector() As String
            Get
                Return _InitVector
            End Get
            Set(ByVal value As String)
                _InitVector = value
            End Set
        End Property

        Private _Keysize As Integer
        Public Property Keysize() As Integer
            Get
                Return _Keysize
            End Get
            Set(ByVal value As Integer)
                _Keysize = value
            End Set
        End Property

        Private _PassPhrase As String
        Public Property PassPhrase() As String
            Get
                Return _PassPhrase
            End Get
            Set(ByVal value As String)
                _PassPhrase = value
            End Set
        End Property

        Private _iniFile As String
        Public Property IniFile() As String
            Get
                Return _iniFile
            End Get
            Set(ByVal value As String)
                _iniFile = value
            End Set
        End Property

        Sub New(ByVal pIniFile As String)
            IniFile = pIniFile
            Me.DataBind()
        End Sub

        Public Function DataBind() As Boolean
            Me.ReadIni()
        End Function

        Private Function ReadIni() As Boolean
            Dim sr As System.IO.StreamReader
            Dim strLine As String
            Dim sectionName As String = ""

            'fix decrypt parameter
            InitVector = SCNYL_Connection.InitVector
            Keysize = SCNYL_Connection.Keysize
            PassPhrase = SCNYL_Connection.PassPhrase

            ' ��ҹ���Ẻ Stream
            sr = FileIO.FileSystem.OpenTextFileReader(IniFile, System.Text.Encoding.Default)

            ' ǹ�ٻ��Ǩ�ͺ������
            Do Until sr.EndOfStream
                strLine = sr.ReadLine()
                If InStr(strLine, "[") > 0 And InStr(strLine, "]") Then
                    sectionName = strLine.Replace("[", "").Replace("]", "")
                Else
                    If strLine.Trim <> "" Then
                        Dim strPosition As Integer
                        Dim strHead As String
                        Dim strSplit As String

                        strPosition = InStr(1, strLine, "=")
                        strHead = strLine.Substring(0, strPosition - 1)
                        strSplit = strLine.Substring(strPosition)

                        If strHead.Trim.ToUpper = "USERNAME" Then
                            Select Case sectionName.ToUpper
                                Case "ORACLE"
                                    Oracle_userName = strSplit
                                Case "SQLSERVER"
                                    Sqlserver_username = strSplit
                                Case Else
                                    Oracle_userName = ""
                                    Sqlserver_username = ""
                            End Select
                        ElseIf strHead.Trim.ToUpper = "PASSWORD" Then
                            Select Case sectionName.ToUpper
                                Case "ORACLE"
                                    ' Using myRijndael As New RijndaelManaged()
                                    'Dim A As String = strSplit

                                    Dim encrypted As Byte()
                                    encrypted = Convert.FromBase64String(strSplit)
                                    ' Encrypt the string to an array of bytes.
                                    Dim roundtrip As String = DecryptStringFromBytes(encrypted, InitVector, Keysize, PassPhrase)
                                    Oracle_password = roundtrip
                                    ' Oracle_password = mdEncrypt.Decrypt(strLine.Split("=")(1).Trim, "Maxky")

                                Case "SQLSERVER"
                                    'Sqlserver_password = mdEncrypt.Decrypt(strLine.Split("=")(1).Trim, "LekStudio")
                                    Dim encrypted As Byte()
                                    If Not IsNothing(strSplit) And strSplit.Trim <> "" Then
                                        encrypted = Convert.FromBase64String(strSplit)
                                        ' Encrypt the string to an array of bytes.

                                        Dim roundtrip As String = DecryptStringFromBytes(encrypted, InitVector, Keysize, PassPhrase)
                                        Sqlserver_password = roundtrip
                                    Else
                                        Sqlserver_password = ""
                                    End If
                                Case Else
                                    Oracle_password = ""
                                    Sqlserver_password = ""
                            End Select
                            'ElseIf strHead.Trim.ToUpper = "INITVECTOR" Then
                            '    InitVector = strSplit
                            'ElseIf strHead.Trim.ToUpper = "KEYSIZE" Then
                            '    Keysize = CInt(strSplit)
                            'ElseIf strHead.Trim.ToUpper = "PASSPHRASE" Then
                            '    PassPhrase = strSplit
                        End If
                    End If
                End If
            Loop
        End Function


    End Class

End Class
