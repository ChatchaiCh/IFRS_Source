﻿Imports UtilityClassLibrary
Imports System.Data.OleDb
Imports System.Text
Imports System.Net.Mail
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports System.IO
Imports System.Data.OracleClient
Imports System.Configuration
Imports SCNYL_Connection2005.SCNYL_Connection

Public Class ClsHashTotalErrorLOCancel
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private _cls_cn As System.Data.IDbConnection
    Dim clsGPS_PayoutGroupSetup As New ClsGPS_PayOutGroup_Setup
    Public str_Error_Message As String

    Public Function getFileName(ByVal oleConn As OleDbConnection, ByVal sysDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT M.PAYM_FILENAME_OUT_TOBANK as pays_file_name ")
        sb.Append("FROM GENERATEPAYMENT.PAYOUT_TOBANK_SUM_IL t ")
        sb.Append("INNER JOIN GENERATEPAYMENT.GPS_TL_EXPTOBNK_SETUP map ")
        sb.Append("ON t.pays_prod_code     = map.EXP_PRODUCT_CODE_IL ")
        sb.Append("INNER JOIN GENERATEPAYMENT.PAYOUT_TOBANK_MAP m ON PAYM_TRANS_DATE = PAYS_TRANS_DATE AND PAYM_FILENAME_OUT = PAYS_FILE_NAME ")
        sb.Append("WHERE t.pays_trans_date = '" & sysDate & "'  ")
        sb.Append("AND t.pays_file_type    = 'D' ")
        'sb.Append("AND map.EXP_PAYMTH      ='M' ")
        sb.Append("AND t.pays_rec_type     ='001' ")
        sb.Append("ORDER BY t.pays_file_name ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function getDataGenFile(ByVal oleConn As OleDbConnection, ByVal v_interface_file_name As String, ByVal v_trans_date As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append(" SELECT DATA_ROW ")
        sb.Append(" FROM GENERATEPAYMENT.IL_T_OUT_PAYMENT ")
        sb.Append(" WHERE INTERFACE_FILE_NAME = '" & v_interface_file_name & "' ")
        sb.Append(" AND TRANS_DATE            = '" & v_trans_date & "' ")
        sb.Append(" ORDER BY IDX  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function deleteDataGenFile(ByVal oleConn As OleDbConnection, ByVal v_interface_file_name As String, ByVal v_trans_date As String) As Integer
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim otran As OleDbTransaction
        otran = oleConn.BeginTransaction


        sb.Append(" DELETE ")
        sb.Append(" FROM GENERATEPAYMENT.IL_T_OUT_PAYMENT ")
        sb.Append(" WHERE INTERFACE_FILE_NAME = '" & v_interface_file_name & "' ")
        sb.Append(" AND TRANS_DATE            = '" & v_trans_date & "' ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, otran)

        If rec = -1 Then
            otran.Rollback()
            deleteDataGenFile = -1
        Else
            otran.Commit()
            deleteDataGenFile = 1
        End If

    End Function

    Public Function getEmail(ByVal oleConn As OleDbConnection, ByVal fc As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT t.email_address ")
        sb.Append("FROM GPS_EMAIL_SETUP t ")
        sb.Append("WHERE t.email_func = '" & fc & "' ") 'ERR_BY_HASH
        sb.Append("ORDER BY t.email_address ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function getil_sp_payout_tobank_filenm_rej(ByVal oleConn As OleDbConnection, ByVal p_busdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append(" SELECT PAYR_TRANS_DATE AS RUN_DATE , ")
        sb.Append("   PAYR_FILE_NAME_D     AS FILE_NAME ")
        sb.Append(" FROM GENERATEPAYMENT.PAYOUT_TOBANK_REL_IL ")
        sb.Append(" WHERE PAYR_TRANS_DATE = '" & p_busdate & "' ")
        sb.Append(" ORDER BY PAYR_FILE_NAME_D ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function getFileMoveIL(ByVal oleConn As OleDbConnection, ByVal sysDate As String, ByVal fileName As String) As String
        Dim sb As New StringBuilder
        Dim Ds As New DataSet
        Try
            sb.Append("SELECT t.payr_file_name_d ")
            sb.Append("FROM PAYOUT_TOBANK_REL_IL t ")
            sb.Append("WHERE t.payr_trans_date = '" & sysDate & "' ")
            sb.Append("and t.payr_file_name_d = '" & fileName & "' ")
            sb.Append("ORDER BY t.payr_file_name_d ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getFileMoveIL = Ds.Tables(0).Rows(0)("payr_file_name_d")

        Catch ex As Exception
            getFileMoveIL = ""
        End Try

    End Function

    Public Function getFileMoveLO(ByVal oleConn As OleDbConnection, ByVal sysDate As String, ByVal fileName As String) As String
        Dim sb As New StringBuilder
        Dim Ds As New DataSet
        Try
            sb.Append("SELECT t.rjil_file_name ")
            sb.Append("FROM PAYOUT_REJECT_LOG t ")
            sb.Append("WHERE t.rjil_rej_date  = '" & sysDate & "'  ")
            sb.Append("AND t.rjil_reject_type = 'LO_CANCEL_IL' ")
            sb.Append("AND t.rjil_file_name = '" & fileName & "' ")
            sb.Append("GROUP BY t.rjil_file_name ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getFileMoveLO = Ds.Tables(0).Rows(0)("rjil_file_name")

        Catch ex As Exception
            getFileMoveLO = ""
        End Try

    End Function

    Public Function getSysDate(ByVal oleConn As OleDbConnection) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" select TO_CHAR(SYSDATE,'YYYYMMDD') as systemdate from dual ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSysDate = Ds.Tables(0).Rows(0)("systemdate")
        Catch ex As Exception
            getSysDate = 0
        End Try
    End Function

    Public Function getSeqLogID(ByVal oleConn As OleDbConnection) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT SEQ_LOG.NEXTVAL FROM DUAL ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSeqLogID = Ds.Tables(0).Rows(0)("NEXTVAL")
        Catch ex As Exception
            getSeqLogID = 0
        End Try
    End Function

    Public Function getSeqLogFileID(ByVal oleConn As OleDbConnection) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT SEQ_LOG_FILE.NEXTVAL FROM DUAL")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSeqLogFileID = Ds.Tables(0).Rows(0)("NEXTVAL")
        Catch ex As Exception
            getSeqLogFileID = 0
        End Try
    End Function

    Public Function getSeqLogFileDetailID(ByVal oleConn As OleDbConnection) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT SEQ_LOG_FILE_DETAIL.NEXTVAL FROM DUAL ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSeqLogFileDetailID = Ds.Tables(0).Rows(0)("NEXTVAL")
        Catch ex As Exception
            getSeqLogFileDetailID = 0
        End Try
    End Function

    Public Function getSeqLogFileTransformID(ByVal oleConn As OleDbConnection) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT SEQ_LOG_TRANSFORM.NEXTVAL FROM DUAL ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getSeqLogFileTransformID = Ds.Tables(0).Rows(0)("NEXTVAL")
        Catch ex As Exception
            getSeqLogFileTransformID = 0
        End Try
    End Function

    Public Function getMailSmtp(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append(" SELECT t.string_value1 as path FROM il_t_po_config_parameter t where t.code ='MAIL' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getMailSmtp = Ds.Tables(0).Rows(0)("path")

        Catch ex As Exception
            getMailSmtp = ""
        End Try

    End Function

    Public Function getPathGenFile(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append(" SELECT t.string_value2 as path FROM il_t_po_config_parameter t where t.code ='INFP' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getPathGenFile = Ds.Tables(0).Rows(0)("path")

        Catch ex As Exception
            getPathGenFile = ""
        End Try

    End Function

    Public Function getPathLOReport(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append(" SELECT t.string_value4 as path FROM il_t_po_config_parameter t where t.code ='INFP' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getPathLOReport = Ds.Tables(0).Rows(0)("path")

        Catch ex As Exception
            getPathLOReport = ""
        End Try

    End Function

    Public Function getImportDate(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append(" SELECT t.string_value1 as path FROM il_t_po_config_parameter t where t.code ='ROUND' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getImportDate = Ds.Tables(0).Rows(0)("path")

        Catch ex As Exception
            getImportDate = ""
        End Try

    End Function

    Public Function getImportRound(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append(" SELECT t.string_value2 as path FROM il_t_po_config_parameter t where t.code ='ROUND' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getImportRound = Ds.Tables(0).Rows(0)("path")

        Catch ex As Exception
            getImportRound = ""
        End Try

    End Function

    Public Function getPayoutRejectLogIL(ByVal oleConn As OleDbConnection, ByVal sysDate As String, ByVal fileName As String, ByVal payNo As String) As DataTable

        Dim sb As New StringBuilder()

        sb.Append("SELECT t.payd_file_name AS payd_file_name_s, ")
        sb.Append("  t.payd_seqno, ")
        sb.Append("  t.payd_3_rec_bnkcde AS bnkcde, ")
        sb.Append("  rj.rejt_rej_group, ")
        sb.Append("  t.payd_trans_code, ")
        sb.Append("  t.payd_polno, ")
        sb.Append("  t.payd_user_id, ")
        sb.Append("  nme.payd_4_payee1_nmetha ")
        sb.Append("FROM (PAYOUT_TOBANK_DETAIL_IL t ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_REL_IL rel ")
        sb.Append("ON t.payd_file_name=rel.payr_file_name_s) ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_DETAIL_IL nme ")
        sb.Append("ON t.payd_trans_date =nme.payd_trans_date ")
        sb.Append("AND t.payd_file_name = nme.payd_file_name ")
        sb.Append("AND t.payd_seqno     = nme.payd_seqno ")
        sb.Append("AND nme.payd_rec_type  = '004' ")
        sb.Append("LEFT JOIN GPS_TL_EXPTOBNK_SETUP bnk ")
        sb.Append("ON t.payd_prod_code = bnk.exp_product_code_il ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER bnkcde ")
        sb.Append("ON t.payd_3_rec_bnkcde  = bnkcde.bkmst_bnkcode_no ")
        sb.Append("AND bnkcde.bkmst_status = 'ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_REJECT_TYPE rj ")
        sb.Append("ON rj.rejt_rej_type        ='HASH_ERR_IL' ")
        sb.Append("WHERE t.payd_trans_date    = '" & sysDate & "' ")
        sb.Append("AND t.payd_rec_type        = '003' ")
        sb.Append("AND rel.payr_file_name_d   ='" & fileName & "' ")
        sb.Append("AND trim(t.payd_3_cust_ref)= '" & payNo & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function getPayoutRejectLogLO(ByVal oleConn As OleDbConnection, ByVal sysDate As String, ByVal fileName As String, ByVal payNo As String) As DataTable

        Dim sb As New StringBuilder()

        sb.Append("SELECT t.payd_file_name AS payd_file_name_s, ")
        sb.Append("  t.payd_seqno, ")
        sb.Append("  tmp.rjil_file_name AS xls_file, ")
        sb.Append("  bnk.exp_paymth, ")
        sb.Append("  t.payd_3_rec_bnkcde AS bnkcde, ")
        sb.Append("  t.payd_3_c_acc_no, ")
        sb.Append("  t.payd_3_c_amt_num, ")
        sb.Append("  t.payd_2_value_date AS payment_date, ")
        sb.Append("  rj.rejt_rej_group, ")
        sb.Append("  t.payd_trans_code, ")
        sb.Append("  t.payd_polno, ")
        sb.Append("  t.payd_user_id, ")
        sb.Append("  nme.payd_4_payee1_nmetha ")
        sb.Append("FROM (((PAYOUT_TOBANK_DETAIL_IL t ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_REL_IL rel ")
        sb.Append("ON t.payd_file_name=rel.payr_file_name_s) ")
        sb.Append("INNER JOIN PAYOUT_TMP_REJECT tmp ")
        sb.Append("ON trim(t.payd_3_cust_ref)=trim(tmp.rjil_cust_ref)")
        ' ''--
        ''sb.Append("                 AND to_number(t.payd_3_c_amt)/1000 = to_number(tmp.rjil_amount)")
        ''sb.Append("                 AND ( t.payd_prod_code = case tmp.rjil_paymth when 'C' then 'MCP' when 'D' then 'DDP' when 'M' then 'DCP' else 'XXX' end ")
        ''sb.Append("                    OR t.payd_prod_code = case tmp.rjil_paymth when 'C' then 'MCP' when 'D' then 'DDP' when 'M' then 'MCL' else 'XXX' end ")
        ''sb.Append("                      )")
        ' ''--
        sb.Append(") ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_DETAIL_IL nme ")
        sb.Append("ON t.payd_trans_date =nme.payd_trans_date ")
        sb.Append("AND t.payd_file_name = nme.payd_file_name ")
        sb.Append("AND t.payd_seqno     = nme.payd_seqno ")
        sb.Append("AND nme.payd_rec_type  = '004') ")
        sb.Append("LEFT JOIN GPS_TL_EXPTOBNK_SETUP bnk ")
        sb.Append("ON t.payd_prod_code = bnk.exp_product_code_il ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER bnkcde ")
        sb.Append("ON t.payd_3_rec_bnkcde  = bnkcde.bkmst_bnkcode_no ")
        sb.Append("AND bnkcde.bkmst_status = 'ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_REJECT_TYPE rj ")
        sb.Append("ON rj.rejt_rej_type        ='LO_CANCEL_IL' ")
        sb.Append("WHERE t.payd_trans_date    = '" & sysDate & "' ")
        sb.Append("AND t.payd_rec_type        = '003' ")
        sb.Append("AND rel.payr_file_name_d   ='" & fileName & "' ")
        sb.Append("AND trim(tmp.rjil_cust_ref)= '" & payNo & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function checkRejectByDate(ByVal oleConn As OleDbConnection, ByVal sysdate As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            Dim rejLog As Integer

            sb.Append("SELECT COUNT(t.rjil_rej_date) AS COUNTR ")
            sb.Append("FROM PAYOUT_REJECT_LOG t ")
            sb.Append("WHERE t.rjil_rej_date = '" & sysdate & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            rejLog = Ds.Tables(0).Rows(0)("COUNTR")

            If rejLog > 0 Then
                checkRejectByDate = False
            Else
                checkRejectByDate = True
            End If

        Catch ex As Exception
            checkRejectByDate = False
        End Try

    End Function

    Public Function CheckDuplicatePayoutRejLog(ByVal oleConn As OleDbConnection) As DataTable

        Dim sb As New StringBuilder()

        sb.Append("SELECT t.rjil_cust_ref, t.rjil_file_name")
        sb.Append("FROM payout_reject_log l ")
        sb.Append("LEFT JOIN payout_tmp_reject t ")
        sb.Append("ON (t.rjil_cust_ref    = l.rjil_cust_ref ) ")
        sb.Append("WHERE t.rjil_cust_ref IS NOT NULL ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function CheckDuplicateGPSRejLog(ByVal oleConn As OleDbConnection) As DataTable

        Dim sb As New StringBuilder()

        sb.Append("SELECT t.rj_cust_ref, t.rj_file_name")
        sb.Append("FROM GPS_reject_log l ")
        sb.Append("LEFT JOIN GPS_tmp_reject t ")
        sb.Append("ON (t.rj_cust_ref    = l.rj_cust_ref ) ")
        sb.Append("WHERE t.rj_cust_ref IS NOT NULL ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    '--------------------------------------------'
    '-- CheckLOInvalidPaymentAndAmount ----------'
    '--------------------------------------------'
    '-- Return 0 - valid                       --'
    '--        1 - invalid payment number      --'
    '--        2 - invalid payment method      --'
    '--        3 - invalid payment amount      --'
    '--        4 - invalid 2 & 3               --'
    '--------------------------------------------'
    Public Function CheckLOInvalidPaymentAndAmount(ByVal oleConn As OleDbConnection, ByRef TransDate As String, ByRef PaymentNumber As String, ByRef PaymentMethod As String, ByRef PaymentAmount As Double) As Integer

        Dim sb As New StringBuilder()

        '--        sb.Append("SELECT ILD.CUSREF, ILD.PRDCDE, TRIM(TO_CHAR(ILD.PYTAMT, '99999999999999999990.999')) PYTAMT, PYT.EXP_PRODUCT_CODE, PYT.EXP_PAYMTH")
        sb.Append("SELECT ILD.CUSREF, ILD.PRDCDE, TO_NUMBER(ILD.PYTAMT, '99999999999999999999.999') PYTAMT, PYT.EXP_PRODUCT_CODE, PYT.EXP_PAYMTH")
        sb.Append("  FROM (SELECT PAYD_PROD_CODE AS PRDCDE, PAYD_3_C_AMT_NUM AS PYTAMT, PAYD_3_CUST_REF AS CUSREF")
        sb.Append("             , PAYD_FILE_NAME AS FILNME, PAYD_REC_TYPE AS RCDTYP, PAYD_SEQNO AS SEQNO")
        sb.Append("        FROM(PAYOUT_TOBANK_DETAIL_IL)")
        sb.Append("         WHERE PAYD_TRANS_DATE = '" & TransDate.Trim & "'")
        sb.Append("           AND PAYD_REC_TYPE = '003'")
        sb.Append("           AND TRIM(PAYD_3_CUST_REF) = '" & PaymentNumber.Trim & "'")
        sb.Append("           AND SUBSTR(PAYD_FILE_NAME,16,1) = '.'")
        sb.Append("         ORDER BY PAYD_TRANS_DATE, PAYD_FILE_NAME, PAYD_REC_TYPE, PAYD_SEQNO) ILD")
        sb.Append("       LEFT JOIN GPS_TL_EXPTOBNK_SETUP PYT")
        sb.Append("              ON ILD.PRDCDE = PYT.EXP_PRODUCT_CODE")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            If dt.Rows(0).Item("EXP_PAYMTH").ToString.Trim() <> PaymentMethod Then
                Return 2
                If dt.Rows(0).Item("PYTAMT") <> PaymentAmount Then
                    Return 4
                Else
                    Return 0
                End If
            Else
                If dt.Rows(0).Item("PYTAMT") <> PaymentAmount Then
                    Return 3
                Else
                    Return 0
                End If
            End If

        Else

            Return 1

        End If

    End Function

    '--------------------------------------------'
    '-- CheckLOInvalidPaymentAndAmount ----------'
    '--------------------------------------------'
    '-- Return 0 - valid                       --'
    '--        1 - invalid payment number      --'
    '--        2 - invalid payment method      --'
    '--        3 - invalid payment amount      --'
    '--        4 - invalid 2 & 3               --'
    '--------------------------------------------'
    Public Function CheckGPSInvalidPaymentAndAmount(ByVal oleConn As OleDbConnection, ByRef TransDate As String, ByRef PaymentNumber As String, ByRef PaymentMethod As String, ByRef PaymentAmount As Double) As Integer

        Dim sb As New StringBuilder()

        '--        sb.Append("SELECT ILD.CUSREF, ILD.PRDCDE, TRIM(TO_CHAR(ILD.PYTAMT, '99999999999999999990.999')) PYTAMT, PYT.EXP_PRODUCT_CODE, PYT.EXP_PAYMTH")
        sb.Append("SELECT T.GP_CUSTREFNO CUSTREF, ' ' PRDCDE, TO_NUMBER(T.GP_AMOUNT, '99999999999999999999.999') PYTAMT, ' ' EXP_PRODUCT_CODE, T.GP_PAYMTH EXP_PAYMTH")
        sb.Append("  FROM GPS_PAYMENT T")
        sb.Append(" WHERE T.GP_CONFIRMDATE = '" & TransDate.Trim & "'")
        sb.Append("   AND T.GP_CUSTREFNO = '" & PaymentNumber.Trim & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then

            If dt.Rows(0).Item("EXP_PAYMTH").ToString.Trim() <> PaymentMethod Then
                Return 2
                If dt.Rows(0).Item("PYTAMT") <> PaymentAmount Then
                    Return 4
                Else
                    Return 0
                End If
            Else
                If dt.Rows(0).Item("PYTAMT") <> PaymentAmount Then
                    Return 3
                Else
                    Return 0
                End If
            End If

        Else

            Return 1

        End If

    End Function

    Public Function generateDataForHashTotalIL(ByVal oleConn As OleDbConnection, ByVal sysDate As String, _
                                               ByVal fileName As String, ByVal accNo As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT payd_file_name, ")
        sb.Append("  ((t.payd_seqno)*2)+1 as payd_seqno, ")  'sb.Append("  t.payd_seqno, ")
        sb.Append("  bnk.exp_paymth, ")
        sb.Append("  t.payd_3_rec_bnkcde  AS bnkcde, ")
        sb.Append("  bnkcde.bkmst_bnkcode AS bnkcde_No, ")
        sb.Append("  t.payd_3_c_acc_no, ")
        sb.Append("  t.payd_3_c_amt_num, ")
        sb.Append("  t.payd_2_value_date AS payment_date, ")
        sb.Append("  rj.rejt_rej_type, ")
        sb.Append("  rj.rejt_remark, ")
        sb.Append("  trim(t.payd_3_cust_ref) as payd_3_cust_ref, ")
        sb.Append("  PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM PAYOUT_TOBANK_DETAIL_IL t ")
        sb.Append("LEFT JOIN GPS_TL_EXPTOBNK_SETUP bnk ")
        sb.Append("ON t.payd_prod_code = bnk.exp_product_code_il ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER bnkcde ")
        sb.Append("ON t.payd_3_rec_bnkcde  = bnkcde.bkmst_bnkcode_no ")
        sb.Append("AND bnkcde.bkmst_status = 'ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_REJECT_TYPE rj ")
        sb.Append("ON rj.rejt_rej_type         ='HASH_ERR_IL' ")
        sb.Append("LEFT JOIN PAYOUT_TOBANK_MAP m ")
        sb.Append("ON PAYM_TRANS_DATE = PAYD_TRANS_DATE AND PAYM_FILENAME_OUT = PAYD_FILE_NAME ")
        sb.Append("WHERE t.payd_trans_date     = '" & sysDate & "' ")
        sb.Append("AND REGEXP_LIKE(m.PAYM_FILENAME_OUT_TOBANK ,'" & fileName & "*')  ")
        sb.Append("AND t.payd_rec_type         = '003' ")
        sb.Append("AND trim(t.payd_3_cust_ref) in (" & accNo & ") ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function deleteFromPayoutTempReject(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("DELETE FROM PAYOUT_TMP_REJECT")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function deleteFromGPSTempReject(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("DELETE FROM GENERATEPAYMENT.GPS_TMP_REJECT")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function deletePayoutTempRejectByCustref(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, ByVal custref As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("DELETE FROM PAYOUT_TMP_REJECT WHERE rjil_cust_ref IN (" & custref & ")") ''000000001','000000002'
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function deleteGPSTempRejectByCustref(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, ByVal custref As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("DELETE FROM GPS_TMP_REJECT WHERE rj_cust_ref IN (" & custref & ")") ''000000001','000000002'
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function deletePayoutTempRejectByFileName(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, ByVal sFileName As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("DELETE FROM PAYOUT_TMP_REJECT WHERE rjil_file_name = '" & sFileName & "'") ''000000001','000000002'
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function deletePayoutRejectLogByDate(ByVal oleConn As OleDbConnection, ByVal sysdate As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim oleTran As OleDbTransaction
        oleTran = oleConn.BeginTransaction
        sb.Append("DELETE PAYOUT_REJECT_LOG t ")
        sb.Append("WHERE t.rjil_rej_date = '" & sysdate & "' ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            oleTran.Rollback()
            Return rec
        Else
            oleTran.Commit()
            Return 1
        End If
    End Function

    Public Function insertIntoPayoutTempReject(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, _
                                               ByVal rejDate As String, ByVal fileName As String, ByVal reason As String, _
                                               ByVal payMth As String, ByVal bnkCode As String, ByVal accNo As String, ByVal payNo As String, _
                                               ByVal amt As String, ByVal paidDateTXT As String, ByVal paidDate As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("INSERT ")
        sb.Append("INTO GENERATEPAYMENT.PAYOUT_TMP_REJECT ")
        sb.Append("  ( ")
        sb.Append("    RJIL_REJ_DATE, ")
        sb.Append("    RJIL_FILE_NAME, ")
        sb.Append("    RJIL_CUST_REF, ")
        sb.Append("    RJIL_PAYMTH, ")
        sb.Append("    RJIL_BNKCODE, ")
        sb.Append("    RJIL_BNKACC_NO, ")
        sb.Append("    RJIL_AMOUNT, ")
        sb.Append("    RJIL_PAIDDATE_TXT, ")
        sb.Append("    RJIL_PAIDDATE, ")
        sb.Append("    RJIL_REASON ")
        sb.Append("  ) ")
        sb.Append("  VALUES ")
        sb.Append("  ( ")
        sb.Append("    '" & rejDate & "', ")
        sb.Append("    '" & fileName & "', ")
        sb.Append("    '" & payNo & "', ")
        sb.Append("    '" & payMth & "', ")
        sb.Append("    '" & bnkCode & "', ")
        sb.Append("    '" & accNo & "', ")
        sb.Append("    '" & amt & "', ")
        sb.Append("    '" & paidDateTXT & "', ")
        sb.Append("    '" & paidDate & "', ")
        sb.Append("    '" & reason & "' ")
        sb.Append("  ) ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            If clsBusiness.gLastErrMessage.ToString.Substring(0, 9) = "ORA-12899" Then
                Return -12899
            Else
                Return rec
            End If
        Else
            Return 1
        End If
    End Function

    Public Function insertIntoGPSTempReject(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, _
                                               ByVal rejDate As String, ByVal fileName As String, ByVal reason As String, _
                                               ByVal payMth As String, ByVal bnkCode As String, ByVal accNo As String, ByVal payNo As String, _
                                               ByVal amt As String, ByVal paidDateTXT As String, ByVal paidDate As String, _
                                               ByVal CoreSystem As String, ByVal TransRef As String, ByVal PaymentSeq As Integer, _
                                               ByVal BillNo As String, ByVal PayeeName As String _
                                               )
        Dim sb As New StringBuilder
        Dim rec As Integer
        sb.Append("INSERT ")
        sb.Append("INTO GENERATEPAYMENT.GPS_TMP_REJECT ")
        sb.Append("  ( ")
        sb.Append("    RJ_REJ_DATE, ")
        sb.Append("    RJ_FILE_NAME, ")
        sb.Append("    RJ_CUST_REF, ")
        sb.Append("    RJ_PAYMTH, ")
        sb.Append("    RJ_BNKCODE, ")
        sb.Append("    RJ_BNKACC_NO, ")
        sb.Append("    RJ_AMOUNT, ")
        sb.Append("    RJ_PAIDDATE_TXT, ")
        sb.Append("    RJ_PAIDDATE, ")
        sb.Append("    RJ_REASON, ")
        sb.Append("    rj_core_system, ")
        sb.Append("    rj_transref, ")
        sb.Append("    rj_payment_seq, ")
        sb.Append("    rj_bill_no, ")
        sb.Append("    rj_payee_name ")
        sb.Append("  ) ")
        sb.Append("  VALUES ")
        sb.Append("  ( ")
        sb.Append("    '" & rejDate & "', ")
        sb.Append("    '" & fileName & "', ")
        sb.Append("    '" & payNo & "', ")
        sb.Append("    '" & payMth & "', ")
        sb.Append("    '" & bnkCode & "', ")
        sb.Append("    '" & accNo & "', ")
        sb.Append("    '" & amt & "', ")
        sb.Append("    '" & paidDateTXT & "', ")
        sb.Append("    '" & paidDate & "', ")
        sb.Append("    '" & reason & "', ")

        sb.Append("    '" & CoreSystem & "', ")
        sb.Append("    '" & TransRef & "', ")
        sb.Append("    " & PaymentSeq & ", ")
        sb.Append("    '" & BillNo & "', ")
        sb.Append("    '" & PayeeName & "' ")

        sb.Append("  ) ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            If clsBusiness.gLastErrMessage.ToString.Substring(0, 9) = "ORA-12899" Then
                Return -12899
            Else
                Return rec
            End If
        Else
            Return 1
        End If
    End Function

    Public Function insertIntoPayoutRejectLog(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, _
                                               ByVal RJIL_REJ_DATE As String, ByVal RJIL_CUST_REF As String, ByVal RJIL_SEQNO As String, _
                                               ByVal RJIL_FILE_NAME As String, ByVal RJIL_PAYMTH_FILE As String, ByVal RJIL_BNKCODE_FILE As String, _
                                               ByVal RJIL_BNKACC_NO_FILE As String, ByVal RJIL_AMOUNT_FILE As String, ByVal RJIL_PAIDDATE_FILE As String, _
                                               ByVal RJIL_REJECT_REASON As String, ByVal RJIL_FILE_NAME_S1_S As String, ByVal RJIL_FILE_NAME_S1_D As String, _
                                               ByVal RJIL_PAYMTH As String, ByVal RJIL_BNKCODE As String, ByVal RJIL_BNKACC_NO As String, _
                                               ByVal RJIL_AMOUNT As String, ByVal RJIL_PAIDDATE As String, ByVal RJIL_REJECT_TYPE As String, _
                                               ByVal RJIL_REJECT_FUNC As String, ByVal RJIL_TRANS_CODE As String, ByVal RJIL_POLNO As String, _
                                               ByVal RJIL_USER_ID As String, ByVal RJIL_PAYEE_NME As String, ByVal gUser As String)
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO PAYOUT_REJECT_LOG ")
        sb.Append("  ( ")
        sb.Append("    RJIL_REJ_DATE, ")
        sb.Append("    RJIL_CUST_REF, ")
        sb.Append("    RJIL_SEQNO, ")
        sb.Append("    RJIL_FILE_NAME, ")
        sb.Append("    RJIL_PAYMTH_FILE, ")
        sb.Append("    RJIL_BNKCODE_FILE, ")
        sb.Append("    RJIL_BNKACC_NO_FILE, ")
        sb.Append("    RJIL_AMOUNT_FILE, ")
        sb.Append("    RJIL_PAIDDATE_FILE, ")
        sb.Append("    RJIL_REJECT_REASON, ")
        sb.Append("    RJIL_FILE_NAME_S1_S, ")
        sb.Append("    RJIL_FILE_NAME_S1_D, ")
        sb.Append("    RJIL_PAYMTH, ")
        sb.Append("    RJIL_BNKCODE, ")
        sb.Append("    RJIL_BNKACC_NO, ")
        sb.Append("    RJIL_AMOUNT, ")
        sb.Append("    RJIL_PAIDDATE, ")
        sb.Append("    RJIL_REJECT_TYPE, ")
        sb.Append("    RJIL_REJECT_FUNC, ")
        sb.Append("    RJIL_TRANS_CODE, ")
        sb.Append("    RJIL_POLNO, ")
        sb.Append("    RJIL_USER_ID, ")
        sb.Append("    RJIL_PAYEE_NME, ")
        sb.Append("    CREATEDBY, ")
        sb.Append("    UPDATEDBY, ")
        sb.Append("    CREATEDDATE, ")
        sb.Append("    UPDATEDDATE ")
        sb.Append("  ) ")
        sb.Append("  VALUES ")
        sb.Append("  ( ")
        sb.Append("    '" & RJIL_REJ_DATE & "', ")
        sb.Append("    '" & RJIL_CUST_REF & "', ")
        sb.Append("    '" & RJIL_SEQNO & "', ")
        sb.Append("    '" & RJIL_FILE_NAME & "', ")
        sb.Append("    '" & RJIL_PAYMTH_FILE & "', ")
        sb.Append("    '" & RJIL_BNKCODE_FILE & "', ")
        sb.Append("    '" & RJIL_BNKACC_NO_FILE & "', ")
        sb.Append("    '" & RJIL_AMOUNT_FILE & "', ")
        sb.Append("    '" & RJIL_PAIDDATE_FILE & "', ")
        sb.Append("    '" & RJIL_REJECT_REASON & "', ")
        sb.Append("    '" & RJIL_FILE_NAME_S1_S & "', ")
        sb.Append("    '" & RJIL_FILE_NAME_S1_D & "', ")
        sb.Append("    '" & RJIL_PAYMTH & "', ")
        sb.Append("    '" & RJIL_BNKCODE & "', ")
        sb.Append("    '" & Trim(RJIL_BNKACC_NO) & "', ")
        sb.Append("    '" & RJIL_AMOUNT & "', ")
        sb.Append("    '" & RJIL_PAIDDATE & "', ")
        sb.Append("    '" & RJIL_REJECT_TYPE & "', ")
        sb.Append("    '" & RJIL_REJECT_FUNC & "', ")
        sb.Append("    '" & RJIL_TRANS_CODE & "', ")
        sb.Append("    '" & RJIL_POLNO & "', ")
        sb.Append("    '" & RJIL_USER_ID & "', ")
        sb.Append("    '" & RJIL_PAYEE_NME & "', ")
        sb.Append("    '" & gUser & "', ")
        sb.Append("    '" & gUser & "', ")
        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("  ) ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function insertIntoGPSRejectLog(ByVal oleConn As OleDbConnection, ByVal oleTran As OleDbTransaction, _
                                           ByVal RJIL_REJ_DATE As String, ByVal RJIL_CUST_REF As String, ByVal RJIL_SEQNO As String, _
                                           ByVal RJIL_FILE_NAME As String, ByVal RJIL_PAYMTH_FILE As String, ByVal RJIL_BNKCODE_FILE As String, _
                                           ByVal RJIL_BNKACC_NO_FILE As String, ByVal RJIL_AMOUNT_FILE As String, ByVal RJIL_PAIDDATE_FILE As String, _
                                           ByVal RJIL_REJECT_REASON As String, ByVal RJIL_FILE_NAME_S1_S As String, ByVal RJIL_FILE_NAME_S1_D As String, _
                                           ByVal RJIL_PAYMTH As String, ByVal RJIL_BNKCODE As String, ByVal RJIL_BNKACC_NO As String, _
                                           ByVal RJIL_AMOUNT As String, ByVal RJIL_PAIDDATE As String, ByVal RJIL_REJECT_TYPE As String, _
                                           ByVal RJIL_REJECT_FUNC As String, ByVal RJIL_TRANS_CODE As String, ByVal RJIL_POLNO As String, _
                                           ByVal RJIL_USER_ID As String, ByVal RJIL_PAYEE_NME As String, ByVal gUser As String)
        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_REJECT_LOG ")
        sb.Append("  ( ")
        sb.Append("    RJIL_REJ_DATE, ")
        sb.Append("    RJIL_CUST_REF, ")
        sb.Append("    RJIL_SEQNO, ")
        sb.Append("    RJIL_FILE_NAME, ")
        sb.Append("    RJIL_PAYMTH_FILE, ")
        sb.Append("    RJIL_BNKCODE_FILE, ")
        sb.Append("    RJIL_BNKACC_NO_FILE, ")
        sb.Append("    RJIL_AMOUNT_FILE, ")
        sb.Append("    RJIL_PAIDDATE_FILE, ")
        sb.Append("    RJIL_REJECT_REASON, ")
        sb.Append("    RJIL_FILE_NAME_S1_S, ")
        sb.Append("    RJIL_FILE_NAME_S1_D, ")
        sb.Append("    RJIL_PAYMTH, ")
        sb.Append("    RJIL_BNKCODE, ")
        sb.Append("    RJIL_BNKACC_NO, ")
        sb.Append("    RJIL_AMOUNT, ")
        sb.Append("    RJIL_PAIDDATE, ")
        sb.Append("    RJIL_REJECT_TYPE, ")
        sb.Append("    RJIL_REJECT_FUNC, ")
        sb.Append("    RJIL_TRANS_CODE, ")
        sb.Append("    RJIL_POLNO, ")
        sb.Append("    RJIL_USER_ID, ")
        sb.Append("    RJIL_PAYEE_NME, ")
        sb.Append("    CREATEDBY, ")
        sb.Append("    UPDATEDBY, ")
        sb.Append("    CREATEDDATE, ")
        sb.Append("    UPDATEDDATE ")
        sb.Append("  ) ")
        sb.Append("  VALUES ")
        sb.Append("  ( ")
        sb.Append("    '" & RJIL_REJ_DATE & "', ")
        sb.Append("    '" & RJIL_CUST_REF & "', ")
        sb.Append("    '" & RJIL_SEQNO & "', ")
        sb.Append("    '" & RJIL_FILE_NAME & "', ")
        sb.Append("    '" & RJIL_PAYMTH_FILE & "', ")
        sb.Append("    '" & RJIL_BNKCODE_FILE & "', ")
        sb.Append("    '" & RJIL_BNKACC_NO_FILE & "', ")
        sb.Append("    '" & RJIL_AMOUNT_FILE & "', ")
        sb.Append("    '" & RJIL_PAIDDATE_FILE & "', ")
        sb.Append("    '" & RJIL_REJECT_REASON & "', ")
        sb.Append("    '" & RJIL_FILE_NAME_S1_S & "', ")
        sb.Append("    '" & RJIL_FILE_NAME_S1_D & "', ")
        sb.Append("    '" & RJIL_PAYMTH & "', ")
        sb.Append("    '" & RJIL_BNKCODE & "', ")
        sb.Append("    '" & Trim(RJIL_BNKACC_NO) & "', ")
        sb.Append("    '" & RJIL_AMOUNT & "', ")
        sb.Append("    '" & RJIL_PAIDDATE & "', ")
        sb.Append("    '" & RJIL_REJECT_TYPE & "', ")
        sb.Append("    '" & RJIL_REJECT_FUNC & "', ")
        sb.Append("    '" & RJIL_TRANS_CODE & "', ")
        sb.Append("    '" & RJIL_POLNO & "', ")
        sb.Append("    '" & RJIL_USER_ID & "', ")
        sb.Append("    '" & RJIL_PAYEE_NME & "', ")
        sb.Append("    '" & gUser & "', ")
        sb.Append("    '" & gUser & "', ")
        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("    TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("  ) ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTran)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function


    Public Function generateDataForHashTotalLo(ByVal oleConn As OleDbConnection, ByVal sysDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT t.payd_file_name, ")
        sb.Append("  t.payd_seqno, ")
        sb.Append("  rj.rjil_cust_ref, ")
        sb.Append("  rj.rjil_paymth, ")
        sb.Append("  t.payd_3_rec_bnkcde  AS bnkcde, ")
        sb.Append("  bnkcde.bkmst_bnkcode AS bnkcde_No, ")
        sb.Append("  t.payd_3_c_acc_no, ")
        sb.Append("  t.payd_3_c_amt_num, ")
        sb.Append("  t.payd_2_value_date AS payment_date, ")
        sb.Append("  rj2.rejt_rej_type, ")
        sb.Append("  rj2.rejt_remark, ")
        sb.Append("  PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM ((PAYOUT_TMP_REJECT rj ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_DETAIL_IL t ")
        sb.Append("ON trim(rj.rjil_cust_ref) = trim(trim(t.payd_3_cust_ref)) ")
        ' ''--
        ''sb.Append("            AND to_number(rj.rjil_amount) = to_number(t.payd_3_c_amt)/1000")
        ''sb.Append("            AND ( t.payd_prod_code = case rj.rjil_paymth when 'C' then 'MCP' when 'D' then 'DDP' when 'M' then 'DCP' else 'XXX' end")
        ''sb.Append("               OR t.payd_prod_code = case rj.rjil_paymth when 'C' then 'MCP' when 'D' then 'DDP' when 'M' then 'MCL' else 'XXX' end")
        ''sb.Append("                 )")
        ' ''--
        sb.Append(" ) ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_REL_IL rel ON t.payd_file_name=rel.payr_file_name_d) ")
        sb.Append("LEFT JOIN GPS_TL_EXPTOBNK_SETUP bnk ")
        sb.Append("ON t.payd_prod_code = bnk.exp_product_code_il ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER bnkcde ")
        sb.Append("ON t.payd_3_rec_bnkcde  = bnkcde.bkmst_bnkcode_no ")
        sb.Append("AND bnkcde.bkmst_status = 'ACTIVE' ")
        sb.Append("LEFT JOIN GPS_TL_REJECT_TYPE rj2 ")
        sb.Append("ON rj2.rejt_rej_type    ='LO_CANCEL_IL' ")
        sb.Append("LEFT JOIN PAYOUT_TOBANK_MAP m ")
        sb.Append("ON PAYM_TRANS_DATE = PAYD_TRANS_DATE AND PAYM_FILENAME_OUT = PAYD_FILE_NAME ")
        sb.Append("WHERE t.payd_trans_date = '" & sysDate & "' ")
        sb.Append("AND t.payd_rec_type     = '003' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function generateDataForHashTotalGPS(ByVal oleConn As OleDbConnection, ByVal sysDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT t.gp_exptobank_filenme,")
        sb.Append("       t.gp_exptobank_seqno,")
        sb.Append("       rj.rj_cust_ref,")
        sb.Append("       rj.rj_paymth,")
        sb.Append("       t.gp_bnkcode AS bnkcde,")
        sb.Append("       t.gp_bnkcode_no as bnkcde_no,")
        sb.Append("       t.gp_payee_bnkaccno,")
        sb.Append("       t.gp_amount,")
        sb.Append("       t.gp_paiddate AS payment_date,")
        sb.Append("        rj2.rejt_rej_type,")
        sb.Append("        rj2.rejt_remark")

        sb.Append("  FROM (GPS_TMP_REJECT rj INNER JOIN GPS_PAYMENT t ON trim(rj.rj_cust_ref) = trim(trim(t.Gp_Custrefno))) ")
        sb.Append("  LEFT JOIN GPS_TL_BANKMASTER bnkcde")
        sb.Append("    ON t.gp_bnkcode_no = bnkcde.bkmst_bnkcode_no")
        sb.Append("   AND bnkcde.bkmst_status = 'ACTIVE'")
        sb.Append("  LEFT JOIN GPS_TL_REJECT_TYPE rj2")
        sb.Append("    ON rj2.rejt_rej_type = 'ACC_CANCEL'")
        sb.Append(" WHERE t.gp_confirmdate = '" & sysDate & "'")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function insertIntoILTLog(ByVal oleConn As OleDbConnection, ByVal businessDate As String, _
                                     ByVal errorMsg As String, ByVal startDate As String, ByVal status As String) As Integer
        Dim sb As New StringBuilder
        Dim otran As OleDbTransaction
        Dim logID, rec As Integer
        logID = getSeqLogID(oleConn)
        If logID <> -1 Then
            '--IC#9894-- otran = oleConn.BeginTransaction
            Try
                sb.Append("INSERT INTO IL_T_LOG(ID, BUSINESS_DATE, STATUS, ERROR_MSG, START_DATE)")
                sb.Append("VALUES(")
                sb.AppendFormat(" '{0}',", logID)
                sb.AppendFormat(" '{0}',", businessDate)
                sb.AppendFormat(" '{0}',", status)
                sb.AppendFormat(" '{0}',", errorMsg)
                sb.Append(" SYSDATE")
                sb.Append(")")
                rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
                If rec = -1 Then
                    insertIntoILTLog = -1
                    '--IC#9894-- otran.Rollback()
                Else
                    insertIntoILTLog = logID
                    '--IC#9894-- otran.Commit()
                End If
            Catch ex As Exception
                insertIntoILTLog = -1
                '--IC#9894-- otran.Rollback()
            End Try
        Else
            insertIntoILTLog = -1
        End If
    End Function

    Public Function insertIntoILTLogFile(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal interfaceName As String, _
                                     ByVal status As String, ByVal startDate As String, ByVal endDate As String) As Integer
        Dim sb As New StringBuilder
        Dim otran As OleDbTransaction
        Dim logFileId, rec As Integer
        logFileId = getSeqLogFileID(oleConn)
        If logFileId <> -1 Then
            '--IC#9894-- otran = oleConn.BeginTransaction
            Try
                sb.Append("INSERT INTO IL_T_LOG_FILE(ID, LOG_ID, INTERFACE_NAME, STATUS, START_DATE, END_DATE)")
                sb.Append("VALUES(")
                sb.AppendFormat(" '{0}',", logFileId)
                sb.AppendFormat(" '{0}',", logId)
                sb.AppendFormat(" '{0}',", interfaceName)
                sb.AppendFormat(" '{0}',", status)
                sb.Append(" SYSDATE,")
                sb.AppendFormat(" '{0}'", endDate)
                sb.Append(")")
                rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
                If rec <> -1 Then
                    insertIntoILTLogFile = logFileId
                    '--IC#9894-- otran.Commit()
                Else
                    insertIntoILTLogFile = -1
                    '--IC#9894-- otran.Rollback()
                End If
            Catch ex As Exception
                insertIntoILTLogFile = -1
                '--IC#9894-- otran.Rollback()
            End Try
        Else
            insertIntoILTLogFile = -1
        End If
    End Function

    Public Function insertIntoILTLogFileDetail(ByVal oleConn As OleDbConnection, ByVal logfileId As String, ByVal interfaceName As String, _
                                               ByVal fileName As String, ByVal description As String, _
                                               ByVal status As String, ByVal startDate As String, ByVal endDate As String) As Integer
        Dim sb As New StringBuilder
        Dim otran As OleDbTransaction
        Dim logFileDetailID, rec As Integer
        logFileDetailID = getSeqLogFileDetailID(oleConn)
        If logFileDetailID <> -1 Then
            '--IC#9894-- otran = oleConn.BeginTransaction
            Try
                sb.Append("INSERT INTO IL_T_LOG_FILE_DETAIL(ID, LOG_FILE_ID, INTERFACE_NAME, FILENAME, DESCRIPTION, STATUS, START_DATE, END_DATE)")
                sb.Append("VALUES(")
                sb.AppendFormat(" '{0}',", logFileDetailID)
                sb.AppendFormat(" '{0}',", logfileId)
                sb.AppendFormat(" '{0}',", interfaceName)
                sb.AppendFormat(" '{0}',", fileName)
                sb.AppendFormat(" '{0}',", description)
                sb.AppendFormat(" '{0}',", status)
                sb.Append(" SYSDATE,")
                sb.AppendFormat(" '{0}'", endDate)
                sb.Append(")")
                rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
                If rec <> -1 Then
                    insertIntoILTLogFileDetail = logFileDetailID
                    '--IC#9894-- otran.Commit()
                Else
                    insertIntoILTLogFileDetail = -1
                    '--IC#9894-- otran.Rollback()
                End If
            Catch ex As Exception
                insertIntoILTLogFileDetail = -1
                '--IC#9894-- otran.Rollback()
            End Try
        Else
            insertIntoILTLogFileDetail = -1
        End If
    End Function

    Public Function insertIntoILTLogTransForm(ByVal oleConn As OleDbConnection, ByVal logfileId As String, ByVal interfaceName As String, _
                                               ByVal fileName As String, ByVal description As String, _
                                               ByVal status As String, ByVal startDate As String, ByVal endDate As String) As Integer
        Dim sb As New StringBuilder
        Dim otran As OleDbTransaction
        Dim logTransFormID, rec As Integer
        logTransFormID = getSeqLogFileTransformID(oleConn)
        If logTransFormID <> -1 Then
            '--IC#9894-- otran = oleConn.BeginTransaction
            Try

                sb.Append("INSERT INTO IL_T_LOG_TRANSFORM(ID, LOG_FILE_ID, INTERFACE_NAME, STATUS, START_DATE, END_DATE)")
                sb.Append("VALUES(")
                sb.AppendFormat(" '{0}',", logTransFormID)
                sb.AppendFormat(" '{0}',", logfileId)
                sb.AppendFormat(" '{0}',", interfaceName)
                sb.AppendFormat(" '{0}',", status)
                sb.Append(" SYSDATE,")
                sb.AppendFormat(" '{0}'", endDate)
                sb.Append(")")
                rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
                If rec <> -1 Then
                    insertIntoILTLogTransForm = logTransFormID
                    '--IC#9894-- otran.Commit()
                Else
                    insertIntoILTLogTransForm = -1
                    '--IC#9894-- otran.Rollback()
                End If
            Catch ex As Exception
                insertIntoILTLogTransForm = -1
                '--IC#9894-- otran.Rollback()
            End Try
        Else
            insertIntoILTLogTransForm = -1
        End If
    End Function

    Public Function updateIntoILTLog(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal status As String) As Double
        Dim otran As OleDbTransaction
        '--IC#9894-- otran = oleConn.BeginTransaction
        Dim rec As Integer
        Try
            Dim sb As New StringBuilder
            sb.Append("UPDATE IL_T_LOG T SET T.STATUS = '" & status & "' ,T.END_DATE = SYSDATE ")
            sb.Append("WHERE T.ID ='" & logId & "' ")

            rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
            If rec = -1 Then
                '--IC#9894-- otran.Rollback()
                updateIntoILTLog = -1
            Else
                updateIntoILTLog = 1
                '--IC#9894-- otran.Commit()
            End If

        Catch ex As Exception
            '--IC#9894-- otran.Rollback()
            updateIntoILTLog = -1
        End Try
    End Function

    Public Function updateIntoILTLogFile(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal status As String) As Double

        Dim otran As OleDbTransaction
        '--IC#9894-- otran = oleConn.BeginTransaction
        Dim rec As Integer
        Try
            Dim sb As New StringBuilder
            sb.Append("UPDATE IL_T_LOG_FILE T SET T.STATUS = '" & status & "' ,T.END_DATE = SYSDATE ")
            sb.Append("WHERE T.ID ='" & logId & "' ")

            rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
            If rec = -1 Then
                '--IC#9894-- otran.Rollback()
                updateIntoILTLogFile = -1
            Else
                '--IC#9894-- otran.Commit()
                updateIntoILTLogFile = 1
            End If
        Catch ex As Exception
            '--IC#9894-- otran.Rollback()
            updateIntoILTLogFile = -1
        End Try
    End Function

    Public Function updateIntoILTLogFileDetail(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal status As String) As Double
        Dim otran As OleDbTransaction
        Dim rec As Integer
        '--IC#9894-- otran = oleConn.BeginTransaction
        Try
            Dim sb As New StringBuilder
            sb.Append("UPDATE IL_T_LOG_FILE_DETAIL T SET T.STATUS = '" & status & "' , T.END_DATE = SYSDATE ")
            sb.Append("WHERE T.ID ='" & logId & "' ")

            rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
            If rec = -1 Then
                '--IC#9894-- otran.Rollback()
                updateIntoILTLogFileDetail = -1
            Else
                '--IC#9894-- otran.Commit()
                updateIntoILTLogFileDetail = 1
            End If
        Catch ex As Exception
            '--IC#9894-- otran.Rollback()
            updateIntoILTLogFileDetail = -1
        End Try
    End Function

    Public Function updateIntoILTLogTransForm(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal status As String) As Double
        Dim otran As OleDbTransaction
        Dim rec As Integer
        '--IC#9894-- otran = oleConn.BeginTransaction
        Try
            Dim sb As New StringBuilder
            sb.Append("UPDATE IL_T_LOG_TRANSFORM T SET T.STATUS = '" & status & "' ,T.END_DATE = SYSDATE ")
            sb.Append("WHERE T.ID ='" & logId & "' ")

            rec = clsBusiness.ExecuteData(oleConn, sb.ToString) '--IC#9894-- , otran)
            If rec = -1 Then
                '--IC#9894-- otran.Rollback()
                updateIntoILTLogTransForm = -1
            Else
                '--IC#9894-- otran.Commit()
                updateIntoILTLogTransForm = 1
            End If
        Catch ex As Exception
            '--IC#9894-- otran.Rollback()
            updateIntoILTLogTransForm = -1
        End Try
    End Function

    Function CALL_il_sp_payout_tobank_rej(ByVal oleConn As OleDbConnection, ByVal logId As String, ByVal logTransFormId As String, ByVal pDate As String)

        Dim dbComm As OleDbCommand

        dbComm = oleConn.CreateCommand
        dbComm.Parameters.Add("p_log_id", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_log_id").Value = logId
        dbComm.Parameters.Add("p_log_transform_id", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_log_transform_id").Value = logTransFormId
        dbComm.Parameters.Add("p_interface_name", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_interface_name").Value = "Hash Total Error Reject"
        dbComm.Parameters.Add("p_regen_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_regen_date").Value = pDate
        dbComm.Parameters.Add("p_is_error", OleDbType.Numeric, 1).Direction = ParameterDirection.Output

        dbComm.CommandText = "il_sp_payout_tobank_rej"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()


        'If dbComm.Parameters("p_is_error").Value = 0 Then
        'str_Error_Message = dbComm.Parameters("p_is_error_message").Value

        Return dbComm.Parameters("p_is_error").Value
        'Else
        'Return 1
        'End If
    End Function

    Function CALL_il_sp_payout_tobank_genfilerej(ByVal oleConn As OleDbConnection, ByVal fileName As String, ByVal pDate As String)

        Dim dbComm As OleDbCommand

        dbComm = oleConn.CreateCommand
        dbComm.Parameters.Add("v_interface_file_name", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("v_interface_file_name").Value = fileName
        dbComm.Parameters.Add("v_trans_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("v_trans_date").Value = pDate
        dbComm.Parameters.Add("v_error", OleDbType.Numeric, 1).Direction = ParameterDirection.Output

        dbComm.CommandText = "il_sp_payout_tobank_genfilerej"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()


        If dbComm.Parameters("v_error").Value = 0 Then
            Return 1
        Else
            Return -1
        End If
    End Function

    Function CALL_il_sp_payout_tobank_upd_prnflg(ByVal oleConn As OleDbConnection, ByVal pDate As String)
        Try
            Dim dbComm As OleDbCommand

            dbComm = oleConn.CreateCommand
            dbComm.Parameters.Add("v_trans_date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
            dbComm.Parameters("v_trans_date").Value = pDate

            dbComm.CommandText = "il_sp_payout_tobank_upd_prnflg"
            dbComm.CommandType = CommandType.StoredProcedure
            dbComm.ExecuteNonQuery()

            CALL_il_sp_payout_tobank_upd_prnflg = 1
        Catch ex As Exception
            CALL_il_sp_payout_tobank_upd_prnflg = -1
        End Try

    End Function

    Public Function RenameFile_RejectByFile(ByVal sFileNameFullPath As String)

        Dim sNewFile As String

        sNewFile = Path.GetFileNameWithoutExtension(sFileNameFullPath) & "_FORMAT_ERROR" & Path.GetExtension(sFileNameFullPath)

        Try

            My.Computer.FileSystem.RenameFile(sFileNameFullPath, sNewFile)
            Return sNewFile

        Catch ex As Exception

            Return "-1"

        End Try

    End Function

    Public Function RenameFileFormatError(ByVal oleConn As OleDbConnection, ByVal fileName As String, ByVal fpath As String, ByVal fileType As String) As Boolean
        'Create File
        'Source Path 

        'Config Name
        Dim out As String = "_FORMAT_ERROR"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = fileType
        'Name .End
        Dim fileRename, fileFrom, fileEnd As New StringBuilder

        Dim clsMNG_FILE As New clsManageFile
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""
        Try

            fileRename.Append(Path.GetFileNameWithoutExtension(fileName))
            fileRename.Append(out)
            '--fileRename.Append(curDate)
            fileRename.Append(".")
            fileRename.Append(endFile)

            'Name .End
            '--fileFrom.Append(fpath)
            fileFrom.Append(fileName)
            '--fileFrom.Append(fileType)

            '--x--My.Computer.FileSystem.RenameFile(fileFrom.ToString, fileRename.ToString)

            clsMNG_FILE.RenameFile(_cls_cn, SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE, _
             system_code, _
             SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, _
             server_1, _
             fileFrom.ToString, fileRename.ToString, _
             SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE, _
             1, _
             server_2)


            fileEnd.Append(fpath)
            fileEnd.Append("\")
            fileEnd.Append(fileRename.ToString)

            Dim fullPathEnd As String = fileEnd.ToString
            Return True
        Catch ex As Exception

            Return False
        End Try
    End Function

    Public Function pathFrom(ByVal oleConn As OleDbConnection, ByVal fileName As String, ByVal fpath As String, ByVal fileType As String)
        'Create File
        'Source Path 

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = fileType
        'Name .End
        Dim fileRename, fileFrom, fileEnd As New StringBuilder

        Dim clsMNG_FILE As New clsManageFile
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        fileRename.Append(fileName)
        fileRename.Append(out)
        fileRename.Append(curDate)
        fileRename.Append(endFile)

        'Name .End
        fileFrom.Append(fpath)
        fileFrom.Append(fileName)
        fileFrom.Append(fileType)

        '--x--My.Computer.FileSystem.RenameFile(fileFrom.ToString, fileRename.ToString)

        clsMNG_FILE.RenameFile(_cls_cn, SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE, _
         system_code, _
         SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, _
         server_1, _
         fileFrom.ToString, fileRename.ToString, _
         SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE, _
         1, _
         server_2)


        fileEnd.Append(fpath)
        fileEnd.Append(fileRename.ToString)

        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    Public Function pathTo(ByVal oleConn As OleDbConnection, ByVal fileName As String, ByVal fpath As String, ByVal fileType As String)
        'Destination Path 
        'filePathBK = 

        'Config Name
        Dim out As String = "_Cancel"
        Dim curDate As String = Date.Now.ToString("yyyyMMdd")
        Dim endFile As String = fileType

        'Name .End
        Dim fileEnd As New StringBuilder
        fileEnd.Append(fpath)
        fileEnd.Append(fileName)
        fileEnd.Append(out)
        fileEnd.Append(curDate)
        fileEnd.Append(endFile)
        Dim fullPathEnd As String = fileEnd.ToString

        Return fullPathEnd
    End Function

    Public Function genReportErrorbyHashTotalGPS(ByVal oleConn As OleDbConnection, ByVal businessdate As String, ByVal path As String, ByVal sReportPath As String, ByVal gUserFullName As String) As String

        Dim sysdate As String = Now.ToString("yyyyMMdd")
        Dim systemdate As String = businessdate.Substring(6, 2) & "/" & businessdate.Substring(4, 2) & "/" & businessdate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()

        Try

            dt = getDataForHashTotalErrorGPSReport(oleConn, businessdate)
            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Dim clsExportPDF As New clsCrystalToPDFConverter
                '--clsExportPDF.SetCrystalReportFilePath("D:\Working\SR\ITSR-25591207-0003 แก้ไข Report Manager ให้ต่อกับ New SQL Server\30 Coding & Unit test\144\Report Manager version v 2.1.7\RPTXL_GenLedRec.rpt")
                '--clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByHashGPS.rpt")
                clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptCancelPayment.rpt")
                clsExportPDF.SetPdfDestinationFilePath("D:\" & "RptCancelPayment_GPS_" & businessdate & ".pdf")
                Dim lstname As New ArrayList
                Dim lstvalue As New ArrayList

                lstname.Add("pTransdate")
                lstname.Add("pUser")
                lstvalue.Add(systemdate)
                lstvalue.Add(gUserFullName)

                clsExportPDF.ExportReport(dt, lstname, lstvalue)

                '-- move file to server
                Dim strSourceFileName As String = "D:\" & "RptCancelPayment_GPS_" & businessdate & ".pdf"
                Dim strDestinationFileName As String = path & "RptCancelPayment_GPS_" & businessdate & ".pdf"
                clsUtility.BackupFile(strSourceFileName, strDestinationFileName)
                '-- end move file to server


                Return path & "RptCancelPayment_GPS_" & businessdate & ".pdf"
            Else
                Return "Data not found!"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return ""
        End Try

    End Function

    Public Sub genReportErrorbyHashTotalLO(ByVal oleConn As OleDbConnection, ByVal businessdate As String, ByVal path As String, ByVal sReportPath As String, ByVal gUserFullName As String)

        Dim sysdate As String = Now.ToString("yyyyMMdd_HHmm")
        Dim systemdate As String = businessdate.Substring(6, 2) & "/" & businessdate.Substring(4, 2) & "/" & businessdate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()
        dt = getDataForHashTotalErrorReport(oleConn, businessdate)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim clsExportPDF As New clsCrystalToPDFConverter
            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByHashLO.rpt")
            clsExportPDF.SetPdfDestinationFilePath(path & "RptCancelPayment_IL_" & sysdate & ".pdf")
            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")
            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)
        End If

    End Sub

    Public Sub genReportErrorbyHashTotalLO_Reprint(ByVal oleConn As OleDbConnection, ByVal businessdate As String, ByVal path As String, ByVal sReportPath As String, ByVal gUserFullName As String, sBatchNo As String)

        Dim sysdate As String = Now.ToString("yyyyMMdd_HHmm")
        Dim Bus_date_time As String = businessdate + Now.ToString("_200") + sBatchNo
        Dim systemdate As String = businessdate.Substring(6, 2) & "/" & businessdate.Substring(4, 2) & "/" & businessdate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()
        dt = getDataForHashTotalErrorReport_Reprint(oleConn, businessdate, sBatchNo)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim clsExportPDF As New clsCrystalToPDFConverter
            clsExportPDF.SetCrystalReportFilePath(sReportPath & "RptErrorByHashLO.rpt")
            clsExportPDF.SetPdfDestinationFilePath(path & "RptCancelPayment_IL_" & Bus_date_time & ".pdf")
            Dim lstname As New ArrayList
            Dim lstvalue As New ArrayList

            lstname.Add("pTransdate")
            lstname.Add("pUser")
            lstvalue.Add(systemdate)
            lstvalue.Add(gUserFullName)

            clsExportPDF.ExportReport(dt, lstname, lstvalue)
        End If

    End Sub

    Public Sub genReportSUM(ByVal oleConn As OleDbConnection, ByVal businessdate As String, ByVal path As String, ByVal sReportPath As String, ByVal reprint As Boolean)

        Dim sysdate As String = Now.ToString("yyyyMMdd_HHmm")
        Dim systemdate As String = businessdate.Substring(6, 2) & "/" & businessdate.Substring(4, 2) & "/" & businessdate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()

        dt = getDataForSUMReport(oleConn, businessdate, reprint)
        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Dim clsExportPDF As New clsCrystalToPDFConverter
        clsExportPDF.SetCrystalReportFilePath(sReportPath & "report_sum.rpt")
        clsExportPDF.SetPdfDestinationFilePath(path & "Report_PaymentOutToBank_SUMIL" & sysdate & "(Re).pdf")

        clsExportPDF.ExportReport(dt)
        'End If

    End Sub

    Public Sub genReportMNG(ByVal oleConn As OleDbConnection, ByVal businessdate As String, ByVal path As String, ByVal sReportPath As String, ByVal reprint As Boolean, ByVal dtPayoutGroupSetup As DataTable)

        Dim sysdate As String = Now.ToString("yyyyMMdd_HHmm")
        Dim systemdate As String = businessdate.Substring(6, 2) & "/" & businessdate.Substring(4, 2) & "/" & businessdate.Substring(0, 4) 'Now.ToString("dd/MM/yyyy")

        Dim dt As DataTable = New DataTable()
        dt = getDataForMNGReport(oleConn, businessdate, reprint, dtPayoutGroupSetup)
        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Dim clsExportPDF As New clsCrystalToPDFConverter
        clsExportPDF.SetCrystalReportFilePath(sReportPath & "report_mng.rpt")
        clsExportPDF.SetPdfDestinationFilePath(path & "Report_PaymentOutToBank_MNGIL" & sysdate & "(Re).pdf")

        clsExportPDF.ExportReport(dt)
        'End If

    End Sub

    Function SendEmail(ByVal FromAddress As String, _
                         ByVal ToAddress As String, _
                         ByVal Subject As String, _
                         ByVal Body As String, _
                         ByVal UserName As String, _
                         ByVal Password As String, _
                         ByVal Server As String, _
                         Optional ByVal Port As Integer = 25, _
                         Optional ByVal AttachmentsFile As List(Of String) = Nothing) As String
        Dim smptMail As New ClsEmailUtil()
        Try

            With smptMail
                .Mailserver = Server
                .smtpPort = CInt(Port)
                '.Mailserver = "MAILSMTP.SCNYL.LOCAL"
                '.smtpPort = 25

                .Sender = FromAddress
                .RECIPIENT = ToAddress '** importance
                .CC = "" ' optional
                .Subject = Subject

                .TextBody = Body
                .Attachment = ""
                If .sendMail() = True Then
                    SendEmail = "Success"
                Else
                    SendEmail = "Error"
                End If

            End With
        Catch error_t As Exception
            MsgBox("Send Email Fail.")
            SendEmail = error_t.ToString
        End Try

    End Function

    Public Function getDataForHashTotalErrorReport(ByVal oleConn As OleDbConnection, ByVal regendate As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT rejtype.REJT_REJ_MASSAGE AS rjil_reject_type, ")
        sb.Append("  t.rjil_paiddate, ")
        sb.Append("  paymth.exp_paymnt_name, ")
        sb.Append("  t.rjil_trans_code, ")
        sb.Append("  tcde.tltrans_name       AS trans_desc, ")
        sb.Append("  tcde.tltrans_department AS dept, ")
        sb.Append("  t.rjil_polno, ")
        sb.Append("  bnk.bkmst_bnkcode, ")
        sb.Append("  t.rjil_cust_ref, ")
        sb.Append("  t.rjil_bnkacc_no, ")
        sb.Append("  t.rjil_payee_nme, ")
        sb.Append("  PAYRJ_3_C_AMT_NUM AS rjil_amount, ")
        sb.Append("  t.rjil_reject_reason, ")
        sb.Append("  t.rjil_user_id, ")
        sb.Append("  t.rjil_file_name_s1_d, ")
        sb.Append("  payrd_round ")
        sb.Append("FROM (PAYOUT_REJECT_LOG t ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_DETAIL_IL_REJ t_rej ")
        sb.Append("ON t_rej.PAYRJ_TRANS_DATE = t.rjil_rej_date ")
        sb.Append("AND t_rej.PAYRJ_FILE_NAME = t.rjil_file_name_s1_s ")
        sb.Append("AND t_rej.PAYRJ_SEQNO     = t.rjil_seqno ")
        sb.Append("AND t_rej.PAYRJ_REC_TYPE  = '003' ")
        sb.Append("INNER JOIN GPS_TL_EXPTOBNK_SETUP paymth ")
        sb.Append("ON t.rjil_paymth          = paymth.exp_paymth ")
        sb.Append("AND t_rej.payrj_prod_code = exp_product_code) ")
        sb.Append("LEFT JOIN PAYOUT_TL_TRANSCODE_IL tcde ")
        sb.Append("ON trim(t.rjil_trans_code) = trim(tcde.tltrans_code) ")
        sb.Append("LEFT JOIN GPS_TL_BANKMASTER bnk ")
        sb.Append("ON trim(t.rjil_bnkcode)=bnk.bkmst_bnkcode_no ")
        sb.Append("LEFT JOIN gps_tl_reject_type rejtype ")
        sb.Append("ON t.rjil_reject_type = rejtype.REJT_REJ_TYPE ")
        sb.Append("LEFT JOIN PAYOUT_ROUND ")
        sb.Append("ON RJIL_FILE_NAME_S1_S = PAYRD_FILENAME_S ")
        sb.Append("WHERE t.rjil_rej_date  ='" & regendate & "' ")
        sb.Append("AND PAYRD_ROUND = (SELECT TO_NUMBER(STRING_VALUE2) FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND') ")
        sb.Append("ORDER BY t.rjil_reject_type, ")
        sb.Append("  tcde.tltrans_department, ")
        sb.Append("  t.rjil_paymth, ")
        sb.Append("  t.rjil_cust_ref  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        'Return Nothing
        'End If

    End Function

    Public Function getDataForHashTotalErrorReport_Reprint(ByVal oleConn As OleDbConnection, ByVal regendate As String, sBatchNo As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT rejtype.REJT_REJ_MASSAGE AS rjil_reject_type, ")
        sb.Append("  t.rjil_paiddate, ")
        sb.Append("  paymth.exp_paymnt_name, ")
        sb.Append("  t.rjil_trans_code, ")
        sb.Append("  tcde.tltrans_name       AS trans_desc, ")
        sb.Append("  tcde.tltrans_department AS dept, ")
        sb.Append("  t.rjil_polno, ")
        sb.Append("  bnk.bkmst_bnkcode, ")
        sb.Append("  t.rjil_cust_ref, ")
        sb.Append("  t.rjil_bnkacc_no, ")
        sb.Append("  t.rjil_payee_nme, ")
        sb.Append("  PAYRJ_3_C_AMT_NUM AS rjil_amount, ")
        sb.Append("  t.rjil_reject_reason, ")
        sb.Append("  t.rjil_user_id, ")
        sb.Append("  t.rjil_file_name_s1_d, ")
        sb.Append("  payrd_round ")
        sb.Append(" FROM (PAYOUT_REJECT_LOG t ")
        sb.Append(" INNER JOIN PAYOUT_TOBANK_DETAIL_IL_REJ t_rej ")
        sb.Append(" ON t_rej.PAYRJ_TRANS_DATE = t.rjil_rej_date ")
        sb.Append(" AND t_rej.PAYRJ_FILE_NAME = t.rjil_file_name_s1_s ")
        sb.Append(" AND t_rej.PAYRJ_SEQNO     = t.rjil_seqno ")
        sb.Append(" AND t_rej.PAYRJ_REC_TYPE  = '003' ")
        sb.Append(" INNER JOIN GPS_TL_EXPTOBNK_SETUP paymth ")
        sb.Append(" ON t.rjil_paymth          = paymth.exp_paymth ")
        sb.Append(" AND t_rej.payrj_prod_code = exp_product_code) ")
        sb.Append(" LEFT JOIN PAYOUT_TL_TRANSCODE_IL tcde ")
        sb.Append(" ON trim(t.rjil_trans_code) = trim(tcde.tltrans_code) ")
        sb.Append(" LEFT JOIN GPS_TL_BANKMASTER bnk ")
        sb.Append(" ON trim(t.rjil_bnkcode)=bnk.bkmst_bnkcode_no ")
        sb.Append(" LEFT JOIN gps_tl_reject_type rejtype ")
        sb.Append(" ON t.rjil_reject_type = rejtype.REJT_REJ_TYPE ")
        sb.Append(" LEFT JOIN PAYOUT_ROUND ")
        sb.Append(" ON RJIL_FILE_NAME_S1_S = PAYRD_FILENAME_S ")
        sb.Append(" WHERE t.rjil_rej_date  ='" & regendate & "' ")
        sb.Append(" AND PAYRD_ROUND = " & sBatchNo & " ")
        sb.Append(" ORDER BY t.rjil_reject_type, ")
        sb.Append("  tcde.tltrans_department, ")
        sb.Append("  t.rjil_paymth, ")
        sb.Append("  t.rjil_cust_ref  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        'Return Nothing
        'End If

    End Function

    Public Function getDataForHashTotalErrorGPSReport(ByVal oleConn As OleDbConnection, ByVal regendate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT T.GPCR_REJECT_TYPE rjil_reject_type, T.GPCR_PAIDDATE rjil_paiddate, PTYPE.PAYT_PAYTYPE exp_paymnt_name, ")
        sb.Append("       T.GPCR_TRANSREF rjil_trans_code, T.GPCR_DESC trans_desc, T.GPCR_CORE_SYSTEM dept, T.GPCR_POLNO rjil_polno, ")
        sb.Append("       T.GPCR_BNKCODE bkmst_bnkcode, '' rjil_cust_ref, T.GPCR_PAYEE_BNKACCNO rjil_bnkacc_no, ")
        sb.Append("       T.GPCR_PAYEE_NAME rjil_payee_nme, T.GPCR_AMOUNT rjil_amount, ")
        sb.Append("       T.GPCR_REMARK rjil_reject_reason, T.UPDATEDBY rjil_user_id, '' rjil_file_name_s1_d ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_PAYMENT_CREATION T ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.GPCR_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_PAYTYPE PTYPE ")
        sb.Append("    ON T.GPCR_PAYMTH = PTYPE.PAYT_PAYMTH ")
        sb.Append("   AND T.GPCR_SUB_PAYMTH = PTYPE.PAYT_SUB_PAYMTH ")
        sb.Append(" WHERE T.GPCR_REJECT_TYPE = 'ACC_CANCEL' ")
        '--sb.Append("   AND T.GPCR_APPROVEDDATE = '" & regendate & "' ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%' ")

        sb.Append("   AND T.GPCR_TRANSREF NOT IN ( ")
        sb.Append("Select T.GPRJ_TRANSREF ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_PAYMENT_REJ T ")
        sb.Append("  LEFT JOIN (SELECT GPS_PAYMENT_CREATION.GPCR_CREATEDATE, ")
        sb.Append("                    GPS_PAYMENT_CREATION.GPCR_CORE_SYSTEM, ")
        sb.Append("                    GPS_PAYMENT_CREATION.GPCR_TRANSREF, ")
        sb.Append("                    GPS_PAYMENT_CREATION.GPCR_REMARK, ")
        sb.Append("                    MAX(GPS_PAYMENT_CREATION.GPCR_APPROVEDDATE) GPCR_APPROVEDDATE ")
        sb.Append("        FROM(GENERATEPAYMENT.GPS_PAYMENT_CREATION) ")
        sb.Append("              GROUP BY GPS_PAYMENT_CREATION.GPCR_CREATEDATE, ")
        sb.Append("                       GPS_PAYMENT_CREATION.GPCR_CORE_SYSTEM, ")
        sb.Append("                       GPS_PAYMENT_CREATION.GPCR_TRANSREF, ")
        sb.Append("                       GPS_PAYMENT_CREATION.GPCR_REMARK) GPCR ")
        sb.Append("    ON T.GPRJ_CREATEDATE = GPCR.GPCR_CREATEDATE ")
        sb.Append("   AND T.GPRJ_CORE_SYSTEM = GPCR.GPCR_CORE_SYSTEM ")
        sb.Append("   AND T.GPRJ_TRANSREF = GPCR.GPCR_TRANSREF ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.GPRJ_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_PAYTYPE PTYPE ")
        sb.Append("    ON T.GPRJ_PAYMTH = PTYPE.PAYT_PAYMTH ")
        sb.Append("   AND T.GPRJ_SUB_PAYMTH = PTYPE.PAYT_SUB_PAYMTH ")
        sb.Append(" WHERE T.GPRJ_REJECT_FUNC = 'ACC_CAN' ")
        '--sb.Append("   AND GPCR.GPCR_APPROVEDDATE = '" & regendate & "') ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%') ")

        sb.Append(" UNION  ")
        sb.Append("SELECT T.GPRJ_REJECT_TYPE rjil_reject_type, T.GPRJ_PAIDDATE rjil_paiddate, PTYPE.PAYT_PAYTYPE exp_paymnt_name, ")
        sb.Append("       T.GPRJ_TRANSREF rjil_trans_code, T.GPRJ_DESC trans_desc, T.GPRJ_CORE_SYSTEM dept, T.GPRJ_POLNO rjil_polno, ")
        sb.Append("       T.GPRJ_BNKCODE bkmst_bnkcode, '' rjil_cust_ref, T.GPRJ_PAYEE_BNKACCNO rjil_bnkacc_no, ")
        sb.Append("       T.GPRJ_PAYEE_NAME rjil_payee_nme, T.GPRJ_AMOUNT rjil_amount, GPCR.GPCR_REMARK rjil_reject_reason, ")
        sb.Append("       T.UPDATEDBY rjil_user_id, '' rjil_file_name_s1_d ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_PAYMENT_REJ T ")
        sb.Append("  LEFT JOIN (SELECT GPS_PAYMENT_CREATION.GPCR_CREATEDATE, GPS_PAYMENT_CREATION.GPCR_CORE_SYSTEM, GPS_PAYMENT_CREATION.GPCR_TRANSREF, GPS_PAYMENT_CREATION.GPCR_REMARK, MAX(GPS_PAYMENT_CREATION.GPCR_APPROVEDDATE) GPCR_APPROVEDDATE FROM GENERATEPAYMENT.GPS_PAYMENT_CREATION GROUP BY GPS_PAYMENT_CREATION.GPCR_CREATEDATE, GPS_PAYMENT_CREATION.GPCR_CORE_SYSTEM, GPS_PAYMENT_CREATION.GPCR_TRANSREF, GPS_PAYMENT_CREATION.GPCR_REMARK ) GPCR ")
        sb.Append("    ON T.GPRJ_CREATEDATE = GPCR.GPCR_CREATEDATE ")
        sb.Append("   AND T.GPRJ_CORE_SYSTEM = GPCR.GPCR_CORE_SYSTEM ")
        sb.Append("   AND T.GPRJ_TRANSREF = GPCR.GPCR_TRANSREF ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.GPRJ_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_PAYTYPE PTYPE ")
        sb.Append("    ON T.GPRJ_PAYMTH = PTYPE.PAYT_PAYMTH ")
        sb.Append("   AND T.GPRJ_SUB_PAYMTH = PTYPE.PAYT_SUB_PAYMTH ")
        sb.Append(" WHERE T.GPRJ_REJECT_FUNC = 'ACC_CAN' ")
        '--sb.Append("   AND GPCR.GPCR_APPROVEDDATE = '" & regendate & "' ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%' ")
        sb.Append(" UNION ")
        sb.Append("SELECT T.TAXRJ_REJECT_TYPE rjil_reject_type, T.TAXRJ_TAXDATE rjil_paiddate, NVL(PTYPE.PAYT_PAYTYPE, 'NON PAY') exp_paymnt_name, T.TAXRJ_TRANSREF rjil_trans_code, ")
        sb.Append("       T.TAXRJ_DESC trans_desc, T.TAXRJ_CORE_SYSTEM dept, '' rjil_polno, '' bkmst_bnkcode, '' rjil_cust_ref, ")
        sb.Append("       '' rjil_bnkacc_no, T.TAXRJ_AP_FNAME rjil_payee_nme, T.TAXRJ_TAX_AMT rjil_amount,  ")
        sb.Append("       GPWT.TAXCR_REMARK rjil_reject_reason, T.UPDATEDBY rjil_user_id, '' rjil_file_name_s1_d ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_WHT_REJ T ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_WHT_CREATION GPWT ")
        sb.Append("    ON T.TAXRJ_CREATEDATE = GPWT.TAXCR_CREATEDATE ")
        sb.Append("   AND T.TAXRJ_CORE_SYSTEM = GPWT.TAXCR_CORE_SYSTEM ")
        sb.Append("   AND T.TAXRJ_TRANSREF = GPWT.TAXCR_TRANSREF ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.TAXRJ_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append("  left JOIN GENERATEPAYMENT.GPS_TRANSREF_REL R ")
        sb.Append("    ON R.TREF_CREATEDATE = T.TAXRJ_CREATEDATE ")
        sb.Append("   AND R.TREF_CORE_SYSTEM = T.TAXRJ_CORE_SYSTEM ")
        sb.Append("   AND R.TREF_TRANSREF = T.TAXRJ_TRANSREF ")
        '--sb.Append("   AND R.TREF_PAYMTH IS NULL ")
        '--sb.Append("   AND R.TREF_SUB_PAYMTH IS NULL ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_PAYTYPE PTYPE ")
        sb.Append("    ON R.TREF_PAYMTH = PTYPE.PAYT_PAYMTH ")
        sb.Append("   AND R.TREF_SUB_PAYMTH = PTYPE.PAYT_SUB_PAYMTH ")
        sb.Append(" WHERE T.TAXRJ_REJECT_FUNC = 'ACC_CAN' ")
        '--sb.Append("   AND GPWT.TAXCR_APPROVEDDATE = '" & regendate & "' ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%' ")
        sb.Append(" UNION  ")
        sb.Append("SELECT T.TAXCR_REJECT_TYPE rjil_reject_type, T.TAXCR_TAXDATE rjil_paiddate, NVL(PTYPE.PAYT_PAYTYPE, 'NON PAY') exp_paymnt_name, TAXCR_TRANSREF rjil_trans_code, ")
        sb.Append("       T.TAXCR_DESC trans_desc, T.TAXCR_CORE_SYSTEM dept, '' rjil_polno, '' bkmst_bnkcode, '' rjil_cust_ref, ")
        sb.Append("       '' rjil_bnkacc_no, T.TAXCR_AP_FNAME rjil_payee_nme, T.TAXCR_TAX_AMT rjil_amount, ")
        sb.Append("       T.TAXCR_REMARK rjil_reject_reason, T.UPDATEDBY rjil_user_id, '' rjil_file_name_s1_d ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_WHT_CREATION T ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.TAXCR_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append("  left JOIN GENERATEPAYMENT.GPS_TRANSREF_REL R ")
        sb.Append("    ON R.TREF_CREATEDATE = T.TAXCR_CREATEDATE ")
        sb.Append("   AND R.TREF_CORE_SYSTEM = T.TAXCR_CORE_SYSTEM ")
        sb.Append("   AND R.TREF_TRANSREF = T.TAXCR_TRANSREF ")
        '--sb.Append("   AND R.TREF_PAYMTH IS NULL ")
        '--sb.Append("   AND R.TREF_SUB_PAYMTH IS NULL ")
        sb.Append("  LEFT JOIN GENERATEPAYMENT.GPS_TL_PAYTYPE PTYPE ")
        sb.Append("    ON R.TREF_PAYMTH = PTYPE.PAYT_PAYMTH ")
        sb.Append("   AND R.TREF_SUB_PAYMTH = PTYPE.PAYT_SUB_PAYMTH ")
        sb.Append(" WHERE T.TAXCR_REJECT_TYPE = 'ACC_CANCEL' ")
        '--sb.Append("   AND T.TAXCR_APPROVEDDATE = '" & regendate & "' ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%' ")
        sb.Append("   AND T.TAXCR_TRANSREF NOT IN (SELECT T.TAXRJ_TRANSREF  ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_WHT_REJ T ")
        sb.Append("  INNER JOIN GENERATEPAYMENT.GPS_WHT_CREATION GPWT ")
        sb.Append("    ON T.TAXRJ_CREATEDATE = GPWT.TAXCR_CREATEDATE ")
        sb.Append("   AND T.TAXRJ_CORE_SYSTEM = GPWT.TAXCR_CORE_SYSTEM ")
        sb.Append("   AND T.TAXRJ_TRANSREF = GPWT.TAXCR_TRANSREF ")
        sb.Append("   AND T.TAXRJ_GPTREF_SEQNO = GPWT.TAXCR_GPTREF_SEQNO ")
        sb.Append("  INNER JOIN GENERATEPAYMENT.GPS_TL_REJECT_TYPE REJTYPE ")
        sb.Append("    ON T.TAXRJ_REJECT_TYPE = REJTYPE.REJT_REJ_TYPE ")
        sb.Append(" left JOIN GENERATEPAYMENT.GPS_TRANSREF_REL R ")
        sb.Append("    ON R.TREF_CREATEDATE = T.TAXRJ_CREATEDATE ")
        sb.Append("   AND R.TREF_CORE_SYSTEM = T.TAXRJ_CORE_SYSTEM ")
        sb.Append("   AND R.TREF_TRANSREF = T.TAXRJ_TRANSREF ")
        '--sb.Append("   AND R.TREF_PAYMTH IS NULL ")
        '--sb.Append("   AND R.TREF_SUB_PAYMTH IS NULL ")
        sb.Append(" WHERE T.TAXRJ_REJECT_FUNC = 'ACC_CAN' ")
        '--sb.Append("   AND GPWT.TAXCR_APPROVEDDATE = '" & regendate & "') ")
        sb.Append("   AND T.CREATEDDATE LIKE '" & regendate & "%') ")
        sb.Append("  ORDER BY RJIL_PAIDDATE, RJIL_TRANS_CODE")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        'Return Nothing
        'End If

    End Function

    Public Function getDataForMNGReport(ByVal oleConn As OleDbConnection, ByVal regendate As String, ByVal reprint As Boolean, ByVal dtPayoutGroupSetup As DataTable) As DataTable
        Dim sb As New StringBuilder

        sb.Append(" Select DISTINCT  'SCB' AS BANK ")
        sb.Append("     ,CASE WHEN PAYS_PROD_CODE IN ('CCP','MCP') THEN 'Cheque' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='MCL' THEN 'Media (Media Clearing)' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='DDP' THEN 'Draft' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='DCP' THEN 'Media (Direct Credit)' ")
        sb.Append("     END AS payment_type ")
        sb.Append("     ,PAYR_FILE_NAME_S ")
        sb.Append("     ,SUBSTR(PAYS_TRANS_DATE,7,2)||'/'||SUBSTR(PAYS_TRANS_DATE,5,2)||'/'||SUBSTR(PAYS_TRANS_DATE,0,4) AS PAYS_TRANS_DATE ")
        sb.Append("     ,PAYS_TRANS_DATE ")
        sb.Append("     ,PAYR_FILE_NAME_D ")
        sb.Append("     ,SUBSTR(PAYR_VALUE_DATE,7,2)||'/'||SUBSTR(PAYR_VALUE_DATE,5,2)||'/'||SUBSTR(PAYR_VALUE_DATE,0,4) AS PAYR_VALUE_DATE ")
        sb.Append("     ,TRUNC(TO_NUMBER(PAYS_9_TOT_NOOF_C)) AS PAYS_9_TOT_NOOF_C ")
        sb.Append("     ,TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  AS PAYS_9_TOT_AMOUNT ")
        'sb.Append("     ,CASE WHEN TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  >= 10000000 THEN 'A' ")
        'sb.Append("      WHEN TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  >= 2000000 AND TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  < 10000000 THEN 'B' ")
        'sb.Append("      WHEN TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14)) < 2000000  THEN 'C' ")

        sb.Append("     ,CASE ")

        For Each drPayoutGroupSetup As DataRow In dtPayoutGroupSetup.Rows

            If drPayoutGroupSetup("APPROVEGROUP") = "A" Then
                sb.Append("      WHEN TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup) + " THEN '" + drPayoutGroupSetup("APPROVEGROUP") + "' ")
            Else
                sb.Append("      WHEN TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  >= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "minamount", dtPayoutGroupSetup) + " AND TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  <= " + clsGPS_PayoutGroupSetup.GetAmountByGroup(drPayoutGroupSetup("APPROVEGROUP"), "maxamount", dtPayoutGroupSetup) + " THEN '" + drPayoutGroupSetup("APPROVEGROUP") + "' ")
            End If

        Next
        sb.Append("     END AS group_of_man ")
        sb.Append("     ,DECODE(PAYM_FILENAME_OUT_TOBANK,'','','( '||PAYM_FILENAME_OUT_TOBANK||' )')  AS NEW_FILE_NAME ")
        sb.Append("     ,PAYRD_ROUND")
        sb.Append(" FROM(PAYOUT_TOBANK_REL_IL) ")
        sb.Append(" INNER JOIN PAYOUT_TOBANK_SUM_IL ON PAYS_TRANS_DATE = PAYR_TRANS_DATE AND PAYS_FILE_NAME = PAYR_FILE_NAME_D ")
        If reprint Then
            sb.Append(" LEFT JOIN PAYOUT_ROUND ON PAYRD_TRANS_DATE = PAYR_TRANS_DATE AND PAYRD_FILENAME_S = PAYR_FILE_NAME_S ")
        Else
            sb.Append(" LEFT JOIN (SELECT * FROM PAYOUT_ROUND WHERE PAYRD_ROUND = (SELECT STRING_VALUE2 FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND')) ON PAYRD_TRANS_DATE = PAYR_TRANS_DATE AND PAYRD_FILENAME_S = PAYR_FILE_NAME_S ")
        End If
        sb.Append(" LEFT JOIN PAYOUT_TOBANK_MAP t_map ON PAYM_TRANS_DATE = PAYR_TRANS_DATE AND PAYM_FILENAME_OUT = PAYR_FILE_NAME_D ")
        sb.Append(" WHERE  PAYS_FILE_TYPE ='D' ")
        sb.Append(" AND PAYS_REC_TYPE = '999' ")
        sb.Append(" AND PAYS_TRANS_DATE  = '" & regendate & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        'Return Nothing
        'End If

    End Function

    Public Function getDataForSUMReport(ByVal oleConn As OleDbConnection, ByVal regendate As String, ByVal reprint As Boolean) As DataTable
        Dim sb As New StringBuilder

        sb.Append(" Select DISTINCT 'SCB' AS BANK ")
        sb.Append("     ,CASE WHEN PAYS_PROD_CODE IN ('CCP','MCP') THEN 'Cheque' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='MCL' THEN 'Media (Media Clearing)' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='DDP' THEN 'Draft' ")
        sb.Append("     WHEN PAYS_PROD_CODE ='DCP' THEN 'Media (Direct Credit)' ")
        sb.Append("     END AS payment_type ")
        sb.Append("     ,PAYR_FILE_NAME_S ")
        sb.Append("     ,SUBSTR(PAYS_TRANS_DATE,7,2)||'/'||SUBSTR(PAYS_TRANS_DATE,5,2)||'/'||SUBSTR(PAYS_TRANS_DATE,0,4) AS PAYS_TRANS_DATE ")
        sb.Append("     ,PAYS_TRANS_DATE ")
        sb.Append("     ,PAYR_FILE_NAME_D ")
        sb.Append("     ,SUBSTR(PAYR_VALUE_DATE,7,2)||'/'||SUBSTR(PAYR_VALUE_DATE,5,2)||'/'||SUBSTR(PAYR_VALUE_DATE,0,4) AS PAYR_VALUE_DATE ")
        sb.Append("     ,TRUNC(TO_NUMBER(PAYS_9_TOT_NOOF_C)) AS PAYS_9_TOT_NOOF_C ")
        sb.Append("     ,TO_NUMBER(SUBSTR(PAYS_9_TOT_AMOUNT,0,13)||'.'||SUBSTR(PAYS_9_TOT_AMOUNT,14))  AS PAYS_9_TOT_AMOUNT ")
        sb.Append("     ,DECODE(PAYM_FILENAME_OUT_TOBANK,'','','( '||PAYM_FILENAME_OUT_TOBANK||' )')  AS NEW_FILE_NAME ")
        sb.Append("     ,PAYRD_ROUND")
        sb.Append(" FROM(PAYOUT_TOBANK_REL_IL) ")
        sb.Append(" INNER JOIN PAYOUT_TOBANK_SUM_IL ON PAYS_TRANS_DATE = PAYR_TRANS_DATE AND PAYS_FILE_NAME = PAYR_FILE_NAME_D ")
        If reprint Then
            sb.Append(" LEFT JOIN PAYOUT_ROUND ON PAYRD_TRANS_DATE = PAYR_TRANS_DATE AND PAYRD_FILENAME_S = PAYR_FILE_NAME_S ")
        Else
            sb.Append(" LEFT JOIN (SELECT * FROM PAYOUT_ROUND WHERE PAYRD_ROUND = (SELECT STRING_VALUE2 FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND')) ON PAYRD_TRANS_DATE = PAYR_TRANS_DATE AND PAYRD_FILENAME_S = PAYR_FILE_NAME_S ")
        End If
        sb.Append(" LEFT JOIN PAYOUT_TOBANK_MAP t_map  ON PAYM_TRANS_DATE = PAYR_TRANS_DATE AND PAYM_FILENAME_OUT = PAYR_FILE_NAME_D ")
        sb.Append(" WHERE  PAYS_FILE_TYPE ='D' ")
        sb.Append(" AND PAYS_REC_TYPE = '999' ")
        sb.Append(" AND PAYS_TRANS_DATE  = '" & regendate & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        'Return Nothing
        'End If

    End Function

    Public Function getFileNameCombo(ByVal oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT DISTINCT '[' || GP_PAYMTH || ':' || GP_SUB_PAYMTH || ']' || PAYM_FILENAME_OUT_TOBANK AS TEXT ")
        sb.Append(", GP_EXPTOBANK_FILENME || '|' || PAYM_FILENAME_OUT_TOBANK AS VALUE ")
        sb.Append("FROM GPS_PAYMENT ")
        sb.Append("INNER JOIN PAYOUT_TOBANK_MAP ON PAYM_FILENAME_OUT = GP_EXPTOBANK_FILENME || '.txt' ")
        sb.Append("WHERE GP_CONFIRMDATE = TO_CHAR(sysdate, 'YYYYMMDD') ")
        sb.Append("AND GP_FLAG_EXPTOBANK = 'Y' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

    Public Function getFtpPath(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'AFPA' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getFtpPath = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getFtpPath = ""
        End Try
    End Function
    Public Function getOutputPath(ByVal oleConn As OleDbConnection) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append(" SELECT string_value1 FROM il_t_po_config_parameter WHERE code = 'OUTP' ")
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            getOutputPath = Ds.Tables(0).Rows(0)("string_value1")
        Catch ex As Exception
            getOutputPath = ""
        End Try
    End Function
    Public Function getOutputFileName(ByVal oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT DISTINCT  PAYM_FILENAME_OUT_TOBANK ")
        sb.Append("FROM    PAYOUT_ROUND ")
        sb.Append("        INNER JOIN PAYOUT_TOBANK_REL_IL ")
        sb.Append("            ON PAYRD_TRANS_DATE = PAYR_TRANS_DATE AND PAYRD_FILENAME_S = PAYR_FILE_NAME_S ")
        sb.Append("        INNER JOIN PAYOUT_TOBANK_MAP ON PAYM_TRANS_DATE = PAYR_TRANS_DATE AND PAYM_FILENAME_OUT = PAYR_FILE_NAME_D ")
        sb.Append("WHERE   PAYRD_ROUND = (SELECT STRING_VALUE2 FROM IL_T_PO_CONFIG_PARAMETER WHERE CODE = 'ROUND') ")
        sb.Append("AND     PAYRD_TRANS_DATE = ( ")
        sb.Append("            SELECT CASE WHEN STRING_VALUE1 = 'A' THEN to_char(sysdate, 'YYYYMMDD') ")
        sb.Append("                        WHEN STRING_VALUE1 = 'M' THEN STRING_VALUE2 END ")
        sb.Append("            FROM  IL_T_PO_CONFIG_PARAMETER ")
        sb.Append("            WHERE CODE = 'BUSC') ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function

End Class
