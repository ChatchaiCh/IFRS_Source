﻿Imports System.Net.Mail
Imports System.Text

Public Class ClsEmailUtil

    Public ProcessMsg As String
    Public ErrMsg As String
    Public RECIPIENT As String
    Public Sender As String
    Public CC As String
    Public Bcc As String
    Public Subject As String
    Public TextBody As String
    Public Attachment As String
    Public Mailserver As String
    Public smtpPort As Integer
    Public TextBodyEncoding As String
    Public TextBodyFormat As String
    Public EmailPriority As String


    Public Function sendMail() As Boolean
        Dim strMSG As String
        Dim blnCC As Boolean = False
        Dim blnAttachments As Boolean = False

        'get the product name, version and description from the assembly
        strMSG = System.Diagnostics.FileVersionInfo.GetVersionInfo( _
      System.Reflection.Assembly.GetExecutingAssembly.Location).ProductName _
              + " v" + System.Diagnostics.FileVersionInfo.GetVersionInfo( _
      System.Reflection.Assembly.GetExecutingAssembly.Location _
            ).ProductVersion + vbCrLf + _
         System.Diagnostics.FileVersionInfo.GetVersionInfo( _
         System.Reflection.Assembly.GetExecutingAssembly.Location _
              ).Comments + vbCrLf

        If Sender.ToString = "" Or RECIPIENT.ToString = "" Or Mailserver.ToString = "" Then
            strMSG = strMSG + "Usage: EPSendMail require from:" + Sender + ", " + _
                   "to:" + RECIPIENT + ", smtp Server:" + Mailserver + vbCrLf
            Console.Write(strMSG)
            Exit Function
        End If

        strMSG = strMSG + "Sending email message" + vbCrLf + _
            "  From        --> " + Trim(Sender) + vbCrLf + _
            "  To          --> " + Trim(RECIPIENT) + vbCrLf + _
            "  Subject     --> " + Trim(Subject) + vbCrLf + _
            "  Message     --> " + Trim(TextBody) + vbCrLf + _
            "  smtp Server --> " + Mailserver + vbCrLf

        If CC.ToString <> "" Then
            If Len(Trim(CC)) > 0 Then
                blnCC = True
                strMSG = strMSG + "  CC          --> " + Trim(CC) + _
                   vbCrLf
            End If
        End If

        If Attachment.ToString <> "" Then
            If Len(Trim(Attachment)) > 0 Then
                blnAttachments = True
                strMSG = strMSG + "  Attachments --> " + Trim(Attachment) + _
                   vbCrLf
            End If
        End If

        Console.Write(strMSG)

        'send the email
        Try

            Dim insMail As New MailMessage()
            With insMail
                .From = New MailAddress(Sender)
                .Subject = Trim(Subject)
                .Body = Trim(TextBody)

                Dim EachTo As String
                Dim delimTo As Char = CChar(";")
                For Each EachTo In RECIPIENT.Split(delimTo)
                    If EachTo <> "" Then
                        .To.Add(New MailAddress(EachTo))
                    End If
                Next

                If blnCC Then
                    Dim EachCC As String
                    Dim delimCC As Char = CChar(";")
                    For Each EachCC In CC.Split(delimCC)
                        .CC.Add(New MailAddress(EachCC))
                    Next
                End If

                If blnAttachments Then
                    Dim strAttach As String
                    Dim delimAtth As Char = CChar(";")
                    For Each strAttach In Attachment.Split(delimAtth)
                        .Attachments.Add(New Attachment(Trim(strAttach)))
                    Next
                End If

                Select Case TextBodyEncoding
                    Case Encoding.UTF7.EncodingName : .BodyEncoding = Encoding.UTF7
                    Case Encoding.UTF8.EncodingName : .BodyEncoding = Encoding.UTF8
                    Case Else : .BodyEncoding = Encoding.ASCII
                End Select

                Select Case UCase(TextBodyFormat)
                    Case "HTML" : .IsBodyHtml = True
                    Case Else : .IsBodyHtml = False
                End Select

                Select Case UCase(EmailPriority)
                    Case "HIGH" : .Priority = MailPriority.High
                    Case "LOW" : .Priority = MailPriority.Low
                    Case Else : .Priority = MailPriority.Normal
                End Select
            End With

            Dim mailClient As New SmtpClient()
            'smtpServer.DeliveryMethod = SmtpDeliveryMethod.Network 'Network is default
            mailClient.Host = Mailserver
            mailClient.Port = smtpPort
            mailClient.Send(insMail)
            mailClient.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory
            mailClient = Nothing
            insMail.Dispose()

            sendMail = True
            ProcessMsg = "Successfully sent email message" + vbCrLf
            Console.WriteLine(ProcessMsg)
            ProcessMsg = strMSG + ProcessMsg

        Catch err As Exception
            sendMail = False
            ErrMsg = "ERROR EXCEPTION " + err.Message + vbCrLf
            Console.WriteLine(ErrMsg)
            ErrMsg = strMSG + ErrMsg

        End Try
    End Function


End Class
