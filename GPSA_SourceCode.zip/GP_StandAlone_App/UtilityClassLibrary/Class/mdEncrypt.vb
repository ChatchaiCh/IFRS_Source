﻿' Migrate from VB6.0
' By copy source code and changes array code to start with 0 stead of 1

Option Explicit Off

Module mdEncrypt
    Public Function Encrypt(ByVal Plain As String, ByVal sEncKey As String) As String
        Dim EnCrypted2 As String
        Dim LenLetter As Integer
        Dim Letter As String
        Dim KeyNum As String
        Dim EncStr As String
        Dim Temp As String
        Dim Temp2 As String
        Dim iTempStr As String
        Dim iTempNum As Integer
        Dim Math As Long

        On Error GoTo Oops

        If Plain = "" Then
            Encrypt = ""
            Exit Function
        End If

        If sEncKey = "" Then sEncKey = "WhiteKnight"

        'ReDim encKEY(1 To Len(sEncKey))
        ReDim encKEY(0 To Len(sEncKey) - 1)

        For i% = 1 To Len(sEncKey$)
            KeyNum = Mid$(sEncKey$, i%, 1)
            encKEY(i% - 1) = Asc(KeyNum)
            If i% = 1 Then Math = encKEY(i% - 1) : GoTo NextOne
            If i% >= 2 And Math - encKEY(i% - 1) >= 0 And encKEY(i% - 1) <= encKEY(i% - 1 - 1) Then Math = Math - encKEY(i% - 1)
            If i% >= 2 And Math - encKEY(i% - 1) >= 0 And encKEY(i% - 1) <= encKEY(i% - 1 - 1) Then Math = Math - encKEY(i% - 1)
            If i% >= 2 And encKEY(i% - 1) >= Math And encKEY(i% - 1) >= encKEY(i% - 1 - 1) Then Math = Math + encKEY(i% - 1)
            If i% >= 2 And encKEY(i% - 1) < Math And encKEY(i% - 1) >= encKEY(i% - 1 - 1) Then Math = Math + encKEY(i% - 1)
NextOne:
        Next i%

        Plain$ = Scramb(Plain$)
        For i% = 1 To Len(Plain)
            Letter = Mid$(Plain, i%, 1)
            LenLetter = Asc(Letter) + Math
            If LenLetter >= 100 Then EncStr = EncStr & Asc(Letter) + Math & " "
            If LenLetter <= 99 Then EncStr$ = EncStr & "0" & Asc(Letter) + Math & " "
        Next i%

        Temp$ = EncStr
        Temp$ = TrimSpaces(Temp)
        iTempNum% = Mid(Temp, 1, 2)
        Temp2$ = Chr(iTempNum% + 100)

        If Len(iTempNum%) >= 2 Then iTempStr$ = Str(iTempNum%)
        If Len(iTempNum%) = 1 Then iTempStr$ = "0" & TrimSpaces(Str(iTempNum%))

        EnCrypted2$ = Temp2

        For i% = 3 To Len(Temp) Step 2
            iTempNum% = Mid(Temp, i%, 2)
            Temp2$ = Chr(iTempNum% + 100)
            If i% = Len(Temp) Then iTempStr$ = Str(iTempNum%) : GoTo ItsDone
            If Len(iTempNum%) = 2 Then iTempStr$ = Str(iTempNum%)
            If Len(TrimSpaces(Str(iTempNum))) = 1 Then iTempStr$ = "0" & TrimSpaces(Str(iTempNum%))
            If Left(TrimSpaces(Str(iTempNum)), 1) = "-" Then MsgBox("There is a bug in the ecryption method please contact your administrator with the following information." & vbCrLf & "Your Encryption Key, The Unencrypted String and the Encrypted String.", vbApplicationModal + vbCritical + vbDefaultButton1, "Encryption Error")
ItsDone:
            EnCrypted2$ = EnCrypted2 & Temp2$
        Next i%

        Encrypt = EnCrypted2
        Exit Function
Oops:
        Debug.Print("Error description", Err.Description)
        Debug.Print("Error source:", Err.Source)
        Debug.Print("Error Number:", Err.Number)
    End Function

    Public Function Decrypt(ByVal Encrypted As String, ByVal sEncKey As String) As String
        Dim NewEncrypted As String
        Dim Letter As String
        Dim KeyNum As String
        Dim EncNum As String
        Dim EncBuffer As Long
        Dim strDecrypted As String
        Dim Kdecrypt As String
        Dim LastTemp As String
        Dim LenTemp As Integer
        Dim Temp As String
        Dim Temp2 As String
        Dim iTempStr As String
        Dim iTempNum As Integer
        Dim Math As Long

        On Error GoTo Oops

        If Encrypted = "" Then
            Decrypt = ""
            Exit Function
        End If
        If sEncKey = "" Then sEncKey = "WhiteKnight"

        'ReDim encKEY(1 To Len(sEncKey))
        ReDim encKEY(0 To Len(sEncKey) - 1)

        For i% = 1 To Len(sEncKey$)
            KeyNum = Mid$(sEncKey$, i%, 1)
            encKEY(i% - 1) = Asc(KeyNum)
            If i% = 1 Then Math = encKEY(i% - 1) : GoTo NextOne
            If i% >= 2 And Math - encKEY(i% - 1) >= 0 And encKEY(i% - 1) <= encKEY(i% - 1 - 1) Then Math = Math - encKEY(i% - 1)
            If i% >= 2 And Math - encKEY(i% - 1) >= 0 And encKEY(i% - 1) <= encKEY(i% - 1 - 1) Then Math = Math - encKEY(i% - 1)
            If i% >= 2 And encKEY(i% - 1) >= Math And encKEY(i% - 1) >= encKEY(i% - 1 - 1) Then Math = Math + encKEY(i% - 1)
            If i% >= 2 And encKEY(i% - 1) < Math And encKEY(i% - 1) >= encKEY(i% - 1 - 1) Then Math = Math + encKEY(i% - 1)
NextOne:
        Next i%

        Temp$ = Encrypted

        For i% = 1 To Len(Temp)
            iTempStr = TrimSpaces(Str(Asc(Mid(Temp, i%, 1)) - 100))
            If Len(iTempStr$) = 2 Then iTempStr$ = iTempStr$
            If i% = Len(Temp) - 2 Then LenTemp% = Len(Mid(Temp2, Len(Temp2) - 3))
            If i% = Len(Temp) Then iTempStr$ = TrimSpaces(iTempStr$) : GoTo ItsDone
            If Len(TrimSpaces(iTempStr$)) = 1 Then iTempStr$ = "0" & TrimSpaces(iTempStr$)
            If Left(TrimSpaces(iTempStr$), 1) = "-" Then GoTo Oops
ItsDone:
            Temp2$ = Temp2$ & iTempStr
        Next i%

        Encrypted = TrimSpaces(Temp2$)

        For i% = 1 To Len(Encrypted) Step 3
            NewEncrypted = NewEncrypted & Mid(Encrypted, CLng(i%), 3) & " "
        Next i%

        LastTemp$ = TrimSpaces(Mid(NewEncrypted, Len(NewEncrypted$) - 3))
        If Len(LastTemp$) = 2 Then
            LastTemp$ = Mid(NewEncrypted, Len(NewEncrypted$) - 1)
            Encrypted = Mid(NewEncrypted, 1, Len(NewEncrypted) - 2) & "0" & LastTemp$
        Else
            Encrypted$ = NewEncrypted$
        End If

        For i% = 1 To Len(Encrypted)
            Letter = Mid$(Encrypted, i%, 1)
            EncNum = EncNum & Letter
            If Letter = " " Then
                EncBuffer = CLng(Mid(EncNum, 1, Len(EncNum) - 1))
                strDecrypted$ = strDecrypted & Chr(EncBuffer - Math)
                EncNum = ""
            End If
        Next i%

        Decrypt = strDecrypted
        Decrypt = UnScramb(strDecrypted$)
        Exit Function
Oops:
        Debug.Print("Error description", Err.Description)
        Debug.Print("Error source:", Err.Source)
        Debug.Print("Error Number:", Err.Number)
        MsgBox("You have entered the WRONG Encrypt key or have the wrong Encrypted message.", vbApplicationModal + vbCritical + vbCritical + vbMsgBoxSetForeground, "Decryption Error")
    End Function

    Private Function TrimSpaces(ByVal strString As String) As String
        Dim lngpos As Long
        Do While InStr(1, strString$, " ")
            'DoEvents()
            lngpos& = InStr(1, strString$, " ")
            strString$ = Left$(strString$, (lngpos& - 1&)) & Right$(strString$, Len(strString$) - (lngpos& + Len(" ") - 1&))
        Loop
        TrimSpaces$ = strString$
    End Function

    Public Function Scramb(ByVal strString As String) As String
        Dim i As Integer, Even As String = "", Odd As String = ""

        For i% = 1 To Len(strString$)
            If i% Mod 2 = 0 Then
                Even$ = Even$ & Mid(strString$, i%, 1)
            Else
                Odd$ = Odd$ & Mid(strString$, i%, 1)
            End If
        Next i
        Scramb$ = Even$ & Odd$
    End Function

    Public Function UnScramb(ByVal strString As String) As String
        Dim x As Integer, EvenInt As Integer, OddInt As Integer
        Dim Even As String, Odd As String, Fin As String

        x% = Len(strString$)
        x% = Int(Len(strString$) / 2)

        Even$ = Mid(strString$, 1, x%)
        Odd$ = Mid(strString$, x% + 1)
        For x = 1 To Len(strString$)
            If x% Mod 2 = 0 Then
                EvenInt% = EvenInt% + 1
                Fin$ = Fin$ & Mid(Even$, EvenInt%, 1)
            Else
                OddInt% = OddInt% + 1
                Fin$ = Fin$ & Mid(Odd$, OddInt%, 1)
            End If
        Next x%
        UnScramb$ = Fin$
    End Function
End Module
