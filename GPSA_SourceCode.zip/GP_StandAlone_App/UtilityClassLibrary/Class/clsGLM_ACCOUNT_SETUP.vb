﻿Imports System.Data.OleDb
Imports System.Text
Imports System.Configuration


Namespace DataClass
    Public Class clsGLM_ACCOUNT_SETUP
        Private _conndb As New System.Data.OleDb.OleDbConnection
        Private _scheme As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Private _tablename As String = "GLM_ACCOUNT_SETUP"
        Private _acnt_flag_anctpay As String
        Private _acnt_name_en As String
        Private _acnt_name_th As String
        Private _acnt_o_code As String
        Private _acnt_s_code As String
        Private _createdby As String
        Private _createddate As String
        Private _updatedby As String
        Private _updateddate As String
        Private _acnt_1gl_code As String
        Private _acnt_1gl_desc As String
        Private _acnt_1gl_scode As String
        Private _acnt_1gl_sdesc As String
        Private _acnt_type As String

        Public Property ConnDB As System.Data.OleDb.OleDbConnection
            Get
                ConnDB = _conndb
            End Get
            Set(value As System.Data.OleDb.OleDbConnection)
                _conndb = value
            End Set
        End Property

        Public Property ACNT_S_CODE As String
            Get
                ACNT_S_CODE = _acnt_s_code
            End Get
            Set(value As String)
                _acnt_s_code = value
            End Set
        End Property

        Public Property ACNT_NAME_TH As String
            Get
                ACNT_NAME_TH = _acnt_name_th
            End Get
            Set(value As String)
                _acnt_name_th = value
            End Set
        End Property

        Public Property ACNT_NAME_EN As String
            Get
                ACNT_NAME_EN = _acnt_name_en
            End Get
            Set(value As String)
                _acnt_name_en = value
            End Set
        End Property

        Public Property ACNT_O_CODE As String
            Get
                ACNT_O_CODE = _acnt_o_code
            End Get
            Set(value As String)
                _acnt_o_code = value
            End Set
        End Property

        Public Property ACNT_FLAG_ANCTPAY As String
            Get
                ACNT_FLAG_ANCTPAY = _acnt_flag_anctpay
            End Get
            Set(value As String)
                _acnt_flag_anctpay = value
            End Set
        End Property

        Public Property CREATEDBY As String
            Get
                CREATEDBY = _createdby
            End Get
            Set(value As String)
                _createdby = value
            End Set
        End Property

        Public Property CREATEDDATE As String
            Get
                CREATEDDATE = _createddate
            End Get
            Set(value As String)
                _createddate = value
            End Set
        End Property

        Public Property UPDATEDBY As String
            Get
                UPDATEDBY = _updatedby
            End Get
            Set(value As String)
                _updatedby = value
            End Set
        End Property

        Public Property UPDATEDDATE As String
            Get
                UPDATEDDATE = _updateddate
            End Get
            Set(value As String)
                _updateddate = value
            End Set
        End Property

        Public Property ACNT_1GL_CODE As String
            Get
                ACNT_1GL_CODE = _updateddate
            End Get
            Set(value As String)
                _acnt_1gl_code = value
            End Set
        End Property

        Public Property ACNT_1GL_DESC As String
            Get
                ACNT_1GL_DESC = _updateddate
            End Get
            Set(value As String)
                _acnt_1gl_desc = value
            End Set
        End Property

        Public Property ACNT_1GL_SCODE As String
            Get
                ACNT_1GL_SCODE = _updateddate
            End Get
            Set(value As String)
                _acnt_1gl_scode = value
            End Set
        End Property

        Public Property ACNT_1GL_SDESC As String
            Get
                ACNT_1GL_SDESC = _updateddate
            End Get
            Set(value As String)
                _acnt_1gl_sdesc = value
            End Set
        End Property

        Public Property ACNT_TYPE As String
            Get
                ACNT_TYPE = _updateddate
            End Get
            Set(value As String)
                _acnt_type = value
            End Set
        End Property

        Public Function Insert() As Boolean
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("INSERT INTO ")
                .Append(_scheme & "." & _tablename)
                .Append(" VALUES(")
                .Append(" '" & _acnt_s_code.Replace("'", "''") & "'") '-- acnt_s_code
                .Append(", '" & _acnt_name_th.Replace("'", "''") & "'") '-- acnt_name_th
                .Append(", '" & _acnt_name_en.Replace("'", "''") & "'") '-- acnt_name_en
                .Append(", '" & _acnt_o_code.Replace("'", "''") & "'") '-- acnt_o_code
                .Append(", '" & _acnt_flag_anctpay.Replace("'", "''") & "'") '-- acnt_flag_anctpay
                .Append(", '" & _createdby & "'") '-- createdby
                .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
                .Append(", '" & _createdby & "'") '-- updatedby
                .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
                .Append(", '" & _acnt_1gl_code.Replace("'", "''") & "'") '-- acnt_1gl_code
                .Append(", '" & _acnt_1gl_desc.Replace("'", "''") & "'") '-- acnt_1gl_desc
                .Append(", '" & _acnt_1gl_scode.Replace("'", "''") & "'") '-- acnt_1gl_scode
                .Append(", '" & _acnt_1gl_sdesc.Replace("'", "''") & "'") '-- acnt_1gl_sdesc
                .Append(", '" & _acnt_type.Replace("'", "''") & "'") '-- acnt_type
                .Append(")")
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function Update() As Boolean
            Dim strSQL As New StringBuilder
            Dim strFldUpd As New StringBuilder
            With strSQL
                .Append("UPDATE ")
                .Append(_scheme & "." & _tablename)
                .Append(" SET ")
                If _acnt_name_th.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_name_th = '" & _acnt_name_th.Replace("'", "''") & "'") '-- acnt_name_th
                End If
                If _acnt_name_en.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_name_en = '" & _acnt_name_en.Replace("'", "''") & "'") '-- acnt_name_en
                End If
                If _acnt_o_code.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_o_code = '" & _acnt_o_code.Replace("'", "''") & "'") '-- acnt_o_code
                End If
                If _acnt_flag_anctpay.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_flag_acntpay = '" & _acnt_flag_anctpay.Replace("'", "''") & "'") '-- acnt_flag_anctpay
                End If
                If _updatedby.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" updatedby = '" & _updatedby & "'") '-- updatedby
                End If
                If _acnt_1gl_code.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_1gl_code = '" & _acnt_1gl_code & "'") '-- acnt_1gl_code
                End If
                If _acnt_1gl_desc.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_1gl_desc = '" & _acnt_1gl_desc & "'") '-- acnt_1gl_desc
                End If
                If _acnt_1gl_scode.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_1gl_scode = '" & _acnt_1gl_scode & "'") '-- acnt_1gl_scode
                End If
                If _acnt_1gl_sdesc.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_1gl_sdesc = '" & _acnt_1gl_sdesc & "'") '-- acnt_1gl_sdesc
                End If
                If _acnt_type.Trim <> "" Then
                    If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                    strFldUpd.Append(" acnt_type = '" & _acnt_type & "'") '-- acnt_type
                End If
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
                .Append(strFldUpd.ToString)
                .Append(" WHERE acnt_s_code = '" & _acnt_s_code.Replace("'", "''") & "'") '-- acnt_s_code
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function Delete() As Boolean
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("DELETE FROM ")
                .Append(_scheme & "." & _tablename)
                .Append(" WHERE acnt_s_code = '" & _acnt_s_code.Replace("'", "''") & "'") '-- acnt_s_code
            End With
            Try
                Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
                Return _command.ExecuteNonQuery()
                'Return True
            Catch ex As Exception
                Throw ex
                Return False
            End Try
        End Function

        Public Function GetRecord(ByRef strWhereCondition As String) As DataTable
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT * ")
                .Append("  FROM " & _scheme & "." & _tablename)
                If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
                .Append(" ORDER BY ACNT_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                Return _dataset.Tables(0)
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try

        End Function

        Public Function Get_1Gl_Account_By_S_CODE(ByRef strS_CODE As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ACNT_1GL_CODE, ACNT_1GL_DESC, ACNT_1GL_SCODE, ACNT_1GL_SDESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ACNT_TYPE = 'AC' AND ACNT_S_CODE = '" & strS_CODE & "' ")
                .Append(" ORDER BY ACNT_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _acnt_1gl_code = _dataset.Tables(0).Rows(0).Item(0).ToString
                _acnt_1gl_desc = _dataset.Tables(0).Rows(0).Item(1).ToString
                _acnt_1gl_scode = _dataset.Tables(0).Rows(0).Item(2).ToString
                _acnt_1gl_sdesc = _dataset.Tables(0).Rows(0).Item(3).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_SubAccount_By_S_CODE(ByRef strS_CODE As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ACNT_1GL_SCODE, ACNT_1GL_SDESC, ACNT_1GL_CODE, ACNT_1GL_DESC ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ACNT_TYPE = 'AC' AND ACNT_S_CODE = '" & strS_CODE & "' ")
                .Append(" ORDER BY ACNT_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _acnt_1gl_scode = _dataset.Tables(0).Rows(0).Item(0).ToString
                _acnt_1gl_sdesc = _dataset.Tables(0).Rows(0).Item(1).ToString
                _acnt_1gl_code = _dataset.Tables(0).Rows(0).Item(2).ToString
                _acnt_1gl_desc = _dataset.Tables(0).Rows(0).Item(3).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_AccountDesc_By_1GL_CODE(ByRef str1GL_CODE As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ACNT_NAME_TH ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ACNT_TYPE = 'AO' AND ACNT_S_CODE = '" & str1GL_CODE & "' ")
                .Append(" ORDER BY ACNT_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _acnt_1gl_code = str1GL_CODE
                _acnt_1gl_desc = _dataset.Tables(0).Rows(0).Item(0).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

        Public Function Get_1Gl_SubAccountDesc_By_1GL_SubCODE(ByRef str1GL_SubCODE As String) As String
            Dim strSQL As New StringBuilder
            With strSQL
                .Append("SELECT ACNT_NAME_TH ")
                .Append("  FROM " & _scheme & "." & _tablename)
                .Append(" WHERE ACNT_TYPE = 'SA' AND ACNT_S_CODE = '" & str1GL_SubCODE & "' ")
                .Append(" ORDER BY ACNT_S_CODE")
            End With
            Try
                Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
                Dim _dataset As New DataSet
                _dataadapter.Fill(_dataset)
                _acnt_1gl_scode = str1GL_SubCODE
                _acnt_1gl_sdesc = _dataset.Tables(0).Rows(0).Item(0).ToString
                Return _dataset.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw ex
                Return Nothing
            End Try
        End Function

    End Class
End Namespace
