Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsUpdateInstrument
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetPaymentType(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT PAYT_PAYMTH||':'|| PAYT_SUB_PAYMTH AS ID ,PAYT_PAYTYPE AS NAME ")
        sb.Append("FROM GPS_TL_PAYTYPE WHERE PAYT_PAY_GROUP='SCBLIFE_CHQ' AND PAYT_PAYMTH||':'|| PAYT_SUB_PAYMTH<>'C:Q' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataForValidate(ByRef oleConn As OleDbConnection, ByVal company_chq As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select p.gp_chqno,count(*) as rec,sum(i.gp_amount) amt ")
        sb.Append("from gps_payment p inner join gps_instrument i ")
        sb.Append("on p.gp_seqno=i.gp_seqno ")
        sb.Append("where p.gp_chqno='" & company_chq & "' ")
        sb.Append("group by p.gp_chqno ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function ChkStatus(ByRef oleConn As OleDbConnection, ByVal company_chq As String) As Boolean
        Dim sb As New StringBuilder

        sb.Append("select count(*) rec from  gps_payment where gp_chqno='" & company_chq & "' and gp_lastupd_sts='O' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If dt.Rows(0)(0).ToString = "1" Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function ChkFindData(ByRef oleConn As OleDbConnection, ByVal company_chq As String) As Boolean
        Dim sb As New StringBuilder

        sb.Append("SELECT COUNT(*) REC FROM  GPS_INSTRUMENTNO_UPDTE WHERE GP_CHQNO='" & company_chq & "'  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If dt.Rows(0)(0) > 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function INS_GPS_INSTRUMENTNO_UPDTE(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Double

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("INSERT INTO GPS_INSTRUMENTNO_UPDTE ( ")
        sb.Append("GP_LOAD_DATE,")
        sb.Append("GP_FILENAME,")
        sb.Append("GP_NO,")
        sb.Append("GP_DESC,")
        sb.Append("GP_BNKBRN_NAME,")
        sb.Append("GP_CHQNO,")
        sb.Append("GP_PAIDDATE,")
        sb.Append("GP_AMOUNT,")
        sb.Append("GP_FEE,")
        sb.Append("GP_REMARK,")
        sb.Append("GP_SEQNO,")
        sb.Append("GP_GPTREF_SEQNO,")
        sb.Append("GP_INSTRUMENT_NO,")
        sb.Append("GP_REFNO,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES (")
        sb.Append("'" & dr("GP_LOAD_DATE") & "',")
        sb.Append("'" & dr("GP_FILENAME") & "',")
        sb.Append("'" & dr("GP_NO") & "',")
        sb.Append("'" & dr("GP_DESC") & "',")
        sb.Append("'" & dr("GP_BNKBRN_NAME") & "',")
        sb.Append("'" & dr("GP_CHQNO") & "',")
        sb.Append("'" & dr("GP_PAIDDATE") & "',")
        sb.Append("'" & dr("GP_AMOUNT") & "',")
        sb.Append("'" & dr("GP_FEE") & "',")
        sb.Append("'" & dr("GP_REMARK") & "',")
        sb.Append("'" & dr("GP_SEQNO") & "',")
        sb.Append("'" & dr("GP_GPTREF_SEQNO") & "',")
        sb.Append("'" & dr("GP_INSTRUMENT_NO") & "',")
        sb.Append("'" & dr("GP_REFNO") & "',")
        sb.Append("'" & dr("CREATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & dr("UPDATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        Return rec
    End Function
    Public Function DEL_GPS_INSTRUMENTNO_UPDTE(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal chqno As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("DELETE FROM GPS_INSTRUMENTNO_UPDTE  ")
        sb.Append("WHERE GP_CHQNO = '" & chqno & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Public Function UPD_GPS_INSTRUMENT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Decimal

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_INSTRUMENT SET   ")
        sb.Append("GP_INSTRUMENT_NO = '" & dr("GP_INSTRUMENT_NO") & "',  ")
        sb.Append("GP_REFNO = '" & dr("GP_REFNO") & "', ")
        sb.Append("UPDATEDBY ='" & dr("UPDATEDBY") & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE GP_SEQNO = '" & dr("GP_SEQNO") & "' ")
        sb.Append("AND GP_GPTREF_SEQNO  = '" & dr("GP_GPTREF_SEQNO") & "' ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        Return rec

    End Function
    Public Function GetDataForPrintReport(ByRef oleConn As OleDbConnection, ByVal company_chq As String, ByVal paymenttype As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT I.*  ")
        sb.Append("FROM GPS_INSTRUMENTNO_UPDTE I INNER JOIN GPS_PAYMENT P ")
        sb.Append("ON I.GP_CHQNO=P.GP_CHQNO ")
        sb.Append("WHERE P.GP_CHQNO='" & company_chq & "' ")
        If paymenttype <> "" Then
            sb.Append(" AND P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH ='" & paymenttype & "' ")
        End If
        sb.Append("ORDER BY I.GP_NO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
End Class
