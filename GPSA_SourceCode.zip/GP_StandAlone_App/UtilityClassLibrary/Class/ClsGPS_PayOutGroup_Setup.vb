﻿Imports System.Text
Imports UtilityClassLibrary

Public Class ClsGPS_PayOutGroup_Setup
    Dim clsBusiness As New BusinessLayer
    Dim clsUtility As New ConnectDB

    Public Sub New()
        If clsUtility.gConnGP.State <> ConnectionState.Open Then
            If clsUtility.OpenConnGP() = False Then
                'Cursor = Cursors.Default
                'MsgBox("Cannot connect database GP StandAlone" & vbCrLf & clsUtility.ErrConnectDBMessage, MsgBoxStyle.Critical)
                Exit Sub
            End If
        End If
    End Sub

    ''' <summary>
    ''' Get all data from table Gps_Payoutgroup_Setup
    ''' </summary>
    ''' <returns>DataTable include data from Gps_Payoutgroup_Setup</returns>
    ''' <remarks></remarks>
    Public Function GetGps_Payoutgroup_Setup() As DataTable

        Dim dtResponse As DataTable

        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM Gps_Payoutgroup_Setup pgs")
        dtResponse = clsBusiness.ExecuteReaderCommand(clsUtility.gConnGP, sb)

        If Not IsNothing(dtResponse) AndAlso dtResponse.Rows.Count > 0 Then
            Return dtResponse
        Else
            Return Nothing
        End If

    End Function

    ''' <summary>
    ''' Return amount by group and type
    ''' </summary>
    ''' <param name="group">Group A, Group B, Group C</param>
    ''' <param name="type">minamount, maxamount</param>
    ''' <param name="dtPayoutGroupSetup">Data from Gps_Payoutgroup_Setup</param>
    ''' <returns>amount(number(17,2) as string)</returns>
    ''' <remarks></remarks>
    Public Function GetAmountByGroup(ByVal group As String, ByVal type As String, ByVal dtPayoutGroupSetup As DataTable) As String

        Dim response As String

        For Each row As DataRow In dtPayoutGroupSetup.Rows
            If row("approvegroup") = group Then
                response = row(type)
                Exit For
            End If
        Next row

        Return response

    End Function

End Class