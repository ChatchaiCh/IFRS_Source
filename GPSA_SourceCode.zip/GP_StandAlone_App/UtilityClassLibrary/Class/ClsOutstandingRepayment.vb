﻿Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsOutstandingRepayment
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public gLastErrorMessage As String

    Public Function GetDataForReport(ByRef oleConn As OleDbConnection, ByVal strDateFrom As String, ByVal strDateTo As String) As DataTable
        Dim sb As New StringBuilder
        Try

            sb.Append("select rownum seq_no")
            sb.Append("     , case t.gp_paymth")
            sb.Append("         when 'C' then case when t.gp_confirmdate < '20160627' then 'Manager Cheque' else 'Corporate Cheque' end")
            sb.Append("         when 'D' then 'Demand Draft'")
            sb.Append("         when 'M' then case when t.gp_sub_paymth = 'M' and t.gp_bnkcode = 'SCB' then 'Direct Credit (SCB Account)' else 'Media Clearing (Non SCB Account)' end")
            sb.Append("         else ' '")
            sb.Append("       end payment_type")
            sb.Append("     , t.gp_sub_paymth")
            sb.Append("     , substr(t.gp_paiddate, 7, 2) || '/' || substr(t.gp_paiddate, 5, 2) || '/' || substr(t.gp_paiddate, 1, 4) as gp_paiddate")
            sb.Append("     , t.gp_payee_bnkaccno_new, t.gp_bnkscode, t.gp_bnkcode")
            sb.Append("     , case t.gp_paymth")
            sb.Append("         when 'C' then t.gp_chqno")
            sb.Append("         when 'D' then t.gp_chqno")
            sb.Append("         when 'M' then t.gp_payee_bnkaccno")
            sb.Append("       end payment_no")
            sb.Append("     , t.gp_polno, t.gp_payee_name, t.gp_paydesc, nvl(t.gp_amount,0) as gp_amount")
            sb.Append("     , nvl(w.tax_tax_amt,0) as tax_tax_amt, nvl(w.tax_base_amt,0) as tax_base_amt")
            sb.Append("  from generatepayment.gps_payment t")
            sb.Append("       left join generatepayment.gps_wht w")
            sb.Append("         on t.gp_transref = w.tax_transref")
            sb.Append("        and t.gp_gptref_seqno = w.tax_gptref_seqno")
            sb.Append(" where 1=1")
            sb.Append("   and t.gp_paiddate between '" & strDateFrom & "' and '" & strDateTo & "'")
            sb.Append("   and t.gp_paymth || t.gp_sub_paymth IN ('CG', 'CH', 'CC', 'CQ', 'DD', 'MM')")
            sb.Append("   and ( ( t.gp_paymth = 'C' and t.gp_lastupd_sts in ('R', 'S', 'C', 'E') )")
            sb.Append("      OR (t.gp_paymth = 'D' and t.gp_lastupd_sts in ('R', 'C', 'S'))")
            sb.Append("      OR ( t.gp_paymth = 'M' and t.gp_lastupd_sts in ('R', 'C', 'F') ) )")
            sb.Append(" order by t.gp_paymth, t.gp_sub_paymth, t.gp_paiddate, t.gp_chqno, t.gp_payee_bnkaccno, t.gp_payee_bnkaccno_new")

            Dim dt As DataTable
            dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

            If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                Return dt
            Else
                gLastErrorMessage = clsBusiness.gLastErrMessage
                Return Nothing
            End If
        Catch ex As Exception
            gLastErrorMessage = clsBusiness.gLastErrMessage
            Return Nothing
        End Try

    End Function

End Class
