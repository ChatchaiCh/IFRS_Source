Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsWatchLists
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetRptBankruptcy(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT T.WLSTN_SUBTYPE,T.WLSTN_SUBTYPE_NAME,DECODE(R.GPRJ_PAYMTH, 'M', R.GPRJ_PAYEE_BNKACCNME, R.GPRJ_PAYEE_NAME) AS GPRJ_PAYEE_NAME,R.GPRJ_POLNO,R.GPRJ_PAYMTH,R.GPRJ_DESC,R.GPRJ_PAIDDATE, ")
        sb.Append("R.GPRJ_AMOUNT,L.TREF_DEP_REPAY,L.TREF_BATCHDATE ")
        sb.Append("FROM (GPS_PAYMENT_REJ R INNER JOIN GPS_TL_WATCHLISTS_SUBTYPNME T ")
        sb.Append("ON R.GPRJ_WLSTT_SUBTYPE=T.WLSTN_SUBTYPE) ")
        sb.Append("INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON R.GPRJ_BATCHDATE=L.TREF_BATCHDATE ")
        sb.Append("AND R.GPRJ_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND R.GPRJ_TRANSREF=L.TREF_TRANSREF ")
        sb.Append("WHERE R.GPRJ_BATCHDATE='" & batchdate & "' ")
        sb.Append("AND R.GPRJ_REJECT_TYPE='WLST_ERR' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetRptAML(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT T.WLSTN_SUBTYPE,T.WLSTN_SUBTYPE_NAME,DECODE(A.GPRJ_PAYMTH, 'M', A.GPRJ_PAYEE_BNKACCNME,A.GPRJ_PAYEE_NAME) AS GPRJ_PAYEE_NAME ,A.GPRJ_POLNO,A.GPRJ_PAYMTH,A.GPRJ_DESC,A.GPRJ_PAIDDATE, ")
        sb.Append("A.GPRJ_AMOUNT,L.TREF_DEP_REPAY,L.TREF_BATCHDATE ")
        sb.Append("FROM (GPS_AML A INNER JOIN GPS_TL_WATCHLISTS_SUBTYPNME T ")
        sb.Append("ON A.GPRJ_WLSTT_SUBTYPE=T.WLSTN_SUBTYPE) ")
        sb.Append("INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON A.GPRJ_BATCHDATE=L.TREF_BATCHDATE ")
        sb.Append("AND A.GPRJ_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND A.GPRJ_TRANSREF=L.TREF_TRANSREF ")
        sb.Append("WHERE A.GPRJ_BATCHDATE='" & batchdate & "' ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
End Class
