Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class clsCrystalToPDFConverter

        Dim ConInfo As New CrystalDecisions.Shared.TableLogOnInfo

        Dim cRDoc As New ReportDocument

        Dim expo As New ExportOptions

        Dim sRecSelFormula As String

        Dim oDfDopt As New DiskFileDestinationOptions

        Dim strCrystalReportFilePath As String

        Dim strPdfFileDestinationPath As String
    Public Sub SetCrystalReportFilePath(ByVal CrystalReportFileNameFullPath As String)

        strCrystalReportFilePath = CrystalReportFileNameFullPath

    End Sub

    Public Sub SetPdfDestinationFilePath(ByVal pdfFileNameFullPath As String)

        strPdfFileDestinationPath = pdfFileNameFullPath

    End Sub

    Public Sub SetRecordSelectionFormula(ByVal recSelFormula As String)

        sRecSelFormula = recSelFormula

    End Sub

    Public Sub ExportReport()

        cRDoc.Load(strCrystalReportFilePath) 'loads the crystalreports in to the memory

        cRDoc.RecordSelectionFormula = sRecSelFormula 'used if u want pass the query to u r crystal form

        oDfDopt.DiskFileName = strPdfFileDestinationPath 'path of file where u want to locate ur PDF

        expo = cRDoc.ExportOptions

        expo.ExportDestinationType = ExportDestinationType.DiskFile

        expo.ExportFormatType = ExportFormatType.PortableDocFormat

        expo.DestinationOptions = oDfDopt

        cRDoc.SetDatabaseLogon("PaySquare", "paysquare") 'login for your DataBase

        cRDoc.Export()

    End Sub
    Public Sub ExportReport(ByVal dt As DataTable, ByVal lstparamname As ArrayList, ByVal lstparamvalue As ArrayList)

        cRDoc.Load(strCrystalReportFilePath) 'loads the crystalreports in to the memory

        Call FillDataTableToReport(dt, lstparamname, lstparamvalue) 'used if u want pass the query to u r crystal form

        oDfDopt.DiskFileName = strPdfFileDestinationPath 'path of file where u want to locate ur PDF

        expo = cRDoc.ExportOptions

        expo.ExportDestinationType = ExportDestinationType.DiskFile

        expo.ExportFormatType = ExportFormatType.PortableDocFormat

        expo.DestinationOptions = oDfDopt

        'cRDoc.SetDatabaseLogon("pbill", "pbille") 'login for your DataBase

        cRDoc.Export(expo)

    End Sub


    Public Sub ExportReportCetificate(ByVal dt As DataTable)

        cRDoc.Load(strCrystalReportFilePath) 'loads the crystalreports in to the memory

        Call FillDataTableToReportCertificate(dt) 'used if u want pass the query to u r crystal form

        oDfDopt.DiskFileName = strPdfFileDestinationPath 'path of file where u want to locate ur PDF

        expo = cRDoc.ExportOptions

        expo.ExportDestinationType = ExportDestinationType.DiskFile

        expo.ExportFormatType = ExportFormatType.PortableDocFormat

        expo.DestinationOptions = oDfDopt

        'cRDoc.SetDatabaseLogon("pbill", "pbille") 'login for your DataBase

        cRDoc.Export(expo)

    End Sub
    Public Sub FillDataTableToReport(ByVal dt As DataTable, ByVal lstparamname As ArrayList, ByVal lstparamvalue As ArrayList)

        Try

            With cRDoc
                .SetDataSource(dt)

                For i As Integer = 0 To lstparamname.Count - 1
                    .SetParameterValue(lstparamname(i).ToString, lstparamvalue(i).ToString)
                Next

                '.SetParameterValue("pJournalType", paramDate)
                '.SetParameterValue("pTransdate", paramRound)
                '.SetParameterValue("pUser", userName)

            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub
    Public Sub FillDataTableToReportCertificate(ByVal dt As DataTable)

        Try

            With cRDoc
                .SetDataSource(dt)
                .Subreports(0).SetDataSource(dt)

            End With

        Catch ex As Exception
            Dim msg As String = ex.Message
        End Try

    End Sub

    Public Sub ExportReport(ByVal dt As DataTable)

        cRDoc.Load(strCrystalReportFilePath) 'loads the crystalreports in to the memory

        Call FillDataTableToReportCertificate(dt) 'used if u want pass the query to u r crystal form

        oDfDopt.DiskFileName = strPdfFileDestinationPath 'path of file where u want to locate ur PDF

        expo = cRDoc.ExportOptions

        expo.ExportDestinationType = ExportDestinationType.DiskFile

        expo.ExportFormatType = ExportFormatType.PortableDocFormat

        expo.DestinationOptions = oDfDopt

        'cRDoc.SetDatabaseLogon("pbill", "pbille") 'login for your DataBase

        cRDoc.Export(expo)

    End Sub

End Class


