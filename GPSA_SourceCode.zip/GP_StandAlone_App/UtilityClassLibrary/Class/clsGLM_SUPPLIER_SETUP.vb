﻿Imports System.Data.OleDb
Imports System.Text
Imports UtilityClassLibrary

Public Class clsGLM_SUPPLIER_SETUP
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Private _conndb As New System.Data.OleDb.OleDbConnection
    Private _scheme As String = "GENERATEPAYMENT"
    Private _tablename As String = "GLM_SUPPLIER_SETUP"
    Private _supp_date As String '--CHAR(8) not null,        
    Private _supp_code As String '--VARCHAR2(10) not null,   
    Private _supp_s_account As String '--VARCHAR2(10) default '', 
    Private _supp_name_gp As String '--VARCHAR2(100) default '',
    Private _supp_name_tax As String '--VARCHAR2(100) default '',
    Private _supp_taxid As String '--VARCHAR2(14) default '', 
    Private _supp_bnkcode_no_gp As String '--VARCHAR2(5) default '',  
    Private _supp_bnkaccno_gp As String '--VARCHAR2(20) default '', 
    Private _supp_address_gp As String '--VARCHAR2(255) default '',
    Private _supp_ampenm_gp As String '--VARCHAR2(100) default '',
    Private _supp_provnm_gp As String '--VARCHAR2(100) default '',
    Private _supp_agzip_gp As String '--VARCHAR2(10) default '', 
    Private _supp_address_tax As String '--VARCHAR2(255) default '',
    Private _supp_ampenm_tax As String '--VARCHAR2(100) default '',
    Private _supp_provnm_tax As String '--VARCHAR2(100) default '',
    Private _supp_agzip_tax As String '--VARCHAR2(10) default '', 
    Private _supp_country As String '--VARCHAR2(50) default '', 
    Private _supp_tel_no As String '--VARCHAR2(25) default '', 
    Private _supp_fax_no As String '--VARCHAR2(25) default '', 
    Private _supp_status As String '--VARCHAR2(8) default '',  
    Private _createdby As String '--VARCHAR2(20) not null,   
    Private _createddate As String '--CHAR(15) not null,       
    Private _updatedby As String '--VARCHAR2(20) not null,   
    Private _updateddate As String '--CHAR(15) not null        


    Public Property ConnDB As System.Data.OleDb.OleDbConnection
        Get
            ConnDB = _conndb
        End Get
        Set(value As System.Data.OleDb.OleDbConnection)
            _conndb = value
        End Set
    End Property

    Public Property supp_date As String
        Get
            supp_date = _supp_date
        End Get
        Set(value As String)
            _supp_date = value
        End Set
    End Property

    Public Property supp_code As String
        Get
            supp_code = _supp_code
        End Get
        Set(value As String)
            _supp_code = value
        End Set
    End Property

    Public Property supp_s_account As String
        Get
            supp_s_account = _supp_s_account
        End Get
        Set(value As String)
            _supp_s_account = value
        End Set
    End Property

    Public Property supp_name_gp As String
        Get
            supp_name_gp = _supp_name_gp
        End Get
        Set(value As String)
            _supp_name_gp = value
        End Set
    End Property

    Public Property supp_name_tax As String
        Get
            supp_name_tax = _supp_name_tax
        End Get
        Set(value As String)
            _supp_name_tax = value
        End Set
    End Property

    Public Property supp_taxid As String
        Get
            supp_taxid = _supp_taxid
        End Get
        Set(value As String)
            _supp_taxid = value
        End Set
    End Property

    Public Property supp_bnkcode_no_gp As String
        Get
            supp_bnkcode_no_gp = _supp_bnkcode_no_gp
        End Get
        Set(value As String)
            _supp_bnkcode_no_gp = value
        End Set
    End Property

    Public Property supp_bnkaccno_gp As String
        Get
            supp_bnkaccno_gp = _supp_bnkaccno_gp
        End Get
        Set(value As String)
            _supp_bnkaccno_gp = value
        End Set
    End Property

    Public Property supp_address_gp As String
        Get
            supp_address_gp = _supp_address_gp
        End Get
        Set(value As String)
            _supp_address_gp = value
        End Set
    End Property

    Public Property supp_ampenm_gp As String
        Get
            supp_ampenm_gp = _supp_ampenm_gp
        End Get
        Set(value As String)
            _supp_ampenm_gp = value
        End Set
    End Property

    Public Property supp_provnm_gp As String
        Get
            supp_provnm_gp = _supp_provnm_gp
        End Get
        Set(value As String)
            _supp_provnm_gp = value
        End Set
    End Property

    Public Property supp_agzip_gp As String
        Get
            supp_agzip_gp = _supp_agzip_gp
        End Get
        Set(value As String)
            _supp_agzip_gp = value
        End Set
    End Property

    Public Property supp_address_tax As String
        Get
            supp_address_tax = _supp_address_tax
        End Get
        Set(value As String)
            _supp_address_tax = value
        End Set
    End Property

    Public Property supp_ampenm_tax As String
        Get
            supp_ampenm_tax = _supp_ampenm_tax
        End Get
        Set(value As String)
            _supp_ampenm_tax = value
        End Set
    End Property

    Public Property supp_provnm_tax As String
        Get
            supp_provnm_tax = _supp_provnm_tax
        End Get
        Set(value As String)
            _supp_provnm_tax = value
        End Set
    End Property

    Public Property supp_agzip_tax As String
        Get
            supp_agzip_tax = _supp_agzip_tax
        End Get
        Set(value As String)
            _supp_agzip_tax = value
        End Set
    End Property

    Public Property supp_country As String
        Get
            supp_country = _supp_country
        End Get
        Set(value As String)
            _supp_country = value
        End Set
    End Property

    Public Property supp_tel_no As String
        Get
            supp_tel_no = _supp_tel_no
        End Get
        Set(value As String)
            _supp_tel_no = value
        End Set
    End Property

    Public Property supp_fax_no As String
        Get
            supp_fax_no = _supp_fax_no
        End Get
        Set(value As String)
            _supp_fax_no = value
        End Set
    End Property

    Public Property supp_status As String
        Get
            supp_status = _supp_status
        End Get
        Set(value As String)
            _supp_status = value
        End Set
    End Property

    Public Property createdby As String
        Get
            createdby = _createdby
        End Get
        Set(value As String)
            _createdby = value
        End Set
    End Property

    Public Property createddate As String
        Get
            createddate = _createddate
        End Get
        Set(value As String)
            _createddate = value
        End Set
    End Property

    Public Property updatedby As String
        Get
            updatedby = _updatedby
        End Get
        Set(value As String)
            _updatedby = value
        End Set
    End Property

    Public Property updateddate As String
        Get
            updateddate = _updateddate
        End Get
        Set(value As String)
            _updateddate = value
        End Set
    End Property

    Public Function Insert() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("INSERT INTO ")
            .Append(_scheme & "." & _tablename)
            .Append(" VALUES(")
            .Append(" '" & _supp_date.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_code.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_s_account.Replace("'", "''") & "'") '--  
            .Append(", '" & _supp_name_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_name_tax.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_taxid.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_bnkcode_no_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_bnkaccno_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_address_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_ampenm_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_provnm_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_agzip_gp.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_address_tax.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_ampenm_tax.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_provnm_tax.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_agzip_tax.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_country.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_tel_no.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_fax_no.Replace("'", "''") & "'") '-- 
            .Append(", '" & _supp_status.Replace("'", "''") & "'") '-- 
            .Append(", '" & _createdby & "'") '-- createdby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- createddate
            .Append(", '" & _updatedby & "'") '-- updatedby
            .Append(", TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(")")
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function Update() As Boolean
        Dim strSQL As New StringBuilder
        Dim strFldUpd As New StringBuilder
        With strSQL
            .Append("UPDATE ")
            .Append(_scheme & "." & _tablename)
            .Append(" SET ")
            If _supp_s_account.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_s_account = '" & _supp_s_account.Replace("'", "''") & "'") '-- _supp_s_account
            End If
            If _supp_name_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_name_gp = '" & _supp_name_gp.Replace("'", "''") & "'") '-- _supp_name_gp
            End If
            If _supp_name_tax.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_name_tax = '" & _supp_name_tax.Replace("'", "''") & "'") '-- _supp_name_tax
            End If
            If _supp_taxid.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_taxid = '" & _supp_taxid.Replace("'", "''") & "'") '-- _supp_taxid
            End If
            If _supp_bnkcode_no_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_bnkcode_no_gp = '" & _supp_bnkcode_no_gp.Replace("'", "''") & "'") '-- _supp_bnkcode_no_gp
            End If
            If _supp_bnkaccno_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_bnkaccno_gp = '" & _supp_bnkaccno_gp.Replace("'", "''") & "'") '-- _supp_bnkaccno_gp
            End If
            If _supp_address_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_address_gp = '" & _supp_address_gp.Replace("'", "''") & "'") '-- _supp_address_gp
            End If
            If _supp_ampenm_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_ampenm_gp = '" & _supp_ampenm_gp.Replace("'", "''") & "'") '-- _supp_ampenm_gp
            End If
            If _supp_provnm_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_provnm_gp = '" & _supp_provnm_gp.Replace("'", "''") & "'") '-- _supp_provnm_gp
            End If
            If _supp_agzip_gp.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_agzip_gp = '" & _supp_agzip_gp.Replace("'", "''") & "'") '-- _supp_agzip_gp
            End If
            If _supp_address_tax.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_address_tax = '" & _supp_address_tax.Replace("'", "''") & "'") '-- _supp_address_tax
            End If
            If _supp_ampenm_tax.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_ampenm_tax = '" & _supp_ampenm_tax.Replace("'", "''") & "'") '-- _supp_ampenm_tax
            End If
            If _supp_provnm_tax.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_provnm_tax = '" & _supp_provnm_tax.Replace("'", "''") & "'") '-- _supp_provnm_tax
            End If
            If _supp_agzip_tax.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_agzip_tax = '" & _supp_agzip_tax.Replace("'", "''") & "'") '-- _supp_agzip_tax
            End If
            If _supp_country.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" _supp_country = '" & _supp_country.Replace("'", "''") & "'") '-- _supp_country
            End If
            If _supp_tel_no.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_tel_no = '" & _supp_tel_no.Replace("'", "''") & "'") '-- _supp_tel_no
            End If
            If _supp_fax_no.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_fax_no = '" & _supp_fax_no.Replace("'", "''") & "'") '-- _supp_fax_no
            End If
            If _supp_status.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" supp_status = '" & _supp_status.Replace("'", "''") & "'") '-- _supp_status
            End If

            If _updatedby.Trim <> "" Then
                If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
                strFldUpd.Append(" updatedby = '" & _updatedby & "'") '-- updatedby
            End If
            If strFldUpd.Length > 0 Then strFldUpd.Append(" ,")
            strFldUpd.Append(" UPDATEDDATE = TO_CHAR(SYSDATE, 'YYYYMMDD')") '-- updateddate
            .Append(strFldUpd.ToString)
            .Append(" WHERE ")
            .Append(" supp_date = '" & _supp_date.Replace("'", "''") & "'") '-- supp_date
            .Append(" and supp_code = '" & _supp_code.Replace("'", "''") & "'") '-- supp_code 
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Public Function Delete() As Boolean
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("DELETE FROM ")
            .Append(_scheme & "." & _tablename)
            .Append(" WHERE ")
            .Append(" supp_date = '" & _supp_date.Replace("'", "''") & "'") '-- supp_date
            .Append(" and supp_code = '" & _supp_code.Replace("'", "''") & "'") '-- supp_code 
        End With
        Try
            Dim _command As New OleDbCommand(strSQL.ToString, _conndb)
            Return _command.ExecuteNonQuery()
            'Return True
        Catch ex As Exception
            Throw ex
            Return False
        End Try
    End Function

    Public Function GetRecord(ByRef strWhereCondition As String) As DataTable
        Dim strSQL As New StringBuilder
        With strSQL
            .Append("SELECT * ")
            .Append("  FROM " & _scheme & "." & _tablename)
            If strWhereCondition.Trim <> "" Then .Append(" WHERE " & strWhereCondition & "")
            .Append(" ORDER BY supp_date, supp_code")
        End With
        Try
            Dim _dataadapter As New OleDbDataAdapter(strSQL.ToString, _conndb)
            Dim _dataset As New DataSet
            _dataadapter.Fill(_dataset)
            Return _dataset.Tables(0)
        Catch ex As Exception
            Throw ex
            Return Nothing
        End Try
    End Function

End Class
