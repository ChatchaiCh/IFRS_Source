Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsBuyBankDraft
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function BindPaymentType(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT PAYT_PAYMTH||':'||PAYT_SUB_PAYMTH ID,PAYT_PAYTYPE AS NAME ")
        sb.Append("FROM GPS_TL_PAYTYPE WHERE PAYT_PAY_GROUP='SCBLIFE_CHQ' AND PAYT_SUB_PAYMTH <> 'Q' ")
       

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindDataInstrument(ByRef oleConn As OleDbConnection, ByVal batchdate As String, ByVal batchno As String, ByVal paymenttype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_CHQNO,P.GP_PAYEE_NAME AS PAYEE_HEAD,I.GP_SEQNO || '|' || I.GP_GPTREF_SEQNO AS REMARK,I.*, ")
        sb.Append("CASE WHEN P.GP_SUB_PAYMTH='G' THEN 15  ")
        sb.Append("WHEN P.GP_SUB_PAYMTH='B' AND P.GP_AMOUNT <= 50000 THEN 30 ")
        sb.Append("WHEN P.GP_SUB_PAYMTH='B' AND P.GP_AMOUNT > 50000 THEN 30+ROUND((P.GP_AMOUNT-50000)/1000,0) ")
        sb.Append("ELSE 0 END AS FEE ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCBLIFE_CHQ' ")
        sb.Append("INNER JOIN GPS_INSTRUMENT I ")
        sb.Append("ON P.GP_SEQNO=I.GP_SEQNO ")
        'sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH <> 'C:Q' ")
        sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH in ('C:G','C:B') ")
        If batchdate <> "" Then
            sb.Append("AND L.TREF_BATCHDATE='" & batchdate & "' ")
        End If
        If batchno <> "" Then
            sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        End If
        If paymenttype <> "ALL" Then
            sb.Append("AND UPPER(T.PAYT_PAYTYPE)='" & paymenttype.ToUpper & "' ")
        End If

        sb.Append("ORDER BY I.GP_GPTREF_SEQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindDataInstrumentForXls(ByRef oleConn As OleDbConnection, ByVal chqno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_CHQNO,P.GP_PAYEE_NAME AS PAYEE_HEAD,I.GP_SEQNO || '|' || I.GP_GPTREF_SEQNO AS REMARK,I.*, ")
        sb.Append("CASE WHEN P.GP_SUB_PAYMTH='G' THEN 15  ")
        sb.Append("WHEN P.GP_SUB_PAYMTH='B' AND P.GP_AMOUNT <= 50000 THEN 30 ")
        sb.Append("WHEN P.GP_SUB_PAYMTH='B' AND P.GP_AMOUNT > 50000 THEN 30+ROUND((P.GP_AMOUNT-50000)/1000,0) ")
        sb.Append("ELSE 0 END AS FEE ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCBLIFE_CHQ' ")
        sb.Append("INNER JOIN GPS_INSTRUMENT I ")
        sb.Append("ON P.GP_SEQNO=I.GP_SEQNO ")
        sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH <> 'C:Q' ")
        sb.Append("AND P.GP_CHQNO='" & chqno & "' ")
        sb.Append("ORDER BY I.GP_GPTREF_SEQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GroupByDataInstrument(ByRef oleConn As OleDbConnection, ByVal batchdate As String, ByVal batchno As String, ByVal paymenttype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_CHQNO ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH ")
        sb.Append("AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='SCBLIFE_CHQ' ")
        sb.Append("INNER JOIN GPS_INSTRUMENT I ")
        sb.Append("ON P.GP_SEQNO=I.GP_SEQNO ")
        sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH <> 'C:Q' ")

        If batchdate <> "" Then
            sb.Append("AND L.TREF_BATCHDATE='" & batchdate & "' ")
        End If
        If batchno <> "" Then
            sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        End If
        If paymenttype <> "ALL" Then
            sb.Append("AND UPPER(T.PAYT_PAYTYPE)='" & paymenttype.ToUpper & "' ")
        End If

        sb.Append("GROUP BY  P.GP_CHQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindDataPayment(ByRef oleConn As OleDbConnection, ByVal batchdate As String, ByVal batchno As String, ByVal paymenttype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_CHQNO,P.GP_PAIDDATE,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME,P.GP_BNKSACC_NO,COUNT(I.GP_SEQNO) REC,SUM(I.GP_AMOUNT) AMT ")

        '--- Begin Adjust by Songpol 22/01/2015 ----
        '--- �觢������ѵ�ػ��ʧ������觫��� �����ʴ������§ҹ Application From
        sb.Append(" , MAX(L.TREF_PPOSE_PCHASE) as PURPOSE ")
        '--- End Adjust by Songpol 22/01/2015 ----

        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM AND P.GP_TRANSREF=L.TREF_TRANSREF) INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON L.TREF_PAYMTH=T.PAYT_PAYMTH AND L.TREF_SUB_PAYMTH=T.PAYT_SUB_PAYMTH AND T.PAYT_PAY_GROUP='SCBLIFE_CHQ' ")
        sb.Append("INNER JOIN GPS_INSTRUMENT I ON P.GP_SEQNO=I.GP_SEQNO   ")
        sb.Append("WHERE 1=1  ")

        If batchdate <> "" Then
            sb.Append("AND L.TREF_BATCHDATE='" & batchdate & "' ")
        End If
        If batchno <> "" Then
            sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        End If
        If paymenttype <> "ALL" Then
            sb.Append("AND UPPER(T.PAYT_PAYTYPE)='" & paymenttype.ToUpper & "' ")
        End If

        sb.Append("GROUP BY P.GP_CHQNO,P.GP_PAIDDATE,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME,P.GP_BNKSACC_NO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
End Class
