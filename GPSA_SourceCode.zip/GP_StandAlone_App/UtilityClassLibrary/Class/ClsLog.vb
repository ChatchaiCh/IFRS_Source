﻿Imports System.Text
Imports System.Data.OleDb

Public Class ClsLog
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Public gLastErrMessage As String
    Public Function getAdjlLog(ByRef oleConn As OleDbConnection, ByVal logTypeId As Integer) As DataTable
        Dim sb As New StringBuilder
        Dim dt As DataTable

        sb.Append(" SELECT T.ADJL_LOG_ID, ")
        sb.Append("   T.ADJL_TYPE_ID, ")
        sb.Append("   T.ADJL_GP_FILENME, ")
        sb.Append("   T.ADJL_PAYEE_BNKACCNO, ")
        sb.Append("   T.ADJL_WHTNO, ")
        sb.Append("   T.ADJL_TAXID, ")
        sb.Append("   T.ADJL_IDCARD, ")
        sb.Append("   T.ADJL_S_TAXDATE, ")
        sb.Append("   T.ADJL_E_TAXDATE, ")
        sb.Append("   T.ADJL_DESC, ")
        sb.Append("   T.ADJL_S_DATETIME, ")
        sb.Append("   T.ADJL_E_DATETIME, ")
        sb.Append("   T.ADJL_RECORD ")
        sb.Append(" FROM GPS_ADJ_LOG T ")
        sb.Append(" WHERE T.ADJL_TYPE_ID = '" & logTypeId & "'")
        sb.Append(" AND T.ADJL_LOG_ID = (SELECT MAX(T.ADJL_LOG_ID) FROM GPS_ADJ_LOG T WHERE T.ADJL_TYPE_ID = '" & logTypeId & "')")

        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function fnGetAdjMaxId(ByRef oleConn As OleDbConnection, ByVal logTypeId As String) As Integer
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT MAX(T.ADJL_LOG_ID) ADJL_LOG_ID FROM GPS_ADJ_LOG T ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGetAdjMaxId = Ds.Tables(0).Rows(0)("ADJL_LOG_ID")

        Catch ex As Exception
            fnGetAdjMaxId = 0
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fnGetAdjType(ByRef oleConn As OleDbConnection, ByVal logTypeId As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT T.ADJT_TYPE FROM GPS_ADJ_TYPE T WHERE T.ADJT_TYPE_ID = '" & logTypeId & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGetAdjType = Ds.Tables(0).Rows(0)("ADJT_TYPE")

        Catch ex As Exception
            fnGetAdjType = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function startAdjLog(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, _
                                ByVal logId As Integer, ByVal logTypeId As String, ByVal whtNo As String, ByVal taxId As String, _
                                ByVal idCard As String, ByVal taxDateFrom As String, ByVal taxDateTo As String, _
                                ByVal gpFilename As String, ByVal accNo As String, _
                                ByVal logType As String, ByVal gUser As String)
        Dim sb As New StringBuilder
        Dim rec As Integer

        'insert into GPS_ADJ_LOG
        sb.Remove(0, sb.Length)
        sb.Append(" INSERT INTO GPS_ADJ_LOG T (T.ADJL_LOG_ID, ")
        sb.Append("  T.ADJL_TYPE_ID,  T.ADJL_WHTNO, ")
        sb.Append("  T.ADJL_GP_FILENME,  T.ADJL_PAYEE_BNKACCNO,")
        sb.Append("  T.ADJL_TAXID,  T.ADJL_IDCARD, ")
        sb.Append("  T.ADJL_S_TAXDATE,  T.ADJL_E_TAXDATE, ")
        sb.Append("  T.ADJL_DESC,  T.ADJL_S_DATETIME, ")
        sb.Append("  T.ADJL_E_DATETIME,  T.ADJL_RECORD, ")
        sb.Append("  T.CREATEDBY,  T.CREATEDDATE, ")
        sb.Append("  T.UPDATEDBY,  T.UPDATEDDATE) ")
        sb.Append("  VALUES (")
        sb.Append("  " & logId & ", ")
        sb.Append("  '" & logTypeId & "', ")
        sb.Append("  '" & whtNo & "', ")
        sb.Append(" '" & gpFilename & "', ")
        sb.Append(" '" & accNo & "', ")
        sb.Append("  '" & taxId & "', ")
        sb.Append("  '" & idCard & "', ")
        sb.Append("  '" & taxDateFrom & "', ")
        sb.Append("  '" & taxDateTo & "', ")
        sb.Append("  '" & logType & "', ")
        sb.Append("  TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("  TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("  0, ")
        sb.Append("  '" & gUser & "', ")
        sb.Append("  TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("  '" & gUser & "', ")
        sb.Append("  TO_CHAR(SYSDATE,'YYYYMMDD') ) ")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function endAdjLog(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, _
                                ByVal logId As Integer, ByVal logTypeId As String, ByVal recorAmt As Integer, _
                                ByVal gUser As String)
        Dim sb As New StringBuilder
        Dim rec As Integer

        'Update
        sb.Remove(0, sb.Length)
        sb.Append(" UPDATE GPS_ADJ_LOG T SET ")
        sb.Append(" T.UPDATEDBY = '" & gUser & "', ")
        sb.Append("   T.UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD'), ")
        sb.Append("   T.ADJL_E_DATETIME = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI'), ")
        sb.Append("   T.ADJL_RECORD = '" & recorAmt & "' ")
        sb.Append(" WHERE  ")
        sb.Append("   T.ADJL_LOG_ID = " & logId)
        sb.Append(" AND T.ADJL_TYPE_ID = '" & logTypeId & "'")
        rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function updateLogWht(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, ByVal logId As String, _
                              ByVal taxCreateDate As String, ByVal coreSystem As String, ByVal transRef As String, _
                              ByVal gptRefseqno As String, ByVal user As String, ByVal tableName As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim col As String = ""

        If tableName = "GPS_WHT_COMPLETE" Then
            col = "CM"
        ElseIf tableName = "GPS_WHT_CREATION" Then
            col = "CR"
        ElseIf tableName = "GPS_WHT_REJ" Then
            col = "RJ"
        ElseIf tableName = "GPS_WHT_LOAD" Then
            col = "LD"
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_BATCHDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        Else
            col = ""
        End If

        If tableName <> "GPS_WHT_LOAD" Then
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_CREATEDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)

        End If
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function updateLogWhtUPD(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, ByVal logId As String, _
                              ByVal taxCreateDate As String, ByVal coreSystem As String, ByVal transRef As String, _
                              ByVal gptRefseqno As String, ByVal user As String, ByVal tableName As String, ByVal tax_lineno As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim col As String = ""

        If tableName = "GPS_WHT_COMPLETE" Then
            col = "CM"
        ElseIf tableName = "GPS_WHT_CREATION" Then
            col = "CR"
        ElseIf tableName = "GPS_WHT_REJ" Then
            col = "RJ"
        ElseIf tableName = "GPS_WHT_LOAD" Then
            col = "LD"
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_BATCHDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            sb.Append(" AND   TAX" & col & "_LINENO = '" & tax_lineno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        Else
            col = ""
        End If

        If tableName <> "GPS_WHT_LOAD" Then
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_CREATEDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            sb.Append(" AND   TAX" & col & "_LINENO = '" & tax_lineno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)

        End If
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function updateLogPayment(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, ByVal logId As String, _
                              ByVal taxCreateDate As String, ByVal coreSystem As String, ByVal transRef As String, _
                              ByVal gptRefseqno As String, ByVal user As String, ByVal tableName As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim col As String = ""

        If tableName = "GPS_PAYMENT_CREATION" Then
            col = "CR"
        ElseIf tableName = "GPS_PAYMENT_LOAD" Then
            col = "LD"
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    GP" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE GP" & col & "_BATCHDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   GP" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   GP" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   GP" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        ElseIf tableName = "GPS_PAYMENT_REJ" Then
            col = "RJ"
        Else
            col = ""
        End If
        If tableName <> "GPS_PAYMENT_LOAD" Then
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    GP" & col & "_ADJL_LOG_ID = '" & logId & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE GP" & col & "_CREATEDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   GP" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   GP" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   GP" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        End If
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function
End Class
