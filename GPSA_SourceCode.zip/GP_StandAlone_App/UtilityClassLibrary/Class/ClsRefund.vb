Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsRefund
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetBatchNo(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
        sb.Append("AND P.GP_FLAG_PRNRPTS='N'  ")
        sb.Append("GROUP BY L.TREF_BATCH_NO  ")
        sb.Append("ORDER BY L.TREF_BATCH_NO DESC  ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataRpt(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("SELECT L.TREF_BATCHDATE,L.TREF_BATCH_NO,C.PCRE_LETTERNO,P.GP_MERCHN_NO,S.BNKS_BNKSACC_NO,B.BKMST_BNKNAME,P.GP_PAIDDATE, ")
        sb.Append("SELECT L.TREF_BATCHDATE,L.TREF_BATCH_NO,C.PCRE_LETTERNO,P.GP_MERCHN_NO,S.BNKS_BNKSACC_NO,B.BKMST_BNKNAME,P.gp_cdcard_date As GP_PAIDDATE, ")
        sb.Append("P.GP_PAYEE_BNKACCNO,P.GP_POLNO,P.GP_AMOUNT,P.GP_PAYDESC,C.PCRE_AUTH_NAME,C.PCRE_AUTH_POSI ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
        sb.Append("INNER JOIN GPS_PRN_CREDITCARD C ")
        sb.Append("ON L.TREF_BATCH_NO=C.PCRE_BATCH_NO ")
        sb.Append("INNER JOIN GPS_TL_BANKMASTER B ")
        sb.Append("ON P.GP_BNKSCODE_NO=B.BKMST_BNKCODE_NO ")
        sb.Append("INNER JOIN GPS_TL_BANKSERVICE2 S ")
        sb.Append("ON P.GP_BNKSCODE_NO=S.BNKS_BNKSCODE_NO AND P.GP_MERCHN_NO=S.BNKS_MERCHN_NO ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataPrintCreditCard(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,   ")
        sb.Append("A.PCRE_LETTERNO,A.PCRE_AUTH_NAME,A.PCRE_AUTH_POSI,SUM(P.GP_AMOUNT) AMT   ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L    ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE    ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM    ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)    ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T    ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH    ")
        sb.Append("INNER JOIN GPS_PRN_CREDITCARD A  ")
        sb.Append("ON A.PCRE_BATCH_NO=L.TREF_BATCH_NO  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'    ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,A.PCRE_LETTERNO,A.PCRE_AUTH_NAME,A.PCRE_AUTH_POSI ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataPayment_ByBatchNo(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,SUM(P.GP_AMOUNT) AS AMT  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
        'sb.Append("AND P.GP_FLAG_PRNRPTS='N'  ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO  ")
        sb.Append("ORDER BY L.TREF_BATCH_NO DESC  ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataPayment_ByConfrimDate(ByRef oleConn As OleDbConnection, ByVal ConfirmDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,SUM(P.GP_AMOUNT) AS AMT  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")

        If ConfirmDate <> "" Then
            sb.Append("WHERE P.GP_CONFIRMDATE='" & ConfirmDate & "' ")
        End If

        ''P.GP_FLAG_PRNRPTS='N''

        sb.Append("AND P.GP_FLAG_PRNRPTS='Y' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO  ")
        sb.Append("ORDER BY L.TREF_BATCH_NO DESC  ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function INS_GPS_PRN_CREDITCARD(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("INSERT INTO GPS_PRN_CREDITCARD( ")
        sb.Append("PCRE_BATCH_NO,")
        sb.Append("PCRE_LETTERNO,")
        sb.Append("PCRE_AUTH_NAME,")
        sb.Append("PCRE_AUTH_POSI,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & dr("PCRE_BATCH_NO") & "',")
        sb.Append("'" & dr("PCRE_LETTERNO") & "',")
        sb.Append("'" & dr("PCRE_AUTH_NAME") & "',")
        sb.Append("'" & dr("PCRE_AUTH_POSI") & "',")
        sb.Append("'" & dr("CREATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & dr("UPDATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')")
        sb.Append(") ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GPS_PRN_CREDITCARD(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_PRN_CREDITCARD SET ")
        sb.Append("PCRE_AUTH_NAME='" & dr("PCRE_AUTH_NAME") & "',")
        sb.Append("PCRE_AUTH_POSI='" & dr("PCRE_AUTH_POSI") & "',")
        sb.Append("UPDATEDBY='" & dr("CREATEDBY") & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE PCRE_BATCH_NO='" & dr("PCRE_BATCH_NO") & "' ")
      


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GP_FLAG_PRNRPTS_ByBatchNo(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("MERGE INTO GPS_PAYMENT A  ")
        sb.Append("USING      ")
        sb.Append("(     ")
        sb.Append("SELECT P.* ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")

        ' sb.Append("AND P.GP_FLAG_PRNRPTS='N' AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append(") T ON (  ")
        sb.Append("A.GP_SEQNO=T.GP_SEQNO ")
        sb.Append(")      ")
        sb.Append("WHEN MATCHED THEN UPDATE      ")
        sb.Append("SET A.GP_FLAG_PRNRPTS='Y', ")
        sb.Append("A.UPDATEDBY='" & guserlogin & "', ")
        sb.Append("A.UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
