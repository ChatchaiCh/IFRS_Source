Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsCancelCHQReport
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetPaymentType(ByRef oleConn As OleDbConnection, ByVal reporttype As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT PAYT_PAYMTH||':'||PAYT_SUB_PAYMTH AS ID,PAYT_PAYTYPE AS NAME FROM GPS_TL_PAYTYPE  ")
        sb.Append("WHERE (PAYT_PAY_GROUP='SCB_NET' OR PAYT_PAY_GROUP='SCBLIFE_CHQ') ")


        If reporttype = "0" Then
            sb.Append("AND PAYT_PAYMTH||':'||PAYT_SUB_PAYMTH NOT IN ('M:M','C:T') ")
        ElseIf reporttype = "1" Then
            sb.Append("AND PAYT_PAYMTH||':'||PAYT_SUB_PAYMTH NOT IN ('M:M','C:T','C:Q') ")
        End If

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataReport(ByRef oleConn As OleDbConnection, ByVal paymenttype As String, ByVal chqno As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("SELECT P.GP_SEQNO,P.GP_PRINTCHQ_STSDATE,P.GP_CHQNO,P.GP_PAYEE_NAME,P.GP_AMOUNT,P.GP_PAYDESC AS REMARK ")
        sb.Append("SELECT P.GP_SEQNO,P.GP_PAIDDATE AS GP_PRINTCHQ_STSDATE,P.GP_CHQNO,P.GP_PAYEE_NAME,P.GP_AMOUNT,P.GP_PAYDESC AS REMARK ")

        sb.Append(" , CASE R.PAYGE_PAYM_TYP WHEN 'MCP' THEN 'SCB M Cheque' WHEN 'CCP' THEN 'SCB Corporate Cheque' WHEN 'DDP' THEN 'M Draft' ELSE R.PAYGE_PAYM_TYP END PAMENT_TYPE")

        sb.Append(" FROM (GPS_PAYMENT P INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH ")
        sb.Append("AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH)  ")

        sb.Append("LEFT JOIN PAYOUT_GEN_RESULT_NONIL R ON P.GP_CUSTREFNO = TRIM(R.PAYGE_51_CUST_REF)")

        sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH = '" & paymenttype & "' ")

        If chqno <> "" Then
            sb.Append("AND P.GP_CHQNO IN  (" & chqno & ") ")
        End If

        sb.Append("UNION ")
        sb.Append("SELECT T.GP_SEQNO,T.GP_PAIDDATE AS GP_PRINTCHQ_STSDATE,T.GP_CHQNO,T.GP_PAYEE_NAME,T.GP_AMOUNT,'' AS REMARK ")

        sb.Append(", 'SCB Corporate Cheque' PAMENT_TYPE")

        sb.Append(" FROM GPS_GP_OLDSYS_CC_CHQ T WHERE T.GP_PAYMTH||':'||T.GP_SUB_PAYMTH = '" & paymenttype & "' ")

        If chqno <> "" Then
            sb.Append("AND T.GP_CHQNO IN  (" & chqno & ") ")
        End If

        sb.Append("ORDER BY GP_CHQNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataDraftReport(ByRef oleConn As OleDbConnection, ByVal paymenttype As String, ByVal instrument_no As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT P.GP_SEQNO,I.GP_INSTRUMENT_NO,I.GP_PAYEE_NAME,I.GP_AMOUNT, ")
        sb.Append("P.GP_CHQNO,P.GP_PRINTCHQ_STSDATE, ")
        'Fixbug Report 17/03/2015 P.GP_CUSTREFNO AS REFNO to I.GP_REFNO
        sb.Append("I.GP_REFNO AS REFNO, ")

        sb.Append("P.GP_DISTRICT AS BRANCH ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH ")
        sb.Append("AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH)  ")
        sb.Append("INNER JOIN GPS_INSTRUMENT I ")
        sb.Append("ON P.GP_SEQNO=I.GP_SEQNO ")
        sb.Append("WHERE P.GP_PAYMTH||':'||P.GP_SUB_PAYMTH = '" & paymenttype & "' ")

        If instrument_no <> "" Then
            sb.Append("AND I.GP_INSTRUMENT_NO IN  (" & instrument_no & ") ")
        End If

        sb.Append("UNION ")
        sb.Append("SELECT T.GP_SEQNO,T.GP_CHQNO AS GP_INSTRUMENT_NO,T.GP_PAYEE_NAME,T.GP_AMOUNT,T.GP_CHQNO,T.GP_PAIDDATE AS GP_PRINTCHQ_STSDATE,'' AS REFNO,'' AS BRANCH ")
        sb.Append("FROM GPS_GP_OLDSYS_CC_CHQ T WHERE T.GP_PAYMTH||':'||T.GP_SUB_PAYMTH = '" & paymenttype & "' ")

        If instrument_no <> "" Then
            sb.Append("AND T.GP_CHQNO IN  (" & instrument_no & ") ")
        End If

        sb.Append("ORDER BY GP_INSTRUMENT_NO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
End Class
