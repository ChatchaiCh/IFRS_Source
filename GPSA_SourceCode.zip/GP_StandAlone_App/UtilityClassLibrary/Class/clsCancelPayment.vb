﻿Imports System.Data.OleDb
Imports System.Configuration
Imports System.Globalization
Imports System.Threading
Imports System.Text
Imports System.IO

Public Class clsCancelPayment
    Dim clsBusiness As New BusinessLayer
    Public gLastErrMessage As String

    Public Function Check_Export_to_Bank(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("Select nvl(t.gp_flag_exptobank, '-') gp_flag_exptobank")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("       left join generatepayment.gps_payment t")
            sb.Append("         on r.tref_transref = t.gp_transref ")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows(0).Item(0).ToString.Trim <> "-" Then
                If Ds.Tables(0).Rows(0).Item(0).ToString.Trim = "N" Then
                    Check_Export_to_Bank = False
                Else
                    Check_Export_to_Bank = True
                End If
            Else
                Check_Export_to_Bank = False
            End If

        Catch ex As Exception
            Check_Export_to_Bank = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function Check_Confirm_Batch(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("Select nvl(t.gp_flag_exptobank, '-') gp_flag_exptobank, nvl(r.tref_jn_no_p,'-') tref_jn_no_p")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("       left join generatepayment.gps_payment t")
            sb.Append("         on r.tref_transref = t.gp_transref ")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows(0).Item(1).ToString.Trim <> "-" Then
                Check_Confirm_Batch = True
                'xxCheck_Confirm_Batch = True
            Else
                Check_Confirm_Batch = False
            End If

        Catch ex As Exception
            Check_Confirm_Batch = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function Check_Confirm_Batch_NonPay(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("Select nvl(t.tax_whtno, '-') gp_flag_exptobank")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("       left join generatepayment.gps_wht t")
            sb.Append("         on r.tref_transref = t.tax_transref ")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows(0).Item(0).ToString.Trim <> "-" Then
                Check_Confirm_Batch_NonPay = True
                'xxCheck_Confirm_Batch = True
            Else
                Check_Confirm_Batch_NonPay = False
            End If

        Catch ex As Exception
            Check_Confirm_Batch_NonPay = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function Check_Non_Pay(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select nvl(r.tref_paycretyp_id, '-') tref_paycretyp_id")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows(0).Item(0).ToString.Trim = "-" Then
                Check_Non_Pay = False
            Else
                Check_Non_Pay = False
                If Ds.Tables(0).Rows(0).Item(0).ToString.Trim = "006" Then
                    Check_Non_Pay = True
                Else
                    Check_Non_Pay = False
                End If
            End If

        Catch ex As Exception
            Check_Non_Pay = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function Check_Payment_Approved(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select nvl(r.tref_approvedby, '-') gpcr_approvedby")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows(0).Item(0).ToString.Trim <> "-" Then
                Check_Payment_Approved = True
            Else
                Check_Payment_Approved = False
            End If

        Catch ex As Exception
            Check_Payment_Approved = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function Check_WHT_NON_PAY_Approved(ByRef oleConn As OleDbConnection, ByVal strJnHold As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select nvl(r.tref_approvedby, '-') gpcr_approvedby")
            sb.Append("  from generatepayment.gps_transref_rel r")
            sb.Append("       left join generatepayment.gps_wht_creation t")
            sb.Append("         on r.tref_transref = t.taxcr_transref ")
            sb.Append("            where(1 = 1)")
            sb.Append("   and r.tref_core_system = 'ACC'")
            sb.Append("   and r.tref_paycretyp_id = '006'")
            sb.Append("   and r.tref_jn_hold = '" & strJnHold & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows.Count = 0 Then
                Check_WHT_NON_PAY_Approved = False
            Else
                If Ds.Tables(0).Rows(0).Item(0).ToString.Trim <> "-" Then
                    Check_WHT_NON_PAY_Approved = True
                Else
                    Check_WHT_NON_PAY_Approved = False
                End If
            End If

        Catch ex As Exception
            Check_WHT_NON_PAY_Approved = False
            gLastErrMessage = ex.ToString
        End Try
    End Function

End Class
