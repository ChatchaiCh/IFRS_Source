﻿Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsValidateManualCloseBatch
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Public Function fValidateNetAmountNotMatch(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("Select A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, A.No_Record, A.gp_p_amount, B.gl_p_amount  ")
            sb.Append("From (Select T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF, count(T.GP_GPTREF_SEQNO) As No_Record, sum(T.GP_AMOUNT) As gp_p_amount   ")
            sb.Append("From GPS_TMP_PAYMENT T  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("Where T.GP_BATCHTYPE='M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("Group by T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF ")
            sb.Append(") A Left join  ")
            sb.Append("(Select gl1.GLCR_CREATEDATE, gl1.GLCR_CORE_SYSTEM, gl1.GLCR_TRANSREF, sum(gl1.GLCR_AMOUNT) as gl_p_amount   ")
            sb.Append("From gps_gl_creation gl1 inner join glm_account_setup gl2 on gl1.GLCR_S_ACCOUNT=gl2.ACNT_S_CODE and  ")
            sb.Append("gl2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("Where gl1.GLCR_APPROVEDDATE='" & batchdate & "' and gl1.GLCR_DRCR='C' and gl1.GLCR_S_TT_TR='00000000'  ")
            sb.Append("and gl1.GLCR_APPROVEDBY is not null and gl1.GLCR_FLAG_BATCH='N' and gl1.GLCR_CORE_SYSTEM<>'PP'  ")
            sb.Append("Group by gl1.GLCR_CREATEDATE, gl1.GLCR_CORE_SYSTEM, gl1.GLCR_TRANSREF) B ON A.GP_CREATEDATE=B.GLCR_CREATEDATE and   ")
            sb.Append("A.GP_CORE_SYSTEM=B.GLCR_CORE_SYSTEM and  ")
            sb.Append("A.GP_TRANSREF=B.GLCR_TRANSREF  ")
            sb.Append("Where A.gp_p_amount<>B.gl_p_amount ")

            
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateNetAmountNotMatch = Ds.Tables(0)

        Catch ex As Exception
            fValidateNetAmountNotMatch = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateNetAmountNotMatch_NORMAL(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("Select A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, A.No_Record, A.gp_p_amount, B.gl_p_amount  ")
            sb.Append("From (Select T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF, count(T.GP_GPTREF_SEQNO) As No_Record, sum(T.GP_AMOUNT) As gp_p_amount   ")
            sb.Append("From GPS_TMP_PAYMENT T  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("Where T.GP_BATCHTYPE<>'M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("Group by T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF ")
            sb.Append(") A Left join  ")
            sb.Append("(Select gl1.GLCR_CREATEDATE, gl1.GLCR_CORE_SYSTEM, gl1.GLCR_TRANSREF, sum(gl1.GLCR_AMOUNT) as gl_p_amount   ")
            sb.Append("From gps_gl_creation gl1 inner join glm_account_setup gl2 on gl1.GLCR_S_ACCOUNT=gl2.ACNT_S_CODE and  ")
            sb.Append("gl2.ACNT_FLAG_ACNTPAY='Y'  ")
            sb.Append("Where gl1.GLCR_APPROVEDDATE='" & batchdate & "' and gl1.GLCR_DRCR='C' and gl1.GLCR_S_TT_TR='00000000'  ")
            sb.Append("and gl1.GLCR_APPROVEDBY is not null and gl1.GLCR_FLAG_BATCH='N' and gl1.GLCR_CORE_SYSTEM<>'PP'  ")
            sb.Append("Group by gl1.GLCR_CREATEDATE, gl1.GLCR_CORE_SYSTEM, gl1.GLCR_TRANSREF) B ON A.GP_CREATEDATE=B.GLCR_CREATEDATE and   ")
            sb.Append("A.GP_CORE_SYSTEM=B.GLCR_CORE_SYSTEM and  ")
            sb.Append("A.GP_TRANSREF=B.GLCR_TRANSREF  ")
            sb.Append("Where A.gp_p_amount<>B.gl_p_amount ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateNetAmountNotMatch_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateNetAmountNotMatch_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePaidDateNotMatch(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            'sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.NO_RECORD,A.GP_PAIDDATE,B.GLCR_DUEDATE,C.TAX_TAXDATE ")
            'sb.Append("FROM (SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_PAIDDATE,COUNT(GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_BATCHTYPE = 'A'AND GP_CORE_SYSTEM <> 'PP' AND GP_FLAG_VALIDATE = 'COMPLETE' ")
            'sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, GP_PAIDDATE) A ")
            'sb.Append("LEFT JOIN (SELECT GL1.GLCR_CREATEDATE,GL1.GLCR_CORE_SYSTEM,GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE ")
            'sb.Append("FROM GPS_GL_CREATION GL1 ")
            'sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2 ")
            'sb.Append("ON GL1.GLCR_S_ACCOUNT = GL2.ACNT_S_CODE ")
            'sb.Append("AND GL2.ACNT_FLAG_ACNTPAY = 'Y' ")
            'sb.Append("WHERE GL1.GLCR_APPROVEDDATE < '" & batchdate & "'AND GL1.GLCR_DRCR = 'C' AND GL1.GLCR_S_TT_TR = '00000000' AND GL1.GLCR_APPROVEDBY IS NOT NULL ")
            'sb.Append("AND GL1.GLCR_FLAG_BATCH = 'N' AND GL1.GLCR_CORE_SYSTEM <> 'PP' ")
            'sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE) B ")
            'sb.Append("ON A.GP_CREATEDATE = B.GLCR_CREATEDATE ")
            'sb.Append("AND A.GP_CORE_SYSTEM = B.GLCR_CORE_SYSTEM ")
            'sb.Append("AND A.GP_TRANSREF = B.GLCR_TRANSREF ")
            'sb.Append("LEFT JOIN  ")
            'sb.Append("(SELECT TAX_CREATEDATE,TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE ")
            'sb.Append("FROM GPS_TMP_WHT ")
            'sb.Append("WHERE TAX_BATCHDATE = '" & batchdate & "' ")
            'sb.Append("AND TAX_CORE_SYSTEM <> 'PP' ")
            'sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE) C ")
            'sb.Append("ON A.GP_CREATEDATE = C.TAX_CREATEDATE ")
            'sb.Append("AND A.GP_CORE_SYSTEM = C.TAX_CORE_SYSTEM ")
            'sb.Append("AND A.GP_TRANSREF = C.TAX_TRANSREF ")
            'sb.Append("WHERE (A.GP_PAIDDATE <> B.GLCR_DUEDATE) ")
            'sb.Append("OR (C.TAX_TAXDATE IS NOT NULL AND A.GP_PAIDDATE <> C.TAX_TAXDATE) ")

            sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.NO_RECORD,A.GP_PAIDDATE,B.GLCR_DUEDATE,C.TAX_TAXDATE  ")
            sb.Append("FROM ( ")
            sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_PAIDDATE,COUNT(GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT T  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("Where T.GP_BATCHTYPE='M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, GP_PAIDDATE            ")
            sb.Append(") A  ")
            sb.Append("LEFT JOIN (SELECT GL1.GLCR_CREATEDATE,GL1.GLCR_CORE_SYSTEM,GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE  ")
            sb.Append("FROM GPS_GL_CREATION GL1  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON GL1.GLCR_S_ACCOUNT = GL2.ACNT_S_CODE  ")
            sb.Append("AND GL2.ACNT_FLAG_ACNTPAY = 'Y'  ")
            sb.Append("WHERE GL1.GLCR_APPROVEDDATE = '" & batchdate & "' AND GL1.GLCR_DRCR = 'C' AND GL1.GLCR_S_TT_TR = '00000000' AND GL1.GLCR_APPROVEDBY IS NOT NULL  ")
            sb.Append("AND GL1.GLCR_FLAG_BATCH = 'N' AND GL1.GLCR_CORE_SYSTEM <> 'PP'  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE) B  ")
            sb.Append("ON A.GP_CREATEDATE = B.GLCR_CREATEDATE  ")
            sb.Append("AND A.GP_CORE_SYSTEM = B.GLCR_CORE_SYSTEM  ")
            sb.Append("AND A.GP_TRANSREF = B.GLCR_TRANSREF  ")
            sb.Append("LEFT JOIN   ")
            sb.Append("(SELECT TAX_CREATEDATE,TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE  ")
            sb.Append("FROM GPS_TMP_WHT  ")
            sb.Append("WHERE TAX_BATCHDATE = '" & batchdate & "'  ")
            sb.Append("AND TAX_CORE_SYSTEM <> 'PP'  ")
            sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE) C  ")
            sb.Append("ON A.GP_CREATEDATE = C.TAX_CREATEDATE  ")
            sb.Append("AND A.GP_CORE_SYSTEM = C.TAX_CORE_SYSTEM  ")
            sb.Append("AND A.GP_TRANSREF = C.TAX_TRANSREF  ")
            sb.Append("WHERE (A.GP_PAIDDATE <> B.GLCR_DUEDATE)  ")
            sb.Append("OR (C.TAX_TAXDATE IS NOT NULL AND A.GP_PAIDDATE <> C.TAX_TAXDATE) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidDateNotMatch = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidDateNotMatch = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePaidDateNotMatch_NORMAL(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            'sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.NO_RECORD,A.GP_PAIDDATE,B.GLCR_DUEDATE,C.TAX_TAXDATE ")
            'sb.Append("FROM (SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_PAIDDATE,COUNT(GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT WHERE GP_BATCHTYPE = 'A'AND GP_CORE_SYSTEM <> 'PP' AND GP_FLAG_VALIDATE = 'COMPLETE' ")
            'sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, GP_PAIDDATE) A ")
            'sb.Append("LEFT JOIN (SELECT GL1.GLCR_CREATEDATE,GL1.GLCR_CORE_SYSTEM,GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE ")
            'sb.Append("FROM GPS_GL_CREATION GL1 ")
            'sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2 ")
            'sb.Append("ON GL1.GLCR_S_ACCOUNT = GL2.ACNT_S_CODE ")
            'sb.Append("AND GL2.ACNT_FLAG_ACNTPAY = 'Y' ")
            'sb.Append("WHERE GL1.GLCR_APPROVEDDATE < '" & batchdate & "'AND GL1.GLCR_DRCR = 'C' AND GL1.GLCR_S_TT_TR = '00000000' AND GL1.GLCR_APPROVEDBY IS NOT NULL ")
            'sb.Append("AND GL1.GLCR_FLAG_BATCH = 'N' AND GL1.GLCR_CORE_SYSTEM <> 'PP' ")
            'sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE) B ")
            'sb.Append("ON A.GP_CREATEDATE = B.GLCR_CREATEDATE ")
            'sb.Append("AND A.GP_CORE_SYSTEM = B.GLCR_CORE_SYSTEM ")
            'sb.Append("AND A.GP_TRANSREF = B.GLCR_TRANSREF ")
            'sb.Append("LEFT JOIN  ")
            'sb.Append("(SELECT TAX_CREATEDATE,TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE ")
            'sb.Append("FROM GPS_TMP_WHT ")
            'sb.Append("WHERE TAX_BATCHDATE = '" & batchdate & "' ")
            'sb.Append("AND TAX_CORE_SYSTEM <> 'PP' ")
            'sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE) C ")
            'sb.Append("ON A.GP_CREATEDATE = C.TAX_CREATEDATE ")
            'sb.Append("AND A.GP_CORE_SYSTEM = C.TAX_CORE_SYSTEM ")
            'sb.Append("AND A.GP_TRANSREF = C.TAX_TRANSREF ")
            'sb.Append("WHERE (A.GP_PAIDDATE <> B.GLCR_DUEDATE) ")
            'sb.Append("OR (C.TAX_TAXDATE IS NOT NULL AND A.GP_PAIDDATE <> C.TAX_TAXDATE) ")

            sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.NO_RECORD,A.GP_PAIDDATE,B.GLCR_DUEDATE,C.TAX_TAXDATE  ")
            sb.Append("FROM ( ")
            sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_PAIDDATE,COUNT(GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT T  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("Where T.GP_BATCHTYPE<>'M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, GP_PAIDDATE            ")
            sb.Append(") A  ")
            sb.Append("LEFT JOIN (SELECT GL1.GLCR_CREATEDATE,GL1.GLCR_CORE_SYSTEM,GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE  ")
            sb.Append("FROM GPS_GL_CREATION GL1  ")
            sb.Append("INNER JOIN GLM_ACCOUNT_SETUP GL2  ")
            sb.Append("ON GL1.GLCR_S_ACCOUNT = GL2.ACNT_S_CODE  ")
            sb.Append("AND GL2.ACNT_FLAG_ACNTPAY = 'Y'  ")
            sb.Append("WHERE GL1.GLCR_APPROVEDDATE = '" & batchdate & "' AND GL1.GLCR_DRCR = 'C' AND GL1.GLCR_S_TT_TR = '00000000' AND GL1.GLCR_APPROVEDBY IS NOT NULL  ")
            sb.Append("AND GL1.GLCR_FLAG_BATCH = 'N' AND GL1.GLCR_CORE_SYSTEM <> 'PP'  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF,GL1.GLCR_DUEDATE) B  ")
            sb.Append("ON A.GP_CREATEDATE = B.GLCR_CREATEDATE  ")
            sb.Append("AND A.GP_CORE_SYSTEM = B.GLCR_CORE_SYSTEM  ")
            sb.Append("AND A.GP_TRANSREF = B.GLCR_TRANSREF  ")
            sb.Append("LEFT JOIN   ")
            sb.Append("(SELECT TAX_CREATEDATE,TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE  ")
            sb.Append("FROM GPS_TMP_WHT  ")
            sb.Append("WHERE TAX_BATCHDATE = '" & batchdate & "'  ")
            sb.Append("AND TAX_CORE_SYSTEM <> 'PP'  ")
            sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM,TAX_TRANSREF,TAX_TAXDATE) C  ")
            sb.Append("ON A.GP_CREATEDATE = C.TAX_CREATEDATE  ")
            sb.Append("AND A.GP_CORE_SYSTEM = C.TAX_CORE_SYSTEM  ")
            sb.Append("AND A.GP_TRANSREF = C.TAX_TRANSREF  ")
            sb.Append("WHERE (A.GP_PAIDDATE <> B.GLCR_DUEDATE)  ")
            sb.Append("OR (C.TAX_TAXDATE IS NOT NULL AND A.GP_PAIDDATE <> C.TAX_TAXDATE) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidDateNotMatch_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidDateNotMatch_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateDuplicateTransRef_1(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, COUNT(GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT  ")
            'sb.Append("WHERE GP_BATCHTYPE='M' AND GP_FLAG_VALIDATE='COMPLETE' ")
            'sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF ")
            sb.Append("SELECT T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF, COUNT(T.GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("Where T.GP_BATCHTYPE='M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateDuplicateTransRef_1 = Ds.Tables(0)

        Catch ex As Exception
            fValidateDuplicateTransRef_1 = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateDuplicateTransRef_1_NORMAL(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF, COUNT(GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT  ")
            'sb.Append("WHERE GP_BATCHTYPE='M' AND GP_FLAG_VALIDATE='COMPLETE' ")
            'sb.Append("GROUP BY GP_CREATEDATE, GP_CORE_SYSTEM, GP_TRANSREF ")
            sb.Append("SELECT T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF, COUNT(T.GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT T INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON T.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND T.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND T.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("Where T.GP_BATCHTYPE<>'M' and T.GP_CORE_SYSTEM<>'PP'   ")
            sb.Append("and T.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY T.GP_CREATEDATE, T.GP_CORE_SYSTEM, T.GP_TRANSREF ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateDuplicateTransRef_1_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateDuplicateTransRef_1_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateDuplicateTransRef_2(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT TREF_TRANSREF FROM GPS_TRANSREF_REL WHERE TREF_TRANSREF='" & transref & "' AND (TREF_CREATEDATE <> '" & create_date & "' OR TREF_CORE_SYSTEM<>'" & core_system & "') ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateDuplicateTransRef_2 = Ds.Tables(0)

        Catch ex As Exception
            fValidateDuplicateTransRef_2 = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateWHTAmountNotMatch(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CASE WHEN A.TAX_CREATEDATE IS NULL THEN B.GLCR_CREATEDATE ELSE A.TAX_CREATEDATE END AS GP_CREATEDATE,   ")
            sb.Append("CASE WHEN A.TAX_CORE_SYSTEM IS NULL THEN B.GLCR_CORE_SYSTEM ELSE A.TAX_CORE_SYSTEM END AS GP_CORE_SYSTEM,   ")
            sb.Append("CASE WHEN A.TAX_TRANSREF IS NULL THEN B.GLCR_TRANSREF ELSE A.TAX_TRANSREF END AS GP_TRANSREF,  ")
            sb.Append("A.NO_RECORD, A.TAX_AMOUNT, B.GL_TAX_AMOUNT  ")
            sb.Append("FROM (SELECT TAX_CREATEDATE, TAX_CORE_SYSTEM, TAX_TRANSREF, COUNT(TAX_LINENO) AS NO_RECORD, SUM(TAX_TAX_AMT) AS TAX_AMOUNT   ")
            sb.Append("FROM GPS_TMP_WHT  ")
            sb.Append("WHERE TAX_BATCHDATE='" & batchdate & "'  AND TAX_CORE_SYSTEM<>'PP' AND TAX_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM, TAX_TRANSREF            ")
            sb.Append(") A FULL JOIN  ")
            sb.Append("(SELECT GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF, SUM(GL1.GLCR_AMOUNT) AS GL_TAX_AMOUNT  ")
            sb.Append("FROM GPS_GL_CREATION GL1  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON GL1.GLCR_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND GL1.GLCR_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND GL1.GLCR_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE GL1.GLCR_APPROVEDDATE='" & batchdate & "'  AND GL1.GLCR_DRCR='C'   ")
            'sb.Append("AND (GL1.GLCR_S_TT_TR<>'00000000' AND SUBSTR(GL1.GLCR_S_TT_TR,1,2)<>'91')  ")
            sb.Append("AND SUBSTR(GL1.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")
            sb.Append("AND GL1.GLCR_APPROVEDBY  IS NOT NULL AND GL1.GLCR_FLAG_BATCH='N' AND GL1.GLCR_CORE_SYSTEM<>'PP'  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF) B   ")
            sb.Append("ON A.TAX_CREATEDATE =B.GLCR_CREATEDATE AND   ")
            sb.Append("A.TAX_CORE_SYSTEM =B.GLCR_CORE_SYSTEM AND  ")
            sb.Append("A.TAX_TRANSREF =B.GLCR_TRANSREF  ")
            sb.Append("WHERE NVL(A.TAX_AMOUNT,0) <> NVL(B.GL_TAX_AMOUNT,0)  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateWHTAmountNotMatch = Ds.Tables(0)

        Catch ex As Exception
            fValidateWHTAmountNotMatch = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateWHTAmountNotMatch_NORMAL(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CASE WHEN A.TAX_CREATEDATE IS NULL THEN B.GLCR_CREATEDATE ELSE A.TAX_CREATEDATE END AS GP_CREATEDATE,   ")
            sb.Append("CASE WHEN A.TAX_CORE_SYSTEM IS NULL THEN B.GLCR_CORE_SYSTEM ELSE A.TAX_CORE_SYSTEM END AS GP_CORE_SYSTEM,   ")
            sb.Append("CASE WHEN A.TAX_TRANSREF IS NULL THEN B.GLCR_TRANSREF ELSE A.TAX_TRANSREF END AS GP_TRANSREF,  ")
            sb.Append("A.NO_RECORD, A.TAX_AMOUNT, B.GL_TAX_AMOUNT  ")
            sb.Append("FROM (SELECT TAX_CREATEDATE, TAX_CORE_SYSTEM, TAX_TRANSREF, COUNT(TAX_LINENO) AS NO_RECORD, SUM(TAX_TAX_AMT) AS TAX_AMOUNT   ")
            sb.Append("FROM GPS_TMP_WHT  ")
            sb.Append("WHERE TAX_BATCHDATE='" & batchdate & "'  AND TAX_CORE_SYSTEM<>'PP' AND TAX_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("GROUP BY TAX_CREATEDATE, TAX_CORE_SYSTEM, TAX_TRANSREF            ")
            sb.Append(") A FULL JOIN  ")
            sb.Append("(SELECT GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF, SUM(GL1.GLCR_AMOUNT) AS GL_TAX_AMOUNT  ")
            sb.Append("FROM GPS_GL_CREATION GL1  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON GL1.GLCR_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND GL1.GLCR_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND GL1.GLCR_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE GL1.GLCR_APPROVEDDATE='" & batchdate & "'  AND GL1.GLCR_DRCR='C'   ")
            'sb.Append("AND (GL1.GLCR_S_TT_TR<>'00000000' AND SUBSTR(GL1.GLCR_S_TT_TR,1,2)<>'91')  ")
            sb.Append("AND SUBSTR(GL1.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")
            sb.Append("AND GL1.GLCR_APPROVEDBY  IS NOT NULL AND GL1.GLCR_FLAG_BATCH='N' AND GL1.GLCR_CORE_SYSTEM<>'PP'  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF) B   ")
            sb.Append("ON A.TAX_CREATEDATE =B.GLCR_CREATEDATE AND   ")
            sb.Append("A.TAX_CORE_SYSTEM =B.GLCR_CORE_SYSTEM AND  ")
            sb.Append("A.TAX_TRANSREF =B.GLCR_TRANSREF  ")
            sb.Append("WHERE NVL(A.TAX_AMOUNT,0) <> NVL(B.GL_TAX_AMOUNT,0)  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateWHTAmountNotMatch_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateWHTAmountNotMatch_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateTransrefError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE, COUNT(A.GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT A LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE  ")
            'sb.Append("FROM GPS_TL_DATASOURCE ")
            'sb.Append("GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE) B ON A.GP_CORE_SYSTEM=B.DTS_CORE_SYSTEM AND ")
            'sb.Append("SUBSTR(A.GP_TRANSREF,1,3)=B.DTS_DTSOURCE ")
            'sb.Append("WHERE A.GP_BATCHTYPE='A' AND A.GP_FLAG_VALIDATE='COMPLETE' AND (LENGTH(A.GP_TRANSREF)>15 OR B.DTS_DTSOURCE IS NULL) ")
            'sb.Append("GROUP BY A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE ")

            sb.Append("SELECT A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE, COUNT(A.GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT A INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON A.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND A.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND A.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE   ")
            sb.Append("FROM GPS_TL_DATASOURCE  ")
            sb.Append("GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE) B ON A.GP_CORE_SYSTEM=B.DTS_CORE_SYSTEM  ")
            sb.Append("AND SUBSTR(A.GP_TRANSREF,1,3)=B.DTS_DTSOURCE  ")
            sb.Append("WHERE A.GP_BATCHTYPE='M' AND A.GP_FLAG_VALIDATE='COMPLETE' AND (LENGTH(A.GP_TRANSREF)>15 OR B.DTS_DTSOURCE IS NULL)  ")
            sb.Append("GROUP BY A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateTransrefError = Ds.Tables(0)

        Catch ex As Exception
            fValidateTransrefError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateTransrefError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE, COUNT(A.GP_GPTREF_SEQNO) AS NO_RECORD ")
            'sb.Append("FROM GPS_TMP_PAYMENT A LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE  ")
            'sb.Append("FROM GPS_TL_DATASOURCE ")
            'sb.Append("GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE) B ON A.GP_CORE_SYSTEM=B.DTS_CORE_SYSTEM AND ")
            'sb.Append("SUBSTR(A.GP_TRANSREF,1,3)=B.DTS_DTSOURCE ")
            'sb.Append("WHERE A.GP_BATCHTYPE='A' AND A.GP_FLAG_VALIDATE='COMPLETE' AND (LENGTH(A.GP_TRANSREF)>15 OR B.DTS_DTSOURCE IS NULL) ")
            'sb.Append("GROUP BY A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE ")

            sb.Append("SELECT A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE, COUNT(A.GP_GPTREF_SEQNO) AS NO_RECORD  ")
            sb.Append("FROM GPS_TMP_PAYMENT A INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON A.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND A.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND A.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE   ")
            sb.Append("FROM GPS_TL_DATASOURCE  ")
            sb.Append("GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE) B ON A.GP_CORE_SYSTEM=B.DTS_CORE_SYSTEM  ")
            sb.Append("AND SUBSTR(A.GP_TRANSREF,1,3)=B.DTS_DTSOURCE  ")
            sb.Append("WHERE A.GP_BATCHTYPE<>'M' AND A.GP_FLAG_VALIDATE='COMPLETE' AND (LENGTH(A.GP_TRANSREF)>15 OR B.DTS_DTSOURCE IS NULL)  ")
            sb.Append("GROUP BY A.GP_CREATEDATE, A.GP_CORE_SYSTEM, A.GP_TRANSREF, B.DTS_DTSOURCE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateTransrefError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateTransrefError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatSpecialCharacterError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO, GP_PAYEE_NAME, GP_ADDRESS1, GP_DISTRICT, ")
            'sb.Append("GP_PROVINCE, GP_PAYEE_BNKACCNME FROM GPS_TMP_PAYMENT WHERE GP_BATCHTYPE='A'  ")
            'sb.Append("AND GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.GP_GPTREF_SEQNO, A.GP_PAYEE_NAME, A.GP_ADDRESS1, A.GP_DISTRICT,  ")
            sb.Append("A.GP_PROVINCE, A.GP_PAYEE_BNKACCNME  ")
            sb.Append("FROM GPS_TMP_PAYMENT A INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON A.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND A.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND A.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE A.GP_BATCHTYPE='M'   ")
            sb.Append("AND A.GP_FLAG_VALIDATE='COMPLETE' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatSpecialCharacterError = Ds.Tables(0)

        Catch ex As Exception
            fValidatSpecialCharacterError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatSpecialCharacterError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO, GP_PAYEE_NAME, GP_ADDRESS1, GP_DISTRICT, ")
            'sb.Append("GP_PROVINCE, GP_PAYEE_BNKACCNME FROM GPS_TMP_PAYMENT WHERE GP_BATCHTYPE='A'  ")
            'sb.Append("AND GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT A.GP_CREATEDATE,A.GP_CORE_SYSTEM,A.GP_TRANSREF,A.GP_GPTREF_SEQNO, A.GP_PAYEE_NAME, A.GP_ADDRESS1, A.GP_DISTRICT,  ")
            sb.Append("A.GP_PROVINCE, A.GP_PAYEE_BNKACCNME  ")
            sb.Append("FROM GPS_TMP_PAYMENT A INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON A.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND A.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND A.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE A.GP_BATCHTYPE<>'M'   ")
            sb.Append("AND A.GP_FLAG_VALIDATE='COMPLETE' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatSpecialCharacterError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatSpecialCharacterError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePaidDateError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAIDDATE,T.PAYT_PAY_GROUP ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TL_PAYTYPE T ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAIDDATE,T.PAYT_PAY_GROUP  ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidDateError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidDateError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePaidDateError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAIDDATE,T.PAYT_PAY_GROUP ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TL_PAYTYPE T ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAIDDATE,T.PAYT_PAY_GROUP  ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidDateError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidDateError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GetSpecialCharacter(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT SPE_CHAR FROM GPS_TL_SPECIALCHAR ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetSpecialCharacter = Ds.Tables(0)

        Catch ex As Exception
            GetSpecialCharacter = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Function LookUpHoliday_SCBLIFE(ByRef oleConn As OleDbConnection, ByVal d_start As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) AS CHK FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE = '" & d_start & "'  AND HLDS_COMPANY_CODE='SCBLIFE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)("CHK") > 0 Then
                Return True
            Else
                Return False
            End If

        Else
            Return False
        End If

    End Function
    Function LookUpHoliday_SCB(ByRef oleConn As OleDbConnection, ByVal d_start As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) AS CHK FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE = '" & d_start & "'  AND HLDS_COMPANY_CODE='SCB' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)("CHK") > 0 Then
                Return True
            Else
                Return False
            End If

        Else
            Return False
        End If

    End Function
    Public Function fValidatePaidAmountError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO,GP_AMOUNT ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P ")
            'sb.Append("WHERE GP_BATCHTYPE='A'  ")
            'sb.Append("AND GP_FLAG_VALIDATE='COMPLETE' ")
            'sb.Append("AND GP_AMOUNT IS NULL OR GP_AMOUNT <=0  ")

            sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO,GP_AMOUNT  ")
            sb.Append("FROM GPS_TMP_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE GP_BATCHTYPE='M'   ")
            sb.Append("AND GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND GP_AMOUNT IS NULL OR GP_AMOUNT <=0  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidAmountError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidAmountError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePaidAmountError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO,GP_AMOUNT ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P ")
            'sb.Append("WHERE GP_BATCHTYPE='A'  ")
            'sb.Append("AND GP_FLAG_VALIDATE='COMPLETE' ")
            'sb.Append("AND GP_AMOUNT IS NULL OR GP_AMOUNT <=0  ")

            sb.Append("SELECT GP_CREATEDATE,GP_CORE_SYSTEM,GP_TRANSREF,GP_GPTREF_SEQNO,GP_AMOUNT  ")
            sb.Append("FROM GPS_TMP_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE GP_BATCHTYPE<>'M'   ")
            sb.Append("AND GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND GP_AMOUNT IS NULL OR GP_AMOUNT <=0  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidAmountError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidAmountError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateBankCodeError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_BNKCODE_NO,T.PAYT_PAY_GROUP  ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TL_PAYTYPE T  ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_BNKCODE_NO,T.PAYT_PAY_GROUP   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")



            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankCodeError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankCodeError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateBankCodeError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_BNKCODE_NO,T.PAYT_PAY_GROUP  ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TL_PAYTYPE T  ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_BNKCODE_NO,T.PAYT_PAY_GROUP   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")



            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankCodeError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankCodeError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Function CHK_BKMST_BNKCODE(ByRef oleConn As OleDbConnection, ByVal bnkcode_no As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE FROM GPS_TL_BANKMASTER WHERE BKMST_BNKCODE_NO='" & bnkcode_no & "' AND BKMST_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function CHK_BNKS_BNKSCODE_NO(ByRef oleConn As OleDbConnection, ByVal pay_grp As String, ByVal bnkcode_no As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("select * from GPS_TL_BANKSERVICE1 WHERE BNKS_PAY_GROUP ='" & pay_grp & "' AND BNKS_BNKSCODE_NO='" & bnkcode_no & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Public Function fValidateBankAccountError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

           
            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNO   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("LEFT JOIN GPS_TL_BANKMASTER B ")
            sb.Append("ON P.GP_BNKCODE_NO=B.BKMST_BNKCODE_NO ")
            sb.Append("AND B.BKMST_STATUS='ACTIVE' ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'  ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND (((P.GP_PAYMTH='M' AND  GP_PAYEE_BNKACCNO IS NULL)  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND  GP_PAYEE_BNKACCNO ='')  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND DECODE((REPLACE( TRANSLATE( TRIM(GP_PAYEE_BNKACCNO), '0123456789','00000000000'),'0',NULL)), NULL, 'NUMBER','CHAR') = 'CHAR' ) )  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='C' AND LENGTH(GP_PAYEE_BNKACCNO) <> 16 ))  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND B.BKMST_BNKCODE_NO IS NULL) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateBankAccountError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNO   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("LEFT JOIN GPS_TL_BANKMASTER B ")
            sb.Append("ON P.GP_BNKCODE_NO=B.BKMST_BNKCODE_NO ")
            sb.Append("AND B.BKMST_STATUS='ACTIVE' ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'  ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND (((P.GP_PAYMTH='M' AND  GP_PAYEE_BNKACCNO IS NULL)  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND  GP_PAYEE_BNKACCNO ='')  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND DECODE((REPLACE( TRANSLATE( TRIM(GP_PAYEE_BNKACCNO), '0123456789','00000000000'),'0',NULL)), NULL, 'NUMBER','CHAR') = 'CHAR' ) )  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND P.GP_SUB_PAYMTH='C' AND LENGTH(GP_PAYEE_BNKACCNO) <> 16 ))  ")
            sb.Append("OR (P.GP_PAYMTH='M' AND B.BKMST_BNKCODE_NO IS NULL) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateBankAccountNameError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNME  ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A' ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")
            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNME   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'  ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountNameError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountNameError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateBankAccountNameError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNME  ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A' ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")
            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_BNKACCNME   ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'  ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountNameError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountNameError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePayeeNameError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME   ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeNameError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeNameError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePayeeNameError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME   ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT  P   INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeNameError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeNameError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePayeeLengthFieldError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME   ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            'sb.Append("AND ((P.GP_PAYMTH='C' OR P.GP_PAYMTH='D') AND LENGTH(P.GP_PAYEE_NAME) > 100) ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            sb.Append("AND ((P.GP_PAYMTH='C' OR P.GP_PAYMTH='D') AND LENGTH(P.GP_PAYEE_NAME) > 100) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeLengthFieldError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeLengthFieldError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatePayeeLengthFieldError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME   ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            'sb.Append("AND ((P.GP_PAYMTH='C' OR P.GP_PAYMTH='D') AND LENGTH(P.GP_PAYEE_NAME) > 100) ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            sb.Append("AND ((P.GP_PAYMTH='C' OR P.GP_PAYMTH='D') AND LENGTH(P.GP_PAYEE_NAME) > 100) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeLengthFieldError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeLengthFieldError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateAddressError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH, ")
            'sb.Append("P.GP_ADDRESS1||P.GP_DISTRICT||P.GP_PROVINCE AS ADDRESS ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
            sb.Append("P.GP_ADDRESS1||P.GP_DISTRICT||P.GP_PROVINCE AS ADDRESS  ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateAddressError = Ds.Tables(0)

        Catch ex As Exception
            fValidateAddressError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateAddressError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH, ")
            'sb.Append("P.GP_ADDRESS1||P.GP_DISTRICT||P.GP_PROVINCE AS ADDRESS ")
            'sb.Append("FROM GPS_TMP_PAYMENT  P   ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'  ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,  ")
            sb.Append("P.GP_ADDRESS1||P.GP_DISTRICT||P.GP_PROVINCE AS ADDRESS  ")
            sb.Append("FROM GPS_TMP_PAYMENT  P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'   ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateAddressError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateAddressError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateMerchantError(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,B.BNKS_MERCHN_NO    ")
            'sb.Append("FROM (GPS_TMP_PAYMENT P INNER JOIN GPS_TL_PAYTYPE T ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH) ")
            'sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 B ")
            'sb.Append("ON P.GP_MERCHN_NO=B.BNKS_MERCHN_NO AND B.BNKS_STATUS='ACTIVE' ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            'sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD' ")
            'sb.Append("AND BNKS_MERCHN_NO IS NULL ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,B.BNKS_MERCHN_NO     ")
            sb.Append("FROM ((GPS_TMP_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF) ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH) ")
            sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 B  ")
            sb.Append("ON P.GP_MERCHN_NO=B.BNKS_MERCHN_NO AND B.BNKS_STATUS='ACTIVE'  ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003'   ")
            sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
            sb.Append("AND BNKS_MERCHN_NO IS NULL ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateMerchantError = Ds.Tables(0)

        Catch ex As Exception
            fValidateMerchantError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateMerchantError_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,B.BNKS_MERCHN_NO    ")
            'sb.Append("FROM (GPS_TMP_PAYMENT P INNER JOIN GPS_TL_PAYTYPE T ")
            'sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH) ")
            'sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 B ")
            'sb.Append("ON P.GP_MERCHN_NO=B.BNKS_MERCHN_NO AND B.BNKS_STATUS='ACTIVE' ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            'sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD' ")
            'sb.Append("AND BNKS_MERCHN_NO IS NULL ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,B.BNKS_MERCHN_NO     ")
            sb.Append("FROM ((GPS_TMP_PAYMENT P INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF) ")
            sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH) ")
            sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 B  ")
            sb.Append("ON P.GP_MERCHN_NO=B.BNKS_MERCHN_NO AND B.BNKS_STATUS='ACTIVE'  ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'  ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003'   ")
            sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
            sb.Append("AND BNKS_MERCHN_NO IS NULL ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateMerchantError_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateMerchantError_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateNBCancel(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_FLAG_CC    ")
            'sb.Append("FROM GPS_TMP_PAYMENT P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            'sb.Append("AND P.GP_FLAG_CC='Y' AND P.GP_CC_APPROVEDBY IS NOT NULL ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_FLAG_CC     ")
            sb.Append("FROM GPS_TMP_PAYMENT P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'    ")
            sb.Append("AND P.GP_FLAG_CC='Y' AND P.GP_CC_APPROVEDBY IS NOT NULL ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateNBCancel = Ds.Tables(0)

        Catch ex As Exception
            fValidateNBCancel = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidateNBCancel_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_FLAG_CC    ")
            'sb.Append("FROM GPS_TMP_PAYMENT P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")
            'sb.Append("AND P.GP_FLAG_CC='Y' AND P.GP_CC_APPROVEDBY IS NOT NULL ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYMTH,P.GP_SUB_PAYMTH,P.GP_FLAG_CC     ")
            sb.Append("FROM GPS_TMP_PAYMENT P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'    ")
            sb.Append("AND P.GP_FLAG_CC='Y' AND P.GP_CC_APPROVEDBY IS NOT NULL ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateNBCancel_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidateNBCancel_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function UPD_PAYMENT_REJ(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT SET GP_FLAG_VALIDATE='INCOMPLETE', GP_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE GP_CREATEDATE ='" & create_date & "' AND GP_CORE_SYSTEM='" & core_system & "' AND GP_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_PAYMENT_REJ(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String, ByVal seq As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT SET GP_FLAG_VALIDATE='INCOMPLETE', GP_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE GP_CREATEDATE ='" & create_date & "' AND GP_CORE_SYSTEM='" & core_system & "' AND GP_TRANSREF='" & transref & "' and GP_GPTREF_SEQNO ='" & seq & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_WHT_REJ(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_WHT SET TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE TAX_CREATEDATE ='" & create_date & "' AND TAX_CORE_SYSTEM='" & core_system & "' AND TAX_TRANSREF='" & transref & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_WHT_REJ(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String, ByVal seq As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_WHT SET TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE TAX_CREATEDATE ='" & create_date & "' AND TAX_CORE_SYSTEM='" & core_system & "' AND TAX_TRANSREF='" & transref & "' AND TAX_GPTREF_SEQNO ='" & seq & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_SPE_CHAR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal field As String, ByVal spetxt As String, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String, ByVal seq As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT SET " & field & "='" & spetxt & "', GP_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE GP_CREATEDATE ='" & create_date & "' AND GP_CORE_SYSTEM='" & core_system & "' AND GP_TRANSREF='" & transref & "'  and GP_GPTREF_SEQNO ='" & seq & "'")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Function CHECK_WATCHLIST_FOR_REJ(ByRef oleConn As OleDbConnection, ByVal payeename As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME   ")
            'sb.Append("FROM GPS_WATCHLISTS_MA1 W INNER JOIN GPS_TL_WATCHLISTS_TYPE T ")
            'sb.Append("ON W.WLST_SUBTYPE_CODE=T.WLSTT_SUBTYPE ")
            'sb.Append("WHERE W.WLST_REJ_CODE='01'  ")
            'sb.Append("AND W.WLST_SUBTYPE_CODE IN ('BANK', 'FT01', 'FT02') ")
            'sb.Append("AND INSTR('" & payeename & "',W.WLST_CHK_NAME) >0 ")
            'sb.Append("GROUP BY T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME ")

            sb.Append("SELECT WLSTT_TYPE,WLST_SUBTYPE_CODE ,WLST_CHK_NAME  ")
            sb.Append("FROM  ")
            sb.Append("( ")
            sb.Append("SELECT T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE,MAX(WLST_LOADDATE)   ")
            sb.Append("FROM GPS_WATCHLISTS_MA1 W INNER JOIN GPS_TL_WATCHLISTS_TYPE T ")
            sb.Append("ON W.WLST_SUBTYPE_CODE=T.WLSTT_SUBTYPE ")
            sb.Append("WHERE W.WLST_SUBTYPE_CODE  IN ('BANK', 'FT01', 'FT02') ")
            sb.Append("GROUP BY T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE  ")
            sb.Append(")T ")
            sb.Append("WHERE WLST_REJ_CODE='01' ")
            sb.Append("AND INSTR('" & payeename & "',WLST_CHK_NAME) >0 ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            CHECK_WATCHLIST_FOR_REJ = Ds.Tables(0)

        Catch ex As Exception
            CHECK_WATCHLIST_FOR_REJ = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try


    End Function
    Function CHECK_WATCHLIST_FOR_AML(ByRef oleConn As OleDbConnection, ByVal payeename As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME   ")
            'sb.Append("FROM GPS_WATCHLISTS_MA1 W INNER JOIN GPS_TL_WATCHLISTS_TYPE T ")
            'sb.Append("ON W.WLST_SUBTYPE_CODE=T.WLSTT_SUBTYPE ")
            'sb.Append("WHERE W.WLST_REJ_CODE='01'  ")
            'sb.Append("AND W.WLST_SUBTYPE_CODE NOT IN ('BANK', 'FT01', 'FT02') ")
            'sb.Append("AND INSTR('" & payeename & "',W.WLST_CHK_NAME) >0 ")
            'sb.Append("GROUP BY T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME ")

            sb.Append("SELECT WLSTT_TYPE,WLST_SUBTYPE_CODE ,WLST_CHK_NAME  ")
            sb.Append("FROM  ")
            sb.Append("( ")
            sb.Append("SELECT T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE,MAX(WLST_LOADDATE)   ")
            sb.Append("FROM GPS_WATCHLISTS_MA1 W INNER JOIN GPS_TL_WATCHLISTS_TYPE T ")
            sb.Append("ON W.WLST_SUBTYPE_CODE=T.WLSTT_SUBTYPE ")
            sb.Append("WHERE W.WLST_SUBTYPE_CODE NOT IN ('BANK', 'FT01', 'FT02') ")
            sb.Append("GROUP BY T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE  ")
            sb.Append(")T ")
            sb.Append("WHERE WLST_REJ_CODE='01' ")
            sb.Append("AND INSTR('" & payeename & "',WLST_CHK_NAME) >0 ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            CHECK_WATCHLIST_FOR_AML = Ds.Tables(0)

        Catch ex As Exception
            CHECK_WATCHLIST_FOR_AML = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try


    End Function
    Function CHECK_WATCHLIST_EFFDATE(ByRef oleConn As OleDbConnection, ByVal payeename As String, ByVal batchdate As String) As Boolean

        Dim sb As New StringBuilder()

        sb.Append("SELECT * FROM GPS_WATCHLISTS_MA2 ")
        sb.Append("WHERE INSTR('" & payeename & "',WLSTP_FNAME||WLSTP_LNAME) >0 ")
        sb.Append("AND '" & batchdate & "' BETWEEN WLSTP_S_EFFDATE AND WLSTP_E_EFFDATE ")
        sb.Append("AND WLSTP_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Public Function fValidatWatchLists(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYEE_NAME    ")
            'sb.Append("FROM GPS_TMP_PAYMENT P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYEE_NAME     ")
            sb.Append("FROM GPS_TMP_PAYMENT P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
            sb.Append("WHERE P.GP_BATCHTYPE='M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatWatchLists = Ds.Tables(0)

        Catch ex As Exception
            fValidatWatchLists = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fValidatWatchLists_NORMAL(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYEE_NAME    ")
            'sb.Append("FROM GPS_TMP_PAYMENT P  ")
            'sb.Append("WHERE P.GP_BATCHTYPE='A'   ")
            'sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")

            sb.Append("SELECT P.GP_CREATEDATE,P.GP_CORE_SYSTEM,P.GP_TRANSREF,P.GP_GPTREF_SEQNO,P.GP_PAYEE_NAME     ")
            sb.Append("FROM GPS_TMP_PAYMENT P  INNER JOIN GPS_TRANSREF_REL R ")
            sb.Append("ON P.GP_CREATEDATE=R.TREF_CREATEDATE ")
            sb.Append("AND P.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
            sb.Append("AND P.GP_TRANSREF=R.TREF_TRANSREF ")
            sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
            sb.Append("WHERE P.GP_BATCHTYPE<>'M'    ")
            sb.Append("AND P.GP_FLAG_VALIDATE='COMPLETE'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatWatchLists_NORMAL = Ds.Tables(0)

        Catch ex As Exception
            fValidatWatchLists_NORMAL = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function UPD_WATCHLIST_AML(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal create_date As String, _
     ByVal core_system As String, ByVal transref As String, ByVal seq As String, _
       ByVal wl_type As String, ByVal wl_subtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT SET GP_WLSTT_TYPE='" & wl_type & "',GP_WLSTT_SUBTYPE ='" & wl_subtype & "' ")
        sb.Append("WHERE GP_CREATEDATE ='" & create_date & "' AND GP_CORE_SYSTEM='" & core_system & "' AND GP_TRANSREF='" & transref & "' and GP_GPTREF_SEQNO ='" & seq & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_WATCHLIST_REJ(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String, ByVal create_date As String, _
    ByVal core_system As String, ByVal transref As String, ByVal seq As String, _
    ByVal wl_type As String, ByVal wl_subtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT SET GP_FLAG_VALIDATE='INCOMPLETE', GP_REJECT_TYPE='" & errtype & "',GP_WLSTT_TYPE='" & wl_type & "',GP_WLSTT_SUBTYPE ='" & wl_subtype & "' ")
        sb.Append("WHERE GP_CREATEDATE ='" & create_date & "' AND GP_CORE_SYSTEM='" & core_system & "' AND GP_TRANSREF='" & transref & "' and GP_GPTREF_SEQNO ='" & seq & "'  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Public Function UPD_VALIDATE10_1(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        'sb.Append("update gps_tmp_wht m ")
        'sb.Append("set TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='" & errtype & "' ")
        'sb.Append("where exists ")
        'sb.Append("( ")
        'sb.Append("select 1 ")
        'sb.Append("from GPS_TMP_PAYMENT a ")
        'sb.Append("inner join gps_tl_bankmaster b on b.bkmst_bnkcode_no= a.gp_bnkcode_no ")
        'sb.Append("where a.gp_flag_validate='COMPLETE'  ")
        'sb.Append("and m.TAX_CREATEDATE=a.GP_CREATEDATE ")
        'sb.Append("and m.TAX_CORE_SYSTEM=a.GP_CORE_SYSTEM ")
        'sb.Append("and m.TAX_TRANSREF=a.GP_TRANSREF ")
        'sb.Append("and m.TAX_GPTREF_SEQNO=a.GP_GPTREF_SEQNO ")
        'sb.Append(") ")

        sb.Append("update gps_tmp_wht m  ")
        sb.Append("set TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='BBB'  ")
        sb.Append("where  exists  ")
        sb.Append("(  ")
        sb.Append("select 1  ")
        sb.Append("from GPS_TMP_PAYMENT a INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON a.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND a.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND a.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("AND R.TREF_PAYCRETYP_ID='003' ")
        sb.Append("AND a.GP_BATCHTYPE='M'   ")
        sb.Append("inner join gps_tl_bankmaster b on b.bkmst_bnkcode_no= a.gp_bnkcode_no  ")
        sb.Append("where a.gp_flag_validate='COMPLETE'   ")
        sb.Append("and m.TAX_CREATEDATE=a.GP_CREATEDATE  ")
        sb.Append("and m.TAX_CORE_SYSTEM=a.GP_CORE_SYSTEM  ")
        sb.Append("and m.TAX_TRANSREF=a.GP_TRANSREF  ")
        sb.Append("and m.TAX_GPTREF_SEQNO=a.GP_GPTREF_SEQNO  ")
        sb.Append(")  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Public Function UPD_VALIDATE10_1_NORMAL(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        'sb.Append("update gps_tmp_wht m ")
        'sb.Append("set TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='" & errtype & "' ")
        'sb.Append("where exists ")
        'sb.Append("( ")
        'sb.Append("select 1 ")
        'sb.Append("from GPS_TMP_PAYMENT a ")
        'sb.Append("inner join gps_tl_bankmaster b on b.bkmst_bnkcode_no= a.gp_bnkcode_no ")
        'sb.Append("where a.gp_flag_validate='COMPLETE'  ")
        'sb.Append("and m.TAX_CREATEDATE=a.GP_CREATEDATE ")
        'sb.Append("and m.TAX_CORE_SYSTEM=a.GP_CORE_SYSTEM ")
        'sb.Append("and m.TAX_TRANSREF=a.GP_TRANSREF ")
        'sb.Append("and m.TAX_GPTREF_SEQNO=a.GP_GPTREF_SEQNO ")
        'sb.Append(") ")

        sb.Append("update gps_tmp_wht m  ")
        sb.Append("set TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='BBB'  ")
        sb.Append("where  exists  ")
        sb.Append("(  ")
        sb.Append("select 1  ")
        sb.Append("from GPS_TMP_PAYMENT a INNER JOIN GPS_TRANSREF_REL R ")
        sb.Append("ON a.GP_CREATEDATE=R.TREF_CREATEDATE ")
        sb.Append("AND a.GP_CORE_SYSTEM=R.TREF_CORE_SYSTEM ")
        sb.Append("AND a.GP_TRANSREF=R.TREF_TRANSREF ")
        sb.Append("AND R.TREF_PAYCRETYP_ID<>'003' ")
        sb.Append("AND a.GP_BATCHTYPE<>'M'   ")
        sb.Append("inner join gps_tl_bankmaster b on b.bkmst_bnkcode_no= a.gp_bnkcode_no  ")
        sb.Append("where a.gp_flag_validate='COMPLETE'   ")
        sb.Append("and m.TAX_CREATEDATE=a.GP_CREATEDATE  ")
        sb.Append("and m.TAX_CORE_SYSTEM=a.GP_CORE_SYSTEM  ")
        sb.Append("and m.TAX_TRANSREF=a.GP_TRANSREF  ")
        sb.Append("and m.TAX_GPTREF_SEQNO=a.GP_GPTREF_SEQNO  ")
        sb.Append(")  ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Public Function UPD_VALIDATE10_2(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("update GPS_TMP_PAYMENT a  ")
        sb.Append("set gp_flag_validate='INCOMPLETE' ")
        sb.Append(",GP_REJECT_TYPE='" & errtype & "' ")
        sb.Append("where a.gp_flag_validate='COMPLETE'  ")
        sb.Append("and not exists ")
        sb.Append("( ")
        sb.Append("select 1 ")
        sb.Append("from gps_tl_bankmaster b ")
        sb.Append("where b.bkmst_bnkcode_no= a.gp_bnkcode_no ")
        sb.Append(") ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_VALIDATE10_3(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("update gps_tmp_wht m ")
        sb.Append("set TAX_FLAG_VALIDATE='INCOMPLETE', TAX_REJECT_TYPE='" & errtype & "' ")
        sb.Append("where exists ")
        sb.Append("( ")
        sb.Append("select 1 ")
        sb.Append("from GPS_TMP_PAYMENT a  ")
        sb.Append("inner join GPS_TL_PAYTYPE b on a.gp_paymth=b.payt_paymth  ")
        sb.Append("and a.gp_sub_paymth=b.payt_sub_paymth ")
        sb.Append("inner join GPS_TL_BANKSERVICE1 c on b.payt_pay_group=c.bnks_pay_group ")
        sb.Append("where a.gp_paymth in ('C','D')  ")
        sb.Append("and a.gp_flag_validate='COMPLETE' ")
        sb.Append("and m.TAX_CREATEDATE=a.GP_CREATEDATE ")
        sb.Append("and m.TAX_CORE_SYSTEM=a.GP_CORE_SYSTEM ")
        sb.Append("and m.TAX_TRANSREF=a.GP_TRANSREF ")
        sb.Append("and m.TAX_GPTREF_SEQNO=a.GP_GPTREF_SEQNO ")
        sb.Append(") ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function UPD_VALIDATE10_4(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal errtype As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("update GPS_TMP_PAYMENT a  ")
        sb.Append("set gp_flag_validate='INCOMPLETE' ")
        sb.Append(",GP_REJECT_TYPE='" & errtype & "' ")
        sb.Append("where a.gp_paymth in ('C','D') and a.gp_flag_validate='COMPLETE' ")
        sb.Append("and not exists ")
        sb.Append("( ")
        sb.Append("select 1 ")
        sb.Append("from GPS_TL_PAYTYPE b  ")
        sb.Append("inner join GPS_TL_BANKSERVICE1 c on b.payt_pay_group=c.bnks_pay_group     ")
        sb.Append("where a.gp_paymth=b.payt_paymth  ")
        sb.Append("and a.gp_sub_paymth=b.payt_sub_paymth       ")
        sb.Append(") ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function LookUp_MassageErr(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT REJT_REJ_MASSAGE FROM GPS_TL_REJECT_TYPE WHERE REJT_REJ_TYPE= '" & code & "'    ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_MassageErr = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_MassageErr = code
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
End Class
