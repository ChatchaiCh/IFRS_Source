﻿Imports System.Security
Imports System.Runtime.InteropServices

Public Class clsManageFile

    ' For development team
    'Private Const INI_FILENAME = "\\devserve-1\SCNYL_Connection\Connection.ini"

    ' For production
    'Private Const INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"

    'Temp private -> public
    Public INI_FILENAME As String
    Public RUNAS_PW As String
    Public RUNAS_US As String

    Public RUNAS_DOMAIN_SCHEMA As String
    Public RUNAS_ENCPWD As String

    'Private Const INI_FILENAME = "D:\WebServices\Connection.ini"
    'Public Declare Function CloseHandle Lib "kernel32" (ByVal hObject As IntPtr) As Long
    'Declare Auto Function CloseHandle Lib "kernel32.dll" (ByVal hObject As IntPtr) As Boolean
    'Declare Function CloseHandle Lib "kernel32" Alias "CloseHandle" (ByVal hObject As Integer) As Integer
    Declare Auto Function CloseHandle Lib "kernel32.dll" (ByVal hObject As Int32) As Int32

    Public Declare Auto Function ShowWindow Lib "user32" (ByVal hwnd As Long, ByVal nCmdShow As Long) As Long

    Public Sub New()
        If System.Configuration.ConfigurationManager.AppSettings("SCNYL_Connection2005_ini") Is Nothing Then
            INI_FILENAME = "\\Oraback\SCNYL_Connection\Connection.ini"
        Else
            INI_FILENAME = System.Configuration.ConfigurationManager.AppSettings("SCNYL_Connection2005_ini").ToString.ToUpper & "\Connection.ini"
        End If
    End Sub

    ' ประเภทของฐานข้อมูล Security_conn **ปกติจะเป็น Oracle
    Public Enum EnumAccessLocationType
        ALT_ORACLE = 0
        ALT_SQLSERVER = 1
    End Enum

    ' ประเภทของฐานข้อมูลที่จะสร้าง connection
    Public Enum EnumLocationType
        LT_ORACLE = 0
        LT_SQLSERVER = 1
        LT_AS400 = 2
    End Enum

    ' ประเภทของ connection ที่ต้องการให้สร้างให้
    Public Enum EnumConnectionType
        ORACLE_PROVIDER_FOR_OLEDB = 0       ' Oracle Provider for OLE DB
        MS_OLEDB_PROVIDER_FOR_ORACLE        ' Microsoft OLE DB Provider for Oracle
        MS_OLEDB_PROVIDER_FOR_SQLSERVER     ' Microsoft OLE DB Provider for SQL Server
        SQLSERVER_PROVIDER                  ' Microsoft SQL Server : SqlClient
        MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE   ' Microsoft OLE DB provider for ODBC Sybase Drivers 
        IBM_AS400_OLEDB_PROVIDER
    End Enum

    Public Function OpenConnection( _
      ByRef pYourConnectionName As System.Data.IDbConnection, _
      ByVal pAccessLocationType As EnumAccessLocationType, _
      ByVal pSystemName As String, _
      ByVal pConnectionType As EnumConnectionType, _
      ByVal pServiceName As String, _
      Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE, _
      Optional ByVal pSeqID As Integer = 1, _
      Optional ByVal pServiceName2 As String = "") As Boolean

        ' อ่าน initial file
        Dim _accessConnectionConfig As New AccessConnectionConfig(INI_FILENAME)
        Dim _systemConfig As SystemConfig
        Dim connString As String = ""
        Dim datasource As String = ""
        Dim cn As System.Data.IDbConnection = Nothing

        _systemConfig = GetSystemConfig(_accessConnectionConfig, pAccessLocationType, pSystemName, pServiceName, pLocationType, pSeqID)

        If _systemConfig Is Nothing Then
            Throw New Exception("Error occured in OpenConnection, can not found System Configuration data.")
        Else
            RUNAS_US = _systemConfig.UserID
            RUNAS_PW = _systemConfig.Password
            RUNAS_DOMAIN_SCHEMA = _systemConfig.Schema
            RUNAS_ENCPWD = _systemConfig.EncryptYN
        End If

        Return True
    End Function

    Private Function GetSystemConfig( _
      ByVal pAccessConnectionConfig As AccessConnectionConfig, _
      ByVal pAccessLocationType As EnumAccessLocationType, _
      ByVal pSystemName As String, _
      ByVal pServiceName As String, _
      ByVal pLocationType As EnumLocationType, _
      ByVal pSeqID As Integer) As SystemConfig

        ' ติดต่อฐานข้อมูลเพื่อขอข้อมูลไปสร้าง ConnectionString ต่อไป

        Dim _systemConfig As SystemConfig = Nothing

        Dim cn As System.Data.IDbConnection = Nothing
        Dim da As System.Data.IDbDataAdapter = Nothing
        Dim cm As System.Data.IDbCommand = Nothing
        Dim ds As New DataSet
        Dim dt As DataTable = Nothing
        Dim connString As String = ""
        Dim strBuilder As System.Text.StringBuilder

        Select Case pAccessLocationType
            Case EnumAccessLocationType.ALT_ORACLE
                connString = CreateConnectionString(EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, pAccessConnectionConfig.Oracle_userName, pAccessConnectionConfig.Oracle_password, pServiceName)
                cn = New System.Data.OracleClient.OracleConnection
                da = New System.Data.OracleClient.OracleDataAdapter
                cm = New System.Data.OracleClient.OracleCommand
            Case EnumAccessLocationType.ALT_SQLSERVER
                connString = CreateConnectionString(EnumConnectionType.SQLSERVER_PROVIDER, pAccessConnectionConfig.Sqlserver_username, pAccessConnectionConfig.Sqlserver_password, pServiceName)
                cn = New System.Data.SqlClient.SqlConnection
                da = New System.Data.SqlClient.SqlDataAdapter
                cm = New System.Data.SqlClient.SqlCommand
        End Select

        If cn Is Nothing Then
            Throw New Exception("Error occured in GetSystemConfig, can not found Location Type")
        End If

        cn.ConnectionString = connString

        ' ค้นหาข้อมูล System configuration
        strBuilder = New System.Text.StringBuilder
        strBuilder.Append(" Select UserID, Password, SC_Schema, Initial_Catalog, encpwd")
        strBuilder.Append(" From T_SystemConnection ")
        strBuilder.Append(" Where SystemName = '" & pSystemName & "' ")
        strBuilder.Append(" And LocationType = '" & pLocationType & "' ")
        strBuilder.Append(" And SeqID = '" & pSeqID & "' ")
        strBuilder.Append(" And RecStatus = 'A' ")
        cm.CommandText = strBuilder.ToString

        cm.Connection = cn
        da.SelectCommand = cm
        da.Fill(ds)
        dt = ds.Tables(0)

        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            _systemConfig = New SystemConfig
            With _systemConfig
                .UserID = dt.Rows(0)("UserID").ToString
                .Password = dt.Rows(0)("Password").ToString
                .Schema = dt.Rows(0)("SC_Schema").ToString
                .Initial_Catalog = dt.Rows(0)("Initial_Catalog").ToString
                .EncryptYN = dt.Rows(0)("encpwd").ToString
            End With
        Else
            _systemConfig = Nothing
        End If

        Return _systemConfig

    End Function

    Private Function CreateConnectionString(ByVal pConnectionType As EnumConnectionType, _
        ByVal pUserName As String, ByVal pPassword As String, ByVal pDataSource As String, Optional ByVal pCatalog As String = "") As String

        Dim connString As String = ""

        ' ถ้าเป็น Oracle connection ไม่ต้องกำหนด Catalog
        Select Case pConnectionType
            Case EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Data Source={2}", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE
                connString = String.Format("Provider=MSDAORA.1;Password={0};User ID={1};Data Source={2};Persist Security Info=False", pPassword, pUserName, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER
                connString = String.Format("Provider=SQLOLEDB.1;Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.SQLSERVER_PROVIDER
                connString = String.Format("Password={0};Persist Security Info=False;User ID={1};Initial Catalog={2};Data Source={3}", pPassword, pUserName, pCatalog, pDataSource)
            Case EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ODBC_SYBASE
                'connString = String.Format("DRIVER=Sybase ASE ODBC Driver;password={0};uid={1};DB={2};NA={3};NLN=Winsock;charset=utf8", pPassword, pUserName, pCatalog, pDataSource)
                connString = String.Format("Driver=Adaptive Server Enterprise;app=myAppName;pwd={0};uid={1};db={2};port={3};server={4};charset=utf8", pPassword, pUserName, pDataSource.Split("|")(2), pDataSource.Split("|")(1), pDataSource.Split("|")(0))

            Case EnumConnectionType.IBM_AS400_OLEDB_PROVIDER
                connString = String.Format("Provider=IBMDA400;Password={0};User ID={1};Data Source={2};Transport Product=Client Access;SSL=DEFAULT", pPassword, pUserName, pDataSource)
        End Select

        Return connString
    End Function

    Public Function ConvertToSecureString(ByVal str As String) As SecureString
        Dim password As New SecureString
        For Each c As Char In str.ToCharArray
            password.AppendChar(c)
        Next
        Return password
    End Function
    Public Sub MovFile( _
      ByRef pYourConnectionName As System.Data.IDbConnection, _
      ByVal pAccessLocationType As EnumAccessLocationType, _
      ByVal pSystemName As String, _
      ByVal pConnectionType As EnumConnectionType, _
      ByVal pServiceName As String, _
      ByVal pPathFrom As String, ByVal pPathTo As String,
      Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE, _
      Optional ByVal pSeqID As Integer = 1, _
      Optional ByVal pServiceName2 As String = "")
        Try

            OpenConnection(pYourConnectionName, pAccessLocationType, _
                           pSystemName, pConnectionType, _
                           pServiceName, pLocationType, _
                           pSeqID, pServiceName2)

            Dim foo As New System.Diagnostics.Process
            'foo.StartInfo.WorkingDirectory = ""

            foo.StartInfo.RedirectStandardOutput = True
            foo.StartInfo.RedirectStandardInput = True
            foo.StartInfo.RedirectStandardError = True

            '--foo.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

            foo.StartInfo.FileName = "cmd.exe"
            'foo.StartInfo.Arguments = "/K copy " & pPathFrom & " " & pPathTo & " && del " & pPathFrom
            '--foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " && del " & Chr(34) & pPathFrom
            foo.StartInfo.UseShellExecute = False
            foo.StartInfo.CreateNoWindow = True

            foo.StartInfo.Domain = RUNAS_DOMAIN_SCHEMA

            foo.StartInfo.UserName = RUNAS_US
            foo.StartInfo.Password = ConvertToSecureString(RUNAS_PW)

            foo.StartInfo.Arguments = " /K move " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34)

            foo.Start()
            foo.WaitForExit(50)

            foo.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Public Sub RenameFile( _
      ByRef pYourConnectionName As System.Data.IDbConnection, _
      ByVal pAccessLocationType As EnumAccessLocationType, _
      ByVal pSystemName As String, _
      ByVal pConnectionType As EnumConnectionType, _
      ByVal pServiceName As String, _
      ByVal pPathFrom As String, ByVal pPathToNoPath As String,
      Optional ByVal pLocationType As EnumLocationType = EnumLocationType.LT_ORACLE, _
      Optional ByVal pSeqID As Integer = 1, _
      Optional ByVal pServiceName2 As String = "")
        Try

            OpenConnection(pYourConnectionName, pAccessLocationType, _
                           pSystemName, pConnectionType, _
                           pServiceName, pLocationType, _
                           pSeqID, pServiceName2)

            Dim foo As New System.Diagnostics.Process
            'foo.StartInfo.WorkingDirectory = ""

            foo.StartInfo.RedirectStandardOutput = True
            foo.StartInfo.RedirectStandardInput = True
            foo.StartInfo.RedirectStandardError = True

            '--foo.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

            foo.StartInfo.FileName = "cmd.exe"
            'foo.StartInfo.Arguments = "/K copy " & pPathFrom & " " & pPathTo & " && del " & pPathFrom
            '--foo.StartInfo.Arguments = " /K copy " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathTo & Chr(34) & " && del " & Chr(34) & pPathFrom
            foo.StartInfo.UseShellExecute = False
            foo.StartInfo.CreateNoWindow = True

            foo.StartInfo.Domain = RUNAS_DOMAIN_SCHEMA

            foo.StartInfo.UserName = RUNAS_US
            foo.StartInfo.Password = ConvertToSecureString(RUNAS_PW)

            foo.StartInfo.Arguments = " /K rename " & Chr(34) & pPathFrom & Chr(34) & " " & Chr(34) & pPathToNoPath & Chr(34)

            foo.Start()
            foo.WaitForExit(20)

            foo.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Class SystemConfig
        Private _userID As String
        Public Property UserID() As String
            Get
                Return _userID
            End Get
            Set(ByVal value As String)
                _userID = value
            End Set
        End Property

        Private _password As String
        Public Property Password() As String
            Get
                Return _password
            End Get
            Set(ByVal value As String)
                _password = value
            End Set
        End Property

        Private _schema As String
        Public Property Schema() As String
            Get
                Return _schema
            End Get
            Set(ByVal value As String)
                _schema = value
            End Set
        End Property

        Private _initial_catalog As String
        Public Property Initial_Catalog() As String
            Get
                Return _initial_catalog
            End Get
            Set(ByVal value As String)
                _initial_catalog = value
            End Set
        End Property

        Private _encryptYN As String
        Public Property EncryptYN() As String
            Get
                Return _encryptYN
            End Get
            Set(ByVal value As String)
                _encryptYN = value
            End Set
        End Property

    End Class

    Private Class AccessConnectionConfig

        Private _oracle_userName As String
        Public Property Oracle_userName() As String
            Get
                Return _oracle_userName
            End Get
            Set(ByVal value As String)
                _oracle_userName = value
            End Set
        End Property

        Private _oracle_password As String
        Public Property Oracle_password() As String
            Get
                Return _oracle_password
            End Get
            Set(ByVal value As String)
                _oracle_password = value
            End Set
        End Property

        Private _sqlserver_userName As String
        Public Property Sqlserver_username() As String
            Get
                Return _sqlserver_userName
            End Get
            Set(ByVal value As String)
                _sqlserver_userName = value
            End Set
        End Property

        Private _sqlserver_password As String
        Public Property Sqlserver_password() As String
            Get
                Return _sqlserver_password
            End Get
            Set(ByVal value As String)
                _sqlserver_password = value
            End Set
        End Property

        Private _iniFile As String
        Public Property IniFile() As String
            Get
                Return _iniFile
            End Get
            Set(ByVal value As String)
                _iniFile = value
            End Set
        End Property

        Sub New(ByVal pIniFile As String)
            IniFile = pIniFile
            Me.DataBind()
        End Sub

        Public Function DataBind() As Boolean
            Me.ReadIni()
        End Function

        Private Function ReadIni() As Boolean
            Dim sr As System.IO.StreamReader
            Dim strLine As String
            Dim sectionName As String = ""

            ' อ่านไฟล์แบบ Stream
            sr = FileIO.FileSystem.OpenTextFileReader(IniFile, System.Text.Encoding.Default)

            ' วนลูปตรวจสอบข้อมูล
            Do Until sr.EndOfStream
                strLine = sr.ReadLine()
                If InStr(strLine, "[") > 0 And InStr(strLine, "]") Then
                    sectionName = strLine.Replace("[", "").Replace("]", "")
                Else
                    If strLine.Trim <> "" Then
                        If strLine.Split("=")(0).Trim.ToUpper = "USERNAME" Then
                            Select Case sectionName.ToUpper
                                Case "ORACLE"
                                    Oracle_userName = strLine.Split("=")(1).Trim
                                Case "SQLSERVER"
                                    Sqlserver_username = strLine.Split("=")(1).Trim
                                Case Else
                                    Oracle_userName = ""
                                    Sqlserver_username = ""
                            End Select
                        ElseIf strLine.Split("=")(0).Trim.ToUpper = "PASSWORD" Then
                            Select Case sectionName.ToUpper
                                Case "ORACLE"
                                    Oracle_password = mdEncrypt.Decrypt(strLine.Split("=")(1).Trim, "Maxky")
                                Case "SQLSERVER"
                                    Sqlserver_password = mdEncrypt.Decrypt(strLine.Split("=")(1).Trim, "LekStudio")
                                Case Else
                                    Oracle_password = ""
                                    Sqlserver_password = ""
                            End Select
                        End If
                    End If
                End If
            Loop
        End Function
    End Class

End Class
