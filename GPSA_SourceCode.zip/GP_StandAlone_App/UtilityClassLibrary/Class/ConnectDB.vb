Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration
Imports SCNYL_Connection2005.SCNYL_Connection
Public Class ConnectDB
    Public gConnGP As New OleDbConnection
    Public gConnGP_2 As New OleDbConnection
    Public gConnGP_3 As New OleDbConnection

    Public ErrConnectDBMessage As String
    Private clsManageFile As ManageFile.ClsManageFile

    Private clsMNG_FILE As clsManageFile

    Private _cls_cn As System.Data.IDbConnection
    Public Function OpenConnGP() As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim sServer As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper 'ORADEV
        Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper 'change GPSA to 206_GPSA by App2App
        Dim sServer2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper 'ORADEV

        'Try
        '    ClsScnylConn.OpenConnection(gConnGP, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)
        '    OpenConnGP = True
        'Catch ex As Exception
        '    ErrConnectDBMessage = ex.ToString
        '    OpenConnGP = False
        'End Try

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Dim strP As String
        '-- CR#174 App2App --

        Try
            strP = SCNYL_Connection2005.SCNYL_Connection.GetAuthorize(sACCESSLOCATION1 _
                                                                      , sSERVICENAME1 _
                                                                      , sSYSTEMCODE1 _
                                                                      , sLOCATIONTYPE1 _
                                                                      , sSEQID1)
            'MsgBox("strP = " & strP)
            ClsScnylConn.OpenConnection(gConnGP, EnumAccessLocationType.ALT_ORACLE, sSYSTEMCODE1, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sSERVICENAME1, EnumLocationType.LT_ORACLE, sSEQID1, sSERVICENAME2)
            OpenConnGP = True
        Catch ex As Exception
            ErrConnectDBMessage = ex.ToString
            OpenConnGP = False
        End Try
    End Function
    Public Function OpenConnGP_2() As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim sServer As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim sSystemCode As String = ConfigurationManager.AppSettings("SYSTEMCODE").ToUpper
        Dim sServer2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper

        'Try
        '    ClsScnylConn.OpenConnection(gConnGP_2, EnumAccessLocationType.ALT_ORACLE, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sServer, EnumLocationType.LT_ORACLE, 1, sServer2)
        '    OpenConnGP_2 = True
        'Catch ex As Exception
        '    ErrConnectDBMessage = ex.ToString
        '    OpenConnGP_2 = False
        'End Try

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Dim strP As String
        '-- CR#174 App2App --

        Try
            strP = SCNYL_Connection2005.SCNYL_Connection.GetAuthorize(sACCESSLOCATION1 _
                                                                      , sSERVICENAME1 _
                                                                      , sSYSTEMCODE1 _
                                                                      , sLOCATIONTYPE1 _
                                                                      , sSEQID1)
            ClsScnylConn.OpenConnection(gConnGP_2, EnumAccessLocationType.ALT_ORACLE, sSYSTEMCODE1, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sSERVICENAME1, EnumLocationType.LT_ORACLE, sSEQID1, sSERVICENAME2)
            OpenConnGP_2 = True
        Catch ex As Exception
            ErrConnectDBMessage = ex.ToString
            OpenConnGP_2 = False
        End Try

    End Function

    Public Function OpenConnGP_3() As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim sServer As String = "10.38.3.92"
        Dim sSystemCode As String = "REFIDEnquiry"
        Dim sServer2 As String = "10.38.3.92"
        Try
            ClsScnylConn.OpenConnection(gConnGP_3, EnumAccessLocationType.ALT_SQLSERVER, sSystemCode, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_SQLSERVER, sServer, EnumLocationType.LT_SQLSERVER, 1, sServer2)
            OpenConnGP_3 = True
        Catch ex As Exception
            ErrConnectDBMessage = ex.ToString
            OpenConnGP_3 = False
        End Try
    End Function

    'Public Function BackupFile(ByVal oleConn As OleDbConnection, ByVal pfileFrom As String, ByVal pfileTo As String) As Boolean
    Public Function BackupFile_ORG(ByVal pfileFrom As String, ByVal pfileTo As String) As Boolean
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        Dim clsMNG_FILE As New clsManageFile

        'Dim thread1 As System.Threading.Thread

        Try
            If cnn_string <> "" Then
                _cls_cn = New Odbc.OdbcConnection
                _cls_cn.ConnectionString = cnn_string
                _cls_cn.Open()
            Else
                clsManageFile = New ManageFile.ClsManageFile
                'clsManageFile.MovFile(oleConn, EnumAccessLocationType.ALT_ORACLE, system_code, EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, server_1, pfileFrom, pfileTo, EnumLocationType.LT_ORACLE, 1, server_2)
                clsManageFile.MovFile(_cls_cn, SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE, _
                         system_code, _
                         SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB, _
                         server_1, _
                         pfileFrom, pfileTo, _
                         SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE, _
                         1, _
                         server_2)

                Return True
            End If

        Catch ex As Exception
            ErrConnectDBMessage = ex.Message
        End Try

        Return False

    End Function

    Public Function BackupFile(ByVal pfileFrom As String, ByVal pfileTo As String) As Boolean
        'xxDim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection

        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Dim strP As String
        Dim blnMoveFile As Boolean
        Dim sSYSTEMCODE_RUNAS As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        '-- CR#174 App2App --

        'Dim thread1 As System.Threading.Thread
        blnMoveFile = False

        Try
            If cnn_string <> "" Then
                _cls_cn = New Odbc.OdbcConnection
                _cls_cn.ConnectionString = cnn_string
                _cls_cn.Open()
            Else
                '' ''--clsManageFile = New ManageFile.ClsManageFile
                clsMNG_FILE = New clsManageFile
                '' ''clsManageFile.MovFile(oleConn _
                '' ''    , EnumAccessLocationType.ALT_ORACLE _
                '' ''    , system_code _
                '' ''    , EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                '' ''    , server_1 _
                '' ''    , pfileFrom _
                '' ''    , pfileTo _
                '' ''    , EnumLocationType.LT_ORACLE _
                '' ''    , 1 _
                '' ''    , server_2)
                '------------clsMNG_FILE.MovFile(_cls_cn _
                '------------                    , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
                '------------                    , system_code _
                '------------                    , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                '------------                    , server_1 _
                '------------                    , pfileFrom, pfileTo _
                '------------                    , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
                '------------                    , 1 _
                '------------                    , server_2)


                'blnMoveFile = ClsScnylConn.MovFile(gConnGP_2 _
                '                     , SCNYL_Connection2005.SCNYL_Connection.EnumAccessLocationType.ALT_ORACLE _
                '                     , sSYSTEMCODE_RUNAS _
                '                     , SCNYL_Connection2005.SCNYL_Connection.EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                '                     , sSERVICENAME1 _
                '                     , pfileFrom _
                '                     , pfileTo)
                '------ClsScnylConn.OpenConnection(gConnGP_2, EnumAccessLocationType.ALT_ORACLE, sSYSTEMCODE1, EnumConnectionType.MS_OLEDB_PROVIDER_FOR_ORACLE, sSERVICENAME1, EnumLocationType.LT_ORACLE, sSEQID1, sSERVICENAME2)
                blnMoveFile = ClsScnylConn.MovFile(gConnGP _
                                                   , EnumAccessLocationType.ALT_ORACLE _
                                                   , sSYSTEMCODE_RUNAS _
                                                   , EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                                                   , sSERVICENAME1 _
                                                   , pfileFrom _
                                                   , pfileTo)
                '_
                '                                                   , EnumLocationType.LT_ORACLE _
                '                                                   , 1 _
                '                                                   , sSERVICENAME2)
                Return blnMoveFile
            End If

        Catch ex As Exception

            ErrConnectDBMessage = ex.Message
            Return False

        End Try

    End Function

    Public Function RenameFile(ByVal pfileFrom As String, ByVal pfileTo As String) As Boolean
        'xxDim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection
        Dim ClsScnylConn As New SCNYL_Connection2005.SCNYL_Connection

        Dim system_code As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        Dim server_1 As String = ConfigurationManager.AppSettings("DSN_SecurityConn").ToUpper
        Dim server_2 As String = ConfigurationManager.AppSettings("DSN_GPStandAlone").ToUpper
        Dim cnn_string As String = ""

        '-- CR#174 App2App --
        Dim sACCESSLOCATION1 As String = ConfigurationManager.AppSettings("ACCESSLOCATION1").ToUpper
        Dim sSYSTEMCODE1 As String = ConfigurationManager.AppSettings("SYSTEMCODE1").ToUpper
        Dim sSERVICENAME1 As String = ConfigurationManager.AppSettings("SERVICENAME1").ToUpper
        Dim sSERVICENAME2 As String = ConfigurationManager.AppSettings("SERVICENAME2").ToUpper
        Dim sSYSTEMNAME1 As String = ConfigurationManager.AppSettings("SYSTEMNAME1").ToUpper
        Dim sLOCATIONTYPE1 As String = ConfigurationManager.AppSettings("LOCATIONTYPE1").ToUpper
        Dim sSEQID1 As String = ConfigurationManager.AppSettings("SEQID1").ToUpper
        Dim sSCHEME As String = ConfigurationManager.AppSettings("SCHEME").ToUpper
        Dim strP As String
        Dim blnMoveFile As Boolean
        Dim blnRenameFile As Boolean

        Dim sSYSTEMCODE_RUNAS As String = ConfigurationManager.AppSettings("SYSTEMCODE_RUNAS").ToUpper
        '-- CR#174 App2App --

        'Dim thread1 As System.Threading.Thread
        blnMoveFile = False

        Try
            If cnn_string <> "" Then
                _cls_cn = New Odbc.OdbcConnection
                _cls_cn.ConnectionString = cnn_string
                _cls_cn.Open()
            Else
                clsMNG_FILE = New clsManageFile
                blnRenameFile = ClsScnylConn.RenameFile(gConnGP _
                                                         , EnumAccessLocationType.ALT_ORACLE _
                                                         , sSYSTEMCODE_RUNAS _
                                                         , EnumConnectionType.ORACLE_PROVIDER_FOR_OLEDB _
                                                         , sSERVICENAME1 _
                                                         , pfileFrom _
                                                         , pfileTo _
                                                         , SCNYL_Connection2005.SCNYL_Connection.EnumLocationType.LT_ORACLE _
                                                         , 1 _
                                                         , server_2)

                Return blnRenameFile
            End If

        Catch ex As Exception

            ErrConnectDBMessage = ex.Message
            Return False

        End Try

    End Function

End Class
