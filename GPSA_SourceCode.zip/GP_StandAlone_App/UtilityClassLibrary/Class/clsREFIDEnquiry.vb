﻿Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient

Public Class clsREFIDEnquiry
    Implements System.IDisposable

    Private ConnRefId As SqlConnection

    Public Sub New()
        Try
            ConnRefId = New SqlConnection(EncryptDecryptUtility.Decrypt(ConfigurationManager.ConnectionStrings("ConnStrRefId").ConnectionString))
        Catch ex As Exception
            Throw New Exception("REFIDEnquiry Database : ConnectionString Error -> " + ex.Message)
        End Try
    End Sub


    Public Sub New(ConnStr As String)
        Try
            ConnRefId = New SqlConnection(ConnStr)
        Catch ex As Exception
            Throw New Exception("REFIDEnquiry Database : ConnectionString Error -> " + ex.Message)
        End Try
    End Sub

    Public Sub OpenConnecttion()
        Try
            ConnRefId.Open()
        Catch ex As Exception
            Throw New Exception("REFIDEnquiry Database : Open Connection Error -> " + ex.Message)
        End Try
    End Sub

    Public Sub CloseConnection()
        Try
            ConnRefId.Close()
        Catch ex As Exception
            Throw New Exception("REFIDEnquiry Database : Close Connection Error -> " + ex.Message)
        End Try
    End Sub

    Public Function GetMaskingPan(RefId As String) As DataTable
        Try
            Dim sb As New StringBuilder

            sb.Append("SELECT * FROM TB_PAN_REFID_M WHERE REFID='" + RefId + "'  ")
            Using oleDa As New SqlDataAdapter(sb.ToString(), ConnRefId)
                Dim dt As New DataTable
                oleDa.Fill(dt)

                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    Return dt
                Else
                    Return Nothing
                End If
            End Using
        Catch ex As Exception
            Throw New Exception("REFIDEnquiry Database : GetMaskingPlan Error -> " + ex.Message)
        End Try
    End Function

#Region "IDisposable Support"
    Private disposedValue As Boolean ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: dispose managed state (managed objects).
            End If

            ' TODO: free unmanaged resources (unmanaged objects) and override Finalize() below.
            ' TODO: set large fields to null.
        End If
        Me.disposedValue = True
    End Sub

    ' TODO: override Finalize() only if Dispose(ByVal disposing As Boolean) above has code to free unmanaged resources.
    'Protected Overrides Sub Finalize()
    '    ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
    '    Dispose(False)
    '    MyBase.Finalize()
    'End Sub

    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
