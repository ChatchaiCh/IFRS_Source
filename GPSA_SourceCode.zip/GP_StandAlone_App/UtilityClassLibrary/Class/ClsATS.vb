Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsATS
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Public Function GetBatchNo(ByRef oleConn As OleDbConnection, ByVal HR As Boolean) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF) ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS' ")

        If HR Then
            sb.Append("AND L.TREF_DTSOURCE='HRM' ")
        Else
            sb.Append("AND L.TREF_DTSOURCE<>'HRM' ")
        End If

        sb.Append("AND P.GP_FLAG_PRNRPTS='N' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO  ")
        sb.Append("ORDER BY L.TREF_BATCH_NO  DESC ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataATS_ByConfirmDate(ByRef oleConn As OleDbConnection, ByVal ConfirmDate As String, ByVal HR As Boolean) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,TO_CHAR(TO_DATE(L.TREF_PAIDDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TREF_PAIDDATE,  ")
        sb.Append("A.PATS_LETTERNO,A.PATS_HASH_TOT,A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,SUM(P.GP_AMOUNT) AMT  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L   ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE   ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM   ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)   ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_PRN_ATS A ")
        sb.Append("ON A.PATS_BATCH_NO=L.TREF_BATCH_NO ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'   ")

        If HR Then
            sb.Append("AND L.TREF_DTSOURCE='HRM' ")
        Else
            sb.Append("AND L.TREF_DTSOURCE<>'HRM' ")
        End If

        If ConfirmDate <> "" Then
            sb.Append("WHERE P.GP_CONFIRMDATE='" & ConfirmDate & "' ")
        End If

        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAIDDATE,A.PATS_LETTERNO,A.PATS_HASH_TOT,A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataATS_ByBatchno(ByRef oleConn As OleDbConnection, ByVal batchno As String, ByVal HR As Boolean) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAIDDATE,SUM(P.GP_AMOUNT) AMT,COUNT(*) REC ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'  ")

        If HR Then
            sb.Append("AND L.TREF_DTSOURCE='HRM' ")
        Else
            sb.Append("AND L.TREF_DTSOURCE<>'HRM' ")
        End If

        sb.Append("AND P.GP_FLAG_PRNRPTS='N'  ")

        sb.Append("WHERE TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAIDDATE ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataPRNATS_ByBatchno(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,L.TREF_PAIDDATE,A.PATS_LETTERNO,A.PATS_HASH_TOT,A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,SUM(P.GP_AMOUNT) AMT  ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L   ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE   ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM   ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)   ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T   ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
        sb.Append("INNER JOIN GPS_PRN_ATS A ")
        sb.Append("ON A.PATS_BATCH_NO=L.TREF_BATCH_NO ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'   ")

        If batchno <> "" Then
            sb.Append("WHERE A.PATS_BATCH_NO='" & batchno & "' ")
        End If

        sb.Append("GROUP BY L.TREF_BATCH_NO,L.TREF_PAIDDATE,A.PATS_LETTERNO,A.PATS_HASH_TOT,A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function INS_GPS_PRN_ATS(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("INSERT INTO GPS_PRN_ATS( ")
        sb.Append("PATS_BATCH_NO, ")
        sb.Append("PATS_LETTERNO, ")
        sb.Append("PATS_HASH_TOT, ")
        sb.Append("PATS_AUTH_NAME, ")
        sb.Append("PATS_AUTH_POSI, ")
        sb.Append("PATS_TOT_RECORD, ")
        sb.Append("CREATEDBY, ")
        sb.Append("CREATEDDATE, ")
        sb.Append("UPDATEDBY, ")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES ( ")
        sb.Append("'" & dr("PATS_BATCH_NO") & "',")
        sb.Append("'" & dr("PATS_LETTERNO") & "',")
        sb.Append("'" & dr("PATS_HASH_TOT") & "',")
        sb.Append("'" & dr("PATS_AUTH_NAME") & "',")
        sb.Append("'" & dr("PATS_AUTH_POSI") & "',")
        sb.Append("'" & dr("PATS_TOT_RECORD") & "',")
        sb.Append("'" & dr("CREATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & dr("UPDATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')")
        sb.Append(") ")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GPS_PRN_ATS(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_PRN_ATS SET  ")
        sb.Append("PATS_HASH_TOT='" & dr("PATS_HASH_TOT") & "',")
        sb.Append("PATS_AUTH_NAME='" & dr("PATS_AUTH_NAME") & "',")
        sb.Append("PATS_AUTH_POSI='" & dr("PATS_AUTH_POSI") & "',")
        sb.Append("PATS_TOT_RECORD='" & dr("PATS_TOT_RECORD") & "',")
        sb.Append("UPDATEDBY='" & dr("UPDATEDBY") & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE PATS_BATCH_NO='" & dr("PATS_BATCH_NO") & "'")
        sb.Append("  AND PATS_LETTERNO='" & dr("PATS_LETTERNO") & "'")


        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GP_FLAG_PRNRPTS(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal batchno As String, ByVal guserlogin As String, ByVal HR As Boolean) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("MERGE INTO GPS_PAYMENT A  ")
        sb.Append("USING      ")
        sb.Append("(     ")
        sb.Append("SELECT P.* ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'  ")

        If HR Then
            sb.Append("AND L.TREF_DTSOURCE='HRM' ")
        Else
            sb.Append("AND L.TREF_DTSOURCE<>'HRM' ")
        End If

        sb.Append("AND P.GP_FLAG_PRNRPTS='N' AND L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append(") T ON (  ")
        sb.Append("A.GP_SEQNO=T.GP_SEQNO ")
        sb.Append(")      ")
        sb.Append("WHEN MATCHED THEN UPDATE      ")
        sb.Append("SET A.GP_FLAG_PRNRPTS='Y', ")
        sb.Append("A.UPDATEDBY='" & guserlogin & "', ")
        sb.Append("A.UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function GetATSRpt(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT A.PATS_BATCH_NO,A.PATS_LETTERNO,A.PATS_HASH_TOT, ")
        sb.Append("A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,P.GP_PAIDDATE, ")
        sb.Append("'' AS COMPANY,SUM(P.GP_AMOUNT) AS AMOUNT ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'  ")
        sb.Append("AND L.TREF_DTSOURCE<>'HRM'  ")
        sb.Append("INNER JOIN GPS_PRN_ATS A ")
        sb.Append("ON A.PATS_BATCH_NO=L.TREF_BATCH_NO ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("GROUP BY A.PATS_BATCH_NO,A.PATS_LETTERNO,A.PATS_HASH_TOT, ")
        sb.Append("A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,P.GP_PAIDDATE ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
   
    Public Function GetATSHRRpt(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT A.PATS_BATCH_NO,A.PATS_LETTERNO,A.PATS_HASH_TOT, ")
        sb.Append("A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,P.GP_PAIDDATE, ")
        sb.Append("'' AS COMPANY,SUM(P.GP_AMOUNT) AS AMOUNT ")
        sb.Append("FROM (GPS_PAYMENT P INNER JOIN GPS_TRANSREF_REL L  ")
        sb.Append("ON P.GP_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND P.GP_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND P.GP_TRANSREF=L.TREF_TRANSREF)  ")
        sb.Append("INNER JOIN GPS_TL_PAYTYPE T  ")
        sb.Append("ON P.GP_PAYMTH=T.PAYT_PAYMTH AND P.GP_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
        sb.Append("AND T.PAYT_PAY_GROUP='ATS'  ")
        sb.Append("AND L.TREF_DTSOURCE='HRM'  ")
        sb.Append("INNER JOIN GPS_PRN_ATS A ")
        sb.Append("ON A.PATS_BATCH_NO=L.TREF_BATCH_NO ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "' ")
        sb.Append("GROUP BY A.PATS_BATCH_NO,A.PATS_LETTERNO,A.PATS_HASH_TOT, ")
        sb.Append("A.PATS_AUTH_NAME,A.PATS_AUTH_POSI,A.PATS_TOT_RECORD,P.GP_PAIDDATE ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
End Class
