Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class clsCreation
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer
    Function ClearTemp(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal tb As String, ByVal gUserLogin As String) As Boolean

        'Dim oleTrans As OleDbTransaction
        'oleTrans = clsUtility.gConnGP.BeginTransaction()

        Dim rec As Integer
        Dim sb As New StringBuilder

        sb.Append("delete from " & tb & " where createdby = '" & gUserLogin & "'")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
            'oleTrans.Commit()
            'MsgBox("Update already")
        Else
            Return False
            'oleTrans.Rollback()
            'MsgBox(clsBusiness.gLastErrMessage)
        End If

    End Function
    Function TmpToTable_GL(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal gUserLogin As String) As Boolean
        Dim ret As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder

        sb.Append("INSERT INTO GPS_GL_CREATION (")
        sb.Append("GLCR_CREATEDATE,")
        sb.Append("GLCR_CORE_SYSTEM,")
        sb.Append("GLCR_JN_TYPE,")
        sb.Append("GLCR_JN_SOURCE,")
        sb.Append("GLCR_B_UNIT,")
        sb.Append("GLCR_GL_PERIOD,")
        sb.Append("GLCR_TRANSREF,")
        sb.Append("GLCR_LINENO,")
        sb.Append("GLCR_GLSTS,")
        sb.Append("GLCR_BOOKID,")
        sb.Append("GLCR_SOURCE_NME,")
        sb.Append("GLCR_CATEGORY_NME,")
        sb.Append("GLCR_CURRENCY_CDE,")
        sb.Append("GLCR_ACTUAL_FLAG,")
        sb.Append("GLCR_COMPANY_CDE,")
        sb.Append("GLCR_RCCODE,")
        sb.Append("GLCR_TRANSDATE,")
        sb.Append("GLCR_DUEDATE,")
        sb.Append("GLCR_DESC,")
        sb.Append("GLCR_O_ACCOUNT,")
        sb.Append("GLCR_AMOUNT,")
        sb.Append("GLCR_DRCR,")
        sb.Append("GLCR_O_DEP_BRN,")
        sb.Append("GLCR_O_PL_PT,")
        sb.Append("GLCR_O_MKT_EMP,")
        sb.Append("GLCR_O_PROJECT,")
        sb.Append("GLCR_PAYMTH,")
        sb.Append("GLCR_PAYEE,")
        sb.Append("GLCR_S_ACCOUNT,")
        sb.Append("GLCR_S_ACCNAME,")
        sb.Append("GLCR_S_DEP_BRN,")
        sb.Append("GLCR_S_PL_PT,")
        sb.Append("GLCR_S_MKT_EMP,")
        sb.Append("GLCR_S_TT_TR,")
        sb.Append("GLCR_S_PROJECT,")
        sb.Append("GLCR_JN_HOLD,")
        sb.Append("GLCR_APPROVEDBY,")
        sb.Append("GLCR_APPROVEDDATE,")
        sb.Append("GLCR_JN_NO_C,")
        sb.Append("GLCR_VCH_NO_C,")
        sb.Append("GLCR_FLAG_BATCH,")
        sb.Append("GLCR_BATCHDATE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE,")
        sb.Append("GLCR_CONVERSION_TYPE,")
        sb.Append("GLCR_CONVERSION_RATE,")
        sb.Append("GLCR_CONVERSION_DATE,")
        sb.Append("GLCR_LINE_TRX_REF1,")
        sb.Append("GLCR_LINE_TRX_REF2,")
        sb.Append("GLCR_LINE_TRX_REF3,")
        sb.Append("GLCR_SUB_ACCT,")
        sb.Append("GLCR_ANALYSIS,")
        sb.Append("GLCR_INTERCOMPANY,")
        sb.Append("GLCR_SPARE1,")
        sb.Append("GLCR_TREATY_CODE,")
        sb.Append("GLCR_EVENT_CODE,")
        sb.Append("GLCR_LOCAL3,")
        sb.Append("GLCR_LOCAL4,")
        sb.Append("GLCR_REF_1,")
        sb.Append("GLCR_REF_2,")
        sb.Append("GLCR_REF_3,")
        sb.Append("GLCR_REF_4,")
        sb.Append("GLCR_REF_5,")
        sb.Append("GLCR_REF_6,")
        sb.Append("GLCR_REF_7,")
        sb.Append("GLCR_REF_8,")
        sb.Append("GLCR_REF_9,")
        sb.Append("GLCR_REF_10,")
        sb.Append("GLCR_TO_lEDGER) ")
        sb.Append("SELECT ")
        sb.Append("GLCR_CREATEDATE,")
        sb.Append("GLCR_CORE_SYSTEM,")
        sb.Append("GLCR_JN_TYPE,")
        sb.Append("GLCR_JN_SOURCE,")
        sb.Append("GLCR_B_UNIT,")
        sb.Append("GLCR_GL_PERIOD,")
        sb.Append("GLCR_TRANSREF,")
        sb.Append("GLCR_LINENO,")
        sb.Append("GLCR_GLSTS,")
        sb.Append("GLCR_BOOKID,")
        sb.Append("GLCR_SOURCE_NME,")
        sb.Append("GLCR_CATEGORY_NME,")
        sb.Append("GLCR_CURRENCY_CDE,")
        sb.Append("GLCR_ACTUAL_FLAG,")
        sb.Append("GLCR_COMPANY_CDE,")
        sb.Append("GLCR_RCCODE,")
        sb.Append("GLCR_TRANSDATE,")
        sb.Append("GLCR_DUEDATE,")
        sb.Append("GLCR_DESC,")
        sb.Append("GLCR_O_ACCOUNT,")
        sb.Append("GLCR_AMOUNT,")
        sb.Append("GLCR_DRCR,")
        sb.Append("GLCR_O_DEP_BRN,")
        sb.Append("GLCR_O_PL_PT,")
        sb.Append("GLCR_O_MKT_EMP,")
        sb.Append("GLCR_O_PROJECT,")
        sb.Append("GLCR_PAYMTH,")
        sb.Append("GLCR_PAYEE,")
        sb.Append("GLCR_S_ACCOUNT,")
        sb.Append("GLCR_S_ACCNAME,")
        sb.Append("GLCR_S_DEP_BRN,")
        sb.Append("GLCR_S_PL_PT,")
        sb.Append("GLCR_S_MKT_EMP,")
        sb.Append("GLCR_S_TT_TR,")
        sb.Append("GLCR_S_PROJECT,")
        sb.Append("GLCR_JN_HOLD,")
        sb.Append("GLCR_APPROVEDBY,")
        sb.Append("GLCR_APPROVEDDATE,")
        sb.Append("GLCR_JN_NO_C,")
        sb.Append("GLCR_VCH_NO_C,")
        sb.Append("GLCR_FLAG_BATCH,")
        sb.Append("GLCR_BATCHDATE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE,")
        sb.Append("GLCR_CONVERSION_TYPE,")
        sb.Append("GLCR_CONVERSION_RATE,")
        sb.Append("GLCR_CONVERSION_DATE,")
        sb.Append("GLCR_LINE_TRX_REF1,")
        sb.Append("GLCR_LINE_TRX_REF2,")
        sb.Append("GLCR_LINE_TRX_REF3,")
        sb.Append("GLCR_SUB_ACCT,")
        sb.Append("GLCR_ANALYSIS,")
        sb.Append("GLCR_INTERCOMPANY,")
        sb.Append("GLCR_SPARE1,")
        sb.Append("GLCR_TREATY_CODE,")
        sb.Append("GLCR_EVENT_CODE,")
        sb.Append("GLCR_LOCAL3,")
        sb.Append("GLCR_LOCAL4,")
        sb.Append("GLCR_REF_1,")
        sb.Append("GLCR_REF_2,")
        sb.Append("GLCR_REF_3,")
        sb.Append("GLCR_REF_4,")
        sb.Append("GLCR_REF_5,")
        sb.Append("GLCR_REF_6,")
        sb.Append("GLCR_REF_7,")
        sb.Append("GLCR_REF_8,")
        sb.Append("GLCR_REF_9,")
        sb.Append("GLCR_REF_10,")
        sb.Append("GLCR_TO_lEDGER ")
        sb.Append("FROM GPS_TMP_GL_CREATION WHERE CREATEDBY='" & gUserLogin & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            ret = True
        Else
            ret = False
        End If
        Return ret
    End Function
    Function TmpToTable_GP(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal gUserLogin As String) As Boolean
        Dim ret As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder
        Try

            sb.Append("INSERT INTO GPS_PAYMENT_CREATION (")
            sb.Append("GPCR_CREATEDATE,")
            sb.Append("GPCR_CORE_SYSTEM,")
            sb.Append("GPCR_TRANSREF,")
            sb.Append("GPCR_GPTREF_SEQNO,")
            sb.Append("GPCR_POLNO,")
            sb.Append("GPCR_BILLNO,")
            sb.Append("GPCR_PAIDDATE,")
            sb.Append("GPCR_AMOUNT,")
            sb.Append("GPCR_DESC,")
            sb.Append("GPCR_PAYMTH,")
            sb.Append("GPCR_PAYEE_NAME,")
            sb.Append("GPCR_BNKCODE,")
            sb.Append("GPCR_BNKCODE_NO,")
            sb.Append("GPCR_BNKBRN,")
            sb.Append("GPCR_BNKNAME,")
            sb.Append("GPCR_PAYEE_BNKACCNO,")
            sb.Append("GPCR_PAYEE_BNKACCNME,")
            sb.Append("GPCR_COMMENT,")
            sb.Append("GPCR_ADDRESS1,")
            sb.Append("GPCR_DISTRICT,")
            sb.Append("GPCR_PROVINCE,")
            sb.Append("GPCR_INSURENAME,")
            sb.Append("GPCR_DATASOURCE_NME,")
            sb.Append("GPCR_RESERVE6,")
            sb.Append("GPCR_MERCHN_NO,")
            sb.Append("GPCR_CDCARD_DATE,")
            sb.Append("GPCR_RESERVE9,")
            sb.Append("GPCR_RESERVE10,")
            sb.Append("GPCR_SYS_REF,")
            sb.Append("GPCR_SYS_GR,")
            sb.Append("GPCR_SUB_PAYMTH,")
            sb.Append("GPCR_FLAG_FLWBILL,")
            sb.Append("GPCR_OSEA_LIST,")
            sb.Append("GPCR_PHONE,")
            sb.Append("GPCR_FAX,")
            sb.Append("GPCR_SWIFT_CODE,")
            sb.Append("GPCR_BNKBRN_NAME,")
            sb.Append("GPCR_BNKADDR,")
            sb.Append("GPCR_COUNTRY,")
            sb.Append("GPCR_CURRENCY,")
            sb.Append("GPCR_EXCHN_RATE,")
            sb.Append("GPCR_BNKCHARGES,")
            sb.Append("GPCR_APPROVEDBY,")
            sb.Append("GPCR_APPROVEDDATE,")
            sb.Append("GPCR_FLAG_VALIDATE,")
            sb.Append("GPCR_FLAG_BATCH,")
            sb.Append("GPCR_BATCHDATE,")
            sb.Append("GPCR_REJECT_TYPE,")
            sb.Append("CREATEDBY,")
            sb.Append("CREATEDDATE,")
            sb.Append("UPDATEDBY,")
            sb.Append("UPDATEDDATE) ")
            sb.Append("SELECT ")
            sb.Append("GPCR_CREATEDATE,")
            sb.Append("GPCR_CORE_SYSTEM,")
            sb.Append("GPCR_TRANSREF,")
            sb.Append("GPCR_GPTREF_SEQNO,")
            sb.Append("GPCR_POLNO,")
            sb.Append("GPCR_BILLNO,")
            sb.Append("GPCR_PAIDDATE,")
            sb.Append("GPCR_AMOUNT,")
            sb.Append("GPCR_DESC,")
            sb.Append("GPCR_PAYMTH,")
            sb.Append("GPCR_PAYEE_NAME,")
            sb.Append("GPCR_BNKCODE,")
            sb.Append("GPCR_BNKCODE_NO,")
            sb.Append("GPCR_BNKBRN,")
            sb.Append("GPCR_BNKNAME,")
            sb.Append("GPCR_PAYEE_BNKACCNO,")
            sb.Append("GPCR_PAYEE_BNKACCNME,")
            sb.Append("GPCR_COMMENT,")
            sb.Append("GPCR_ADDRESS1,")
            sb.Append("GPCR_DISTRICT,")
            sb.Append("GPCR_PROVINCE,")
            sb.Append("GPCR_INSURENAME,")
            sb.Append("GPCR_DATASOURCE_NME,")
            sb.Append("GPCR_RESERVE6,")
            sb.Append("GPCR_MERCHN_NO,")
            sb.Append("GPCR_CDCARD_DATE,")
            sb.Append("GPCR_RESERVE9,")
            sb.Append("GPCR_RESERVE10,")
            sb.Append("GPCR_SYS_REF,")
            sb.Append("GPCR_SYS_GR,")
            sb.Append("GPCR_SUB_PAYMTH,")
            sb.Append("GPCR_FLAG_FLWBILL,")
            sb.Append("GPCR_OSEA_LIST,")
            sb.Append("GPCR_PHONE,")
            sb.Append("GPCR_FAX,")
            sb.Append("GPCR_SWIFT_CODE,")
            sb.Append("GPCR_BNKBRN_NAME,")
            sb.Append("GPCR_BNKADDR,")
            sb.Append("GPCR_COUNTRY,")
            sb.Append("GPCR_CURRENCY,")
            sb.Append("GPCR_EXCHN_RATE,")
            sb.Append("GPCR_BNKCHARGES,")
            sb.Append("GPCR_APPROVEDBY,")
            sb.Append("GPCR_APPROVEDDATE,")
            sb.Append("GPCR_FLAG_VALIDATE,")
            sb.Append("GPCR_FLAG_BATCH,")
            sb.Append("GPCR_BATCHDATE,")
            sb.Append("GPCR_REJECT_TYPE,")
            sb.Append("CREATEDBY,")
            sb.Append("CREATEDDATE,")
            sb.Append("UPDATEDBY,")
            sb.Append("UPDATEDDATE ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION WHERE CREATEDBY='" & gUserLogin & "' ")

            rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

            If rec >= 0 Then
                ret = True
            Else
                ret = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)

            ret = False
        End Try
        Return ret
    End Function
    Function TmpToTable_WHT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal gUserLogin As String) As Boolean
        Dim ret As Boolean
        Dim rec As Double
        Dim sb As New StringBuilder

        sb.Append("INSERT INTO GPS_WHT_CREATION (")
        sb.Append("TAXCR_CREATEDATE,")
        sb.Append("TAXCR_CORE_SYSTEM,")
        sb.Append("TAXCR_TRANSREF,")
        sb.Append("TAXCR_GPTREF_SEQNO,")
        sb.Append("TAXCR_LINENO,")
        sb.Append("TAXCR_TAXID,")
        sb.Append("TAXCR_IDCARD,")
        sb.Append("TAXCR_AP_TTL,")
        sb.Append("TAXCR_AP_FNAME,")
        sb.Append("TAXCR_AP_LNAME,")
        sb.Append("TAXCR_ADDRESS,")
        sb.Append("TAXCR_AMPENM,")
        sb.Append("TAXCR_PROVNM,")
        sb.Append("TAXCR_AGZIP,")
        sb.Append("TAXCR_TAXTYPE,")
        sb.Append("TAXCR_TAXITEM,")
        sb.Append("TAXCR_TAXDATE,")
        sb.Append("TAXCR_BASE_AMT,")
        sb.Append("TAXCR_TAX_AMT,")
        sb.Append("TAXCR_PAYEE,")
        sb.Append("TAXCR_TAX_RATE,")
        sb.Append("TAXCR_DESC,")
        sb.Append("TAXCR_GL_ACCOUNT,")
        sb.Append("TAXCR_APPROVEDBY,")
        sb.Append("TAXCR_APPROVEDDATE,")
        sb.Append("TAXCR_FLAG_VALIDATE,")
        sb.Append("TAXCR_FLAG_BATCH,")
        sb.Append("TAXCR_BATCHDATE,")
        sb.Append("TAXCR_REJECT_TYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE,")
        sb.Append("TAXCR_SUB_ACCT) ")
        sb.Append("SELECT ")
        sb.Append("TAXCR_CREATEDATE,")
        sb.Append("TAXCR_CORE_SYSTEM,")
        sb.Append("TAXCR_TRANSREF,")
        sb.Append("TAXCR_GPTREF_SEQNO,")
        sb.Append("TAXCR_LINENO,")
        sb.Append("TAXCR_TAXID,")
        sb.Append("TAXCR_IDCARD,")
        sb.Append("TAXCR_AP_TTL,")
        sb.Append("TAXCR_AP_FNAME,")
        sb.Append("TAXCR_AP_LNAME,")
        sb.Append("TAXCR_ADDRESS,")
        sb.Append("TAXCR_AMPENM,")
        sb.Append("TAXCR_PROVNM,")
        sb.Append("TAXCR_AGZIP,")
        sb.Append("TAXCR_TAXTYPE,")
        sb.Append("TAXCR_TAXITEM,")
        sb.Append("TAXCR_TAXDATE,")
        sb.Append("TAXCR_BASE_AMT,")
        sb.Append("TAXCR_TAX_AMT,")
        sb.Append("TAXCR_PAYEE,")
        sb.Append("TAXCR_TAX_RATE,")
        sb.Append("TAXCR_DESC,")
        sb.Append("TAXCR_GL_ACCOUNT,")
        sb.Append("TAXCR_APPROVEDBY,")
        sb.Append("TAXCR_APPROVEDDATE,")
        sb.Append("TAXCR_FLAG_VALIDATE,")
        sb.Append("TAXCR_FLAG_BATCH,")
        sb.Append("TAXCR_BATCHDATE,")
        sb.Append("TAXCR_REJECT_TYPE,")
        sb.Append("CREATEDBY,")
        sb.Append("CREATEDDATE,")
        sb.Append("UPDATEDBY,")
        sb.Append("UPDATEDDATE,")
        sb.Append("TAXCR_SUB_ACCT ")
        sb.Append("FROM GPS_TMP_WHT_CREATION WHERE CREATEDBY='" & gUserLogin & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            ret = True
        Else
            ret = False
        End If
        Return ret
    End Function
    Function LookUpHoliday(ByRef oleConn As OleDbConnection, ByVal d_start As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("SELECT COUNT(*) AS CHK FROM GPS_HOLIDAY_SETUP WHERE HLDS_HOLIDAY_DATE = '" & d_start & "'  AND HLDS_COMPANY_CODE='SCBLIFE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)("CHK") > 0 Then
                Return True
            Else
                Return False
            End If

        Else
            Return False
        End If

    End Function
    Function CHK_BKMST_BNKCODE(ByRef oleConn As OleDbConnection, ByVal bnkcode_no As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("SELECT BKMST_BNKCODE FROM GPS_TL_BANKMASTER WHERE BKMST_BNKCODE_NO='" & bnkcode_no & "' AND BKMST_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Function CHK_BNKS_BNKSCODE_NO(ByRef oleConn As OleDbConnection, ByVal pay_grp As String, ByVal bnkcode_no As String) As Boolean

        Dim sb As New StringBuilder()
        sb.Append("select * from GPS_TL_BANKSERVICE1 WHERE BNKS_PAY_GROUP ='" & pay_grp & "' AND BNKS_BNKSCODE_NO='" & bnkcode_no & "'")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Public Function fValidate_TaxType(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select * from GPS_TMP_WHT_CREATION where taxcr_createdate='" & create_date & "' and taxcr_core_system='" & core_system & "' and taxcr_transref='" & transref & "' and (taxcr_taxtype='' or taxcr_taxtype is null) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidate_TaxType = Ds.Tables(0)

        Catch ex As Exception
            fValidate_TaxType = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function fValidate_TaxID(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select * from GPS_TMP_WHT_CREATION where taxcr_createdate='" & create_date & "' and taxcr_core_system='" & core_system & "' and taxcr_transref='" & transref & "'  ")
            sb.Append("and (taxcr_taxid='' or taxcr_taxid is null or length(taxcr_taxid) <>13) and (taxcr_idcard='' or taxcr_idcard is null or length(taxcr_idcard) <>13)")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidate_TaxID = Ds.Tables(0)

        Catch ex As Exception
            fValidate_TaxID = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function fValidate_DescGP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select * from GPS_TMP_PAYMENT_CREATION where gpcr_createdate='" & create_date & "' and gpcr_core_system='" & core_system & "' and gpcr_transref='" & transref & "'  ")
            sb.Append("and (gpcr_desc is null or  gpcr_desc='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidate_DescGP = Ds.Tables(0)

        Catch ex As Exception
            fValidate_DescGP = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function fValidateDuplicateTransRef_2(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT TREF_TRANSREF FROM GPS_TRANSREF_REL WHERE TREF_TRANSREF='" & transref & "' AND TREF_CREATEDATE = '" & create_date & "' AND TREF_CORE_SYSTEM = '" & core_system & "' ")

            sb.Append("SELECT TREF_TRANSREF FROM GPS_TRANSREF_REL WHERE TREF_TRANSREF='" & transref & "' AND (TREF_CREATEDATE <> '" & create_date & "' OR TREF_CORE_SYSTEM<>'" & core_system & "') ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateDuplicateTransRef_2 = Ds.Tables(0)

        Catch ex As Exception
            fValidateDuplicateTransRef_2 = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function fValidateTransrefError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("SELECT A.GPCR_CREATEDATE, A.GPCR_CORE_SYSTEM, A.GPCR_TRANSREF, B.DTS_DTSOURCE, COUNT(A.GPCR_GPTREF_SEQNO) AS NO_RECORD ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION A LEFT JOIN (SELECT DTS_CORE_SYSTEM, DTS_DTSOURCE  ")
            sb.Append("FROM GPS_TL_DATASOURCE ")
            sb.Append("GROUP BY DTS_CORE_SYSTEM, DTS_DTSOURCE) B ON A.GPCR_CORE_SYSTEM=B.DTS_CORE_SYSTEM AND ")
            sb.Append("SUBSTR(A.GPCR_TRANSREF,1,3)=B.DTS_DTSOURCE ")
            sb.Append("WHERE A.CREATEDBY='" & userlogin & "'  AND (LENGTH(A.GPCR_TRANSREF)>15 OR B.DTS_DTSOURCE IS NULL) ")
            sb.Append("GROUP BY A.GPCR_CREATEDATE, A.GPCR_CORE_SYSTEM, A.GPCR_TRANSREF, B.DTS_DTSOURCE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateTransrefError = Ds.Tables(0)

        Catch ex As Exception
            fValidateTransrefError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatePaidDateError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAIDDATE,T.PAYT_PAY_GROUP  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GPCR_PAYMTH=T.PAYT_PAYMTH AND P.GPCR_SUB_PAYMTH=T.PAYT_SUB_PAYMTH  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidDateError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidDateError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatePaidAmountError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT GPCR_CREATEDATE,GPCR_CORE_SYSTEM,GPCR_TRANSREF,GPCR_GPTREF_SEQNO,GPCR_AMOUNT  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND GPCR_AMOUNT IS NULL OR GPCR_AMOUNT <=0  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaidAmountError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaidAmountError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateBankCodeError(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal paymth As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,P.GPCR_BNKCODE_NO,T.PAYT_PAY_GROUP,P.GPCR_PAYEE_BNKACCNO    ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P INNER JOIN GPS_TL_PAYTYPE T   ")
            sb.Append("ON P.GPCR_PAYMTH=T.PAYT_PAYMTH AND P.GPCR_SUB_PAYMTH=T.PAYT_SUB_PAYMTH   ")
            sb.Append("LEFT JOIN GPS_TL_BANKMASTER B ")
            sb.Append("ON P.GPCR_BNKCODE_NO=B.BKMST_BNKCODE_NO AND B.BKMST_STATUS='ACTIVE'  ")

            If paymth = "C" Or paymth = "D" Then
                sb.Append("LEFT JOIN GPS_TL_BANKSERVICE1 S ON S.BNKS_PAY_GROUP =T.PAYT_PAY_GROUP AND S.BNKS_BNKSCODE_NO=P.GPCR_BNKCODE_NO ")
            End If

            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND B.BKMST_BNKCODE_NO IS NULL  ")

            If paymth = "C" Or paymth = "D" Then
                sb.Append("AND S.BNKS_BNKSCODE_NO IS NULL ")
            End If

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankCodeError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankCodeError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateBankAccountError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE, ")
            sb.Append("       P.GPCR_CORE_SYSTEM, ")
            sb.Append("       P.GPCR_TRANSREF, ")
            sb.Append("       P.GPCR_GPTREF_SEQNO, ")
            sb.Append("       P.GPCR_PAYMTH, ")
            sb.Append("       P.GPCR_SUB_PAYMTH, ")
            sb.Append("       P.GPCR_PAYEE_BNKACCNO ")
            sb.Append("  FROM GPS_TMP_PAYMENT_CREATION P ")
            sb.Append("  LEFT JOIN GPS_TL_BANKMASTER B ")
            sb.Append("    ON P.GPCR_BNKCODE_NO = B.BKMST_BNKCODE_NO ")
            sb.Append("   AND B.BKMST_STATUS = 'ACTIVE' ")
            sb.Append(" WHERE P.CREATEDBY = '" & userlogin & "' ")
            sb.Append(" AND ((P.GPCR_PAYMTH = 'M' AND GPCR_PAYEE_BNKACCNO IS NULL) ")
            sb.Append("        OR (P.GPCR_PAYMTH = 'M' AND GPCR_PAYEE_BNKACCNO = '') ")
            sb.Append("        OR (LENGTH(TRIM(P.GPCR_PAYEE_BNKACCNO)) < 10) ")
            sb.Append("        OR (P.GPCR_PAYMTH = 'M' AND DECODE((REPLACE(TRANSLATE(TRIM(GPCR_PAYEE_BNKACCNO),'0123456789','00000000000'), '0', NULL)),NULL,'NUMBER','CHAR') = 'CHAR') ")
            sb.Append("        OR (P.GPCR_PAYMTH = 'M' AND P.GPCR_SUB_PAYMTH = 'C' AND LENGTH(GPCR_PAYEE_BNKACCNO) <> 16) ")
            sb.Append("        OR (P.GPCR_PAYMTH = 'M' AND B.BKMST_BNKCODE_NO IS NULL)   ")
            sb.Append("        ) ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateBankAccountNameError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,P.GPCR_PAYEE_BNKACCNME   ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P   ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH='M' ")
            sb.Append("AND (P.GPCR_PAYEE_BNKACCNME IS NULL OR TRIM(GPCR_PAYEE_BNKACCNME)='') ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateBankAccountNameError = Ds.Tables(0)

        Catch ex As Exception
            fValidateBankAccountNameError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatePayeeNameError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,P.GPCR_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P    ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_PAYEE_NAME IS NULL OR TRIM(P.GPCR_PAYEE_NAME)='') ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeNameError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeNameError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatePayeeLengthFieldError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,P.GPCR_PAYEE_NAME    ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P    ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND ((P.GPCR_PAYMTH='C' OR P.GPCR_PAYMTH='D') AND LENGTH(P.GPCR_PAYEE_NAME) > 100) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePayeeLengthFieldError = Ds.Tables(0)

        Catch ex As Exception
            fValidatePayeeLengthFieldError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateAddressError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,  ")
            sb.Append("P.GPCR_ADDRESS1||P.GPCR_DISTRICT||P.GPCR_PROVINCE AS ADDRESS  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P    ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_ADDRESS1||P.GPCR_DISTRICT||P.GPCR_PROVINCE IS NULL OR P.GPCR_ADDRESS1||P.GPCR_DISTRICT||P.GPCR_PROVINCE ='' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateAddressError = Ds.Tables(0)

        Catch ex As Exception
            fValidateAddressError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateMerchantError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYMTH,P.GPCR_SUB_PAYMTH,B.BNKS_MERCHN_NO     ")
            sb.Append("FROM (GPS_TMP_PAYMENT_CREATION P INNER JOIN GPS_TL_PAYTYPE T  ")
            sb.Append("ON P.GPCR_PAYMTH=T.PAYT_PAYMTH AND P.GPCR_SUB_PAYMTH=T.PAYT_SUB_PAYMTH)  ")
            sb.Append("LEFT JOIN GPS_TL_BANKSERVICE2 B  ")
            sb.Append("ON P.GPCR_MERCHN_NO=B.BNKS_MERCHN_NO AND B.BNKS_STATUS='ACTIVE'  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND T.PAYT_PAY_GROUP='CREDIT_CARD'  ")
            sb.Append("AND BNKS_MERCHN_NO IS NULL ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateMerchantError = Ds.Tables(0)

        Catch ex As Exception
            fValidateMerchantError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatSpecialCharacterError_OLD(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT GPCR_CREATEDATE,GPCR_CORE_SYSTEM,GPCR_TRANSREF,GPCR_GPTREF_SEQNO, GPCR_PAYEE_NAME, GPCR_ADDRESS1, GPCR_DISTRICT,  ")
            sb.Append("GPCR_PROVINCE, GPCR_PAYEE_BNKACCNME FROM GPS_TMP_PAYMENT_CREATION WHERE CREATEDBY='" & userlogin & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatSpecialCharacterError_OLD = Ds.Tables(0)

        Catch ex As Exception
            fValidatSpecialCharacterError_OLD = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatSpecialCharacterError(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select  a.*,b.spe_char ")
            sb.Append("from    GPS_TMP_PAYMENT_CREATION a ")
            sb.Append("        , GPS_TL_SPECIALCHAR b ")
            sb.Append("where  a.createdby='" & userlogin & "'  ")
            sb.Append("and trim(a.gpcr_payee_name||a.gpcr_address1||a.gpcr_district||a.gpcr_province||a.gpcr_payee_bnkaccnme) like '%' || B.SPE_CHAR || '%' ")
            sb.Append("and     B.SPE_CHAR not in ('%', '_') ")
            sb.Append("or      trim(a.gpcr_payee_name||a.gpcr_address1||a.gpcr_district||a.gpcr_province||a.gpcr_payee_bnkaccnme) like '%\%%' escape '\' ")
            sb.Append("or      trim(a.gpcr_payee_name||a.gpcr_address1||a.gpcr_district||a.gpcr_province||a.gpcr_payee_bnkaccnme) like '%\_%' escape '\' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatSpecialCharacterError = Ds.Tables(0)

        Catch ex As Exception
            fValidatSpecialCharacterError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateGPtrefSeqNo(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT * FROM ")
            sb.Append("(SELECT P.GPCR_GPTREF_SEQNO,W.TAXCR_GPTREF_SEQNO, ")
            sb.Append("CASE WHEN P.GPCR_GPTREF_SEQNO = W.TAXCR_GPTREF_SEQNO THEN 'TRUE' ELSE 'FALSE' END CHK ")
            sb.Append("FROM GPS_TMP_WHT_CREATION W LEFT JOIN GPS_TMP_PAYMENT_CREATION P ")
            sb.Append("ON W.TAXCR_CREATEDATE=P.GPCR_CREATEDATE ")
            sb.Append("AND W.TAXCR_CORE_SYSTEM=P.GPCR_CORE_SYSTEM ")
            sb.Append("AND W.TAXCR_TRANSREF=P.GPCR_TRANSREF ")
            sb.Append("AND W.TAXCR_GPTREF_SEQNO=P.GPCR_GPTREF_SEQNO ")
            sb.Append("WHERE W.CREATEDBY='" & userlogin & "') A ")
            sb.Append("WHERE A.CHK='FALSE' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateGPtrefSeqNo = Ds.Tables(0)

        Catch ex As Exception
            fValidateGPtrefSeqNo = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetSpecialCharacter(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT SPE_CHAR FROM GPS_TL_SPECIALCHAR ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetSpecialCharacter = Ds.Tables(0)

        Catch ex As Exception
            GetSpecialCharacter = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function UPD_SPE_CHAR(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal spetxt As String, ByVal errtype As String, ByVal create_date As String, ByVal core_system As String, ByVal transref As String, ByVal seq As String) As Integer

        Dim sb As New StringBuilder
        Dim rec As Integer

        sb.Append("UPDATE GPS_TMP_PAYMENT_CREATION SET gpcr_payee_name=replace(gpcr_payee_name,'" & spetxt & "',' '), ")
        sb.Append("gpcr_address1=replace(gpcr_address1,'" & spetxt & "',' '), ")
        sb.Append("gpcr_district=replace(gpcr_district,'" & spetxt & "',' '), ")
        sb.Append("gpcr_province=replace(gpcr_province,'" & spetxt & "',' '), ")
        sb.Append("gpcr_payee_bnkaccnme=replace(gpcr_payee_bnkaccnme,'" & spetxt & "',' '), ")
        sb.Append("GPCR_REJECT_TYPE='" & errtype & "' ")
        sb.Append("WHERE GPCR_CREATEDATE ='" & create_date & "' AND GPCR_CORE_SYSTEM='" & core_system & "' AND GPCR_TRANSREF='" & transref & "'  and GPCR_GPTREF_SEQNO ='" & seq & "'")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function fValidatWatchLists(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_GPTREF_SEQNO,P.GPCR_PAYEE_NAME, P.GPCR_PAYMTH, P.GPCR_POLNO, P.GPCR_AMOUNT, P.GPCR_PAYEE_BNKACCNME, P.GPCR_PAIDDATE     ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION P   ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatWatchLists = Ds.Tables(0)

        Catch ex As Exception
            fValidatWatchLists = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Function CHECK_WATCHLIST_FOR_REJ(ByRef oleConn As OleDbConnection, ByVal payeename As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            'sb.Append("SELECT WLSTT_TYPE,WLST_SUBTYPE_CODE ,WLST_CHK_NAME  ")
            'sb.Append("FROM  ")
            'sb.Append("( ")
            'sb.Append("SELECT T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE,MAX(WLST_LOADDATE)   ")
            'sb.Append("FROM GPS_WATCHLISTS_MA1 W INNER JOIN GPS_TL_WATCHLISTS_TYPE T ")
            'sb.Append("ON W.WLST_SUBTYPE_CODE=T.WLSTT_SUBTYPE ")
            'sb.Append("WHERE W.WLST_SUBTYPE_CODE  IN ('BANK', 'FT01', 'FT02') ")
            'sb.Append("GROUP BY T.WLSTT_TYPE,W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,WLST_REJ_CODE  ")
            'sb.Append(")T ")
            'sb.Append("WHERE WLST_REJ_CODE='01' ")
            'sb.Append("AND INSTR('" & payeename & "',WLST_CHK_NAME) >0 ")


            sb.Append("SELECT * FROM ")
            sb.Append("(SELECT W.WLST_SUBTYPE_CODE ,W.WLST_CHK_NAME,MAX(WLST_LOADDATE) AS WLST_LOADDATE    ")
            sb.Append("FROM GPS_WATCHLISTS_MA1 W  ")
            sb.Append("WHERE W.WLST_SUBTYPE_CODE  IN ('BANK', 'FT01', 'FT02')  ")
            sb.Append("GROUP BY W.WLST_SUBTYPE_CODE,W.WLST_CHK_NAME)A ")
            sb.Append("INNER JOIN GPS_WATCHLISTS_MA1 B ")
            sb.Append("ON A.WLST_SUBTYPE_CODE=B.WLST_SUBTYPE_CODE ")
            sb.Append("AND A.WLST_CHK_NAME=B.WLST_CHK_NAME ")
            sb.Append("AND A.WLST_LOADDATE=B.WLST_LOADDATE ")
            sb.Append("AND B.WLST_REJ_CODE='01' ")
            sb.Append("AND INSTR('" & payeename & "',B.WLST_CHK_NAME) >0 ")



            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            CHECK_WATCHLIST_FOR_REJ = Ds.Tables(0)

        Catch ex As Exception
            CHECK_WATCHLIST_FOR_REJ = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try


    End Function
    Function CHECK_WATCHLIST_FOR_REJ_NEW(ByRef oleConn As OleDbConnection _
                                         , ByRef strCoreSystem As String _
                                         , ByRef strCreateDate As String _
                                         , ByRef strPolicyNo As String _
                                         , ByRef dblAmount As Double _
                                         , ByRef strPaymentMTH As String _
                                         , ByVal strPayeeName As String _
                                         , ByVal strPayeeBankAccountName As String _
                                         ) As DataTable

        Dim sb As New StringBuilder()
        Dim Ds As New DataSet
        Dim _strPayeeName As String
        Dim _strSQL As String

        Try
            '1. Check payment method 
            If strPaymentMTH = "M" Then
                _strPayeeName = strPayeeBankAccountName
            Else
                _strPayeeName = strPayeeName
            End If
            _strPayeeName.Replace(" ", "")
            '2. Check Individual or Corporate and Generate SQL statement
            If InStr(1, _strPayeeName, "��", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName, "��ҧ�����ǹ", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName, "����ѷ", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName, "���", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName, "˨�", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName.ToUpper, "PCL", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName.ToUpper, "LTD", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName.ToUpper, "LIMITED", CompareMethod.Text) > 0 _
                Or InStr(1, _strPayeeName.ToUpper, "COMPANY", CompareMethod.Text) > 0 _
                Then
                _strSQL = BUILD_SQL_CHECK_WATCHLIST_CORPORATE(_strPayeeName _
                                                              , strCoreSystem _
                                                              , strCreateDate _
                                                              , strPolicyNo _
                                                              , dblAmount)
            Else
                _strSQL = BUILD_SQL_CHECK_WATCHLIST_INDIVIDUAL(_strPayeeName _
                                                              , strCoreSystem _
                                                              , strCreateDate _
                                                              , strPolicyNo _
                                                              , dblAmount)
            End If
            '3. Execute SQL statement for check
            sb.Append(_strSQL)
            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            CHECK_WATCHLIST_FOR_REJ_NEW = Ds.Tables(0)

        Catch ex As Exception
            CHECK_WATCHLIST_FOR_REJ_NEW = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try


    End Function

    Private Function BUILD_SQL_CHECK_WATCHLIST_INDIVIDUAL(ByRef strPayeeName As String _
                                         , ByRef strCoreSystem As String _
                                         , ByRef strCreateDate As String _
                                         , ByRef strPolicyNo As String _
                                         , ByRef dblAmount As Double _
                                         ) As String
        Dim strSQL As New StringBuilder
        Try

            strSQL.Append("Select WLST_CHK_NAME ")
            strSQL.Append("  FROM (SELECT WLST_CHK_NAME, WLST_SUBTYPE_CODE ")
            strSQL.Append("            FROM(GENERATEPAYMENT.GPS_WATCHLISTS_MA1) ")
            strSQL.Append("         WHERE WLST_SUBTYPE_CODE IN ('BANK', 'FT01', 'FT02') ")
            strSQL.Append("           AND WLST_REJ_CODE = '01' ")
            strSQL.Append("           AND LENGTH(NVL(WLST_FNAME, '#')) > 1 ")
            strSQL.Append("           AND LENGTH(NVL(WLST_LNAME, '#')) > 1 ")
            strSQL.Append("           AND WLST_LOADDATE = ")
            strSQL.Append("                        ( ")
            strSQL.Append("                          Select MAX(WLST_LOADDATE) ")
            strSQL.Append("                            FROM (SELECT WLST_LOADDATE, WLST_SUBTYPE_CODE, WLST_CHK_NAME FROM GENERATEPAYMENT.GPS_WATCHLISTS_MA1 WHERE WLST_SUBTYPE_CODE IN ('BANK', 'FT01', 'FT02')) WW ")
            strSQL.Append("                                 INNER JOIN GENERATEPAYMENT.GPS_TL_WATCHLISTS_TYPE TT ")
            strSQL.Append("                                         ON WW.WLST_SUBTYPE_CODE = TT.WLSTT_SUBTYPE ")
            '--strSQL.Append("                                        AND WW.WLST_CHK_NAME = WLST_CHK_NAME ")
            strSQL.Append("                                        AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLST_CHK_NAME) > 0 ")
            strSQL.Append("                        ) ")
            strSQL.Append("           AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLST_CHK_NAME) > 0 ")
            strSQL.Append("        ) W ")
            strSQL.Append("       INNER JOIN GENERATEPAYMENT.GPS_TL_WATCHLISTS_TYPE T ")
            strSQL.Append("               ON W.WLST_SUBTYPE_CODE = T.WLSTT_SUBTYPE ")
            strSQL.Append("  WHERE NOT EXISTS ")
            strSQL.Append("                ( ")
            strSQL.Append("                  SELECT WLSTP_FNAME||WLSTP_LNAME ")
            strSQL.Append("                    FROM GENERATEPAYMENT.GPS_WATCHLISTS_MA2  ")
            strSQL.Append("                   WHERE WLSTP_STATUS = 'ACTIVE' ")
            strSQL.Append("                     AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLSTP_FNAME||WLSTP_LNAME) > 0 ")
            strSQL.Append("                     AND '" & strCreateDate.ToString.Trim & "' BETWEEN WLSTP_S_EFFDATE AND WLSTP_E_EFFDATE ")
            strSQL.Append("                     AND ")
            If strCoreSystem = "TLM" Then
                strSQL.Append("                          (WLSTP_POLNO = '" & strPolicyNo.ToString.Trim & "') ")
            Else
                strSQL.Append("                          (WLSTP_AMOUNT = " & dblAmount.ToString.Trim & ") ")
            End If
            strSQL.Append("                ) ")

            Return strSQL.ToString

        Catch ex As Exception
            Return "error"
        End Try
    End Function

    Private Function BUILD_SQL_CHECK_WATCHLIST_CORPORATE(ByRef strPayeeName As String _
                                         , ByRef strCoreSystem As String _
                                         , ByRef strCreateDate As String _
                                         , ByRef strPolicyNo As String _
                                         , ByRef dblAmount As Double _
                                         ) As String
        Dim strSQL As New StringBuilder
        Try

            strSQL.Append("Select WLST_CHK_NAME ")
            strSQL.Append("  FROM (SELECT WLST_CHK_NAME, WLST_SUBTYPE_CODE ")
            strSQL.Append("            FROM(GENERATEPAYMENT.GPS_WATCHLISTS_MA1) ")
            strSQL.Append("         WHERE WLST_SUBTYPE_CODE IN ('BANK', 'FT01', 'FT02') ")
            strSQL.Append("           AND WLST_REJ_CODE = '01' ")
            strSQL.Append("           AND LENGTH(NVL(WLST_FNAME, '#')) > 1 ")
            strSQL.Append("           and NVL(WLST_LNAME, '#') = '#' ")
            strSQL.Append("           AND WLST_LOADDATE = ")
            strSQL.Append("                        ( ")
            strSQL.Append("                          Select MAX(WLST_LOADDATE) ")
            strSQL.Append("                            FROM (SELECT WLST_LOADDATE, WLST_SUBTYPE_CODE, WLST_CHK_NAME FROM GENERATEPAYMENT.GPS_WATCHLISTS_MA1 WHERE WLST_SUBTYPE_CODE IN ('BANK', 'FT01', 'FT02')) WW ")
            strSQL.Append("                                 INNER JOIN GENERATEPAYMENT.GPS_TL_WATCHLISTS_TYPE TT ")
            strSQL.Append("                                         ON WW.WLST_SUBTYPE_CODE = TT.WLSTT_SUBTYPE ")
            '--strSQL.Append("                                        AND WW.WLST_CHK_NAME = WLST_CHK_NAME ")
            strSQL.Append("                                        AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLST_CHK_NAME) > 0 ")
            strSQL.Append("                        ) ")
            strSQL.Append("           AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLST_CHK_NAME) > 0 ")
            strSQL.Append("        ) W ")
            strSQL.Append("       INNER JOIN GENERATEPAYMENT.GPS_TL_WATCHLISTS_TYPE T ")
            strSQL.Append("               ON W.WLST_SUBTYPE_CODE = T.WLSTT_SUBTYPE ")
            strSQL.Append("  WHERE NOT EXISTS ")
            strSQL.Append("                ( ")
            strSQL.Append("                  SELECT WLSTP_FNAME||WLSTP_LNAME ")
            strSQL.Append("                    FROM GENERATEPAYMENT.GPS_WATCHLISTS_MA2  ")
            strSQL.Append("                   WHERE WLSTP_STATUS = 'ACTIVE' ")
            strSQL.Append("                     AND INSTR( '" & strPayeeName.ToString.Replace(" ", "") & "', WLSTP_FNAME||WLSTP_LNAME) > 0 ")
            strSQL.Append("                     AND '" & strCreateDate.ToString.Trim & "' BETWEEN WLSTP_S_EFFDATE AND WLSTP_E_EFFDATE ")
            strSQL.Append("                     AND ")
            If strCoreSystem = "TLM" Then
                strSQL.Append("                          (WLSTP_POLNO = '" & strPolicyNo.ToString.Trim & "') ")
            Else
                strSQL.Append("                          (WLSTP_AMOUNT = " & dblAmount.ToString.Trim & ") ")
            End If
            strSQL.Append("                ) ")

            Return strSQL.ToString

        Catch ex As Exception
            Return "error"
        End Try
    End Function

    Function CHECK_WATCHLIST_EFFDATE(ByRef oleConn As OleDbConnection, ByVal payeename As String, ByVal batchdate As String) As Boolean

        Dim sb As New StringBuilder()

        sb.Append("SELECT * FROM GPS_WATCHLISTS_MA2 ")
        sb.Append("WHERE INSTR('" & payeename & "',WLSTP_FNAME||WLSTP_LNAME) >0 ")
        sb.Append("AND '" & batchdate & "' BETWEEN WLSTP_S_EFFDATE AND WLSTP_E_EFFDATE ")
        sb.Append("AND WLSTP_STATUS='ACTIVE' ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)
        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    'Approve Validate
    Public Function fnNetAmountError(ByRef oleConn As OleDbConnection, ByVal user As String) As Boolean
        Dim ret As Boolean
        Dim dt As New DataTable

        dt = ChkNetAmountError(oleConn, user)

        If dt.Rows.Count > 0 Then
            'ret_RejectCode = "PAMT_ERR"
            ret = False
        Else
            ret = True
            'ret_RejectCode = ""
        End If
        Return ret

    End Function
    Public Function fnPaidDateNotMatch(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean
        Dim strPaidDate_GP, strPaidDate_GLGP, strPaidDate_WHT, strPaidDate_GLWHT As String 'strPaidDate_WHT,strPaidDate_GLWHT

        strPaidDate_GLGP = GetPaidDate_GLGP(oleConn, create_date, core_system, transref)
        strPaidDate_GLWHT = GetPaidDate_GLWHT(oleConn, create_date, core_system, transref)
        strPaidDate_GP = GetPaidDate_GP(oleConn, create_date, core_system, transref)
        strPaidDate_WHT = GetPaidDate_WHT(oleConn, create_date, core_system, transref)

        If (strPaidDate_GLGP <> strPaidDate_GP) Or (strPaidDate_GLWHT <> strPaidDate_WHT) Then
            ret = False
        Else
            ret = True
        End If
        Return ret

    End Function
    Public Function fnPaidDateErr(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String, ByVal keyid As String, ByVal busDate As String) As Boolean
        Dim ret As Boolean = True
        Dim strPaidDate_GP, strPaidDate_GLGP As String 'strPaidDate_WHT,strPaidDate_GLWHT

        strPaidDate_GLGP = GetPaidDate_GLGP(oleConn, create_date, core_system, transref)
        strPaidDate_GP = GetPaidDate_GP(oleConn, create_date, core_system, transref)

        If keyid = "003" Then
            If strPaidDate_GLGP = busDate Then
                ret = True
            Else
                ret = False
            End If

            'pattamalin 2015/02/05 non pay ����ͧ validate
            'Else
            '    If strPaidDate_GLGP > busDate Then
            '        ret = True
            '    Else
            '        ret = False
            '    End If

        End If




        Return ret

    End Function
    Public Function fnPaidDateNotMatch_NONPAY(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean
        Dim strPaidDate_GLWHT, strPaidDate_WHT As String

        'strPaidDate_GLGP = GetPaidDate_GLGP(oleConn, create_date, core_system, transref)
        strPaidDate_GLWHT = GetPaidDate_GLWHT(oleConn, create_date, core_system, transref)
        'strPaidDate_GP = GetPaidDate_GP(oleConn, create_date, core_system, transref)
        strPaidDate_WHT = GetPaidDate_WHT(oleConn, create_date, core_system, transref)

        If (strPaidDate_GLWHT <> strPaidDate_WHT) Then
            ret = False

        Else

            ret = True
        End If
        Return ret

    End Function
    Public Function fnNetAmountNotMatch_Creation(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean
        Dim sum_gp, sum_gl_amount, sum_gl_amount_one_gl As Double ', sum_gl_wht, sum_wht

        sum_gp = GET_SUM_GP_CR(oleConn, create_date, core_system, transref)
        sum_gl_amount = GET_SUM_GL_AMOUNT_CR(oleConn, create_date, core_system, transref)
        sum_gl_amount_one_gl = GET_SUM_GL_AMOUNT_CR_ONE_GL(oleConn, create_date, core_system, transref)

        If (sum_gp <> sum_gl_amount) Then ' Or (sum_gl_wht <> sum_wht) Then
            ret = False
            'ret_RejectCode = "PAMT_NOMAT"
            If (sum_gp <> sum_gl_amount_one_gl) Then
                ret = False
            Else
                ret = True
            End If
        Else
            'ret_RejectCode = ""
            ret = True
        End If

        'MsgBox(sum_gp.ToString & vbCrLf & sum_gl_amount.ToString & vbCrLf & sum_gl_amount_one_gl.ToString & vbCrLf & ret.ToString)

        Return ret

    End Function

    Public Function fnNetAmountNotMatch(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean
        Dim sum_gp, sum_gl_amount, sum_gl_amount_one_gl As Double ', sum_gl_wht, sum_wht
        sum_gp = GET_SUM_GP(oleConn, create_date, core_system, transref)
        sum_gl_amount = GET_SUM_GL_AMOUNT(oleConn, create_date, core_system, transref)
        sum_gl_amount_one_gl = GET_SUM_GL_AMOUNT_ONE_GL(oleConn, create_date, core_system, transref)
        'sum_gl_wht = GET_SUM_GL_WHT(oleConn, create_date, core_system, transref)
        'sum_wht = GET_SUM_WHT(oleConn, create_date, core_system, transref)

        If (sum_gp <> sum_gl_amount) Then ' Or (sum_gl_wht <> sum_wht) Then
            ret = False
            'ret_RejectCode = "PAMT_NOMAT"
            If (sum_gp <> sum_gl_amount_one_gl) Then
                ret = False
            Else
                ret = True
            End If
        Else
            'ret_RejectCode = ""
            ret = True
        End If

        '--MsgBox(ret.ToString)

        Return ret

    End Function
    Public Function fnNetAmountNotMatch_NONPAY(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Boolean
        Dim ret As Boolean
        Dim sum_gl_wht, sum_wht As Double ', sum_gl_wht, sum_wht

        sum_gl_wht = GET_SUM_GL_WHT(oleConn, create_date, core_system, transref)
        sum_wht = GET_SUM_WHT(oleConn, create_date, core_system, transref)

        If (sum_gl_wht <> sum_wht) Then
            ret = False
            'ret_RejectCode = "PAMT_NOMAT"
        Else
            'ret_RejectCode = ""
            ret = True
        End If

        Return ret

    End Function
    Public Function fnValidateWHTAmountNotMatch_CR(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CASE WHEN A.TAXCR_CREATEDATE IS NULL THEN B.GLCR_CREATEDATE ELSE A.TAXCR_CREATEDATE END AS GP_CREATEDATE,   ")
            sb.Append("CASE WHEN A.TAXCR_CORE_SYSTEM IS NULL THEN  B.GLCR_CORE_SYSTEM ELSE A.TAXCR_CORE_SYSTEM END AS GP_CORE_SYSTEM,   ")
            sb.Append("CASE WHEN A.TAXCR_TRANSREF IS NULL THEN  B.GLCR_TRANSREF ELSE A.TAXCR_TRANSREF END AS GP_TRANSREF,   ")
            sb.Append("A.NO_RECORD, A.TAX_AMOUNT, B.GL_TAX_AMOUNT  ")
            sb.Append("FROM (SELECT TAXCR_CREATEDATE, TAXCR_CORE_SYSTEM, TAXCR_TRANSREF, COUNT(TAXCR_LINENO) AS NO_RECORD, SUM(TAXCR_TAX_AMT) AS TAX_AMOUNT   ")
            sb.Append("FROM GPS_TMP_WHT_CREATION  ")
            sb.Append("WHERE TAXCR_CREATEDATE='" & create_date & "' AND TAXCR_CORE_SYSTEM='" & core_system & "' AND TAXCR_TRANSREF='" & transref & "'  ")
            sb.Append("GROUP BY TAXCR_CREATEDATE, TAXCR_CORE_SYSTEM, TAXCR_TRANSREF) A   ")
            sb.Append("FULL JOIN  ")
            sb.Append("(SELECT GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF, SUM(GL1.GLCR_AMOUNT) AS GL_TAX_AMOUNT   ")
            sb.Append("FROM GPS_TMP_GL_CREATION GL1  ")
            sb.Append("WHERE GLCR_CREATEDATE='" & create_date & "' AND GLCR_CORE_SYSTEM='" & core_system & "'AND GLCR_TRANSREF='" & transref & "'   AND GL1.GLCR_DRCR='C' AND SUBSTR(GL1.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF) B   ")
            sb.Append("ON A.TAXCR_CREATEDATE =B.GLCR_CREATEDATE AND   ")
            sb.Append("A.TAXCR_CORE_SYSTEM=B.GLCR_CORE_SYSTEM AND  ")
            sb.Append("A.TAXCR_TRANSREF=B.GLCR_TRANSREF  ")
            sb.Append("WHERE NVL(A.TAX_AMOUNT,0) <> NVL(B.GL_TAX_AMOUNT,0)  ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnValidateWHTAmountNotMatch_CR = Ds.Tables(0)

        Catch ex As Exception
            fnValidateWHTAmountNotMatch_CR = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fnValidateWHTAmountNotMatch(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CASE WHEN A.TAXCR_CREATEDATE IS NULL THEN B.GLCR_CREATEDATE ELSE A.TAXCR_CREATEDATE END AS GP_CREATEDATE,   ")
            sb.Append("CASE WHEN A.TAXCR_CORE_SYSTEM IS NULL THEN  B.GLCR_CORE_SYSTEM ELSE A.TAXCR_CORE_SYSTEM END AS GP_CORE_SYSTEM,   ")
            sb.Append("CASE WHEN A.TAXCR_TRANSREF IS NULL THEN  B.GLCR_TRANSREF ELSE A.TAXCR_TRANSREF END AS GP_TRANSREF,   ")
            sb.Append("A.NO_RECORD, A.TAX_AMOUNT, B.GL_TAX_AMOUNT  ")
            sb.Append("FROM (SELECT TAXCR_CREATEDATE, TAXCR_CORE_SYSTEM, TAXCR_TRANSREF, COUNT(TAXCR_LINENO) AS NO_RECORD, SUM(TAXCR_TAX_AMT) AS TAX_AMOUNT   ")
            sb.Append("FROM GPS_WHT_CREATION  ")
            sb.Append("WHERE TAXCR_CREATEDATE='" & create_date & "' AND TAXCR_CORE_SYSTEM='" & core_system & "' AND TAXCR_TRANSREF='" & transref & "'  ")
            sb.Append("GROUP BY TAXCR_CREATEDATE, TAXCR_CORE_SYSTEM, TAXCR_TRANSREF) A   ")
            sb.Append("FULL JOIN  ")
            sb.Append("(SELECT GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF, SUM(GL1.GLCR_AMOUNT) AS GL_TAX_AMOUNT   ")
            sb.Append("FROM GPS_GL_CREATION GL1  ")
            'sb.Append("WHERE GLCR_CREATEDATE='" & create_date & "' AND GLCR_CORE_SYSTEM='" & core_system & "'AND GLCR_TRANSREF='" & transref & "'   AND GL1.GLCR_DRCR='C' AND GL1.GLCR_S_TT_TR<>'00000000'  ")
            sb.Append("WHERE GLCR_CREATEDATE='" & create_date & "' AND GLCR_CORE_SYSTEM='" & core_system & "'AND GLCR_TRANSREF='" & transref & "'   AND GL1.GLCR_DRCR='C' AND SUBSTR(GL1.GLCR_S_TT_TR,1,2) IN ('02','03','53')  ")
            sb.Append("GROUP BY GL1.GLCR_CREATEDATE, GL1.GLCR_CORE_SYSTEM, GL1.GLCR_TRANSREF) B   ")
            sb.Append("ON A.TAXCR_CREATEDATE =B.GLCR_CREATEDATE AND   ")
            sb.Append("A.TAXCR_CORE_SYSTEM=B.GLCR_CORE_SYSTEM AND  ")
            sb.Append("A.TAXCR_TRANSREF=B.GLCR_TRANSREF  ")
            sb.Append("WHERE NVL(A.TAX_AMOUNT,0) <> NVL(B.GL_TAX_AMOUNT,0)  ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnValidateWHTAmountNotMatch = Ds.Tables(0)

        Catch ex As Exception
            fnValidateWHTAmountNotMatch = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkNetAmountError(ByRef oleConn As OleDbConnection, ByVal user As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select gpcr_amount ")
            sb.Append("from gps_tmp_payment_creation ")
            sb.Append("where createdby='" & user & "' and gpcr_amount <=0 ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkNetAmountError = Ds.Tables(0)
        Catch ex As Exception
            ChkNetAmountError = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_SUM_GP_CR(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select sum(gpcr_amount) as sum_gp ")
            sb.Append("from gps_tmp_payment_creation ")
            sb.Append("where gpcr_createdate='" & create_date & "' ")
            sb.Append("and gpcr_core_system='" & core_system & "' ")
            sb.Append("and gpcr_transref='" & transref & "' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GP_CR = Ds.Tables(0).Rows(0)("sum_gp")
        Catch ex As Exception
            GET_SUM_GP_CR = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_SUM_GP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select sum(gpcr_amount) as sum_gp ")
            sb.Append("from gps_payment_creation ")
            sb.Append("where gpcr_createdate='" & create_date & "' ")
            sb.Append("and gpcr_core_system='" & core_system & "' ")
            sb.Append("and gpcr_transref='" & transref & "' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GP = Ds.Tables(0).Rows(0)("sum_gp")
        Catch ex As Exception
            GET_SUM_GP = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_SUM_GL_AMOUNT_CR(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("select sum(glcr_amount) sum_gl_amount  ")
            sb.Append("from gps_tmp_gl_creation gl inner join glm_account_setup gl2  ")
            sb.Append("on gl.glcr_s_account=gl2.acnt_s_code   ")
            sb.Append("and  gl2.acnt_flag_acntpay='Y'  ")
            sb.Append("where gl.glcr_createdate='" & create_date & "'  ")
            sb.Append("and gl.glcr_core_system='" & core_system & "'  ")
            sb.Append("and gl.glcr_transref='" & transref & "'  ")
            sb.Append("and gl.glcr_drcr='C'  ")
            sb.Append("and gl.glcr_s_tt_tr='00000000' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GL_AMOUNT_CR = Ds.Tables(0).Rows(0)("sum_gl_amount")
        Catch ex As Exception
            GET_SUM_GL_AMOUNT_CR = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GET_SUM_GL_AMOUNT_CR_ONE_GL(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("select nvl(sum(glcr_amount),0) sum_gl_amount  ")
            sb.Append("from gps_tmp_gl_creation gl inner join (select tt.acnt_1gl_code, tt.acnt_1gl_scode, tt.acnt_flag_acntpay from glm_account_setup tt group by tt.acnt_1gl_code, tt.acnt_1gl_scode, tt.acnt_flag_acntpay ) gl2  ")
            '-- ONE GL -- sb.Append("on gl.glcr_s_account = gl2.acnt_s_code   ")
            sb.Append("on gl.glcr_s_account || gl.glcr_sub_acct = gl2.acnt_1gl_code || gl2.acnt_1gl_scode   ")

            sb.Append("and  gl2.acnt_flag_acntpay='Y'  ")
            sb.Append("where gl.glcr_createdate='" & create_date & "'  ")
            sb.Append("and gl.glcr_core_system='" & core_system & "'  ")
            sb.Append("and gl.glcr_transref='" & transref & "'  ")
            sb.Append("and gl.glcr_drcr='C'  ")
            sb.Append("and gl.glcr_s_tt_tr='00000000' ")

            'MsgBox(sb.ToString)

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GL_AMOUNT_CR_ONE_GL = Ds.Tables(0).Rows(0)("sum_gl_amount")
        Catch ex As Exception
            GET_SUM_GL_AMOUNT_CR_ONE_GL = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GET_SUM_GL_AMOUNT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("select sum(glcr_amount) sum_gl_amount  ")
            sb.Append("from gps_gl_creation gl inner join glm_account_setup gl2  ")
            sb.Append("on gl.glcr_s_account=gl2.acnt_s_code   ")
            sb.Append("and  gl2.acnt_flag_acntpay='Y'  ")
            sb.Append("where gl.glcr_createdate='" & create_date & "'  ")
            sb.Append("and gl.glcr_core_system='" & core_system & "'  ")
            sb.Append("and gl.glcr_transref='" & transref & "'  ")
            sb.Append("and gl.glcr_drcr='C'  ")
            sb.Append("and gl.glcr_s_tt_tr='00000000' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GL_AMOUNT = Ds.Tables(0).Rows(0)("sum_gl_amount")
        Catch ex As Exception
            GET_SUM_GL_AMOUNT = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GET_SUM_GL_AMOUNT_ONE_GL(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("select nvl(sum(glcr_amount),0) sum_gl_amount  ")
            sb.Append("from gps_gl_creation gl inner join (select tt.acnt_1gl_code, tt.acnt_1gl_scode, tt.acnt_flag_acntpay from glm_account_setup tt group by tt.acnt_1gl_code, tt.acnt_1gl_scode, tt.acnt_flag_acntpay ) gl2  ")
            '-- ONE GL -- sb.Append("on gl.glcr_s_account=gl2.acnt_s_code   ")
            sb.Append("on gl.glcr_s_account || gl.glcr_sub_acct = gl2.acnt_1gl_code || gl2.acnt_1gl_scode   ")
            sb.Append(" and  gl2.acnt_flag_acntpay='Y'  ")
            sb.Append("where gl.glcr_createdate='" & create_date & "'  ")
            sb.Append("and gl.glcr_core_system='" & core_system & "'  ")
            sb.Append("and gl.glcr_transref='" & transref & "'  ")
            sb.Append("and gl.glcr_drcr='C'  ")
            sb.Append("and gl.glcr_s_tt_tr='00000000' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GL_AMOUNT_ONE_GL = Ds.Tables(0).Rows(0)("sum_gl_amount")
        Catch ex As Exception
            GET_SUM_GL_AMOUNT_ONE_GL = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GET_SUM_GL_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select sum(glcr_amount) sum_gl_wht ")
            sb.Append("from gps_gl_creation ")
            sb.Append("where glcr_createdate='" & create_date & "' ")
            sb.Append("and glcr_core_system='" & core_system & "' ")
            sb.Append("and glcr_transref='" & transref & "' ")
            sb.Append("and glcr_drcr='C' ")
            sb.Append("and SUBSTR(glcr_s_tt_tr,1,2) IN ('02','03','53') ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_GL_WHT = Ds.Tables(0).Rows(0)("sum_gl_wht")
        Catch ex As Exception
            GET_SUM_GL_WHT = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_SUM_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As Double
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select sum(taxcr_tax_amt) sum_wht ")
            sb.Append("from gps_wht_creation ")
            sb.Append("where taxcr_createdate='" & create_date & "' ")
            sb.Append("and taxcr_core_system='" & core_system & "' ")
            sb.Append("and taxcr_transref='" & transref & "' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GET_SUM_WHT = Ds.Tables(0).Rows(0)("sum_wht")
        Catch ex As Exception
            GET_SUM_WHT = 0
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPaidDate_GLWHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select glcr_duedate ")
            sb.Append("from gps_gl_creation ")
            sb.Append("where glcr_createdate='" & create_date & "' ")
            sb.Append("and glcr_core_system='" & core_system & "' ")
            sb.Append("and glcr_transref='" & transref & "' ")
            sb.Append("and glcr_drcr ='C' and substr(glcr_s_tt_tr,1,2) IN ('02','03','53') ")
            'sb.Append("and glcr_drcr ='C' and glcr_s_tt_tr <> '00000000' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetPaidDate_GLWHT = Ds.Tables(0).Rows(0)("glcr_duedate")
        Catch ex As Exception
            GetPaidDate_GLWHT = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPaidDate_GP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select gpcr_paiddate ")
            sb.Append("from gps_payment_creation ")
            sb.Append("where gpcr_createdate='" & create_date & "' ")
            sb.Append("and gpcr_core_system='" & core_system & "' ")
            sb.Append("and gpcr_transref='" & transref & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetPaidDate_GP = Ds.Tables(0).Rows(0)("gpcr_paiddate")
        Catch ex As Exception
            GetPaidDate_GP = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPaidDate_WHT(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select taxcr_taxdate ")
            sb.Append("from gps_wht_creation ")
            sb.Append("where taxcr_createdate='" & create_date & "' ")
            sb.Append("and taxcr_core_system='" & core_system & "' ")
            sb.Append("and taxcr_transref='" & transref & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetPaidDate_WHT = Ds.Tables(0).Rows(0)("taxcr_taxdate")
        Catch ex As Exception
            GetPaidDate_WHT = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPaidDate_GLGP(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select glcr_duedate ")
            sb.Append("from gps_gl_creation ")
            sb.Append("where glcr_createdate='" & create_date & "' ")
            sb.Append("and glcr_core_system='" & core_system & "' ")
            sb.Append("and glcr_transref='" & transref & "' ")
            'sb.Append("and glcr_s_account like '2%' and glcr_drcr ='C' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            GetPaidDate_GLGP = Ds.Tables(0).Rows(0)("glcr_duedate")
        Catch ex As Exception
            GetPaidDate_GLGP = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateDuplicateTransRef(ByRef oleConn As OleDbConnection, ByVal create_date As String, ByVal core_system As String, ByVal transref As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT TREF_TRANSREF FROM GPS_TRANSREF_REL WHERE TREF_TRANSREF='" & transref & "' AND (TREF_CREATEDATE <> '" & create_date & "' OR TREF_CORE_SYSTEM<>'" & core_system & "') ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateDuplicateTransRef = Ds.Tables(0)

        Catch ex As Exception
            fValidateDuplicateTransRef = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function LookUp_ACCSetUp(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select acnt_s_code from glm_account_setup where acnt_o_code like '%" & code & "%'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_ACCSetUp = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_ACCSetUp = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_SunAccount(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("select * from glm_account_setup where acnt_s_code like '%" & code & "%'   ")
            sb.Append("select * from glm_account_setup where acnt_s_code = '" & code & "'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_SunAccount = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_SunAccount = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_OracleAccount(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select * from glm_account_setup where acnt_o_code like '%" & code & "%'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_OracleAccount = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_OracleAccount = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_ACCName(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("select acnt_name_th from glm_account_setup where acnt_s_code like '%" & code & "%'   ")
            sb.Append("select acnt_name_th from glm_account_setup where acnt_s_code = '" & code & "'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_ACCName = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_ACCName = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_SunCode(ByRef oleConn As OleDbConnection, ByVal code As String, ByVal condition As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select anl_1gl_code from glm_anlcode_setup where anl_s_code = '" & code & "'    ")
            sb.Append(condition)

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows.Count > 0 AndAlso Not IsDBNull(Ds.Tables(0).Rows(0)(0)) AndAlso Not String.IsNullOrEmpty(Ds.Tables(0).Rows(0)(0)) Then
                LookUp_SunCode = Ds.Tables(0).Rows(0)(0).ToString
            ElseIf Ds.Tables(0).Rows.Count > 0 Then
                LookUp_SunCode = code
            Else
                LookUp_SunCode = ""
            End If
        Catch ex As Exception
            LookUp_SunCode = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_OracleCode(ByRef oleConn As OleDbConnection, ByVal code As String, ByVal condition As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select anl_o_code from glm_anlcode_setup where anl_o_code like '%" & code & "%'    ")
            sb.Append(condition)

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_OracleCode = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_OracleCode = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_ANLSetUp(ByRef oleConn As OleDbConnection, ByVal code As String, ByVal condition As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select anl_s_code from glm_anlcode_setup where anl_o_code like '%" & code & "%'    ")
            sb.Append(condition)

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_ANLSetUp = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_ANLSetUp = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_MassageErr(ByRef oleConn As OleDbConnection, ByVal code As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT REJT_REJ_MASSAGE FROM GPS_TL_REJECT_TYPE WHERE REJT_REJ_TYPE= '" & code & "'    ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_MassageErr = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_MassageErr = code
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_PaymentType(ByRef oleConn As OleDbConnection, ByVal paymth_subpaymth As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT PAYT_PAYTYPE  FROM GPS_TL_PAYTYPE where PAYT_PAYMTH||PAYT_SUB_PAYMTH = '" & paymth_subpaymth & "'    ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_PaymentType = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_PaymentType = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_BankCodeNo(ByRef oleConn As OleDbConnection, ByVal bankcode As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select bkmst_bnkcode_no from gps_tl_bankmaster where bkmst_bnkcode= '" & bankcode & "'    ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_BankCodeNo = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_BankCodeNo = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_BankName(ByRef oleConn As OleDbConnection, ByVal bankcode As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select bkmst_bnkname from gps_tl_bankmaster where bkmst_bnkcode= '" & bankcode & "'    ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_BankName = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_BankName = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_Phorngordor(ByRef oleConn As OleDbConnection, ByVal pngd As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select pngd_taxtype from gps_tl_phorngordor where pngd_phorngordor='" & pngd & "'   ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_Phorngordor = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_Phorngordor = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function LookUp_DepRepay(ByRef oleConn As OleDbConnection, ByVal datasource As String, ByVal core_system As String, ByVal depkeyin As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("select dts_dep_repay from gps_tl_datasource    ")
            sb.Append("where dts_core_system='" & core_system & "' and dts_dep_keyin='" & depkeyin & "' and dts_dtsource='" & datasource & "'")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            LookUp_DepRepay = Ds.Tables(0).Rows(0)(0).ToString

        Catch ex As Exception
            LookUp_DepRepay = ""
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidatePaymentDate(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_PAIDDATE ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("GROUP BY P.GPCR_CREATEDATE,P.GPCR_CORE_SYSTEM,P.GPCR_TRANSREF,P.GPCR_PAIDDATE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidatePaymentDate = Ds.Tables(0)

        Catch ex As Exception
            fValidatePaymentDate = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateGLDate(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT L.GLCR_CREATEDATE,L.GLCR_CORE_SYSTEM,L.GLCR_TRANSREF,L.GLCR_DUEDATE ")
            sb.Append("FROM GPS_TMP_GL_CREATION  L ")
            sb.Append("WHERE L.CREATEDBY='" & userlogin & "' ")
            sb.Append("GROUP BY L.GLCR_CREATEDATE,L.GLCR_CORE_SYSTEM,L.GLCR_TRANSREF,L.GLCR_DUEDATE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateGLDate = Ds.Tables(0)

        Catch ex As Exception
            fValidateGLDate = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function fValidateTAXDate(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT L.TAXCR_CREATEDATE,L.TAXCR_CORE_SYSTEM,L.TAXCR_TRANSREF,L.TAXCR_TAXDATE ")
            sb.Append("FROM GPS_TMP_WHT_CREATION  L ")
            sb.Append("WHERE L.CREATEDBY='" & userlogin & "' ")
            sb.Append("GROUP BY L.TAXCR_CREATEDATE,L.TAXCR_CORE_SYSTEM,L.TAXCR_TRANSREF,L.TAXCR_TAXDATE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fValidateTAXDate = Ds.Tables(0)

        Catch ex As Exception
            fValidateTAXDate = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fnGetAPMaster(ByRef oleConn As OleDbConnection, ByVal scode As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            'sb.Append("SELECT * FROM GLM_ACCOUNT_SETUP  WHERE  ACNT_FLAG_ACNTPAY='Y' AND SUBSTR(ACNT_S_CODE,-5,5) <> '00000' AND ACNT_S_CODE IN ('" & scode & "') ")

            sb.Append("SELECT * FROM GLM_ACCOUNT_SETUP  A INNER JOIN GLM_SUPPLIER_SETUP S ")
            sb.Append("ON A.ACNT_S_CODE=S.SUPP_S_ACCOUNT ")
            sb.Append("AND A.ACNT_S_CODE IN (" & scode & ") ")
            'sb.Append("AND ACNT_FLAG_ACNTPAY='Y' ")
            sb.Append("AND SUBSTR(A.ACNT_S_CODE,-5,5) <> '00000' ")
            sb.Append("AND S.SUPP_STATUS='ACTIVE' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGetAPMaster = Ds.Tables(0)

        Catch ex As Exception
            fnGetAPMaster = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function fnGetAPOther(ByRef oleConn As OleDbConnection, ByVal scode As String) As DataTable

        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet


            sb.Append("SELECT * FROM GLM_SUPPLIER_SETUP ")
            sb.Append("WHERE SUPP_TAXID = " & scode & " ")
            sb.Append("AND SUPP_STATUS='ACTIVE' ")


            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGetAPOther = Ds.Tables(0)

        Catch ex As Exception
            fnGetAPOther = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function ChkGL_TransDate(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_GL_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GLCR_TRANSDATE IS NULL OR P.GLCR_TRANSDATE='' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGL_TransDate = Ds.Tables(0)

        Catch ex As Exception
            ChkGL_TransDate = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function ChkGP_Description(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_DESC IS NULL OR P.GPCR_DESC ='' OR LENGTH(P.GPCR_DESC) > 240) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Description = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Description = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function ChkGP_PayeeName(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_PAYEE_NAME IS NULL OR P.GPCR_PAYEE_NAME ='' OR LENGTH(P.GPCR_PAYEE_NAME) > 100) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_PayeeName = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_PayeeName = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankCode(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_BNKCODE IS NULL OR P.GPCR_BNKCODE ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankCode = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankCode = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankNo(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_BNKCODE_NO IS NULL OR P.GPCR_BNKCODE_NO ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankNo = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankNo = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankName(ByRef oleConn As OleDbConnection, ByVal userlogin As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND (P.GPCR_BNKNAME IS NULL OR P.GPCR_BNKNAME ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankName = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankName = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankAccount(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_PAYEE_BNKACCNO IS NULL OR P.GPCR_PAYEE_BNKACCNO ='' OR LENGTH(P.GPCR_PAYEE_BNKACCNO) > 20 ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankAccount = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankAccount = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankAccountName(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_PAYEE_BNKACCNME IS NULL OR P.GPCR_PAYEE_BNKACCNME ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankAccountName = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankAccountName = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankBranch(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_BNKBRN IS NULL OR P.GPCR_BNKBRN ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankBranch = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankBranch = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Merchn(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_MERCHN_NO IS NULL OR P.GPCR_MERCHN_NO ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Merchn = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Merchn = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Address(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_ADDRESS1||P.GPCR_DISTRICT||P.GPCR_PROVINCE IS NULL OR P.GPCR_ADDRESS1||P.GPCR_DISTRICT||P.GPCR_PROVINCE ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Address = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Address = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankBranchName(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_BNKBRN_NAME IS NULL OR P.GPCR_BNKBRN_NAME ='' )  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankBranchName = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankBranchName = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankAddress(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_BNKADDR IS NULL OR P.GPCR_BNKADDR ='' )  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankAddress = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankAddress = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Phone(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_PHONE IS NULL OR P.GPCR_PHONE ='' )  ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Phone = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Phone = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_SwiftCode(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_SWIFT_CODE IS NULL OR P.GPCR_SWIFT_CODE ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_SwiftCode = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_SwiftCode = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Country(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_COUNTRY IS NULL OR P.GPCR_COUNTRY ='' ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Country = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Country = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Currency(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_CURRENCY IS NULL OR P.GPCR_CURRENCY ='' or length(p.GPCR_CURRENCY) > 5 ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Currency = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Currency = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_Exchange(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_EXCHN_RATE IS NULL OR P.GPCR_EXCHN_RATE ='' OR P.GPCR_EXCHN_RATE < 0  ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_Exchange = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_Exchange = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ChkGP_BankCharge(ByRef oleConn As OleDbConnection, ByVal userlogin As String, ByVal pay_subpay As String) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT *  ")
            sb.Append("FROM GPS_TMP_PAYMENT_CREATION  P  ")
            sb.Append("WHERE P.CREATEDBY='" & userlogin & "' ")
            sb.Append("AND P.GPCR_PAYMTH||':'||P.GPCR_SUB_PAYMTH='" & pay_subpay & "' ")
            sb.Append("AND (P.GPCR_BNKCHARGES IS NULL OR P.GPCR_BNKCHARGES ='' OR LENGTH(P.GPCR_BNKCHARGES) > 1   ) ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            ChkGP_BankCharge = Ds.Tables(0)

        Catch ex As Exception
            ChkGP_BankCharge = Nothing
            clsBusiness.gLastErrMessage = ex.ToString
        End Try
    End Function
End Class
