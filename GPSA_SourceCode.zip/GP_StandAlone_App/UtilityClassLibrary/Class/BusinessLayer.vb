Imports System.Data.OleDb
Imports System.Configuration
Imports System.Globalization
Imports System.Threading
Imports System.Text
Imports System.IO

Public Class BusinessLayer
    'Public ret_RejectCode As String
    Public gLastErrMessage As String
    Public clsGLM_ACCOUNT_SETUP As New DataClass.clsGLM_ACCOUNT_SETUP
    Public clsGLM_ANLCODE_SETUP As New DataClass.clsGLM_ANLCODE_SETUP

    Public Function GetSystemDate(ByRef oleConn As OleDbConnection) As String

        Dim en As New System.Globalization.CultureInfo("en-GB")
        Return DateTime.Now.ToString("yyyyMMdd HH:mm:ss", en)

    End Function

    Public Function GetSystemDate_ORG(ByRef oleConn As OleDbConnection) As String

        Dim sb As New StringBuilder()
        sb.Append("select TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi:ss') as systemdate from dual")

        Dim dt As New DataTable
        dt = ExecuteReaderCommand(oleConn, sb)
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)("systemdate").ToString()
        Else
            Return ""
        End If

    End Function

    Public Function DtEmptyRpt(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select 1 from dual ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If

    End Function
    Public Function ExecuteCommand(ByRef oleConn As OleDbConnection, ByVal sb As StringBuilder, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try

            ExecuteCommand = ExecuteData(oleConn, sb.ToString, oTrans)

        Catch ex As Exception
            gLastErrMessage = ex.ToString
        End Try

    End Function
    Public Function ExecuteReaderCommand(ByRef oleConn As OleDbConnection, ByVal sb As StringBuilder) As DataTable
        Try

            Dim Ds As New DataSet
            ExecuteReader(oleConn, Ds, sb.ToString)
            ExecuteReaderCommand = Ds.Tables(0)
        Catch ex As Exception
            ExecuteReaderCommand = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ExecuteReader(ByRef oConn As OleDbConnection, ByRef oDs As DataSet, ByVal sSql As String, Optional ByVal sTableName As String = "") As Boolean
        Dim oleDa As New OleDbDataAdapter(sSql, oConn)
        Try
            If sTableName = "" Then
                oleDa.Fill(oDs)
            Else
                oleDa.Fill(oDs, sTableName)
            End If
            ExecuteReader = True
        Catch ex As Exception
            gLastErrMessage = ex.Message
            ExecuteReader = False
        End Try
    End Function
    Public Function ExecuteData(ByRef oConn As OleDbConnection, ByVal sSql As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Dim oleComm As New OleDbCommand(sSql)
        Try
            oleComm.Connection = oConn
            If oTrans Is Nothing Then
            Else
                oleComm.Transaction = oTrans
            End If
            oleComm.CommandText = sSql
            ExecuteData = oleComm.ExecuteNonQuery
        Catch ex As Exception
            gLastErrMessage = ex.Message
            ExecuteData = -1
        End Try
    End Function
    Public Function GetBankForPrtCheque(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT BKMST_BNKCODE,BKMST_BNKNAME FROM GPS_TL_BANKMASTER WHERE BKMST_FLAG_PRN_OTHBNK='Y' AND BKMST_STATUS='ACTIVE'  ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GetBankForPrtCheque = Ds.Tables(0)
        Catch ex As Exception
            GetBankForPrtCheque = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetBankCode(ByRef oleConn As OleDbConnection, Optional ByVal bankcode As String = "") As DataTable
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT BANK_CODE,PAY_CHANNEL ||'-'|| TH_DESC BANK_NAME  FROM SPI_M_PAY_CHANNEL   ")
            If bankcode <> "" Then
                sb.Append("WHERE BANK_CODE LIKE '%" & bankcode & "%' ")
            End If
            sb.Append("ORDER BY BANK_NAME ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GetBankCode = Ds.Tables(0)
        Catch ex As Exception
            GetBankCode = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function CHECK_INTERFACE_CONTROL_STATUS(ByRef oleConn As OleDbConnection, ByVal fn As String) As Boolean
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT * FROM GLM_INTERFACE_CONTROL   ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")
            sb.Append("AND INT_STATUS='STOP' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            If Ds.Tables(0).Rows.Count > 0 Then
                CHECK_INTERFACE_CONTROL_STATUS = True
            Else
                CHECK_INTERFACE_CONTROL_STATUS = False
            End If

        Catch ex As Exception
            CHECK_INTERFACE_CONTROL_STATUS = False
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GET_NO_INTERFACE_CONTROL(ByRef oleConn As OleDbConnection, ByVal fn As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT NVL(INT_GL_NO,0)+1 AS NEXTNO FROM GLM_INTERFACE_CONTROL   ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            GET_NO_INTERFACE_CONTROL = Ds.Tables(0).Rows(0)("NEXTNO") ' Ds.Tables(0).Rows("NEXTNO").ToString
        Catch ex As Exception
            GET_NO_INTERFACE_CONTROL = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function UPDATE_INTERFACE_CONTROL_STATUS(ByRef oleConn As OleDbConnection, ByVal fn As String, ByVal status As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("UPDATE GLM_INTERFACE_CONTROL SET INT_STATUS='" & status & "'  ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            UPDATE_INTERFACE_CONTROL_STATUS = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            UPDATE_INTERFACE_CONTROL_STATUS = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function UPDATE_INTERFACE_CONTROL_NO(ByRef oleConn As OleDbConnection, ByVal fn As String, Optional ByRef oTrans As OleDbTransaction = Nothing) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("UPDATE GLM_INTERFACE_CONTROL SET INT_GL_NO=INT_GL_NO+1  ")
            sb.Append("WHERE INT_FUNCTION='" & fn & "' ")

            UPDATE_INTERFACE_CONTROL_NO = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            UPDATE_INTERFACE_CONTROL_NO = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetPhorNgorDor(ByRef oleConn As OleDbConnection) As DataTable
        Try
            Dim dtGL As DataTable = Nothing
            If dtGL Is Nothing Then
                dtGL = New DataTable

                dtGL.Columns.Add("IDCARD")
                dtGL.Columns.Add("TAXID")
                dtGL.Columns.Add("APNAME")
                dtGL.Columns.Add("ADDRESS")

            End If

            Dim rowNew As DataRow
            rowNew = dtGL.NewRow

            rowNew.Item("IDCARD") = "1239876542314"
            rowNew.Item("TAXID") = "1896654310990"
            rowNew.Item("APNAME") = "�ѷ���Թ ��͹��"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "�ҭ��� �ͧ˹ع"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "���� �Ҫ�Թ"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "���Թ�� ���ا���"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "��ʹ� �ح�ѧ"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "����� �á��"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = "1231200017124"
            rowNew.Item("TAXID") = "1234567890123"
            rowNew.Item("APNAME") = "�പ �ء�����"
            rowNew.Item("ADDRESS") = "58/79 ���� 14 �����ҹ�ġ������� �.�ҧ��ǧ �.�ҧ�˭� �.������� 11140"
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()


            rowNew = dtGL.NewRow
            rowNew.Item("IDCARD") = ""
            rowNew.Item("TAXID") = ""
            rowNew.Item("APNAME") = ""
            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()


            GetPhorNgorDor = dtGL
        Catch ex As Exception
            GetPhorNgorDor = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function SetDefaultGL() As DataTable
        Try
            Dim dtGL As DataTable = Nothing
            If dtGL Is Nothing Then
                dtGL = New DataTable

                dtGL.Columns.Add("STATUS")
                dtGL.Columns.Add("SET_OF_BOOKS_ID")
                dtGL.Columns.Add("USER_JE_SOURCE_NAME")
                dtGL.Columns.Add("USER_JE_CATEGORY_NAME")
                dtGL.Columns.Add("ACCOUNTING_DATE")
                dtGL.Columns.Add("CURRENCY_CODE")
                dtGL.Columns.Add("DATE_CREATED")
                dtGL.Columns.Add("CREATED_BY")
                dtGL.Columns.Add("ACTUAL_FLAG")
                dtGL.Columns.Add("CURRENCY_CONVERSION_DATE")
                dtGL.Columns.Add("CURRENCY_CONVERSION_TYPE")
                dtGL.Columns.Add("CURRENCY_CONVERSION_RATE")
                dtGL.Columns.Add("COMPANY_CODE")
                dtGL.Columns.Add("RC_CODE")
                dtGL.Columns.Add("OWNER_CODE")
                dtGL.Columns.Add("PRODUCT_CODE")
                dtGL.Columns.Add("CHANNEL_CODE")
                dtGL.Columns.Add("ACCOUNT_CODE")
                dtGL.Columns.Add("PROJECT_CODE")
                dtGL.Columns.Add("TAX_CODE")
                dtGL.Columns.Add("SEGMENT_RESERVE1")
                dtGL.Columns.Add("SEGMENT_RESERVE2")
                dtGL.Columns.Add("ENTERED_DR")
                dtGL.Columns.Add("ENTERED_CR")
                dtGL.Columns.Add("ACCOUNTED_DR")
                dtGL.Columns.Add("ACCOUNTED_CR")
                dtGL.Columns.Add("REFERENCE1")
                dtGL.Columns.Add("REFERENCE4")
                dtGL.Columns.Add("RESERSAL_FLAG")
                dtGL.Columns.Add("RESERSAL_PERIOD")
                dtGL.Columns.Add("RESERSAL_METHOD")
                dtGL.Columns.Add("REFERENCE10")
                dtGL.Columns.Add("GROUP_ID")
                dtGL.Columns.Add("PERIOD_NAME")
                dtGL.Columns.Add("STAT_AMOUNT")
                dtGL.Columns.Add("ATTRIBUTE1")
                dtGL.Columns.Add("ATTRIBUTE2")
                dtGL.Columns.Add("ATTRIBUTE3")

            End If

            Dim rowNew As DataRow
            rowNew = dtGL.NewRow

            rowNew.Item("STATUS") = "NEW"
            rowNew.Item("SET_OF_BOOKS_ID") = "255"
            rowNew.Item("USER_JE_SOURCE_NAME") = "SUNGL"
            rowNew.Item("USER_JE_CATEGORY_NAME") = "Normal"
            rowNew.Item("CREATED_BY") = "1072"
            rowNew.Item("ACTUAL_FLAG") = "A"
            rowNew.Item("COMPANY_CODE") = "01"
            rowNew.Item("RC_CODE") = "0001"
            rowNew.Item("SEGMENT_RESERVE1") = "0000"
            rowNew.Item("SEGMENT_RESERVE2") = "0000"

            dtGL.Rows.Add(rowNew)
            dtGL.AcceptChanges()

            SetDefaultGL = dtGL
        Catch ex As Exception
            SetDefaultGL = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function ReadTextGL_Old(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGL")

                            dtD.Columns.Add("LineNo")
                            dtD.Columns.Add("TransDate")
                            dtD.Columns.Add("Dept")
                            dtD.Columns.Add("PLPT")
                            dtD.Columns.Add("Mktg")
                            dtD.Columns.Add("AccCode")
                            dtD.Columns.Add("AccName")
                            dtD.Columns.Add("Desc")
                            dtD.Columns.Add("Project")
                            dtD.Columns.Add("TTTR")
                            dtD.Columns.Add("DC")
                            'dtD.Columns.Add("DrAmt")
                            'dtD.Columns.Add("CrAmt")
                            dtD.Columns.Add("OracleAccCode")
                            dtD.Columns.Add("OracleDept")
                            dtD.Columns.Add("OraclePLPT")
                            dtD.Columns.Add("OracleMktg")

                        End If

                        Row = dtD.NewRow
                        Row.Item(0) = CurrentRow(5).ToString.Trim
                        Row.Item(1) = CurrentRow(6).ToString.Trim
                        Row.Item(2) = CurrentRow(20).ToString.Trim
                        Row.Item(3) = CurrentRow(21).ToString.Trim
                        Row.Item(4) = CurrentRow(22).ToString.Trim
                        Row.Item(5) = CurrentRow(18).ToString.Trim
                        Row.Item(6) = CurrentRow(19).ToString.Trim
                        Row.Item(7) = CurrentRow(8).ToString.Trim
                        Row.Item(8) = CurrentRow(15).ToString.Trim
                        Row.Item(9) = CurrentRow(23).ToString.Trim
                        Row.Item(10) = CurrentRow(10).ToString.Trim & "-" & CurrentRow(11).ToString.Trim

                        'If CurrentRow(11).ToString.Trim = "C" Then
                        '    Row.Item(10) = "0"
                        '    Row.Item(11) = CurrentRow(10).ToString.Trim
                        'Else
                        '    Row.Item(10) = CurrentRow(10).ToString.Trim
                        '    Row.Item(11) = "0"
                        'End If

                        Row.Item(11) = CurrentRow(9).ToString.Trim
                        Row.Item(12) = CurrentRow(12).ToString.Trim
                        Row.Item(13) = CurrentRow(13).ToString.Trim
                        Row.Item(14) = CurrentRow(14).ToString.Trim

                        dtD.Rows.Add(Row)
                    Else 'if last row

                    End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    Public Function ReadTextGL(ByVal filename As String, ByVal delimited As String, ByVal jntype As String, ByVal datasource As String, ByVal duedate As String, ByVal lineno As Integer, ByRef ConnDB As OleDbConnection) As DataTable
        '-- 1GL --
        Dim clsGLM_ACCOUNT_SETUP As New DataClass.clsGLM_ACCOUNT_SETUP
        Dim clsGLM_ANLCODE_SETUP As New DataClass.clsGLM_ANLCODE_SETUP
        clsGLM_ACCOUNT_SETUP.ConnDB = ConnDB
        clsGLM_ANLCODE_SETUP.ConnDB = ConnDB
        '-- 1GL --

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        'Dim lineno As Integer = 1
        Dim RowFooter As Integer '��ҹ�ҡ Text File
        Dim countRow As Integer 'Loop Sum �ҡ Text File
        Dim AmtHead As Decimal  '��ҹ�ҡ Text File
        Dim AmtCredit As Decimal 'Loop Sum �ҡ Text File
        Dim AmtDebit As Decimal 'Loop Sum �ҡ Text File
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()
        AmtHead = Convert.ToDecimal(CurrentRow(1).ToString)

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGL")

                            dtD.Columns.Add("JournalType")
                            dtD.Columns.Add("JournalSource")
                            dtD.Columns.Add("BusinessUnit")
                            dtD.Columns.Add("AccPeriod")
                            dtD.Columns.Add("TransRef")
                            dtD.Columns.Add("LineNo", GetType(Integer))
                            dtD.Columns.Add("TransDate")
                            dtD.Columns.Add("DueDate")
                            dtD.Columns.Add("Description")
                            dtD.Columns.Add("OracleAccCode")
                            dtD.Columns.Add("Amount")
                            dtD.Columns.Add("DC")
                            dtD.Columns.Add("OracleDept")
                            dtD.Columns.Add("OraclePLPT")
                            dtD.Columns.Add("OracleMktg")
                            dtD.Columns.Add("OracleProjectCode")
                            dtD.Columns.Add("PaymentType")
                            dtD.Columns.Add("PayeeName")
                            dtD.Columns.Add("SunAccCode")
                            dtD.Columns.Add("SunAccName")
                            dtD.Columns.Add("SunDept")
                            dtD.Columns.Add("SunPLPT")
                            dtD.Columns.Add("SunMktg")
                            dtD.Columns.Add("SunTTTR")
                            dtD.Columns.Add("SunProjectCode")

                            dtD.Columns.Add("Conversion_type")
                            dtD.Columns.Add("Conversion_rate")
                            dtD.Columns.Add("Conversion_date")
                            dtD.Columns.Add("Line_trx_ref1")
                            dtD.Columns.Add("Line_trx_ref2")
                            dtD.Columns.Add("Line_trx_ref3")
                            dtD.Columns.Add("Analysis")
                            dtD.Columns.Add("Intercompany")
                            dtD.Columns.Add("Spare1")
                            dtD.Columns.Add("Treaty_code")
                            dtD.Columns.Add("Event_code")
                            dtD.Columns.Add("Local3")
                            dtD.Columns.Add("Local4")
                            dtD.Columns.Add("Ref_1")
                            dtD.Columns.Add("Ref_2")
                            dtD.Columns.Add("Ref_3")
                            dtD.Columns.Add("Ref_4")
                            dtD.Columns.Add("Ref_5")
                            dtD.Columns.Add("Ref_6")
                            dtD.Columns.Add("Ref_7")
                            dtD.Columns.Add("Ref_8")
                            dtD.Columns.Add("Ref_9")
                            dtD.Columns.Add("Ref_10")
                            dtD.Columns.Add("To_ledger")

                            dtD.Columns.Add("Sub_acct")

                        End If

                        'If CurrentRow(0).ToString.Trim <> jntype Then
                        '    MsgBox("Journal Type not match")
                        '    dtD = Nothing
                        '    Return dtD
                        '    Exit Function
                        'End If

                        'If Left(CurrentRow(4).ToString.Trim, 3).ToUpper <> datasource.ToUpper Then
                        '    MsgBox("Datasource not match")
                        '    dtD = Nothing
                        '    Return dtD
                        '    Exit Function
                        'End If

                        Dim txt_duedate As String
                        txt_duedate = CurrentRow(7).Substring(6, 4) & CurrentRow(7).Substring(3, 2) & CurrentRow(7).Substring(0, 2)
                        If txt_duedate < duedate Then
                            MsgBox("DueDate not match")
                            dtD = Nothing
                            Return dtD
                            Exit Function
                        End If

                        Row = dtD.NewRow
                        lineno = lineno + 1

                        Row.Item(0) = CurrentRow(0).ToString.Trim '-- JournalType
                        Row.Item(1) = CurrentRow(1).ToString.Trim '-- JournalSource
                        Row.Item(2) = CurrentRow(2).ToString.Trim '-- BusinessUnit
                        Row.Item(3) = CurrentRow(3).ToString.Trim '-- AccPeriod
                        Row.Item(4) = CurrentRow(4).ToString.Trim.Replace("PASAV", "").Replace("_", "") '-- TransRef
                        If Not Row.Item(4).ToString.StartsWith("CLM") Then
                            Row.Item(4) = "CLM" & Row.Item(4).ToString
                        End If
                        Row.Item(5) = lineno  'CurrentRow(5).ToString.Trim  '-- LineNo
                        Row.Item(6) = CurrentRow(6).ToString.Trim '-- TransDate
                        Row.Item(7) = CurrentRow(7).ToString.Trim '-- DueDate
                        Row.Item(8) = CurrentRow(8).ToString.Trim '-- Description
                        Row.Item(9) = CurrentRow(9).ToString.Trim '-- OracleAccCode
                        Row.Item(10) = CurrentRow(10).ToString.Trim '-- Amount
                        Row.Item(11) = CurrentRow(11).ToString.Trim '-- DC (Debit/Credit)
                        Row.Item(12) = CurrentRow(12).ToString.Trim '-- OracleDept
                        Row.Item(13) = CurrentRow(13).ToString.Trim '-- OraclePLPT
                        Row.Item(14) = CurrentRow(14).ToString.Trim '-- OracleMktg
                        Row.Item(15) = CurrentRow(15).ToString.Trim '-- OracleProjectCode
                        Row.Item(16) = CurrentRow(16).ToString.Trim '-- PaymentType
                        Row.Item(17) = CurrentRow(17).ToString.Trim '-- PayeeName 
                        If CurrentRow(18).ToString.Trim.Length > 7 And CurrentRow(18).ToString.Trim.Length < 14 Then
                            '--Row.Item(18) = CurrentRow(18).ToString.Trim.Substring(0, 7) '-- SunAccCode
                            '-- sub code --
                            Row.Item(18) = clsGLM_ACCOUNT_SETUP.Get_1Gl_Account_By_S_CODE(CurrentRow(18).ToString.Trim) '-- SunAccCode
                        ElseIf CurrentRow(18).ToString.Trim.Length = 14 Then
                            '-- 1GL code --
                            Row.Item(18) = CurrentRow(18).ToString.Trim.Substring(0, 7) '-- SunAccCode
                        Else
                            Row.Item(18) = CurrentRow(18).ToString.Trim '-- SunAccCode
                        End If
                        Row.Item(19) = CurrentRow(19).ToString.Trim '-- SunAccName
                        Row.Item(20) = clsGLM_ANLCODE_SETUP.Get_1Gl_CC_By_DepBrn(CurrentRow(20).ToString.Trim) '-- CurrentRow(20).ToString.Trim '-- SunDept
                        Row.Item(21) = clsGLM_ANLCODE_SETUP.Get_1Gl_Product_By_PLPT(CurrentRow(21).ToString.Trim) '-- CurrentRow(21).ToString.Trim '-- SunPLPT
                        Row.Item(22) = clsGLM_ANLCODE_SETUP.Get_1Gl_Channel_By_MKTG(CurrentRow(22).ToString.Trim) '-- CurrentRow(22).ToString.Trim '-- SunMktg
                        Row.Item(23) = CurrentRow(23).ToString.Trim '-- SunTTTR
                        Row.Item(24) = clsGLM_ANLCODE_SETUP.Get_1Gl_Project_By_PROJ(CurrentRow(24).ToString.Trim) '-- CurrentRow(24).ToString.Trim '-- SunProjectCode

                        Row.Item(25) = "User" '--CurrentRow(25).ToString.Trim '-- Conversion_type
                        Row.Item(26) = "1.0000" '--CurrentRow(26).ToString.Trim '-- Conversion_rate
                        Row.Item(27) = Now.ToString("yyyyMMdd") '-- CurrentRow(27).ToString.Trim '-- Conversion_date
                        Row.Item(28) = "" '-- CurrentRow(28).ToString.Trim '-- Line_trx_ref1
                        Row.Item(29) = "" '-- CurrentRow(29).ToString.Trim '-- Line_trx_ref2
                        Row.Item(30) = "" '-- CurrentRow(30).ToString.Trim '-- Line_trx_ref3
                        Row.Item(31) = "" '-- CurrentRow(31).ToString.Trim '-- Analysis
                        Row.Item(32) = "" '-- CurrentRow(32).ToString.Trim '-- Intercompany
                        Row.Item(33) = "" '-- CurrentRow(33).ToString.Trim '-- Spare1
                        Row.Item(34) = "0000000" '-- CurrentRow(34).ToString.Trim '-- Treaty_code
                        Row.Item(35) = "000000" '-- CurrentRow(35).ToString.Trim '-- Event_code
                        Row.Item(36) = "00" '-- CurrentRow(36).ToString.Trim '-- Local3
                        Row.Item(37) = "00" '-- CurrentRow(37).ToString.Trim '-- Local4
                        Row.Item(38) = "" '-- CurrentRow(38).ToString.Trim '-- Ref_1
                        Row.Item(39) = "" '-- CurrentRow(39).ToString.Trim '-- Ref_2
                        Row.Item(40) = "" '-- CurrentRow(40).ToString.Trim '-- Ref_3
                        Row.Item(41) = "" '-- CurrentRow(41).ToString.Trim '-- Ref_4
                        Row.Item(42) = "" '-- CurrentRow(42).ToString.Trim '-- Ref_5

                        '-- update ref_6 20201202
                        Row.Item(43) = CurrentRow(22).ToString.Trim '-- CurrentRow(43).ToString.Trim '-- Ref_6

                        Row.Item(44) = "" '-- CurrentRow(44).ToString.Trim '-- Ref_7
                        Row.Item(45) = "" '-- CurrentRow(45).ToString.Trim '-- Ref_8
                        Row.Item(46) = "" '-- CurrentRow(46).ToString.Trim '-- Ref_9
                        Row.Item(47) = "" '-- CurrentRow(47).ToString.Trim '-- Ref_10
                        Row.Item(48) = "GCOMN" '-- CurrentRow(48).ToString.Trim '-- To_ledger
                        '--If CurrentRow(18).ToString.Trim.Length > 7 Then
                        If CurrentRow(18).ToString.Trim.Length > 7 And CurrentRow(18).ToString.Trim.Length < 14 Then
                            '-- Row.Item(49) = CurrentRow(18).ToString.Trim.Substring(7)  '-- Sub_acct
                            '-- Sun Code --
                            Row.Item(49) = clsGLM_ACCOUNT_SETUP.Get_1Gl_SubAccount_By_S_CODE(CurrentRow(18).ToString.Trim) '-- Sub_acct
                        ElseIf CurrentRow(18).ToString.Trim.Length = 14 Then
                            '-- 1GL code --
                            Row.Item(49) = CurrentRow(18).ToString.Trim.Substring(7)  '-- Sub_acct
                        Else
                            Row.Item(49) = "" '-- Sub_acct
                        End If

                        If CurrentRow(11).ToString.Trim = "C" Then
                            AmtCredit = AmtCredit + Convert.ToDecimal(CurrentRow(10).ToString)
                        ElseIf CurrentRow(11).ToString.Trim = "D" Then
                            AmtDebit = AmtDebit + Convert.ToDecimal(CurrentRow(10).ToString)
                        End If

                        countRow = countRow + 1

                        dtD.Rows.Add(Row)
                    Else 'if last row
                        RowFooter = Convert.ToDouble(CurrentRow(0).ToString)
                    End If

                    End If
            Catch ex As  _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            'lineno = lineno + 1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        If AmtHead <> AmtCredit Then
            MsgBox("Total amount is not valid")
            dtD = Nothing
        End If

        If RowFooter <> countRow Then
            MsgBox("Line number is not valid")
            dtD = Nothing
        End If

        If AmtCredit <> AmtDebit Then
            MsgBox("Amount Credit <> Amount Debit")
            dtD = Nothing
        End If


        Return dtD

    End Function
    Public Function ReadTextGP(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)
        'Dim dtImport As DataTable = New DataTable("ImportText")

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    If CurrentRow.Length <> 1 Then
                        If dtD Is Nothing Then
                            dtD = New DataTable("dtGP")

                            dtD.Columns.Add("TransRef")
                            dtD.Columns.Add("PolNo")
                            dtD.Columns.Add("BillNo")
                            dtD.Columns.Add("DueDate")
                            dtD.Columns.Add("Amount")
                            dtD.Columns.Add("PaymentDesc")
                            dtD.Columns.Add("PaymentType")
                            dtD.Columns.Add("PayeeName")
                            dtD.Columns.Add("BankCode")
                            dtD.Columns.Add("BankBranch")
                            dtD.Columns.Add("BankName")
                            dtD.Columns.Add("PayeeBankAccNo")
                            dtD.Columns.Add("PayeeBankAccName")
                            dtD.Columns.Add("Comment")
                            dtD.Columns.Add("Address1")
                            dtD.Columns.Add("District")
                            dtD.Columns.Add("Province")
                            dtD.Columns.Add("InsureName")
                            dtD.Columns.Add("DataSource")
                            dtD.Columns.Add("Reserve6")
                            dtD.Columns.Add("Reserve7")
                            dtD.Columns.Add("Reserve8")
                            dtD.Columns.Add("Reserve9")
                            dtD.Columns.Add("Reserve10")
                            dtD.Columns.Add("Sys_Ref")
                            dtD.Columns.Add("Sys_Gr")

                        End If

                        Row = dtD.NewRow

                        Row.Item(0) = CurrentRow(0).ToString.Trim
                        Row.Item(1) = CurrentRow(1).ToString.Trim
                        Row.Item(2) = CurrentRow(2).ToString.Trim
                        Row.Item(3) = CurrentRow(3).ToString.Trim
                        Row.Item(4) = Convert.ToDecimal(CurrentRow(4).ToString.Trim)
                        Row.Item(5) = CurrentRow(5).ToString.Trim
                        Row.Item(6) = CurrentRow(6).ToString.Trim
                        Row.Item(7) = CurrentRow(7).ToString.Trim
                        Row.Item(8) = CurrentRow(8).ToString.Trim
                        Row.Item(9) = CurrentRow(9).ToString.Trim
                        Row.Item(10) = CurrentRow(10).ToString.Trim
                        Row.Item(11) = CurrentRow(11).ToString.Trim
                        Row.Item(12) = CurrentRow(12).ToString.Trim
                        Row.Item(13) = CurrentRow(13).ToString.Trim
                        Row.Item(14) = CurrentRow(14).ToString.Trim
                        Row.Item(15) = CurrentRow(15).ToString.Trim
                        Row.Item(16) = CurrentRow(16).ToString.Trim
                        Row.Item(17) = CurrentRow(17).ToString.Trim
                        Row.Item(18) = CurrentRow(18).ToString.Trim
                        Row.Item(19) = CurrentRow(19).ToString.Trim
                        Row.Item(20) = CurrentRow(20).ToString.Trim
                        Row.Item(21) = CurrentRow(21).ToString.Trim
                        Row.Item(22) = CurrentRow(22).ToString.Trim
                        Row.Item(23) = CurrentRow(23).ToString.Trim
                        Row.Item(24) = CurrentRow(24).ToString.Trim
                        Row.Item(25) = CurrentRow(25).ToString.Trim


                        dtD.Rows.Add(Row)
                    Else 'if last row

                    End If

                End If
            Catch ex As _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    Public Function ReadTextGP_Fix(ByVal filename As String, ByVal delimited As String) As DataTable
        Dim dt As DataTable = Nothing
        Dim row As DataRow
        Dim unicode As Encoding = Encoding.Default

        '-- CR#379
        Dim oSR As System.IO.StreamReader
        Dim sTextLine As String
        Dim intLine As Integer = 0
        oSR = My.Computer.FileSystem.OpenTextFileReader(filename, Encoding.Default)
        Dim currentRow As String()
        While Not oSR.EndOfStream
            Try
                If dt Is Nothing Then
                    dt = New DataTable("dtGP")

                    dt.Columns.Add("Sys_Ref")
                    dt.Columns.Add("Sys_Gr")
                    dt.Columns.Add("GenerateDate")
                    dt.Columns.Add("Description")
                    dt.Columns.Add("BankCode")
                    dt.Columns.Add("PayeeBankAccNo")
                    dt.Columns.Add("DueDate")
                    dt.Columns.Add("Amount") ', GetType(Decimal)
                    dt.Columns.Add("PayeeName")
                    dt.Columns.Add("BankNo")
                    dt.Columns.Add("BankName")
                End If


                sTextLine = oSR.ReadLine()
                intLine += 1

                If sTextLine.Length >= 18 Then


                    row = dt.NewRow

                    Dim len As Integer
                    Dim LineLen As Integer '-- CR#379
                    LineLen = sTextLine.Length '-- CR#379

                    If LineLen <= 140 Then '-- 139 Then
                        '-- old format
                        len = sTextLine.Length - 79
                        row.Item(0) = sTextLine.Substring(0, 5).Trim '-- Sys_Ref
                        row.Item(1) = sTextLine.Substring(5, 5).Trim '-- Sys_Gr
                        row.Item(2) = sTextLine.Substring(10, 8).Trim '-- GenerateDate
                        row.Item(3) = sTextLine.Substring(18, 30).Trim '-- Description
                        row.Item(4) = sTextLine.Substring(48, 3).Trim '-- BankCode
                        row.Item(5) = sTextLine.Substring(51, 11).Trim '-- PayeeBankAccNo
                        row.Item(6) = sTextLine.Substring(62, 8).Trim '-- DueDate
                        row.Item(7) = sTextLine.Substring(70, 9).Trim '-- Amount
                        row.Item(8) = sTextLine.Substring(79, len).Trim '-- PayeeName
                    Else
                        '-- PA Saving -- CR#379 --
                        len = sTextLine.Length - 87
                        row.Item(0) = sTextLine.Substring(0, 5).Trim '-- Sys_Ref
                        row.Item(1) = sTextLine.Substring(5, 5).Trim '-- Sys_Gr
                        row.Item(2) = sTextLine.Substring(10, 8).Trim '-- GenerateDate
                        row.Item(3) = sTextLine.Substring(18, 30).Trim '-- Description
                        row.Item(4) = sTextLine.Substring(48, 5).Trim '-- BankCode
                        row.Item(5) = sTextLine.Substring(53, 11).Trim '-- PayeeBankAccNo
                        row.Item(6) = sTextLine.Substring(64, 8).Trim '-- DueDate
                        row.Item(7) = sTextLine.Substring(72, 15).Trim '-- Amount
                        row.Item(8) = sTextLine.Substring(87, len).Trim '-- PayeeName
                    End If


                    'row.Item(0) = currentRow(0).ToString.Trim
                    'row.Item(1) = currentRow(1).ToString.Trim
                    'row.Item(2) = currentRow(2).ToString.Trim
                    'row.Item(3) = currentRow(3).ToString.Trim
                    'row.Item(4) = currentRow(4).ToString.Trim
                    'row.Item(5) = currentRow(5).ToString.Trim


                    Dim txt_duedate As String '17062014

                    txt_duedate = row.Item(6).Substring(0, 2) & "/" & row.Item(6).Substring(2, 2) & "/" & row.Item(6).Substring(4, 4)

                    row.Item(6) = txt_duedate 'currentRow(6).ToString.Trim
                    row.Item(7) = (Convert.ToDecimal(row.Item(7)) / 100).ToString("###,###.00") 'currentRow(7).ToString.Trim Amount
                    row.Item(8) = row.Item(8).ToString.Trim


                    dt.Rows.Add(row)

                End If

            Catch ex As Exception
                '--dt = Nothing
                MsgBox("Line " & intLine & " is not valid and will be skipped.")
            End Try
        End While
        oSR.Close()

        '-- end of CR#379

        '' ''Using Reader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)

        '' ''    Reader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.FixedWidth
        '' ''    'Reader.SetFieldWidths(5, 5, 8, 30, 3, 11, 8, 9, -1)
        '' ''    Reader.SetFieldWidths(-1)
        '' ''    Dim currentRow As String()
        '' ''    While Not Reader.EndOfData
        '' ''        Try
        '' ''            currentRow = Reader.ReadFields()
        '' ''            'Dim currentField As String
        '' ''            If Not currentRow Is Nothing Then
        '' ''                If dt Is Nothing Then
        '' ''                    dt = New DataTable("dtGP")

        '' ''                    dt.Columns.Add("Sys_Ref")
        '' ''                    dt.Columns.Add("Sys_Gr")
        '' ''                    dt.Columns.Add("GenerateDate")
        '' ''                    dt.Columns.Add("Description")
        '' ''                    dt.Columns.Add("BankCode")
        '' ''                    dt.Columns.Add("PayeeBankAccNo")
        '' ''                    dt.Columns.Add("DueDate")
        '' ''                    dt.Columns.Add("Amount") ', GetType(Decimal)
        '' ''                    dt.Columns.Add("PayeeName")
        '' ''                    dt.Columns.Add("BankNo")
        '' ''                    dt.Columns.Add("BankName")
        '' ''                End If
        '' ''                Dim txt As String
        '' ''                txt = currentRow(0).ToString

        '' ''                If txt.Length >= 18 Then


        '' ''                    row = dt.NewRow

        '' ''                    Dim len As Integer
        '' ''                    Dim LineLen As Integer '-- CR#379
        '' ''                    len = txt.Length - 79
        '' ''                    LineLen = txt.Length '-- CR#379

        '' ''                    If LineLen > 139 Then
        '' ''                        '-- old format
        '' ''                        row.Item(0) = txt.Substring(0, 5).Trim '-- Sys_Ref
        '' ''                        row.Item(1) = txt.Substring(5, 5).Trim '-- Sys_Gr
        '' ''                        row.Item(2) = txt.Substring(10, 8).Trim '-- GenerateDate
        '' ''                        row.Item(3) = txt.Substring(18, 30).Trim '-- Description
        '' ''                        row.Item(4) = txt.Substring(48, 3).Trim '-- BankCode
        '' ''                        row.Item(5) = txt.Substring(51, 11).Trim '-- PayeeBankAccNo
        '' ''                        row.Item(6) = txt.Substring(62, 8).Trim '-- DueDate
        '' ''                        row.Item(7) = txt.Substring(70, 9).Trim '-- Amount
        '' ''                        row.Item(8) = txt.Substring(79, len).Trim '-- PayeeName
        '' ''                    Else
        '' ''                        '-- PA Saving -- CR#379 --
        '' ''                        row.Item(0) = txt.Substring(0, 5).Trim '-- Sys_Ref
        '' ''                        row.Item(1) = txt.Substring(5, 5).Trim '-- Sys_Gr
        '' ''                        row.Item(2) = txt.Substring(10, 8).Trim '-- GenerateDate
        '' ''                        row.Item(3) = txt.Substring(18, 30).Trim '-- Description
        '' ''                        row.Item(4) = txt.Substring(48, 5).Trim '-- BankCode
        '' ''                        row.Item(5) = txt.Substring(53, 11).Trim '-- PayeeBankAccNo
        '' ''                        row.Item(6) = txt.Substring(64, 8).Trim '-- DueDate
        '' ''                        row.Item(7) = txt.Substring(72, 9).Trim '-- Amount
        '' ''                        row.Item(8) = txt.Substring(88, len).Trim '-- PayeeName
        '' ''                    End If


        '' ''                    'row.Item(0) = currentRow(0).ToString.Trim
        '' ''                    'row.Item(1) = currentRow(1).ToString.Trim
        '' ''                    'row.Item(2) = currentRow(2).ToString.Trim
        '' ''                    'row.Item(3) = currentRow(3).ToString.Trim
        '' ''                    'row.Item(4) = currentRow(4).ToString.Trim
        '' ''                    'row.Item(5) = currentRow(5).ToString.Trim


        '' ''                    Dim txt_duedate As String '17062014

        '' ''                    txt_duedate = row.Item(6).Substring(0, 2) & "/" & row.Item(6).Substring(2, 2) & "/" & row.Item(6).Substring(4, 4)

        '' ''                    row.Item(6) = txt_duedate 'currentRow(6).ToString.Trim
        '' ''                    row.Item(7) = (Convert.ToDecimal(row.Item(7)) / 100).ToString("###,###.00") 'currentRow(7).ToString.Trim Amount
        '' ''                    row.Item(8) = row.Item(8).ToString.Trim


        '' ''                    dt.Rows.Add(row)

        '' ''                End If

        '' ''            End If
        '' ''            'For Each currentField In currentRow
        '' ''            '    MsgBox(currentField)
        '' ''            'Next
        '' ''        Catch ex As Microsoft.VisualBasic.FileIO.MalformedLineException
        '' ''            dt = Nothing
        '' ''            MsgBox("Line " & ex.Message & "is not valid and will be skipped.")
        '' ''        End Try
        '' ''    End While
        '' ''End Using

        Return dt

    End Function

    Public Function ReadTextGP_DRAFT_Fix(ByVal filename As String, ByVal delimited As String) As DataTable
        Dim dt As DataTable = Nothing
        Dim row As DataRow
        Dim unicode As Encoding = Encoding.Default

        '-- CR#379
        Dim oSR As System.IO.StreamReader
        Dim sTextLine As String
        Dim intLine As Integer = 0
        oSR = My.Computer.FileSystem.OpenTextFileReader(filename, Encoding.Default)
        Dim currentRow As String()
        While Not oSR.EndOfStream
            Try
                If dt Is Nothing Then
                    dt = New DataTable("dtGP")

                    dt.Columns.Add("Transaction Reference")
                    dt.Columns.Add("DueDate")
                    dt.Columns.Add("Amount")
                    dt.Columns.Add("Description")
                    dt.Columns.Add("PayeeName")
                    dt.Columns.Add("District")
                    dt.Columns.Add("Province")
                    dt.Columns.Add("BankCode")

                End If


                sTextLine = oSR.ReadLine()
                intLine += 1

                If sTextLine.Length >= 18 Then


                    row = dt.NewRow

                    Dim len As Integer
                    Dim LineLen As Integer '-- CR#379
                    LineLen = sTextLine.Length '-- CR#379

                    row.Item(0) = sTextLine.Substring(0, 30).Trim '-- TransRef
                    row.Item(1) = sTextLine.Substring(30, 8).Trim '-- Due Date
                    row.Item(2) = sTextLine.Substring(38, 15).Trim '-- Amount
                    row.Item(3) = sTextLine.Substring(53, 30).Trim '-- PayDesc
                    row.Item(4) = sTextLine.Substring(83, 60).Trim '-- PayeeName
                    row.Item(5) = sTextLine.Substring(143, 60).Trim '-- District
                    row.Item(6) = sTextLine.Substring(203, 60).Trim '-- Province


                    Dim txt_duedate As String '17062014

                    txt_duedate = row.Item(1).Substring(0, 2) & "/" & row.Item(1).Substring(2, 2) & "/" & row.Item(1).Substring(4, 4)

                    row.Item(1) = txt_duedate
                    row.Item(2) = (Convert.ToDecimal(row.Item(2)) / 100).ToString("###,###.00")


                    dt.Rows.Add(row)

                End If

            Catch ex As Exception
                '--dt = Nothing
                MsgBox("Line " & intLine & " is not valid and will be skipped.")
            End Try
        End While
        oSR.Close()


        Return dt

    End Function

    Public Function ReadTextTAX(ByVal filename As String, ByVal delimited As String) As DataTable

        Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(filename, Encoding.Default)
        TextFileReader.TextFieldType = FileIO.FieldType.Delimited
        TextFileReader.SetDelimiters(delimited)

        Dim dtD As DataTable = Nothing
        Dim Row As DataRow
        Dim CurrentRow As String()
        Dim lineno As Integer = 1
        'Skip First row
        'CurrentRow = TextFileReader.ReadFields()

        While Not TextFileReader.EndOfData
            Try

                CurrentRow = TextFileReader.ReadFields()

                If Not CurrentRow Is Nothing Then
                    ''# Check if DataTable has been created
                    'If CurrentRow.Length <> 1 Then
                    If dtD Is Nothing Then
                        dtD = New DataTable("dtTAX")

                        dtD.Columns.Add("LineNo")
                        dtD.Columns.Add("TaxID")
                        dtD.Columns.Add("IDCard")
                        dtD.Columns.Add("APTitle")
                        dtD.Columns.Add("APName")
                        dtD.Columns.Add("APLastName")
                        dtD.Columns.Add("Address")
                        dtD.Columns.Add("AMPENM")
                        dtD.Columns.Add("PROVNM")
                        dtD.Columns.Add("AGZIP")
                        dtD.Columns.Add("TaxType")
                        dtD.Columns.Add("TaxItem")
                        dtD.Columns.Add("TaxDate")
                        dtD.Columns.Add("BaseAmount")
                        dtD.Columns.Add("WHTAmount")
                        dtD.Columns.Add("Payee")
                        dtD.Columns.Add("TaxRate")
                        dtD.Columns.Add("Description")
                        dtD.Columns.Add("AccountCode")
                        dtD.Columns.Add("TransRef")

                    End If

                    Row = dtD.NewRow
                    Row.Item(0) = CurrentRow(0).ToString.Trim
                    Row.Item(1) = CurrentRow(1).ToString.Trim
                    Row.Item(2) = CurrentRow(2).ToString.Trim
                    Row.Item(3) = CurrentRow(3).ToString.Trim
                    Row.Item(4) = CurrentRow(4).ToString.Trim
                    Row.Item(5) = CurrentRow(5).ToString.Trim
                    Row.Item(6) = CurrentRow(6).ToString.Trim
                    Row.Item(7) = CurrentRow(7).ToString.Trim
                    Row.Item(8) = CurrentRow(8).ToString.Trim
                    Row.Item(9) = CurrentRow(9).ToString.Trim
                    Row.Item(10) = CurrentRow(10).ToString.Trim
                    Row.Item(11) = CurrentRow(11).ToString.Trim
                    Row.Item(12) = CurrentRow(12).ToString.Trim
                    Row.Item(13) = CurrentRow(13).ToString.Trim
                    Row.Item(14) = CurrentRow(14).ToString.Trim
                    Row.Item(15) = CurrentRow(15).ToString.Trim
                    Row.Item(16) = CurrentRow(16).ToString.Trim
                    Row.Item(17) = CurrentRow(17).ToString.Trim
                    Row.Item(18) = CurrentRow(18).ToString.Trim
                    Row.Item(19) = CurrentRow(19).ToString.Trim

                    dtD.Rows.Add(Row)
                    'Else 'if last row

                    'End If

                End If
            Catch ex As  _
            Microsoft.VisualBasic.FileIO.MalformedLineException
                MsgBox("Line " & ex.Message & _
                "is not valid and will be skipped.")
            End Try
            lineno = +1
        End While
        TextFileReader.Dispose()

        'dsImport.Tables.Add(dtD)

        Return dtD

    End Function
    Public Function fnCallBatchNo(ByRef oleConn As OleDbConnection, ByVal systemdate As String) As String
        Dim batchno As String
        Dim sb As New StringBuilder


        sb.Append("select nvl(max(gpcm_batch_no),0) batch_no from gps_payment_complete where gpcm_batchdate='" & systemdate & "' ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Dim no As Integer
            no = Convert.ToInt16(Right(dt.Rows(0)("batch_no"), 2)) + 1
            batchno = "GP" & systemdate & no.ToString.PadLeft(2, "0")
        Else
            batchno = "GP" & systemdate & "01"
        End If
        Return batchno
    End Function
    Public Function fnCallLastBatchNo(ByRef oleConn As OleDbConnection, Optional ByVal paygroup As String = "") As String
        Dim batchno As String
        Dim sb As New StringBuilder


        'sb.Append("select max(gpcm_batch_no) as batch_no from gps_payment_complete order by gpcm_batchdate desc ")

        sb.Append("select max(l.tref_batch_no) as batch_no  ")
        sb.Append("from gps_payment c inner join gps_transref_rel l ")
        sb.Append("on c.gp_createdate=l.tref_createdate ")
        sb.Append("and c.gp_core_system=l.tref_core_system ")
        sb.Append("and c.gp_transref=l.tref_transref ")
        sb.Append("inner join gps_tl_paytype t ")
        sb.Append("on c.gp_paymth=t.payt_paymth and c.gp_sub_paymth=t.payt_sub_paymth ")

        If paygroup <> "" Then
            sb.Append("where t.payt_pay_group='" & paygroup & "' ")
        End If
        sb.Append("order by l.tref_batch_no desc ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            batchno = dt.Rows(0)("batch_no")
        Else
            batchno = ""
        End If
        Return batchno
    End Function
    Public Function INS_GPS_PRNCHQ_OTHBNK(ByRef oleConn As OleDbConnection, ByRef oTrans As OleDbTransaction, ByVal dr As DataRow) As Double
        Try
            Dim sb As New StringBuilder

            sb.Append("INSERT INTO GPS_PRNCHQ_OTHBNK( ")
            sb.Append("PCHQ_BNKCODE, ")
            sb.Append("PCHQ_CHQNO, ")
            sb.Append("PCHQ_PAYEE_NAME, ")
            sb.Append("PCHQ_AMOUNT, ")
            sb.Append("PCHQ_PAIDDATE, ")
            sb.Append("CREATEDBY, ")
            sb.Append("CREATEDDATE, ")
            sb.Append("UPDATEDBY, ")
            sb.Append("UPDATEDDATE) ")
            sb.Append("VALUES ( ")
            sb.Append("'" & dr("PCHQ_BNKCODE") & "',")
            sb.Append("'" & dr("PCHQ_CHQNO") & "',")
            sb.Append("'" & dr("PCHQ_PAYEE_NAME") & "',")
            sb.Append("'" & dr("PCHQ_AMOUNT") & "',")
            sb.Append("'" & dr("PCHQ_PAIDDATE") & "',")
            sb.Append("'" & dr("CREATEDBY") & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
            sb.Append("'" & dr("UPDATEDBY") & "',")
            sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'))")

            INS_GPS_PRNCHQ_OTHBNK = ExecuteData(oleConn, sb.ToString, oTrans)
        Catch ex As Exception
            INS_GPS_PRNCHQ_OTHBNK = Nothing
            gLastErrMessage = ex.ToString
        End Try
    End Function
    Public Function GetRptPrtCheque(ByRef oleConn As OleDbConnection, ByVal bnkcode As String, ByVal chqno As String) As DataTable
        Dim sb As New StringBuilder
        sb.Append("SELECT * FROM GPS_PRNCHQ_OTHBNK WHERE PCHQ_BNKCODE='" & bnkcode & "' AND  PCHQ_CHQNO='" & chqno & "' ")
        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetMaxLetterNo(ByRef oleConn As OleDbConnection) As String
        Dim sb As New StringBuilder

        sb.Append("SELECT TO_CHAR(SYSDATE,'YYYY') AS YYYY,NVL(MAX(SUBSTR(LETT_NO,-6)),0) AS LETT_NO FROM GPS_LETTERNO_SETUP WHERE LETT_YEAR=TO_CHAR(SYSDATE,'YYYY')")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            If dt.Rows(0)("LETT_NO") = 0 Then
                Return "Treasury-" & dt.Rows(0)("YYYY") & "/000001"
            Else
                Dim no As String
                no = Convert.ToDecimal(dt.Rows(0)("LETT_NO")) + 1
                Return "Treasury-" & dt.Rows(0)("YYYY") & "/" & no.PadLeft(6, "0")
            End If
        Else
            Return Nothing
        End If
    End Function
    Public Function INS_GPS_LETTERNO_SETUP(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("INSERT INTO GPS_LETTERNO_SETUP ( ")
        sb.Append("LETT_YEAR, ")
        sb.Append("LETT_NO, ")
        sb.Append("CREATEDBY, ")
        sb.Append("CREATEDDATE, ")
        sb.Append("UPDATEDBY, ")
        sb.Append("UPDATEDDATE) ")
        sb.Append("VALUES( ")
        sb.Append("'" & dr("LETT_YEAR") & "',")
        sb.Append("'" & dr("LETT_NO") & "',")
        sb.Append("'" & dr("CREATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi'),")
        sb.Append("'" & dr("UPDATEDBY") & "',")
        sb.Append("TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi')")
        sb.Append(") ")


        rec = ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function UPD_GPS_LETTERNO_SETUP(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal dr As DataRow) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_LETTERNO_SETUP SET ")
        sb.Append("LETT_NO='" & dr("LETT_NO") & "',")
        sb.Append("UPDATEDBY='" & dr("UPDATEDBY") & "',")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD hh24:mi') ")
        sb.Append("WHERE LETT_YEAR='" & dr("LETT_YEAR") & "' ")


        rec = ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function GetReportContract(ByRef oleConn As OleDbConnection, ByVal rpt_id As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT * FROM GPS_TL_CONTRACT_RPT WHERE CONT_REPORT_ID='" & rpt_id & "' ")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataRptWHT(ByRef oleConn As OleDbConnection, ByVal batchno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT L.TREF_BATCH_NO,W.TAX_WHTNO,W.TAX_TAXDATE,W.TAX_AP_TTL||W.TAX_AP_FNAME||W.TAX_AP_LNAME AS PAYEENAME,W.TAX_TAXID,W.TAX_BASE_AMT,  ")
        sb.Append("W.TAX_TAX_AMT,(W.TAX_BASE_AMT-W.TAX_TAX_AMT) AS AMOUNT,W.TAX_TRANSREF,  ")
        sb.Append("W.TAX_PHORNGORDOR,S.STS_DESC  AS TAX_PRINTWHT_STS,W.TAX_PRINTWHT_STSDATE  ")
        sb.Append("FROM (GPS_WHT W INNER JOIN GPS_TRANSREF_REL L    ")
        sb.Append("ON W.TAX_CREATEDATE=L.TREF_CREATEDATE  ")
        sb.Append("AND W.TAX_CORE_SYSTEM=L.TREF_CORE_SYSTEM  ")
        sb.Append("AND W.TAX_TRANSREF=L.TREF_TRANSREF ) ")
        sb.Append("LEFT JOIN ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='PRN_WHT')S ")
        sb.Append("ON W.TAX_PRINTWHT_STS=S.STS_STATUS ")
        sb.Append("WHERE L.TREF_BATCH_NO='" & batchno & "'  ")
        sb.Append("  AND W.Tax_Flag_Cc <> 'Y'  ")
        sb.Append("ORDER BY W.TAX_WHTNO ")


        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataRptErrorByHash(ByRef oleConn As OleDbConnection, ByVal batchdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select c.csys_core_systemname as core_system,d.dep_depname as department,s.dts_business as business, ")
        sb.Append("r.gprj_paiddate,p.payt_paytype,r.gprj_desc, ")
        sb.Append("r.gprj_polno,r.gprj_bnkcode,r.gprj_payee_bnkaccno, ")
        sb.Append("case when r.gprj_paymth='M' and r.gprj_sub_paymth='M' then r.gprj_payee_bnkaccnme else r.gprj_payee_name end as payeename, ")
        sb.Append("r.gprj_amount,r.gprj_reject_type as errgroup,rt.rejt_rej_group,rt.rejt_rej_massage ")
        sb.Append("from gps_payment_rej r inner join gps_transref_rel t ")
        sb.Append("on r.gprj_createdate=t.tref_createdate ")
        sb.Append("and r.gprj_core_system=t.tref_core_system ")
        sb.Append("and r.gprj_transref=t.tref_transref ")
        sb.Append("inner join gps_tl_paytype p ")
        sb.Append("on r.gprj_paymth=p.payt_paymth and r.gprj_sub_paymth=p.payt_sub_paymth ")
        sb.Append("inner join gps_tl_core_system c on r.gprj_core_system=c.csys_core_system ")
        sb.Append("inner join gps_tl_datasource s on r.gprj_core_system=s.dts_core_system ")
        sb.Append("and t.tref_dtsource=s.dts_dtsource  ")
        sb.Append("and t.tref_dep_repay=s.dts_dep_repay ")
        sb.Append("inner join gps_tl_reject_type rt  ")
        sb.Append("on r.gprj_reject_type=rt.rejt_rej_type ")
        sb.Append("inner join gps_tl_department d on t.tref_dep_repay=d.dep_depcode ")
        sb.Append("where r.gprj_batchdate='" & batchdate & "'   ")
        sb.Append(" and r.gprj_reject_func='HASH'")

        Dim dt As DataTable
        dt = ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function fnGet_pathconfig(ByRef oleConn As OleDbConnection, ByVal fn As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT CPATH_PATH FROM GPS_TL_CONFIG_PATH  WHERE CPATH_FUNC = '" & fn & "' ")

            ExecuteReader(oleConn, Ds, sb.ToString)
            fnGet_pathconfig = Ds.Tables(0).Rows(0)("CPATH_PATH")

        Catch ex As Exception
            fnGet_pathconfig = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function
End Class
