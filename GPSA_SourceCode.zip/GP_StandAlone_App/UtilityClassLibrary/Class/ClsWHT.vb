Imports System.Text
Imports System.Data.OleDb
Imports UtilityClassLibrary
Public Class ClsWHT
    Dim clsUtility As New ConnectDB
    Dim clsBusiness As New BusinessLayer

    Public gLastErrMessage As String
    Private _TAXSWC_TOT_LINE As Long
    Private _TAXSWC_TOT_AMT As Decimal
    Private _TAXSWC_TOT_TAX As Decimal

    Public Property TAXSWC_TOT_AMT As Decimal
        Get
            TAXSWC_TOT_AMT = _TAXSWC_TOT_AMT
        End Get
        Set(value As Decimal)
            _TAXSWC_TOT_AMT = value
        End Set
    End Property

    Public Property TAXSWC_TOT_TAX As Decimal
        Get
            TAXSWC_TOT_TAX = _TAXSWC_TOT_TAX
        End Get
        Set(value As Decimal)
            _TAXSWC_TOT_TAX = value
        End Set
    End Property

    Public Property TAXSWC_TOT_LINE As Long
        Get
            TAXSWC_TOT_LINE = _TAXSWC_TOT_LINE
        End Get
        Set(value As Long)
            _TAXSWC_TOT_LINE = value
        End Set
    End Property

    Public Function GetBatchNo(ByRef oleConn As OleDbConnection, ByVal confirmdate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("select p.gp_confirmdate,l.tref_batch_no ")
        sb.Append("from (gps_transref_rel l inner join gps_payment p ")
        sb.Append("on l.tref_createdate=p.gp_createdate ")
        sb.Append("and l.tref_core_system=p.gp_core_system ")
        sb.Append("and l.tref_transref=p.gp_transref) ")
        sb.Append("where p.gp_confirmdate='" & confirmdate & "' ")
        sb.Append("group by p.gp_confirmdate,l.tref_batch_no ")



        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function BindDataCertificate(ByRef oleConn As OleDbConnection, ByVal whtno As String, ByVal datefrom As String, ByVal dateto As String, _
                                             ByVal taxid As String, ByVal idcard As String, ByVal name As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL || W.TAX_AP_FNAME || ' ' || W.TAX_AP_LNAME AS FNAME,  ")
        sb.Append("W.TAX_ADDRESS || ' ' || W.TAX_AMPENM || ' ' || W.TAX_PROVNM || ' ' || W.TAX_AGZIP AS ADDRESS, ")
        sb.Append("W.TAX_TAXID,W.TAX_IDCARD,W.TAX_TAXTYPE,TO_CHAR(TO_DATE(W.TAX_TAXDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_TAXDATE , ")
        sb.Append("W.TAX_BASE_AMT,W.TAX_TAX_AMT, ")
        sb.Append("S.STS_DESC  AS TAX_PRINTWHT_STS,TO_CHAR(TO_DATE(W.TAX_PRINTWHT_STSDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_PRINTWHT_STSDATE   ")
        sb.Append("FROM (GPS_WHT W INNER JOIN GPS_TRANSREF_REL L     ")
        sb.Append("ON W.TAX_CREATEDATE=L.TREF_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=L.TREF_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=L.TREF_TRANSREF )  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='PRN_WHT')S  ")
        sb.Append("ON W.TAX_PRINTWHT_STS=S.STS_STATUS  ")
        sb.Append("WHERE 1=1 ")

        If whtno <> "" Then
            sb.Append("AND W.TAX_WHTNO='" & whtno & "' ")
        End If

        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND L.TREF_PAIDDATE BETWEEN '" & datefrom & "' AND '" & dateto & "' ")
        ElseIf datefrom <> "" And dateto = "" Then
            sb.Append("AND L.TREF_PAIDDATE ='" & datefrom & "' ")
        ElseIf datefrom = "" And dateto <> "" Then
            sb.Append("AND L.TREF_PAIDDATE ='" & dateto & "' ")
        End If

        If taxid <> "" Then
            sb.Append("AND W.TAX_TAXID='" & taxid & "' ")
        End If

        If idcard <> "" Then
            sb.Append("AND W.TAX_IDCARD='" & idcard & "' ")
        End If

        If name <> "" Then
            sb.Append("AND  W.TAX_AP_FNAME || ' ' || W.TAX_AP_LNAME LIKE '%" & name & "%' ")
        End If

        sb.Append("ORDER BY W.TAX_SEQNO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetDataCertificateReport(ByRef oleConn As OleDbConnection, ByVal whtno As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL || W.TAX_AP_FNAME || ' ' || W.TAX_AP_LNAME AS FNAME,  ")
        sb.Append("W.TAX_ADDRESS || ' ' || W.TAX_AMPENM || ' ' || W.TAX_PROVNM || ' ' || W.TAX_AGZIP AS ADDRESS, ")
        sb.Append("NVL(W.TAX_TAXID,TAX_IDCARD) AS TAX_TAXID,W.TAX_IDCARD,W.TAX_TAXTYPE,TO_CHAR(TO_DATE(W.TAX_TAXDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_TAXDATE , ")
        sb.Append("W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_FLAG_CC AS STATUS,W.TAX_DESC,")
        sb.Append("S.STS_DESC  AS TAX_PRINTWHT_STS,TO_CHAR(TO_DATE(W.TAX_PRINTWHT_STSDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_PRINTWHT_STSDATE, W.tax_payee  ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_6.COMP_NMO1 ELSE COM_SETUP_1.COMP_NAME END COMP_NAME ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_7.COMP_ADO2 ELSE COM_SETUP_2.COMP_ADDR END COMP_ADDR ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_4.COMP_TAXO1 ELSE COM_SETUP_3.COMP_TAXID END COMP_TAXID ")
        sb.Append("FROM (GPS_WHT W INNER JOIN GPS_TRANSREF_REL L     ")
        sb.Append("ON W.TAX_CREATEDATE=L.TREF_CREATEDATE   ")
        sb.Append("AND W.TAX_CORE_SYSTEM=L.TREF_CORE_SYSTEM   ")
        sb.Append("AND W.TAX_TRANSREF=L.TREF_TRANSREF )  ")
        sb.Append("LEFT JOIN  ")
        sb.Append("(SELECT * FROM GPS_TL_STATUS WHERE STS_TYPE='PRN_WHT')S  ")
        sb.Append("ON W.TAX_PRINTWHT_STS=S.STS_STATUS  ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_NAME FROM GPS_COMPANY_SETUP WHERE CODE = 'NAME') COM_SETUP_1 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_ADDR FROM GPS_COMPANY_SETUP WHERE CODE = 'ADDR') COM_SETUP_2 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXID FROM GPS_COMPANY_SETUP WHERE CODE = 'TAXI') COM_SETUP_3 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'TAO1') COM_SETUP_4 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXEF FROM GPS_COMPANY_SETUP WHERE CODE = 'TAEF') COM_SETUP_5 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_NMO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'NMO1') COM_SETUP_6 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_ADO2 FROM GPS_COMPANY_SETUP WHERE CODE = 'ADO2') COM_SETUP_7 ON 1=1 ")
        sb.Append("WHERE 1=1 ")

        If whtno <> "" Then
            sb.Append("AND W.TAX_WHTNO IN (" & whtno & ") ")
        End If

        sb.Append("ORDER BY W.TAX_SEQNO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function UPD_STATUS(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal whtno As String, ByVal guserlogin As String) As Boolean

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_WHT SET ")
        sb.Append("TAX_PRINTWHT_STS='R',")
        sb.Append("UPDATEDBY='" & guserlogin & "', ")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE TAX_WHTNO IN (" & whtno & ") ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)

        If rec >= 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Function GetDataPhorNgorDor_ByPeriod(ByRef oleConn As OleDbConnection, ByVal period As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        'sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL||W.TAX_AP_FNAME AS AP_NAME,W.TAX_AP_LNAME,W.TAX_TAXID AS TAXID,W.TAX_DESC,W.TAX_FLAG_CC AS CC, ")
        'sb.Append("W.TAX_IDCARD AS IDCARD,W.TAX_TAXDATE,W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_TAX_RATE, ")
        'sb.Append("W.TAX_ADDRESS||' '||W.TAX_AMPENM||' '||W.TAX_PROVNM||' '||W.TAX_AGZIP AS ADDRESS,W.TAX_PRINTWHT_STS ")
        'sb.Append(",W.TAX_PAYEE AS PAYEE ")
        'sb.Append("FROM GPS_WHT W WHERE SUBSTR(W.TAX_TAXDATE,1,6)='" & period & "'  ")
        'sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "' ")
        'sb.Append("ORDER BY W.TAX_SEQNO  ")
        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL||W.TAX_AP_FNAME AS AP_NAME,W.TAX_AP_LNAME,W.TAX_TAXID AS TAXID,W.TAX_DESC,W.TAX_FLAG_CC AS CC, ")
        sb.Append("W.TAX_IDCARD AS IDCARD,W.TAX_TAXDATE,W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_TAX_RATE, ")
        sb.Append("W.TAX_ADDRESS||' '||W.TAX_AMPENM||' '||W.TAX_PROVNM||' '||W.TAX_AGZIP AS ADDRESS,W.TAX_PRINTWHT_STS ")
        sb.Append(",W.TAX_PAYEE AS PAYEE ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_4.COMP_TAXO1 ELSE COM_SETUP_3.COMP_TAXID END COMP_TAXID ")
        sb.Append("FROM GPS_WHT W INNER JOIN GPS_TRANSREF_REL T ON W.TAX_TRANSREF = T.TREF_TRANSREF ")
        sb.Append("AND W.TAX_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND W.TAX_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")

        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXID FROM GPS_COMPANY_SETUP WHERE CODE = 'TAXI') COM_SETUP_3 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'TAO1') COM_SETUP_4 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXEF FROM GPS_COMPANY_SETUP WHERE CODE = 'TAEF') COM_SETUP_5 ON 1=1 ")

        sb.Append("WHERE T.TREF_GL_PERIOD <= T.TREF_WHT_PERIOD ")
        sb.Append("AND SUBSTR(T.TREF_WHT_PERIOD,1,4)||SUBSTR(T.TREF_WHT_PERIOD,6,2)='" & period & "'   ")
        sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO   ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function
    Public Function GetDataPhorNgorDorOutMth_ByPeriod(ByRef oleConn As OleDbConnection, ByVal period As String, ByVal accperiod As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL||W.TAX_AP_FNAME AS AP_NAME,W.TAX_AP_LNAME,W.TAX_TAXID AS TAXID,W.TAX_DESC,W.TAX_FLAG_CC AS CC, ")
        sb.Append("W.TAX_IDCARD AS IDCARD,W.TAX_TAXDATE,W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_TAX_RATE, ")
        sb.Append("W.TAX_ADDRESS||' '||W.TAX_AMPENM||' '||W.TAX_PROVNM||' '||W.TAX_AGZIP AS ADDRESS,W.TAX_PRINTWHT_STS ")
        sb.Append(",W.TAX_PAYEE AS PAYEE ")
        sb.Append(", CASE WHEN W.TAX_TAXDATE < COM_SETUP_5.COMP_TAXEF THEN COM_SETUP_4.COMP_TAXO1 ELSE COM_SETUP_3.COMP_TAXID END COMP_TAXID ")
        sb.Append("FROM GPS_WHT W JOIN GPS_TRANSREF_REL T ON W.TAX_TRANSREF = T.TREF_TRANSREF ")
        sb.Append("AND W.TAX_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND W.TAX_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")

        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXID FROM GPS_COMPANY_SETUP WHERE CODE = 'TAXI') COM_SETUP_3 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'TAO1') COM_SETUP_4 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXEF FROM GPS_COMPANY_SETUP WHERE CODE = 'TAEF') COM_SETUP_5 ON 1=1 ")

        sb.Append("WHERE T.TREF_GL_PERIOD > T.TREF_WHT_PERIOD ")
        sb.Append("AND SUBSTR(T.TREF_WHT_PERIOD,1,4)||SUBSTR(T.TREF_WHT_PERIOD,6,2)='" & period & "'   ")
        sb.Append("AND SUBSTR(T.TREF_GL_PERIOD,1,4)||SUBSTR(T.TREF_GL_PERIOD,6,2)='" & accperiod & "'   ")
        sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO   ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function
    Public Function GetDataPhorNgorDorOutMthToSWC_ByPeriod(ByRef oleConn As OleDbConnection, ByVal period As String, ByVal accperiod As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        '--sb.Append("SELECT W.* ")
        sb.Append("select w.tax_seqno, w.tax_whtno, w.tax_confirmdate, w.tax_createdate, w.tax_core_system, w.tax_transref, w.tax_gptref_seqno, w.tax_lineno, w.tax_taxid, w.tax_idcard, w.tax_ap_ttl, w.tax_ap_fname, w.tax_ap_lname, w.tax_address, w.tax_ampenm, w.tax_provnm, w.tax_agzip, w.tax_taxtype, w.tax_phorngordor, w.tax_taxitem, w.tax_taxdate, case w.tax_flag_cc when 'Y' then 0 else w.tax_base_amt end tax_base_amt, case w.tax_flag_cc when 'Y' then 0 else w.tax_tax_amt end tax_tax_amt, w.tax_payee, w.tax_tax_rate, w.tax_desc, w.tax_gl_account, w.tax_printwht_sts, w.tax_printwht_stsdate, w.tax_flag_cc, w.tax_cc_date, w.createdby, w.createddate, w.updatedby, w.updateddate, w.tax_cc_type, w.tax_adjl_log_id")
        sb.Append(" FROM GPS_WHT W JOIN GPS_TRANSREF_REL T ON W.TAX_TRANSREF = T.TREF_TRANSREF ")
        sb.Append("AND W.TAX_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND W.TAX_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")
        sb.Append("WHERE T.TREF_GL_PERIOD > T.TREF_WHT_PERIOD ")
        sb.Append("AND SUBSTR(T.TREF_WHT_PERIOD,1,4)||SUBSTR(T.TREF_WHT_PERIOD,6,2)='" & period & "'   ")
        sb.Append("AND SUBSTR(T.TREF_GL_PERIOD,1,4)||SUBSTR(T.TREF_GL_PERIOD,6,2)='" & accperiod & "'   ")
        sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO   ")
        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function
    Public Function GetDataPhorNgorDor2Kor_ByYear(ByRef oleConn As OleDbConnection, ByVal taxyear As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT W.TAX_WHTNO,W.TAX_AP_TTL||W.TAX_AP_FNAME AS AP_NAME,W.TAX_AP_LNAME,W.TAX_TAXID AS TAXID,W.TAX_DESC,W.TAX_FLAG_CC AS CC, ")
        sb.Append("W.TAX_IDCARD AS IDCARD,W.TAX_TAXDATE,W.TAX_BASE_AMT,W.TAX_TAX_AMT,W.TAX_TAX_RATE, ")
        sb.Append("W.TAX_ADDRESS||' '||W.TAX_AMPENM||' '||W.TAX_PROVNM||' '||W.TAX_AGZIP AS ADDRESS,W.TAX_PRINTWHT_STS, W.TAX_PAYEE AS PAYEE ")
        sb.Append(", CASE WHEN SUBSTR(W.TAX_TAXDATE, 1, 4) < SUBSTR(COM_SETUP_5.COMP_TAXEF, 1, 4) THEN COM_SETUP_4.COMP_TAXO1 ELSE COM_SETUP_3.COMP_TAXID END COMP_TAXID ")
        sb.Append("FROM GPS_WHT W ")

        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXID FROM GPS_COMPANY_SETUP WHERE CODE = 'TAXI') COM_SETUP_3 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXO1 FROM GPS_COMPANY_SETUP WHERE CODE = 'TAO1') COM_SETUP_4 ON 1=1 ")
        sb.Append("LEFT JOIN (SELECT VALUE AS COMP_TAXEF FROM GPS_COMPANY_SETUP WHERE CODE = 'TAEF') COM_SETUP_5 ON 1=1 ")

        sb.Append("WHERE W.TAX_TAXDATE LIKE '" & taxyear & "%'  ")
        sb.Append("  AND W.TAX_PHORNGORDOR='02' ")
        sb.Append("ORDER BY W.TAX_SEQNO  ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function
    Public Function GetDataWHTByYear(ByRef oleConn As OleDbConnection, ByVal year As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT A.TAX_TAXID,A.TAX_IDCARD,A.TAX_AP_FNAME ")
        sb.Append(", Sum(A.M_1) M_1, Sum(A.M_2) M_2 ")
        sb.Append(", Sum(A.M_3) M_3, Sum(A.M_4) M_4, Sum(A.M_5) M_5 ")
        sb.Append(", Sum(A.M_6) M_6, Sum(A.M_7) M_7, Sum(A.M_8) M_8 ")
        sb.Append(", Sum(A.M_9) M_9, Sum(A.M_10) M_10, Sum(A.M_11) M_11 ")
        sb.Append(", Sum(A.M_12) M_12 ")
        sb.Append("FROM ( ")
        sb.Append("SELECT TAX_TAXID,TAX_IDCARD,TAX_AP_FNAME ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'01',TAX_BASE_AMT,0) AS M_1 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'02',TAX_BASE_AMT,0) AS M_2 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'03',TAX_BASE_AMT,0) AS M_3 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'04',TAX_BASE_AMT,0) AS M_4 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'05',TAX_BASE_AMT,0) AS M_5 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'06',TAX_BASE_AMT,0) AS M_6 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'07',TAX_BASE_AMT,0) AS M_7 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'08',TAX_BASE_AMT,0) AS M_8 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'09',TAX_BASE_AMT,0) AS M_9 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'10',TAX_BASE_AMT,0) AS M_10 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'11',TAX_BASE_AMT,0) AS M_11 ")
        sb.Append(", DECODE(SUBSTR(TAX_TAXDATE,5,2),'12',TAX_BASE_AMT,0) AS M_12 ")
        sb.Append("FROM GPS_WHT ")
        sb.Append("WHERE SUBSTR(TAX_TAXDATE,1,4)='" & year & "' AND TAX_PHORNGORDOR='" & phorngordor & "' AND TAX_FLAG_CC='N' ) A ")
        sb.Append("GROUP BY TAX_TAXID,TAX_IDCARD,TAX_AP_FNAME ")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function
    Public Function GetSummaryWHTReport(ByRef oleConn As OleDbConnection, ByVal period_from As String, ByVal period_to As String, ByVal whtperiod_from As String, ByVal whtperiod_to As String) As DataTable
        'Public Function GetSummaryWHTReport(ByRef oleConn As OleDbConnection, ByVal period_from As String, ByVal period_to As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT CP.GL_PERIOD,CP.TAX_PERIOD,CP.TAX_PHORNGORDOR AS PHORNGORDOR,NVL(CP.RCOMPLETE,0) AS RCOMPLETE,NVL(CC.RCANCEL,0) AS RCANCEL, ")
        sb.Append("NVL(CP.TAX_BASE_AMT,0) AS BASE_AMT ,NVL(CP.TAX_TAX_AMT,0) AS TAX_AMT  ")
        sb.Append("FROM  ")
        'sb.Append("(SELECT T.TREF_GL_PERIOD AS GL_PERIOD,SUBSTR(W.TAX_TAXDATE,1,4)||LPAD(SUBSTR(W.TAX_TAXDATE,5,2),3,'0') AS TAX_PERIOD, ")
        sb.Append("(SELECT T.TREF_GL_PERIOD AS GL_PERIOD,T.TREF_WHT_PERIOD AS TAX_PERIOD, ")
        sb.Append("W.TAX_PHORNGORDOR,COUNT(*) AS RCOMPLETE, ")
        sb.Append("SUM(W.TAX_BASE_AMT) AS TAX_BASE_AMT,SUM(W.TAX_TAX_AMT) AS TAX_TAX_AMT ")
        sb.Append("FROM (GPS_TRANSREF_REL T INNER JOIN GPS_WHT W ")
        sb.Append("ON T.TREF_CREATEDATE=W.TAX_CREATEDATE ")
        sb.Append("AND T.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM ")
        sb.Append("AND T.TREF_TRANSREF=W.TAX_TRANSREF) ")
        sb.Append("WHERE T.TREF_GL_PERIOD BETWEEN '" & period_from & "' AND '" & period_to & "' ")
        sb.Append("AND T.TREF_WHT_PERIOD BETWEEN '" & whtperiod_from & "' AND '" & whtperiod_to & "' ")
        sb.Append("AND W.TAX_FLAG_CC <> 'Y' ")
        'sb.Append("GROUP BY T.TREF_GL_PERIOD ,SUBSTR(W.TAX_TAXDATE,1,4)||LPAD(SUBSTR(W.TAX_TAXDATE,5,2),3,'0'),W.TAX_PHORNGORDOR)CP ")
        sb.Append("GROUP BY T.TREF_GL_PERIOD ,T.TREF_WHT_PERIOD,W.TAX_PHORNGORDOR)CP ")
        sb.Append("LEFT JOIN ")
        'sb.Append("(SELECT T.TREF_GL_PERIOD AS GL_PERIOD,SUBSTR(W.TAX_TAXDATE,1,4)||LPAD(SUBSTR(W.TAX_TAXDATE,5,2),3,'0') AS TAX_PERIOD, ")
        sb.Append("(SELECT T.TREF_GL_PERIOD AS GL_PERIOD,T.TREF_WHT_PERIOD AS TAX_PERIOD, ")
        sb.Append("W.TAX_PHORNGORDOR,COUNT(*) AS RCANCEL ")
        sb.Append("FROM (GPS_TRANSREF_REL T INNER JOIN GPS_WHT W ")
        sb.Append("ON T.TREF_CREATEDATE=W.TAX_CREATEDATE ")
        sb.Append("AND T.TREF_CORE_SYSTEM=W.TAX_CORE_SYSTEM ")
        sb.Append("AND T.TREF_TRANSREF=W.TAX_TRANSREF) ")
        sb.Append("WHERE T.TREF_GL_PERIOD BETWEEN '" & period_from & "' AND '" & period_to & "' ")
        sb.Append("AND T.TREF_WHT_PERIOD BETWEEN '" & whtperiod_from & "' AND '" & whtperiod_to & "' ")
        sb.Append("AND W.TAX_FLAG_CC='Y' ")
        'sb.Append("GROUP BY T.TREF_GL_PERIOD ,SUBSTR(W.TAX_TAXDATE,1,4)||LPAD(SUBSTR(W.TAX_TAXDATE,5,2),3,'0'),W.TAX_PHORNGORDOR)CC ")
        sb.Append("GROUP BY T.TREF_GL_PERIOD ,T.TREF_WHT_PERIOD,W.TAX_PHORNGORDOR)CC ")
        sb.Append("ON CP.GL_PERIOD=CC.GL_PERIOD ")
        sb.Append("AND CP.TAX_PERIOD=CC.TAX_PERIOD ")
        sb.Append("AND CP.TAX_PHORNGORDOR=CC.TAX_PHORNGORDOR ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataForCancel(ByRef oleConn As OleDbConnection, ByVal systemdate As String, Optional ByVal whtno As String = "", Optional ByVal datefrom As String = "", Optional ByVal dateto As String = "", _
    Optional ByVal taxid As String = "", Optional ByVal idcard As String = "", Optional ByVal payeename As String = "") As DataTable
        Dim sb As New StringBuilder
        Dim CrrMonth As String = ""
        Dim lastday As String = ""
        If Convert.ToInt16(systemdate.Substring(6, 2)) <= 7 Then
            If systemdate.Substring(4, 2) = "01" Then
                CrrMonth = Convert.ToInt16(systemdate.Substring(0, 4)).ToString - 1 & "1201"
            Else
                CrrMonth = Convert.ToInt16(systemdate.Substring(0, 4)).ToString & (Convert.ToInt16(systemdate.Substring(4, 2)) - 1).ToString.PadLeft(2, "0") & "01"
            End If
        Else
            CrrMonth = systemdate.Substring(0, 6) & "01"
        End If

        'MsgBox(CrrMonth & " " & systemdate)

        sb.Remove(0, sb.Length)

        sb.Append("SELECT W.TAX_WHTNO, ")
        sb.Append("  TO_CHAR(TO_DATE(W.TAX_TAXDATE,'YYYYMMDD'),'DD/MM/YYYY') AS TAX_DATE , ")
        sb.Append("  W.TAX_AP_FNAME AS TAX_PAYEE, ")
        sb.Append("  W.TAX_TAXID, ")
        sb.Append(" W.TAX_IDCARD, ")
        sb.Append("  W.TAX_BASE_AMT, ")
        sb.Append(" W.TAX_TAX_AMT, ")
        sb.Append(" W.TAX_TRANSREF, ")
        sb.Append(" T.DTS_JN_TYPE_R AS JN_TYPE, ")
        sb.Append(" T.DTS_CORE_SYSTEM AS CORE_SYSTEM ")
        sb.Append("FROM GPS_WHT W ")
        sb.Append("LEFT JOIN GPS_TRANSREF_REL ")
        sb.Append("ON W.TAX_CREATEDATE   = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        sb.Append("AND W.TAX_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        sb.Append("AND W.TAX_TRANSREF = GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" left join GPS_TL_DATASOURCE T ")
        sb.Append(" on GPS_TRANSREF_REL.TREF_CORE_SYSTEM = T.DTS_CORE_SYSTEM ")
        sb.Append(" and GPS_TRANSREF_REL.TREF_DTSOURCE = T.DTS_DTSOURCE ")
        sb.Append(" and GPS_TRANSREF_REL.TREF_DEP_KEYIN = T.DTS_DEP_KEYIN ")

        sb.Append("WHERE W.TAX_TAXDATE BETWEEN '" & CrrMonth & "' AND TO_CHAR(LAST_DAY(TO_DATE('" & systemdate & "','YYYYMMDD')),'YYYYMMDD') ")
        If whtno <> "" Then
            sb.Append("AND W.TAX_WHTNO= '" & whtno & "' ")
        End If
        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND W.TAX_TAXDATE BETWEEN '" & datefrom & "'  AND '" & dateto & "'")
        Else
            If datefrom <> "" Then
                sb.Append("AND W.TAX_TAXDATE = '" & datefrom & "' ")
            End If
            If dateto <> "" Then
                sb.Append("AND W.TAX_TAXDATE = '" & dateto & "'")
            End If
        End If
        If taxid <> "" Then
            sb.Append("AND W.TAX_TAXID = '" & taxid & "' ")
        End If
        If idcard <> "" Then
            sb.Append("AND W.TAX_IDCARD = '" & idcard & "' ")
        End If
        If payeename <> "" Then
            sb.Append("AND W.TAX_PAYEE like '%" & payeename & "%' ")
        End If
        'sb.Append("ORDER BY W.TAX_WHTNO ")

        sb.Append("AND W.TAX_FLAG_CC <> 'Y' ")

        sb.Append("ORDER BY W.TAX_TRANSREF , W.TAX_WHTNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function CancelWHT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal whtno As String, ByVal status As String, ByVal guserlogin As String) As Double

        Dim sb As New StringBuilder
        Dim rec As Integer


        sb.Append("UPDATE GPS_WHT SET ")
        sb.Append("TAX_FLAG_CC='Y',")
        sb.Append("TAX_CC_DATE=TO_CHAR(SYSDATE,'YYYYMMDD'),")
        sb.Append("TAX_CC_TYPE='" & status & "',")
        sb.Append("UPDATEDBY='" & guserlogin & "', ")
        sb.Append("UPDATEDDATE=TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("WHERE TAX_WHTNO = '" & whtno & "' ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
        Return rec

    End Function

    Public Function GetDataGLForCancel(ByRef oleConn As OleDbConnection, ByVal systemdate As String, Optional ByVal whtno As String = "", Optional ByVal datefrom As String = "", Optional ByVal dateto As String = "", _
        Optional ByVal taxid As String = "", Optional ByVal idcard As String = "", Optional ByVal payeename As String = "") As DataTable
        Dim sb As New StringBuilder
        Dim CrrMonth As String = ""
        Dim lastday As String = ""
        If Convert.ToInt16(systemdate.Substring(6, 2)) <= 7 Then
            If systemdate.Substring(4, 2) = "01" Then
                CrrMonth = Convert.ToInt16(systemdate.Substring(0, 4)).ToString - 1 & "1201"
            Else
                CrrMonth = Convert.ToInt16(systemdate.Substring(0, 4)).ToString & (Convert.ToInt16(systemdate.Substring(4, 2)) - 1).ToString.PadLeft(2, "0") & "01"
            End If
        Else
            CrrMonth = systemdate.Substring(0, 6) & "01"
        End If

        sb.Append("SELECT * FROM (  ")
        sb.Append("	SELECT ")
        sb.Append(" DECODE(SUBSTR(CR.GLCR_JN_TYPE,1,1), 'C' , 'R' ")
        sb.Append(" ||SUBSTR(CR.GLCR_JN_TYPE,2,2), DECODE(SUBSTR(CR.GLCR_JN_TYPE,1,1), 'T' , 'R' ")
        sb.Append(" ||SUBSTR(CR.GLCR_JN_TYPE,2,2), CR.GLCR_JN_TYPE)) AS JN_TYPE ")
        sb.Append("  , CR.GLCR_CORE_SYSTEM AS CORE_SYSTEM ")
        sb.Append("  , CR.GLCR_JN_SOURCE AS JN_SOURCE ")
        sb.Append("  , CR.GLCR_B_UNIT AS B_UNIT ")
        sb.Append("  , CR.GLCR_GL_PERIOD AS GL_PERIOD ")
        sb.Append("  , CR.GLCR_JN_NO_C AS JN_NO_C ")
        sb.Append("  , CR.GLCR_VCH_NO_C AS VCH_NO_C ")
        sb.Append("  , CR.GLCR_TRANSREF AS TRANSREF ")
        sb.Append("  , CR.GLCR_S_ACCOUNT AS S_ACCOUNT ")
        sb.Append("  , CR.GLCR_LINENO AS LINENO ")

        'sb.Append("  , CR.GLCR_TRANSDATE AS TRANSDATE ")
        'sb.Append("  , CR.GLCR_DUEDATE AS DUEDATE ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') AS TRANSDATE ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') AS DUEDATE ")

        sb.Append("  , CR.GLCR_DESC AS GL_DESC ")
        sb.Append("  , CR.GLCR_AMOUNT AS AMOUNT ")
        sb.Append("  , CR.GLCR_DRCR AS DRCR ")
        sb.Append("  , CR.GLCR_S_DEP_BRN AS S_DEP_BRN ")
        sb.Append("  , CR.GLCR_S_PL_PT AS S_PL_PT ")
        sb.Append("  , CR.GLCR_S_MKT_EMP AS S_MKT_EMP ")
        sb.Append("  , CR.GLCR_S_TT_TR AS S_TT_TR ")
        sb.Append("  , CR.GLCR_S_PROJECT AS S_PROJECT ")
        sb.Append("  , CR.GLCR_LINENO AS S_LINENO ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_GL_CREATION CR ")
        sb.Append("  WHERE CR.GLCR_TRANSREF IN " & whtno & " ")
        sb.Append("  UNION ")
        sb.Append("  SELECT  ")
        sb.Append(" DECODE(SUBSTR(L.GLLD_JN_TYPE,1,1), 'C' , 'R' ")
        sb.Append("   ||SUBSTR(L.GLLD_JN_TYPE,2,2), DECODE(SUBSTR(L.GLLD_JN_TYPE,1,1), 'T' , 'R' ")
        sb.Append("   ||SUBSTR(L.GLLD_JN_TYPE,2,2), L.GLLD_JN_TYPE)) AS JN_TYPE ")
        sb.Append(" , L.GLLD_CORE_SYSTEM AS CORE_SYSTEM ")
        sb.Append("  , L.GLLD_JN_SOURCE AS JN_SOURCE ")
        sb.Append("  , L.GLLD_B_UNIT ")
        sb.Append("  , L.GLLD_GL_PERIOD ")
        sb.Append("  , L.GLLD_JN_NO_C ")
        sb.Append("  , L.GLLD_VCH_NO_C ")
        sb.Append("  , L.GLLD_TRANSREF AS TRANSREF ")
        sb.Append("  , L.GLLD_S_ACCOUNT AS S_ACCOUNT ")
        sb.Append("  , L.GLLD_LINENO AS LINENO ")

        'sb.Append("  , L.GLLD_TRANSDATE AS TRANSDATE ")
        'sb.Append("  , L.GLLD_DUEDATE AS DUEDATE ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') AS TRANSDATE ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD') AS DUEDATE ")

        sb.Append("  , L.GLLD_DESC AS GL_DESC ")
        sb.Append("  , L.GLLD_AMOUNT AS AMOUNT ")
        sb.Append("  , L.GLLD_DRCR AS DRCR ")
        sb.Append("  , L.GLLD_S_DEP_BRN AS S_DEP_BRN ")
        sb.Append("  , L.GLLD_S_PL_PT AS S_PL_PT ")
        sb.Append("  , L.GLLD_S_MKT_EMP AS S_MKT_EMP ")
        sb.Append("  , L.GLLD_S_TT_TR AS S_TT_TR ")
        sb.Append("  , L.GLLD_S_PROJECT AS S_PROJECT ")
        sb.Append("  , L.GLLD_LINENO AS S_LINENO ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_GL_LOAD L ")
        sb.Append("  WHERE L.GLLD_TRANSREF IN " & whtno & " ")
        sb.Append(" ) MasterData")
        sb.Append(" ORDER BY S_LINENO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GLDailyCancelWHT(ByRef oleConn As OleDbConnection, ByVal oleTrans As OleDbTransaction, ByVal whtno As String, ByVal status As String, ByVal guserlogin As String) As Double

        Dim sb As New StringBuilder
        Dim rec As Integer

        '<<<====================== Get Head Setup
        Dim dataSrcName As String = ""
        Dim dataGlsts As String = ""
        Dim dataBookId As String = ""
        Dim dataCatName As String = ""
        Dim dataCurCode As String = ""
        Dim dataActFlg As String = ""
        Dim dataComCode As String = ""
        Dim dataRcCode As String = ""

        Dim dtGps As DataTable
        dtGps = GetGpsGlHeadSetUp(oleConn)
        If Not IsNothing(dtGps) AndAlso dtGps.Rows.Count > 0 Then
            dataSrcName = dtGps.Rows(0)("SOURCE_NME").ToString()
            dataGlsts = dtGps.Rows(0)("GLSTS").ToString()
            dataBookId = dtGps.Rows(0)("BOOKID").ToString()
            dataCatName = dtGps.Rows(0)("CATEGORY_NME").ToString()
            dataCurCode = dtGps.Rows(0)("CURRENCY_CDE").ToString()
            dataActFlg = dtGps.Rows(0)("ACTUAL_FLAG").ToString()
            dataComCode = dtGps.Rows(0)("COMPANY_CDE").ToString()
            dataRcCode = dtGps.Rows(0)("RCCODE").ToString()
        End If
        '<<<====================== END

        sb.Append(" INSERT INTO GENERATEPAYMENT.GLM_GL_DAILY  ( ")
        sb.Append(" GL_POSTING_DATE ")
        sb.Append("  , GL_SYSTEM_NAME ")
        sb.Append("  , GL_JN_TYPE ")
        sb.Append("  , GL_JN_SOURCE")
        sb.Append("  , GL_B_UNIT")
        sb.Append("  , GL_PERIOD")
        sb.Append("  , GL_JN_NO")
        sb.Append("  , GL_VCH_NO")
        sb.Append("  , GL_TRANSREF")
        sb.Append("  , GL_S_ACCOUNT")
        sb.Append("  , GL_LINENO")
        sb.Append("  , GL_GLSTS")
        sb.Append("  , GL_BOOKID")
        sb.Append("  , GL_SOURCE_NME")
        sb.Append("  , GL_CATEGORY_NME")
        sb.Append("  , GL_CURRENCY_CDE")
        sb.Append(" , GL_ACTUAL_FLAG")
        sb.Append("  , GL_COMPANY_CDE")
        sb.Append("  , GL_RCCODE")
        sb.Append("  , GL_TRANSDATE")
        sb.Append("  , GL_DUEDATE")
        sb.Append("  , GL_DESC")
        sb.Append("  , GL_AMOUNT")
        sb.Append("  , GL_DRCR")
        sb.Append("  , GL_S_DEP_BRN")
        sb.Append("  , GL_S_PL_PT")
        sb.Append("  , GL_S_MKT_EMP")
        sb.Append("  , GL_S_TT_TR")
        sb.Append("  , GL_S_PROJECT")
        sb.Append("  , CREATEDBY")
        sb.Append("  , CREATEDDATE")
        sb.Append("  , UPDATEDBY ")
        sb.Append("  , UPDATEDDATE")
        sb.Append("  ) VALUES  ( ")
        sb.Append(" '20141027' ")
        sb.Append("  , 'GPSA' ")
        sb.Append("  , 'RD' ")
        sb.Append("  , 'PP' ")
        sb.Append("  , 'SCB' ")
        sb.Append("  ,  '2014010' ")
        sb.Append("  , '1400020' ")
        sb.Append("  , 'RD1400020' ")
        sb.Append("  ,  '" & whtno & "' ")
        sb.Append("  , '1220100000' ")
        sb.Append("  , 1 ")

        sb.Append("  , '" & dataGlsts & "' ")
        sb.Append("  , '" & dataBookId & "' ")
        sb.Append("  , '" & dataSrcName & "' ")
        sb.Append("  , '" & dataCatName & "' ")
        sb.Append("  , '" & dataCurCode & "' ")
        sb.Append(" , '" & dataActFlg & "' ")
        sb.Append("  , '" & dataComCode & "' ")
        sb.Append("  , '" & dataRcCode & "' ")

        sb.Append("  , '20141027' ")
        sb.Append("  , '20141027' ")
        sb.Append("  , '��������' ")
        sb.Append("  , 100 ")
        sb.Append("  , 'D' ")
        sb.Append("  , '000-0101' ")
        sb.Append("  , '0-000' ")
        sb.Append("  , '000-00000' ")
        sb.Append("  , '00000000' ")
        sb.Append("  , '00000' ")
        sb.Append("  , 'SYSTEMCan' ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("  , 'SYSTEMCan' ")
        sb.Append("  , TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
        sb.Append("  ) ")

        rec = clsBusiness.ExecuteCommand(oleConn, sb, oleTrans)
        Return rec

    End Function

    Public Function GetGpsGlHeadSetUp(ByRef oleConn As OleDbConnection) As DataTable
        Dim sb As New StringBuilder
        Dim dt As DataTable

        sb.Append("SELECT")
        sb.Append("  GPS_GL_HEAD_SETUP.GLHS_SOURCE_NME as SOURCE_NME ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_GLSTS as GLSTS ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_BOOKID as BOOKID ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_CATEGORY_NME as CATEGORY_NME ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_CURRENCY_CDE as CURRENCY_CDE ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_ACTUAL_FLAG as ACTUAL_FLAG ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_COMPANY_CDE as COMPANY_CDE ")
        sb.Append(", GPS_GL_HEAD_SETUP.GLHS_RCCODE as RCCODE ")
        sb.Append("FROM GPS_GL_HEAD_SETUP ")

        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Function CALL_GLM_SP_LOG_IMPORTGLMFEED(ByRef oleConn As OleDbConnection, ByVal jnNo As String, ByVal user As String, Optional ByRef oTrans As OleDbTransaction = Nothing)

        Dim dbComm As OleDbCommand

        Dim sysdate As String = Now.ToString("yyyyMMdd")

        dbComm = oleConn.CreateCommand
        dbComm.Parameters.Add("p_Filename", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Filename").Value = ""
        dbComm.Parameters.Add("p_BatchName", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_BatchName").Value = sysdate
        dbComm.Parameters.Add("p_Description", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Description").Value = "GPS_SCREEN_CANCEL_TAX"
        dbComm.Parameters.Add("p_Status", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Status").Value = "SUCCESS"
        dbComm.Parameters.Add("p_Start_Date", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_Start_Date").Value = sysdate
        dbComm.Parameters.Add("p_ErrorMsg", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_ErrorMsg").Value = ""
        dbComm.Parameters.Add("p_GL_JN_NO", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_GL_JN_NO").Value = jnNo
        dbComm.Parameters.Add("p_GL_VCH_NO", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_GL_VCH_NO").Value = ""
        dbComm.Parameters.Add("p_GL_LINENO", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_GL_LINENO").Value = ""
        dbComm.Parameters.Add("p_SOURCENAME", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_SOURCENAME").Value = "GPSA"
        dbComm.Parameters.Add("p_user", OleDbType.VarChar, 100).Direction = ParameterDirection.Input
        dbComm.Parameters("p_user").Value = user
        dbComm.Parameters.Add("result_return", OleDbType.VarChar, 100).Direction = ParameterDirection.Output
        dbComm.Parameters.Add("result_msg", OleDbType.VarChar, 100).Direction = ParameterDirection.Output

        dbComm.Transaction = oTrans
        dbComm.CommandText = "GLM_SP_LOG_IMPORTGLMFEED_CLNT"
        dbComm.CommandType = CommandType.StoredProcedure
        dbComm.ExecuteNonQuery()


        If dbComm.Parameters("result_return").Value = True Then
            Return 1
        Else
            Return -1
        End If
    End Function

    Public Function GetDataForUpdWHT(ByRef oleConn As OleDbConnection, Optional ByVal whtno As String = "", Optional ByVal datefrom As String = "", Optional ByVal dateto As String = "", _
    Optional ByVal taxid As String = "", Optional ByVal idcard As String = "") As DataTable
        Dim sb As New StringBuilder

        sb.Remove(0, sb.Length)

        sb.Append(" SELECT W.TAX_WHTNO, ")
        sb.Append("   W.TAX_TAXID, ")
        sb.Append("   W.TAX_IDCARD, ")
        sb.Append("   W.TAX_AP_TTL, ")
        sb.Append("   (SELECT MAX(GS.SUPP_NAME_TAX) FROM GLM_SUPPLIER_SETUP GS ")
        sb.Append("   WHERE GS.SUPP_TAXID = W.TAX_TAXID OR GS.SUPP_TAXID = W.TAX_IDCARD AND GS.SUPP_STATUS='ACTIVE') AS TAX_AP_FNAME, ")
        sb.Append("   (SELECT MAX(GS.SUPP_ADDRESS_TAX) FROM GLM_SUPPLIER_SETUP GS ")
        sb.Append("   WHERE GS.SUPP_TAXID = W.TAX_TAXID OR GS.SUPP_TAXID = W.TAX_IDCARD AND GS.SUPP_STATUS='ACTIVE') AS TAX_ADDRESS, ")
        sb.Append("   W.TAX_AMPENM, ")
        sb.Append("   W.TAX_PROVNM, ")
        sb.Append("   W.TAX_AGZIP, ")
        sb.Append("   W.TAX_TAXITEM, ")
        sb.Append("   W.TAX_BASE_AMT, ")
        sb.Append("   W.TAX_TAX_AMT, ")
        sb.Append("   W.TAX_TAX_RATE, ")
        sb.Append("   W.TAX_DESC, ")
        sb.Append("   W.TAX_CREATEDATE, ")
        sb.Append("   W.TAX_CORE_SYSTEM, ")
        sb.Append("   W.TAX_TRANSREF, ")
        sb.Append("   W.TAX_GPTREF_SEQNO, ")
        sb.Append("   W.TAX_LINENO ")
        sb.Append(" FROM GPS_WHT W ")
        sb.Append(" JOIN GPS_TRANSREF_REL  ")
        sb.Append(" ON W.TAX_CREATEDATE   = GPS_TRANSREF_REL.TREF_CREATEDATE ")
        sb.Append(" AND W.TAX_CORE_SYSTEM = GPS_TRANSREF_REL.TREF_CORE_SYSTEM ")
        sb.Append(" AND W.TAX_TRANSREF    = GPS_TRANSREF_REL.TREF_TRANSREF ")
        sb.Append(" LEFT JOIN GPS_TL_DATASOURCE T ")
        sb.Append(" ON GPS_TRANSREF_REL.TREF_CORE_SYSTEM = T.DTS_CORE_SYSTEM ")
        sb.Append(" AND GPS_TRANSREF_REL.TREF_DTSOURCE   = T.DTS_DTSOURCE ")
        sb.Append(" AND GPS_TRANSREF_REL.TREF_DEP_KEYIN  = T.DTS_DEP_KEYIN ")
        sb.Append(" WHERE 1=1 ")
        If whtno <> "" Then
            sb.Append("AND W.TAX_WHTNO= '" & whtno & "' ")
        End If
        If datefrom <> "" And dateto <> "" Then
            sb.Append("AND W.TAX_TAXDATE BETWEEN '" & datefrom & "'  AND '" & dateto & "'")
        Else
            If datefrom <> "" Then
                sb.Append("AND W.TAX_TAXDATE = '" & datefrom & "' ")
            End If
            If dateto <> "" Then
                sb.Append("AND W.TAX_TAXDATE = '" & dateto & "'")
            End If
        End If
        If taxid <> "" Then
            sb.Append("AND W.TAX_TAXID = '" & taxid & "' ")
        End If
        If idcard <> "" Then
            sb.Append("AND W.TAX_IDCARD = '" & idcard & "' ")
        End If

        sb.Append("ORDER BY W.TAX_TRANSREF , W.TAX_WHTNO ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function UpdateWHT(ByRef oleConn As OleDbConnection, ByRef transation As OleDbTransaction, ByVal taxID As String, ByVal idCard As String, _
                              ByVal apFname As String, ByVal adDress As String, ByVal desc As String, _
                              ByVal taxCreateDate As String, ByVal coreSystem As String, ByVal transRef As String, _
                              ByVal gptRefseqno As String, ByVal user As String, ByVal tableName As String, _
                              ByVal taxItem As String, ByVal baseAmount As String, ByVal tax_lineno As String)
        Dim sb As New StringBuilder
        Dim rec As Integer
        Dim col As String = ""

        If tableName = "GPS_WHT_COMPLETE" Then
            col = "CM"
        ElseIf tableName = "GPS_WHT_CREATION" Then
            col = "CR"
        ElseIf tableName = "GPS_WHT_LOAD" Then
            col = "LD"
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_TAXID = '" & taxID & "', ")
            sb.Append("    TAX" & col & "_IDCARD = '" & idCard & "', ")
            sb.Append("    TAX" & col & "_AP_FNAME = '" & apFname & "', ")
            sb.Append("    TAX" & col & "_ADDRESS = '" & adDress & "', ")
            sb.Append("    TAX" & col & "_DESC = '" & desc & "', ")
            sb.Append("    TAX" & col & "_TAXITEM = '" & taxItem & "', ")
            sb.Append("    TAX" & col & "_BASE_AMT = '" & baseAmount & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_BATCHDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            sb.Append(" AND   TAX" & col & "_LINENO = '" & tax_lineno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        ElseIf tableName = "GPS_WHT_REJ" Then
            col = "RJ"
        Else
            col = ""
        End If

        If tableName <> "GPS_WHT_LOAD" Then
            'Update
            sb.Remove(0, sb.Length)
            sb.Append(" UPDATE " & tableName & "  SET   ")
            sb.Append("    TAX" & col & "_TAXID = '" & taxID & "', ")
            sb.Append("    TAX" & col & "_IDCARD = '" & idCard & "', ")
            sb.Append("    TAX" & col & "_AP_FNAME = '" & apFname & "', ")
            sb.Append("    TAX" & col & "_ADDRESS = '" & adDress & "', ")
            sb.Append("    TAX" & col & "_DESC = '" & desc & "', ")
            sb.Append("    TAX" & col & "_TAXITEM = '" & taxItem & "', ")
            sb.Append("    TAX" & col & "_BASE_AMT = '" & baseAmount & "', ")
            sb.Append("    UPDATEDBY = '" & user & "', ")
            sb.Append("    UPDATEDDATE = TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI') ")
            sb.Append(" WHERE TAX" & col & "_CREATEDATE = '" & taxCreateDate & "' ")
            sb.Append(" AND   TAX" & col & "_CORE_SYSTEM = '" & coreSystem & "' ")
            sb.Append(" AND   TAX" & col & "_TRANSREF = '" & transRef & "' ")
            sb.Append(" AND   TAX" & col & "_GPTREF_SEQNO = '" & gptRefseqno & "' ")
            sb.Append(" AND   TAX" & col & "_LINENO = '" & tax_lineno & "' ")
            rec = clsBusiness.ExecuteCommand(oleConn, sb, transation)
        End If
        If rec = -1 Then
            Return rec
        Else
            Return 1
        End If
    End Function

    Public Function fnGet_baseAmt(ByRef oleConn As OleDbConnection, ByVal whtNo As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet

            sb.Append("SELECT GPS_WHT.TAX_BASE_AMT FROM GPS_WHT WHERE GPS_WHT.TAX_WHTNO = '" & whtNo & "' ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGet_baseAmt = Ds.Tables(0).Rows(0)("TAX_BASE_AMT")

        Catch ex As Exception
            fnGet_baseAmt = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fnGet_apName(ByRef oleConn As OleDbConnection, ByVal taxId As String, ByVal idCard As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT MAX(T.SUPP_NAME_TAX) as SUPP_NAME_TAX FROM GLM_SUPPLIER_SETUP T WHERE T.SUPP_TAXID = '" & taxId & "' OR T.SUPP_TAXID = '" & idCard & "' AND T.SUPP_STATUS='ACTIVE' ORDER BY T.SUPP_CODE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGet_apName = Ds.Tables(0).Rows(0)("SUPP_NAME_TAX")

        Catch ex As Exception
            fnGet_apName = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function fnGet_apAddress(ByRef oleConn As OleDbConnection, ByVal taxId As String, ByVal idCard As String) As String
        Try
            Dim sb As New StringBuilder()
            Dim Ds As New DataSet
            sb.Append("SELECT MAX(T.SUPP_ADDRESS_TAX) as SUPP_ADDRESS_TAX FROM GLM_SUPPLIER_SETUP T WHERE T.SUPP_TAXID = '" & taxId & "' OR T.SUPP_TAXID = '" & idCard & "' AND T.SUPP_STATUS='ACTIVE' ORDER BY T.SUPP_CODE ")

            clsBusiness.ExecuteReader(oleConn, Ds, sb.ToString)
            fnGet_apAddress = Ds.Tables(0).Rows(0)("SUPP_ADDRESS_TAX")

        Catch ex As Exception
            fnGet_apAddress = ""
            gLastErrMessage = ex.ToString
        End Try
    End Function

    Public Function GetDataPhorngordor2(ByRef oleConn As OleDbConnection, ByVal strFromDate As String, ByVal strToDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT '2' ") '--A1 �Թ�����ҵ��
        sb.Append("     || '|' || TRIM(TO_CHAR(COUNT(*) OVER (ORDER BY T.TAX_SEQNO))) ") '--A2 �ӴѺ���
        sb.Append("     || '|' || T.TAX_IDCARD ") '--A3 �Ţ��Шӵ�Ǽ����������
        sb.Append("     || '|' || '' ") ' --A4 �ӹ�˹�Ҫ���
        sb.Append("     || '|' || SUBSTR(T.TAX_AP_FNAME, 1, 80) ") '--A5 ����
        sb.Append("     || '|' || '' ") '--A6 ���ʡ��
        sb.Append("     || '|' || '' ") '--A7 �Ţ���ѭ���Թ�ҡ
        sb.Append("     || '|' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 7, 2)) || '/' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 5, 2)) || '/' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 1, 4)+543) ") '--A8 �ѹ��͹�շ�����
        sb.Append("     || '|' || TO_CHAR(T.TAX_TAX_RATE) ") '--A9 �ѵ������
        sb.Append("     || '|' || CASE T.TAX_FLAG_CC WHEN 'Y' THEN '' ELSE TRIM(TO_CHAR(T.TAX_BASE_AMT, '99999999999999999.99')) END ") '--A10 �ӹǹ�Թ������
        sb.Append("     || '|' || CASE T.TAX_FLAG_CC WHEN 'Y' THEN '' ELSE TRIM(TO_CHAR(T.TAX_TAX_AMT, '99999999999999999.99')) END ") '--A11 �ӹǹ�Թ���շ���ѡ
        sb.Append("     || '|' || T.TAX_PAYEE ") '--A12  '1' ���͹䢡�þѡ����
        sb.Append("     || '|' as data ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_WHT T")
        sb.Append(" WHERE 1=1")
        sb.Append("   AND T.TAX_CREATEDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")
        sb.Append("   AND T.TAX_TAXTYPE = 3")
        sb.Append(" ORDER BY T.TAX_CONFIRMDATE, T.TAX_WHTNO")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
            End If
    End Function

    Public Function GetDataPhorngordor2_Exten(ByRef oleConn As OleDbConnection, ByVal strFromDate As String, ByVal strToDate As String) As DataTable
        Dim sb As New StringBuilder

        sb.Append("SELECT '2' ") '--A1 �Թ�����ҵ��
        sb.Append("     || '|' || TRIM(TO_CHAR(COUNT(*) OVER (ORDER BY T.TAX_SEQNO))) ") '--A2 �ӴѺ���
        sb.Append("     || '|' || T.TAX_IDCARD ") '--A3 �Ţ��Шӵ�Ǽ����������
        sb.Append("     || '|' || '' ") ' --A4 �ӹ�˹�Ҫ���
        sb.Append("     || '|' || SUBSTR(T.TAX_AP_FNAME, 1, 80) ") '--A5 ����
        sb.Append("     || '|' || '' ") '--A6 ���ʡ��
        sb.Append("     || '|' || '' ") '--A7 �Ţ���ѭ���Թ�ҡ
        sb.Append("     || '|' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 7, 2)) || '/' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 5, 2)) || '/' || TO_CHAR(SUBSTR(T.TAX_TAXDATE, 1, 4)+543) ") '--A8 �ѹ��͹�շ�����
        sb.Append("     || '|' || TO_CHAR(T.TAX_TAX_RATE) ") '--A9 �ѵ������
        sb.Append("     || '|' || CASE T.TAX_FLAG_CC WHEN 'Y' THEN '' ELSE TRIM(TO_CHAR(T.TAX_BASE_AMT, '99999999999999999.99')) END ") '--A10 �ӹǹ�Թ������
        sb.Append("     || '|' || CASE T.TAX_FLAG_CC WHEN 'Y' THEN '' ELSE TRIM(TO_CHAR(T.TAX_TAX_AMT, '99999999999999999.99')) END ") '--A11 �ӹǹ�Թ���շ���ѡ
        sb.Append("     || '|' || T.TAX_PAYEE ") '--A12  '1' ���͹䢡�þѡ����
        sb.Append("     || '|' as data ")
        sb.Append("  FROM GENERATEPAYMENT.GPS_WHT T")
        sb.Append(" WHERE 1=1")
        sb.Append("   AND T.TAX_CREATEDATE > '" & strToDate & "'")
        sb.Append("   AND T.TAX_TAXDATE BETWEEN '" & strFromDate & "' AND '" & strToDate & "'")
        sb.Append("   AND T.TAX_TAXTYPE = 3")
        sb.Append(" ORDER BY T.TAX_CONFIRMDATE, T.TAX_WHTNO")


        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
            Return dt
        Else
            Return Nothing
        End If
    End Function

    Public Function GetDataPhorNgorDorToSWC_ByPeriod(ByRef oleConn As OleDbConnection, ByVal period As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        '--sb.Append("SELECT W.* ")
        sb.Append("select w.tax_seqno, w.tax_whtno, w.tax_confirmdate, w.tax_createdate, w.tax_core_system, w.tax_transref, w.tax_gptref_seqno, w.tax_lineno, w.tax_taxid, w.tax_idcard, w.tax_ap_ttl, w.tax_ap_fname, w.tax_ap_lname, w.tax_address, w.tax_ampenm, w.tax_provnm, w.tax_agzip, w.tax_taxtype, w.tax_phorngordor, w.tax_taxitem, w.tax_taxdate, case w.tax_flag_cc when 'Y' then 0 else w.tax_base_amt end tax_base_amt, case w.tax_flag_cc when 'Y' then 0 else w.tax_tax_amt end tax_tax_amt, w.tax_payee, w.tax_tax_rate, w.tax_desc, w.tax_gl_account, w.tax_printwht_sts, w.tax_printwht_stsdate, w.tax_flag_cc, w.tax_cc_date, w.createdby, w.createddate, w.updatedby, w.updateddate, w.tax_cc_type, w.tax_adjl_log_id")
        sb.Append(" FROM GPS_WHT W INNER JOIN GPS_TRANSREF_REL T ON W.TAX_TRANSREF = T.TREF_TRANSREF ")
        sb.Append("AND W.TAX_CREATEDATE=T.TREF_CREATEDATE ")
        sb.Append("AND W.TAX_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")
        sb.Append("WHERE T.TREF_GL_PERIOD <= T.TREF_WHT_PERIOD ")
        sb.Append("AND SUBSTR(T.TREF_WHT_PERIOD,1,4)||SUBSTR(T.TREF_WHT_PERIOD,6,2)='" & period & "'   ")
        sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO   ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function

    Public Function GetDataPhorNgorDorToSWC_ByYear(ByRef oleConn As OleDbConnection, ByVal period As String, ByVal phorngordor As String) As DataTable
        Dim sb As New StringBuilder

        '--sb.Append("SELECT W.* ")
        sb.Append("select w.tax_seqno, w.tax_whtno, w.tax_confirmdate, w.tax_createdate, w.tax_core_system, w.tax_transref, w.tax_gptref_seqno, w.tax_lineno, w.tax_taxid, w.tax_idcard, w.tax_ap_ttl, w.tax_ap_fname, w.tax_ap_lname, w.tax_address, w.tax_ampenm, w.tax_provnm, w.tax_agzip, w.tax_taxtype, w.tax_phorngordor, w.tax_taxitem, w.tax_taxdate, case w.tax_flag_cc when 'Y' then 0 else w.tax_base_amt end tax_base_amt, case w.tax_flag_cc when 'Y' then 0 else w.tax_tax_amt end tax_tax_amt, w.tax_payee, w.tax_tax_rate, w.tax_desc, w.tax_gl_account, w.tax_printwht_sts, w.tax_printwht_stsdate, w.tax_flag_cc, w.tax_cc_date, w.createdby, w.createddate, w.updatedby, w.updateddate, w.tax_cc_type, w.tax_adjl_log_id")
        sb.Append(" FROM GPS_WHT W ") 'INNER JOIN GPS_TRANSREF_REL T ON W.TAX_TRANSREF = T.TREF_TRANSREF ")
        'sb.Append("AND W.TAX_CREATEDATE=T.TREF_CREATEDATE ")
        'sb.Append("AND W.TAX_CORE_SYSTEM=T.TREF_CORE_SYSTEM ")
        'sb.Append("WHERE T.TREF_GL_PERIOD <= T.TREF_WHT_PERIOD ")
        'sb.Append("AND SUBSTR(T.TREF_WHT_PERIOD,1,4)='" & period & "'   ")
        sb.Append("WHERE W.TAX_TAXDATE LIKE '" & period & "%'  ")
        sb.Append("AND W.TAX_PHORNGORDOR='" & phorngordor & "'  ")
        sb.Append("ORDER BY W.TAX_SEQNO   ")

        Dim dt As DataTable
        dt = clsBusiness.ExecuteReaderCommand(oleConn, sb)

        'If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
        Return dt
        'Else
        '    Return Nothing
        'End If
    End Function

    Private Function GetTaxSWCFormatH(ByRef conConn As System.Data.OleDb.OleDbConnection, ByRef strTaxTypeCode As String) As DataTable
        Try
            Dim dt As DataTable
            Dim cls As New clsGPS_TAXSWC_FORMAT_SETUP
            Dim dtTaxType As DataTable
            Dim clsTaxType As New clsGPS_TAXSWC_TAXTYPE_SETUP
            With clsTaxType
                .ConnDB = conConn
                dtTaxType = .GetRecord("tax_type_code = '" & strTaxTypeCode & "'")
            End With
            With cls
                .ConnDB = conConn
                dt = .GetRecord("LINE_TYPE = 'H' and TAX_TYPE = " & dtTaxType.Rows(0).Item("id").ToString.Trim & "")
                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    cls = Nothing
                    clsTaxType = Nothing
                    Return dt
                Else
                    cls = Nothing
                    clsTaxType = Nothing
                    Return Nothing
                End If
            End With

        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Private Function GetTaxSWCFormatD(ByRef conConn As System.Data.OleDb.OleDbConnection, ByRef strTaxTypeCode As String) As DataTable
        Try
            Dim dt As DataTable
            Dim cls As New clsGPS_TAXSWC_FORMAT_SETUP
            Dim dtTaxType As DataTable
            Dim clsTaxType As New clsGPS_TAXSWC_TAXTYPE_SETUP
            With clsTaxType
                .ConnDB = conConn
                dtTaxType = .GetRecord("tax_type_code = '" & strTaxTypeCode & "'")
            End With
            With cls
                .ConnDB = conConn
                dt = .GetRecord("LINE_TYPE = 'D' and TAX_TYPE = " & dtTaxType.Rows(0).Item("id").ToString.Trim & "")
                If Not IsNothing(dt) AndAlso dt.Rows.Count > 0 Then
                    cls = Nothing
                    clsTaxType = Nothing
                    Return dt
                Else
                    cls = Nothing
                    clsTaxType = Nothing
                    Return Nothing
                End If
            End With

        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Private Function TaxSplitField(ByRef strField As String) As String()
        Try
            Dim strResult As String()
            Dim str() As String = strField.Split(";;")
            strResult = Split(str(0).ToString, "||")
            Return strResult
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function TaxSplitLen(ByRef strLen As String) As String()
        Try
            Dim strResult As String()
            Dim str As String() '--= strLen.Split(";;")
            str = Split(strLen, ";;")
            strResult = Split(";", ";")
            strResult(0) = str(1)
            strResult(1) = str(2)
            Return strResult
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function TaxFieldConcate(ByRef drRowD As DataRow, ByRef strField As String) As String
        Try
            Dim strResult As String
            Dim intLine As Integer = 0
            Dim strFS As String()
            Dim strFS2 As String()
            Dim strFS3 As String()
            Dim strFL As String()
            Dim strFC As String = String.Empty
            Dim strFC2 As String = String.Empty
            Dim strFConcate As String = String.Empty
            If strField.ToString.Contains("||") AndAlso strField.ToString.Contains(";;") Then
                strFS = TaxSplitField(strField.ToString)
                For Each strF As String In strFS
                    strFC = strFC & drRowD.Item(strF.ToString).ToString.Trim & " "
                Next
                strFS2 = strFC.Split(" ")
                strFS3 = Split(";;;;;;;;;", ";")
                strFL = TaxSplitLen(strField.ToString)
                intLine = 1
                For Each strF2 As String In strFS2
                    If Len(strFC2 & strF2 & " ") < Val(strFL(0)) Then
                        strFC2 = strFC2 & strF2 & " "
                        strFS3(intLine - 1) = strFC2.Trim
                    Else
                        intLine += 1
                        strFC2 = String.Empty
                    End If
                Next
                strResult = strFS3(Val(strFL(1)) - 1).Trim
            ElseIf strField.ToString.Contains("||") Then
                strFS = TaxSplitField(strField.ToString)
                For Each strF As String In strFS
                    strFC = strFC & drRowD.Item(strF.ToString).ToString.Trim & " "
                Next
                strResult = strFC.Trim
            Else
                strResult = drRowD.Item(strField).ToString.Trim
            End If
            Return strResult
        Catch ex As Exception
            Return String.Empty
        End Try
    End Function

    Private Function ReformatData(ByRef strFieldValue As String, ByRef strFormat As String) As String
        Try
            Dim strResult As String = String.Empty
            Dim strY As String = String.Empty
            Dim strM As String = String.Empty
            Dim strD As String = String.Empty

            Select Case strFormat
                Case "YYBB"
                    If Len(strFieldValue) = 4 Then
                        If CInt(strFieldValue) < 2500 Then
                            strResult = CStr(CInt(strFieldValue) + 543).Trim
                        Else
                            strResult = strFieldValue
                        End If
                    Else
                        If CInt(strFieldValue.Substring(0, 4)) < 2500 Then
                            strResult = CStr(CInt(strFieldValue.Substring(0, 4)) + 543).Trim
                        Else
                            strResult = CStr(CInt(strFieldValue.Substring(0, 4))).Trim
                        End If
                    End If
                Case "DDMMYYBB"
                    strY = strFieldValue.Substring(0, 4)
                    strM = strFieldValue.Substring(4, 2)
                    strD = strFieldValue.Substring(6, 2)
                    If CInt(strY) < 2500 Then
                        strY = CStr(CInt(strY) + 543).Trim
                    End If
                    strResult = strD & strM & strY
                Case "MMDDYYBB"
                    strY = strFieldValue.Substring(0, 4)
                    strM = strFieldValue.Substring(4, 2)
                    strD = strFieldValue.Substring(6, 2)
                    If CInt(strY) < 2500 Then
                        strY = CStr(CInt(strY) + 543).Trim
                    End If
                    strResult = strM & strD & strY
                Case "YYBBMMDD"
                    strY = strFieldValue.Substring(0, 4)
                    strM = strFieldValue.Substring(4, 2)
                    strD = strFieldValue.Substring(6, 2)
                    If CInt(strY) < 2500 Then
                        strY = CStr(CInt(strY) + 543).Trim
                    End If
                    strResult = strY & strM & strD
                Case "YYYY"
                    If Len(strFieldValue) = 8 Then
                        strY = strFieldValue.Substring(0, 4)
                        strM = strFieldValue.Substring(4, 2)
                        strD = strFieldValue.Substring(6, 2)
                        If CInt(strY) < 2500 Then
                            strResult = strY
                        Else
                            strResult = CStr(CInt(strY) - 543).Trim
                        End If
                    Else
                        strResult = strFieldValue
                    End If
                Case "DDMMYYYY"
                    If Len(strFieldValue) = 8 Then
                        strY = strFieldValue.Substring(0, 4)
                        strM = strFieldValue.Substring(4, 2)
                        strD = strFieldValue.Substring(6, 2)
                        If CInt(strY) < 2500 Then
                            strResult = strD & strM & strY
                        Else
                            strResult = strD & strM & CStr(CInt(strY) - 543).Trim
                        End If
                    Else
                        strResult = strFieldValue
                    End If
                Case "MMDDYYYY"
                    If Len(strFieldValue) = 8 Then
                        strY = strFieldValue.Substring(0, 4)
                        strM = strFieldValue.Substring(4, 2)
                        strD = strFieldValue.Substring(6, 2)
                        If CInt(strY) < 2500 Then
                            strResult = strM & strD & strY
                        Else
                            strResult = strM & strD & CStr(CInt(strY) - 543).Trim
                        End If
                    Else
                        strResult = strFieldValue
                    End If
                Case "DD"
                    If Len(strFieldValue) = 8 Then
                        strY = strFieldValue.Substring(0, 4)
                        strM = strFieldValue.Substring(4, 2)
                        strD = strFieldValue.Substring(6, 2)
                        strResult = strD
                    Else
                        strResult = strFieldValue
                    End If
                Case "MM"
                    If Len(strFieldValue) = 8 Then
                        strY = strFieldValue.Substring(0, 4)
                        strM = strFieldValue.Substring(4, 2)
                        strD = strFieldValue.Substring(6, 2)
                        strResult = strM
                    Else
                        strResult = strFieldValue
                    End If
                Case Else
                    strResult = strFieldValue
            End Select
            Return strResult
        Catch ex As Exception
            Return String.Empty
        End Try
    End Function

    Private Function ReformatSelectData(ByRef strFIELD_MAPPING_VALUE As String, ByRef strDefault_value As String, ByRef strConfig_Value As String) As String
        Try
            Dim strValue As String = String.Empty
            If strFIELD_MAPPING_VALUE <> "" Then
                strValue = strFIELD_MAPPING_VALUE
            ElseIf strDefault_value <> "" Then
                strValue = strDefault_value
            Else
                strValue = strConfig_Value
            End If
            Return strValue
        Catch ex As Exception
            Return String.Empty
        End Try

    End Function

    Private Function ReformatLenError(ByRef drRowF As DataRow, ByRef strFIELD_MAPPING_VALUE As String) As String
        Try
            Dim strValue As String = String.Empty

            If drRowF.Item("FLAG_LEN_ERROR_ISEMPTY").ToString = "Y" Then
                If Len(strFIELD_MAPPING_VALUE) > drRowF.Item("FIELD_LENGTH") Then
                    strValue = drRowF.Item("DEFAULT_VALUE").ToString
                Else
                    strValue = strFIELD_MAPPING_VALUE
                End If
            Else
                strValue = strFIELD_MAPPING_VALUE
            End If

            Return strValue
        Catch ex As Exception
            Return String.Empty
        End Try

    End Function

    Private Function ReformatField(ByRef drFormat As DataRow _
                                   , ByRef strFIELD_MAPPING_VALUE As String _
                                   , ByRef strDefault_value As String _
                                   , ByRef strConfig_Value As String _
                                   ) As String
        Try
            Dim strValue As String = String.Empty
            Select Case drFormat.Item(6).ToString
                Case "C"
                    strValue = ReformatSelectData(strFIELD_MAPPING_VALUE, strDefault_value, strConfig_Value) '--strSource.Substring(1, drFormat.Item(7))
                Case "N"
                    If drFormat.Item(8).ToString = "" Then
                        strValue = ReformatSelectData(strFIELD_MAPPING_VALUE, strDefault_value, strConfig_Value) '--strSource.ToString.Trim()
                    Else
                        Dim str1, str2 As String
                        str1 = "###0"
                        str2 = StrDup(CInt(drFormat.Item(8)), "0")
                        strValue = Format(Val(ReformatSelectData(strFIELD_MAPPING_VALUE, strDefault_value, strConfig_Value)), str1 & "." & str2) '--Format(Val(strSource), str1 & "." & str2)
                    End If
                Case Else

            End Select
            Return strValue
        Catch ex As Exception
            Return String.Empty
        End Try
    End Function

    Private Function ReformatSWC(ByRef clsTAXSWC_CONFIG As clsGPS_TAXSWC_CONFIG_SETUP _
                                  , ByRef dtFormatH As DataTable _
                                  , ByRef dtFormatD As DataTable _
                                  , ByRef dtData As DataTable _
                                  , ByRef strTaxYear As String _
                                  , ByRef strTaxMonth As String _
                                  , ByRef strFormType As String) As String
        Try
            Dim strText As String = String.Empty
            Dim strLineH As String
            Dim strLineD As String
            Dim strField As String = String.Empty
            Dim strFieldValue As String = String.Empty
            Dim lngLine As Long = 0
            Dim lngTotal_Item As Long = 0
            Dim decTotal_Amt As Decimal = 0.0
            Dim decTotal_Tax As Decimal = 0.0
            Dim strF As String

            strLineD = String.Empty

            For Each rowD As DataRow In dtData.Rows
                'Add the Data rows.
                '--sbText += row(0).ToString & vbCr & vbLf
                lngLine += 1

                For Each rowF As DataRow In dtFormatD.Rows
                    strField = String.Empty
                    ''If rowF.Item(3) = 12 Then '-- line_seq
                    ''    decTotal_Amt += rowD.Item(rowF.Item(13).ToString)
                    ''End If
                    ''If rowF.Item(3) = 13 Then '-- line_seq
                    ''    decTotal_Tax += rowD.Item(rowF.Item(13).ToString)
                    ''End If
                    If rowF.Item(15).ToString = "Y" Then
                        If rowF.Item(13).ToString = "tax_base_amt" Then

                        End If
                        Select Case rowF.Item(13).ToString.Trim
                            Case "tax_base_amt"
                                decTotal_Amt += rowD.Item(rowF.Item(13).ToString)
                            Case "tax_tax_amt"
                                decTotal_Tax += rowD.Item(rowF.Item(13).ToString)
                            Case Else
                        End Select
                    End If

                    If rowF.Item(13).ToString.Trim <> "" Then
                        Select Case rowF.Item(13).ToString.Substring(0, 1)
                            Case "{" '--running
                                strField = lngLine.ToString.Trim
                            Case "[" '--get config value
                                strFieldValue = TaxFieldConcate(rowD, rowF.Item(13).ToString)
                                strF = rowF.Item(13).ToString.Replace("[", "").Replace("]", "")
                                strField = ReformatField(rowF _
                                                        , strFieldValue _
                                                        , rowF.Item(12).ToString _
                                                        , clsTAXSWC_CONFIG.Config_Value(strF))
                            Case Else '-- field mapping

                                strFieldValue = TaxFieldConcate(rowD, rowF.Item(13).ToString)
                                strFieldValue = ReformatData(strFieldValue, rowF.Item(14).ToString)
                                strFieldValue = ReformatLenError(rowF, strFieldValue)
                                strField = ReformatField(rowF _
                                                        , strFieldValue _
                                                        , rowF.Item(12).ToString _
                                                        , "")
                        End Select
                    Else
                        strField = ReformatField(rowF _
                                                , "" _
                                                , rowF.Item(12).ToString _
                                                , "")
                    End If

                    strLineD = strLineD & strField & clsTAXSWC_CONFIG.configFIELD_SEPERATE

                Next
                strLineD = strLineD.Substring(0, Len(strLineD) - 1)
                Select Case clsTAXSWC_CONFIG.configLINE_SEPERATE
                    Case "CRLF"
                        strLineD = strLineD & vbCrLf
                    Case "CR"
                        strLineD = strLineD & vbCr
                    Case "LF"
                        strLineD = strLineD & vbLf
                    Case Else
                        strLineD = strLineD & vbCrLf
                End Select
            Next

            '-- haeader --
            '=============
            ' 1. field mapping
            ' 2. default value
            ' 3. config value
            strLineH = String.Empty
            For Each rowF As DataRow In dtFormatH.Rows
                strField = String.Empty
                If rowF.Item(13).ToString.Trim <> "" Then
                    Select Case rowF.Item(13).ToString.Substring(0, 1)
                        Case "{" '--total_line
                            '--strLineH = lngLine.ToString.Trim
                            Select Case rowF.Item(13).ToString.Replace("{", "").Replace("}", "")
                                Case "tax_month"
                                    '--strField = strTaxMonth
                                    strField = ReformatData(strTaxMonth, rowF.Item(14).ToString)
                                Case "tax_year"
                                    '--strField = strTaxYear
                                    strField = ReformatData(strTaxYear, rowF.Item(14).ToString)
                                Case "form_type"
                                    strField = strFormType
                                Case "total_line"
                                    strField = lngLine.ToString.Trim
                                Case "running"
                                    strField = lngLine.ToString.Trim
                                Case "total_amt"
                                    strField = ReformatField(rowF _
                                                , decTotal_Amt.ToString _
                                                , rowF.Item(12).ToString _
                                                , "")
                                Case "total_tax"
                                    strField = ReformatField(rowF _
                                                , decTotal_Tax.ToString _
                                                , rowF.Item(12).ToString _
                                                , "")
                                Case Else
                                    strField = ""
                            End Select
                        Case "[" '--get config value
                            strF = rowF.Item(13).ToString.Replace("[", "").Replace("]", "")
                            strField = ReformatField(rowF _
                                                    , "" _
                                                    , rowF.Item(12).ToString _
                                                    , clsTAXSWC_CONFIG.Config_Value(strF))
                        Case Else '-- field mapping
                            strField = ReformatField(rowF _
                                                    , "" _
                                                    , rowF.Item(12).ToString _
                                                    , "")
                    End Select
                Else
                    strField = ReformatField(rowF _
                                            , "" _
                                            , rowF.Item(12).ToString _
                                            , "")
                End If

                strLineH = strLineH & strField & clsTAXSWC_CONFIG.configFIELD_SEPERATE
            Next
            strLineH = strLineH.Substring(0, Len(strLineH) - 1)
            Select Case clsTAXSWC_CONFIG.configLINE_SEPERATE
                Case "CRLF"
                    strLineH = strLineH & vbCrLf
                Case "CR"
                    strLineH = strLineH & vbCr
                Case "LF"
                    strLineH = strLineH & vbLf
                Case Else
                    strLineH = strLineH & vbCrLf
            End Select

            _TAXSWC_TOT_LINE = lngLine
            _TAXSWC_TOT_AMT = decTotal_Amt
            _TAXSWC_TOT_TAX = decTotal_Tax
            strText = strLineH & strLineD

            Return strText

        Catch ex As Exception
            Return Nothing
        End Try

    End Function


    Public Function GenSWCText(ByRef conConn As System.Data.OleDb.OleDbConnection _
                               , ByRef strTaxTypeCode As String _
                               , ByRef strTaxPeriod As String _
                               , ByRef strAccountPeriod As String _
                               , ByRef strForm_Type As String _
                               ) As String

        Try
            Dim dtTaxData As New DataTable
            Dim dtSWCFormatH As New DataTable
            Dim dtSWCFormatD As New DataTable
            Dim strTAXSWC As String
            Dim strFLAG_ISYEARLY As String
            Dim clsTAXSWC_CONFIG As New clsGPS_TAXSWC_CONFIG_SETUP
            Dim clsTAXSWC_TAXTYPE As New clsGPS_TAXSWC_TAXTYPE_SETUP

            With clsTAXSWC_CONFIG
                .ConnDB = conConn
                .GetConfig()
            End With
            With clsTAXSWC_TAXTYPE
                .ConnDB = conConn
                strFLAG_ISYEARLY = .GetTaxTypeIsYearly(strTaxTypeCode)
            End With

            If strFLAG_ISYEARLY = "Y" Then
                dtTaxData = GetDataPhorNgorDorToSWC_ByYear(conConn, strTaxPeriod, strTaxTypeCode.Substring(0, 2))
            Else
                If strForm_Type = "00" Then
                    dtTaxData = GetDataPhorNgorDorToSWC_ByPeriod(conConn, strTaxPeriod, strTaxTypeCode)
                Else
                    dtTaxData = GetDataPhorNgorDorOutMthToSWC_ByPeriod(conConn, strTaxPeriod, strAccountPeriod, strTaxTypeCode)
                End If
            End If


            If Not IsNothing(dtTaxData) AndAlso dtTaxData.Rows.Count > 0 Then
                dtSWCFormatH = GetTaxSWCFormatH(conConn, strTaxTypeCode)
                dtSWCFormatD = GetTaxSWCFormatD(conConn, strTaxTypeCode)

                If Not IsNothing(dtSWCFormatH) AndAlso dtSWCFormatH.Rows.Count > 0 Then
                Else
                    Return Nothing
                End If
                If Not IsNothing(dtSWCFormatD) AndAlso dtSWCFormatD.Rows.Count > 0 Then
                Else
                    Return Nothing
                End If

                If strFLAG_ISYEARLY = "Y" Then
                    strTAXSWC = ReformatSWC(clsTAXSWC_CONFIG, dtSWCFormatH, dtSWCFormatD, dtTaxData, strTaxPeriod.Substring(0, 4), "00", strForm_Type)
                Else
                    strTAXSWC = ReformatSWC(clsTAXSWC_CONFIG, dtSWCFormatH, dtSWCFormatD, dtTaxData, strTaxPeriod.Substring(0, 4), strTaxPeriod.Substring(4, 2), strForm_Type)
                End If
                Return strTAXSWC
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing

        End Try
    End Function


End Class
